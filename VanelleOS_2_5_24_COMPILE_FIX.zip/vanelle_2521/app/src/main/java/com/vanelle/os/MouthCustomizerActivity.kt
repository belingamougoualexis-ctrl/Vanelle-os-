package com.vanelle.os

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

/**
 * Éditeur réel de bouche/lèvres : bibliothèque intégrée + photo personnelle,
 * déplacement tactile, taille, rotation et sauvegarde persistante par mascotte.
 */
class MouthCustomizerActivity : ComponentActivity() {
    private lateinit var preview: FrameLayout
    private lateinit var mouth: ImageView
    private lateinit var mascot: ImageView
    private lateinit var scaleSeek: SeekBar
    private lateinit var rotationSeek: SeekBar
    private var mascotId = "kawaii"
    private var selectedAsset = ""
    private var scale = 1f
    private var rotation = 0f
    private var dragging = false
    private var downRawX = 0f
    private var downRawY = 0f
    private var startTx = 0f
    private var startTy = 0f

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun button(text: String, primary: Boolean = false) = Button(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(if (primary) Color.WHITE else UiKit.BLACK)
        background = if (primary) UiKit.buttonPrimary(this@MouthCustomizerActivity) else UiKit.buttonSecondary(this@MouthCustomizerActivity)
        minHeight = dp(44)
        isAllCaps = false
    }

    private val photoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        val copied = MouthManager.importCustomPhoto(this, mascotId, uri)
        if (copied == null) {
            Toast.makeText(this, "Impossible de charger cette photo.", Toast.LENGTH_SHORT).show()
            return@registerForActivityResult
        }
        selectedAsset = copied
        MouthManager.getDrawable(this, mascotId)?.let { mouth.setImageDrawable(it) }
        Toast.makeText(this, "Photo ajoutée. Déplace maintenant la bouche sur le sourire.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mascotId = intent.getStringExtra("mascot_id") ?: MascotManager.getSelected(this)
        val saved = MouthManager.get(this, mascotId)
        selectedAsset = saved.asset.ifBlank { MouthManager.library.first() }
        scale = saved.scale
        rotation = saved.rotation

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(UiKit.WHITE)
        }
        root.addView(TextView(this).apply {
            text = "Personnalise la bouche de ta mascotte"
            textSize = 20f
            setTextColor(UiKit.BLACK)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Choisis une bouche ou ajoute ta propre photo, puis glisse-la directement sur le sourire."
            textSize = 12f
            setTextColor(UiKit.TEXT_MUTED)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(12))
        })

        preview = FrameLayout(this).apply {
            setBackgroundColor(UiKit.SURFACE)
            layoutParams = LinearLayout.LayoutParams(-1, dp(360)).apply { bottomMargin = dp(10) }
        }
        mascot = ImageView(this).apply {
            setImageResource(MascotManager.getDrawableId(this@MouthCustomizerActivity, mascotId))
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }
        mouth = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageDrawable(resolveMouthDrawable(selectedAsset))
            layoutParams = FrameLayout.LayoutParams(dp(92), dp(60))
            elevation = dp(6).toFloat()
            contentDescription = "Bouche sélectionnée"
        }
        preview.addView(mascot)
        preview.addView(mouth)
        root.addView(preview)

        root.addView(TextView(this).apply {
            text = "👆 Glisse la bouche avec le doigt pour la placer exactement où tu veux."
            textSize = 11f
            setTextColor(UiKit.TEXT_MUTED)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
        })

        val sizeLabel = TextView(this).apply { text = "Taille"; setTextColor(UiKit.BLACK); textSize = 12f }
        scaleSeek = SeekBar(this).apply {
            max = 175
            progress = ((scale - .45f) / 1.75f * 175f).roundToInt().coerceIn(0, 175)
        }
        val rotLabel = TextView(this).apply { text = "Rotation"; setTextColor(UiKit.BLACK); textSize = 12f }
        rotationSeek = SeekBar(this).apply { max = 50; progress = (rotation + 25f).roundToInt().coerceIn(0, 50) }
        root.addView(sizeLabel); root.addView(scaleSeek); root.addView(rotLabel); root.addView(rotationSeek)

        val photoButton = button("📷  Ajouter ma photo de bouche / lèvres")
        photoButton.setOnClickListener { photoPicker.launch(arrayOf("image/jpeg", "image/png", "image/webp")) }
        root.addView(photoButton, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(6) })

        val grid = GridLayout(this).apply {
            columnCount = 4
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = true
            layoutParams = LinearLayout.LayoutParams(-1, dp(250)).apply { topMargin = dp(4) }
        }
        MouthManager.library.forEach { asset ->
            val iv = ImageView(this).apply {
                setImageDrawable(resolveMouthDrawable(asset))
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = if (asset == selectedAsset) UiKit.selected(this@MouthCustomizerActivity) else UiKit.card(this@MouthCustomizerActivity)
                contentDescription = "Bouche $asset"
                layoutParams = GridLayout.LayoutParams().apply { width = dp(72); height = dp(48) }
                setPadding(dp(2), dp(2), dp(2), dp(2))
                setOnClickListener {
                    selectedAsset = asset
                    mouth.setImageDrawable(resolveMouthDrawable(asset))
                    refreshSelection(grid)
                }
            }
            grid.addView(iv)
        }
        val scroll = ScrollView(this).apply { addView(grid) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        val reset = button("Réinitialiser")
        val save = button("Enregistrer", true)
        actions.addView(reset, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        actions.addView(save, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) })
        root.addView(actions)
        setContentView(root)

        preview.post { applyConfig(saved.x, saved.y) }

        scaleSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                scale = .45f + (p / 175f) * 1.75f
                mouth.scaleX = scale; mouth.scaleY = scale
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        rotationSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                rotation = p - 25f
                mouth.rotation = rotation
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        reset.setOnClickListener {
            MouthManager.reset(this, mascotId)
            selectedAsset = MouthManager.library.first()
            scale = 1f; rotation = 0f
            mouth.setImageDrawable(resolveMouthDrawable(selectedAsset))
            mouth.scaleX = 1f; mouth.scaleY = 1f; mouth.rotation = 0f
            scaleSeek.progress = ((1f - .45f) / 1.75f * 175f).roundToInt()
            rotationSeek.progress = 25
            preview.post { applyConfig(.5f, MascotManager.mouthPositionFraction(this, mascotId)) }
            refreshSelection(grid)
            Toast.makeText(this, "Bouche réinitialisée", Toast.LENGTH_SHORT).show()
        }

        save.setOnClickListener {
            val w = preview.width.coerceAtLeast(1)
            val h = preview.height.coerceAtLeast(1)
            val centerX = (mouth.x + mouth.width / 2f).coerceIn(0f, w.toFloat())
            val centerY = (mouth.y + mouth.height / 2f).coerceIn(0f, h.toFloat())
            MouthManager.save(this, mascotId, MouthManager.Config(selectedAsset, centerX / w, centerY / h, scale, rotation))
            FloatingMascotButton.refreshIcon(this)
            Toast.makeText(this, "Modification enregistrée pour ${MascotManager.mascots.firstOrNull { it.first == mascotId }?.second ?: "ta mascotte"}", Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK)
            finish()
        }

        mouth.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = true; downRawX = event.rawX; downRawY = event.rawY
                    startTx = v.x; startTy = v.y; true
                }
                MotionEvent.ACTION_MOVE -> if (dragging) {
                    val nx = (startTx + event.rawX - downRawX).coerceIn(-v.width * .45f, preview.width - v.width * .55f)
                    val ny = (startTy + event.rawY - downRawY).coerceIn(-v.height * .45f, preview.height - v.height * .55f)
                    v.x = nx; v.y = ny; true
                } else false
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { dragging = false; true }
                else -> false
            }
        }
    }

    private fun resolveMouthDrawable(asset: String): Drawable? =
        if (MouthManager.isCustomPhoto(asset)) MouthManager.customFile(this, asset)?.let { Drawable.createFromPath(it.absolutePath) }
        else {
            val id = resources.getIdentifier(asset, "drawable", packageName)
            if (id != 0) ContextCompat.getDrawable(this, id) else null
        }

    private fun applyConfig(xNorm: Float, yNorm: Float) {
        mouth.scaleX = scale; mouth.scaleY = scale; mouth.rotation = rotation
        preview.post {
            val x = xNorm.coerceIn(0f, 1f) * preview.width - mouth.width / 2f
            val y = yNorm.coerceIn(0.05f, .95f) * preview.height - mouth.height / 2f
            mouth.x = x; mouth.y = y
        }
    }

    private fun refreshSelection(grid: GridLayout) {
        for (i in 0 until grid.childCount) {
            val v = grid.getChildAt(i) as ImageView
            v.background = if (MouthManager.library[i] == selectedAsset) UiKit.selected(this) else UiKit.card(this)
        }
    }
}
