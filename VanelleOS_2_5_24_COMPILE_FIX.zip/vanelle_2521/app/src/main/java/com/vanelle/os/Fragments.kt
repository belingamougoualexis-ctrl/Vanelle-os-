package com.vanelle.os
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.Toast
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.content.ClipData
import android.content.ClipboardManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.webkit.WebView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
class MascotFragment:Fragment(){
    private val mouthEditorLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { if (it.resultCode == android.app.Activity.RESULT_OK) refreshCurrentPreview() }

    private var currentMascotId = "kawaii"
    private var heroFrame: FrameLayout? = null
    private var heroImage: ImageView? = null
    private var heroMouth: ImageView? = null

    private fun dp(v:Int):Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val root=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(28,28,28,28); setBackgroundColor(UiKit.WHITE)}

        val title=TextView(ctx).apply{
            text="TA MASCOTTE"
            setTextColor(UiKit.BLACK); textSize=20f; typeface=android.graphics.Typeface.DEFAULT_BOLD
            setPadding(2,0,2,4)
        }
        val subtitle=TextView(ctx).apply{
            text="Choisis son style et personnalise sa bouche comme tu veux."
            setTextColor(UiKit.TEXT_MUTED); textSize=12f; setPadding(2,0,2,14)
        }
        root.addView(title); root.addView(subtitle)

        heroFrame=FrameLayout(ctx).apply{
            layoutParams=LinearLayout.LayoutParams(-1,480).apply{bottomMargin=16}
            background=UiKit.card(ctx)
        }
        heroImage=ImageView(ctx).apply{
            scaleType=ImageView.ScaleType.FIT_CENTER
            layoutParams=FrameLayout.LayoutParams(-1,-1)
        }
        heroMouth=ImageView(ctx).apply{
            scaleType=ImageView.ScaleType.FIT_CENTER
            visibility=View.GONE
            elevation=8f
            layoutParams=FrameLayout.LayoutParams(dp(92),dp(60))
        }
        heroFrame?.let { frame ->
            heroImage?.let(frame::addView)
            heroMouth?.let(frame::addView)
        }
        root.addView(heroFrame)

        val editMouth=Button(ctx).apply{
            text="👄  Personnaliser la bouche"
            textSize=12f; setTextColor(UiKit.BLACK); background=UiKit.buttonSecondary(ctx)
            layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=16}
            setOnClickListener{
                mouthEditorLauncher.launch(Intent(ctx,MouthCustomizerActivity::class.java).putExtra("mascot_id",currentMascotId))
            }
        }
        root.addView(editMouth)

        val nameTitle=TextView(ctx).apply{
            text="NOM DE TA MASCOTTE"
            setTextColor(UiKit.TEXT_MUTED); textSize=11f; letterSpacing=0.1f
            setPadding(4,8,0,8)
        }
        val nameRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(16,8,16,8); background=UiKit.card(ctx)}
        val nameEdit=EditText(ctx).apply{
            hint="Ex: Luna, Buddy, Pixel..."; setText(MascotManager.getCustomName(ctx)); setTextColor(UiKit.BLACK)
            setHintTextColor(UiKit.TEXT_MUTED); textSize=14f; background=null
            layoutParams=LinearLayout.LayoutParams(0,-2,1f); maxLines=1; isSingleLine=true
        }
        val saveBtn=Button(ctx).apply{
            text="Enregistrer"; textSize=11f; background=UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            setOnClickListener{
                val n=nameEdit.text?.toString()?.trim() ?: ""; MascotManager.setCustomName(ctx,n)
                Toast.makeText(ctx,if(n.isBlank()) "Nom réinitialisé" else "Nom enregistré : $n",Toast.LENGTH_SHORT).show()
            }
        }
        nameRow.addView(nameEdit); nameRow.addView(saveBtn)

        val nameHint=TextView(ctx).apply{
            text="La bouche personnalisée est enregistrée pour chaque mascotte et utilisée dans le mode vocal et la mascotte flottante."
            setTextColor(UiKit.TEXT_MUTED); textSize=10.5f; setPadding(6,10,6,16)
        }

        val styleTitle=TextView(ctx).apply{text="CHOISIS UN STYLE"; setTextColor(UiKit.TEXT_MUTED); textSize=11f; letterSpacing=0.1f; setPadding(4,4,0,10)}
        val scroll=HorizontalScrollView(ctx).apply{isHorizontalScrollBarEnabled=false}
        val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        for((id,name) in MascotManager.mascots){
            val card=LinearLayout(ctx).apply{
                orientation=LinearLayout.VERTICAL; setPadding(10,10,10,10)
                layoutParams=LinearLayout.LayoutParams(150,200).apply{setMargins(0,0,12,0)}
                background=if(id==currentMascotId) UiKit.selected(ctx) else UiKit.card(ctx)
            }
            val iv=ImageView(ctx).apply{
                try{setImageResource(MascotManager.getDrawableId(ctx,id))}catch(_:Exception){}
                scaleType=ImageView.ScaleType.FIT_CENTER; layoutParams=LinearLayout.LayoutParams(-1,150); adjustViewBounds=true
            }
            val tv=TextView(ctx).apply{text=name; setTextColor(UiKit.BLACK); textSize=10f; letterSpacing=0.04f; setPadding(0,8,0,0); gravity=android.view.Gravity.CENTER}
            card.addView(iv); card.addView(tv)
            card.setOnClickListener{
                currentMascotId=id; MascotManager.setSelected(ctx,id); FloatingMascotButton.refreshIcon(ctx); refreshCurrentPreview()
                for(j in 0 until row.childCount){(row.getChildAt(j) as LinearLayout).background=UiKit.card(ctx)}
                card.background=UiKit.selected(ctx)
            }
            row.addView(card)
        }
        scroll.addView(row)

        val testBtn=Button(ctx).apply{
            text="Faire apparaître maintenant"; textSize=12f; background=UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=20}
            setOnClickListener{
                if(!DataDownloadService.isUsable(ctx)){Toast.makeText(ctx,"L'IA doit être téléchargée et chargée en mémoire avant d'afficher la mascotte.",Toast.LENGTH_LONG).show();return@setOnClickListener}
                if(!OverlayHelper.canDraw(ctx)){Toast.makeText(ctx,"Active d'abord « afficher par-dessus les apps » dans Configuration",Toast.LENGTH_LONG).show();OverlayHelper.requestPermission(ctx);return@setOnClickListener}
                OverlayHelper.showMascot(ctx,MascotManager.getDrawableId(ctx,MascotManager.getSelected(ctx)),"")
            }
        }

        root.addView(nameTitle); root.addView(nameRow); root.addView(nameHint); root.addView(styleTitle); root.addView(scroll); root.addView(testBtn)
        currentMascotId=MascotManager.getSelected(ctx)
        refreshCurrentPreview()
        return root
    }

    private fun refreshCurrentPreview(){
        val ctx=context ?: return
        val id=MascotManager.getSelected(ctx); currentMascotId=id
        heroImage?.setImageResource(MascotManager.getDrawableId(ctx,id))
        val cfg=MouthManager.get(ctx,id); val drawable=MouthManager.getDrawable(ctx,id)
        val mouth=heroMouth ?: return
        if(drawable==null){mouth.visibility=View.GONE; return}
        mouth.visibility=View.VISIBLE; mouth.setImageDrawable(drawable); mouth.scaleX=cfg.scale; mouth.scaleY=cfg.scale; mouth.rotation=cfg.rotation
        heroFrame?.post{
            val w=heroFrame?.width ?: return@post; val h=heroFrame?.height ?: return@post
            mouth.x=cfg.x*w-mouth.width/2f; mouth.y=cfg.y*h-mouth.height/2f
        }
    }
}
class ConfigFragment:Fragment(){
    private val refreshers=mutableListOf<()->Unit>()
    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        val msg = UserDataSnapshot.importFromUri(requireContext(), uri)
        Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show()
    }
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext(); refreshers.clear()
        val sv=ScrollView(ctx).apply{setBackgroundColor(UiKit.WHITE)}
        val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(32,40,32,40)}

        fun sectionTitle(t:String)=TextView(ctx).apply{text=t; setTextColor(UiKit.TEXT_MUTED); textSize=11f; letterSpacing=0.1f; setPadding(4,0,0,10)}
        fun spacer(h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,h)}

        // --- Assistant vocal ---
        col.addView(sectionTitle("ASSISTANT VOCAL"))
        val voiceInfo=TextView(ctx).apply{
            text="Clique sur la mascotte flottante pour activer le micro."
            setTextColor(UiKit.TEXT_MUTED); textSize=12f; setPadding(24,18,24,18); background=UiKit.card(ctx)
        }
        col.addView(voiceInfo); col.addView(spacer(28))

        // Diagnostic retire — ecran plus simple

        // --- Autorisations ---
        col.addView(sectionTitle("AUTORISATIONS"))

        // Aide commune : Android 13+ bloque certaines autorisations (accessibilité, SMS...)
        // pour les apps installées hors Play Store tant qu'on n'a pas explicitement débloqué
        // les « paramètres restreints » dans l'écran Infos de l'application.
        fun showRestrictedSettingsHelp(extra: String = "") {
            AlertDialog.Builder(ctx)
                .setTitle("Autorisation bloquée par Android")
                .setMessage(
                    "Depuis Android 13, une app installée hors Play Store (comme Vanelle OS) " +
                    "doit d'abord être débloquée manuellement avant de pouvoir accorder certaines " +
                    "autorisations sensibles.$extra\n\n" +
                    "Dans l'écran qui va s'ouvrir :\n" +
                    "1. Touche le menu ⋮ en haut à droite\n" +
                    "2. Choisis « Autoriser les paramètres restreints »\n" +
                    "3. Reviens ici et réessaie d'accorder l'autorisation"
                )
                .setPositiveButton("Ouvrir les réglages de l'appli") { _, _ ->
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply { data = Uri.fromParts("package", ctx.packageName, null) }
                    startActivity(intent)
                }
                .setNegativeButton("Annuler", null)
                .show()
        }

        fun permRow(label:String, permission:String, consequence:String, restrictedHint:Boolean=false):View{
            val col2=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
            val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
            val labelView=TextView(ctx).apply{text=label; setTextColor(UiKit.BLACK); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
            val statusView=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
            val manageBtn=Button(ctx).apply{
                text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(UiKit.BLACK)
                setOnClickListener{
                    val granted=ContextCompat.checkSelfPermission(ctx,permission)==PackageManager.PERMISSION_GRANTED
                    if(restrictedHint && !granted && Build.VERSION.SDK_INT>=33){
                        showRestrictedSettingsHelp(
                            " C'est la cause la plus fréquente quand l'envoi de SMS reste " +
                            "\u00ab non accordée \u00bb même après avoir accepté la demande."
                        )
                    } else {
                        val intent=Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply{ data=Uri.fromParts("package",ctx.packageName,null) }
                        startActivity(intent)
                    }
                }
            }
            val consLabel=TextView(ctx).apply{text="Si refuse : $consequence"; setTextColor(UiKit.TEXT_MUTED); textSize=10f; setPadding(0,8,0,0)}
            fun refresh(){
                val granted=ContextCompat.checkSelfPermission(ctx,permission)==PackageManager.PERMISSION_GRANTED
                statusView.text=if(granted) "Accordee" else "Non accordee"
                statusView.setTextColor(if(granted) UiKit.BLACK else UiKit.DANGER)
            }
            refresh(); refreshers.add(::refresh)
            row.addView(labelView); row.addView(statusView); row.addView(manageBtn)
            col2.addView(row); col2.addView(consLabel)
            return col2
        }

        col.addView(permRow("Microphone (ecoute vocale)", Manifest.permission.RECORD_AUDIO, "impossible d'utiliser les commandes vocales"))
        col.addView(spacer(2))
        col.addView(permRow("Contacts (appel par nom)", Manifest.permission.READ_CONTACTS, "impossible de trouver un contact par son nom"))
        col.addView(spacer(2))
        col.addView(permRow("Appel telephonique", Manifest.permission.CALL_PHONE, "les demandes d'appel resteront sans effet, meme apres confirmation"))
        col.addView(spacer(2))
        col.addView(permRow("Envoi de SMS", Manifest.permission.SEND_SMS, "les demandes d'envoi de message resteront sans effet, meme apres confirmation", restrictedHint=true))
        col.addView(spacer(2))
        if(Build.VERSION.SDK_INT>=33){
            col.addView(permRow("Notifications", Manifest.permission.POST_NOTIFICATIONS, "la notification d'ecoute active et les rappels de relances ne s'afficheront pas"))
            col.addView(spacer(2))
        }

        // Accès « Ne pas déranger » (requis pour mode silencieux / vibreur / normal)
        if (Build.VERSION.SDK_INT >= 24) {
            val dndCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 18, 24, 18); background = UiKit.card(ctx) }
            val dndRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            val dndLabel = TextView(ctx).apply {
                text = "Ne pas deranger (mode son silencieux / vibreur)"
                setTextColor(UiKit.BLACK); textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val dndStatus = TextView(ctx).apply { textSize = 11f; setPadding(0, 0, 20, 0) }
            val dndBtn = Button(ctx).apply {
                text = "Gerer"; textSize = 10f; background = UiKit.pill(ctx); setTextColor(UiKit.BLACK)
                setOnClickListener {
                    try {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                    } catch (_: Exception) {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.fromParts("package", ctx.packageName, null)
                        })
                    }
                }
            }
            fun refreshDnd() {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager
                val granted = nm?.isNotificationPolicyAccessGranted == true
                dndStatus.text = if (granted) "Accordee" else "Non accordee"
                dndStatus.setTextColor(if (granted) UiKit.BLACK else UiKit.DANGER)
            }
            refreshDnd(); refreshers.add(::refreshDnd)
            dndRow.addView(dndLabel); dndRow.addView(dndStatus); dndRow.addView(dndBtn)
            val dndCons = TextView(ctx).apply {
                text = "Si refuse : impossible de passer en mode silencieux, vibreur ou son normal via Vanelle"
                setTextColor(UiKit.TEXT_MUTED); textSize = 10f; setPadding(0, 8, 0, 0)
            }
            dndCol.addView(dndRow); dndCol.addView(dndCons)
            col.addView(dndCol); col.addView(spacer(2))
        }

        // Accessibilite (mecanisme different : reglage systeme, pas une permission classique)
        val accCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val accRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val accLabel=TextView(ctx).apply{text="Service d'accessibilite (actions systeme)"; setTextColor(UiKit.BLACK); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val accStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val accBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            setOnClickListener{
                val exp="${ctx.packageName}/${VanelleAccessibilityService::class.java.canonicalName}"
                val en=Settings.Secure.getString(ctx.contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                var granted=false
                if(en!=null){ val split=TextUtils.SimpleStringSplitter(':'); split.setString(en); while(split.hasNext()){ if(split.next().equals(exp,true)){ granted=true; break } } }
                if(!granted && Build.VERSION.SDK_INT>=33){
                    showRestrictedSettingsHelp(
                        " C'est la cause la plus fréquente quand le service d'accessibilité " +
                        "reste grisé ou refuse de s'activer."
                    )
                } else {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
        }
        fun refreshAcc(){
            val exp="${ctx.packageName}/${VanelleAccessibilityService::class.java.canonicalName}"
            val en=Settings.Secure.getString(ctx.contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            var granted=false
            if(en!=null){ val split=TextUtils.SimpleStringSplitter(':'); split.setString(en); while(split.hasNext()){ if(split.next().equals(exp,true)){ granted=true; break } } }
            accStatus.text=if(granted) "Accordee" else "Non accordee"
            accStatus.setTextColor(if(granted) UiKit.BLACK else UiKit.DANGER)
        }
        refreshAcc(); refreshers.add(::refreshAcc)
        accRow.addView(accLabel); accRow.addView(accStatus); accRow.addView(accBtn)
        val accCons=TextView(ctx).apply{text="Si refuse : les commandes retour/accueil/notifications/recents ne fonctionneront pas"; setTextColor(UiKit.TEXT_MUTED); textSize=10f; setPadding(0,8,0,0)}
        accCol.addView(accRow); accCol.addView(accCons)
        col.addView(accCol); col.addView(spacer(2))

        // Alarmes exactes (necessaire pour l'onglet Relances)
        val alarmCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val alarmRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val alarmLabel=TextView(ctx).apply{text="Alarmes exactes (relances a l'heure precise)"; setTextColor(UiKit.BLACK); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val alarmStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val alarmBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            setOnClickListener{ if(Build.VERSION.SDK_INT>=31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:${ctx.packageName}"))) }
        }
        fun refreshAlarm(){
            val granted=AlarmScheduler.canScheduleExact(ctx)
            alarmStatus.text=if(granted) "Accordee" else "Non accordee"
            alarmStatus.setTextColor(if(granted) UiKit.BLACK else UiKit.DANGER)
        }
        refreshAlarm(); refreshers.add(::refreshAlarm)
        alarmRow.addView(alarmLabel); alarmRow.addView(alarmStatus); alarmRow.addView(alarmBtn)
        val alarmCons=TextView(ctx).apply{text="Si refuse : les relances programmees peuvent se declencher en retard, plus jamais a l'heure exacte"; setTextColor(UiKit.TEXT_MUTED); textSize=10f; setPadding(0,8,0,0)}
        alarmCol.addView(alarmRow); alarmCol.addView(alarmCons)
        col.addView(alarmCol); col.addView(spacer(2))

        // Affichage par-dessus les autres apps (mascotte sur l'ecran principal)
        val overlayCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val overlayRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val overlayLabel=TextView(ctx).apply{text="Affichage sur l'ecran principal"; setTextColor(UiKit.BLACK); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val overlayStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val overlayBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            setOnClickListener{ OverlayHelper.requestPermission(ctx) }
        }
        fun refreshOverlay(){
            val granted=OverlayHelper.canDraw(ctx)
            overlayStatus.text=if(granted) "Accordee" else "Non accordee"
            overlayStatus.setTextColor(if(granted) UiKit.BLACK else UiKit.DANGER)
        }
        refreshOverlay(); refreshers.add(::refreshOverlay)
        overlayRow.addView(overlayLabel); overlayRow.addView(overlayStatus); overlayRow.addView(overlayBtn)
        val overlayCons=TextView(ctx).apply{text="Si refuse : la mascotte repond seulement dans une fenetre de l'app, pas par-dessus ton ecran habituel"; setTextColor(UiKit.TEXT_MUTED); textSize=10f; setPadding(0,8,0,0)}
        overlayCol.addView(overlayRow); overlayCol.addView(overlayCons)
        col.addView(overlayCol); col.addView(spacer(28))

        // --- Mode traduction : activation vocale uniquement ---
        col.addView(sectionTitle("MODE TRADUCTION"))
        val trRow=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,20,24,20); background=UiKit.card(ctx)}
        val trLabel=TextView(ctx).apply{
            text="Mode traduction vocale : Vanelle écoute, traduit et lit à voix haute.\n• Source = langue que tu parles\n• Cible = langue de sortie\n• Activer / Arrêter = démarre ou stoppe le mode\n25+ langues via le moteur système / réseau (si autorisé)."
            setTextColor(UiKit.BLACK); textSize=12f
        }
        val trStatus=TextView(ctx).apply{
            text=if(TranslateModePrefs.isActive(ctx))
                "Actif : ${TranslateHelper.labelFor(TranslateModePrefs.source(ctx))} → ${TranslateHelper.labelFor(TranslateModePrefs.target(ctx))}"
            else "Inactif"
            textSize=11f; setTextColor(UiKit.TEXT_MUTED); setPadding(0,10,0,0)
        }
        val langLabels = TranslateHelper.UI_LANGUAGES.map { it.first }.toTypedArray()
        val langCodes = TranslateHelper.UI_LANGUAGES.map { it.second }
        fun pickLang(title: String, currentCode: String, onPick: (String) -> Unit) {
            val idx = langCodes.indexOfFirst { it.equals(currentCode, true) }.coerceAtLeast(0)
            AlertDialog.Builder(ctx).setTitle(title)
                .setSingleChoiceItems(langLabels, idx) { d, which ->
                    onPick(langCodes[which])
                    d.dismiss()
                }
                .setNegativeButton("Annuler", null).show()
        }
        val trBtns = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 10, 0, 0) }
        val srcBtn = Button(ctx).apply {
            text = "Langue source"; textSize = 10f; background = UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 6 }
            setOnClickListener {
                pickLang("Langue source", TranslateModePrefs.source(ctx)) { code ->
                    val t = TranslateModePrefs.target(ctx)
                    if (TranslateModePrefs.isActive(ctx)) TranslateModePrefs.start(ctx, code, t)
                    else { TranslateModePrefs.start(ctx, code, t); TranslateModePrefs.stop(ctx) }
                    trStatus.text = "Source : ${TranslateHelper.labelFor(code)}"
                }
            }
        }
        val tgtBtn = Button(ctx).apply {
            text = "Langue cible"; textSize = 10f; background = UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 6 }
            setOnClickListener {
                pickLang("Langue cible", TranslateModePrefs.target(ctx)) { code ->
                    val s = TranslateModePrefs.source(ctx)
                    if (TranslateModePrefs.isActive(ctx)) TranslateModePrefs.start(ctx, s, code)
                    else { TranslateModePrefs.start(ctx, s, code); TranslateModePrefs.stop(ctx) }
                    trStatus.text = "Cible : ${TranslateHelper.labelFor(code)}"
                }
            }
        }
        val toggleTr = Button(ctx).apply {
            text = if (TranslateModePrefs.isActive(ctx)) "Arrêter" else "Activer"
            textSize = 10f; background = UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener {
                if (TranslateModePrefs.isActive(ctx)) {
                    TranslateModePrefs.stop(ctx)
                    text = "Activer"
                    trStatus.text = "Inactif"
                } else {
                    TranslateModePrefs.start(ctx, TranslateModePrefs.source(ctx), TranslateModePrefs.target(ctx).let { if (it == "auto") "fr" else it })
                    text = "Arrêter"
                    trStatus.text = "Actif : ${TranslateHelper.labelFor(TranslateModePrefs.source(ctx))} → ${TranslateHelper.labelFor(TranslateModePrefs.target(ctx))}"
                }
            }
        }
        trBtns.addView(srcBtn); trBtns.addView(tgtBtn); trBtns.addView(toggleTr)
        trRow.addView(trLabel); trRow.addView(trStatus)
        col.addView(trRow); col.addView(trBtns); col.addView(spacer(28))
        refreshers.add{
            val active=TranslateModePrefs.isActive(ctx)
            trStatus.text=if(active)
                "Actif : ${TranslateHelper.labelFor(TranslateModePrefs.source(ctx))} → ${TranslateHelper.labelFor(TranslateModePrefs.target(ctx))}"
            else "Inactif"
            toggleTr.text = if (active) "Arrêter" else "Activer"
        }

        col.addView(spacer(28))

        // --- Bouton mascotte flottant (déclenchement manuel, plus fiable que le mot de réveil) ---
        col.addView(sectionTitle("VOIX DE L'IA"))
        val voiceCard = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            background = UiKit.card(ctx)
        }
        val voiceHint = TextView(ctx).apply {
            text = "Débit, hauteur et voix française du moteur TTS de ton téléphone."
            setTextColor(UiKit.TEXT_MUTED); textSize = 11f; setPadding(0, 0, 0, 12)
        }
        voiceCard.addView(voiceHint)

        // Débit
        val rateLabel = TextView(ctx).apply {
            text = "Débit : ${"%.1f".format(VoicePrefs.getRate(ctx))}"
            setTextColor(UiKit.BLACK); textSize = 13f
        }
        val rateBar = SeekBar(ctx).apply {
            max = 15 // 0.5 .. 2.0 step 0.1
            progress = ((VoicePrefs.getRate(ctx) - 0.5f) * 10f).toInt().coerceIn(0, 15)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val r = 0.5f + p / 10f
                    rateLabel.text = "Débit : ${"%.1f".format(r)}"
                    if (fromUser) VoicePrefs.setRate(ctx, r)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        voiceCard.addView(rateLabel); voiceCard.addView(rateBar)

        // Hauteur
        val pitchLabel = TextView(ctx).apply {
            text = "Hauteur : ${"%.1f".format(VoicePrefs.getPitch(ctx))}"
            setTextColor(UiKit.BLACK); textSize = 13f; setPadding(0, 12, 0, 0)
        }
        val pitchBar = SeekBar(ctx).apply {
            max = 15
            progress = ((VoicePrefs.getPitch(ctx) - 0.5f) * 10f).toInt().coerceIn(0, 15)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val r = 0.5f + p / 10f
                    pitchLabel.text = "Hauteur : ${"%.1f".format(r)}"
                    if (fromUser) VoicePrefs.setPitch(ctx, r)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        voiceCard.addView(pitchLabel); voiceCard.addView(pitchBar)

        // Voix installées
        val voiceListLabel = TextView(ctx).apply {
            text = "Voix française : chargement…"
            setTextColor(UiKit.BLACK); textSize = 13f; setPadding(0, 14, 0, 6)
        }
        voiceCard.addView(voiceListLabel)
        val voiceButtons = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
        }
        voiceCard.addView(voiceButtons)

        // TTS temporaire pour lister + tester
        var previewTts: TextToSpeech? = null
        previewTts = TextToSpeech(ctx.applicationContext) { status ->
            if (status != TextToSpeech.SUCCESS) {
                voiceListLabel.text = "Voix : moteur TTS indisponible"
                return@TextToSpeech
            }
            VoicePrefs.apply(ctx, previewTts)
            val voices = VoicePrefs.listFrenchVoices(previewTts)
            val current = VoicePrefs.getVoiceName(ctx)
            if (voices.isEmpty()) {
                voiceListLabel.text = "Aucune voix FR listée — la voix système par défaut sera utilisée."
            } else {
                voiceListLabel.text = "Choisis une voix (${voices.size} disponible(s)) :"
                voiceButtons.removeAllViews()
                // Option défaut
                val defBtn = Button(ctx).apply {
                    text = if (current.isBlank()) "• Défaut système" else "Défaut système"
                    textSize = 11f; background = UiKit.pill(ctx); setTextColor(UiKit.BLACK)
                    setOnClickListener {
                        VoicePrefs.setVoiceName(ctx, "")
                        VoicePrefs.apply(ctx, previewTts)
                        previewTts?.speak("Bonjour, je suis Vanelle.", TextToSpeech.QUEUE_FLUSH, null, "preview")
                        Toast.makeText(ctx, "Voix par défaut", Toast.LENGTH_SHORT).show()
                    }
                }
                voiceButtons.addView(defBtn)
                for (v in voices.take(8)) {
                    val label = VoicePrefs.labelFor(v)
                    val selected = v.name == current
                    val b = Button(ctx).apply {
                        text = if (selected) "• $label" else label
                        textSize = 10f; background = UiKit.pill(ctx)
                        setTextColor(if (selected) UiKit.BLACK else UiKit.BLACK)
                        setOnClickListener {
                            VoicePrefs.setVoiceName(ctx, v.name)
                            VoicePrefs.apply(ctx, previewTts)
                            previewTts?.speak("Bonjour, je suis Vanelle.", TextToSpeech.QUEUE_FLUSH, null, "preview")
                            Toast.makeText(ctx, "Voix sélectionnée", Toast.LENGTH_SHORT).show()
                        }
                    }
                    voiceButtons.addView(b)
                }
            }
        }

        val testBtn = Button(ctx).apply {
            text = "Tester la voix"
            textSize = 12f; background = UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            setOnClickListener {
                try {
                    if (previewTts == null) {
                        Toast.makeText(ctx, "Moteur TTS en cours de chargement…", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    VoicePrefs.apply(ctx, previewTts)
                    val prenom = RelationalMemory(ctx).displayName()
                    val sample = if (prenom.isNotBlank()) "$prenom, bonjour, je suis Vanelle."
                    else "Bonjour, je suis Vanelle."
                    previewTts?.speak(sample, TextToSpeech.QUEUE_FLUSH, null, "preview")
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Test impossible : ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
        voiceCard.addView(testBtn)
        col.addView(voiceCard); col.addView(spacer(28))

        col.addView(sectionTitle("BOUTON MASCOTTE"))
        val floatRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,20,24,20); background=UiKit.card(ctx)}
        val floatLabel=TextView(ctx).apply{
            text="Mascotte flottante : clique dessus pour activer le micro"
            setTextColor(UiKit.BLACK); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)
        }
        val floatSw=Switch(ctx).apply{
            isChecked = FloatingMascotButton.isEnabled(ctx)
            setOnCheckedChangeListener{ sw, checked ->
                if (checked && !OverlayHelper.canDraw(ctx)) {
                    sw.isChecked = false
                    AlertDialog.Builder(ctx)
                        .setTitle("Autorisation nécessaire")
                        .setMessage("Pour afficher le bouton par-dessus les autres applis, autorise Vanelle OS dans les réglages système qui vont s'ouvrir.")
                        .setPositiveButton("Ouvrir les réglages"){_,_-> OverlayHelper.requestPermission(ctx) }
                        .setNegativeButton("Annuler",null)
                        .show()
                    return@setOnCheckedChangeListener
                }
                FloatingMascotButton.setEnabled(ctx, checked)
                Toast.makeText(ctx, if(checked) "Bouton mascotte activé" else "Bouton mascotte désactivé", Toast.LENGTH_SHORT).show()
            }
        }
        floatRow.addView(floatLabel); floatRow.addView(floatSw)
        col.addView(floatRow)

        // Curseur de taille (réagit tout de suite si le bouton est déjà affiché)
        val sizeCol = LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,16,24,16); background=UiKit.card(ctx)}
        val sizeLabel = TextView(ctx).apply{
            text = "Taille du bouton : ${FloatingMascotButton.getSizeDp(ctx)} dp"
            setTextColor(UiKit.BLACK); textSize=13f
        }
        val sizeBar = SeekBar(ctx).apply{
            max = FloatingMascotButton.MAX_SIZE_DP - FloatingMascotButton.MIN_SIZE_DP
            progress = FloatingMascotButton.getSizeDp(ctx) - FloatingMascotButton.MIN_SIZE_DP
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean){
                    val sizeDp = FloatingMascotButton.MIN_SIZE_DP + p
                    sizeLabel.text = "Taille du bouton : $sizeDp dp"
                    if (fromUser) FloatingMascotButton.setSizeDp(ctx, sizeDp)
                }
                override fun onStartTrackingTouch(sb: SeekBar?){}
                override fun onStopTrackingTouch(sb: SeekBar?){}
            })
        }
        sizeCol.addView(sizeLabel); sizeCol.addView(sizeBar)
        col.addView(sizeCol); col.addView(spacer(28))

        // --- Sauvegarde / changement de téléphone ---
        col.addView(sectionTitle("SAUVEGARDE & CHANGEMENT DE TELEPHONE"))
        val backupInfo = TextView(ctx).apply {
            text = "Active la sauvegarde Google pour retrouver mémoire, relances et préférences après réinstallation. Pour un autre téléphone : exporte le fichier puis importe-le ici."
            setTextColor(UiKit.TEXT_MUTED); textSize = 12f; setPadding(24, 18, 24, 12); background = UiKit.card(ctx)
        }
        col.addView(backupInfo); col.addView(spacer(8))

        val sysBackupBtn = Button(ctx).apply {
            text = "Activer la sauvegarde systeme"
            textSize = 12f
            background = UiKit.pill(ctx)
            setTextColor(UiKit.BLACK)
            setOnClickListener {
                try { UserDataSnapshot.save(ctx) } catch (_: Exception) {}
                val landedOnToggle = UserDataSnapshot.openSystemBackupSettings(ctx)
                if (landedOnToggle) {
                    Toast.makeText(ctx, "Active le bouton \u00ab Sauvegarder sur Google Drive \u00bb en haut de l'écran", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(ctx, "Depuis les réglages : Système puis Sauvegarde, et active \u00ab Sauvegarder sur Google Drive \u00bb", Toast.LENGTH_LONG).show()
                }
            }
        }
        col.addView(sysBackupBtn); col.addView(spacer(8))

        val exportBtn = Button(ctx).apply {
            text = "Exporter mes donnees"
            textSize = 12f
            background = UiKit.pill(ctx)
            setTextColor(UiKit.BLACK)
            setOnClickListener {
                try {
                    val intent = UserDataSnapshot.shareIntent(ctx)
                    startActivity(Intent.createChooser(intent, "Exporter la sauvegarde VanelleOS"))
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Export impossible : ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        col.addView(exportBtn); col.addView(spacer(8))

        val importBtn = Button(ctx).apply {
            text = "Importer mes donnees"
            textSize = 12f
            background = UiKit.pill(ctx)
            setTextColor(UiKit.BLACK)
            setOnClickListener {
                try {
                    importLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Import impossible : ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        col.addView(importBtn); col.addView(spacer(28))

        sv.addView(col); return sv
    }
    override fun onResume(){ super.onResume(); refreshers.forEach{ it() } }
}


/**
 * Catalogue des fonctions REELLES uniquement (handlers implementes).
 * Section Sans IA = executable pendant telechargement modele.
 */

/**
 * Catalogue des fonctions reelles — exemples clairs a dire a la mascotte.
 * Pas de boutons Tester : la voix (mascotte) execute, meme sans IA chargee.
 */
class FeaturesFragment : Fragment() {
    private var readinessBanner: View? = null
    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val d = ctx.resources.displayMetrics.density
        val sv = ScrollView(ctx).apply { setBackgroundColor(UiKit.WHITE) }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((22 * d).toInt(), (24 * d).toInt(), (22 * d).toInt(), (28 * d).toInt())
        }
        fun spacer(h: Int) = View(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(-1, (h * d).toInt())
        }
        fun h(title: String) = TextView(ctx).apply {
            text = title
            setTextColor(0xFF050708.toInt())
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, (8 * d).toInt(), 0, (10 * d).toInt())
        }

        val aiReady = try { DataDownloadService.isUsable(ctx) } catch (_: Exception) { false }
        val banner = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * d).toInt(), (14 * d).toInt(), (16 * d).toInt(), (14 * d).toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(if (aiReady) 0xFFDDF7F8.toInt() else 0xFFF4FCFD.toInt())
                cornerRadius = 12f * d
            }
        }
        banner.addView(TextView(ctx).apply {
            text = if (aiReady) "IA prete" else "IA pas encore prete"
            setTextColor(if (aiReady) 0xFF00545C.toInt() else 0xFF00545C.toInt())
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        banner.addView(TextView(ctx).apply {
            text = if (aiReady)
                "Parle a la mascotte pour n'importe quelle fonction."
            else
                "Parle a la mascotte pour les actions Sans IA. " +
                    "Si tu demandes du chat libre, elle te dira que l'IA n'est pas prete."
            setTextColor(UiKit.TEXT_MUTED)
            textSize = 12f
            setPadding(0, (6 * d).toInt(), 0, 0)
        })
        readinessBanner = banner
        if (aiReady) banner.visibility = View.GONE
        col.addView(banner)
        col.addView(spacer(14))

        data class Feat(val title: String, val examples: String, val detail: String)

        val offline = listOf(
            Feat("Batterie", "« Batterie »  ·  « Quel est mon niveau de batterie »", "Annonce le pourcentage de charge"),
            Feat("Lampe torche", "« Allume la lampe »  ·  « Eteins la lampe »", "Active / coupe le flash"),
            Feat("Volume", "« Monte le volume »  ·  « Baisse le volume »", "Regle le volume multimedia"),
            Feat("Mode sonnerie", "« Mode silencieux »  ·  « Mets en vibreur »  ·  « Reactive le son »", "Necessite l'acces Ne pas deranger (Configuration)"),
            Feat("Ouvrir une app", "« Ouvre Spotify »  ·  « Ouvre la calculatrice »  ·  « Ouvre WhatsApp »", "Lance l'application par son nom"),
            Feat("Camera", "« Ouvre la camera »  ·  « Prends une photo »", "Ouvre l'appareil photo"),
            Feat("Galerie", "« Ouvre la galerie »  ·  « Montre mes photos »", "Ouvre la galerie photos"),
            Feat("YouTube / recherche", "« Ouvre YouTube et joue Stromae »  ·  « Cherche cette vidéo sur YouTube »", "Compréhension de commande sans modèle IA ; la recherche en ligne nécessite Internet"),
            Feat("Maps / Navigation", "« Navigue vers Paris »  ·  « Maps Tour Eiffel »", "Ouvre Google Maps"),
            Feat("Recherche web", "« Cherche meteo demain »  ·  « Cherche actualites France »", "Recherche Internet — sans modèle IA, mais connexion Internet requise"),
            Feat("Lien web", "« Ouvre https://wikipedia.org »", "Ouvre une URL"),
            Feat("Appeler", "« Appelle Maman »  ·  « Appelle Paul »", "Confirmation puis appel (permission)"),
            Feat("SMS", "« Envoie un message a Paul texte j'arrive »", "SMS apres confirmation (permission)"),
            Feat("Urgence", "« Urgence »", "Compose le 112"),
            Feat("Telephone perdu", "« Retrouve mon telephone »", "Alarme forte + vibration"),
            Feat("Presse-papiers", "« Lis le presse-papiers »", "Lit le texte copie"),
            Feat("Minuteur", "« Minuteur 5 minutes »  ·  « Timer 10 minutes »", "Lance un minuteur systeme"),
            Feat("Partager", "« Partage le texte bonjour a tous »", "Menu de partage Android"),
            Feat("Traduction en ligne", "« Traduis hello how are you »", "Sans modèle IA local, mais Internet requis pour le service de traduction"),
            Feat("Memoire — sauver", "« Retiens que mon code wifi est abcd1234 »", "Note stockee sur le telephone"),
            Feat("Memoire — rappeler", "« Rappelle-moi mon code wifi »", "Relit une note sauvee"),
            Feat("Retour / Accueil", "« Retour »  ·  « Accueil »", "Accessibilite Vanelle requise"),
            Feat("Lire l'ecran", "« Lis l'ecran »", "Lit le texte visible (accessibilite)"),
            Feat("Journal", "« Journal d'activite »", "Dernieres actions Vanelle"),
            Feat("Confidentialite", "« Statut confidentialite »", "Etat du pare-feu privacy")
        )

        val withAi = listOf(
            Feat("Conversation libre", "« Explique la photosynthese »  ·  « Donne-moi 3 idees de diner »", "Réponse conversationnelle et raisonnement avec le modèle IA local"),
            Feat("Resume d'ecran", "« Resume l'ecran »", "Lecture d'écran + interprétation par le modèle IA local"),
            Feat("Compréhension avancée", "« Fais ce que je viens de te demander en tenant compte de notre discussion »", "Compréhension du contexte, raisonnement et génération avec le modèle IA local")
        )

        fun addCard(feat: Feat) {
            val card = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((16 * d).toInt(), (14 * d).toInt(), (16 * d).toInt(), (14 * d).toInt())
                background = UiKit.card(ctx)
            }
            card.addView(TextView(ctx).apply {
                text = feat.title
                setTextColor(0xFF050708.toInt())
                textSize = 13.5f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            card.addView(TextView(ctx).apply {
                text = "Dis a la mascotte :\n${feat.examples}"
                setTextColor(0xFF050708.toInt())
                textSize = 12.5f
                setPadding(0, (8 * d).toInt(), 0, 0)
                setLineSpacing(0f, 1.15f)
            })
            card.addView(TextView(ctx).apply {
                text = feat.detail
                setTextColor(UiKit.TEXT_MUTED)
                textSize = 11.5f
                setPadding(0, (6 * d).toInt(), 0, 0)
            })
            col.addView(card)
            col.addView(spacer(8))
        }

        col.addView(h("Sans modèle IA — logique système"))
        col.addView(TextView(ctx).apply {
            text = "Fonctionne pendant le téléchargement. Certaines fonctions (traduction/recherche) nécessitent Internet."
            setTextColor(UiKit.TEXT_MUTED)
            textSize = 11.5f
            setPadding(0, 0, 0, (8 * d).toInt())
        })
        for (x in offline) addCard(x)

        col.addView(spacer(8))
        col.addView(h("Avec modèle IA — modèle chargé"))
        col.addView(TextView(ctx).apply {
            text = "Si le modele n'est pas pret, la mascotte le dira en une phrase courte."
            setTextColor(UiKit.TEXT_MUTED)
            textSize = 11.5f
            setPadding(0, 0, 0, (8 * d).toInt())
        })
        for (x in withAi) addCard(x)

        sv.addView(col)
        return sv
    }
    override fun onResume() {
        super.onResume()
        if (try { DataDownloadService.isUsable(requireContext()) } catch (_: Exception) { false }) {
            readinessBanner?.visibility = View.GONE
        }
    }

}

class RelanceFragment:Fragment(){
    private var rebuildUi: (() -> Unit)? = null

    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val root=FrameLayout(ctx).apply{setBackgroundColor(UiKit.WHITE)}
        fun rebuild(){
            root.removeAllViews()
            val sv=ScrollView(ctx).apply{setBackgroundColor(UiKit.WHITE)}
            val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(28,32,28,32)}
            fun sectionTitle(t:String)=TextView(ctx).apply{text=t; setTextColor(UiKit.TEXT_MUTED); textSize=11f; letterSpacing=0.1f; setPadding(4,0,0,10)}
            fun spacer(h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,h)}
            val fmt=java.text.SimpleDateFormat("dd/MM HH:mm",java.util.Locale.FRANCE)
            val repo=RelanceRepository(ctx)

            col.addView(sectionTitle("A VENIR"))
            val tasks=repo.getTasks()
            if(tasks.isEmpty()) col.addView(TextView(ctx).apply{text="Aucune relance programmee. Dis : Rappelle-moi d'appeler Paul a 18h30"; setTextColor(UiKit.TEXT_MUTED); textSize=12f; setPadding(24,16,24,16)})
            for(task in tasks){
                val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
                val displayDesc=if(task.description.startsWith("routine:")) task.description.substringAfter("|",task.description) else task.description
                val label=TextView(ctx).apply{
                    text="$displayDesc\n${task.hour.toString().padStart(2,'0')}h${task.minute.toString().padStart(2,'0')}${if(task.repeatDaily) " - tous les jours" else " - une fois"}"
                    setTextColor(UiKit.BLACK); textSize=12f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)
                }
                val delBtn=Button(ctx).apply{
                    text="Supprimer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(UiKit.DANGER)
                    setOnClickListener{
                        try {
                            AlarmScheduler.cancel(ctx, task.id)
                            repo.removeTask(task.id)
                            android.widget.Toast.makeText(ctx, "Relance supprimee", android.widget.Toast.LENGTH_SHORT).show()
                        } catch (_:Exception) {}
                        rebuild()
                    }
                }
                row.addView(label); row.addView(delBtn)
                col.addView(row); col.addView(spacer(8))
            }
            col.addView(spacer(28))

            col.addView(sectionTitle("HISTORIQUE"))
            val history=repo.getHistory()
            if(history.isEmpty()) col.addView(TextView(ctx).apply{text="Aucune relance executee pour le moment."; setTextColor(UiKit.TEXT_MUTED); textSize=12f; setPadding(24,16,24,16)})
            for(h in history.take(30)){
                val row=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,16,24,16); background=UiKit.card(ctx)}
                val labelTop=TextView(ctx).apply{text=h.description; setTextColor(UiKit.BLACK); textSize=12f}
                val labelBottom=TextView(ctx).apply{text="${fmt.format(java.util.Date(h.executedAt))} - ${h.result}"; setTextColor(UiKit.TEXT_MUTED); textSize=10f; setPadding(0,4,0,0)}
                row.addView(labelTop); row.addView(labelBottom)
                col.addView(row); col.addView(spacer(8))
            }
            sv.addView(col)
            root.addView(sv)
        }
        rebuildUi = { rebuild() }
        rebuild()
        return root
    }
    override fun onResume(){
        super.onResume()
        rebuildUi?.invoke()
    }
}

/**
 * Chat texte avec Vanelle — même historique que la mascotte vocale.
 */
/**
 * Conversation : chat actif + historique organisé (dossiers, tags, recherche).
 */
/**
 * Conversation — interface type chat moderne (fil + saisie bas).
 */
/**
 * Conversation — interface type Grok :
 * fond clair, messages assistant à gauche, utilisateur à droite,
 * grande zone de saisie en bas, historique accessible.
 */
class ChatFragment : Fragment() {
    private var listCol: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var inputBar: View? = null
    private var modeHistory = false
    private var thinkingView: LinearLayout? = null
    private var thinkingAnimator: android.animation.Animator? = null
    private var thinkingPulse: Runnable? = null
    private var thinkingStage: String = "Vanelle travaille"
    private var attachedName: String? = null
    private var attachedText: String? = null

    private val filePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        val ctx = requireContext()
        attachedName = try {
            var name: String? = null
            ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cur ->
                if (cur.moveToFirst()) name = cur.getString(0)
            }
            name ?: "fichier"
        } catch (_: Exception) { "fichier" }
        attachedText = try {
            val mime = ctx.contentResolver.getType(uri).orEmpty().lowercase()
            val nameLower = (attachedName ?: "fichier").lowercase()
            val isText = mime.startsWith("text/") || mime.contains("json") || mime.contains("xml") ||
                mime.contains("javascript") || mime.contains("kotlin") || mime.contains("markdown") ||
                nameLower.endsWith(".txt") || nameLower.endsWith(".md") ||
                nameLower.endsWith(".csv") || nameLower.endsWith(".json") ||
                nameLower.endsWith(".xml") || nameLower.endsWith(".kt") ||
                nameLower.endsWith(".java") || nameLower.endsWith(".py")
            if (isText) ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText().take(16000) } else null
        } catch (_: Exception) { null }
        Toast.makeText(ctx, if (attachedText != null) "Fichier ajouté : $attachedName" else "Fichier ajouté : $attachedName", Toast.LENGTH_SHORT).show()
        refresh(requireContext())
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val d = ctx.resources.displayMetrics.density
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(UiKit.WHITE)
        }

        // Aucun bandeau « Nouvelle conversation » : historique et nouvelle conversation
        // sont regroupés dans le menu à trois traits.
        val menuRow = FrameLayout(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(-1, (52 * d).toInt())
            setBackgroundColor(UiKit.WHITE)
            setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
        }
        val menuBtn = TextView(ctx).apply {
            text = "☰"
            gravity = android.view.Gravity.CENTER
            textSize = 23f
            setTextColor(UiKit.TEXT_DARK)
            background = UiKit.pill(ctx)
            setPadding((12 * d).toInt(), 0, (12 * d).toInt(), 0)
        }
        val mp = FrameLayout.LayoutParams((50 * d).toInt(), (42 * d).toInt()).apply {
            gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
        }
        menuRow.addView(menuBtn, mp)
        root.addView(menuRow)

        val sv = ScrollView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            isFillViewport = true
            setBackgroundColor(UiKit.WHITE)
            isVerticalScrollBarEnabled = false
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((18 * d).toInt(), (4 * d).toInt(), (18 * d).toInt(), (24 * d).toInt())
        }
        listCol = col
        scroll = sv
        sv.addView(col)
        root.addView(sv)

        val bottom = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (12 * d).toInt())
            setBackgroundColor(UiKit.WHITE)
        }
        inputBar = bottom
        val inputWrap = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.BOTTOM
            setPadding((4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFFF4FCFD.toInt())
                cornerRadius = 28f * d
                setStroke((1 * d).toInt(), 0xFFC8E9EC.toInt())
            }
        }
        val plus = TextView(ctx).apply {
            text = "+"
            gravity = android.view.Gravity.CENTER
            setTextColor(UiKit.TEXT_DARK)
            textSize = 25f
            layoutParams = LinearLayout.LayoutParams((42 * d).toInt(), (48 * d).toInt())
            setOnClickListener {
                filePicker.launch(arrayOf("*/*"))
            }
        }
        val input = EditText(ctx).apply {
            hint = "Message Vanelle"
            setTextColor(0xFF050708.toInt())
            setHintTextColor(0xFF53636A.toInt())
            textSize = 15f
            minLines = 1
            maxLines = 6
            background = null
            setPadding((8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val send = TextView(ctx).apply {
            text = "↑"
            gravity = android.view.Gravity.CENTER
            setTextColor(UiKit.WHITE)
            textSize = 16f
            val sz = (36 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (6 * d).toInt(); bottomMargin = (4 * d).toInt() }
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(UiKit.ACCENT)
            }
        }
        val stop = TextView(ctx).apply {
            text = "■"
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFF00545C.toInt())
            textSize = 14f
            visibility = View.GONE
            val sz = (36 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (6 * d).toInt(); bottomMargin = (4 * d).toInt() }
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xFFE8F1F2.toInt())
            }
            setOnClickListener { LocalLlamaHelper.get(ctx).stopGeneration() }
        }

        fun doSend() {
            if (modeHistory) return
            val msg = input.text?.toString()?.trim().orEmpty()
            if (msg.isBlank() && attachedName == null) return
            val fileName = attachedName
            val fileText = attachedText
            input.setText("")
            attachedName = null
            attachedText = null
            val shown = if (fileName != null) {
                if (msg.isBlank()) "📎 $fileName" else "$msg\n📎 $fileName"
            } else msg
            ChatHistory.add(ctx, "user", shown, alsoRelational = false)
            appendBubble(ctx, col, "user", shown)
            scrollToBottom()
            send.isEnabled = false
            send.visibility = View.GONE
            stop.visibility = View.VISIBLE
            showThinking(ctx, col)
            val prompt = if (fileText != null) {
                "$msg\n\n[Fichier joint : $fileName]\n$fileText"
            } else if (fileName != null) {
                "$msg\n\n[Fichier joint : $fileName. Le contenu de ce type de fichier n'est pas directement lisible par le moteur local.]"
            } else msg
            viewLifecycleOwner.lifecycleScope.launch {
                val engine = CommandInterpreter(ctx)
                val result = try {
                    engine.executeDetailed(prompt) { stage ->
                        requireActivity().runOnUiThread { updateThinkingStage(stage) }
                    }
                } catch (e: Exception) {
                    CommandInterpreter.ExecutionResult("Je n'ai pas pu terminer cette demande. Cause : ${e.javaClass.simpleName}.")
                }
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    removeThinking()
                    ChatHistory.add(ctx, "assistant", result.answer, alsoRelational = false)
                    if (result.reasoningSummary.isNotBlank()) ChatHistory.setLastAssistantReasoning(ctx, result.reasoningSummary)
                    appendBubble(ctx, col, "assistant", result.answer, result.reasoningSummary)
                    scrollToBottom()
                    send.isEnabled = true
                    send.visibility = View.VISIBLE
                    stop.visibility = View.GONE
                }
            }
        }
        send.setOnClickListener { doSend() }
        inputWrap.addView(plus)
        inputWrap.addView(input)
        inputWrap.addView(send)
        inputWrap.addView(stop)
        bottom.addView(inputWrap)
        root.addView(bottom)

        fun showMenu() {
            val popup = PopupWindow(ctx).apply {
                isFocusable = true
                elevation = 12f
                setBackgroundDrawable(android.graphics.drawable.ColorDrawable(UiKit.WHITE))
            }
            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
            }
            fun item(label: String, click: () -> Unit) {
                box.addView(TextView(ctx).apply {
                    text = label
                    textSize = 15f
                    setTextColor(UiKit.TEXT_DARK)
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    setPadding((16 * d).toInt(), (14 * d).toInt(), (42 * d).toInt(), (14 * d).toInt())
                    setOnClickListener { popup.dismiss(); click() }
                })
            }
            item("Historique") { modeHistory = true; refresh(ctx) }
            item("Nouvelle conversation") { ChatHistory.newThread(ctx); modeHistory = false; refresh(ctx) }
            popup.contentView = box
            popup.width = (230 * d).toInt()
            popup.height = -2
            popup.showAsDropDown(menuBtn, (4 * d).toInt(), 0, android.view.Gravity.START)
        }
        menuBtn.setOnClickListener { showMenu() }
        refresh(ctx)
        return root
    }

    override fun onResume() {
        super.onResume()
        refresh(requireContext())
    }

    private fun refresh(ctx: android.content.Context) {
        val col = listCol ?: return
        col.removeAllViews()
        thinkingView = null
        inputBar?.visibility = if (modeHistory) View.GONE else View.VISIBLE
        if (modeHistory) {
            showHistory(ctx, col)
            return
        }
        val msgs = ChatHistory.messages(ctx)
        if (msgs.isEmpty()) {
            val empty = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER_HORIZONTAL
                setPadding(24, 80, 24, 24)
            }
            val mascot = ImageView(ctx).apply {
                val size = (96 * ctx.resources.displayMetrics.density).toInt()
                layoutParams = LinearLayout.LayoutParams(size, size).apply { bottomMargin = 12 }
                scaleType = ImageView.ScaleType.FIT_CENTER
                try { setImageResource(MascotManager.getDrawableId(ctx, MascotManager.getSelected(ctx))) } catch (_: Exception) {}
            }
            empty.addView(mascot)
            empty.addView(TextView(ctx).apply {
                text = "Que veux-tu faire aujourd’hui ?"
                setTextColor(UiKit.TEXT_MUTED)
                textSize = 16f
                gravity = android.view.Gravity.CENTER
            })
            col.addView(empty)
        } else {
            for (m in msgs) appendBubble(ctx, col, m.role, m.text, m.reasoning)
        }
        scrollToBottom()
    }

    private fun showHistory(ctx: android.content.Context, col: LinearLayout) {
        val d = ctx.resources.displayMetrics.density
        val close = TextView(ctx).apply {
            text = "←  Retour à la conversation"
            textSize = 14f
            setTextColor(UiKit.TEXT_MUTED)
            setPadding(0, 0, 0, (12 * d).toInt())
            setOnClickListener { modeHistory = false; refresh(ctx) }
        }
        col.addView(close)
        val search = EditText(ctx).apply {
            hint = "Rechercher dans l'historique"
            setTextColor(0xFF050708.toInt())
            setHintTextColor(0xFF53636A.toInt())
            textSize = 14f
            setPadding((16 * d).toInt(), (12 * d).toInt(), (16 * d).toInt(), (12 * d).toInt())
            background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFFF4FCFD.toInt()); cornerRadius = 16f * d }
        }
        col.addView(search)
        val host = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        col.addView(host)
        fun rebuild() {
            host.removeAllViews()
            val q = search.text?.toString().orEmpty()
            val threads = if (q.isNotBlank()) ChatHistory.search(ctx, q) else ChatHistory.allThreads(ctx)
            if (threads.isEmpty()) {
                host.addView(TextView(ctx).apply { text = "Aucune conversation"; setTextColor(0xFF53636A.toInt()); setPadding(8, 24, 8, 8) })
                return
            }
            for (th in threads) {
                host.addView(TextView(ctx).apply {
                    text = th.title.ifBlank { "Sans titre" }
                    setTextColor(0xFF050708.toInt())
                    textSize = 14f
                    setPadding((14 * d).toInt(), (14 * d).toInt(), (14 * d).toInt(), (14 * d).toInt())
                    background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFFFFFFFF.toInt()); cornerRadius = 12f * d }
                    setOnClickListener { ChatHistory.setActive(ctx, th.id); modeHistory = false; refresh(ctx) }
                }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = (8 * d).toInt() })
            }
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { rebuild() }
        })
        rebuild()
    }

    private fun showThinking(ctx: android.content.Context, col: LinearLayout) {
        removeThinking()
        val d = ctx.resources.displayMetrics.density
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, (8 * d).toInt(), 0, (10 * d).toInt())
        }
        val mascot = ImageView(ctx).apply {
            val size = (44 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(size, size).apply { rightMargin = (10 * d).toInt() }
            scaleType = ImageView.ScaleType.FIT_CENTER
            try { setImageResource(MascotManager.getDrawableId(ctx, MascotManager.getSelected(ctx))) } catch (_: Exception) {}
        }
        val text = TextView(ctx).apply {
            setTextColor(UiKit.TEXT_MUTED)
            textSize = 13f
            text = "Vanelle travaille…"
        }
        row.addView(mascot)
        row.addView(text)
        col.addView(row)
        thinkingView = row
        thinkingStage = "Analyse de la demande"

        // Indicateur visuel honnête : il signifie seulement que le moteur traite la demande.
        // Il ne prétend pas afficher la chaîne de pensée interne du modèle.
        val pulse = object : Runnable {
            var phase = 0
            override fun run() {
                if (thinkingView !== row) return
                val dots = when (phase % 4) {
                    0 -> ""
                    1 -> " ·"
                    2 -> " ··"
                    else -> " ···"
                }
                text.text = thinkingStage + dots
                phase++
                row.postDelayed(this, 320L)
            }
        }
        thinkingPulse = pulse
        row.post(pulse)

        thinkingAnimator = android.animation.ObjectAnimator.ofPropertyValuesHolder(
            mascot,
            android.animation.PropertyValuesHolder.ofFloat("scaleX", 1f, 1.05f, 1f),
            android.animation.PropertyValuesHolder.ofFloat("scaleY", 1f, 1.05f, 1f)
        ).apply {
            duration = 700L
            repeatCount = android.animation.ValueAnimator.INFINITE
            start()
        }
        scrollToBottom()
    }

    private fun updateThinkingStage(stage: String) {
        val row = thinkingView ?: return
        val tv = row.getChildAt(1) as? TextView ?: return
        thinkingStage = stage
        tv.text = stage
        scrollToBottom()
    }

    private fun removeThinking() {
        thinkingPulse?.let { thinkingView?.removeCallbacks(it) }
        thinkingPulse = null
        thinkingAnimator?.cancel()
        thinkingAnimator = null
        thinkingView?.let { (it.parent as? ViewGroup)?.removeView(it) }
        thinkingView = null
        thinkingStage = "Vanelle travaille"
    }

    private fun appendBubble(ctx: android.content.Context, col: LinearLayout, role: String, text: String, reasoning: String = "") {
        val d = ctx.resources.displayMetrics.density
        val isUser = role.equals("user", true)
        if (isUser) {
            val block = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = android.view.Gravity.END; setPadding((48 * d).toInt(), (6 * d).toInt(), 0, (6 * d).toInt()) }
            val bubble = TextView(ctx).apply {
                this.text = text
                setTextColor(UiKit.WHITE)
                textSize = 15f
                setTextIsSelectable(true)
                setPadding((16 * d).toInt(), (12 * d).toInt(), (16 * d).toInt(), (12 * d).toInt())
                background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFF050708.toInt()); cornerRadius = 20f * d }
            }
            block.addView(bubble)
            val copy = TextView(ctx).apply {
                this.text = "Copier"
                setTextColor(UiKit.TEXT_MUTED)
                textSize = 11.5f
                setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
                setOnClickListener {
                    val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("Vanelle", text))
                    Toast.makeText(ctx, "Texte copié", Toast.LENGTH_SHORT).show()
                }
            }
            block.addView(copy)
            col.addView(block)
        } else {
            val block = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, (10 * d).toInt(), (24 * d).toInt(), (10 * d).toInt()) }
            block.addView(TextView(ctx).apply { this.text = "Vanelle"; setTextColor(0xFF27343A.toInt()); textSize = 12f; setPadding(0, 0, 0, (4 * d).toInt()) })
            if (reasoning.isNotBlank()) {
                val reason = TextView(ctx).apply {
                    this.text = "Afficher la réflexion"
                    setTextColor(UiKit.TEXT_MUTED)
                    textSize = 11.5f
                    setPadding((8 * d).toInt(), (5 * d).toInt(), (8 * d).toInt(), (5 * d).toInt())
                    background = UiKit.pill(ctx)
                }
                val detail = TextView(ctx).apply {
                    this.text = "Résumé des éléments pris en compte :\n$reasoning"
                    setTextColor(UiKit.TEXT_MUTED)
                    textSize = 12.5f
                    setLineSpacing(0f, 1.2f)
                    setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
                    visibility = View.GONE
                    background = UiKit.card(ctx)
                }
                reason.setOnClickListener { detail.visibility = if (detail.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
                block.addView(reason)
                block.addView(detail)
            }
            block.addView(TextView(ctx).apply {
                this.text = text
                setTextColor(UiKit.TEXT_DARK)
                textSize = 15.5f
                setLineSpacing(0f, 1.25f)
                setTextIsSelectable(true)
            })
            val actions = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, (4 * d).toInt(), 0, 0) }
            fun action(label: String, click: () -> Unit): TextView = TextView(ctx).apply {
                this.text = label; setTextColor(UiKit.TEXT_MUTED); textSize = 11.5f
                setPadding((8 * d).toInt(), (5 * d).toInt(), (8 * d).toInt(), (5 * d).toInt())
                background = UiKit.pill(ctx)
                setOnClickListener { click() }
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = (6 * d).toInt() }
            }
            actions.addView(action("Copier") {
                val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Vanelle", text))
                Toast.makeText(ctx, "Réponse copiée", Toast.LENGTH_SHORT).show()
            })
            actions.addView(action("Régénérer") { retryLastMessage() })
            actions.addView(action("Partager") {
                val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, text) }
                ctx.startActivity(android.content.Intent.createChooser(send, "Partager la réponse"))
            })
            actions.addView(action("Supprimer") { ChatHistory.removeLastAssistant(ctx); refresh(ctx) })
            block.addView(actions)
            col.addView(block)
        }
    }

    private fun retryLastMessage() {
        val ctx = requireContext()
        val messages = ChatHistory.messages(ctx)
        val lastUser = messages.lastOrNull { it.role.equals("user", true) } ?: return
        ChatHistory.removeLastAssistant(ctx)
        refresh(ctx)
        val col = listCol ?: return
        showThinking(ctx, col)
        viewLifecycleOwner.lifecycleScope.launch {
            val engine = CommandInterpreter(ctx)
            val result = try { engine.executeDetailed(lastUser.text) } catch (e: Exception) {
                CommandInterpreter.ExecutionResult("Je n'ai pas pu terminer cette demande. Cause : ${e.javaClass.simpleName}.")
            }
            withContext(kotlinx.coroutines.Dispatchers.Main) {
                removeThinking()
                ChatHistory.add(ctx, "assistant", result.answer, alsoRelational = false)
                if (result.reasoningSummary.isNotBlank()) ChatHistory.setLastAssistantReasoning(ctx, result.reasoningSummary)
                refresh(ctx)
            }
        }
    }

    private fun scrollToBottom() {
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }
}
