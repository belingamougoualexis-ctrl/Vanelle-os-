import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vanelle.os"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.vanelle.os"
        // minSdk 24 requis par la dépendance io.github.ljcamargo:llamacpp-kotlin:0.4.0
        // (déclarée sans flavor "legacy" séparé dans ce build unique — un minSdk < 24
        // provoque un échec de fusion de manifeste : "uses-sdk:minSdkVersion 23 cannot be
        // smaller than version 24 declared in library [io.github.ljcamargo:llamacpp-kotlin]").
        minSdk = 24
        targetSdk = 36
        versionCode = 72
        versionName = "2.5.24"
    }


    buildFeatures {
        // Le modèle GGUF reste toujours externe à l'APK.
        buildConfig = false
    }

    // --- Signature release : keystore permanent fourni par le workflow CI via variables
    // d'environnement (voir .github/workflows/android-build.yml), jamais commité dans le dépôt.
    // Si ces variables sont absentes (build local sans les secrets), la release retombe
    // sur la signature debug par défaut plutôt que d'échouer, pour ne pas casser un
    // simple `./gradlew assembleRelease` en local.
    val ksPath = System.getenv("VANELLE_KEYSTORE_PATH")
    val ksPass = System.getenv("VANELLE_KEYSTORE_PASSWORD")
    val ksAlias = System.getenv("VANELLE_KEY_ALIAS")
    val ksKeyPass = System.getenv("VANELLE_KEY_PASSWORD")
    val hasReleaseSigning = !ksPath.isNullOrBlank() && !ksPass.isNullOrBlank() &&
        !ksAlias.isNullOrBlank() && !ksKeyPass.isNullOrBlank()

    signingConfigs {
        if (hasReleaseSigning) {
            create("release") {
                storeFile = file(ksPath!!)
                storePassword = ksPass
                keyAlias = ksAlias
                keyPassword = ksKeyPass
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = if (hasReleaseSigning) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
        debug {
            isMinifyEnabled = false
            // Le modèle GGUF est externe à l'APK. Une mise à jour de l'APK par-dessus
            // l'installation existante conserve le fichier du modèle et évite un nouveau téléchargement.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/*.kotlin_module"
            )
        }
    }

    androidResources {
        noCompress += listOf("tflite", "gguf")
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.18.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.2.0")
    // OCR local réel pour lire les écrans qui n'exposent pas leur texte via l'accessibilité.
    implementation("com.google.mlkit:text-recognition:16.0.1")
    // Le moteur local est unique : pas de variante de test ni de moteur simulé.
    implementation("io.github.ljcamargo:llamacpp-kotlin:0.4.0")
}
