# VanelleLife 1.3.0-ondevice-image

## Image 100 % on-device (léger autant que possible)
- Dépendance `com.google.mediapipe:tasks-vision-image-generator`
- `LocalImageGenerator` (réflexion) + dossier `filesDir/models/image_generator/`
- `ImageGenService` priorise on-device → provider HTTPS → AI Studio → échec honnête
- Hub modèles : entrée « Image on-device » + instructions de conversion MediaPipe

## Installation du modèle (utilisateur)
1. Récupérer SD v1.5 EMA-only
2. Convertir avec le script officiel MediaPipe `convert.py`
3. Copier les bins dans le dossier indiqué par le Hub

Qualité limitée / téléphone récent recommandé. Aucune fausse image générée.
