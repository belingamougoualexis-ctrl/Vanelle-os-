# VanelleLife 1.0.0-production — ajouts pour publication

Ce paquet ajoute les fondations manquantes pour un produit **pro, réel, fonctionnel et prêt publication**, sans prétendre disposer de modèles frontier absents.

## Ajouté

### Légal & RGPD
- `assets/legal/privacy_fr.html` — politique de confidentialité
- `assets/legal/terms_fr.html` — conditions d'utilisation
- `LegalActivity` — affichage WebView offline
- `ConsentStore` — consentement premier lancement + opt-in crash/analytics
- Gate de consentement avant compte / UI principale

### Crash reporting
- `CrashReporter` — handler global, traces locales dans `filesDir/crashes/`, envoi distant **uniquement** si opt-in (hook Sentry/Crashlytics prêt)

### LLM on-device (contrat honnête)
- `OnDeviceLlm` / `NativeModelLlm` / `RuleBasedLlm` / `LlmRouter`
- Jamais de texte inventé si le runtime/modèle manque
- Statut visible dans Info → État LLM

### Base durable
- `AppDatabase` (SQLite) : index mémoire, événements de consentement, métriques locales, schema_meta

### Accessibilité
- `AccessibilityHelper` + contentDescriptions sur boutons clés + live region chat

### Production docs
- `docs/PRODUCTION_CHECKLIST.md`
- `docs/PLAY_STORE.md` (textes fiche store)

### Build
- versionCode **50**, versionName **1.0.0-production**
- dépendance Material Design
- `LegalActivity` déclarée dans le manifeste
- thème nuit (`values-night`)

### Tests
- `ConsentStoreTest`
- `OnDeviceLlmTest`

## Non livré volontairement (infrastructure externe)
- Poids GGUF / ONNX d’un LLM (téléchargement utilisateur)
- Libs natives llama.cpp / MediaPipe LLM (à lier quand le modèle est choisi)
- Backend cloud, marketplace, GPU fleet
- Rewrite UI complète en Jetpack Compose (UI actuelle fonctionnelle)

## Prochaines étapes recommandées
1. Générer le keystore + secrets CI
2. `./gradlew bundleRelease`
3. Remplir Data safety Play Console avec les textes de `docs/PLAY_STORE.md`
4. (Optionnel) Brancher Sentry dans `CrashReporter`
5. (Optionnel) Intégrer un runtime natif + petit modèle
