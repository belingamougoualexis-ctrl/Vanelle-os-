# VanelleLife 1.1.0-light-models

Ajouts demandés (tout sauf backend cloud), en version **légère**.

## Téléchargements in-app (Hub modèles)
- Écran `ModelHubActivity` : télécharger / supprimer / progression
- Catalogue léger uniquement :
  - **MiniLM embeddings INT8** ≈ 23 Mo + tokenizer 1 Mo
  - **Gemma-3 1B IT Q4** ≈ 550 Mo (LLM MediaPipe le plus léger officiel)
- Stockage privé `filesDir/models/`, reprise HTTP Range

## Runtime LLM
- `MediaPipeLlm` (réflexion + dépendance `tasks-genai`)
- `LlmRouter` : MediaPipe si prêt → sinon règles locales
- `ChatEngine` : provider HTTPS → on-device LLM → LocalBrain

## Compose
- BOM Compose + Material3 activés (migration progressive)
- UI principale conservée en Views pour stabilité production

## Crash / Sentry
- `SentryBridge` + DSN configurable dans Info
- Init seulement si opt-in crash + DSN non vide

## Room
- Dépendances `room-runtime` / `room-ktx` ajoutées
- `AppDatabase` SQLite reste la source de vérité (pas de ksp obligatoire)

## Tests instrumentés
- `SmokeInstrumentedTest` (package + catalogue modèles)

## Non inclus (volontairement)
- Backend cloud / marketplace / sync serveur
- Modèles image/vidéo lourds (diffusion)
- Rewrite Compose de tous les écrans
