# Comment fonctionne NOVA / Vanelle

## Idée centrale

Ce n’est **pas** une app de chat branchée à ChatGPT.
Ce sont des **mascottes** (Vanelle) que **toi** tu élèves.

Chaque mascotte :
- a un **nom** que tu choisis
- a une **apparence** (une des 17 images Vanelle)
- a une **voix** (synthèse vocale)
- a sa propre **mémoire**, ses **concepts**, sa **personnalité**

Elle ne « sait » que ce que tu lui apprends.

---

## Architecture (briques)

```
┌─────────────────────────────────────────────┐
│  Toi (texte, micro, corrections)            │
└──────────────────┬──────────────────────────┘
                   ▼
┌─────────────────────────────────────────────┐
│  MainActivity / Bulle flottante             │
│  - UI chat, mascottes, permissions          │
│  - Overlay sur toutes les apps              │
└──────────────────┬──────────────────────────┘
                   ▼
┌─────────────────────────────────────────────┐
│  NovaSession (par mascotte active)          │
│  - MemoryStore      souvenirs               │
│  - LearningStore    expériences + savoirs   │
│  - ConceptStore     concepts formés         │
│  - SemanticMemory   liens entre idées       │
│  - VectorMemory     proximité (hash local)  │
│  - SupervisedStore  corrections             │
│  - DevelopmentEngine observe / consolide    │
│  - LocalBrain       compose la réponse      │
└──────────────────┬──────────────────────────┘
                   ▼
┌─────────────────────────────────────────────┐
│  VoiceEngine + VoiceStore                   │
│  - TTS Android (parle)                      │
│  - Téléchargement packs dans l'app          │
└─────────────────────────────────────────────┘
```

---

## Parcours utilisateur

1. **Ouvrir l’app**  
   Une Vanelle par défaut est créée si besoin.

2. **Mascottes**  
   - Ajouter → taper un **nom libre** → choisir une **image**  
   - Sélectionner une mascotte existante  
   - Renommer  

3. **Parler**  
   - Texte + Envoyer  
   - 🎤 micro dans l’app  
   - **Bulle ON** : image flottante partout → toucher = micro  

4. **Réponse**  
   `LocalBrain` cherche :
   - corrections supervisées proches de ta question  
   - connaissances / souvenirs / concepts  
   - sinon : « je ne sais pas encore, enseigne-moi »  

5. **Éduquer**  
   - **Corriger** : tu donnes la réponse que tu aurais voulue  
   - **Consolider** : elle digère le lot d’expériences (nuit ou manuel)  

6. **Voix**  
   - Court 🔊 = ON/OFF  
   - Long 🔊 = **Centre des voix**  
     - régler ton / débit / voix système  
     - **télécharger** des profils dans l’app  
     - installer le pack FR du téléphone  

7. **Export / Import**  
   Sauvegarde JSON de l’identité d’**une** mascotte (mémoire séparée).

---

## Mémoire & apprentissage

| Stockage | Rôle |
|----------|------|
| MemoryStore | Souvenirs textuels |
| LearningStore | Expériences Q/R + traits + connaissances |
| ConceptStore | Concepts regroupés à la consolidation |
| SemanticMemory | Liens entre mots / idées |
| VectorMemory | Similarité (hash local, sans cloud) |
| SupervisedStore | Tes corrections prioritaires |

Tout est **namespacé par id de mascotte** : Lila n’a pas la mémoire de Max.

---

## Voix (détail)

1. **Moteur** : Text-To-Speech Android (souvent Google TTS).  
2. **Dans l’app** : `VoiceStore` télécharge des profils (pitch/rate + fichiers HF légers) dans `filesDir/voices/`.  
3. **Pack FR système** : l’app lance la vérif / install des données vocales du téléphone (une fois, gratuit, offline ensuite).  
4. Chaque mascotte garde ses réglages voix.

Les gros modèles neuronaux (Piper ONNX complets, 60 Mo+) restent optionnels côté HF pour ne pas alourdir l’APK ; les profils et le TTS système suffisent pour parler tout de suite.

---

## Permissions

| Permission | Pourquoi |
|------------|----------|
| RECORD_AUDIO | Micro |
| SYSTEM_ALERT_WINDOW | Bulle sur les autres apps |
| FOREGROUND_SERVICE | Garder la bulle active |
| POST_NOTIFICATIONS | Notification du service |
| INTERNET | Télécharger voix / modèles |

---

## Ce qui n’existe pas (volontairement)

- Pas de clé API OpenAI / Gemini  
- Pas de chat cloud obligatoire  
- Pas d’éducation « magique » sans toi  

La mascotte grandit **uniquement** par tes interactions, corrections et consolidations.

---

## Nouveautés 0.7

### Stades
XP calculé depuis souvenirs, leçons, corrections, concepts.
Œuf → Bébé → Curieuse → Sage → Complice (barre sous le nom).

### Onboarding
1. Nom 2. Apparence 3. Un secret qu'elle mémorise tout de suite.

### Proactif
À l'ouverture : bonjour du matin, « tu m'as manqué », invitation à consolider le soir.

### Enseigner
Bouton dédié : sujet + fait → connaissance forte + entrée carnet + XP.

### Widget
Ajouter le widget « Vanelle » depuis l'écran d'accueil du téléphone.
