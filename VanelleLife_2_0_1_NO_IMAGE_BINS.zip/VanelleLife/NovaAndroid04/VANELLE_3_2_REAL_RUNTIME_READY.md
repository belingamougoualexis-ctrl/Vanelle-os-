# VanelleLife 3.2 — Real Runtime Ready

## Added
- strict runtime readiness checks;
- unified real generation service;
- unified real training service;
- model SHA-256 verification;
- explicit model/runtime incompatibility errors;
- secret boundary preventing API credentials from being part of portable AI identity;
- runtime exception handling without fake success;
- checkpoint-aware training contract.

## Important reality constraint
This release makes the platform ready to integrate real inference/training engines; it does not claim that model weights or a GPU backend exist when they do not.

A modality becomes usable only after a compatible `GenerationRuntime` or `TrainingRuntime` is registered and its model artifacts are installed and verified.

## Recommended next integration
1. A real on-device LLM runtime + small model.
2. A real image runtime + compatible diffusion model.
3. A PC/server worker for heavier image/video generation.
4. Authenticated remote jobs and GPU workers.
5. SDK and marketplace services.
