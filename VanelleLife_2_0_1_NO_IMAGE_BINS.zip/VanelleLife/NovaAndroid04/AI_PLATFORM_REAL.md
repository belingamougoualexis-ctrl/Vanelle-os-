# VanelleLife — AI Platform architecture

## Runtime layers
1. AI identity: personality, values, permissions, memories and education.
2. Capability layer: skills and tools with explicit confirmation policy.
3. Model registry: local/user/external model artifacts with SHA-256 and compatibility metadata.
4. Generation router: chooses an installed local model or configured provider; it never fabricates output.
5. Dataset layer: imports user files into private storage and records MIME, size and SHA-256.
6. Training orchestration: WorkManager jobs + real runtime contract + remote training protocol.
7. Audit layer: persistent SQLite events for important actions.

## Real vs unavailable
The app can genuinely store, validate, encrypt, download, route, submit and manage these resources. A neural network cannot be created from Kotlin metadata alone. A real image/video model still needs a real ML runtime and model implementation/weights. The production architecture therefore refuses to report training/generation as successful until an actual runtime returns success.
