# Changements apportés — passe "sécurité + tests + build + architecture + IA externe"

Ce fichier documente honnêtement ce qui a été réellement changé dans cette version,
pour que rien ne soit ni caché ni survendu.

## 1. Sécurité — hachage des mots de passe (CORRIGÉ)
- Avant : SHA-256 en un seul passage, salt = UUID du compte. Cassable en force brute
  très rapidement sur GPU.
- Après : PBKDF2-HMAC-SHA256, 210 000 itérations (recommandation OWASP 2023),
  comparaison en temps constant. Format auto-descriptif pour permettre de futures
  montées de version de l'algorithme sans casser les comptes existants.
- Migration : les comptes déjà créés avec l'ancien format continuent de fonctionner
  (vérification rétro-compatible) et sont automatiquement re-hachés au prochain login
  réussi. Aucune action utilisateur requise, aucun compte perdu.
- Fichiers touchés : `AccountStore.kt`, `FullAccountBackup.kt`.

## 2. Tests automatisés (AJOUTÉS)
- `AccountStoreCryptoTest.kt` — verrouille le comportement du hachage/vérification
  (nouveau format, rétro-compatibilité avec l'ancien, rejet des mauvais mots de passe).
- `CapabilityPolicyTest.kt` — vérifie que le blocage HTTP/localhost/127.0.0.1 fonctionne
  réellement (c'est la barrière anti-fuite vers un serveur non chiffré).
- `JsonPathTest.kt` — vérifie le parseur utilisé pour extraire les réponses des
  providers externes.
- Avant : 1 fichier de test pour ~5 700 lignes de code. Toujours insuffisant pour un
  produit "extrêmement pro", mais les chemins les plus sensibles (sécurité) sont
  maintenant couverts. Les stores restants (MemoryStore, LearningStore, etc.) dépendent
  d'Android Context et nécessiteraient Robolectric pour être testés unitairement —
  non ajouté ici pour ne pas gonfler les dépendances sans direction claire de ta part.

## 3. Build de production (AJOUTÉ)
- `proguard-rules.pro` créé + `isMinifyEnabled`/`isShrinkResources` activés en release.
- Signature de release câblée via variables d'environnement
  (`VANELLELIFE_KEYSTORE_PATH/_PASSWORD/_KEY_ALIAS/_KEY_PASSWORD`) — jamais de secret
  en dur dans le repo. **Tu dois générer ton propre keystore** (`keytool -genkeypair`)
  et renseigner ces variables toi-même ; ce n'est pas fourni ici pour des raisons
  évidentes de sécurité (personne d'autre que toi ne doit avoir ta clé de signature).

## 4. Architecture (AMÉLIORÉ, PAS ENTIÈREMENT REFAIT — voir honnêteté ci-dessous)
- `MainActivity` hérite maintenant de `AppCompatActivity` (le thème était déjà
  `Theme.AppCompat.NoActionBar`, donc ce changement est sûr) au lieu de `Activity` brute.
- Le chemin d'envoi de message (`handleUserText`) utilise maintenant `lifecycleScope` +
  coroutines Kotlin au lieu d'un `Executor`/`Handler` manuel : la requête réseau est
  automatiquement annulée si l'utilisateur quitte l'écran, ce qui élimine une fuite
  mémoire potentielle et un crash possible ("Handler leaked / View not attached").
- **Ce qui n'a PAS été fait** : une réécriture complète en Jetpack Compose / MVVM de
  toute l'app (1 385 lignes dans une seule Activity, tout le reste encore en
  `findViewById`+XML). Le faire correctement sur 66 fichiers sans pouvoir compiler ni
  tester dans cet environnement aurait un risque élevé de tout casser silencieusement.
  C'est un chantier réel, mais qui mérite d'être fait par petites étapes vérifiables
  (un écran à la fois, avec compilation entre chaque étape côté Android Studio),
  pas en un seul gros commit à l'aveugle.

## 5. IA conversationnelle réelle (AJOUTÉ — branchement, pas un modèle inclus)
- Nouveau fichier `ChatEngine.kt` : avant, TOUT le chat passait uniquement par
  `LocalBrain`, un moteur à base de mots-clés/phrases pré-composées — pas une IA
  générative. La plomberie pour parler à un vrai provider externe existait déjà
  dans le code (`ProviderRegistry`, `AISecretVault`, `ProviderExecutor`) mais n'était
  branchée nulle part dans la conversation.
- Maintenant : si tu configures un provider (nouveau bouton "Provider IA (chat)" dans
  le menu Info), chaque message passe d'abord par ce provider HTTPS réel ; en cas
  d'échec ou d'absence de configuration, repli automatique et silencieux sur
  `LocalBrain`.
- **Important, honnêtement** : ceci ne fournit AUCUN modèle. Tu dois toi-même avoir
  accès à une API de génération de texte (la tienne, ou un tiers) qui répond en HTTPS
  avec un JSON contenant un champ texte extractible. Le connecteur est générique
  (mapping JSON configurable) et non pré-câblé sur un fournisseur précis, pour rester
  cohérent avec l'architecture "aucun provider n'est obligatoire" déjà en place dans
  `ProviderSpec.kt`.

## 6. CI/CD (AJOUTÉ, avec une limite à connaître)
- `.github/workflows/ci.yml` : compile (`assembleDebug`), lance les tests unitaires,
  lance le lint Android, et sur push vers `main`/`master` vérifie que le build de
  release compile (signature optionnelle via secrets GitHub, décodage d'un keystore
  base64 — voir commentaires dans le fichier).
- `gradlew` / `gradlew.bat` / `gradle/wrapper/gradle-wrapper.properties` ajoutés
  (le projet n'avait AUCUN wrapper Gradle avant — impossible à builder de façon
  reproductible sur une autre machine ou en CI sans ça).
- **Limite honnête** : `gradle/wrapper/gradle-wrapper.jar` est un fichier **binaire**
  que je ne peux pas générer depuis cet environnement (pas d'accès réseau pour le
  télécharger). Sans lui, `./gradlew` et donc la CI ne fonctionneront pas tel quel.
  **Une seule commande à lancer une fois**, en local (Android Studio a un terminal
  intégré, ou n'importe quel Gradle déjà installé sur ta machine) :
  ```
  gradle wrapper --gradle-version 8.9
  ```
  Ça génère le `.jar` manquant. Ensuite tu le commits normalement (ce n'est pas un
  secret, c'est un fichier standard de tous les projets Gradle/Android sur GitHub).
  Alternative encore plus simple : ouvre juste le projet dans Android Studio, il
  propose de régénérer le wrapper automatiquement au premier sync si besoin.

## 7. Tests étendus aux stores Android via Robolectric (AJOUTÉ)
- Dépendances `robolectric` + `androidx.test:core` ajoutées en `testImplementation`.
- Nouveau test : `AccountStoreInstrumentedTest.kt` — teste le vrai flux
  inscription → déconnexion → connexion → mauvais mot de passe, en conditions quasi
  réelles (SharedPreferences simulées par Robolectric), pas seulement la fonction de
  hachage isolée comme dans `AccountStoreCryptoTest.kt`.
- Entraînement de modèle réel sur l'appareil (`TrainingRuntime` reste une interface
  vide — nécessite un runtime ML natif que je ne peux pas fabriquer ni te fournir ici).
- Compte cloud / synchronisation multi-appareils (actuellement 100% local par design).
- CI/CD (pipeline GitHub Actions / GitLab CI pour lancer les tests automatiquement).
- Couverture de tests étendue à tous les stores (nécessite Robolectric).
- Migration UI complète vers Compose.

Ces points restent les vrais chantiers "leader mondial" — infrastructure, modèle
économique, équipe — qu'aucun ajout de code ne remplace.
