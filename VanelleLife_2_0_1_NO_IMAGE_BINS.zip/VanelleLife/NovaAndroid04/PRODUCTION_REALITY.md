# VanelleLife — Real functionality boundary

## Implemented as real Android functionality
- Local persistent AI Studio metadata and education ledger.
- Local SQLite platform database for datasets/jobs/audit events.
- SHA-256 dataset inspection and dataset materialization into private app storage.
- HTTPS-only provider execution with configurable JSON request/response paths.
- Android Keystore protection for provider secrets.
- Password-protected export encryption using PBKDF2 + AES-GCM.
- Model artifact SHA-256 verification and compatibility checks.
- Resumable/durable job orchestration through WorkManager contracts.
- Real remote-training HTTP submission to an HTTPS server controlled/authorized by the user.
- Real hardware capability detection for Vulkan and NNAPI feature availability.

## Not claimed as implemented because it is not technically possible to conjure it from Android code alone
- A frontier-quality text-to-video model trained from zero.
- A frontier-quality text-to-image model trained from zero.
- A full GPU/NPU training runtime for arbitrary neural-network architectures.
- A production cloud GPU fleet, CDN, marketplace backend, account service, or global infrastructure.

Those require actual model weights/architectures, native ML runtimes, datasets, hardware, and/or backend infrastructure. The app therefore reports these capabilities as unavailable until a real runtime is installed/connected; it never fabricates progress or generated media.
