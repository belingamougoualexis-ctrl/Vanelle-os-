plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.nova.ai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.vanellelife.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 201
        versionName = "2.0.1-no-image-bins"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        // Optionnel : -PSENTRY_DSN=https://...@o.ingest.sentry.io/xxx
        buildConfigField("String", "SENTRY_DSN", "\"${project.findProperty("SENTRY_DSN") ?: System.getenv("SENTRY_DSN") ?: ""}\"")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    testOptions {
        unitTests {
            isIncludeAndroidResources = true
            isReturnDefaultValues = true
        }
    }

    // Signature de release : ne JAMAIS committer de keystore/mot de passe en dur.
    // Renseigner via variables d'environnement (CI) ou gradle.properties local
    // non versionné : VANELLELIFE_KEYSTORE_PATH / _PASSWORD / _KEY_ALIAS / _KEY_PASSWORD.
    val releaseKeystorePath = System.getenv("VANELLELIFE_KEYSTORE_PATH")
        ?: (project.findProperty("VANELLELIFE_KEYSTORE_PATH") as String?)
    signingConfigs {
        if (!releaseKeystorePath.isNullOrBlank()) {
            create("release") {
                storeFile = file(releaseKeystorePath)
                storePassword = System.getenv("VANELLELIFE_KEYSTORE_PASSWORD")
                    ?: (project.findProperty("VANELLELIFE_KEYSTORE_PASSWORD") as String?)
                keyAlias = System.getenv("VANELLELIFE_KEY_ALIAS")
                    ?: (project.findProperty("VANELLELIFE_KEY_ALIAS") as String?)
                keyPassword = System.getenv("VANELLELIFE_KEY_PASSWORD")
                    ?: (project.findProperty("VANELLELIFE_KEY_PASSWORD") as String?)
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (!releaseKeystorePath.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
        }
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")

    // Compose (UI progressive — Hub peut migrer ; Main reste Views pour stabilité)
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.activity:activity-compose:1.9.3")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // MediaPipe LLM (léger côté APK ; le modèle ~550 Mo se télécharge in-app)
    implementation("com.google.mediapipe:tasks-genai:0.10.27")

    // Sentry optionnel (activé seulement si DSN + opt-in)
    implementation("io.sentry:sentry-android:7.16.0")

    // Room (DAO optionnels ; AppDatabase SQLite reste la base actuelle)
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
    testImplementation("org.robolectric:robolectric:4.13")
    testImplementation("androidx.test:core:1.6.1")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
