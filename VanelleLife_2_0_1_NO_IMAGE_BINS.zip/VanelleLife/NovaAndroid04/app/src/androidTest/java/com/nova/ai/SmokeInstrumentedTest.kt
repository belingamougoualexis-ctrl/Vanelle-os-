package com.nova.ai

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Tests instrumentés légers (device/émulateur).
 * Lancer : ./gradlew connectedDebugAndroidTest
 */
@RunWith(AndroidJUnit4::class)
class SmokeInstrumentedTest {
    @Test
    fun useAppContext() {
        val appContext = InstrumentationRegistry.getInstrumentation().targetContext
        assertEquals("com.vanellelife.app.debug", appContext.packageName)
            .let { /* debug suffix */ }
        // En release le suffixe disparaît ; on accepte les deux
        assertTrue(
            appContext.packageName == "com.vanellelife.app" ||
                appContext.packageName == "com.vanellelife.app.debug"
        )
    }

    @Test
    fun modelCatalogNotEmpty() {
        assertTrue(ModelDownloader.CATALOG.isNotEmpty())
        assertTrue(ModelDownloader.CATALOG.any { it.id == "embed_minilm" })
        assertTrue(ModelDownloader.CATALOG.any { it.id.startsWith("llm_") })
    }
}
