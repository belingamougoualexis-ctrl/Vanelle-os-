package com.nova.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Le hachage de mot de passe est le point le plus sensible de l'app (compte 100% local,
 * aucune récupération possible si cassé). Ces tests verrouillent le comportement attendu.
 */
class AccountStoreCryptoTest {

    @Test
    fun hashHasExpectedFormatAndPrefix() {
        val hash = AccountStore.hashPassword("motdepasse123", "salt-id-1")
        assertTrue("Le hash doit être auto-descriptif (algo\$iterations\$hex)", hash.startsWith("pbkdf2-sha256$"))
        val parts = hash.split("$")
        assertEquals(3, parts.size)
        assertEquals(210_000, parts[1].toInt())
        assertTrue("La partie hash doit être de l'hexadécimal", parts[2].matches(Regex("^[0-9a-f]{64}$")))
    }

    @Test
    fun sameInputsProduceSameHash() {
        val a = AccountStore.hashPassword("motdepasse123", "salt-id-1")
        val b = AccountStore.hashPassword("motdepasse123", "salt-id-1")
        assertEquals(a, b)
    }

    @Test
    fun differentSaltsProduceDifferentHashes() {
        val a = AccountStore.hashPassword("motdepasse123", "salt-id-1")
        val b = AccountStore.hashPassword("motdepasse123", "salt-id-2")
        assertNotEquals(a, b)
    }

    @Test
    fun differentPasswordsProduceDifferentHashes() {
        val a = AccountStore.hashPassword("motdepasse123", "salt-id-1")
        val b = AccountStore.hashPassword("autremotdepasse", "salt-id-1")
        assertNotEquals(a, b)
    }

    @Test
    fun verifyStoredAcceptsCorrectPassword() {
        val hash = AccountStore.hashPassword("motdepasse123", "salt-id-1")
        assertTrue(AccountStore.verifyStored("motdepasse123", "salt-id-1", hash))
    }

    @Test
    fun verifyStoredRejectsWrongPassword() {
        val hash = AccountStore.hashPassword("motdepasse123", "salt-id-1")
        assertFalse(AccountStore.verifyStored("mauvaismotdepasse", "salt-id-1", hash))
    }

    @Test
    fun verifyStoredIsBackwardCompatibleWithLegacySha256() {
        // Reproduit l'ancien format (avant migration PBKDF2) pour garantir que les comptes
        // existants ne sont pas verrouillés dehors par la mise à jour de sécurité.
        val md = java.security.MessageDigest.getInstance("SHA-256")
        val legacyBytes = md.digest("salt-id-1::motdepasse123".toByteArray(Charsets.UTF_8))
        val legacyHash = legacyBytes.joinToString("") { "%02x".format(it) }

        assertTrue(AccountStore.verifyStored("motdepasse123", "salt-id-1", legacyHash))
        assertFalse(AccountStore.verifyStored("mauvaismotdepasse", "salt-id-1", legacyHash))
    }
}
