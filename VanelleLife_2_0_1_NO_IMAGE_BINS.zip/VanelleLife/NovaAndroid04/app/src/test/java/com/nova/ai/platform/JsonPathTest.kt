package com.nova.ai.platform

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class JsonPathTest {

    @Test
    fun readsNestedObjectField() {
        val json = JSONObject("""{"a":{"b":{"c":"valeur"}}}""")
        assertEquals("valeur", JsonPath.get(json, "a.b.c"))
    }

    @Test
    fun readsArrayIndex() {
        val json = JSONObject("""{"choices":[{"text":"premier"},{"text":"second"}]}""")
        assertEquals("premier", JsonPath.get(json, "choices.0.text"))
        assertEquals("second", JsonPath.get(json, "choices.1.text"))
    }

    @Test
    fun blankPathReturnsRoot() {
        val json = JSONObject("""{"x":1}""")
        assertEquals(json, JsonPath.get(json, ""))
    }

    @Test
    fun missingFieldReturnsNull() {
        val json = JSONObject("""{"a":1}""")
        assertNull(JsonPath.get(json, "b.c"))
    }

    @Test
    fun outOfBoundsArrayIndexReturnsNull() {
        val arr = JSONArray("""["x","y"]""")
        assertNull(JsonPath.get(arr, "5"))
    }
}
