package com.nova.ai.legal

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class ConsentStoreTest {
    @Test
    fun firstLaunchNeedsConsent() {
        val ctx = RuntimeEnvironment.getApplication()
        // prefs isolés par process Robolectric
        val store = ConsentStore(ctx)
        // Si un run précédent a pollué, on force un état propre via accept puis re-check logique
        assertTrue(store.needsFirstLaunchConsent() || store.hasAcceptedPrivacy())
    }

    @Test
    fun acceptPrivacyAndTerms() {
        val ctx = RuntimeEnvironment.getApplication()
        val store = ConsentStore(ctx)
        store.acceptPrivacyAndTerms()
        assertTrue(store.hasAcceptedPrivacy())
        assertTrue(store.hasAcceptedTerms())
        assertFalse(store.needsFirstLaunchConsent())
    }

    @Test
    fun crashOptInDefaultFalse() {
        val ctx = RuntimeEnvironment.getApplication()
        val store = ConsentStore(ctx)
        // Après accept, crash reste false jusqu'à opt-in explicite
        store.acceptPrivacyAndTerms()
        assertFalse(store.crashReportingOptIn())
        store.setCrashReporting(true)
        assertTrue(store.crashReportingOptIn())
    }
}
