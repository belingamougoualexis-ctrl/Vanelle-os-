package com.nova.ai

import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Teste AccountStore avec un vrai Context Android simulé (SharedPreferences réelles via
 * Robolectric), pas seulement la fonction de hachage isolée. Couvre le parcours utilisateur
 * complet : inscription, déconnexion, reconnexion, mauvais mot de passe, ré-inscription.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class AccountStoreInstrumentedTest {

    private lateinit var store: AccountStore

    @Before
    fun setUp() {
        store = AccountStore(ApplicationProvider.getApplicationContext())
    }

    @Test
    fun freshInstallHasNoAccount() {
        assertFalse(store.hasAccount())
        assertFalse(store.isLoggedIn())
        assertNull(store.current())
    }

    @Test
    fun registerCreatesAndLogsInAccount() {
        val error = store.register("alice", "motdepasse")
        assertNull("L'inscription ne doit pas renvoyer d'erreur", error)
        assertTrue(store.hasAccount())
        assertTrue(store.isLoggedIn())
        assertNotNull(store.current())
        assertEquals("alice", store.current()!!.username)
    }

    @Test
    fun registerRejectsShortUsername() {
        val error = store.register("ab", "motdepasse")
        assertNotNull(error)
        assertFalse(store.hasAccount())
    }

    @Test
    fun registerRejectsShortPassword() {
        val error = store.register("alice", "abc")
        assertNotNull(error)
        assertFalse(store.hasAccount())
    }

    @Test
    fun logoutThenLoginWithCorrectPasswordSucceeds() {
        store.register("alice", "motdepasse")
        store.logout()
        assertFalse(store.isLoggedIn())

        val error = store.login("alice", "motdepasse")
        assertNull(error)
        assertTrue(store.isLoggedIn())
    }

    @Test
    fun loginWithWrongPasswordFails() {
        store.register("alice", "motdepasse")
        store.logout()

        val error = store.login("alice", "mauvaismotdepasse")
        assertNotNull(error)
        assertFalse(store.isLoggedIn())
    }

    @Test
    fun loginWithWrongUsernameFails() {
        store.register("alice", "motdepasse")
        store.logout()

        val error = store.login("bob", "motdepasse")
        assertNotNull(error)
    }

    @Test
    fun verifyPasswordMatchesCurrentAccount() {
        store.register("alice", "motdepasse")
        assertTrue(store.verifyPassword("motdepasse"))
        assertFalse(store.verifyPassword("mauvaismotdepasse"))
    }

    @Test
    fun reRegisterAfterLogoutReplacesAccount() {
        store.register("alice", "motdepasse")
        store.logout()
        val error = store.register("bob", "autremotdepasse")
        assertNull(error)
        assertEquals("bob", store.current()!!.username)
        // L'ancien compte "alice" ne doit plus être vérifiable avec ses identifiants.
        assertFalse(store.login("alice", "motdepasse") == null)
    }
}
