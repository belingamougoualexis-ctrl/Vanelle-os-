package com.nova.ai.platform

import org.junit.Test

class CapabilityPolicyTest {

    @Test
    fun acceptsValidHttpsEndpoint() {
        CapabilityPolicy.validateExternalEndpoint("https://api.example.com/v1/chat")
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsHttpEndpoint() {
        CapabilityPolicy.validateExternalEndpoint("http://api.example.com/v1/chat")
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsLocalhost() {
        CapabilityPolicy.validateExternalEndpoint("https://localhost:8080/generate")
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsLoopbackIp() {
        CapabilityPolicy.validateExternalEndpoint("https://127.0.0.1:8080/generate")
    }

    @Test
    fun destructiveActionsRequireConfirmation() {
        assert(CapabilityPolicy.requiresConfirmation("delete_data"))
        assert(CapabilityPolicy.requiresConfirmation("payment"))
        assert(CapabilityPolicy.requiresConfirmation("publish"))
    }

    @Test
    fun readOnlyActionsDoNotRequireConfirmation() {
        assert(!CapabilityPolicy.requiresConfirmation("read_status"))
    }
}
