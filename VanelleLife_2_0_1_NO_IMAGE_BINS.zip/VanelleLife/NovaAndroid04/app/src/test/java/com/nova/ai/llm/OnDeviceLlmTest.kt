package com.nova.ai.llm

import com.nova.ai.platform.ReadinessState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class OnDeviceLlmTest {

    @Test
    fun mediaPipe_missingModelByDefault() {
        val ctx = RuntimeEnvironment.getApplication()
        val llm = MediaPipeLlm()
        val check = llm.readiness(ctx)
        // Soit MODEL_MISSING soit RUNTIME_MISSING selon présence de la lib sur le classpath de test
        assert(check.state == ReadinessState.MODEL_MISSING || check.state == ReadinessState.RUNTIME_MISSING)
        assertNull(llm.generate(ctx, "bonjour"))
    }

    @Test
    fun ruleBased_alwaysReady() {
        val ctx = RuntimeEnvironment.getApplication()
        val llm = object : OnDeviceLlm {
            override val id = "stub"
            override fun readiness(context: android.content.Context) =
                com.nova.ai.platform.RuntimeCheck(ReadinessState.READY, "ok")
            override fun generate(context: android.content.Context, prompt: String, systemHint: String?) =
                "réponse-test"
        }
        assertEquals(ReadinessState.READY, llm.readiness(ctx).state)
        assertEquals("réponse-test", llm.generate(ctx, "hi"))
    }
}
