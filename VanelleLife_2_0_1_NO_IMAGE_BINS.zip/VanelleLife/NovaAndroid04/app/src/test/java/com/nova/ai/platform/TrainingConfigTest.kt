package com.nova.ai.platform

import org.junit.Test

class TrainingConfigTest {
    @Test fun validConfigIsAccepted(){ TrainingConfig().validate() }
    @Test(expected = IllegalArgumentException::class)
    fun invalidFpsIsRejected(){ TrainingConfig(fps=0).validate() }
}
