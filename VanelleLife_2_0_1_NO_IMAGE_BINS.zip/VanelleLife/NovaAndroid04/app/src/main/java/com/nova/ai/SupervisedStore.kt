package com.nova.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Apprentissage supervisé local (sans fine-tuning des poids du LLM).
 *
 * Quand l'utilisateur corrige une réponse de NOVA, on enregistre la paire
 * (question, réponse préférée). Au prochain échange similaire, les meilleurs
 * exemples sont injectés dans le contexte (few-shot retrieval).
 *
 * Un export JSONL prêt pour un fine-tuning externe (OpenAI, etc.) est aussi
 * disponible via IdentityBackup / bouton dédié.
 */
data class SupervisedPair(
    val input: String,
    val preferred: String,
    val timestamp: Long = System.currentTimeMillis(),
    val source: String = "correction"
)

class SupervisedStore(context: Context, namespace: String = "default") {
    private val p = context.getSharedPreferences("nova_supervised_$namespace", Context.MODE_PRIVATE)
    private val maxPairs = 300

    fun all(): List<SupervisedPair> {
        val a = JSONArray(p.getString("pairs", "[]") ?: "[]")
        return buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(SupervisedPair(
                    o.getString("input"),
                    o.getString("preferred"),
                    o.optLong("ts", 0),
                    o.optString("source", "correction")
                ))
            }
        }
    }

    fun size(): Int = all().size

    fun add(input: String, preferred: String, source: String = "correction") {
        if (input.isBlank() || preferred.isBlank()) return
        val list = all().takeLast(maxPairs - 1).toMutableList()
        list.add(SupervisedPair(input.trim(), preferred.trim(), System.currentTimeMillis(), source))
        persist(list)
    }

    /** Récupération lexicale simple des exemples les plus proches (complétée par vecteurs si dispo). */
    fun relevant(query: String, limit: Int = 4): List<SupervisedPair> {
        val tokens = query.lowercase().split(Regex("\\W+")).filter { it.length > 2 }.toSet()
        if (tokens.isEmpty()) return emptyList()
        return all()
            .map { pair ->
                val score = tokens.count { pair.input.lowercase().contains(it) || pair.preferred.lowercase().contains(it) }
                pair to score
            }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(limit)
            .map { it.first }
    }

    /** Format JSONL compatible export fine-tuning (messages OpenAI-style). */
    fun toFineTuneJsonl(): String = all().joinToString("\n") { pair ->
        JSONObject().apply {
            put("messages", JSONArray().apply {
                put(JSONObject().apply { put("role", "user"); put("content", pair.input) })
                put(JSONObject().apply { put("role", "assistant"); put("content", pair.preferred) })
            })
        }.toString()
    }

    fun clear() {
        p.edit().putString("pairs", "[]").apply()
    }

    private fun persist(list: List<SupervisedPair>) {
        val a = JSONArray(list.map { e ->
            JSONObject().apply {
                put("input", e.input)
                put("preferred", e.preferred)
                put("ts", e.timestamp)
                put("source", e.source)
            }
        })
        p.edit().putString("pairs", a.toString()).apply()
    }
}
