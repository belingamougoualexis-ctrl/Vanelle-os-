package com.nova.ai

import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

/** Real REST provider client. It never fabricates a generation result. */
object AIProviderClient {
    data class Result(val ok:Boolean,val body:String,val code:Int)
    fun postJson(endpoint:String, json:String, bearer:String?=null): Result = try {
        require(endpoint.startsWith("https://")) { "Endpoint HTTPS requis." }
        val c=URL(endpoint).openConnection() as HttpURLConnection
        c.requestMethod="POST"; c.connectTimeout=20_000;c.readTimeout=120_000;c.doOutput=true
        c.setRequestProperty("Content-Type","application/json")
        if (!bearer.isNullOrBlank()) c.setRequestProperty("Authorization", "Bearer $bearer")
        c.outputStream.use{it.write(json.toByteArray())}
        val code=c.responseCode; val stream=if(code in 200..299)c.inputStream else c.errorStream
        val body=stream?.bufferedReader()?.use{it.readText()} ?: ""
        Result(code in 200..299,body,code)
    } catch(e:Exception){Result(false,e.message ?: "Erreur réseau",-1)}
    fun generationRequest(prompt:String, kind:String)=JSONObject().apply{put("prompt",prompt);put("type",kind)}.toString()
}

/** Provider-agnostic execution helpers. The response is always the provider's real response. */
fun AIProviderClient.executeConfigured(endpoint: String, apiKey: String?, kind: String, prompt: String): AIProviderClient.Result {
    require(endpoint.startsWith("https://")) { "Endpoint HTTPS requis." }
    return AIProviderClient.postJson(endpoint, AIProviderClient.generationRequest(prompt, kind), apiKey)
}
