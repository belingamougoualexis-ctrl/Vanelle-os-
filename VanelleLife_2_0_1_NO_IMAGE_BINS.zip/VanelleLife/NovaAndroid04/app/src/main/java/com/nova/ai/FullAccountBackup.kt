package com.nova.ai

import android.content.Context
import org.json.JSONObject

/**
 * Sauvegarde complète du compte + toutes les mascottes + boutique + carnets.
 * Permet de changer de téléphone sans serveur.
 */
object FullAccountBackup {

    fun export(context: Context, password: String): String? {
        val accounts = AccountStore(context)
        val acc = accounts.current() ?: return null
        if (!accounts.verifyPassword(password)) return null

        val root = JSONObject()
        root.put("format", "nova_full_account")
        root.put("version", 5)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("account", JSONObject().apply {
            put("id", acc.id)
            put("username", acc.username)
            put("password_hash", acc.passwordHash)
            put("created_at", acc.createdAt)
        })

        // Mascottes
        val mascotPrefs = context.getSharedPreferences("nova_mascots", Context.MODE_PRIVATE)
        root.put("nova_mascots", prefsToJson(mascotPrefs))

        val store = MascotStore(context)
        val mascotsArr = org.json.JSONArray()
        for (m in store.all()) {
            val pack = JSONObject()
            pack.put("mascot_id", m.id)
            pack.put("identity", JSONObject(IdentityBackup.export(context, m.id)))
            mascotsArr.put(pack)
        }
        root.put("mascots_data", mascotsArr)

        // Boutique / onboarding / proactive / account-level
        for (name in listOf("nova_shop", "nova_onboarding", "nova_proactive", "nova_account")) {
            root.put(name, prefsToJson(context.getSharedPreferences(name, Context.MODE_PRIVATE)))
        }

        return root.toString(2)
    }

    fun import(context: Context, json: String, password: String): String? {
        return try {
            val root = JSONObject(json)
            if (root.optString("format") != "nova_full_account") {
                return "Fichier invalide (pas un compte NOVA complet)"
            }
            val accObj = root.getJSONObject("account")
            val id = accObj.getString("id")
            val username = accObj.getString("username")
            val hash = accObj.getString("password_hash")
            val created = accObj.optLong("created_at", System.currentTimeMillis())

            // Vérifier le mot de passe saisi contre le hash du fichier (accepte l'ancien et le nouveau format)
            if (!AccountStore.verifyStored(password, id, hash)) return "Mot de passe incorrect pour ce compte"

            // Restaurer compte
            AccountStore(context).restoreAccount(id, username, hash, created)

            // Mascottes liste
            if (root.has("nova_mascots")) {
                jsonToPrefs(context, "nova_mascots", root.getJSONObject("nova_mascots"))
            }

            // Données par mascotte
            if (root.has("mascots_data")) {
                val arr = root.getJSONArray("mascots_data")
                for (i in 0 until arr.length()) {
                    val pack = arr.getJSONObject(i)
                    val identity = pack.getJSONObject("identity").toString()
                    IdentityBackup.import(context, identity)
                }
            }

            for (name in listOf("nova_shop", "nova_onboarding", "nova_proactive")) {
                if (root.has(name)) jsonToPrefs(context, name, root.getJSONObject(name))
            }

            null
        } catch (e: Exception) {
            e.message ?: "Import échoué"
        }
    }

    private fun prefsToJson(p: android.content.SharedPreferences): JSONObject {
        val o = JSONObject()
        p.all.forEach { (k, v) ->
            when (v) {
                is String -> o.put(k, v)
                is Int -> o.put(k, v)
                is Long -> o.put(k, v)
                is Float -> o.put(k, v.toDouble())
                is Boolean -> o.put(k, v)
            }
        }
        return o
    }

    private fun jsonToPrefs(context: Context, name: String, o: JSONObject) {
        val ed = context.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear()
        o.keys().forEach { k ->
            when (val v = o.get(k)) {
                is String -> ed.putString(k, v)
                is Int -> ed.putInt(k, v)
                is Long -> ed.putLong(k, v)
                is Double -> ed.putFloat(k, v.toFloat())
                is Boolean -> ed.putBoolean(k, v)
            }
        }
        ed.apply()
    }
}
