package com.nova.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Carnet de croissance : événements marquants par mascotte. */
class GrowthJournal(context: Context, private val namespace: String) {
    private val p = context.getSharedPreferences("nova_journal_$namespace", Context.MODE_PRIVATE)

    data class Entry(val at: Long, val kind: String, val text: String)

    fun add(kind: String, text: String) {
        val a = JSONArray(p.getString("entries", "[]") ?: "[]")
        a.put(JSONObject().put("at", System.currentTimeMillis()).put("kind", kind).put("text", text))
        // garder 200 max
        while (a.length() > 200) a.remove(0)
        p.edit().putString("entries", a.toString()).apply()
    }

    fun all(): List<Entry> {
        val a = JSONArray(p.getString("entries", "[]") ?: "[]")
        return buildList {
            for (i in a.length() - 1 downTo 0) {
                val o = a.getJSONObject(i)
                add(Entry(o.getLong("at"), o.getString("kind"), o.getString("text")))
            }
        }
    }

    fun timelineText(limit: Int = 30): String {
        val list = all().take(limit)
        if (list.isEmpty()) return "Encore aucun événement. Parle, enseigne, corrige…"
        val fmt = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.FRANCE)
        return list.joinToString("\n\n") { "• ${fmt.format(java.util.Date(it.at))} — [${it.kind}] ${it.text}" }
    }

    /** Résumé court des derniers messages, utilisé comme contexte de conversation envoyé à un provider externe. */
    fun recentTextSummary(limit: Int = 6): String =
        all().filter { it.kind == "message" }.take(limit).reversed().joinToString("\n") { it.text }
}
