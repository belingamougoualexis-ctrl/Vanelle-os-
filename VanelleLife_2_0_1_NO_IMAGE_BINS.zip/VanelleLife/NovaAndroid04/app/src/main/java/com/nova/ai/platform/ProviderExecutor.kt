package com.nova.ai.platform

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * Appel HTTPS réel au provider.
 * - Remplace {{prompt}}, {{system}}, {{context}}, etc. dans le template
 * - Remplit aussi les clés JSON vides connues (prompt, content, message…)
 * - Ne fabrique jamais une réponse : uniquement le HTTP reçu
 */
object ProviderExecutor {
    data class Result(
        val ok: Boolean,
        val status: Int,
        val body: String,
        val extracted: String?,
        val error: String? = null
    )

    fun execute(
        spec: ProviderSpec,
        secret: String?,
        variables: Map<String, String>,
        timeoutMs: Int = 120_000
    ): Result {
        return try {
            CapabilityPolicy.validateExternalEndpoint(spec.endpoint)
            val payload = buildPayload(spec.requestTemplate, variables)
            val c = (URL(spec.endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = timeoutMs.coerceAtLeast(15_000)
                readTimeout = timeoutMs.coerceAtLeast(15_000)
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
                if (!secret.isNullOrBlank()) when (spec.authType.lowercase()) {
                    "bearer" -> setRequestProperty("Authorization", "Bearer $secret")
                    "api-key", "x-api-key" -> setRequestProperty("X-API-Key", secret)
                    else -> setRequestProperty("Authorization", secret)
                }
            }
            c.outputStream.use { it.write(payload.toByteArray(StandardCharsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            c.disconnect()
            if (code !in 200..299) {
                Result(false, code, body, null, "HTTP $code")
            } else {
                val extracted = extract(body, spec.responsePath)
                Result(true, code, body, extracted)
            }
        } catch (e: Exception) {
            Result(false, -1, "", null, e.message ?: e.javaClass.simpleName)
        }
    }

    /** Test rapide de connectivité (même pipeline que le chat). */
    fun test(spec: ProviderSpec, secret: String?): Result {
        val vars = mapOf(
            "prompt" to "Réponds uniquement: OK",
            "message" to "Réponds uniquement: OK",
            "user" to "Réponds uniquement: OK",
            "system" to "Tu es un test de connexion. Réponds OK.",
            "system_prompt" to "Tu es un test de connexion. Réponds OK.",
            "context" to "",
            "history" to ""
        )
        return execute(spec, secret, vars, timeoutMs = 45_000)
    }

    fun buildPayload(template: String, variables: Map<String, String>): String {
        var filled = template.ifBlank { """{"prompt":"{{prompt}}","system":"{{system}}"}""" }
        variables.forEach { (k, v) ->
            filled = filled
                .replace("{{$k}}", jsonEscape(v))
                .replace("\${$k}", jsonEscape(v))
        }
        return try {
            val root = JSONObject(filled)
            fillJsonTree(root, variables)
            // Aussi au premier niveau pour les APIs simples
            variables.forEach { (k, v) ->
                if (!root.has(k) || root.optString(k).isBlank()) root.put(k, v)
            }
            root.toString()
        } catch (_: Exception) {
            filled
        }
    }

    private fun fillJsonTree(node: Any?, variables: Map<String, String>) {
        when (node) {
            is JSONObject -> {
                val keys = node.keys().asSequence().toList()
                for (key in keys) {
                    val v = node.opt(key)
                    when (v) {
                        is JSONObject, is JSONArray -> fillJsonTree(v, variables)
                        is String -> {
                            val s = v.trim()
                            if (s.startsWith("{{") && s.endsWith("}}")) {
                                val name = s.removePrefix("{{").removeSuffix("}}").trim()
                                variables[name]?.let { node.put(key, it) }
                            } else if (s.isEmpty() && key.lowercase() in contentKeys) {
                                val mapped = when (key.lowercase()) {
                                    "system", "system_prompt" -> variables["system"] ?: variables["system_prompt"]
                                    "prompt", "message", "user", "query", "input", "text", "content" ->
                                        variables["prompt"] ?: variables["message"] ?: variables["user"]
                                    "context", "history" -> variables["context"] ?: variables["history"]
                                    else -> null
                                }
                                if (!mapped.isNullOrBlank()) node.put(key, mapped)
                            }
                        }
                    }
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    fillJsonTree(node.opt(i), variables)
                }
            }
        }
    }

    private val contentKeys = setOf(
        "prompt", "message", "user", "query", "input", "text", "content",
        "system", "system_prompt", "context", "history"
    )

    private fun jsonEscape(s: String): String =
        s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "")

    private fun extract(body: String, path: String): String? {
        if (path.isBlank()) return body
        val got = runCatching { JsonPath.get(JSONObject(body), path) }.getOrNull()
        return when (got) {
            null -> tryFallbackExtract(body)
            is String -> got
            is JSONObject -> got.optString("content", got.toString())
            else -> got.toString()
        }
    }

    /** Fallbacks OpenAI / Anthropic / Gemini-like. */
    private fun tryFallbackExtract(body: String): String? {
        return runCatching {
            val o = JSONObject(body)
            o.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                ?.takeIf { it.isNotBlank() }
                ?: o.optJSONArray("choices")?.optJSONObject(0)?.optString("text")?.takeIf { it.isNotBlank() }
                ?: o.optString("text").takeIf { it.isNotBlank() }
                ?: o.optString("response").takeIf { it.isNotBlank() }
                ?: o.optString("output").takeIf { it.isNotBlank() }
                ?: o.optJSONArray("content")?.optJSONObject(0)?.optString("text")?.takeIf { it.isNotBlank() }
        }.getOrNull()
    }
}
