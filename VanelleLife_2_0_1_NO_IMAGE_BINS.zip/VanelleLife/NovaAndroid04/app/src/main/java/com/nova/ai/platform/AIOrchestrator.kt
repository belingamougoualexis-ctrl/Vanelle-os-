package com.nova.ai.platform

/** Deterministic tool-selection plan. Execution is delegated to real runtimes. */
class AIOrchestrator(private val router:GenerationRouter){
    data class Step(val action:String,val input:String,val requiredCapability:String)
    fun plan(request:String):List<Step>{val t=request.lowercase();return when{listOf("vidéo","video","film","animation").any{t.contains(it)}->listOf(Step("analyze","$request","chat"),Step("generate_video","$request","video"));listOf("image","photo","dessin","illustration").any{t.contains(it)}->listOf(Step("analyze","$request","chat"),Step("generate_image","$request","image"));listOf("voix","audio","parle").any{t.contains(it)}->listOf(Step("generate_audio","$request","audio"));else->listOf(Step("answer","$request","chat"))}}
}
