package com.nova.ai.platform

/** Runtime registry entry. A runtime is usable only when an implementation is installed. */
data class RuntimeDescriptor(val id:String,val name:String,val modalities:Set<String>,val version:String,val local:Boolean,val installed:Boolean,val minRamMb:Long)
object LocalRuntimeRegistry {
    private val descriptors=mutableListOf<RuntimeDescriptor>()
    fun register(d:RuntimeDescriptor){synchronized(descriptors){descriptors.removeAll{it.id==d.id};descriptors+=d}}
    fun all():List<RuntimeDescriptor>=synchronized(descriptors){descriptors.toList()}
    fun forModality(modality:String)=all().filter{it.installed&&it.modalities.contains(modality.lowercase())}
}
