package com.nova.ai

import android.content.Context

class DevelopmentEngine(
    private val context: Context,
    private val memory: MemoryStore,
    private val learning: LearningStore,
    namespace: String = "default"
) {
    val concepts = ConceptStore(context, namespace)
    val semantic = SemanticMemory(context, namespace)
    val vectors = VectorMemory(context, namespace)
    val supervised = SupervisedStore(context, namespace)
    private val personality = PersonalityEngine(learning)
    val consolidation = ConsolidationEngine(context, memory, learning, concepts, semantic, personality, namespace)

    data class State(
        val stage: String,
        val memories: Int,
        val experiences: Int,
        val knowledge: Int,
        val skills: Int,
        val curiosity: Int,
        val concepts: Int,
        val beliefRevisions: Int,
        val unconsolidated: Int,
        val vectors: Int,
        val supervised: Int
    )

    fun state(): State {
        val score = memory.all().size + learning.experiences().size + learning.knowledge().size * 2 +
            learning.skills().sumOf { it.level / 10 } + concepts.all().size * 3 +
            vectors.size() + supervised.size() * 2
        val stage = when {
            score < 25 -> "Naissance"
            score < 120 -> "Découverte"
            score < 350 -> "Apprentissage"
            score < 900 -> "Raisonnement"
            else -> "Maturité"
        }
        return State(
            stage,
            memory.all().size,
            learning.experiences().size,
            learning.knowledge().size,
            learning.skills().size,
            (35 + learning.experiences().size / 5).coerceAtMost(100),
            concepts.all().size,
            learning.beliefRevisions().size,
            consolidation.unconsolidatedCount(),
            vectors.size(),
            supervised.size()
        )
    }

    fun observe(userText: String) {
        if (shouldRemember(userText)) memory.remember(userText, 3)
        val lower = userText.lowercase()
        when {
            lower.startsWith("j'aime ") -> BeliefRevision.evaluate(learning, "préférence", userText, .85, "interaction")
            lower.startsWith("je préfère ") -> BeliefRevision.evaluate(learning, "préférence", userText, .9, "interaction")
            lower.startsWith("je n'aime pas ") -> BeliefRevision.evaluate(learning, "préférence", userText, .85, "interaction")
            lower.startsWith("je m'appelle ") -> BeliefRevision.evaluate(learning, "identité utilisateur", userText, .95, "interaction")
            lower.startsWith("mon objectif") || lower.startsWith("je veux ") -> BeliefRevision.evaluate(learning, "objectif", userText, .8, "interaction")
            lower.startsWith("souviens-toi") || lower.startsWith("retiens") || lower.startsWith("apprends que") ||
            lower.startsWith("note que") || lower.startsWith("il faut savoir") ->
                BeliefRevision.evaluate(learning, "enseignement", userText, .9, "enseignement")
            " est " in lower && lower.length in 10..200 ->
                BeliefRevision.evaluate(learning, lower.substringBefore(" est ").takeLast(40).trim(), userText, .75, "interaction")
        }
        learning.addExperience("Utilisateur : $userText", "Observation enregistrée")
        semantic.link(userText.lowercase().split(Regex("\\W+")).filter { it.length > 4 })
        if (consolidation.shouldAutoConsolidate()) consolidation.consolidate()
    }

    /** Indexe un texte dans la mémoire vectorielle (hors thread UI). */
    fun indexVector(text: String, kind: String, embedder: EmbeddingClient?) {
        if (embedder == null || text.isBlank()) return
        val r = embedder.embed(text)
        val vec = r.vector ?: return
        vectors.upsert(text.take(500), vec, kind)
    }

    fun contextFor(query: String, embedder: EmbeddingClient? = null): String {
        val words = query.lowercase().split(Regex("\\W+")).filter { it.length > 2 }.toSet()
        val base = learning.contextFor(query)
        val relatedConcepts = concepts.relevantTo(words)
        val associated = semantic.associate(words.toList())
        val recentRevisions = learning.beliefRevisions().takeLast(3)
        val relevantMemories = memory.relevant(query)
        relevantMemories.forEach { memory.reinforce(it.text) }

        val vectorHits = if (embedder != null) {
            val qr = embedder.embed(query)
            if (qr.vector != null) vectors.search(qr.vector, limit = 5) else emptyList()
        } else emptyList()

        val fewShot = supervised.relevant(query, limit = 3)

        return buildString {
            append(base)
            if (relatedConcepts.isNotEmpty()) {
                append("\nCONCEPTS FORMÉS:\n")
                relatedConcepts.forEach {
                    append("- ${it.name} (${it.exemplarCount} exemples, confiance ${"%.0f".format(it.confidence * 100)}%) : ${it.summary}\n")
                }
            }
            if (associated.isNotEmpty()) append("\nASSOCIATIONS SÉMANTIQUES: ${associated.joinToString(", ")}\n")
            if (vectorHits.isNotEmpty()) {
                append("\nMÉMOIRE VECTORIELLE (similarité):\n")
                vectorHits.forEach { (e, score) ->
                    append("- [${"%.0f".format(score * 100)}%] (${e.kind}) ${e.text.take(180)}\n")
                }
            }
            if (fewShot.isNotEmpty()) {
                append("\nEXEMPLES SUPERVISÉS (corrections passées):\n")
                fewShot.forEach {
                    append("- Q: ${it.input.take(120)}\n  R préférée: ${it.preferred.take(160)}\n")
                }
            }
            if (recentRevisions.isNotEmpty()) {
                append("\nCROYANCES RÉCEMMENT RÉVISÉES:\n")
                recentRevisions.forEach {
                    append("- ${it.subject} : confiance ${"%.0f".format(it.oldConfidence * 100)}%→${"%.0f".format(it.newConfidence * 100)}% (${it.reason})\n")
                }
            }
            if (relevantMemories.isNotEmpty()) {
                append("\nSOUVENIRS PERTINENTS:\n")
                relevantMemories.forEach { append("- ${it.text}\n") }
            }
        }
    }

    fun consolidateNow(): ConsolidationEngine.Report = consolidation.consolidate()

    fun recordCorrection(question: String, preferredAnswer: String) {
        supervised.add(question, preferredAnswer, "correction")
        learning.addExperience("Correction utilisateur sur « ${question.take(60)} »", "Réponse préférée enregistrée")
        learning.practice("apprentissage supervisé", 2)
    }

    private fun shouldRemember(text: String) =
        text.length > 80 || listOf(
            "je m'appelle", "j'aime", "je préfère", "je n'aime pas",
            "souviens-toi", "mon objectif", "je veux"
        ).any { text.lowercase().contains(it) }
}
