package com.nova.ai

import android.content.Context

/**
 * Cycle de consolidation.
 *
 * Relit le lot d'expériences accumulées depuis le dernier cycle et en tire :
 *  - des concepts (regroupement par mots-clés récurrents, brique 2)
 *  - des liens sémantiques renforcés (brique 5)
 *  - une décroissance des croyances et compétences non reconfirmées (briques 3 et 4)
 *  - une évolution de personnalité fondée sur les motifs du lot (brique 6)
 *
 * Peut être déclenché manuellement (bouton "Consolider", simulant un temps de repos) ou
 * automatiquement dès qu'un seuil d'expériences non consolidées est atteint.
 */
class ConsolidationEngine(
    context: Context,
    private val memory: MemoryStore,
    private val learning: LearningStore,
    private val concepts: ConceptStore,
    private val semantic: SemanticMemory,
    private val personality: PersonalityEngine,
    namespace: String = "default"
) {
    private val p = context.getSharedPreferences("nova_consolidation_$namespace", Context.MODE_PRIVATE)

    data class Report(val batchSize: Int, val conceptsFormed: Int, val beliefsRevised: Int, val linksReinforced: Int)

    private val staleBeliefMillis = 14L * 24 * 3600 * 1000  // ~2 semaines sans reconfirmation
    private val staleSkillMillis = 21L * 24 * 3600 * 1000   // ~3 semaines sans pratique
    private val staleMemoryMillis = 30L * 24 * 3600 * 1000  // ~1 mois sans réutilisation

    fun unconsolidatedCount(): Int = (learning.experiences().size - p.getInt("consolidated_up_to", 0)).coerceAtLeast(0)

    fun shouldAutoConsolidate(threshold: Int = 6): Boolean = unconsolidatedCount() >= threshold

    fun lastConsolidation(): Long = p.getLong("last_consolidation", 0)

    fun consolidate(): Report {
        val all = learning.experiences()
        val from = p.getInt("consolidated_up_to", 0).coerceIn(0, all.size)
        val batch = all.subList(from, all.size)
        if (batch.isEmpty()) return Report(0, 0, 0, 0)

        val revisionsBefore = learning.beliefRevisions().size
        var conceptsFormed = 0
        var linksReinforced = 0

        clusterByKeyword(batch).forEach { (keyword, group) ->
            if (group.size >= 2) {
                val before = concepts.all().size
                val summary = "Motif récurrent autour de « $keyword » observé dans ${group.size} expériences : " +
                    group.take(3).joinToString(" ; ") { it.event.take(60) }
                concepts.upsert(keyword.replaceFirstChar { it.uppercase() }, summary, group.flatMap { keywordsOf(it.event) }.distinct())
                if (concepts.all().size > before) conceptsFormed++
                semantic.link(keywordsOf(group.joinToString(" ") { it.event }))
                linksReinforced++
            }
        }

        personality.developFromExperience(batch)

        val now = System.currentTimeMillis()
        learning.decayStaleBeliefs(now, staleBeliefMillis)
        learning.decaySkills(now, staleSkillMillis)
        memory.decayAndPrune(now, staleMemoryMillis)

        p.edit().putInt("consolidated_up_to", all.size).putLong("last_consolidation", now).apply()
        return Report(batch.size, conceptsFormed, learning.beliefRevisions().size - revisionsBefore, linksReinforced)
    }

    private fun keywordsOf(text: String) = text.lowercase().split(Regex("\\W+")).filter { it.length > 4 }

    private fun clusterByKeyword(batch: List<Experience>): Map<String, List<Experience>> {
        val freq = mutableMapOf<String, MutableList<Experience>>()
        batch.forEach { e -> keywordsOf(e.event).distinct().forEach { k -> freq.getOrPut(k) { mutableListOf() }.add(e) } }
        return freq.filter { it.value.size >= 2 }.entries.sortedByDescending { it.value.size }.take(5).associate { it.key to it.value }
    }
}
