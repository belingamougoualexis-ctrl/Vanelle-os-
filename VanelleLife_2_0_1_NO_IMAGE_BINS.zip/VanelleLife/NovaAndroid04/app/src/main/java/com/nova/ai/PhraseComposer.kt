package com.nova.ai

/**
 * Compose des phrases françaises correctes à partir des connaissances / souvenirs,
 * sans LLM cloud.
 *
 * Sources de formulation :
 * 1. Phrases entières déjà validées (corrections supervisées, leçons)
 * 2. Faits stockés comme phrases complètes → réutilisés tels quels
 * 3. Gabarits FR (sujet + fait, réponse à une question, souvenir…)
 * 4. Patterns extraits des expériences passées
 */
object PhraseComposer {

    fun composeAnswer(
        query: String,
        displayName: String,
        know: List<Knowledge>,
        mems: List<Memory>,
        concepts: List<Concept>,
        supervisedPreferred: String? = null
    ): String {
        // Phrase déjà validée par l'utilisateur = meilleure formulation possible
        if (!supervisedPreferred.isNullOrBlank()) {
            return ensureSentence(supervisedPreferred.trim())
        }

        val q = query.lowercase().trim()
        val parts = mutableListOf<String>()

        // Faits : si le fait est déjà une phrase, on la garde ; sinon gabarit
        know.take(2).forEach { k ->
            parts.add(factToSentence(k, q))
        }

        if (parts.isEmpty() && mems.isNotEmpty()) {
            parts.add(memoryToSentence(mems.first(), q))
        }

        if (concepts.isNotEmpty() && parts.size < 2) {
            val c = concepts.first()
            val summary = c.summary.trim()
            parts.add(
                when {
                    summary.length > 15 -> ensureSentence(summary)
                    else -> "Je relie ça au concept « ${c.name} »."
                }
            )
        }

        if (parts.isEmpty()) return ""

        return joinSentences(parts)
    }

    private fun factToSentence(k: Knowledge, query: String): String {
        val fact = k.fact.trim().trimEnd('.', '!', '?')
        val subject = k.subject.trim()

        // Le fait est déjà une phrase complète
        if (looksLikeFullSentence(fact)) {
            return ensureSentence(fact)
        }

        // Questions types
        when {
            isWhatQuestion(query) || isWhoQuestion(query) -> {
                return when {
                    subject.isNotBlank() && !fact.contains(subject, true) ->
                        ensureSentence("$subject : $fact")
                    else -> ensureSentence(fact)
                }
            }
            isWhereQuestion(query) ->
                return ensureSentence(if (fact.startsWith("à ", true) || fact.startsWith("en ", true)) fact else "C'est à $fact")
            isWhyQuestion(query) ->
                return ensureSentence(if (fact.startsWith("parce", true)) fact else "Parce que $fact")
            isHowQuestion(query) ->
                return ensureSentence(if (fact.lowercase().startsWith("en ") || fact.lowercase().startsWith("par ")) fact else "Voici comment : $fact")
        }

        // Gabarit générique sujet / fait
        return when {
            subject.equals("identité", true) || subject.equals("préférence", true) ->
                ensureSentence(fact)
            subject.isNotBlank() && !fact.lowercase().contains(subject.lowercase()) ->
                ensureSentence("Pour « $subject », je retiens que $fact")
            else -> ensureSentence(fact)
        }
    }

    private fun memoryToSentence(m: Memory, query: String): String {
        val t = m.text.trim()
        if (looksLikeFullSentence(t)) return ensureSentence(t)
        return ensureSentence("Je me souviens que $t")
    }

    /** Extrait des modèles de phrases depuis les corrections (pour enrichir plus tard). */
    fun phrasePatternsFrom(supervised: List<SupervisedPair>): List<String> =
        supervised.map { ensureSentence(it.preferred.trim()) }.filter { it.length in 8..200 }.distinct()

    fun ensureSentence(text: String): String {
        var t = text.trim().replace(Regex("\\s+"), " ")
        if (t.isEmpty()) return t
        // Majuscule initiale
        t = t[0].uppercaseChar() + t.substring(1)
        // Ponctuation finale
        if (t.last() !in charArrayOf('.', '!', '?', '…')) t += "."
        return t
    }

    private fun joinSentences(parts: List<String>): String {
        val cleaned = parts.map { ensureSentence(it) }.distinct()
        return when (cleaned.size) {
            0 -> ""
            1 -> cleaned[0]
            2 -> cleaned[0].trimEnd('.') + ". " + cleaned[1]
            else -> cleaned.take(3).joinToString(" ")
        }
    }

    private fun looksLikeFullSentence(s: String): Boolean {
        val t = s.trim()
        if (t.length < 8) return false
        val startsOk = t[0].isUpperCase() || t.startsWith("je ", true) || t.startsWith("c'est", true)
        val hasVerbHint = listOf(
            " est ", " sont ", " suis ", " a ", " ont ", " ai ", " suis",
            " c'est", " j'", " je ", " tu ", " il ", " elle ", " on ", " nous ", " vous "
        ).any { t.lowercase().contains(it) }
        return startsOk || hasVerbHint || t.endsWith('.') || t.endsWith('!')
    }

    private fun isWhatQuestion(q: String) =
        listOf("qu'est", "c'est quoi", "quoi", "quel", "quelle", "que sais").any { q.contains(it) }

    private fun isWhoQuestion(q: String) =
        listOf("qui est", "c'est qui", "qui es", "qui suis").any { q.contains(it) }

    private fun isWhereQuestion(q: String) =
        listOf("où ", "ou est", "où est", "où se").any { q.contains(it) }

    private fun isWhyQuestion(q: String) =
        listOf("pourquoi", "pour quelle raison").any { q.contains(it) }

    private fun isHowQuestion(q: String) =
        listOf("comment ").any { q.contains(it) }
}
