package com.nova.ai

import android.content.Context
import android.net.Uri
import com.nova.ai.platform.*
import org.json.JSONObject
import java.util.UUID

/** Model Lab: creates reproducible training projects and only claims progress when a real runtime reports it. */
class ModelLab(private val context: Context, private val store: AIStudioStore) {
    private val datasets=DatasetManager(context)
    private val jobs=JobManager(context)
    data class Hardware(val ramMb:Long,val cpuCores:Int,val abi:String,val freeMb:Long,val sdk:Int,val nnapi:Boolean)
    fun hardware():Hardware { val h=HardwareInspector.read(context);return Hardware(h.totalRamMb,h.cpuCores,h.abis.firstOrNull()? :"unknown",h.freeRamMb,h.sdk,h.hasNnapi) }
    fun createProject(aiId:String,modality:String,architecture:String,resolution:String,fps:Int,epochs:Int,batch:Int,dataset:Uri?):AIStudioStore.ModelProject { require(modality=="image"||modality=="video");require(fps in 1..60);require(epochs>0);require(batch>0);val p=AIStudioStore.ModelProject(UUID.randomUUID().toString(),aiId,modality,architecture,resolution,fps,epochs,batch,dataset?.toString()? : "","","draft",0,System.currentTimeMillis());store.saveProject(p);return p }
    fun inspectDataset(uris:List<Uri>)=datasets.inspect(uris)
    fun capabilityMessage(p:AIStudioStore.ModelProject):String { val h=hardware(); return when { p.modality=="video"&&h.ramMb<8192 -> "Entraînement vidéo depuis zéro déconseillé sur cet appareil (${h.ramMb} Mo RAM). Connecte une machine GPU personnelle.";p.modality=="image"&&h.ramMb<4096 -> "Entraînement image depuis zéro déconseillé sur cet appareil (${h.ramMb} Mo RAM).";else->"Configuration vérifiée. Aucun entraînement n'est lancé tant qu'un moteur ML réel n'est pas disponible." } }
    fun validateTrainingConfig(config:TrainingConfig){config.validate()}
    fun availableTrainingRuntime(modality:String)=TrainingRuntimeStatus.describe(context,modality)
    fun enqueueRealTraining(projectId:String)=jobs.enqueueTraining(projectId)
    fun buildRemotePayload(p:AIStudioStore.ModelProject)=JSONObject().apply{put("schemaVersion",AIArchitecture.SCHEMA_VERSION);put("projectId",p.id);put("aiId",p.aiId);put("modality",p.modality);put("architecture",p.architecture);put("resolution",p.resolution);put("fps",p.fps);put("epochs",p.epochs);put("batchSize",p.batchSize);put("datasetUri",p.datasetUri)}
    fun submitToOwnServer(endpoint:String,p:AIStudioStore.ModelProject,token:String?):RemoteTrainingClient.Result { CapabilityPolicy.validateExternalEndpoint(endpoint);return RemoteTrainingClient.submit(endpoint,buildRemotePayload(p),token) }
}
