package com.nova.ai.platform

import android.content.Context
import androidx.work.*
import com.nova.ai.AIStudioStore
import java.util.UUID
import java.util.concurrent.TimeUnit

/** Durable job queue. Workers only report progress returned by a real runtime. */
class JobManager(private val context:Context){
    fun enqueueTraining(projectId:String):UUID {
        val req=OneTimeWorkRequestBuilder<TrainingWorker>().setInputData(workDataOf("projectId" to projectId)).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,10,TimeUnit.SECONDS).build()
        WorkManager.getInstance(context).enqueueUniqueWork("training-$projectId",ExistingWorkPolicy.KEEP,req);return req.id
    }
}
class TrainingWorker(appContext:Context,params:WorkerParameters):CoroutineWorker(appContext,params){
    override suspend fun doWork():Result {
        val projectId=inputData.getString("projectId") ?: return Result.failure(workDataOf("error" to "projectId manquant"))
        val store=AIStudioStore(applicationContext);var p:AIStudioStore.ModelProject?=null;for(profile in store.all()){p=store.projects(profile.id).firstOrNull{it.id==projectId};if(p!=null)break};val project=p ?: return Result.failure(workDataOf("error" to "Projet introuvable: $projectId"))
        val db=PlatformDatabase(applicationContext);db.upsertJob(id.toString(),project.aiId,"training","running",0,"Recherche d'un runtime réel")
        setProgress(workDataOf("state" to "RUNNING","progress" to 0,"projectId" to projectId))
        val config=TrainingConfig(architecture=project.architecture,resolution=project.resolution,fps=project.fps,epochs=project.epochs,batchSize=project.batchSize)
        config.validate()
        val runtime=TrainingRuntimeRegistry.find(applicationContext,project.modality,config)
            ?: return Result.failure(workDataOf("error" to "Aucun runtime ML réel compatible n'est installé pour ${project.modality}."))
        val request=TrainingRequest(project.id,project.modality,project.datasetUri,project.outputUri.ifBlank{applicationContext.filesDir.resolve("checkpoints/${project.id}").absolutePath},config)
        val result=runtime.train(applicationContext,request,object:TrainingRuntime.Listener{
            override fun onProgress(progress:Int,step:Long,loss:Double?){db.upsertJob(id.toString(),project.aiId,"training","running",progress,"step=$step loss=${loss ?: "n/a"}");setProgress(workDataOf("state" to "RUNNING","progress" to progress,"step" to step,"loss" to (loss ?: -1.0)))}
            override fun onCheckpoint(path:String){db.upsertJob(id.toString(),project.aiId,"training","checkpoint",0,"checkpoint=$path")}
            override fun onMessage(message:String){db.upsertJob(id.toString(),project.aiId,"training","running",0,message)}
        })
        return if(result.success){project.status="completed";project.progress=100;project.lastCheckpoint=result.checkpoint.orEmpty();store.saveProject(project);db.upsertJob(id.toString(),project.aiId,"training","completed",100,"Entraînement terminé par ${runtime.id}");Result.success(workDataOf("checkpoint" to (result.checkpoint ?: "")))}else{project.status="failed";store.saveProject(project);db.upsertJob(id.toString(),project.aiId,"training","failed",0,result.error ?: "runtime failure");Result.failure(workDataOf("error" to (result.error ?: "Entraînement échoué")))}
    }
}
