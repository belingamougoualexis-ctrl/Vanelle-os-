package com.nova.ai.platform

/** Chooses a real execution path. No fallback silently fabricates output. */
class GenerationRouter(private val providers:ProviderRegistry, private val models:ModelRegistry){
    data class Route(val execution:AIArchitecture.Execution,val providerId:String?=null,val modelId:String?=null,val reason:String)
    fun route(modality:String):Route { models.all().firstOrNull{it.modality.equals(modality,true)}?.let{return Route(AIArchitecture.Execution.LOCAL,modelId=it.id,reason="Modèle local enregistré")}; providers.all().firstOrNull{it.enabled&&it.capabilities.contains(modality.lowercase())}?.let{return Route(AIArchitecture.Execution.EXTERNAL_API,providerId=it.id,reason="Provider externe configuré")};return Route(AIArchitecture.Execution.LOCAL,reason="Aucun moteur disponible : configuration requise") }
}
