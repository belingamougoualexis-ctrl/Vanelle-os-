package com.nova.ai

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Téléchargeur de modèles : reprise .part + Range, contrôle d'espace. */
object ModelDownloader {
    data class ModelSpec(
        val id: String,
        val label: String,
        val url: String,
        val fileName: String,
        val approxMb: Int,
        val sha256: String? = null
    )

    val CATALOG = listOf(
        ModelSpec(
            "embed_minilm",
            "Embeddings MiniLM-L6 (INT8) — recherche mémoire",
            "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/onnx/model_qint8_arm64.onnx",
            "all-minilm-l6-v2-qint8.onnx",
            23
        ),
        ModelSpec(
            "embed_tokenizer",
            "Tokenizer MiniLM (requis avec embeddings)",
            "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/tokenizer.json",
            "minilm-tokenizer.json",
            1
        ),
        ModelSpec(
            "llm_gemma1b",
            "Gemma-3 1B IT Q4 — LLM local le plus léger (MediaPipe)",
            "https://huggingface.co/litert-community/Gemma3-1B-IT/resolve/main/gemma3-1b-it-q4.task",
            "gemma3-1b-it-q4.task",
            550
        )
    )

    fun modelDir(context: Context) = File(context.filesDir, "models").also { it.mkdirs() }
    fun fileFor(context: Context, spec: ModelSpec) = File(modelDir(context), spec.fileName)

    fun isReady(context: Context, id: String): Boolean {
        val s = CATALOG.find { it.id == id } ?: return false
        if (s.url.isBlank()) return false
        val f = fileFor(context, s)
        return f.isFile && f.length() > 10_000L &&
            (s.sha256.isNullOrBlank() || sha256(f).equals(s.sha256, true))
    }

    fun embeddingsReady(context: Context) =
        isReady(context, "embed_minilm") && isReady(context, "embed_tokenizer")

    fun download(context: Context, spec: ModelSpec, onProgress: (Int) -> Unit): String? {
        if (spec.url.isBlank()) return "URL manquante pour ${spec.id}"
        val dest = fileFor(context, spec)
        val part = File(dest.absolutePath + ".part")
        val already = if (part.isFile) part.length() else 0L
        val needBytes = (spec.approxMb.toLong() * 1024L * 1024L) - already
        if (needBytes > 0) {
            val free = context.filesDir.usableSpace
            if (free < needBytes + 20L * 1024 * 1024) {
                return "Espace insuffisant (~${spec.approxMb} Mo requis, ${free / (1024 * 1024)} Mo libres). Libère de l'espace puis rouvre l'app : le téléchargement reprendra."
            }
        }
        return try {
            var offset = if (part.isFile) part.length() else 0L
            var conn = (URL(spec.url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 30_000
                readTimeout = 120_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "VanelleLife/2.0")
            }
            if (offset > 0) conn.setRequestProperty("Range", "bytes=$offset-")
            conn.connect()
            if (offset > 0 && conn.responseCode == 200) {
                offset = 0
                part.delete()
                conn.disconnect()
                conn = (URL(spec.url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 30_000
                    readTimeout = 120_000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "VanelleLife/2.0")
                }
                conn.connect()
            }
            require(conn.responseCode in 200..299) { "HTTP ${conn.responseCode}" }
            val total = if (conn.contentLengthLong > 0) conn.contentLengthLong + offset else -1L
            conn.inputStream.use { input ->
                FileOutputStream(part, true).use { out ->
                    val buf = ByteArray(128 * 1024)
                    var done = offset
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        if (n == 0) continue
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress((done * 100 / total).toInt().coerceIn(0, 100))
                    }
                    out.fd.sync()
                }
            }
            conn.disconnect()
            if (spec.sha256 != null && !sha256(part).equals(spec.sha256, true)) {
                part.delete()
                return "SHA-256 incorrect"
            }
            if (dest.exists()) dest.delete()
            require(part.renameTo(dest)) {
                part.copyTo(dest, true)
                part.delete()
            }
            onProgress(100)
            null
        } catch (e: Exception) {
            e.message ?: e.javaClass.simpleName
        }
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val b = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(b)
                if (n < 0) break
                if (n > 0) md.update(b, 0, n)
            }
        }
        return md.digest().joinToString("") { String.format("%02x", it) }
    }
}
