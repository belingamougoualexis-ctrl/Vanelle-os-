package com.nova.ai

import android.content.Context

/**
 * Téléchargement automatique au démarrage — une seule barre 0–100.
 * Reprise via ModelDownloader (.part + Range).
 */
object ModelBootstrap {
    private const val PREFS = "vanelle_bootstrap"
    private const val KEY_DONE = "models_bootstrap_v3_done"

    fun isDone(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_DONE, false)

    fun markDone(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_DONE, true).apply()
    }

    fun reset(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_DONE, false).apply()
    }

    fun run(context: Context, onLine: (line: String, globalPercent: Int) -> Unit): String? {
        val catalog = ModelDownloader.CATALOG.filter { it.url.isNotBlank() }
        val pending = catalog.filter { !ModelDownloader.isReady(context, it.id) }
        if (pending.isEmpty()) {
            markDone(context)
            onLine("Modèles déjà installés", 100)
            return null
        }
        val errors = mutableListOf<String>()
        pending.forEachIndexed { index, spec ->
            val base = (index * 100) / pending.size
            val span = (100 / pending.size).coerceAtLeast(1)
            onLine("${spec.label} · démarrage (${index + 1}/${pending.size})", base)
            val err = ModelDownloader.download(context, spec) { p ->
                onLine("${spec.label} · $p %", (base + span * p / 100).coerceIn(0, 99))
            }
            if (err != null) errors += "${spec.label}: $err"
            else onLine("OK ${spec.label}", ((index + 1) * 100) / pending.size)
        }
        if (errors.isEmpty()) {
            markDone(context)
            onLine("Tous les modèles sont prêts", 100)
            return null
        }
        onLine("Terminé avec erreurs", 100)
        return errors.joinToString("\n")
    }
}
