package com.nova.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class BrainClient(private val endpoint: String, private val apiKey: String, private val model: String) {
    fun ask(system: String, user: String, memories: List<Memory>): String {
        if (apiKey.isBlank()) return "Le cerveau LLM n'est pas configuré. La mémoire locale fonctionne déjà."
        val memoryText = memories.joinToString("\n") { "- ${it.text}" }
        val body = JSONObject().apply {
            put("model", model)
            put("messages", JSONArray().apply {
                put(JSONObject().apply { put("role", "system"); put("content", "$system\n\nSouvenirs pertinents:\n$memoryText") })
                put(JSONObject().apply { put("role", "user"); put("content", user) })
            })
            put("temperature", 0.7)
        }.toString()

        val c = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $apiKey")
        }
        return try {
            c.outputStream.use { it.write(body.toByteArray()) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val text = stream.bufferedReader().use { it.readText() }
            if (c.responseCode !in 200..299) "Erreur HTTP ${c.responseCode} du cerveau."
            else JSONObject(text).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
        } catch (e: Exception) {
            "Connexion au cerveau impossible : ${e.javaClass.simpleName}."
        } finally { c.disconnect() }
    }
}
