package com.nova.ai

import android.content.Context
import org.json.JSONObject

/**
 * Mémoire sémantique légère : un graphe pondéré où les mots-clés qui apparaissent ensemble
 * dans une même expérience voient leur lien renforcé. La récupération se fait par activation
 * propagée sur quelques sauts, ce qui permet de retrouver des notions associées même sans
 * correspondance de mot exacte — une approche relationnelle plutôt que des embeddings vectoriels,
 * volontairement simple pour rester locale et sans dépendance externe.
 */
class SemanticMemory(context: Context, namespace: String = "default") {
    private val p = context.getSharedPreferences("nova_semantic_$namespace", Context.MODE_PRIVATE)

    private fun graph(): MutableMap<String, MutableMap<String, Double>> {
        val o = JSONObject(p.getString("graph", "{}") ?: "{}")
        val map = mutableMapOf<String, MutableMap<String, Double>>()
        o.keys().forEach { k ->
            val edges = o.getJSONObject(k)
            val inner = mutableMapOf<String, Double>()
            edges.keys().forEach { k2 -> inner[k2] = edges.getDouble(k2) }
            map[k] = inner
        }
        return map
    }

    private fun save(g: Map<String, Map<String, Double>>) {
        val o = JSONObject()
        g.forEach { (k, edges) -> val eo = JSONObject(); edges.forEach { (k2, w) -> eo.put(k2, w) }; o.put(k, eo) }
        p.edit().putString("graph", o.toString()).apply()
    }

    /** Renforce les liens entre tous les mots-clés apparus ensemble dans un même contexte. */
    fun link(words: List<String>) {
        val clean = words.map { it.lowercase().trim() }.filter { it.length > 3 }.distinct().take(15)
        if (clean.size < 2) return
        val g = graph()
        for (a in clean) for (b in clean) {
            if (a == b) continue
            val edges = g.getOrPut(a) { mutableMapOf() }
            edges[b] = ((edges[b] ?: 0.0) + 0.1).coerceAtMost(5.0)
        }
        save(g)
    }

    /** Active un ensemble de mots-clés et propage l'activation sur le graphe pour trouver des notions reliées indirectement. */
    fun associate(seed: List<String>, maxHops: Int = 2, limit: Int = 8): List<String> {
        val g = graph()
        val seedSet = seed.map { it.lowercase().trim() }.filter { it.isNotBlank() }.toSet()
        if (seedSet.isEmpty()) return emptyList()
        var frontier: Map<String, Double> = seedSet.associateWith { 1.0 }
        val cumulative = mutableMapOf<String, Double>()
        repeat(maxHops) {
            val next = mutableMapOf<String, Double>()
            frontier.forEach { (node, energy) ->
                g[node]?.forEach { (neighbor, weight) ->
                    if (neighbor !in seedSet) {
                        val gain = energy * weight * 0.3
                        next[neighbor] = (next[neighbor] ?: 0.0) + gain
                        cumulative[neighbor] = (cumulative[neighbor] ?: 0.0) + gain
                    }
                }
            }
            frontier = next
        }
        return cumulative.entries.sortedByDescending { it.value }.take(limit).map { it.key }
    }
}
