package com.nova.ai.platform

import java.net.HttpURLConnection
import java.net.URL

object ProviderHealth {
    data class Check(val ok:Boolean,val code:Int,val latencyMs:Long,val message:String)
    fun ping(endpoint:String, timeoutMs:Int=10_000):Check { val started=System.currentTimeMillis(); return try { CapabilityPolicy.validateExternalEndpoint(endpoint);val c=URL(endpoint).openConnection() as HttpURLConnection;c.requestMethod="HEAD";c.connectTimeout=timeoutMs;c.readTimeout=timeoutMs;val code=c.responseCode;Check(code in 200..499,code,System.currentTimeMillis()-started,"HTTP $code") } catch(e:Exception){Check(false,-1,System.currentTimeMillis()-started,e.message ?: "Connexion impossible")} }
}
