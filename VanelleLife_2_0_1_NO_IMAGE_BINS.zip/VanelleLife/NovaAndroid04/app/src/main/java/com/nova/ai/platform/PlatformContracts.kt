package com.nova.ai.platform

import android.content.Context

enum class Modality { CHAT, VISION, IMAGE, VIDEO, AUDIO, SPEECH_TO_TEXT, TEXT_TO_SPEECH, EMBEDDING }
enum class ExecutionMode { LOCAL, PERSONAL_PC, PERSONAL_SERVER, CLOUD, API, AUTO }

data class RuntimeCapability(
    val runtimeId: String,
    val displayName: String,
    val modalities: Set<Modality>,
    val executionMode: ExecutionMode,
    val available: Boolean,
    val reason: String? = null
)

data class GenerationRequest(
    val aiId: String,
    val modality: Modality,
    val prompt: String,
    val modelId: String? = null,
    val seed: Long? = null,
    val width: Int? = null,
    val height: Int? = null,
    val frames: Int? = null,
    val fps: Int? = null
)

data class GenerationResult(
    val success: Boolean,
    val outputPath: String? = null,
    val remoteJobId: String? = null,
    val providerId: String? = null,
    val modelId: String? = null,
    val executionMode: ExecutionMode? = null,
    val measuredMs: Long = 0,
    val errorCode: String? = null,
    val errorMessage: String? = null
)

interface GenerationRuntime {
    val id: String
    val displayName: String
    val mode: ExecutionMode
    fun capabilities(context: Context): List<RuntimeCapability>
    fun supports(context: Context, request: GenerationRequest): Boolean
    fun generate(context: Context, request: GenerationRequest): GenerationResult
}

data class TrainingConfig(
    val epochs: Int,
    val batchSize: Int,
    val learningRate: Double,
    val seed: Long? = null
)

data class TrainingRequest(
    val aiId: String,
    val modality: Modality,
    val datasetId: String,
    val modelId: String,
    val config: TrainingConfig
)

data class TrainingResult(
    val success: Boolean,
    val jobId: String? = null,
    val checkpointPath: String? = null,
    val errorCode: String? = null,
    val errorMessage: String? = null
)

interface TrainingRuntime {
    val id: String
    val displayName: String
    fun supports(context: Context, request: TrainingRequest): Boolean
    fun train(context: Context, request: TrainingRequest, listener: Listener): TrainingResult

    interface Listener {
        fun onProgress(progress: Float)
        fun onLog(message: String)
        fun onCheckpoint(path: String)
    }
}

object RuntimeRegistry {
    private val generation = mutableListOf<GenerationRuntime>()
    private val training = mutableListOf<TrainingRuntime>()

    fun registerGeneration(runtime: GenerationRuntime) = synchronized(generation) {
        if (generation.none { it.id == runtime.id }) generation += runtime
    }

    fun registerTraining(runtime: TrainingRuntime) = synchronized(training) {
        if (training.none { it.id == runtime.id }) training += runtime
    }

    fun generationRuntimes(): List<GenerationRuntime> = synchronized(generation) { generation.toList() }
    fun trainingRuntimes(): List<TrainingRuntime> = synchronized(training) { training.toList() }

    fun findGeneration(context: Context, request: GenerationRequest, mode: ExecutionMode? = null): GenerationRuntime? =
        generationRuntimes().firstOrNull {
            (mode == null || it.mode == mode) &&
                runCatching { it.supports(context, request) }.getOrDefault(false)
        }

    fun findTraining(context: Context, request: TrainingRequest): TrainingRuntime? =
        trainingRuntimes().firstOrNull {
            runCatching { it.supports(context, request) }.getOrDefault(false)
        }
}

object CapabilityService {
    fun all(context: Context): List<RuntimeCapability> =
        RuntimeRegistry.generationRuntimes().flatMap { runCatching { it.capabilities(context) }.getOrDefault(emptyList()) }
}

object HonestExecution {
    fun unavailable(modality: Modality, message: String): GenerationResult =
        GenerationResult(
            success = false,
            errorCode = "RUNTIME_UNAVAILABLE",
            errorMessage = "$modality: $message"
        )
}
