package com.nova.ai.crash

import android.content.Context
import android.util.Log
import com.nova.ai.legal.ConsentStore

/**
 * Sentry production-ready :
 * - DSN via prefs (UI) ou BuildConfig.SENTRY_DSN
 * - Init uniquement si opt-in crash + DSN non vide
 */
object SentryBridge {
    private const val TAG = "VanelleSentry"
    private const val PREFS = "vanelle_sentry"
    private const val KEY_DSN = "dsn"
    private var initialized = false

    fun setDsn(context: Context, dsn: String) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_DSN, dsn.trim()).apply()
    }

    fun getDsn(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_DSN, "") ?: ""
        if (prefs.isNotBlank()) return prefs
        return try {
            val f = Class.forName("com.nova.ai.BuildConfig").getField("SENTRY_DSN")
            (f.get(null) as? String).orEmpty()
        } catch (_: Throwable) {
            ""
        }
    }

    fun initIfAllowed(context: Context) {
        if (!ConsentStore(context).crashReportingOptIn()) {
            Log.i(TAG, "Crash opt-in off — Sentry inactif")
            return
        }
        val dsn = getDsn(context)
        if (dsn.isBlank()) {
            Log.i(TAG, "Pas de DSN — traces locales uniquement")
            return
        }
        if (initialized) return
        try {
            val sentryAndroid = Class.forName("io.sentry.android.core.SentryAndroid")
            val optionsConfig = Class.forName("io.sentry.Sentry.OptionsConfiguration")
            // SentryAndroid.init(context) { options -> options.dsn = dsn }
            val proxy = java.lang.reflect.Proxy.newProxyInstance(
                optionsConfig.classLoader,
                arrayOf(optionsConfig)
            ) { _, method, args ->
                if (method.name == "configure" && args != null && args.isNotEmpty()) {
                    val options = args[0]
                    options.javaClass.getMethod("setDsn", String::class.java).invoke(options, dsn)
                    try {
                        options.javaClass.getMethod("setTracesSampleRate", java.lang.Double.TYPE)
                            .invoke(options, 0.2)
                    } catch (_: Throwable) { }
                }
                null
            }
            val init = sentryAndroid.methods.first {
                it.name == "init" && it.parameterTypes.size == 2 &&
                    it.parameterTypes[0].name.contains("Context")
            }
            init.invoke(null, context.applicationContext, proxy)
            initialized = true
            Log.i(TAG, "Sentry initialisé")
        } catch (e: ClassNotFoundException) {
            Log.i(TAG, "sentry-android absent")
        } catch (t: Throwable) {
            Log.w(TAG, "Init Sentry: ${t.message}")
            // Fallback
            try {
                Class.forName("io.sentry.Sentry").getMethod("init", String::class.java).invoke(null, dsn)
                initialized = true
            } catch (t2: Throwable) {
                Log.w(TAG, "Fallback Sentry: ${t2.message}")
            }
        }
    }
}
