package com.nova.ai.platform

import android.content.Context
import java.io.File

/** Real device/model compatibility checks; no generic GPU=true assumptions. */
object ModelCompatibility {
    data class Result(val compatible: Boolean, val level: String, val reasons: List<String>, val availableRamMb: Long)
    fun check(context: Context, model: ModelArtifact): Result {
        val h = HardwareInspector.read(context)
        val f = File(model.path)
        val reasons = mutableListOf<String>()
        if (!f.exists()) reasons += "Fichier du modèle absent"
        if (model.sizeBytes > 0 && h.totalRamMb * 1024L * 1024L < model.sizeBytes * 2L) reasons += "RAM probablement insuffisante pour charger le modèle"
        if (model.sha256.isBlank()) reasons += "SHA-256 manquant"
        val level = when { reasons.any { it.contains("absent") } -> "red"; reasons.isNotEmpty() -> "yellow"; else -> "green" }
        return Result(reasons.none { it.contains("absent") }, level, reasons, h.availRamMb)
    }
}
