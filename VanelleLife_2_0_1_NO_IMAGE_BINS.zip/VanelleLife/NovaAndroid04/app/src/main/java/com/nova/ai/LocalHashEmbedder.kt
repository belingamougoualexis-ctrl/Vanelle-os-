package com.nova.ai

/**
 * Embeddings 100 % locaux, sans modèle lourd ni clé API.
 * Hashing de n-grammes → vecteur dense normalisé (dim 384, compatible MiniLM).
 * Qualité inférieure à all-MiniLM, mais fonctionne offline, gratuit, illimité.
 * Quand le modèle ONNX MiniLM est téléchargé + runtime branché, on pourra le remplacer.
 */
object LocalHashEmbedder {
    const val DIM = 384

    fun embed(text: String): FloatArray {
        val vec = FloatArray(DIM)
        val normed = text.lowercase().trim()
        if (normed.isEmpty()) return vec

        // unigrams + bigrams de tokens
        val tokens = normed.split(Regex("\\W+")).filter { it.length > 1 }
        fun add(token: String, weight: Float) {
            var h = token.hashCode()
            for (k in 0 until 3) {
                val idx = Math.floorMod(h, DIM)
                val sign = if ((h and 1) == 0) 1f else -1f
                vec[idx] += sign * weight
                h = h * 31 + k
            }
        }
        tokens.forEach { add(it, 1f) }
        for (i in 0 until tokens.size - 1) add(tokens[i] + "_" + tokens[i + 1], 0.6f)

        // char trigrams (robuste orthographe)
        val compact = normed.replace(Regex("\\s+"), " ")
        for (i in 0 until compact.length - 2) {
            add("c:" + compact.substring(i, i + 3), 0.25f)
        }

        var sumSq = 0.0
        for (v in vec) sumSq += v * v
        val n = kotlin.math.sqrt(sumSq).toFloat().coerceAtLeast(1e-6f)
        for (i in vec.indices) vec[i] /= n
        return vec
    }
}
