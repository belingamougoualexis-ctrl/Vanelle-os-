package com.nova.ai.platform

import android.content.Context

object PlatformBootstrap {
    @Volatile private var initialized = false

    fun initialize(context: Context) {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            RuntimeRegistry.registerGeneration(LocalCapabilityRuntime())
            initialized = true
        }
    }
}
