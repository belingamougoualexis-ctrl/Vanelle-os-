package com.nova.ai.platform

import android.content.Context

class TrainingService(private val context: Context) {
    fun train(
        request: TrainingRequest,
        listener: TrainingRuntime.Listener
    ): TrainingResult {
        val runtime = RuntimeRegistry.findTraining(context, request)
            ?: return TrainingResult(
                success = false,
                errorCode = "TRAINING_RUNTIME_UNAVAILABLE",
                errorMessage = "Aucun moteur d'entraînement réel compatible n'est disponible."
            )

        return runCatching {
            runtime.train(context, request, listener)
        }.getOrElse {
            TrainingResult(
                success = false,
                errorCode = "TRAINING_RUNTIME_EXCEPTION",
                errorMessage = it.message ?: "Le moteur d'entraînement réel a échoué."
            )
        }
    }
}
