package com.nova.ai.platform

data class ModelCard(
    val id: String,
    val name: String,
    val version: String,
    val modality: Modality,
    val format: String,
    val parameterCount: Long?,
    val fileSizeBytes: Long?,
    val minRamBytes: Long?,
    val minVramBytes: Long?,
    val runtimeIds: List<String>,
    val license: String,
    val sha256: String,
    val source: String
)

data class ModelCompatibility(
    val compatible: Boolean,
    val reasons: List<String>
)

object ModelCompatibilityEngine {
    fun check(card: ModelCard, ramBytes: Long, vramBytes: Long = 0): ModelCompatibility {
        val reasons = mutableListOf<String>()
        if (card.minRamBytes != null && ramBytes < card.minRamBytes) reasons += "RAM insuffisante"
        if (card.minVramBytes != null && vramBytes < card.minVramBytes) reasons += "VRAM insuffisante"
        return ModelCompatibility(reasons.isEmpty(), reasons)
    }
}
