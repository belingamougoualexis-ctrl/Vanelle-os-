package com.nova.ai.platform

import com.nova.ai.AIStudioStore
import org.json.JSONObject

object TrainingManifest {
    fun create(project:AIStudioStore.ModelProject, datasetSha256:String, itemCount:Int):JSONObject=JSONObject().apply{
        put("schema",1);put("projectId",project.id);put("aiId",project.aiId);put("modality",project.modality);put("architecture",project.architecture);put("resolution",project.resolution);put("fps",project.fps);put("epochs",project.epochs);put("batchSize",project.batchSize);put("datasetSha256",datasetSha256);put("itemCount",itemCount);put("createdAt",System.currentTimeMillis())
    }
}
