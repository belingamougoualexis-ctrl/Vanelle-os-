package com.nova.ai.platform

data class UsageEvent(
    val aiId: String,
    val modality: Modality,
    val executionMode: ExecutionMode,
    val modelId: String?,
    val durationMs: Long,
    val inputUnits: Long = 0,
    val outputUnits: Long = 0,
    val estimatedCostMicros: Long? = null,
    val timestamp: Long = System.currentTimeMillis()
)

interface UsageStore {
    fun record(event: UsageEvent)
    fun total(aiId: String): Long
}
