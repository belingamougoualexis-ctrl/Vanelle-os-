package com.nova.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Mémoire sémantique vectorielle : stocke des paires (texte, embedding) et
 * récupère les plus proches par similarité cosinus.
 * Complète le graphe de cooccurrence (SemanticMemory) sans le remplacer.
 */
data class VectorEntry(
    val text: String,
    val vector: FloatArray,
    val timestamp: Long = System.currentTimeMillis(),
    val kind: String = "memory" // memory | concept | knowledge | experience
)

class VectorMemory(context: Context, namespace: String = "default") {
    private val p = context.getSharedPreferences("nova_vectors_$namespace", Context.MODE_PRIVATE)
    private val maxEntries = 400

    fun all(): List<VectorEntry> {
        val a = JSONArray(p.getString("items", "[]") ?: "[]")
        return buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val va = o.getJSONArray("v")
                val vec = FloatArray(va.length()) { j -> va.getDouble(j).toFloat() }
                add(VectorEntry(o.getString("text"), vec, o.optLong("ts", 0), o.optString("kind", "memory")))
            }
        }
    }

    fun size(): Int = all().size

    fun upsert(text: String, vector: FloatArray, kind: String = "memory") {
        if (text.isBlank() || vector.isEmpty()) return
        val list = all().toMutableList()
        val i = list.indexOfFirst { it.text == text }
        val entry = VectorEntry(text, vector, System.currentTimeMillis(), kind)
        if (i >= 0) list[i] = entry else list.add(entry)
        persist(list.takeLast(maxEntries))
    }

    fun search(queryVector: FloatArray, limit: Int = 6, minScore: Float = 0.35f): List<Pair<VectorEntry, Float>> {
        if (queryVector.isEmpty()) return emptyList()
        return all()
            .map { it to EmbeddingClient.cosine(queryVector, it.vector) }
            .filter { it.second >= minScore }
            .sortedByDescending { it.second }
            .take(limit)
    }

    fun clear() {
        p.edit().putString("items", "[]").apply()
    }

    private fun persist(list: List<VectorEntry>) {
        val a = JSONArray()
        list.forEach { e ->
            a.put(JSONObject().apply {
                put("text", e.text)
                put("ts", e.timestamp)
                put("kind", e.kind)
                put("v", JSONArray(e.vector.map { it.toDouble() }))
            })
        }
        p.edit().putString("items", a.toString()).apply()
    }
}
