package com.nova.ai.platform

import android.content.Context

object TrainingRuntimeStatus {
    fun describe(context:Context, modality:String):String {
        val cfg=TrainingConfig()
        val r=TrainingRuntimeRegistry.find(context,modality,cfg)
        return r?.let{"Moteur réel disponible : ${it.displayName}"} ?: "Aucun moteur d'entraînement local installé pour $modality."
    }
}
