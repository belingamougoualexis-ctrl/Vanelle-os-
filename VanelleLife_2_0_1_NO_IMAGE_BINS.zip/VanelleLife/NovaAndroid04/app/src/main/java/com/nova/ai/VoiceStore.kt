package com.nova.ai

import android.content.Context
import android.content.Intent
import android.os.Build
import android.speech.tts.TextToSpeech
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Centre de voix dans l'app :
 * 1) Packs TTS système (FR) via Intent install
 * 2) Téléchargement de packs de voix Hugging Face (métadonnées + échantillons)
 *    stockés dans filesDir/voices — l'APK reste léger.
 *
 * Les packs HF configurent pitch/rate/engine préféré et vérifient la présence
 * de la voix système correspondante. Le pack « français Google » déclenche
 * l'installation des données TTS dans le flux de l'app.
 */
object VoiceStore {

    data class VoicePack(
        val id: String,
        val label: String,
        val description: String,
        val locale: String,
        /** URL fichier optionnel (échantillon ou config), null = pack système uniquement */
        val url: String? = null,
        val fileName: String? = null,
        val approxMb: Int = 0,
        val defaultPitch: Float = 1.0f,
        val defaultRate: Float = 1.0f,
        /** true = nécessite ACTION_INSTALL_TTS_DATA */
        val systemInstall: Boolean = false
    )

    val CATALOG = listOf(
        VoicePack(
            id = "sys_fr_install",
            label = "Français (pack système)",
            description = "Télécharge les données vocales FR du moteur TTS Android (Google/Samsung…). Gratuit, souvent offline.",
            locale = "fr-FR",
            systemInstall = true,
            approxMb = 20
        ),
        VoicePack(
            id = "fr_female_soft",
            label = "FR — douce",
            description = "Voix française, ton légèrement plus aigu, débit calme.",
            locale = "fr-FR",
            url = "https://huggingface.co/rhasspy/piper-voices/resolve/main/fr/fr_FR/siwis/medium/fr_FR-siwis-medium.onnx.json",
            fileName = "fr_siwis_medium.json",
            approxMb = 1,
            defaultPitch = 1.15f,
            defaultRate = 0.95f
        ),
        VoicePack(
            id = "fr_female_siwis",
            label = "FR — Siwis (modèle Piper)",
            description = "Métadonnées Piper Siwis medium (HF). Utilise le TTS système avec ce profil.",
            locale = "fr-FR",
            url = "https://huggingface.co/rhasspy/piper-voices/resolve/main/fr/fr_FR/siwis/medium/MODEL_CARD",
            fileName = "fr_siwis_card.txt",
            approxMb = 1,
            defaultPitch = 1.05f,
            defaultRate = 1.0f
        ),
        VoicePack(
            id = "fr_male_low",
            label = "FR — grave",
            description = "Profil masculin / ton plus bas.",
            locale = "fr-FR",
            defaultPitch = 0.82f,
            defaultRate = 0.95f
        ),
        VoicePack(
            id = "fr_child",
            label = "FR — jeune",
            description = "Ton plus aigu, débit un peu plus rapide.",
            locale = "fr-FR",
            defaultPitch = 1.35f,
            defaultRate = 1.05f
        ),
        VoicePack(
            id = "fr_slow",
            label = "FR — lente (apprentissage)",
            description = "Débit ralenti, idéal pour bien comprendre.",
            locale = "fr-FR",
            defaultPitch = 1.0f,
            defaultRate = 0.75f
        ),
        VoicePack(
            id = "en_us_fallback",
            label = "English (US)",
            description = "Pack anglais si disponible sur l'appareil.",
            locale = "en-US",
            systemInstall = true,
            approxMb = 15
        )
    )

    fun voicesDir(context: Context): File =
        File(context.filesDir, "voices").also { if (!it.exists()) it.mkdirs() }

    fun isDownloaded(context: Context, pack: VoicePack): Boolean {
        if (pack.systemInstall && pack.url == null) {
            // pack système : on considère "téléchargé" si une voix FR est listable
            return true // vérifié dynamiquement ailleurs
        }
        val name = pack.fileName ?: return true
        val f = File(voicesDir(context), name)
        return f.exists() && f.length() > 10L
    }

    fun download(context: Context, pack: VoicePack, onProgress: (Int) -> Unit): String? {
        val url = pack.url ?: return null
        val name = pack.fileName ?: return "Nom de fichier manquant"
        val dest = File(voicesDir(context), name)
        val tmp = File(dest.absolutePath + ".part")
        return try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = true
                connectTimeout = 30_000
                readTimeout = 60_000
                setRequestProperty("User-Agent", "NOVA-Android/0.6")
            }
            conn.connect()
            if (conn.responseCode !in 200..299) {
                return "HTTP ${conn.responseCode}"
            }
            val total = conn.contentLengthLong.coerceAtLeast(1L)
            conn.inputStream.use { input ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(8192)
                    var read = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        out.write(buf, 0, n)
                        read += n
                        onProgress(((read * 100) / total).toInt().coerceIn(0, 100))
                    }
                }
            }
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) {
                tmp.copyTo(dest, overwrite = true)
                tmp.delete()
            }
            onProgress(100)
            null
        } catch (e: Exception) {
            tmp.delete()
            e.message ?: "Échec téléchargement"
        }
    }

    fun toVoiceSettings(pack: VoicePack, voiceName: String = "", languageTag: String = ""): VoiceEngine.VoiceSettings =
        VoiceEngine.VoiceSettings(
            voiceName = voiceName,
            pitch = pack.defaultPitch,
            rate = pack.defaultRate,
            languageTag = languageTag.ifBlank { pack.locale.ifBlank { LanguageCatalog.DEFAULT } }
        )

    fun installTtsDataIntent(): Intent =
        Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)

    fun checkTtsDataIntent(): Intent =
        Intent(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA)
}
