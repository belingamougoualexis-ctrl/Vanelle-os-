package com.nova.ai.llm

import android.content.Context
import com.nova.ai.ModelDownloader
import com.nova.ai.platform.ReadinessState
import com.nova.ai.platform.RuntimeCheck
import java.io.File
import java.util.concurrent.atomic.AtomicReference

/**
 * Runtime MediaPipe / LiteRT LLM via réflexion.
 * - Dépendance optionnelle : com.google.mediapipe:tasks-genai
 * - Modèle le plus léger du catalogue : Gemma-3 1B (~550 Mo) téléchargeable in-app
 * - Si la lib ou le fichier manque → readiness honnête, pas de texte inventé
 */
class MediaPipeLlm : OnDeviceLlm {
    override val id: String = "mediapipe_gemma1b"

    private val engineRef = AtomicReference<Any?>(null)

    override fun readiness(context: Context): RuntimeCheck {
        if (!isMediaPipePresent()) {
            return RuntimeCheck(
                ReadinessState.RUNTIME_MISSING,
                "Lib MediaPipe tasks-genai absente du binaire. Sync Gradle avec la dépendance optionnelle."
            )
        }
        val path = modelPath(context)
        if (path == null) {
            return RuntimeCheck(
                ReadinessState.MODEL_MISSING,
                "Modèle Gemma-3 1B non téléchargé. Ouvre Hub modèles → Télécharger (≈550 Mo)."
            )
        }
        return RuntimeCheck(ReadinessState.READY, "MediaPipe + Gemma-3 1B prêts ($path)")
    }

    override fun generate(context: Context, prompt: String, systemHint: String?): String? {
        if (readiness(context).state != ReadinessState.READY) return null
        return try {
            val path = modelPath(context) ?: return null
            val engine = ensureEngine(context, path) ?: return null
            val full = buildString {
                if (!systemHint.isNullOrBlank()) {
                    append(systemHint.trim())
                    append("\n\n")
                }
                append(prompt.trim())
            }
            invokeGenerate(engine, full)
        } catch (t: Throwable) {
            engineRef.set(null)
            null
        }
    }

    fun release() {
        try {
            engineRef.getAndSet(null)?.let { eng ->
                eng.javaClass.methods.firstOrNull { it.name == "close" && it.parameterCount == 0 }?.invoke(eng)
            }
        } catch (_: Throwable) { }
    }

    private fun modelPath(context: Context): String? {
        // Préférence : id catalogue llm_gemma1b
        val spec = ModelDownloader.CATALOG.find { it.id == "llm_gemma1b" }
        if (spec != null && ModelDownloader.isReady(context, spec.id)) {
            return ModelDownloader.fileFor(context, spec).absolutePath
        }
        // Fallback : tout .task / .bin dans models/
        val dir = ModelDownloader.modelDir(context)
        val f = dir.listFiles()?.firstOrNull {
            it.isFile && it.length() > 50_000_000L &&
                (it.name.endsWith(".task") || it.name.endsWith(".bin") || it.name.endsWith(".litertlm"))
        }
        return f?.absolutePath
    }

    private fun ensureEngine(context: Context, path: String): Any? {
        engineRef.get()?.let { return it }
        synchronized(this) {
            engineRef.get()?.let { return it }
            val created = createEngine(context, path) ?: return null
            engineRef.set(created)
            return created
        }
    }

    private fun createEngine(context: Context, path: String): Any? {
        return try {
            val llmClass = Class.forName("com.google.mediapipe.tasks.genai.llminference.LlmInference")
            val optionsClass = Class.forName("com.google.mediapipe.tasks.genai.llminference.LlmInference\$LlmInferenceOptions")
            val builderMethod = optionsClass.getMethod("builder")
            val builder = builderMethod.invoke(null)
            builder.javaClass.getMethod("setModelPath", String::class.java).invoke(builder, path)
            try {
                builder.javaClass.getMethod("setMaxTokens", Int::class.javaPrimitiveType).invoke(builder, 256)
            } catch (_: Throwable) { }
            try {
                builder.javaClass.getMethod("setTemperature", Float::class.javaPrimitiveType).invoke(builder, 0.7f)
            } catch (_: Throwable) { }
            val options = builder.javaClass.getMethod("build").invoke(builder)
            val create = llmClass.methods.firstOrNull {
                it.name == "createFromOptions" && it.parameterCount == 2
            } ?: return null
            create.invoke(null, context, options)
        } catch (_: Throwable) {
            null
        }
    }

    private fun invokeGenerate(engine: Any, prompt: String): String? {
        val m = engine.javaClass.methods.firstOrNull {
            it.name == "generateResponse" && it.parameterCount == 1
        } ?: return null
        val out = m.invoke(engine, prompt) ?: return null
        return out.toString().trim().ifBlank { null }
    }

    companion object {
        fun isMediaPipePresent(): Boolean = try {
            Class.forName("com.google.mediapipe.tasks.genai.llminference.LlmInference")
            true
        } catch (_: Throwable) {
            false
        }
    }
}
