package com.nova.ai

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.nova.ai.llm.MediaPipeLlm
import com.nova.ai.ImageGenService
import java.util.concurrent.Executors

/**
 * Hub de téléchargement des modèles légers (in-app, sans backend).
 * - Embeddings MiniLM ~24 Mo
 * - Gemma-3 1B ~550 Mo (plus léger des LLM MediaPipe officiels)
 */
class ModelHubActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            setBackgroundColor(0xFF0A0A0A.toInt())
        }
        status = TextView(this).apply {
            setTextColor(0xFF90E0EF.toInt())
            textSize = 14f
            setPadding(0, 0, 0, 24)
        }
        listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val scroll = ScrollView(this).apply { addView(listBox) }
        root.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        ))
        setContentView(root)
        title = "Hub modèles (légers)"
        refresh()
    }

    private fun refresh() {
        listBox.removeAllViews()
        status.text = try {
            val mp = MediaPipeLlm()
            buildString {
                appendLine(mp.readiness(this@ModelHubActivity).message)
                appendLine("MediaPipe LLM lib : ${MediaPipeLlm.isMediaPipePresent()}")
                appendLine(ImageGenService.statusLine(this@ModelHubActivity))
            }
        } catch (e: Exception) {
            e.message ?: "OK"
        }

        ModelDownloader.CATALOG.forEach { spec ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 16, 0, 16)
            }
            val ready = ModelDownloader.isReady(this, spec.id)
            val title = TextView(this).apply {
                setTextColor(0xFFFFFFFF.toInt())
                text = "${spec.label}\n≈ ${spec.approxMb} Mo · ${if (ready) "INSTALLÉ" else "non installé"}"
            }
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = if (ready) 100 else 0
                visibility = if (ready) android.view.View.GONE else android.view.View.VISIBLE
            }
            val btn = Button(this).apply {
                text = when {
                    ready -> "Réinstaller"
                    spec.url.isBlank() -> "Instructions"
                    else -> "Télécharger"
                }
                isEnabled = true
                setOnClickListener {
                    if (spec.url.isBlank()) {
                        Toast.makeText(this@ModelHubActivity, "Pas d'URL pour ce modèle.", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    isEnabled = false
                    text = "Téléchargement…"
                    bar.visibility = android.view.View.VISIBLE
                    executor.execute {
                        val err = ModelDownloader.download(this@ModelHubActivity, spec) { p ->
                            main.post { bar.progress = p }
                        }
                        main.post {
                            isEnabled = true
                            if (err != null) {
                                Toast.makeText(this@ModelHubActivity, err, Toast.LENGTH_LONG).show()
                                text = "Réessayer"
                            } else {
                                Toast.makeText(this@ModelHubActivity, "OK : ${spec.label}", Toast.LENGTH_SHORT).show()
                                refresh()
                            }
                        }
                    }
                }
            }
            val del = Button(this).apply {
                text = "Supprimer"
                isEnabled = ready
                setOnClickListener {
                    ModelDownloader.fileFor(this@ModelHubActivity, spec).delete()
                    Toast.makeText(this@ModelHubActivity, "Supprimé", Toast.LENGTH_SHORT).show()
                    refresh()
                }
            }
            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.START
                addView(btn)
                addView(del)
            }
            row.addView(title)
            row.addView(bar)
            row.addView(actions)
            listBox.addView(row)
        }

        val note = TextView(this).apply {
            setTextColor(0xFFB0BEC5.toInt())
            textSize = 12f
            setPadding(0, 32, 0, 0)
            text = "Les modèles restent dans le stockage privé de l'app.\n" +
                "Aucun backend VanelleLife : téléchargement direct depuis Hugging Face.\n" +
                "Gemma-3 1B est le LLM officiel le plus léger supporté MediaPipe (~550 Mo).\n" +
                "Embeddings MiniLM (~24 Mo) améliorent la recherche mémoire locale."
        }
        listBox.addView(note)
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
