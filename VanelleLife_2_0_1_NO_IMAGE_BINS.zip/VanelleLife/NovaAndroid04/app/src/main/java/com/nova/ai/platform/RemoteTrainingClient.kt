package com.nova.ai.platform

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Protocol client for a training server owned/authorized by the user. */
object RemoteTrainingClient {
    data class Result(val ok:Boolean,val code:Int,val body:String)
    fun submit(endpoint:String, payload:JSONObject, token:String?=null, timeoutMs:Int=20_000):Result=try{require(endpoint.startsWith("https://")){"Le serveur d'entraînement doit utiliser HTTPS."};val c=URL(endpoint).openConnection() as HttpURLConnection;c.requestMethod="POST";c.connectTimeout=timeoutMs;c.readTimeout=timeoutMs;c.doOutput=true;c.setRequestProperty("Content-Type","application/json");if(!token.isNullOrBlank())c.setRequestProperty("Authorization","Bearer $token");c.outputStream.use{it.write(payload.toString().toByteArray())};val code=c.responseCode;val stream=if(code in 200..299)c.inputStream else c.errorStream;Result(code in 200..299,code,stream?.bufferedReader()?.use{it.readText()}.orEmpty())}catch(e:Exception){Result(false,-1,e.message.orEmpty())}
}
