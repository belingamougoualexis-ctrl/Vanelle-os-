package com.nova.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Un concept est une généralisation formée à partir de plusieurs expériences ou connaissances
 * qui se ressemblent (mêmes mots-clés récurrents). Contrairement à une expérience isolée,
 * un concept a une confiance qui grandit avec le nombre d'exemples qui le confirment.
 */
data class Concept(
    val name: String,
    val summary: String,
    val keywords: List<String>,
    val exemplarCount: Int,
    val confidence: Double,
    val formedAt: Long,
    val lastReinforced: Long
)

class ConceptStore(context: Context, namespace: String = "default") {
    private val p = context.getSharedPreferences("nova_concepts_$namespace", Context.MODE_PRIVATE)

    fun all(): List<Concept> = readArray { o ->
        Concept(
            o.getString("name"), o.getString("summary"),
            o.getString("keywords").split(",").filter { it.isNotBlank() },
            o.optInt("exemplarCount", 1), o.optDouble("confidence", .4),
            o.optLong("formedAt", System.currentTimeMillis()), o.optLong("lastReinforced", System.currentTimeMillis())
        )
    }

    /** Crée le concept s'il n'existe pas, sinon le renforce : plus d'exemplaires, confiance en hausse, mots-clés enrichis. */
    fun upsert(name: String, summary: String, keywords: List<String>) {
        val list = all().toMutableList()
        val i = list.indexOfFirst { it.name.equals(name, true) }
        if (i >= 0) {
            val c = list[i]
            list[i] = c.copy(
                exemplarCount = c.exemplarCount + 1,
                confidence = (c.confidence + 0.05).coerceAtMost(0.97),
                lastReinforced = System.currentTimeMillis(),
                keywords = (c.keywords + keywords).distinct().take(12),
                summary = c.summary
            )
        } else {
            list.add(Concept(name, summary, keywords.distinct().take(12), 1, 0.35, System.currentTimeMillis(), System.currentTimeMillis()))
        }
        write(list)
    }

    fun relevantTo(words: Set<String>, limit: Int = 5): List<Concept> =
        all().map { c -> c to c.keywords.count { k -> words.any { w -> w.contains(k) || k.contains(w) } } }
            .filter { it.second > 0 }
            .sortedByDescending { it.second * it.first.confidence }
            .take(limit).map { it.first }

    private inline fun <T> readArray(map: (JSONObject) -> T): List<T> {
        val a = JSONArray(p.getString("concepts", "[]")); return buildList { for (i in 0 until a.length()) add(map(a.getJSONObject(i))) }
    }

    private fun write(list: List<Concept>) {
        val a = JSONArray(list.map { c ->
            JSONObject().apply {
                put("name", c.name); put("summary", c.summary); put("keywords", c.keywords.joinToString(","))
                put("exemplarCount", c.exemplarCount); put("confidence", c.confidence)
                put("formedAt", c.formedAt); put("lastReinforced", c.lastReinforced)
            }
        })
        p.edit().putString("concepts", a.toString()).apply()
    }
}
