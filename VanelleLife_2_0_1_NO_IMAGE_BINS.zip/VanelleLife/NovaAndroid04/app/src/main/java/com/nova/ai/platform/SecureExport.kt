package com.nova.ai.platform

import com.nova.ai.AIExportCrypto
import com.nova.ai.AISecretVault
import com.nova.ai.AIStudioStore
import android.content.Context
import org.json.JSONObject

/** Complete metadata export plus explicitly encrypted provider credentials. */
class SecureExport(private val context:Context,private val store:AIStudioStore,private val vault:AISecretVault){
    fun build(aiId:String,password:String):String{
        require(password.length>=8){"Le mot de passe d'export doit contenir au moins 8 caractères."}
        val base=JSONObject(store.exportJson(aiId))
        val secrets=JSONObject()
        listOf("image","video","voix","conversation").forEach{kind->vault.get("$aiId:$kind")?.let{secrets.put(kind,AIExportCrypto.encrypt(it,password))}}
        base.put("security",JSONObject().put("credentialEncryption","PBKDF2-HMAC-SHA256 + AES-256-GCM").put("binaryAssets","referenced-and-hash-verified").put("plaintextSecrets",false))
        base.put("encryptedApiSecrets",secrets)
        return base.toString(2)
    }
}
