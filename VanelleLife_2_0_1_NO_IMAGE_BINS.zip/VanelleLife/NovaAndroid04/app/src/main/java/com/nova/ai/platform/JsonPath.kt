package com.nova.ai.platform

import org.json.JSONArray
import org.json.JSONObject

/** Small JSON path reader for provider response mappings: a.b.0.c */
object JsonPath {
    fun get(root: Any?, path: String): Any? {
        if (path.isBlank()) return root
        var cur=root
        for (part in path.split('.')) {
            cur=when(cur){
                is JSONObject -> if(cur.has(part)) cur.opt(part) else return null
                is JSONArray -> part.toIntOrNull()?.let{cur.opt(it)} ?: return null
                else -> return null
            }
        }
        return cur
    }
}
