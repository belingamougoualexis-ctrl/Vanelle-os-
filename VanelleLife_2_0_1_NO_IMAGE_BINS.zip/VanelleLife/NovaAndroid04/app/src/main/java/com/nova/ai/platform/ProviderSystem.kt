package com.nova.ai.platform

data class ProviderEndpoint(
    val id: String,
    val name: String,
    val baseUrl: String,
    val enabled: Boolean,
    val supportedModalities: Set<Modality>,
    val modelIds: List<String>
)

interface ProviderClient {
    val providerId: String
    fun generate(request: GenerationRequest): GenerationResult
}

class ProviderRouter(
    private val providers: List<ProviderClient>
) {
    fun route(request: GenerationRequest): GenerationResult {
        val client = providers.firstOrNull()
            ?: return HonestExecution.unavailable(request.modality, "Aucun provider réel n'est configuré.")
        return runCatching { client.generate(request) }.getOrElse {
            GenerationResult(false, errorCode = "PROVIDER_ERROR", errorMessage = it.message ?: "Erreur provider")
        }
    }
}
