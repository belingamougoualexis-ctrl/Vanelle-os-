package com.nova.ai

import android.content.Context
import android.os.Build
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/**
 * Voix synthétiques Android (TTS).
 * Langue = tag BCP-47 de la mascotte (micro + TTS alignés).
 */
class VoiceEngine(context: Context) : TextToSpeech.OnInitListener {
    private val app = context.applicationContext
    private var tts: TextToSpeech? = null
    private var ready = false
    private var onReady: (() -> Unit)? = null

    data class VoiceOption(
        val name: String,
        val label: String,
        val locale: String,
        val quality: Int
    )

    init {
        tts = TextToSpeech(app, this)
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) {
            tts?.language = LanguageCatalog.localeOf(LanguageCatalog.DEFAULT)
            onReady?.invoke()
        }
    }

    fun whenReady(cb: () -> Unit) {
        if (ready) cb() else onReady = cb
    }

    fun isReady(): Boolean = ready

    /** Voix installées, filtrées par langue si [languageTag] non vide. */
    fun availableVoices(languageTag: String = ""): List<VoiceOption> {
        val engine = tts ?: return emptyList()
        if (Build.VERSION.SDK_INT < 21) {
            return listOf(VoiceOption("default", "Voix système", languageTag.ifBlank { "fr_FR" }, 300))
        }
        val voices = try {
            engine.voices?.toList() ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
        val want = languageTag.replace('-', '_').lowercase()
        val langOnly = languageTag.substringBefore('-').lowercase()

        fun matches(v: Voice): Boolean {
            if (languageTag.isBlank()) return true
            val vl = v.locale.toString().replace('-', '_').lowercase()
            return vl.startsWith(want) || vl.startsWith(langOnly)
        }

        val offline = voices.filter { matches(it) && !it.isNetworkConnectionRequired }
            .sortedByDescending { it.quality }
        val online = voices.filter { matches(it) && it.isNetworkConnectionRequired }
        val picked = (offline + online).ifEmpty {
            // fallback : toutes les voix de la langue racine, sinon toutes
            voices.filter {
                it.locale.language.equals(langOnly, true)
            }.ifEmpty { voices.take(12) }
        }
        return picked.map { v ->
            val net = if (v.isNetworkConnectionRequired) " · cloud" else " · offline"
            val q = when {
                v.quality >= 400 -> "HQ"
                v.quality >= 300 -> "normale"
                else -> "basse"
            }
            VoiceOption(
                name = v.name,
                label = "${v.locale.displayName} · $q$net",
                locale = v.locale.toString(),
                quality = v.quality
            )
        }.distinctBy { it.name }
    }

    fun apply(settings: VoiceSettings) {
        val engine = tts ?: return
        if (!ready) return
        engine.setSpeechRate(settings.rate.coerceIn(0.5f, 2.0f))
        engine.setPitch(settings.pitch.coerceIn(0.5f, 2.0f))
        val locale = LanguageCatalog.localeOf(settings.languageTag.ifBlank { LanguageCatalog.DEFAULT })
        if (Build.VERSION.SDK_INT >= 21 && settings.voiceName.isNotBlank()) {
            val match = try {
                engine.voices?.firstOrNull { it.name == settings.voiceName }
            } catch (_: Exception) { null }
            if (match != null) {
                engine.voice = match
            } else {
                setLanguageSafe(engine, locale)
            }
        } else {
            setLanguageSafe(engine, locale)
        }
    }

    private fun setLanguageSafe(engine: TextToSpeech, locale: Locale) {
        val r = engine.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            // repli langue racine puis anglais
            val root = Locale(locale.language)
            val r2 = engine.setLanguage(root)
            if (r2 == TextToSpeech.LANG_MISSING_DATA || r2 == TextToSpeech.LANG_NOT_SUPPORTED) {
                engine.language = Locale.US
            }
        }
    }

    fun speak(text: String, settings: VoiceSettings, utteranceId: String = "nova") {
        val engine = tts ?: return
        if (!ready || text.isBlank()) return
        apply(settings)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }

    /** Disponibilité TTS pour une langue. */
    fun languageAvailable(languageTag: String): Boolean {
        val engine = tts ?: return false
        if (!ready) return false
        val locale = LanguageCatalog.localeOf(languageTag)
        val r = engine.isLanguageAvailable(locale)
        return r >= TextToSpeech.LANG_AVAILABLE
    }

    data class VoiceSettings(
        val voiceName: String = "",
        val pitch: Float = 1.0f,
        val rate: Float = 1.0f,
        val languageTag: String = LanguageCatalog.DEFAULT
    ) {
        fun toJson(): String =
            org.json.JSONObject()
                .put("voiceName", voiceName)
                .put("pitch", pitch.toDouble())
                .put("rate", rate.toDouble())
                .put("languageTag", languageTag)
                .toString()

        companion object {
            fun fromJson(s: String?): VoiceSettings {
                if (s.isNullOrBlank()) return VoiceSettings()
                return try {
                    val o = org.json.JSONObject(s)
                    VoiceSettings(
                        o.optString("voiceName", ""),
                        o.optDouble("pitch", 1.0).toFloat(),
                        o.optDouble("rate", 1.0).toFloat(),
                        o.optString("languageTag", LanguageCatalog.DEFAULT).ifBlank { LanguageCatalog.DEFAULT }
                    )
                } catch (_: Exception) {
                    VoiceSettings()
                }
            }
        }
    }
}
