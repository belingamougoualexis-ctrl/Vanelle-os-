package com.nova.ai.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Base Room-compatible (SQLiteOpenHelper) pour l'état durable de production.
 * Complète PlatformDatabase : journal de consentement, préférences accessibilité,
 * métriques locales anonymisées (si opt-in), et index mémoire longue.
 *
 * Migration progressive : les stores existants (SharedPreferences) restent la source
 * de vérité tant qu'une migration explicite n'a pas été exécutée.
 */
class AppDatabase(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    "vanelle_app.db",
    null,
    VERSION
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS memory_index(
              id TEXT PRIMARY KEY,
              mascot_id TEXT NOT NULL,
              kind TEXT NOT NULL,
              snippet TEXT NOT NULL,
              tokens TEXT NOT NULL,
              score REAL NOT NULL DEFAULT 0,
              created_at INTEGER NOT NULL,
              updated_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_memory_mascot ON memory_index(mascot_id)")
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS consent_events(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              action TEXT NOT NULL,
              value TEXT NOT NULL,
              created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS local_metrics(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL,
              value REAL NOT NULL,
              created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS schema_meta(
              key TEXT PRIMARY KEY,
              value TEXT NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("INSERT OR REPLACE INTO schema_meta(key,value) VALUES('version','$VERSION')")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            // Placeholders pour futures migrations Room-style
            db.execSQL("CREATE TABLE IF NOT EXISTS schema_meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        }
    }

    fun recordConsentEvent(action: String, value: String) {
        writableDatabase.execSQL(
            "INSERT INTO consent_events(action,value,created_at) VALUES(?,?,?)",
            arrayOf(action, value, System.currentTimeMillis())
        )
    }

    fun upsertMemoryIndex(
        id: String,
        mascotId: String,
        kind: String,
        snippet: String,
        tokens: String,
        score: Double
    ) {
        val now = System.currentTimeMillis()
        writableDatabase.execSQL(
            """
            INSERT OR REPLACE INTO memory_index(id,mascot_id,kind,snippet,tokens,score,created_at,updated_at)
            VALUES(?,?,?,?,?,?,COALESCE((SELECT created_at FROM memory_index WHERE id=?),?),?)
            """.trimIndent(),
            arrayOf(id, mascotId, kind, snippet, tokens, score, id, now, now)
        )
    }

    fun searchMemory(mascotId: String, queryTokens: List<String>, limit: Int = 8): List<MemoryHit> {
        if (queryTokens.isEmpty()) return emptyList()
        val like = queryTokens.take(5).joinToString(" OR ") { "tokens LIKE ?" }
        val args = mutableListOf(mascotId)
        queryTokens.take(5).forEach { args.add("%${it.lowercase()}%") }
        args.add(limit.toString())
        val sql = """
            SELECT id, kind, snippet, score FROM memory_index
            WHERE mascot_id=? AND ($like)
            ORDER BY score DESC, updated_at DESC LIMIT ?
        """.trimIndent()
        val out = mutableListOf<MemoryHit>()
        readableDatabase.rawQuery(sql, args.toTypedArray()).use { c ->
            while (c.moveToNext()) {
                out.add(
                    MemoryHit(
                        id = c.getString(0),
                        kind = c.getString(1),
                        snippet = c.getString(2),
                        score = c.getDouble(3)
                    )
                )
            }
        }
        return out
    }

    data class MemoryHit(val id: String, val kind: String, val snippet: String, val score: Double)

    companion object {
        const val VERSION = 2
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: AppDatabase(context).also { instance = it }
            }
    }
}
