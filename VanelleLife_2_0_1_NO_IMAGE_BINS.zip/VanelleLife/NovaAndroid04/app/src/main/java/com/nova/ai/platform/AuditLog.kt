package com.nova.ai.platform

import android.content.Context

class AuditLog(context: Context) {
    private val db = PlatformDatabase(context.applicationContext)
    fun success(aiId: String?, action: String, detail: String = "") = db.audit(aiId, action, "success", detail)
    fun failure(aiId: String?, action: String, detail: String) = db.audit(aiId, action, "failure", detail)
}
