package com.nova.ai.platform

import android.content.Context

/**
 * Contract for a REAL model-training engine. Implementations must report measured progress
 * and never manufacture a completed checkpoint. VanelleLife ships the orchestration contract;
 * a native/GPU runtime can be plugged in without changing the AI domain model.
 */
interface TrainingRuntime {
    val id: String
    val displayName: String
    fun canTrain(context: Context, modality: String, config: TrainingConfig): Boolean
    fun train(context: Context, request: TrainingRequest, listener: Listener): TrainingResult
    interface Listener { fun onProgress(progress: Int, step: Long, loss: Double?); fun onCheckpoint(path: String); fun onMessage(message: String) }
}
data class TrainingRequest(val projectId:String,val modality:String,val datasetManifest:String,val outputDirectory:String,val config:TrainingConfig)
data class TrainingResult(val success:Boolean,val checkpoint:String?,val error:String?)

object TrainingRuntimeRegistry {
    private val runtimes=mutableListOf<TrainingRuntime>()
    fun register(runtime:TrainingRuntime){ synchronized(runtimes){ if(runtimes.none{it.id==runtime.id}) runtimes += runtime } }
    fun all():List<TrainingRuntime> = synchronized(runtimes){runtimes.toList()}
    fun find(context:Context,modality:String,config:TrainingConfig):TrainingRuntime?=all().firstOrNull{runCatching{it.canTrain(context,modality,config)}.getOrDefault(false)}
}
