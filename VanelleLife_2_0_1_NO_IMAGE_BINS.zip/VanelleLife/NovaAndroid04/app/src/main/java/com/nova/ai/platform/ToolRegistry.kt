package com.nova.ai.platform

import org.json.JSONObject
import java.util.UUID

/** Declarative tools: the orchestrator can only execute registered capabilities. */
data class ToolSpec(val id:String=UUID.randomUUID().toString(), val name:String, val capability:String, val requiresConfirmation:Boolean=false, val network:Boolean=false) {
    fun json()=JSONObject().apply{put("id",id);put("name",name);put("capability",capability);put("requiresConfirmation",requiresConfirmation);put("network",network)}
}
class ToolRegistry {
    private val tools=linkedMapOf<String,ToolSpec>()
    fun register(tool:ToolSpec){tools[tool.id]=tool}
    fun all():List<ToolSpec> = tools.values.toList()
    fun findByCapability(capability:String)=all().filter{it.capability.equals(capability,true)}
}
