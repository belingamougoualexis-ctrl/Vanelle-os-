package com.nova.ai.crash

import android.content.Context
import android.util.Log
import com.nova.ai.legal.ConsentStore
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Rapport de plantage local + hook optionnel pour un SDK (Sentry / Crashlytics).
 * Aucun envoi réseau tant que ConsentStore.crashReportingOptIn() == false.
 */
object CrashReporter {
    private const val TAG = "VanelleCrash"
    private val installed = AtomicBoolean(false)

    fun install(context: Context) {
        if (!installed.compareAndSet(false, true)) return
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                persistLocal(app, throwable)
                if (ConsentStore(app).crashReportingOptIn()) {
                    // Point d'extension : brancher Sentry / Firebase ici après ajout des dépendances.
                    Log.e(TAG, "Crash (opt-in actif) — trace locale enregistrée", throwable)
                } else {
                    Log.e(TAG, "Crash (opt-in inactif) — trace locale uniquement", throwable)
                }
            } catch (_: Exception) {
                // ne jamais masquer le crash original
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    fun logNonFatal(context: Context, message: String, t: Throwable? = null) {
        if (!ConsentStore(context).crashReportingOptIn()) return
        Log.w(TAG, message, t)
        if (t != null) persistLocal(context, t, prefix = "nonfatal")
    }

    private fun persistLocal(context: Context, t: Throwable, prefix: String = "crash") {
        val dir = File(context.filesDir, "crashes").apply { mkdirs() }
        val sw = StringWriter()
        t.printStackTrace(PrintWriter(sw))
        val file = File(dir, "${prefix}_${System.currentTimeMillis()}.txt")
        file.writeText(sw.toString())
        // Rotation simple : garder 20 fichiers max
        dir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(20)?.forEach { it.delete() }
    }
}
