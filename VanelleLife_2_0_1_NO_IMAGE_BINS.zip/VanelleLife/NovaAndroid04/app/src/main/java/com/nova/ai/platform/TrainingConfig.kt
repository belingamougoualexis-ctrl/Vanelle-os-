package com.nova.ai.platform

import org.json.JSONObject

data class TrainingConfig(
    val mode: AIArchitecture.TrainingMode = AIArchitecture.TrainingMode.FROM_SCRATCH,
    val architecture: String = "transformer-diffusion-experimental",
    val resolution: String = "256x256",
    val fps: Int = 8,
    val frames: Int = 16,
    val epochs: Int = 1,
    val batchSize: Int = 1,
    val learningRate: Double = 1e-4,
    val seed: Long = 42,
    val precision: String = "fp16",
    val checkpointEvery: Int = 500
) {
    fun validate() {
        require(fps in 1..60); require(frames in 1..2048); require(epochs in 1..1_000_000)
        require(batchSize in 1..4096); require(learningRate>0); require(precision in setOf("fp32","fp16","bf16"))
    }
    fun toJson()=JSONObject().apply{put("mode",mode.name);put("architecture",architecture);put("resolution",resolution);put("fps",fps);put("frames",frames);put("epochs",epochs);put("batchSize",batchSize);put("learningRate",learningRate);put("seed",seed);put("precision",precision);put("checkpointEvery",checkpointEvery)}
}
