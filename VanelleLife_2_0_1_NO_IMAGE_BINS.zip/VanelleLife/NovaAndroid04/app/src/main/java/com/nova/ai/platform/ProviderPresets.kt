package com.nova.ai.platform

/** Templates prêts à l'emploi (HTTPS + clé fournie par l'utilisateur). */
object ProviderPresets {

    fun openAiChat(apiKeyHint: Boolean = true) = ProviderSpec(
        name = "OpenAI Chat",
        endpoint = "https://api.openai.com/v1/chat/completions",
        authType = "bearer",
        capabilities = setOf("chat", "text"),
        requestTemplate = """
            {
              "model": "gpt-4o-mini",
              "messages": [
                {"role": "system", "content": "{{system}}"},
                {"role": "user", "content": "{{context}}\n\n{{prompt}}"}
              ],
              "temperature": 0.7
            }
        """.trimIndent(),
        responsePath = "choices.0.message.content",
        enabled = true
    )

    fun openAiCompatible(baseUrl: String, model: String = "gpt-4o-mini") = ProviderSpec(
        name = "API compatible OpenAI",
        endpoint = baseUrl.trimEnd('/') + "/chat/completions",
        authType = "bearer",
        capabilities = setOf("chat", "text"),
        requestTemplate = """
            {
              "model": "$model",
              "messages": [
                {"role": "system", "content": "{{system}}"},
                {"role": "user", "content": "{{context}}\n\n{{prompt}}"}
              ]
            }
        """.trimIndent(),
        responsePath = "choices.0.message.content",
        enabled = true
    )

    fun simplePrompt() = ProviderSpec(
        name = "API simple (prompt)",
        endpoint = "https://example.com/v1/generate",
        authType = "bearer",
        capabilities = setOf("chat", "text"),
        requestTemplate = """{"prompt":"{{prompt}}","system":"{{system}}"}""",
        responsePath = "text",
        enabled = true
    )
}
