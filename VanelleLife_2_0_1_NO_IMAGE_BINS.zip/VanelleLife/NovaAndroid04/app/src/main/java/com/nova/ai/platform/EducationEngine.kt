package com.nova.ai.platform

import org.json.JSONObject
import java.util.UUID

data class EducationEvent(val id:String=UUID.randomUUID().toString(),val aiId:String,val type:String,val topic:String,val content:String,val confidence:Double,val source:String,val createdAt:Long=System.currentTimeMillis())
/** Explicit education ledger: memory, corrections and skills remain distinguishable from model weights. */
class EducationEngine(private val store:AIStudioStore){
    fun teach(aiId:String,topic:String,content:String,confidence:Double=.95,source:String="user"){require(content.isNotBlank());store.teach(aiId,topic,content,confidence)}
    fun correction(aiId:String,topic:String,content:String){store.teach(aiId,topic,"[CORRECTION] $content",.99)}
    fun exportLedger(aiId:String):JSONObject=JSONObject().apply{put("schema",1);put("aiId",aiId);put("lessons",store.lessons(aiId).map{JSONObject().put("topic",it.topic).put("content",it.content).put("confidence",it.confidence).put("createdAt",it.createdAt)})}
}
