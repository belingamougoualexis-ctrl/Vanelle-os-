package com.nova.ai

/**
 * Révision des croyances.
 *
 * Avant d'ajouter une nouvelle affirmation en mémoire, on la compare aux connaissances
 * existantes sur le même sujet. Deux cas déclenchent une révision plutôt qu'un simple ajout :
 *  - la phrase contient un marqueur explicite de correction ("en fait", "je me suis trompé"...)
 *  - la nouvelle information partage le sujet mais recoupe très peu de mots avec l'ancienne
 *    (signe d'une affirmation différente, potentiellement incompatible)
 * Dans ces cas, l'ancienne croyance perd en confiance et l'événement est journalisé
 * (LearningStore.beliefRevisions) au lieu d'être silencieusement écrasé.
 */
object BeliefRevision {
    private val correctionMarkers = listOf(
        "en fait", "je me suis trompé", "je me trompais", "erreur", "c'est faux",
        "plutôt que", "j'ai changé d'avis", "non finalement", "à corriger", "ce n'est pas"
    )

    fun evaluate(store: LearningStore, subject: String, newFact: String, confidence: Double, source: String) {
        val cleanSubject = subject.trim()
        val cleanFact = newFact.trim()
        val lower = cleanFact.lowercase()
        val looksLikeCorrection = correctionMarkers.any { lower.contains(it) }

        val candidates = store.knowledge().filter {
            it.subject.equals(cleanSubject, true) && !it.fact.equals(cleanFact, true)
        }
        for (old in candidates) {
            val overlap = wordOverlap(old.fact, cleanFact)
            val divergent = overlap < 0.25
            if (looksLikeCorrection || divergent) {
                val penalty = if (looksLikeCorrection) 0.35 else 0.15
                val reason = if (looksLikeCorrection)
                    "contredite explicitement par une information plus récente"
                else
                    "nouvelle affirmation divergente sur le même sujet, à confirmer"
                store.reviseConfidence(old.subject, old.fact, (old.confidence - penalty).coerceIn(0.05, 1.0), reason)
            }
        }
        store.learn(cleanSubject, cleanFact, confidence, source)
    }

    private fun wordOverlap(a: String, b: String): Double {
        val wa = a.lowercase().split(Regex("\\W+")).filter { it.length > 2 }.toSet()
        val wb = b.lowercase().split(Regex("\\W+")).filter { it.length > 2 }.toSet()
        if (wa.isEmpty() || wb.isEmpty()) return 1.0
        val union = wa.union(wb).size
        if (union == 0) return 1.0
        return wa.intersect(wb).size.toDouble() / union
    }
}
