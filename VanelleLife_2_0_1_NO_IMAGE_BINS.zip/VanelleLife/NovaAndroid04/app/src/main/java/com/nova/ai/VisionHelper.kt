package com.nova.ai

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Vision multimodale via le même endpoint chat (modèle vision type gpt-4o).
 * L'image est encodée en base64 data-URL ; aucun modèle local n'est embarqué.
 * Configuration = endpoint + clé + modèle vision (réglages / premier lancement).
 */
object VisionHelper {

    fun bitmapToDataUrl(bitmap: Bitmap, maxSide: Int = 1024, quality: Int = 82): String {
        val scaled = scaleDown(bitmap, maxSide)
        val baos = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, quality, baos)
        val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        return "data:image/jpeg;base64,$b64"
    }

    fun askWithImage(
        endpoint: String,
        apiKey: String,
        model: String,
        system: String,
        userText: String,
        dataUrl: String
    ): String {
        if (apiKey.isBlank()) return "Vision non configurée (clé API manquante)."
        val content = JSONArray().apply {
            put(JSONObject().apply {
                put("type", "text")
                put("text", userText.ifBlank { "Décris cette image et dis ce que tu en retiens." })
            })
            put(JSONObject().apply {
                put("type", "image_url")
                put("image_url", JSONObject().apply { put("url", dataUrl) })
            })
        }
        val body = JSONObject().apply {
            put("model", model)
            put("messages", JSONArray().apply {
                put(JSONObject().apply { put("role", "system"); put("content", system) })
                put(JSONObject().apply { put("role", "user"); put("content", content) })
            })
            put("temperature", 0.5)
            put("max_tokens", 800)
        }.toString()

        val c = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $apiKey")
        }
        return try {
            c.outputStream.use { it.write(body.toByteArray()) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val text = stream.bufferedReader().use { it.readText() }
            if (c.responseCode !in 200..299) "Erreur vision HTTP ${c.responseCode}."
            else JSONObject(text).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
        } catch (e: Exception) {
            "Vision indisponible : ${e.javaClass.simpleName}."
        } finally {
            c.disconnect()
        }
    }

    fun probe(endpoint: String, apiKey: String, model: String): String {
        if (apiKey.isBlank()) return "Vision : clé manquante"
        // Probe léger : on ne envoie pas d'image, juste un message texte au modèle vision
        val body = JSONObject().apply {
            put("model", model)
            put("messages", JSONArray().apply {
                put(JSONObject().apply { put("role", "user"); put("content", "Réponds uniquement : OK") })
            })
            put("max_tokens", 5)
        }.toString()
        val c = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $apiKey")
        }
        return try {
            c.outputStream.use { it.write(body.toByteArray()) }
            if (c.responseCode in 200..299) "Vision OK ($model)"
            else "Vision : HTTP ${c.responseCode}"
        } catch (e: Exception) {
            "Vision : ${e.javaClass.simpleName}"
        } finally {
            c.disconnect()
        }
    }

    private fun scaleDown(src: Bitmap, maxSide: Int): Bitmap {
        val w = src.width
        val h = src.height
        val longest = maxOf(w, h)
        if (longest <= maxSide) return src
        val scale = maxSide.toFloat() / longest
        return Bitmap.createScaledBitmap(src, (w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1), true)
    }
}
