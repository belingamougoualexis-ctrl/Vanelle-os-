package com.nova.ai

import android.view.View
import android.widget.ImageView
import android.widget.TextView

/** Utilitaires accessibilité (TalkBack / contentDescription). */
object AccessibilityHelper {
    fun setButtonLabel(view: View, label: String) {
        view.contentDescription = label
        view.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    fun setAvatarLabel(avatar: ImageView, mascotName: String, stage: String) {
        avatar.contentDescription = "Avatar de $mascotName, stade $stage"
    }

    fun setChatLiveRegion(chat: TextView) {
        chat.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        chat.contentDescription = "Conversation avec la mascotte"
    }
}
