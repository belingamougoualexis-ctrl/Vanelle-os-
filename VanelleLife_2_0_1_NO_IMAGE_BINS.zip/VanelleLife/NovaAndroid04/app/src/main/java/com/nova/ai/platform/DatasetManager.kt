package com.nova.ai.platform

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.security.MessageDigest

/** Dataset inspection never pretends to train; it validates real files and creates manifests. */
class DatasetManager(private val context: Context) {
    private val datasetRoot = File(context.filesDir, "datasets").also { it.mkdirs() }
    private val db = PlatformDatabase(context)
    data class Item(val uri:String,val name:String,val bytes:Long,val mime:String,val sha256:String)
    data class Report(val items:List<Item>,val totalBytes:Long,val errors:List<String>)

    fun inspect(uris:List<Uri>): Report {
        val out=mutableListOf<Item>(); val errors=mutableListOf<String>()
        for(uri in uris.distinct()) try {
            val name=queryName(uri); val bytes=context.contentResolver.openAssetFileDescriptor(uri,"r")?.use{it.length}.takeIf{it!=null && it>=0} ?: 0
            val sha=sha256(uri); out += Item(uri.toString(),name,bytes,context.contentResolver.getType(uri).orEmpty(),sha)
        } catch(e:Exception){ errors += "${uri}: ${e.message ?: "lecture impossible"}" }
        return Report(out,out.sumOf{it.bytes},errors)
    }
    fun importDataset(datasetId:String, uris:List<Uri>, onProgress:(Int)->Unit = {}):String {
        require(datasetId.isNotBlank())
        val dir=File(datasetRoot,datasetId).also{it.mkdirs()}
        val report=inspect(uris)
        require(report.errors.isEmpty()){report.errors.joinToString("; ")}
        val manifest=org.json.JSONObject().apply{
            put("schema",1);put("datasetId",datasetId);put("createdAt",System.currentTimeMillis())
            put("items",org.json.JSONArray())
        }
        val items=manifest.getJSONArray("items")
        report.items.forEachIndexed{index,item->
            val safe=(index.toString().padStart(6,'0')+"_"+(item.name.ifBlank{"item"}).replace(Regex("[^A-Za-z0-9._-]"),"_"))
            val out=File(dir,safe)
            context.contentResolver.openInputStream(Uri.parse(item.uri)).use{input->requireNotNull(input){"Impossible de lire ${item.name}"};out.outputStream().use{output->input.copyTo(output)}}
            items.put(org.json.JSONObject().apply{put("name",item.name);put("path",out.absolutePath);put("bytes",out.length());put("mime",item.mime);put("sha256",item.sha256)})
            onProgress(((index+1)*100/report.items.size.coerceAtLeast(1)))
        }
        val manifestFile=File(dir,"manifest.json");manifestFile.writeText(manifest.toString(2))
        val datasetSha=sha256File(manifestFile)
        db.recordDataset(datasetId,null,datasetId,manifestFile.absolutePath,report.totalBytes,report.items.size,datasetSha)
        return manifestFile.absolutePath
    }

    private fun queryName(uri:Uri):String=context.contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{c->if(c.moveToFirst())c.getString(0) else uri.lastPathSegment.orEmpty()}.orEmpty()
    private fun sha256File(file:File):String { val md=MessageDigest.getInstance("SHA-256");file.inputStream().use{input->val b=ByteArray(64*1024);while(true){val n=input.read(b);if(n<0)break;if(n>0)md.update(b,0,n)}};return md.digest().joinToString(""){ "%02x".format(it) } }
    private fun sha256(uri:Uri):String { val md=MessageDigest.getInstance("SHA-256"); context.contentResolver.openInputStream(uri)?.use{input->val b=ByteArray(64*1024);while(true){val n=input.read(b);if(n<0)break;if(n>0)md.update(b,0,n)}} ?: throw IllegalStateException("Fichier inaccessible"); return md.digest().joinToString(""){ "%02x".format(it) } }
}
