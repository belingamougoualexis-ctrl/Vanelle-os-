package com.nova.ai

import android.content.Context

/**
 * XP + stades visibles + émotions.
 * Œuf → Bébé → Curieuse → Sage → Complice
 */
object GrowthSystem {

    enum class Emotion { IDLE, HAPPY, THINKING, LISTENING, SURPRISED, PROUD, SAD }

    data class Progress(
        val xp: Int,
        val stage: String,
        val stageIndex: Int,
        val xpIntoStage: Int,
        val xpForNext: Int,
        val progress01: Float,
        val label: String
    )

    private val STAGES = listOf(
        0 to "Œuf",
        40 to "Bébé",
        120 to "Curieuse",
        300 to "Sage",
        700 to "Complice"
    )

    fun compute(state: DevelopmentEngine.State, extraXp: Int = 0): Progress {
        val xp = (
            state.experiences * 3 +
                state.knowledge * 8 +
                state.memories * 2 +
                state.concepts * 12 +
                state.supervised * 15 +
                state.beliefRevisions * 5 +
                extraXp
            ).coerceAtLeast(0)
        var idx = 0
        for (i in STAGES.indices) {
            if (xp >= STAGES[i].first) idx = i
        }
        val cur = STAGES[idx].first
        val next = if (idx + 1 < STAGES.size) STAGES[idx + 1].first else cur + 200
        val into = xp - cur
        val need = (next - cur).coerceAtLeast(1)
        val name = STAGES[idx].second
        return Progress(
            xp = xp,
            stage = name,
            stageIndex = idx,
            xpIntoStage = into,
            xpForNext = need,
            progress01 = (into.toFloat() / need).coerceIn(0f, 1f),
            label = "$name · $xp XP"
        )
    }

    fun emotionFor(event: String): Emotion = when (event) {
        "listen" -> Emotion.LISTENING
        "think" -> Emotion.THINKING
        "learn", "correct", "teach" -> Emotion.PROUD
        "unknown" -> Emotion.SURPRISED
        "greet", "happy" -> Emotion.HAPPY
        "miss" -> Emotion.SAD
        else -> Emotion.IDLE
    }

    fun xpPrefs(context: Context, mascotId: String) =
        context.getSharedPreferences("nova_xp_$mascotId", Context.MODE_PRIVATE)

    fun bonusXp(context: Context, mascotId: String): Int =
        xpPrefs(context, mascotId).getInt("bonus", 0)

    fun addBonusXp(context: Context, mascotId: String, amount: Int) {
        val p = xpPrefs(context, mascotId)
        p.edit().putInt("bonus", p.getInt("bonus", 0) + amount).apply()
    }
}
