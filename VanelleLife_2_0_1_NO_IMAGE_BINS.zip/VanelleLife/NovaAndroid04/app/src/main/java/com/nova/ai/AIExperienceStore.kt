package com.nova.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class AIExperience(val id:String=UUID.randomUUID().toString(),val aiId:String,val type:String,val input:String,val outcome:String,val importance:Int=1,val createdAt:Long=System.currentTimeMillis())
/** Separate episodic experience from semantic lessons and model weights. */
class AIExperienceStore(context:Context){
    private val p=context.getSharedPreferences("ai_experiences_v1",0)
    fun all(aiId:String):List<AIExperience>{val a=JSONArray(p.getString("items","[]"));return(0 until a.length()).map{val o=a.getJSONObject(it);AIExperience(o.getString("id"),o.getString("aiId"),o.optString("type"),o.optString("input"),o.optString("outcome"),o.optInt("importance",1),o.optLong("createdAt"))}.filter{it.aiId==aiId}.sortedByDescending{it.createdAt}}
    fun add(e:AIExperience){val a=JSONArray(p.getString("items","[]"));a.put(JSONObject().apply{put("id",e.id);put("aiId",e.aiId);put("type",e.type);put("input",e.input);put("outcome",e.outcome);put("importance",e.importance);put("createdAt",e.createdAt)});p.edit().putString("items",a.toString()).apply()}
}
