package com.nova.ai

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Consolidation nocturne : NOVA relit et consolide ses expériences une fois par jour,
 * sans action de l'utilisateur, en simulant un temps de repos plutôt qu'une consolidation
 * uniquement déclenchée par l'usage (bouton manuel ou seuil d'échanges).
 */
class NightlyConsolidationWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val store = MascotStore(applicationContext)
        val mascots = store.all().ifEmpty { return Result.success() }
        for (m in mascots) {
            val memory = MemoryStore(applicationContext, m.id)
            val learning = LearningStore(applicationContext, m.id)
            val concepts = ConceptStore(applicationContext, m.id)
            val semantic = SemanticMemory(applicationContext, m.id)
            val personality = PersonalityEngine(learning)
            ConsolidationEngine(applicationContext, memory, learning, concepts, semantic, personality, m.id).consolidate()
        }
        Result.success()
    } catch (e: Exception) {
        Result.retry()
    }

    companion object {
        private const val WORK_NAME = "nova_nightly_consolidation"

        /** Planifie (ou conserve, si déjà planifiée) une consolidation quotidienne vers 3h du matin. */
        fun schedule(context: Context) {
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 3); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
            }
            val request = PeriodicWorkRequestBuilder<NightlyConsolidationWorker>(24, TimeUnit.HOURS)
                .setInitialDelay((target.timeInMillis - now.timeInMillis).coerceAtLeast(0), TimeUnit.MILLISECONDS)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }
}
