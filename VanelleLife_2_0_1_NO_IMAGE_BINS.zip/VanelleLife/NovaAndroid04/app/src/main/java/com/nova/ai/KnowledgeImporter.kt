package com.nova.ai

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.nio.charset.Charset
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

/**
 * Importe des leçons pour une mascotte.
 * .txt/.md/.csv/.json/.jsonl + .zip (extrait les textes) + .gz
 * .rar/.7z/.bin : message clair, non supportés nativement.
 */
object KnowledgeImporter {

    data class Report(
        val knowledge: Int = 0,
        val memories: Int = 0,
        val supervised: Int = 0,
        val experiences: Int = 0,
        val skipped: Int = 0,
        val message: String = ""
    ) {
        operator fun plus(other: Report) = Report(
            knowledge + other.knowledge,
            memories + other.memories,
            supervised + other.supervised,
            experiences + other.experiences,
            skipped + other.skipped,
            listOf(message, other.message).filter { it.isNotBlank() }.joinToString(" · ")
        )
    }

    private val archiveHint = setOf("rar", "7z", "tar", "bz2", "xz")
    private val binarySkip = setOf(
        "png", "jpg", "jpeg", "gif", "webp", "bmp", "pdf", "mp3", "mp4", "wav",
        "bin", "task", "onnx", "tflite", "so", "apk", "dex", "class", "exe", "dll"
    )

    fun importBytes(session: NovaSession, bytes: ByteArray, fileName: String): Report {
        val name = fileName.lowercase()
        val ext = name.substringAfterLast('.', "")
        return when {
            ext == "zip" || isZip(bytes) -> importZip(session, bytes, fileName)
            ext == "gz" || ext == "gzip" -> importGzip(session, bytes, fileName)
            ext in archiveHint -> Report(
                message = "Format .$ext non lu nativement. Convertis en .zip (ou extrais les .txt/.json) puis réimporte."
            )
            ext in binarySkip -> Report(
                message = "Fichier binaire .$ext ignoré (pas une leçon texte)."
            )
            else -> {
                val raw = decodeText(bytes)
                if (raw.isBlank()) Report(skipped = 1, message = "Contenu vide ou illisible.")
                else importText(session, raw, fileName)
            }
        }
    }

    fun importText(session: NovaSession, raw: String, fileName: String = ""): Report {
        val name = fileName.lowercase()
        return when {
            name.endsWith(".jsonl") || looksLikeJsonl(raw) -> importJsonl(session, raw)
            name.endsWith(".json") || raw.trimStart().startsWith("{") || raw.trimStart().startsWith("[") ->
                importJson(session, raw)
            else -> importPlainText(session, raw)
        }
    }

    fun importFile(session: NovaSession, file: File): Report {
        if (!file.isFile) return Report(message = "Fichier introuvable.")
        return importBytes(session, file.readBytes(), file.name)
    }

    private fun isZip(bytes: ByteArray): Boolean =
        bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte()

    private fun importZip(session: NovaSession, bytes: ByteArray, fileName: String): Report {
        var total = Report()
        var files = 0
        return try {
            ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val entryName = entry.name.substringAfterLast('/').substringAfterLast('\\')
                    if (!entry.isDirectory && entryName.isNotBlank() && !entryName.startsWith(".")) {
                        val ext = entryName.substringAfterLast('.', "").lowercase()
                        if (ext in binarySkip || ext in archiveHint) {
                            total += Report(skipped = 1)
                        } else {
                            val content = zis.readBytes()
                            if (content.isNotEmpty() && content.size < 8_000_000) {
                                total += importBytes(session, content, entryName)
                                files++
                            } else {
                                total += Report(skipped = 1)
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            total.copy(
                message = "Zip « $fileName » : $files fichier(s). K=${total.knowledge} M=${total.memories} S=${total.supervised}"
            )
        } catch (e: Exception) {
            Report(message = "Zip illisible : ${e.message}")
        }
    }

    private fun importGzip(session: NovaSession, bytes: ByteArray, fileName: String): Report {
        return try {
            GZIPInputStream(ByteArrayInputStream(bytes)).use { gis ->
                val inner = gis.readBytes()
                val innerName = fileName.removeSuffix(".gz").removeSuffix(".gzip")
                importBytes(session, inner, innerName)
            }
        } catch (e: Exception) {
            Report(message = "GZip illisible : ${e.message}")
        }
    }

    private fun decodeText(bytes: ByteArray): String {
        val charsets = listOf(Charsets.UTF_8, Charset.forName("ISO-8859-1"), Charsets.UTF_16)
        for (cs in charsets) {
            try {
                val s = String(bytes, cs)
                if (s.count { it == '\uFFFD' } < s.length / 10) return s
            } catch (_: Exception) {
            }
        }
        return String(bytes, Charsets.UTF_8)
    }

    private fun looksLikeJsonl(raw: String): Boolean {
        val first = raw.lineSequence().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: return false
        return first.startsWith("{") && (
            first.contains("\"prompt\"") || first.contains("\"completion\"") || first.contains("\"question\"")
            )
    }

    private fun importPlainText(session: NovaSession, raw: String): Report {
        var know = 0
        var mem = 0
        var skip = 0
        val blocks = raw.split(Regex("\n\\s*\n")).map { it.trim() }.filter { it.isNotEmpty() }
        val units = if (blocks.size > 1 && blocks.any { it.length > 80 }) {
            blocks
        } else {
            raw.split(Regex("\r?\n")).map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
        }
        for (line in units) {
            val cleaned = line.removePrefix("- ").removePrefix("* ").trim()
            when {
                cleaned.contains(":") && cleaned.indexOf(':') in 1..80 -> {
                    val idx = cleaned.indexOf(':')
                    val subject = cleaned.substring(0, idx).trim()
                    val fact = cleaned.substring(idx + 1).trim()
                    if (fact.length >= 3 && subject.length in 1..80) {
                        session.learning.learn(subject, PhraseComposer.ensureSentence(fact), 0.9)
                        session.memory.remember("$subject : $fact", 4)
                        know++
                        mem++
                    } else skip++
                }
                cleaned.length >= 8 -> {
                    val subject = inferSubject(cleaned)
                    session.learning.learn(subject, PhraseComposer.ensureSentence(cleaned), 0.85)
                    session.memory.remember(cleaned, 3)
                    know++
                    mem++
                }
                else -> skip++
            }
        }
        return Report(knowledge = know, memories = mem, skipped = skip, message = "Texte : $know faits, $mem souvenirs.")
    }

    private fun inferSubject(line: String): String {
        val words = line.lowercase().split(Regex("\\W+")).filter { it.length > 3 }
        return words.take(2).joinToString(" ").ifBlank { "import" }.take(40)
    }

    private fun importJson(session: NovaSession, raw: String): Report {
        var know = 0
        var mem = 0
        var supervised = 0
        var experiences = 0
        var skip = 0
        try {
            val trimmed = raw.trim()
            if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                for (i in 0 until arr.length()) {
                    when (val item = arr.opt(i)) {
                        is String -> if (item.length >= 8) {
                            session.learning.learn(inferSubject(item), PhraseComposer.ensureSentence(item), 0.85)
                            know++
                        } else skip++
                        is JSONObject -> {
                            val r = ingestJsonObject(session, item)
                            know += r.knowledge
                            mem += r.memories
                            supervised += r.supervised
                            experiences += r.experiences
                            skip += r.skipped
                        }
                        else -> skip++
                    }
                }
            } else {
                val root = JSONObject(trimmed)
                if (root.has("facts")) {
                    val arr = root.getJSONArray("facts")
                    for (i in 0 until arr.length()) {
                        val f = arr.optString(i, "")
                        if (f.length >= 3) {
                            session.learning.learn(inferSubject(f), PhraseComposer.ensureSentence(f), 0.9)
                            session.memory.remember(f, 3)
                            know++
                            mem++
                        } else skip++
                    }
                }
                if (root.has("knowledge")) {
                    val arr = root.getJSONArray("knowledge")
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val subject = o.optString("subject", o.optString("topic", "import"))
                        val fact = o.optString("fact", o.optString("text", ""))
                        if (fact.length >= 3) {
                            session.learning.learn(
                                subject,
                                PhraseComposer.ensureSentence(fact),
                                o.optDouble("confidence", 0.9)
                            )
                            know++
                        } else skip++
                    }
                }
                if (root.has("memories")) {
                    val arr = root.getJSONArray("memories")
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val text = o.optString("text", o.optString("content", ""))
                        if (text.length >= 3) {
                            session.memory.remember(text, o.optInt("importance", 3))
                            mem++
                        }
                    }
                }
                if (root.has("supervised_pairs")) {
                    val arr = root.getJSONArray("supervised_pairs")
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val q = o.optString("question", o.optString("prompt", ""))
                        val a = o.optString("preferred", o.optString("completion", o.optString("answer", "")))
                        if (q.length >= 2 && a.length >= 2) {
                            session.development.supervised.add(q, a)
                            supervised++
                        }
                    }
                }
                if (!root.has("facts") && !root.has("knowledge") && !root.has("memories") && !root.has("supervised_pairs")) {
                    val r = ingestJsonObject(session, root)
                    know += r.knowledge
                    mem += r.memories
                    supervised += r.supervised
                    experiences += r.experiences
                    skip += r.skipped
                }
            }
        } catch (e: Exception) {
            return Report(message = "JSON invalide : ${e.message}")
        }
        return Report(know, mem, supervised, experiences, skip, "JSON : K=$know M=$mem S=$supervised")
    }

    private fun ingestJsonObject(session: NovaSession, o: JSONObject): Report {
        var know = 0
        var supervised = 0
        var skip = 0
        val fact = o.optString("fact", o.optString("text", o.optString("content", "")))
        val subject = o.optString("subject", o.optString("topic", inferSubject(fact)))
        if (fact.length >= 3) {
            session.learning.learn(subject, PhraseComposer.ensureSentence(fact), o.optDouble("confidence", 0.9))
            know++
        }
        val q = o.optString("question", o.optString("prompt", ""))
        val a = o.optString("preferred", o.optString("completion", o.optString("answer", "")))
        if (q.length >= 2 && a.length >= 2) {
            session.development.supervised.add(q, a)
            supervised++
        }
        if (know == 0 && supervised == 0) skip++
        return Report(knowledge = know, supervised = supervised, skipped = skip)
    }

    private fun importJsonl(session: NovaSession, raw: String): Report {
        var know = 0
        var supervised = 0
        var skip = 0
        for (line in raw.lineSequence()) {
            val t = line.trim()
            if (t.isEmpty() || t.startsWith("#")) continue
            try {
                val o = JSONObject(t)
                val q = o.optString("prompt", o.optString("question", ""))
                val a = o.optString("completion", o.optString("preferred", o.optString("answer", "")))
                if (q.length >= 2 && a.length >= 2) {
                    session.development.supervised.add(q, a)
                    session.learning.learn(inferSubject(q), PhraseComposer.ensureSentence(a), 0.9)
                    supervised++
                    know++
                } else {
                    val fact = o.optString("fact", o.optString("text", ""))
                    if (fact.length >= 3) {
                        session.learning.learn(inferSubject(fact), PhraseComposer.ensureSentence(fact), 0.85)
                        know++
                    } else skip++
                }
            } catch (_: Exception) {
                skip++
            }
        }
        return Report(
            knowledge = know,
            supervised = supervised,
            skipped = skip,
            message = "JSONL : S=$supervised K=$know"
        )
    }
}
