package com.nova.ai

import android.content.Context

object Onboarding {
    private fun p(ctx: Context) = ctx.getSharedPreferences("nova_onboarding", Context.MODE_PRIVATE)

    fun isDone(ctx: Context): Boolean = p(ctx).getBoolean("done", false)

    fun markDone(ctx: Context) {
        p(ctx).edit().putBoolean("done", true).apply()
    }

    fun saveSecret(ctx: Context, mascotId: String, secret: String) {
        p(ctx).edit().putString("secret_$mascotId", secret).apply()
    }

    fun secret(ctx: Context, mascotId: String): String? =
        p(ctx).getString("secret_$mascotId", null)
}
