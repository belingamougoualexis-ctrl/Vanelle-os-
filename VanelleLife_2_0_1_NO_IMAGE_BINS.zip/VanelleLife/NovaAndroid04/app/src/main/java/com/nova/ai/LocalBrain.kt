package com.nova.ai

/**
 * Cerveau local : mémoire + corrections + personnalité visible dans le ton.
 */
class LocalBrain(
    private val development: DevelopmentEngine,
    private val learning: LearningStore,
    private val memory: MemoryStore,
    private val displayName: String = "Vanelle",
    /** Prompt système utilisateur — influence réellement le ton / les priorités locales. */
    var systemPrompt: String = ""
) {
    fun reply(userText: String): String {
        val lower = userText.lowercase().trim()
        val state = development.state()
        // Réponses méta sur le prompt système
        if (lower.contains("prompt système") || lower.contains("prompt systeme") || lower == "qui es-tu" || lower == "qui es tu") {
            val sp = systemPrompt.trim()
            if (sp.isNotEmpty()) {
                return colorWithPersonality(
                    "Mon prompt système actuel : « ${sp.take(280)} »${if (sp.length > 280) "…" else ""}",
                    state
                )
            }
        }

        val supervised = development.supervised.relevant(userText, limit = 1)
        if (supervised.isNotEmpty()) {
            val preferred = supervised.first().preferred
            return colorWithPersonality(
                PhraseComposer.composeAnswer(userText, displayName, emptyList(), emptyList(), emptyList(), preferred),
                state
            )
        }

        when {
            isGreeting(lower) -> return colorWithPersonality(greeting(state), state)
            isIdentityQuestion(lower) -> return colorWithPersonality(identity(state), state)
            isHowAreYou(lower) -> return colorWithPersonality(mood(state), state)
            isTeachIntent(lower) -> return colorWithPersonality(
                "D'accord. Dis-moi clairement le fait à retenir, je l'enregistrerai.", state
            )
            isThanks(lower) -> return colorWithPersonality(thanksLine(), state)
        }

        val know = learning.knowledge().filter { k ->
            overlaps(lower, k.subject) || overlaps(lower, k.fact)
        }.sortedByDescending { it.confidence }.take(6)

        val mems = memory.relevant(userText, limit = 6)
        val concepts = development.concepts.relevantTo(
            lower.split(Regex("\\W+")).filter { it.length > 2 }.toSet()
        )

        if (know.isNotEmpty() || mems.isNotEmpty() || concepts.isNotEmpty()) {
            val composed = PhraseComposer.composeAnswer(
                userText, displayName, know, mems, concepts, null
            )
            val body = composed.ifBlank { buildFromKnowledge(userText, know, mems, concepts, state) }
            return applySystemPrompt(colorWithPersonality(body, state), state)
        }

        return applySystemPrompt(colorWithPersonality(unknown(userText, state), state), state)
    }

    /** Applique des directives du prompt système (mots-clés simples, réel et déterministe). */
    private fun applySystemPrompt(text: String, state: DevelopmentEngine.State): String {
        val sp = systemPrompt.lowercase()
        if (sp.isBlank()) return text
        var t = text
        if (sp.contains("tutoi") || sp.contains("tutoyer")) {
            t = t.replace("vous ", "tu ").replace("Vous ", "Tu ")
        }
        if (sp.contains("vouvoi")) {
            t = t.replace(" tu ", " vous ").replace("Tu ", "Vous ")
        }
        if ((sp.contains("court") || sp.contains("brief") || sp.contains("concis")) && t.length > 160) {
            t = t.take(157).trimEnd() + "…"
        }
        if (sp.contains("emoji") && !t.contains("😊") && !t.contains("✨")) {
            t = "$t ✨"
        }
        if (sp.contains("ne dis jamais je ne sais") || sp.contains("toujours une idée")) {
            if (t.contains("je ne sais pas", ignoreCase = true)) {
                t = "Hmm, je n'ai pas encore la réponse exacte, mais on peut explorer ensemble."
            }
        }
        return t
    }

    /** Teinte le style selon les traits dominants. */
    private fun colorWithPersonality(text: String, state: DevelopmentEngine.State): String {
        val traits = learning.traits().sortedByDescending { kotlin.math.abs(it.value - 0.5) }
        val top = traits.firstOrNull() ?: return text
        val t = text.trim()
        return when {
            top.name.contains("curios", true) && top.value > 0.6 ->
                if (t.endsWith("?")) t else "$t Tu m'en dis un peu plus ?"
            top.name.contains("humil", true) && top.value > 0.6 ->
                if (t.contains("je ne sais")) t else t
            top.name.contains("confiance", true) && top.value > 0.65 ->
                t.replace("peut-être", "sûrement").let { if (it == t) "$t." else it }
            top.name.contains("profondeur", true) && top.value > 0.6 ->
                "$t (J'y pense avec le stade ${state.stage}.)"
            top.name.contains("prudence", true) && top.value > 0.6 ->
                if (t.contains("je ne sais")) t else "Si j'ai bien compris : $t"
            else -> t
        }.trim()
    }

    private fun thanksLine(): String {
        val traits = learning.traits()
        val warm = traits.any { it.name.contains("confiance") && it.value > 0.55 }
        return if (warm) "Avec grand plaisir. Ça me fait grandir." else "Avec plaisir. Continuons quand tu veux."
    }

    private fun buildFromKnowledge(
        query: String,
        know: List<Knowledge>,
        mems: List<Memory>,
        concepts: List<Concept>,
        state: DevelopmentEngine.State
    ): String {
        val parts = mutableListOf<String>()
        if (know.isNotEmpty()) {
            parts.add(know.joinToString(" ") { it.fact.trim().trimEnd('.') + "." })
        }
        if (mems.isNotEmpty() && know.isEmpty()) {
            parts.add("Je me souviens : " + mems.joinToString(" · ") { it.text.take(100) })
        }
        if (concepts.isNotEmpty()) {
            parts.add("Concepts liés : " + concepts.take(3).joinToString(", ") { it.name })
        }
        if (parts.isEmpty()) return unknown(query, state)
        return parts.joinToString(" ")
    }

    private fun unknown(userText: String, state: DevelopmentEngine.State): String {
        val curios = listOf(
            "Je ne sais pas encore ça. Tu peux me l'apprendre ?",
            "Ce n'est pas dans ma mémoire. Explique-moi, je retiendrai.",
            "Je n'ai pas d'expérience là-dessus. Que veux-tu que je sache ?",
            "Inconnu pour moi pour l'instant. Enseigne-moi en une phrase claire."
        )
        val base = curios[Math.floorMod(userText.hashCode(), curios.size)]
        return when (state.stage) {
            "Naissance", "Œuf" -> "$base (Je débute à peine.)"
            else -> base
        }
    }

    private fun greeting(state: DevelopmentEngine.State): String {
        return "Bonjour. Je suis $displayName, stade ${state.stage}. " +
            "${state.experiences} expériences, ${state.knowledge} connaissances. Que veux-tu faire ?"
    }

    private fun identity(state: DevelopmentEngine.State): String {
        val prefs = learning.knowledge().filter {
            it.subject.contains("préférence", true) || it.subject.contains("identité", true)
        }.take(4)
        val traits = learning.traits().sortedByDescending { kotlin.math.abs(it.value - 0.5) }.take(3)
        return buildString {
            append("Je suis $displayName. Stade : ${state.stage}. ")
            append("Je grandis par ce que tu m'enseignes. ")
            if (prefs.isNotEmpty()) {
                append("Ce que je retiens : ")
                append(prefs.joinToString(" ; ") { it.fact.take(60) })
                append(". ")
            }
            if (traits.isNotEmpty()) {
                append("Ma personnalité : ")
                append(traits.joinToString(", ") {
                    val level = when {
                        it.value > 0.7 -> "forte"
                        it.value > 0.55 -> "marquée"
                        else -> "naissante"
                    }
                    "${it.name} ($level)"
                })
                append(".")
            }
        }
    }

    private fun mood(state: DevelopmentEngine.State): String {
        val cur = state.curiosity
        return when {
            cur > 70 -> "Curieuse — j'ai envie d'apprendre encore. Tu as quelque chose à m'enseigner ?"
            state.unconsolidated > 5 -> "Un peu saturée d'expériences non consolidées. Tu peux lancer Consolider."
            else -> "Stable. Stade ${state.stage}, ${state.memories} souvenirs. Et toi ?"
        }
    }

    private fun polish(text: String, state: DevelopmentEngine.State): String {
        return text.trim().ifBlank { unknown("?", state) }
    }

    private fun overlaps(a: String, b: String): Boolean {
        val wa = a.split(Regex("\\W+")).filter { it.length > 2 }.toSet()
        val wb = b.lowercase().split(Regex("\\W+")).filter { it.length > 2 }.toSet()
        return wa.any { it in wb }
    }

    private fun isGreeting(s: String) =
        listOf("bonjour", "salut", "hello", "hey", "bonsoir", "coucou").any { s.startsWith(it) || s == it }

    private fun isIdentityQuestion(s: String) =
        listOf("qui es-tu", "tu es qui", "présente-toi", "c'est quoi nova", "que es-tu").any { s.contains(it) }

    private fun isHowAreYou(s: String) =
        listOf("comment ça va", "ça va", "tu vas bien", "how are you").any { s.contains(it) }

    private fun isTeachIntent(s: String) =
        listOf(
            "enseigne", "apprends", "retenir", "rappelle", "souviens", "mémorise",
            "remember", "retenons", "note que", "il faut savoir"
        ).any { s.contains(it) }

    private fun isThanks(s: String) =
        listOf("merci", "thanks", "thank you").any { s.contains(it) }
}
