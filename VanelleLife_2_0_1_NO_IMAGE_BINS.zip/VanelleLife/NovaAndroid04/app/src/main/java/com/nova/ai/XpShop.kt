package com.nova.ai

import android.content.Context

/**
 * Boutique XP : looks / titres / auras / voix — pas l'intelligence.
 */
object XpShop {

    data class Item(
        val id: String,
        val label: String,
        val description: String,
        val cost: Int,
        val kind: Kind
    ) {
        enum class Kind { SKIN, TITLE, AURA, VOICE_PROFILE, BOOST }
    }

    val CATALOG = listOf(
        // Skins
        Item("skin_vanelle_gold", "Skin Or", "Apparence luxe dorée", 80, Item.Kind.SKIN),
        Item("skin_vanelle_bronze", "Skin Bronze", "Apparence bronze", 55, Item.Kind.SKIN),
        Item("skin_vanelle_steel", "Skin Acier", "Apparence métal", 55, Item.Kind.SKIN),
        Item("skin_vanelle_lava", "Skin Lave", "Apparence magma", 60, Item.Kind.SKIN),
        Item("skin_vanelle_aurora", "Skin Aurore", "Apparence boréale", 70, Item.Kind.SKIN),
        Item("skin_vanelle_ice", "Skin Glace", "Apparence cristalline", 60, Item.Kind.SKIN),
        Item("skin_vanelle_iridescent", "Skin Irisé", "Apparence holographique", 100, Item.Kind.SKIN),
        Item("skin_vanelle_dark", "Skin Sombre", "Apparence dark", 50, Item.Kind.SKIN),
        Item("skin_vanelle_ocean_dark", "Skin Océan sombre", "Vague sombre", 65, Item.Kind.SKIN),
        // Titres
        Item("title_explorer", "Titre · Exploratrice", "Badge Exploratrice", 30, Item.Kind.TITLE),
        Item("title_scholar", "Titre · Erudite", "Badge Erudite", 50, Item.Kind.TITLE),
        Item("title_legend", "Titre · Légende", "Badge Légende", 120, Item.Kind.TITLE),
        Item("title_bestie", "Titre · Meilleure amie", "Badge Meilleure amie", 40, Item.Kind.TITLE),
        Item("title_guardian", "Titre · Gardienne", "Badge Gardienne", 45, Item.Kind.TITLE),
        Item("title_star", "Titre · Étoile", "Badge Étoile", 35, Item.Kind.TITLE),
        // Auras
        Item("aura_soft", "Aura douce", "Lueur violette sur la bulle", 25, Item.Kind.AURA),
        Item("aura_fire", "Aura feu", "Lueur chaude", 35, Item.Kind.AURA),
        Item("aura_ocean", "Aura océan", "Lueur bleue", 35, Item.Kind.AURA),
        Item("aura_gold", "Aura dorée", "Lueur or", 50, Item.Kind.AURA),
        // Voix
        Item("voice_soft", "Voix douce", "Ton aigu, débit calme", 20, Item.Kind.VOICE_PROFILE),
        Item("voice_deep", "Voix grave", "Ton plus bas", 20, Item.Kind.VOICE_PROFILE),
        Item("voice_energetic", "Voix énergique", "Débit vif", 25, Item.Kind.VOICE_PROFILE),
        Item("voice_slow", "Voix lente", "Débit posé (apprentissage)", 20, Item.Kind.VOICE_PROFILE),
        // Boosts (consommables : +XP structure via journal, petit bonus)
        Item("boost_candy", "Bonbon d'XP", "+15 XP boutique instantanés (cadeau)", 0, Item.Kind.BOOST)
    )

    val FREE_SKINS = setOf(
        "vanelle_cosmos", "vanelle_kawaii_purple", "vanelle_kawaii_wink",
        "vanelle_kawaii_star", "vanelle_green", "vanelle_mint", "vanelle_slate", "vanelle_amber"
    )

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("nova_shop", Context.MODE_PRIVATE)

    fun owned(ctx: Context, mascotId: String): Set<String> {
        val raw = prefs(ctx).getString("owned_$mascotId", "") ?: ""
        return raw.split(",").filter { it.isNotBlank() }.toSet()
    }

    fun has(ctx: Context, mascotId: String, itemId: String): Boolean =
        itemId in owned(ctx, mascotId)

    fun activeTitle(ctx: Context, mascotId: String): String =
        prefs(ctx).getString("title_$mascotId", "") ?: ""

    fun activeAura(ctx: Context, mascotId: String): String =
        prefs(ctx).getString("aura_$mascotId", "") ?: ""

    fun setTitle(ctx: Context, mascotId: String, titleId: String) {
        prefs(ctx).edit().putString("title_$mascotId", titleId).apply()
    }

    fun setAura(ctx: Context, mascotId: String, auraId: String) {
        prefs(ctx).edit().putString("aura_$mascotId", auraId).apply()
    }

    fun titleLabel(titleId: String): String = when (titleId) {
        "title_explorer" -> "Exploratrice"
        "title_scholar" -> "Erudite"
        "title_legend" -> "Légende"
        "title_bestie" -> "Meilleure amie"
        "title_guardian" -> "Gardienne"
        "title_star" -> "Étoile"
        else -> ""
    }

    fun spendableXp(ctx: Context, mascotId: String): Int {
        val bonus = GrowthSystem.bonusXp(ctx, mascotId)
        val spent = prefs(ctx).getInt("spent_$mascotId", 0)
        return (bonus - spent).coerceAtLeast(0)
    }

    fun buy(ctx: Context, mascotId: String, item: Item): String? {
        if (item.kind == Item.Kind.BOOST) {
            // bonbon gratuit une fois pour découvrir la boutique
            if (has(ctx, mascotId, item.id)) return "Déjà pris"
            val owned = owned(ctx, mascotId).toMutableSet()
            owned.add(item.id)
            prefs(ctx).edit().putString("owned_$mascotId", owned.joinToString(",")).apply()
            GrowthSystem.addBonusXp(ctx, mascotId, 15)
            return null
        }
        if (has(ctx, mascotId, item.id)) return "Déjà possédé"
        val available = spendableXp(ctx, mascotId)
        if (available < item.cost) return "Pas assez d'XP (il te faut ${item.cost}, tu as $available)"
        val p = prefs(ctx)
        val owned = owned(ctx, mascotId).toMutableSet()
        owned.add(item.id)
        val spent = p.getInt("spent_$mascotId", 0) + item.cost
        p.edit()
            .putString("owned_$mascotId", owned.joinToString(","))
            .putInt("spent_$mascotId", spent)
            .apply()
        when (item.kind) {
            Item.Kind.TITLE -> setTitle(ctx, mascotId, item.id)
            Item.Kind.AURA -> setAura(ctx, mascotId, item.id)
            else -> {}
        }
        return null
    }

    fun skinIdFromItem(itemId: String): String? =
        if (itemId.startsWith("skin_")) itemId.removePrefix("skin_") else null

    fun voiceSettingsFor(itemId: String, languageTag: String = LanguageCatalog.DEFAULT): VoiceEngine.VoiceSettings? = when (itemId) {
        "voice_soft" -> VoiceEngine.VoiceSettings("", 1.15f, 0.92f, languageTag)
        "voice_deep" -> VoiceEngine.VoiceSettings("", 0.82f, 0.95f, languageTag)
        "voice_energetic" -> VoiceEngine.VoiceSettings("", 1.05f, 1.15f, languageTag)
        "voice_slow" -> VoiceEngine.VoiceSettings("", 1.0f, 0.75f, languageTag)
        else -> null
    }

    fun isSkinUnlocked(ctx: Context, mascotId: String, skin: String): Boolean {
        if (skin in FREE_SKINS) return true
        return has(ctx, mascotId, "skin_$skin")
    }
}
