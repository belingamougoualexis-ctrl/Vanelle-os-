package com.nova.ai.platform

data class SecretReference(
    val providerId: String,
    val keyAlias: String
)

object SecretBoundary {
    fun allowedInPortableManifest(value: Any?): Boolean = false
    fun redactForLogs(value: String): String =
        if (value.length <= 8) "••••" else value.take(3) + "••••••" + value.takeLast(3)
}
