package com.nova.ai

import android.content.Context
import java.security.MessageDigest
import java.security.spec.KeySpec
import java.util.UUID
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Compte 100 % local (aucun serveur).
 * Changement de téléphone = exporter le compte → importer sur le nouveau + même mot de passe.
 */
class AccountStore(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("nova_account", Context.MODE_PRIVATE)

    data class Account(
        val id: String,
        val username: String,
        val passwordHash: String,
        val createdAt: Long
    )

    fun isLoggedIn(): Boolean = p.getBoolean("logged_in", false) && current() != null

    fun current(): Account? {
        val id = p.getString("id", null) ?: return null
        val user = p.getString("username", null) ?: return null
        val hash = p.getString("password_hash", null) ?: return null
        val created = p.getLong("created_at", 0L)
        return Account(id, user, hash, created)
    }

    fun register(username: String, password: String): String? {
        val u = username.trim()
        if (u.length < 3) return "Identifiant trop court (min. 3)"
        if (password.length < 4) return "Mot de passe trop court (min. 4)"
        if (hasAccount() && isLoggedIn()) {
            return "Déconnecte-toi d'abord (Info → Déconnexion) pour créer un autre compte."
        }
        if (hasAccount() && !isLoggedIn()) {
            // Réinscription après déconnexion : nouveau compte local propre
            clearAccountHard()
        }
        // Si compte local existe mais pas connecté → écrasement uniquement après confirmation côté UI
        val id = UUID.randomUUID().toString()
        val hash = hashPassword(password, id)
        p.edit()
            .putString("id", id)
            .putString("username", u)
            .putString("password_hash", hash)
            .putLong("created_at", System.currentTimeMillis())
            .putBoolean("logged_in", true)
            .apply()
        return null
    }

    /** Réécrit le compte (après import). */
    fun restoreAccount(id: String, username: String, passwordHash: String, createdAt: Long) {
        p.edit()
            .putString("id", id)
            .putString("username", username)
            .putString("password_hash", passwordHash)
            .putLong("created_at", createdAt)
            .putBoolean("logged_in", true)
            .apply()
    }

    fun login(username: String, password: String): String? {
        val acc = current() ?: return "Aucun compte local. Inscris-toi ou importe un fichier compte."
        if (!acc.username.equals(username.trim(), ignoreCase = true)) {
            return "Identifiant incorrect"
        }
        if (!verifyStored(password, acc.id, acc.passwordHash)) return "Mot de passe incorrect"
        // Migration transparente : si l'ancien format (SHA-256 mono-passage) est détecté,
        // on le remplace par PBKDF2 dès qu'on a le mot de passe en clair (au login réussi).
        if (!acc.passwordHash.startsWith("$PREFIX$")) {
            p.edit().putString("password_hash", hashPassword(password, acc.id)).apply()
        }
        p.edit().putBoolean("logged_in", true).apply()
        return null
    }

    /** Vérifie le mot de passe pour export sécurisé. */
    fun verifyPassword(password: String): Boolean {
        val acc = current() ?: return false
        return verifyStored(password, acc.id, acc.passwordHash)
    }

    fun logout() {
        p.edit().putBoolean("logged_in", false).apply()
    }

    fun clearAccountHard() {
        p.edit().clear().apply()
    }

    fun hasAccount(): Boolean = p.getString("id", null) != null

    companion object {
        private const val PREFIX = "pbkdf2-sha256"
        private const val ITERATIONS = 210_000 // recommandation OWASP 2023 pour PBKDF2-HMAC-SHA256
        private const val KEY_LENGTH_BITS = 256

        /**
         * PBKDF2-HMAC-SHA256, 210 000 itérations. Le "salt" applicatif (id de compte, UUID v4,
         * ~122 bits d'entropie, jamais choisi par l'attaquant) est d'abord étendu en 16 octets via
         * SHA-256 pour servir de sel cryptographique au sens strict de PBKDF2.
         * Format de sortie auto-descriptif : "pbkdf2-sha256$<iterations>$<hash_hex>"
         * (le salt applicatif n'a pas besoin d'être stocké séparément : il est déjà connu = acc.id).
         */
        fun hashPassword(password: String, salt: String): String {
            val saltBytes = MessageDigest.getInstance("SHA-256").digest(salt.toByteArray(Charsets.UTF_8))
            val spec: KeySpec = PBEKeySpec(password.toCharArray(), saltBytes, ITERATIONS, KEY_LENGTH_BITS)
            val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            val hash = factory.generateSecret(spec).encoded
            return "$PREFIX$${ITERATIONS}$${hash.joinToString("") { "%02x".format(it) }}"
        }

        /** Ancien format (SHA-256 mono-passage), conservé uniquement pour vérifier les comptes existants. */
        private fun legacyHash(password: String, salt: String): String {
            val md = MessageDigest.getInstance("SHA-256")
            val bytes = md.digest("$salt::$password".toByteArray(Charsets.UTF_8))
            return bytes.joinToString("") { "%02x".format(it) }
        }

        /** Vérifie un mot de passe contre un hash stocké, quel que soit son format (nouveau ou legacy). */
        fun verifyStored(password: String, salt: String, storedHash: String): Boolean {
            return if (storedHash.startsWith("$PREFIX$")) {
                constantTimeEquals(hashPassword(password, salt), storedHash)
            } else {
                constantTimeEquals(legacyHash(password, salt), storedHash)
            }
        }

        /** Comparaison en temps constant pour limiter les attaques par mesure de timing. */
        private fun constantTimeEquals(a: String, b: String): Boolean {
            if (a.length != b.length) return false
            var result = 0
            for (i in a.indices) result = result or (a[i].code xor b[i].code)
            return result == 0
        }
    }
}
