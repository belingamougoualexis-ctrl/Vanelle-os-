package com.nova.ai

import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import org.json.JSONObject

/** Password-protected export envelope for AI credentials. */
object AIExportCrypto {
    private const val ITERATIONS = 120_000
    private const val KEY_BITS = 256
    fun encrypt(value: String, password: String): String {
        require(password.length >= 8) { "Le mot de passe d'export doit contenir au moins 8 caractères." }
        val salt=ByteArray(16); SecureRandom().nextBytes(salt)
        val iv=ByteArray(12); SecureRandom().nextBytes(iv)
        val spec=PBEKeySpec(password.toCharArray(),salt,ITERATIONS,KEY_BITS)
        val raw=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,SecretKeySpec(raw,"AES"),GCMParameterSpec(128,iv))
        val out=c.doFinal(value.toByteArray(StandardCharsets.UTF_8))
        return JSONObject().put("kdf","PBKDF2-HMAC-SHA256").put("iterations",ITERATIONS).put("salt",Base64.encodeToString(salt,Base64.NO_WRAP)).put("iv",Base64.encodeToString(iv,Base64.NO_WRAP)).put("ciphertext",Base64.encodeToString(out,Base64.NO_WRAP)).toString()
    }
    fun decrypt(envelope:String,password:String):String {
        val o=JSONObject(envelope);val salt=Base64.decode(o.getString("salt"),Base64.NO_WRAP);val iv=Base64.decode(o.getString("iv"),Base64.NO_WRAP);val spec=PBEKeySpec(password.toCharArray(),salt,o.optInt("iterations",ITERATIONS),KEY_BITS);val raw=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded;val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,SecretKeySpec(raw,"AES"),GCMParameterSpec(128,iv));return String(c.doFinal(Base64.decode(o.getString("ciphertext"),Base64.NO_WRAP)),StandardCharsets.UTF_8)
    }
}
