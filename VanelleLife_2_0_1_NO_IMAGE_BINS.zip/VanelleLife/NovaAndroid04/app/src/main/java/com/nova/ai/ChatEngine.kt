package com.nova.ai

import android.content.Context
import com.nova.ai.llm.LlmRouter
import com.nova.ai.llm.RuleBasedLlm
import com.nova.ai.platform.CapabilityPolicy
import com.nova.ai.platform.ProviderExecutor
import com.nova.ai.platform.ProviderRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Réponses IA unifiées.
 * Priorité : Provider HTTPS → LLM on-device → LocalBrain
 */
object ChatEngine {

    enum class Source { EXTERNAL_PROVIDER, ON_DEVICE_LLM, LOCAL_RULES_ENGINE }
    data class Reply(val text: String, val source: Source, val providerName: String? = null)

    fun buildSystemPrompt(session: NovaSession): String {
        val custom = session.mascot.systemPrompt.trim()
        val base = buildString {
            append("Tu es ")
            append(session.mascot.name)
            append(", mascotte personnelle élevée par l'utilisateur. ")
            append("Réponds en français, de façon claire et utile. ")
            append("Utilise en priorité les faits et souvenirs fournis dans le contexte. ")
            append("Si tu n'as pas l'info, dis-le honnêtement plutôt qu'inventer.")
        }
        return if (custom.isBlank()) base else "$custom\n\n$base"
    }

    fun buildContextPack(session: NovaSession, userText: String): String {
        val know = session.learning.knowledge()
            .sortedByDescending { it.confidence }
            .take(12)
            .joinToString("\n") { "- [${it.subject}] ${it.fact}" }
        val mems = session.memory.relevant(userText, limit = 8)
            .joinToString("\n") { "- ${it.text}" }
        val supervised = session.development.supervised.relevant(userText, limit = 4)
            .joinToString("\n") { "- Q: ${it.input} → R: ${it.preferred}" }
        val recent = session.journal.recentTextSummary(limit = 8)
        return buildString {
            if (know.isNotBlank()) append("FAITS APPRIS:\n").append(know).append("\n\n")
            if (mems.isNotBlank()) append("SOUVENIRS:\n").append(mems).append("\n\n")
            if (supervised.isNotBlank()) append("RÉPONSES PRÉFÉRÉES:\n").append(supervised).append("\n\n")
            if (recent.isNotBlank()) append("HISTORIQUE RÉCENT:\n").append(recent)
        }.trim()
    }

    suspend fun reply(context: Context, session: NovaSession, userText: String): Reply =
        withContext(Dispatchers.IO) {
            // Enseignement explicite → confirmation. Faits ordinaires → absorbés en silence puis réponse.
            val taught = TeachCapture.apply(session, userText)
            if (taught != null) {
                session.journal.add("enseignement", taught.take(120))
                return@withContext Reply("C'est noté. Je retiendrai : $taught", Source.LOCAL_RULES_ENGINE)
            }
            TeachCapture.absorbSilently(session, userText)

            val system = buildSystemPrompt(session)
            val contextPack = buildContextPack(session, userText)
            val registry = ProviderRegistry(context)
            val vault = AISecretVault(context)
            val provider = registry.all().firstOrNull {
                it.enabled && it.capabilities.any { c ->
                    c.equals("chat", true) || c.equals("text", true)
                }
            }

            if (provider != null) {
                val secret = vault.get(provider.id)
                if (secret.isNullOrBlank()) {
                    // Pas de clé : on n'appelle pas le réseau, on bascule local
                } else {
                    val outcome = runCatching {
                        CapabilityPolicy.validateExternalEndpoint(provider.endpoint)
                        val variables = mapOf(
                            "prompt" to userText,
                            "message" to userText,
                            "user" to userText,
                            "system" to system,
                            "system_prompt" to system,
                            "context" to contextPack,
                            "history" to contextPack
                        )
                        ProviderExecutor.execute(provider, secret, variables, timeoutMs = 90_000)
                    }.getOrNull()
                    if (outcome != null && outcome.ok) {
                        val text = (outcome.extracted?.takeIf { it.isNotBlank() } ?: outcome.body).trim()
                        if (text.isNotBlank()) {
                            return@withContext Reply(text, Source.EXTERNAL_PROVIDER, provider.name)
                        }
                    }
                    // Échec API : message honnête si 401/403, sinon fallback local
                    if (outcome != null && outcome.status in listOf(401, 403)) {
                        return@withContext Reply(
                            "Clé API refusée (${outcome.status}). Vérifie la clé dans Info → Provider API.",
                            Source.EXTERNAL_PROVIDER,
                            provider.name
                        )
                    }
                }
            }

            try {
                val router = LlmRouter(rules = RuleBasedLlm { session.brain })
                val fullHint = buildString {
                    append(system)
                    if (contextPack.isNotBlank()) {
                        append("\n\n")
                        append(contextPack)
                    }
                }
                val (engineId, text) = router.generate(context, userText, fullHint)
                if (text.isNotBlank()) {
                    val src = if (engineId.contains("mediapipe", true) || engineId.contains("gemma", true))
                        Source.ON_DEVICE_LLM else Source.LOCAL_RULES_ENGINE
                    return@withContext Reply(text, src)
                }
            } catch (_: Exception) { }

            Reply(session.brain.reply(userText), Source.LOCAL_RULES_ENGINE)
        }
}
