package com.nova.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.nova.ai.platform.CapabilityPolicy
import com.nova.ai.platform.ProviderExecutor
import com.nova.ai.platform.ProviderRegistry
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Génération d'image via provider HTTPS uniquement (pas de bins MediaPipe / zip).
 */
object ImageGenService {

    data class Result(
        val ok: Boolean,
        val message: String,
        val file: File? = null,
        val source: String? = null
    )

    fun generate(context: Context, prompt: String, systemHint: String = ""): Result {
        val p = prompt.trim()
        if (p.length < 3) return Result(false, "Prompt trop court.")

        val registry = ProviderRegistry(context)
        val vault = AISecretVault(context)
        val imageProvider = registry.all().firstOrNull {
            it.enabled && it.capabilities.any { c ->
                c.equals("image", true) || c.equals("images", true)
            }
        }
        if (imageProvider != null) {
            val secret = vault.get(imageProvider.id)
            val r = runCatching {
                CapabilityPolicy.validateExternalEndpoint(imageProvider.endpoint)
                ProviderExecutor.execute(
                    imageProvider,
                    secret,
                    mapOf(
                        "prompt" to p,
                        "system" to systemHint,
                        "system_prompt" to systemHint
                    ),
                    timeoutMs = 90_000
                )
            }.getOrNull()
            if (r != null && r.ok) {
                val saved = saveFromProviderBody(context, r.body, r.extracted)
                if (saved != null) return Result(true, "Image via ${imageProvider.name}", saved, imageProvider.name)
                val url = extractUrl(r.body, r.extracted)
                if (url != null) {
                    val downloaded = downloadToFile(context, url)
                    if (downloaded != null) return Result(true, "Image via ${imageProvider.name}", downloaded, imageProvider.name)
                }
                return Result(false, "Provider image a répondu sans fichier utilisable.")
            }
            if (r != null) return Result(false, "Échec provider image: ${r.error ?: r.body.take(120)}")
        }

        val studio = AIStudioStore(context)
        val profile = studio.all().firstOrNull { it.imageBackend.startsWith("https") }
        if (profile != null) {
            val key = vault.get("${profile.id}:image") ?: ""
            val body = AIProviderClient.generationRequest(p, "image")
            val r = AIProviderClient.postJson(profile.imageBackend, body, key)
            if (r.ok) {
                val saved = saveFromProviderBody(context, r.body, null)
                if (saved != null) return Result(true, "Image via AI Studio", saved, profile.name)
                val url = extractUrl(r.body, null)
                if (url != null) {
                    val downloaded = downloadToFile(context, url)
                    if (downloaded != null) return Result(true, "Image via AI Studio", downloaded, profile.name)
                }
            }
        }

        return Result(
            false,
            "Aucune génération image disponible. Configure un provider HTTPS avec capacité « image » dans Info."
        )
    }

    fun statusLine(context: Context): String {
        val has = ProviderRegistry(context).all().any {
            it.enabled && it.capabilities.any { c -> c.equals("image", true) }
        }
        return if (has) "Image : provider HTTPS configuré" else "Image : aucun provider (optionnel)"
    }

    private fun saveFromProviderBody(context: Context, body: String, extracted: String?): File? {
        val candidates = listOfNotNull(extracted, body)
        for (c in candidates) {
            val b64 = extractBase64(c) ?: continue
            return try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: continue
                writeBitmap(context, bmp)
            } catch (_: Exception) {
                null
            }
        }
        runCatching {
            val o = JSONObject(body)
            val data = o.optJSONArray("data")
            if (data != null && data.length() > 0) {
                val b64 = data.getJSONObject(0).optString("b64_json", "")
                if (b64.isNotBlank()) {
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
                    return writeBitmap(context, bmp)
                }
                val u = data.getJSONObject(0).optString("url", "")
                if (u.startsWith("http")) return downloadToFile(context, u)
            }
        }
        return null
    }

    private fun extractBase64(s: String): String? {
        val idx = s.indexOf("base64,")
        if (idx >= 0) return s.substring(idx + 7).trim().takeWhile { !it.isWhitespace() }
        return null
    }

    private fun extractUrl(body: String, extracted: String?): String? {
        val re = Regex("""https?://[^\s\"']+\.(png|jpg|jpeg|webp)(\?[^\s\"']*)?""", RegexOption.IGNORE_CASE)
        for (t in listOfNotNull(extracted, body)) {
            re.find(t)?.value?.let { return it }
        }
        return null
    }

    private fun downloadToFile(context: Context, url: String): File? {
        return try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 30_000
                readTimeout = 60_000
                instanceFollowRedirects = true
            }
            conn.inputStream.use { input ->
                val bytes = input.readBytes()
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
                writeBitmap(context, bmp)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun writeBitmap(context: Context, bmp: Bitmap): File {
        val dir = File(context.filesDir, "generated_images").apply { mkdirs() }
        val f = File(dir, "img_${System.currentTimeMillis()}.png")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 95, it) }
        return f
    }
}
