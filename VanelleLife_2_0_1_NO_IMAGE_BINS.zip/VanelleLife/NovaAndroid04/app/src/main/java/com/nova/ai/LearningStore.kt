package com.nova.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Experience(val event: String, val result: String, val timestamp: Long)
data class Knowledge(
    val subject: String, val fact: String, val confidence: Double, val source: String,
    val lastSeen: Long = System.currentTimeMillis(), val revisions: Int = 0
)
data class Skill(val name: String, val level: Int, val practiceCount: Int, val lastPracticed: Long = System.currentTimeMillis())
data class Trait(val name: String, val value: Double)
data class BeliefRevisionEntry(
    val subject: String, val fact: String, val oldConfidence: Double, val newConfidence: Double,
    val reason: String, val timestamp: Long
)

class LearningStore(context: Context, namespace: String = "default") {
    private val p = context.getSharedPreferences("nova_learning_$namespace", Context.MODE_PRIVATE)

    fun experiences(): List<Experience> = readArray("experiences") { o -> Experience(o.getString("event"), o.getString("result"), o.getLong("timestamp")) }
    fun knowledge(): List<Knowledge> = readArray("knowledge") { o ->
        Knowledge(
            o.getString("subject"), o.getString("fact"), o.optDouble("confidence", .5), o.optString("source", "interaction"),
            o.optLong("lastSeen", System.currentTimeMillis()), o.optInt("revisions", 0)
        )
    }
    fun skills(): List<Skill> = readArray("skills") { o ->
        Skill(o.getString("name"), o.optInt("level", 0), o.optInt("practiceCount", 0), o.optLong("lastPracticed", System.currentTimeMillis()))
    }
    fun traits(): List<Trait> = readArray("traits") { o -> Trait(o.getString("name"), o.optDouble("value", .5)) }
    fun beliefRevisions(): List<BeliefRevisionEntry> = readArray("belief_revisions") { o ->
        BeliefRevisionEntry(o.getString("subject"), o.getString("fact"), o.getDouble("oldConfidence"), o.getDouble("newConfidence"), o.getString("reason"), o.getLong("timestamp"))
    }

    fun addExperience(event: String, result: String) {
        val list = experiences().takeLast(499).map { it.toJson() }.toMutableList()
        list.add(Experience(event, result, System.currentTimeMillis()).toJson())
        write("experiences", JSONArray(list))
    }

    /** Crée ou renforce une connaissance. Utilisé directement pour les faits non conflictuels ;
     *  pour toute nouvelle affirmation susceptible de contredire une croyance existante, passer par BeliefRevision.evaluate(). */
    fun learn(subject: String, fact: String, confidence: Double, source: String = "interaction") {
        val cleanSubject = subject.trim().ifEmpty { "inconnu" }
        val cleanFact = fact.trim()
        if (cleanFact.isEmpty()) return
        val existing = knowledge().toMutableList()
        val idx = existing.indexOfFirst { it.subject.equals(cleanSubject, true) && it.fact.equals(cleanFact, true) }
        if (idx >= 0) {
            val old = existing[idx]
            existing[idx] = old.copy(confidence = ((old.confidence + confidence) / 2).coerceIn(0.0, 1.0), source = source, lastSeen = System.currentTimeMillis())
        } else existing.add(Knowledge(cleanSubject, cleanFact, confidence.coerceIn(0.0, 1.0), source))
        write("knowledge", JSONArray(existing.takeLast(1000).map { it.toJson() }))
    }

    /** Révision des croyances : ajuste la confiance d'une connaissance existante et journalise le motif. */
    fun reviseConfidence(subject: String, fact: String, newConfidence: Double, reason: String) {
        val list = knowledge().toMutableList()
        val i = list.indexOfFirst { it.subject.equals(subject, true) && it.fact.equals(fact, true) }
        if (i < 0) return
        val old = list[i]
        val clamped = newConfidence.coerceIn(0.0, 1.0)
        if (kotlin.math.abs(old.confidence - clamped) < 0.001) return
        list[i] = old.copy(confidence = clamped, revisions = old.revisions + 1, lastSeen = System.currentTimeMillis())
        write("knowledge", JSONArray(list.map { it.toJson() }))
        val log = beliefRevisions().takeLast(199).map { it.toJson() }.toMutableList()
        log.add(BeliefRevisionEntry(subject, fact, old.confidence, clamped, reason, System.currentTimeMillis()).toJson())
        write("belief_revisions", JSONArray(log))
    }

    /** Les croyances non reconfirmées depuis longtemps perdent lentement en confiance : l'incertitude grandit avec le temps sans preuve nouvelle. */
    fun decayStaleBeliefs(now: Long, staleAfterMillis: Long) {
        val list = knowledge().toMutableList()
        var changed = false
        for (i in list.indices) {
            val k = list[i]
            if (now - k.lastSeen > staleAfterMillis && k.confidence > 0.15) {
                list[i] = k.copy(confidence = (k.confidence - 0.03).coerceAtLeast(0.1))
                changed = true
            }
        }
        if (changed) write("knowledge", JSONArray(list.map { it.toJson() }))
    }

    /** Progression avec rendement décroissant : plus le niveau est haut, plus chaque pratique rapporte peu (courbe d'apprentissage réaliste). */
    fun practice(skill: String, amount: Int = 1) {
        val list = skills().toMutableList(); val i = list.indexOfFirst { it.name.equals(skill, true) }
        if (i < 0) list.add(Skill(skill.trim(), (amount * 3).coerceAtMost(10), amount))
        else {
            val s = list[i]
            val gain = (amount * (1.0 - s.level / 130.0)).coerceAtLeast(0.4)
            list[i] = s.copy(level = (s.level + gain).toInt().coerceAtMost(100), practiceCount = s.practiceCount + amount, lastPracticed = System.currentTimeMillis())
        }
        write("skills", JSONArray(list.map { it.toJson() }))
    }

    /** Compétences non pratiquées depuis longtemps : léger fléchissement, comme un savoir-faire qui se rouille. */
    fun decaySkills(now: Long, staleAfterMillis: Long) {
        val list = skills().toMutableList()
        var changed = false
        for (i in list.indices) {
            val s = list[i]
            if (now - s.lastPracticed > staleAfterMillis && s.level > 5) {
                list[i] = s.copy(level = (s.level - 1).coerceAtLeast(5))
                changed = true
            }
        }
        if (changed) write("skills", JSONArray(list.map { it.toJson() }))
    }

    fun masteryLabel(level: Int) = when { level < 20 -> "novice"; level < 45 -> "débutant"; level < 70 -> "intermédiaire"; level < 90 -> "avancé"; else -> "maîtrisé" }

    fun adjustTrait(name: String, delta: Double) {
        val list = traits().toMutableList(); val i = list.indexOfFirst { it.name.equals(name, true) }
        if (i < 0) list.add(Trait(name, (.5 + delta).coerceIn(0.0, 1.0)))
        else list[i] = list[i].copy(value = (list[i].value + delta).coerceIn(0.0, 1.0))
        write("traits", JSONArray(list.map { JSONObject().apply { put("name", it.name); put("value", it.value) } }))
    }

    fun contextFor(query: String): String {
        val words = query.lowercase().split(Regex("\\W+")).filter { it.length > 2 }
        val exp = experiences().filter { e -> words.any { e.event.lowercase().contains(it) || e.result.lowercase().contains(it) } }.takeLast(8)
        val know = knowledge().filter { k -> words.any { k.subject.lowercase().contains(it) || k.fact.lowercase().contains(it) } }.sortedByDescending { it.confidence }.take(10)
        val skill = skills().take(10)
        val tr = traits().take(10)
        return buildString {
            if (exp.isNotEmpty()) { append("EXPÉRIENCES:\n"); exp.forEach { append("- ${it.event} => ${it.result}\n") } }
            if (know.isNotEmpty()) { append("CONNAISSANCES:\n"); know.forEach { append("- ${it.subject}: ${it.fact} [${"%.0f".format(it.confidence * 100)}%]\n") } }
            if (skill.isNotEmpty()) { append("COMPÉTENCES:\n"); skill.forEach { append("- ${it.name}: ${it.level}/100 (${masteryLabel(it.level)})\n") } }
            if (tr.isNotEmpty()) { append("TRAITS ÉVOLUTIFS:\n"); tr.forEach { append("- ${it.name}: ${"%.2f".format(it.value)}\n") } }
        }.ifBlank { "Aucune connaissance pertinente en mémoire." }
    }

    private fun Experience.toJson() = JSONObject().apply { put("event", event); put("result", result); put("timestamp", timestamp) }
    private fun Knowledge.toJson() = JSONObject().apply { put("subject", subject); put("fact", fact); put("confidence", confidence); put("source", source); put("lastSeen", lastSeen); put("revisions", revisions) }
    private fun Skill.toJson() = JSONObject().apply { put("name", name); put("level", level); put("practiceCount", practiceCount); put("lastPracticed", lastPracticed) }
    private fun BeliefRevisionEntry.toJson() = JSONObject().apply { put("subject", subject); put("fact", fact); put("oldConfidence", oldConfidence); put("newConfidence", newConfidence); put("reason", reason); put("timestamp", timestamp) }

    private inline fun <T> readArray(key: String, map: (JSONObject) -> T): List<T> {
        val a = JSONArray(p.getString(key, "[]")); return buildList { for (i in 0 until a.length()) add(map(a.getJSONObject(i))) }
    }
    private fun write(key: String, a: JSONArray) { p.edit().putString(key, a.toString()).apply() }
}
