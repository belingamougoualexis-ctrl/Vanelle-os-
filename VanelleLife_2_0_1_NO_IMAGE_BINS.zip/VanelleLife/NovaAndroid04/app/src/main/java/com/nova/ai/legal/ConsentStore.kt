package com.nova.ai.legal

import android.content.Context

/**
 * Consentements production (RGPD / Play Data Safety).
 * Tout est local ; aucun envoi tant que l'utilisateur n'a pas opt-in.
 */
class ConsentStore(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("vanelle_consent", Context.MODE_PRIVATE)

    fun hasAcceptedPrivacy(): Boolean = p.getBoolean(KEY_PRIVACY, false)
    fun hasAcceptedTerms(): Boolean = p.getBoolean(KEY_TERMS, false)
    fun crashReportingOptIn(): Boolean = p.getBoolean(KEY_CRASH, false)
    fun analyticsOptIn(): Boolean = p.getBoolean(KEY_ANALYTICS, false)

    fun acceptPrivacyAndTerms() {
        p.edit()
            .putBoolean(KEY_PRIVACY, true)
            .putBoolean(KEY_TERMS, true)
            .putLong(KEY_ACCEPTED_AT, System.currentTimeMillis())
            .apply()
    }

    fun setCrashReporting(enabled: Boolean) {
        p.edit().putBoolean(KEY_CRASH, enabled).apply()
    }

    fun setAnalytics(enabled: Boolean) {
        p.edit().putBoolean(KEY_ANALYTICS, enabled).apply()
    }

    fun needsFirstLaunchConsent(): Boolean = !hasAcceptedPrivacy() || !hasAcceptedTerms()

    companion object {
        private const val KEY_PRIVACY = "privacy_v1"
        private const val KEY_TERMS = "terms_v1"
        private const val KEY_CRASH = "crash_opt_in"
        private const val KEY_ANALYTICS = "analytics_opt_in"
        private const val KEY_ACCEPTED_AT = "accepted_at"
    }
}
