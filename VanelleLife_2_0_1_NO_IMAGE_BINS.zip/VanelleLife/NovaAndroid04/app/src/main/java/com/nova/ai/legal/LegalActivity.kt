package com.nova.ai.legal

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.nova.ai.R

/**
 * Affiche politique de confidentialité ou conditions (assets HTML).
 * Intent extra: "doc" = "privacy" | "terms"
 */
class LegalActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val doc = intent.getStringExtra(EXTRA_DOC) ?: DOC_PRIVACY
        val asset = if (doc == DOC_TERMS) "legal/terms_fr.html" else "legal/privacy_fr.html"
        val titleText = if (doc == DOC_TERMS) "Conditions d'utilisation" else "Politique de confidentialité"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0A0A0A.toInt())
        }
        val web = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            setBackgroundColor(0xFF0A0A0A.toInt())
            webViewClient = WebViewClient()
            settings.javaScriptEnabled = false
            loadUrl("file:///android_asset/$asset")
        }
        val close = Button(this).apply {
            text = "Fermer"
            contentDescription = "Fermer le document légal"
            setOnClickListener { finish() }
        }
        title = titleText
        root.addView(web)
        root.addView(close)
        setContentView(root)
    }

    companion object {
        const val EXTRA_DOC = "doc"
        const val DOC_PRIVACY = "privacy"
        const val DOC_TERMS = "terms"
    }
}
