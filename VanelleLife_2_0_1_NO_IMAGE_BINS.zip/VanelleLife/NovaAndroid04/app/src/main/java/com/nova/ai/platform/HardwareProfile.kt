package com.nova.ai.platform

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

data class HardwareProfile(val totalRamMb:Long,val freeRamMb:Long,val cpuCores:Int,val abis:List<String>,val sdk:Int,val hasGpu:Boolean,val hasNnapi:Boolean) {
    fun summary()="RAM ${totalRamMb} Mo · libre ${freeRamMb} Mo · CPU $cpuCores · ${abis.joinToString()} · Android $sdk · Vulkan=$hasGpu · NNAPI=$hasNnapi"
}
object HardwareInspector {
    fun read(context:Context):HardwareProfile {
        val am=context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi=ActivityManager.MemoryInfo().also{am.getMemoryInfo(it)}
        val pm=context.packageManager
        val vulkan=Build.VERSION.SDK_INT>=24 && pm.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL)
        val nnapi=Build.VERSION.SDK_INT>=27 && pm.hasSystemFeature(PackageManager.FEATURE_NNAPI)
        return HardwareProfile(mi.totalMem/1048576,mi.availMem/1048576,Runtime.getRuntime().availableProcessors().coerceAtLeast(1),Build.SUPPORTED_ABIS.toList(),Build.VERSION.SDK_INT,vulkan,nnapi)
    }
}
