package com.nova.ai.platform

data class ToolPermission(
    val toolId: String,
    val allowedActions: Set<String>,
    val requiresConfirmation: Boolean
)

data class ToolManifest(
    val id: String,
    val name: String,
    val version: String,
    val permissions: List<ToolPermission>,
    val inputSchemaJson: String,
    val outputSchemaJson: String
)

interface AgentPlanner {
    fun plan(goal: String, availableSkills: List<AISkill>): List<String>
}

interface ToolExecutor {
    fun execute(toolId: String, action: String, inputJson: String): String
}
