package com.nova.ai.platform

import android.content.Context
import org.json.JSONArray

/** Local, versioned registry for external AI providers. */
class ProviderRegistry(context: Context) {
    private val prefs=context.getSharedPreferences("ai_provider_registry_v1",Context.MODE_PRIVATE)
    fun all(): List<ProviderSpec> = try { val a=JSONArray(prefs.getString("providers","[]")); (0 until a.length()).map{ProviderSpec.fromJson(a.getJSONObject(it))} } catch(_:Exception){emptyList()}
    fun save(spec:ProviderSpec){ val all=all().filterNot{it.id==spec.id}+spec; prefs.edit().putString("providers",JSONArray(all.map{it.toJson()}).toString()).apply() }
    fun remove(id:String){ val all=all().filterNot{it.id==id}; prefs.edit().putString("providers",JSONArray(all.map{it.toJson()}).toString()).apply() }
}
