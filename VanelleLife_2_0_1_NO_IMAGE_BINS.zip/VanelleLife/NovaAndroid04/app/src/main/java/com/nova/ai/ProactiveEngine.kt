package com.nova.ai

import android.content.Context

/** Messages initiés par la mascotte (matin, retour, stagnation). */
object ProactiveEngine {

    fun prefs(context: Context) =
        context.getSharedPreferences("nova_proactive", Context.MODE_PRIVATE)

    fun onAppOpen(context: Context, session: NovaSession): String? {
        val p = prefs(context)
        val now = System.currentTimeMillis()
        val last = p.getLong("last_open_${session.mascot.id}", 0L)
        p.edit().putLong("last_open_${session.mascot.id}", now).apply()

        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val name = session.mascot.name
        val progress = GrowthSystem.compute(
            session.development.state(),
            GrowthSystem.bonusXp(context, session.mascot.id)
        )

        if (last == 0L) {
            return null // onboarding gère la première fois
        }

        val gap = now - last
        val day = 24 * 60 * 60 * 1000L

        return when {
            gap > 3 * day -> {
                session.development.observe("(retour après absence)")
                "Tu m'as manqué… Je suis $name, toujours en stade ${progress.stage}. On reprend ?"
            }
            gap > day -> {
                "Content(e) de te revoir. J'ai pensé à nos ${session.development.state().experiences} expériences."
            }
            hour in 5..10 && gap > 4 * 60 * 60 * 1000L -> {
                "Bonjour ! Moi c'est $name (${progress.stage}). Que fait-on ce matin ?"
            }
            hour in 21..23 && gap > 2 * 60 * 60 * 1000L -> {
                "Bonne soirée. Tu veux consolider ma journée avant de dormir ?"
            }
            else -> null
        }
    }

    fun shareCard(session: NovaSession, progress: GrowthSystem.Progress): String {
        val s = session.development.state()
        val mem = session.memory.all().lastOrNull()?.text?.take(80) ?: "—"
        return """
✨ ${session.mascot.name}
Stade : ${progress.stage} ($progress.xp XP)
Souvenirs ${s.memories} · Expériences ${s.experiences} · Concepts ${s.concepts}
Dernier souvenir : $mem
Élevée avec NOVA — 100% local
        """.trimIndent()
    }
}
