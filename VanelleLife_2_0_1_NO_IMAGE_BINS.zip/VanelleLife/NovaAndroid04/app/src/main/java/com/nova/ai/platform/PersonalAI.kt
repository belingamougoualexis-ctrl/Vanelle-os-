package com.nova.ai.platform

data class PersonalAI(
    val id: String,
    val name: String,
    val version: String,
    val personality: Personality,
    val goals: List<String>,
    val memoryIds: List<String>,
    val skillIds: List<String>,
    val knowledgeIds: List<String>,
    val modelBindings: Map<Modality, String>,
    val createdAt: Long,
    val updatedAt: Long
)

data class Personality(
    val systemInstruction: String,
    val traits: Map<String, Double>
)

data class AIExperience(
    val id: String,
    val aiId: String,
    val input: String,
    val outcome: String,
    val correction: String?,
    val createdAt: Long
)

data class AISkill(
    val id: String,
    val aiId: String,
    val name: String,
    val version: String,
    val manifestJson: String,
    val enabled: Boolean
)

data class AIVersion(
    val id: String,
    val aiId: String,
    val version: String,
    val createdAt: Long,
    val manifestHash: String
)
