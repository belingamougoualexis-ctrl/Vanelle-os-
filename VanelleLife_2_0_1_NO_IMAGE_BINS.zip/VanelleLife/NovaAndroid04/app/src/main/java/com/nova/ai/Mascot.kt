package com.nova.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Mascot(
    val id: String,
    val name: String,
    val skin: String,
    val voice: VoiceEngine.VoiceSettings = VoiceEngine.VoiceSettings(),
    val createdAt: Long = System.currentTimeMillis(),
    /** Prompt système défini par l'utilisateur — injecté réellement dans le chat. */
    val systemPrompt: String = ""
)

class MascotStore(context: Context) {
    private val p = context.getSharedPreferences("nova_mascots", Context.MODE_PRIVATE)

    fun all(): List<Mascot> {
        val a = JSONArray(p.getString("list", "[]") ?: "[]")
        return buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val rawSkin = o.optString("skin", o.optString("emoji", DEFAULT_SKIN))
                val skin = if (rawSkin in SKINS.map { it.first }) rawSkin else DEFAULT_SKIN
                add(
                    Mascot(
                        o.getString("id"),
                        o.getString("name"),
                        skin,
                        VoiceEngine.VoiceSettings.fromJson(o.optString("voice", "")),
                        o.optLong("createdAt", 0L),
                        o.optString("systemPrompt", "")
                    )
                )
            }
        }
    }

    fun activeId(): String = p.getString("active_id", "") ?: ""

    fun active(): Mascot? {
        val id = activeId()
        return all().firstOrNull { it.id == id } ?: all().firstOrNull()
    }

    fun setActive(id: String) {
        p.edit().putString("active_id", id).apply()
    }

    fun add(name: String, skin: String, voice: VoiceEngine.VoiceSettings = VoiceEngine.VoiceSettings()): Mascot {
        val m = Mascot(
            id = "m_${System.currentTimeMillis()}",
            name = name.trim().ifBlank { "Vanelle" },
            skin = if (skin in SKINS.map { it.first }) skin else DEFAULT_SKIN,
            voice = voice
        )
        val list = all().toMutableList()
        list.add(m)
        persist(list)
        if (activeId().isBlank()) setActive(m.id)
        return m
    }

    fun rename(id: String, newName: String) {
        val n = newName.trim()
        if (n.isEmpty()) return
        val list = all().map { if (it.id == id) it.copy(name = n) else it }
        persist(list)
    }

    fun setVoice(id: String, voice: VoiceEngine.VoiceSettings) {
        val list = all().map { if (it.id == id) it.copy(voice = voice) else it }
        persist(list)
    }

    fun setSkin(id: String, skin: String) {
        val s = if (skin in SKINS.map { it.first }) skin else DEFAULT_SKIN
        val list = all().map { if (it.id == id) it.copy(skin = s) else it }
        persist(list)
    }

    fun setSystemPrompt(id: String, prompt: String) {
        val list = all().map { if (it.id == id) it.copy(systemPrompt = prompt.trim()) else it }
        persist(list)
    }

    fun remove(id: String) {
        val list = all().filter { it.id != id }
        persist(list)
        if (activeId() == id) setActive(list.firstOrNull()?.id ?: "")
    }

    private fun persist(list: List<Mascot>) {
        val a = JSONArray()
        list.forEach { m ->
            a.put(JSONObject().apply {
                put("id", m.id)
                put("name", m.name)
                put("skin", m.skin)
                put("voice", m.voice.toJson())
                put("createdAt", m.createdAt)
                put("systemPrompt", m.systemPrompt)
            })
        }
        p.edit().putString("list", a.toString()).apply()
    }

    companion object {
        const val DEFAULT_SKIN = "vanelle_cosmos"

        val SKINS = listOf(
            "vanelle_cosmos" to "Cosmos",
            "vanelle_lava" to "Lave",
            "vanelle_ice" to "Glace",
            "vanelle_aurora" to "Aurore",
            "vanelle_kawaii_purple" to "Kawaii violet",
            "vanelle_kawaii_wink" to "Kawaii clin d'œil",
            "vanelle_kawaii_star" to "Kawaii étoile",
            "vanelle_amber" to "Ambre",
            "vanelle_green" to "Vert",
            "vanelle_slate" to "Ardoise",
            "vanelle_gold" to "Or",
            "vanelle_steel" to "Acier",
            "vanelle_bronze" to "Bronze",
            "vanelle_iridescent" to "Irisé",
            "vanelle_dark" to "Sombre",
            "vanelle_ocean_dark" to "Océan sombre",
            "vanelle_mint" to "Menthe"
        )

        fun drawableId(context: Context, skin: String): Int {
            val name = if (skin in SKINS.map { it.first }) skin else DEFAULT_SKIN
            val id = context.resources.getIdentifier(name, "drawable", context.packageName)
            return if (id != 0) id else context.resources.getIdentifier(DEFAULT_SKIN, "drawable", context.packageName)
        }
    }
}
