package com.nova.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Client d'embeddings multi-fournisseurs.
 * - Format OpenAI : { "data": [ { "embedding": [...] } ] }
 * - Format HuggingFace feature-extraction : [[...]] ou [...]
 */
class EmbeddingClient(
    private val endpoint: String,
    private val apiKey: String,
    private val model: String,
    private val preferLocal: Boolean = false
) {
    data class Result(val vector: FloatArray?, val error: String? = null)

    fun embed(text: String): Result {
        if (text.isBlank()) return Result(null, "Texte vide.")
        // Mode local offline (toujours dispo, illimité, gratuit)
        if (apiKey.isBlank() || preferLocal) {
            return Result(LocalHashEmbedder.embed(text))
        }

        val isHf = endpoint.contains("huggingface") || endpoint.contains("hf-inference") ||
            endpoint.contains("api-inference.huggingface")

        val body = if (isHf) {
            // HF serverless feature-extraction
            JSONObject().apply {
                put("inputs", text.take(2000))
                put("options", JSONObject().put("wait_for_model", true))
            }.toString()
        } else {
            JSONObject().apply {
                put("model", model)
                put("input", text.take(8000))
            }.toString()
        }

        val url = if (isHf && !endpoint.contains("/pipeline/") && !endpoint.contains("/models/")) {
            // endpoint de base HF → modèle embeddings
            "https://api-inference.huggingface.co/pipeline/feature-extraction/$model"
        } else endpoint

        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 25000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $apiKey")
        }
        return try {
            c.outputStream.use { it.write(body.toByteArray()) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val textResp = stream.bufferedReader().use { it.readText() }
            if (c.responseCode !in 200..299) {
                Result(null, "HTTP ${c.responseCode} embeddings")
            } else {
                parseVector(textResp)
            }
        } catch (e: Exception) {
            Result(null, e.javaClass.simpleName)
        } finally {
            c.disconnect()
        }
    }

    private fun parseVector(textResp: String): Result {
        return try {
            // OpenAI style
            if (textResp.contains("\"embedding\"")) {
                val arr = JSONObject(textResp)
                    .getJSONArray("data")
                    .getJSONObject(0)
                    .getJSONArray("embedding")
                val vec = FloatArray(arr.length()) { i -> arr.getDouble(i).toFloat() }
                return Result(vec)
            }
            // HF: [[f,f,...]] (token-level) ou [f,f,...] (sentence)
            val trimmed = textResp.trim()
            val arr = when {
                trimmed.startsWith("[[") -> {
                    val outer = JSONArray(trimmed)
                    // moyenne sur les tokens si 2D
                    val first = outer.getJSONArray(0)
                    if (outer.length() == 1 && first.length() > 0 && first.opt(0) is Number) {
                        first
                    } else {
                        // mean pool
                        val dim = first.length()
                        val sum = DoubleArray(dim)
                        for (i in 0 until outer.length()) {
                            val row = outer.getJSONArray(i)
                            for (j in 0 until dim) sum[j] += row.getDouble(j)
                        }
                        val mean = JSONArray()
                        for (j in 0 until dim) mean.put(sum[j] / outer.length())
                        mean
                    }
                }
                trimmed.startsWith("[") -> JSONArray(trimmed)
                else -> return Result(null, "Format embeddings inconnu")
            }
            val vec = FloatArray(arr.length()) { i -> arr.getDouble(i).toFloat() }
            Result(vec)
        } catch (e: Exception) {
            Result(null, "Parse: ${e.javaClass.simpleName}")
        }
    }

    fun probe(): String {
        if (preferLocal || apiKey.isBlank()) {
            val r = embed("nova probe")
            return if (r.vector != null) "Embeddings LOCAUX OK (${r.vector.size} dims, hash offline)"
            else "Embeddings locaux : échec"
        }
        val r = embed("nova probe")
        return when {
            r.error != null -> "Embeddings cloud : échec (${r.error}) — bascule locale possible"
            r.vector != null -> "Embeddings cloud OK (${r.vector.size} dims, $model)"
            else -> "Embeddings : réponse vide"
        }
    }

    companion object {
        fun cosine(a: FloatArray, b: FloatArray): Float {
            if (a.size != b.size || a.isEmpty()) return 0f
            var dot = 0.0
            var na = 0.0
            var nb = 0.0
            for (i in a.indices) {
                dot += a[i] * b[i]
                na += a[i] * a[i]
                nb += b[i] * b[i]
            }
            val denom = kotlin.math.sqrt(na) * kotlin.math.sqrt(nb)
            return if (denom == 0.0) 0f else (dot / denom).toFloat()
        }
    }
}
