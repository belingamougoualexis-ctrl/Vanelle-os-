package com.nova.ai.db

/**
 * Notes Room 1.1 :
 * - Les dépendances room-runtime / room-ktx sont dans le Gradle.
 * - AppDatabase (SQLiteOpenHelper) reste la source de vérité pour éviter kapt/ksp obligatoire.
 * - Pour migrer un store vers @Entity / @Dao : ajouter ksp("androidx.room:room-compiler:2.6.1")
 *   et créer les entités progressivement (MemoryIndexEntity, etc.).
 * - L'index mémoire dans AppDatabase.searchMemory() est déjà utilisable sans annotation Room.
 */
object RoomNotes {
    const val STRATEGY = "sqlite_first_room_ready"
}
