package com.nova.ai.platform

import android.content.Context

enum class ReadinessState {
    READY,
    MODEL_MISSING,
    MODEL_INCOMPATIBLE,
    RUNTIME_MISSING,
    PERMISSION_MISSING,
    NETWORK_REQUIRED,
    STORAGE_INSUFFICIENT
}

data class RuntimeCheck(
    val state: ReadinessState,
    val message: String
)

interface RuntimeInstaller {
    fun isInstalled(context: Context, runtimeId: String): Boolean
    fun install(context: Context, runtimeId: String): Boolean
}

object RuntimeReadiness {
    fun check(context: Context, request: GenerationRequest): RuntimeCheck {
        val runtime = RuntimeRegistry.findGeneration(context, request)
            ?: return RuntimeCheck(
                ReadinessState.RUNTIME_MISSING,
                "Aucun moteur réel compatible n'est installé."
            )
        if (!runtime.supports(context, request)) {
            return RuntimeCheck(
                ReadinessState.MODEL_INCOMPATIBLE,
                "Le runtime ne supporte pas cette configuration."
            )
        }
        return RuntimeCheck(ReadinessState.READY, "Runtime réel disponible.")
    }
}
