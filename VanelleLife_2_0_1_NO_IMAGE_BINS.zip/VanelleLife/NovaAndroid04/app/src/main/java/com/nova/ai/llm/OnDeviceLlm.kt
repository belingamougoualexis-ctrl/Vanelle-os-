package com.nova.ai.llm

import android.content.Context
import com.nova.ai.LocalBrain
import com.nova.ai.platform.ReadinessState
import com.nova.ai.platform.RuntimeCheck

/**
 * Contrat de runtime LLM on-device réel.
 * Aucune génération n'est inventée : si le modèle/runtime manque, on bascule
 * explicitement sur le moteur de règles local (LocalBrain).
 */
interface OnDeviceLlm {
    val id: String
    fun readiness(context: Context): RuntimeCheck
    /** Génère une réponse. Retourne null si le runtime n'est pas prêt. */
    fun generate(context: Context, prompt: String, systemHint: String? = null): String?
}

/** Fallback honnête : délègue à LocalBrain (mémoire + règles). Toujours disponible. */
class RuleBasedLlm(
    private val brainFactory: () -> LocalBrain
) : OnDeviceLlm {
    override val id: String = "local_rules_v1"
    override fun readiness(context: Context): RuntimeCheck =
        RuntimeCheck(ReadinessState.READY, "Moteur de règles local (mémoire utilisateur).")

    override fun generate(context: Context, prompt: String, systemHint: String?): String {
        return brainFactory().reply(prompt)
    }
}

/**
 * Routeur : MediaPipe (Gemma 1B) si prêt → sinon règles locales.
 * Pas de backend cloud.
 */
class LlmRouter(
    private val mediaPipe: OnDeviceLlm = MediaPipeLlm(),
    private val rules: OnDeviceLlm
) {
    fun bestAvailable(context: Context): OnDeviceLlm {
        val m = mediaPipe.readiness(context)
        return if (m.state == ReadinessState.READY) mediaPipe else rules
    }

    fun generate(context: Context, prompt: String, systemHint: String? = null): Pair<String, String> {
        val engine = bestAvailable(context)
        val text = engine.generate(context, prompt, systemHint)
            ?: rules.generate(context, prompt, systemHint)
            ?: "Je ne peux pas répondre pour le moment."
        return engine.id to text
    }

    fun statusLine(context: Context): String {
        val m = mediaPipe.readiness(context)
        return when (m.state) {
            ReadinessState.READY -> "LLM on-device : MediaPipe + Gemma-3 1B"
            ReadinessState.MODEL_MISSING -> "LLM : modèle léger non téléchargé (règles locales)"
            ReadinessState.RUNTIME_MISSING -> "LLM : MediaPipe non lié — sync Gradle (règles locales)"
            else -> "LLM : ${m.message}"
        }
    }

    fun detailedStatus(context: Context): String {
        val m = mediaPipe.readiness(context)
        return buildString {
            appendLine("MediaPipe présent : ${MediaPipeLlm.isMediaPipePresent()}")
            appendLine("État : ${m.state}")
            appendLine(m.message)
            appendLine()
            appendLine("Moteur de secours : règles locales (toujours actif)")
            appendLine("Téléchargement : Hub modèles (Gemma-3 1B ≈ 550 Mo, embeddings ≈ 24 Mo)")
        }
    }
}
