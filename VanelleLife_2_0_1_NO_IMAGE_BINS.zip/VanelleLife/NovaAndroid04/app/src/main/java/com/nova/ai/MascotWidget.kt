package com.nova.ai

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class MascotWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val store = MascotStore(context)
        val m = store.active()
        val session = if (m != null) NovaSession(context, m) else null
        val progress = session?.progress()
        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.widget_mascot)
            if (m != null) {
                views.setTextViewText(R.id.widget_name, m.name)
                views.setTextViewText(
                    R.id.widget_stage,
                    progress?.label ?: "—"
                )
                views.setImageViewResource(R.id.widget_avatar, MascotStore.drawableId(context, m.skin))
            } else {
                views.setTextViewText(R.id.widget_name, "Vanelle")
                views.setTextViewText(R.id.widget_stage, "Ouvre l'app")
            }
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, open)
            manager.updateAppWidget(id, views)
        }
    }
}
