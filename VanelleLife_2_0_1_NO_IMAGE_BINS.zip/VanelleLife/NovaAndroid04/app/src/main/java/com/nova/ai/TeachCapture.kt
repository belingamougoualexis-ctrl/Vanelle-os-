package com.nova.ai

/**
 * Apprentissage depuis le chat — PAS limité aux phrases magiques.
 *
 * 1) Enseignement explicite ("Rappelle-toi que…") → confiance haute + accusé de réception
 * 2) Fait déclaratif ordinaire ("Le plus vieux du monde a 123 ans.") → appris en silence
 * 3) Questions / salutations / ordres courts → non stockés comme leçons
 *
 * Les fichiers (.txt/.json/.zip…) passent par KnowledgeImporter, sans phrase spéciale.
 */
object TeachCapture {

    data class Capture(
        val fact: String,
        val subject: String,
        val explicit: Boolean,
        val confidence: Double
    )

    private val explicitPatterns = listOf(
        Regex("""(?i)^\s*(?:rappelle[- ]toi|souviens[- ]toi|reten(?:s|ir)|apprends?|note|mémorise|n'oublie pas)\s+(?:que\s+)?(.+)$"""),
        Regex("""(?i)^\s*(?:remember|note that|don't forget)\s+(?:that\s+)?(.+)$"""),
        Regex("""(?i)^\s*(?:je te (?:dis|enseigne|apprends)|sache que)\s+(.+)$""")
    )

    private val questionStarts = listOf(
        "qui ", "que ", "quoi", "quand", "où ", "ou ", "comment", "pourquoi",
        "combien", "est-ce", "est ce", "c'est quoi", "tu ", "peux-tu", "peux tu",
        "what", "who", "when", "where", "why", "how", "can you", "do you"
    )

    private val chatter = listOf(
        "bonjour", "salut", "hello", "hi ", "hey", "merci", "thanks", "ok", "oui", "non",
        "ciao", "bonne nuit", "bonsoir", "ça va", "ca va"
    )

    fun extract(userText: String): Capture? {
        val t = userText.trim()
        if (t.length < 10) return null

        // 1) Explicite
        for (p in explicitPatterns) {
            val m = p.find(t) ?: continue
            val fact = m.groupValues.getOrNull(1)?.trim().orEmpty()
            if (fact.length >= 6) {
                return Capture(PhraseComposer.ensureSentence(fact), subjectOf(fact), explicit = true, confidence = 0.95)
            }
        }

        // 2) Fait déclaratif (sans phrase magique)
        if (looksLikeQuestion(t) || looksLikeChatter(t)) return null
        if (!looksLikeDeclarativeFact(t)) return null
        return Capture(
            PhraseComposer.ensureSentence(t),
            subjectOf(t),
            explicit = false,
            confidence = 0.82
        )
    }

    /**
     * @return le fait si enseignement **explicite** (pour afficher "C'est noté"),
     *         null sinon (y compris si un fait a été appris en silence).
     */
    fun apply(session: NovaSession, userText: String): String? {
        val c = extract(userText) ?: return null
        session.learning.learn(c.subject, c.fact, c.confidence, source = if (c.explicit) "explicit_teach" else "chat_fact")
        session.memory.remember(c.fact, if (c.explicit) 5 else 3)
        session.development.observe(c.fact)
        // Paires utiles pour reformuler plus tard
        session.development.supervised.add(
            "Que sais-tu sur ${c.subject} ?",
            c.fact,
            source = if (c.explicit) "explicit_teach" else "chat_fact"
        )
        // Variante question naturelle si le fait contient un nombre / nom propre simple
        val q = autoQuestion(c.fact)
        if (q != null) {
            session.development.supervised.add(q, c.fact, source = "auto_qa")
        }
        return if (c.explicit) c.fact else null
    }

    /** Apprend sans bloquer la réponse (faits silencieux). */
    fun absorbSilently(session: NovaSession, userText: String) {
        val c = extract(userText) ?: return
        if (c.explicit) return // déjà géré par apply
        session.learning.learn(c.subject, c.fact, c.confidence, source = "chat_fact")
        session.memory.remember(c.fact, 3)
        session.development.observe(c.fact)
    }

    private fun looksLikeQuestion(t: String): Boolean {
        val lower = t.lowercase().trim()
        if (lower.endsWith("?")) return true
        return questionStarts.any { lower.startsWith(it) }
    }

    private fun looksLikeChatter(t: String): Boolean {
        val lower = t.lowercase().trim()
        if (lower.length < 16 && chatter.any { lower.contains(it) }) return true
        return false
    }

    /**
     * Phrase informative probable : assez longue, pas une question,
     * contient un verbe / structure de fait.
     */
    private fun looksLikeDeclarativeFact(t: String): Boolean {
        val lower = t.lowercase()
        if (t.length < 18 || t.length > 500) return false
        if (looksLikeQuestion(t)) return false
        // indices de fait
        val factHints = listOf(
            " est ", " sont ", " a ", " ont ", " était ", " étaient ",
            " mesure ", " pèse ", " s'appelle ", " se trouve ", " date ",
            " is ", " are ", " was ", " were ", " has ", " have "
        )
        if (factHints.any { lower.contains(it) }) return true
        // sujet: fait
        if (t.contains(":") && t.indexOf(':') in 1..60) return true
        // contient un nombre souvent = fait
        if (Regex("""\d+""").containsMatchIn(t) && t.split(Regex("\\s+")).size >= 5) return true
        return false
    }

    private fun autoQuestion(fact: String): String? {
        val lower = fact.lowercase()
        // "X a 123 ans" → "Quel âge …"
        val age = Regex("""(?i)(.+?)\s+a\s+(\d+)\s+ans?""").find(fact)
        if (age != null) {
            val who = age.groupValues[1].trim().removePrefix("Le ").removePrefix("La ").removePrefix("L'")
            return "Quel âge a $who ?"
        }
        val capital = Regex("""(?i)(?:la )?capitale (?:de |d')(.+?)\s+est\s+(.+)""").find(fact)
        if (capital != null) {
            return "Quelle est la capitale de ${capital.groupValues[1].trim().trimEnd('.')} ?"
        }
        if (lower.contains(" est ")) {
            val parts = fact.split(Regex("""(?i)\s+est\s+"""), limit = 2)
            if (parts.size == 2 && parts[0].length in 3..60) {
                return "Qu'est-ce que ${parts[0].trim()} ?"
            }
        }
        return null
    }

    private fun subjectOf(fact: String): String {
        val words = fact.lowercase()
            .replace(Regex("""[^\p{L}\p{N}\s]"""), " ")
            .split(Regex("\\s+"))
            .filter { it.length > 3 && it !in stop }
        return words.take(3).joinToString(" ").ifBlank { "fait" }.take(48)
    }

    private val stop = setOf(
        "que", "qui", "les", "des", "une", "est", "sont", "pour", "dans", "avec",
        "plus", "très", "avoir", "être", "cette", "cela", "aussi", "comme", "tout",
        "the", "and", "that", "this", "with", "from", "have", "been", "ans", "âge"
    )
}
