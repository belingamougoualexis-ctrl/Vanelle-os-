package com.nova.ai.ui

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.*
import com.nova.ai.crash.SentryBridge
import com.nova.ai.legal.ConsentStore
import com.nova.ai.legal.LegalActivity
import com.nova.ai.llm.LlmRouter
import com.nova.ai.llm.RuleBasedLlm
import com.nova.ai.platform.ProviderRegistry
import com.nova.ai.platform.ProviderSpec
import com.nova.ai.platform.ProviderExecutor
import com.nova.ai.platform.ProviderPresets
import com.nova.ai.AISecretVault
import com.nova.ai.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun VanelleRoot(accountStore: AccountStore, onNeedLegacy: () -> Unit = {}) {
    val context = LocalContext.current
    val consent = remember { ConsentStore(context) }
    var phase by remember {
        mutableStateOf(
            when {
                consent.needsFirstLaunchConsent() -> Phase.Consent
                !accountStore.isLoggedIn() -> Phase.Auth
                else -> Phase.Main
            }
        )
    }
    VanelleTheme {
        Surface(Modifier.fillMaxSize(), color = VlSurfaceSoft) {
            when (phase) {
                Phase.Consent -> ConsentScreen(
                    onAccept = {
                        consent.acceptPrivacyAndTerms()
                        phase = if (accountStore.isLoggedIn()) Phase.Main else Phase.Auth
                    },
                    onPrivacy = {
                        context.startActivity(
                            Intent(context, LegalActivity::class.java)
                                .putExtra(LegalActivity.EXTRA_DOC, LegalActivity.DOC_PRIVACY)
                        )
                    },
                    onTerms = {
                        context.startActivity(
                            Intent(context, LegalActivity::class.java)
                                .putExtra(LegalActivity.EXTRA_DOC, LegalActivity.DOC_TERMS)
                        )
                    }
                )
                Phase.Auth -> AuthScreen(accountStore) { phase = Phase.Main }
                Phase.Main -> MainChatScreen(accountStore) {
                    accountStore.logout()
                    phase = Phase.Auth
                }
            }
        }
    }
}

private enum class Phase { Consent, Auth, Main }

@Composable
private fun ConsentScreen(onAccept: () -> Unit, onPrivacy: () -> Unit, onTerms: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(MaldivesMist, VlSurfaceSoft, Color.White)))
            .padding(28.dp)
    ) {
        Column(Modifier.align(Alignment.Center)) {
            Text("VanelleLife", color = MaldivesBlueDark, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text(
                "Compte et mascottes 100 % locaux.\nEn continuant, tu acceptes la confidentialité et les conditions.",
                color = VlGray,
                fontSize = 15.sp,
                lineHeight = 22.sp
            )
            Spacer(Modifier.height(28.dp))
            Button(
                onClick = onAccept,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaldivesBlue)
            ) { Text("J'accepte", fontSize = 16.sp) }
            TextButton(onClick = onPrivacy) { Text("Politique de confidentialité", color = MaldivesBlueDark) }
            TextButton(onClick = onTerms) { Text("Conditions d'utilisation", color = MaldivesBlueDark) }
        }
    }
}

@Composable
private fun AuthScreen(accountStore: AccountStore, onLoggedIn: () -> Unit) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(MaldivesMist, Color.White)))
            .padding(28.dp)
    ) {
        Column(Modifier.align(Alignment.Center)) {
            Text("Compte local", color = VlBlack, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("Aucun serveur. Export pour changer de téléphone.", color = VlGray, fontSize = 13.sp)
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                user, { user = it }, label = { Text("Identifiant") },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                pass, { pass = it }, label = { Text("Mot de passe") },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
            error?.let { Text(it, color = VlError, modifier = Modifier.padding(top = 8.dp)) }
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = {
                    val e = accountStore.login(user, pass)
                    if (e != null) error = e else onLoggedIn()
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaldivesBlue)
            ) { Text("Connexion") }
            OutlinedButton(
                onClick = {
                    val e = accountStore.register(user, pass)
                    if (e != null) error = e else onLoggedIn()
                },
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("Inscription") }
        }
    }
}

data class ChatLine(val who: String, val text: String)

@Composable
fun MainChatScreen(accountStore: AccountStore, onLogout: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val mascotStore = remember { MascotStore(context) }
    var session by remember {
        mutableStateOf(
            run {
                if (mascotStore.all().isEmpty()) {
                    val m = mascotStore.add("Vanelle", MascotStore.DEFAULT_SKIN)
                    mascotStore.setActive(m.id)
                } else if (mascotStore.active() == null) {
                    mascotStore.setActive(mascotStore.all().first().id)
                }
                NovaSession(context, mascotStore.active()!!)
            }
        )
    }
    var lines by remember { mutableStateOf(listOf<ChatLine>()) }
    var input by remember { mutableStateOf("") }
    var bootstrapLine by remember { mutableStateOf<String?>(null) }
    var bootstrapPct by remember { mutableStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val report = withContext(Dispatchers.IO) {
                try {
                    val name = uri.lastPathSegment?.substringAfterLast('/') ?: "import.bin"
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: return@withContext KnowledgeImporter.Report(message = "Lecture impossible")
                    KnowledgeImporter.importBytes(session, bytes, name)
                } catch (e: Exception) {
                    KnowledgeImporter.Report(message = e.message ?: "Erreur import")
                }
            }
            session = NovaSession(context, mascotStore.active()!!)
            lines = lines + ChatLine(
                "Système",
                report.message.ifBlank {
                    "Import : ${report.knowledge} faits, ${report.memories} souvenirs, ${report.supervised} paires."
                }
            )
        }
    }

    LaunchedEffect(Unit) {
        if (!ModelBootstrap.isDone(context)) {
            bootstrapLine = "Préparation des modèles…"
            withContext(Dispatchers.IO) {
                ModelBootstrap.run(context) { line, pct ->
                    bootstrapLine = line
                    bootstrapPct = pct
                }
            }
            bootstrapLine = "Modèles prêts"
            bootstrapPct = 100
            kotlinx.coroutines.delay(1800)
            bootstrapLine = null
        }
        ProactiveEngine.onAppOpen(context, session)?.let { msg ->
            lines = lines + ChatLine(session.mascot.name, msg)
        }
    }

    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.animateScrollToItem(lines.lastIndex)
    }

    val avatarBmp = remember(session.mascot.skin) {
        val id = MascotStore.drawableId(context, session.mascot.skin)
        BitmapFactory.decodeResource(context.resources, id)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(MaldivesMist, VlSurfaceSoft, Color(0xFFF8FAFC))))
            .padding(14.dp)
    ) {
        // Header lumineux
        Row(
            Modifier
                .fillMaxWidth()
                .shadow(6.dp, RoundedCornerShape(20.dp))
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(104.dp)
                    .shadow(4.dp, CircleShape)
                    .clip(CircleShape)
                    .border(2.dp, MaldivesSoft, CircleShape)
                    .background(VlSurfaceHigh)
            ) {
                if (avatarBmp != null) {
                    Image(
                        bitmap = avatarBmp.asImageBitmap(),
                        contentDescription = session.mascot.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(session.mascot.name, color = VlBlack, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(session.statusLine(), color = VlGray, fontSize = 12.sp, maxLines = 2)
                LinearProgressIndicator(
                    progress = { session.progress().progress01 },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = MaldivesBlue,
                    trackColor = VlStroke
                )
            }
            TextButton(onClick = { showSettings = true }) {
                Text("Info", color = MaldivesBlueDark, fontWeight = FontWeight.SemiBold)
            }
        }

        bootstrapLine?.let { line ->
            Column(
                Modifier
                    .padding(top = 10.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White)
                    .padding(12.dp)
            ) {
                Text(line, color = MaldivesBlueDark, fontSize = 12.sp, maxLines = 1)
                LinearProgressIndicator(
                    progress = { bootstrapPct / 100f },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp).height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = MaldivesBlue,
                    trackColor = VlStroke
                )
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().padding(vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(lines) { line ->
                val isUser = line.who == "Toi"
                Column(
                    Modifier.fillMaxWidth(),
                    horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                ) {
                    Text(line.who, color = MaldivesBlueDark, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Surface(
                        shape = RoundedCornerShape(
                            topStart = 16.dp, topEnd = 16.dp,
                            bottomStart = if (isUser) 16.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 16.dp
                        ),
                        color = if (isUser) VlBubbleUser else VlBubbleBot,
                        shadowElevation = 2.dp,
                        modifier = Modifier.widthIn(max = 340.dp)
                    ) {
                        Text(
                            line.text,
                            color = VlBlack,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            fontSize = 15.sp,
                            lineHeight = 21.sp
                        )
                    }
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Écris à ta mascotte…", color = VlGray) },
                shape = RoundedCornerShape(16.dp),
                maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaldivesBlue,
                    unfocusedBorderColor = VlStroke,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )
            Spacer(Modifier.width(8.dp))
            Button(
                enabled = !busy && input.isNotBlank(),
                onClick = {
                    val text = input.trim()
                    input = ""
                    lines = lines + ChatLine("Toi", text)
                    busy = true
                    scope.launch {
                        val reply = withContext(Dispatchers.IO) {
                            ChatEngine.reply(context, session, text)
                        }
                        lines = lines + ChatLine(session.mascot.name, reply.text)
                        withContext(Dispatchers.IO) {
                            session.development.observe(text)
                            session.memory.remember(text, 2)
                            session.journal.add("chat", text.take(100))
                        }
                        session = NovaSession(context, mascotStore.active()!!)
                        busy = false
                    }
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaldivesBlue)
            ) { Text(if (busy) "…" else "Envoyer") }
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val actions = listOf(
                "Fichier" to { importLauncher.launch("*/*") },
                "Consolider" to {
                    scope.launch {
                        withContext(Dispatchers.IO) { session.development.consolidateNow() }
                        session = NovaSession(context, mascotStore.active()!!)
                        lines = lines + ChatLine("Système", "Consolidation terminée.")
                    }
                },
                "Enseigner" to {
                    lines = lines + ChatLine(
                        "Système",
                        "Écris : « Rappelle-toi que … » ou importe un .txt / .json / .zip"
                    )
                },
                "Image" to {
                    lines = lines + ChatLine(
                        "Système",
                        "Configure un provider HTTPS avec capacité image dans Info."
                    )
                }
            )
            actions.forEach { (label, action) ->
                OutlinedButton(
                    onClick = action,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaldivesBlueDark)
                ) { Text(label, fontSize = 11.sp, maxLines = 1) }
            }
        }
    }

    if (showSettings) {
        SettingsSheet(
            session = session,
            mascotStore = mascotStore,
            onDismiss = { showSettings = false },
            onLogout = onLogout,
            onSessionRefresh = { session = NovaSession(context, mascotStore.active()!!) },
            onSystemMessage = { lines = lines + ChatLine("Système", it) }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsSheet(
    session: NovaSession,
    mascotStore: MascotStore,
    onDismiss: () -> Unit,
    onLogout: () -> Unit,
    onSessionRefresh: () -> Unit,
    onSystemMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var systemPrompt by remember { mutableStateOf(session.mascot.systemPrompt) }
    var sentryDsn by remember { mutableStateOf(SentryBridge.getDsn(context)) }
    val registry = remember { ProviderRegistry(context) }
    val existingProvider = remember { registry.all().firstOrNull { it.enabled } }
    val providerStatus = remember {
        val p = existingProvider
        if (p == null) "Aucun provider configuré (mode local)."
        else {
            val hasKey = !AISecretVault(context).get(p.id).isNullOrBlank()
            "${p.name} · ${if (hasKey) "clé OK" else "clé manquante"} · ${p.endpoint.take(40)}"
        }
    }

    var apiName by remember { mutableStateOf(existingProvider?.name ?: "OpenAI Chat") }
    var apiEndpoint by remember { mutableStateOf(existingProvider?.endpoint ?: "https://api.openai.com/v1/chat/completions") }
    var apiKey by remember { mutableStateOf("") }
    var apiTemplate by remember {
        mutableStateOf(existingProvider?.requestTemplate ?: ProviderPresets.openAiChat().requestTemplate)
    }
    var apiPath by remember {
        mutableStateOf(existingProvider?.responsePath ?: "choices.0.message.content")
    }
    var apiStatus by remember {
        mutableStateOf(
            run {
                val p = existingProvider
                if (p == null) "Aucun provider configuré (mode local)."
                else {
                    val hasKey = !AISecretVault(context).get(p.id).isNullOrBlank()
                    "${p.name} · ${if (hasKey) "clé OK" else "clé manquante"}"
                }
            }
        )
    }
    val llmStatus = remember {
        try {
            LlmRouter(rules = RuleBasedLlm { session.brain }).statusLine(context)
        } catch (_: Exception) {
            "LLM local"
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(Modifier.padding(20.dp).navigationBarsPadding()) {
            Text("Paramètres", color = VlBlack, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(llmStatus, color = VlGray, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = systemPrompt,
                onValueChange = { systemPrompt = it },
                label = { Text("Prompt système") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                shape = RoundedCornerShape(12.dp)
            )
            Button(
                onClick = {
                    mascotStore.setSystemPrompt(session.mascot.id, systemPrompt)
                    onSessionRefresh()
                    onSystemMessage("Prompt système enregistré.")
                },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaldivesBlue)
            ) { Text("Enregistrer le prompt système") }


            Spacer(Modifier.height(16.dp))
            Text("Provider API (chat réel)", color = VlBlack, fontWeight = FontWeight.SemiBold)
            Text(
                "Clé + HTTPS → réponses cloud réelles. Sans clé → local uniquement.",
                color = VlGray, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(apiName, { apiName = it }, label = { Text("Nom") }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(12.dp))
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(apiEndpoint, { apiEndpoint = it }, label = { Text("Endpoint HTTPS") }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(12.dp))
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(apiKey, { apiKey = it }, label = { Text("Clé API (vide = ne pas changer)") }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(12.dp))
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(apiPath, { apiPath = it }, label = { Text("Chemin réponse JSON") }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(12.dp))
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(apiTemplate, { apiTemplate = it }, label = { Text("Template JSON") }, modifier = Modifier.fillMaxWidth(), minLines = 3, shape = RoundedCornerShape(12.dp))
            Text(apiStatus, color = VlGray, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (!apiEndpoint.startsWith("https://")) {
                            apiStatus = "Endpoint doit être en https://"
                            return@Button
                        }
                        val reg = ProviderRegistry(context)
                        val id = existingProvider?.id ?: java.util.UUID.randomUUID().toString()
                        val spec = ProviderSpec(
                            id = id,
                            name = apiName.ifBlank { "Provider IA" },
                            endpoint = apiEndpoint.trim(),
                            authType = "bearer",
                            capabilities = setOf("chat", "text"),
                            requestTemplate = apiTemplate.ifBlank { ProviderPresets.openAiChat().requestTemplate },
                            responsePath = apiPath.ifBlank { "choices.0.message.content" },
                            enabled = true
                        )
                        reg.save(spec)
                        if (apiKey.isNotBlank()) AISecretVault(context).put(spec.id, apiKey.trim())
                        apiStatus = "Provider enregistré. Teste la connexion."
                        onSystemMessage("Provider API enregistré : ${spec.name}")
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaldivesBlue)
                ) { Text("Sauver API") }
                OutlinedButton(
                    onClick = {
                        val reg = ProviderRegistry(context)
                        val spec = reg.all().firstOrNull { it.enabled } ?: run {
                            apiStatus = "Aucun provider sauvé"
                            return@OutlinedButton
                        }
                        val secret = AISecretVault(context).get(spec.id)
                        if (secret.isNullOrBlank() && apiKey.isBlank()) {
                            apiStatus = "Clé API manquante"
                            return@OutlinedButton
                        }
                        val key = apiKey.ifBlank { secret!! }
                        apiStatus = "Test en cours…"
                        // run blocking-ish via thread
                        Thread {
                            val r = ProviderExecutor.test(spec, key)
                            // update on main - Compose state may need careful update
                            android.os.Handler(android.os.Looper.getMainLooper()).post {
                                apiStatus = if (r.ok) {
                                    "OK HTTP ${r.status} · ${(r.extracted ?: r.body).take(80)}"
                                } else {
                                    "Échec ${r.error} · ${r.body.take(100)}"
                                }
                            }
                        }.start()
                    },
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Tester") }
            }
            TextButton(onClick = {
                val p = ProviderPresets.openAiChat()
                apiName = p.name
                apiEndpoint = p.endpoint
                apiTemplate = p.requestTemplate
                apiPath = p.responsePath
                apiStatus = "Preset OpenAI chargé — colle ta clé puis Sauver."
            }) { Text("Preset OpenAI (gpt-4o-mini)", color = MaldivesBlueDark) }

            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = sentryDsn,
                onValueChange = { sentryDsn = it },
                label = { Text("Sentry DSN") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        SentryBridge.setDsn(context, sentryDsn)
                        ConsentStore(context).setCrashReporting(sentryDsn.isNotBlank())
                        SentryBridge.initIfAllowed(context)
                        onSystemMessage("Sentry configuré.")
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaldivesBlueDark)
                ) { Text("Activer Sentry") }
                OutlinedButton(
                    onClick = { context.startActivity(Intent(context, ModelHubActivity::class.java)) },
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Hub modèles") }
            }
TextButton(onClick = {
                context.startActivity(
                    Intent(context, LegalActivity::class.java)
                        .putExtra(LegalActivity.EXTRA_DOC, LegalActivity.DOC_PRIVACY)
                )
            }) { Text("Confidentialité", color = MaldivesBlueDark) }
            TextButton(onClick = onLogout) { Text("Déconnexion", color = VlError) }
            Spacer(Modifier.height(20.dp))
        }
    }
}
