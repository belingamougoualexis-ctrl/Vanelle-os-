package com.nova.ai.platform

import java.io.File
import java.security.MessageDigest

object ModelIntegrity {
    fun sha256(file: File): String {
        require(file.isFile) { "Model file not found: ${file.absolutePath}" }
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun matches(file: File, expected: String): Boolean =
        sha256(file).equals(expected.trim().lowercase(), ignoreCase = true)
}
