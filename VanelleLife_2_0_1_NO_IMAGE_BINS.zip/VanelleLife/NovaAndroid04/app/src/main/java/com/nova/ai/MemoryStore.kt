package com.nova.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Memory(
    val text: String, val timestamp: Long, val importance: Int,
    val lastUsed: Long = timestamp, val reinforcements: Int = 0
)

class MemoryStore(context: Context, namespace: String = "default") {
    private val prefs = context.getSharedPreferences("nova_memory_$namespace", Context.MODE_PRIVATE)

    fun all(): List<Memory> {
        val a = JSONArray(prefs.getString("items", "[]") ?: "[]")
        return buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(Memory(
                    o.getString("text"), o.getLong("timestamp"), o.optInt("importance", 1),
                    o.optLong("lastUsed", o.getLong("timestamp")), o.optInt("reinforcements", 0)
                ))
            }
        }
    }

    fun remember(text: String, importance: Int = 1) {
        val list = all().takeLast(199).toMutableList()
        list.add(Memory(text, System.currentTimeMillis(), importance.coerceIn(1, 5)))
        persist(list)
    }

    fun relevant(query: String, limit: Int = 8): List<Memory> {
        val tokens = query.lowercase().split(Regex("\\W+")).filter { it.length > 2 }.toSet()
        return all().map { m ->
            m to tokens.count { m.text.lowercase().contains(it) } * m.importance
        }.filter { it.second > 0 }.sortedByDescending { it.second }.take(limit).map { it.first }
    }

    /** Évaluateur des souvenirs : un souvenir effectivement réutilisé comme contexte pertinent gagne en importance. */
    fun reinforce(text: String) {
        val list = all().toMutableList()
        val i = list.indexOfFirst { it.text == text }
        if (i < 0) return
        val m = list[i]
        list[i] = m.copy(importance = (m.importance + 1).coerceAtMost(5), lastUsed = System.currentTimeMillis(), reinforcements = m.reinforcements + 1)
        persist(list)
    }

    /** Les souvenirs jamais renforcés et vieux de plus de staleAfterMillis, restés à l'importance minimale, sont oubliés. */
    fun decayAndPrune(now: Long, staleAfterMillis: Long) {
        val kept = all().filterNot { it.importance <= 1 && it.reinforcements == 0 && now - it.timestamp > staleAfterMillis }
        persist(kept)
    }

    private fun persist(list: List<Memory>) {
        val a = JSONArray(list.map { m ->
            JSONObject().apply {
                put("text", m.text); put("timestamp", m.timestamp); put("importance", m.importance)
                put("lastUsed", m.lastUsed); put("reinforcements", m.reinforcements)
            }
        })
        prefs.edit().putString("items", a.toString()).apply()
    }
}
