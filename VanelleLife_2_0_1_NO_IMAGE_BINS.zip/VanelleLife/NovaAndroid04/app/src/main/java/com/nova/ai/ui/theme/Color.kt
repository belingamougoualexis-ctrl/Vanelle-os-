package com.nova.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Palette lumineuse pro (fond clair doux + accent océan)
val MaldivesBlue = Color(0xFF0891B2)
val MaldivesBlueDark = Color(0xFF0E7490)
val MaldivesBlueDeep = Color(0xFF155E75)
val MaldivesSoft = Color(0xFF67E8F9)
val MaldivesMist = Color(0xFFECFEFF)
val VlBlack = Color(0xFF0F172A)
val VlSurface = Color(0xFFFFFFFF)
val VlSurfaceHigh = Color(0xFFF0FDFA)
val VlSurfaceSoft = Color(0xFFF8FAFC)
val VlWhite = Color(0xFF0F172A)
val VlGray = Color(0xFF64748B)
val VlError = Color(0xFFDC2626)
val VlSuccess = Color(0xFF059669)
val VlBubbleUser = Color(0xFFCFFAFE)
val VlBubbleBot = Color(0xFFFFFFFF)
val VlStroke = Color(0xFFE2E8F0)
