package com.nova.ai.platform

import android.content.Context

class GenerationService(private val context: Context) {
    fun generate(request: GenerationRequest): GenerationResult {
        val check = RuntimeReadiness.check(context, request)
        if (check.state != ReadinessState.READY) {
            return HonestExecution.unavailable(request.modality, check.message)
        }

        val runtime = RuntimeRegistry.findGeneration(context, request)
            ?: return HonestExecution.unavailable(request.modality, "Runtime disparu avant exécution.")

        return runCatching { runtime.generate(context, request) }.getOrElse {
            GenerationResult(
                success = false,
                errorCode = "RUNTIME_EXCEPTION",
                errorMessage = it.message ?: "Le runtime réel a échoué."
            )
        }
    }
}
