package com.nova.ai.platform

import android.content.Context
import java.io.File

/** Installs a model only after integrity verification. */
class ModelInstaller(private val context:Context,private val registry:ModelRegistry){
    fun install(file:File,name:String,modality:String,version:String,runtime:String,source:String,license:String,expectedSha256:String):ModelArtifact{
        require(file.isFile){"Fichier modèle absent"};require(expectedSha256.matches(Regex("[0-9a-fA-F]{64}"))){"SHA-256 attendu invalide"};require(ModelArtifactVerifier.verify(file,expectedSha256)){"Intégrité du modèle refusée : SHA-256 incorrect"}
        val targetDir=File(context.filesDir,"installed_models").also{it.mkdirs()};val target=File(targetDir,"${expectedSha256.lowercase()}_${file.name}");if(file.absolutePath!=target.absolutePath)file.copyTo(target,true)
        val artifact=ModelArtifact(name=name,modality=modality,version=version,path=target.absolutePath,sha256=expectedSha256.lowercase(),sizeBytes=target.length(),runtime=runtime,source=source,license=license);registry.save(artifact);return artifact
    }
}
