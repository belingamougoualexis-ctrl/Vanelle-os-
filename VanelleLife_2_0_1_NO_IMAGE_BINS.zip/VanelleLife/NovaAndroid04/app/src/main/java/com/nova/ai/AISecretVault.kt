package com.nova.ai

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.charset.StandardCharsets
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Device-bound encryption for provider credentials. Secrets are never stored as plaintext. */
class AISecretVault(private val context: Context) {
    private val alias = "vanellelife-ai-secrets-v1"
    private fun key(): SecretKey {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return kg.generateKey()
    }
    fun put(id: String, secret: String) { if (secret.isBlank()) return; val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());val blob=Base64.encodeToString(c.iv + c.doFinal(secret.toByteArray(StandardCharsets.UTF_8)),Base64.NO_WRAP);context.getSharedPreferences("ai_secrets",0).edit().putString(id,blob).apply() }
    fun get(id: String): String? = try { val raw=Base64.decode(context.getSharedPreferences("ai_secrets",0).getString(id,null) ?: return null,Base64.NO_WRAP); val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,raw.copyOfRange(0,12)));String(c.doFinal(raw.copyOfRange(12,raw.size)),StandardCharsets.UTF_8) } catch (_: Exception){null}
}
