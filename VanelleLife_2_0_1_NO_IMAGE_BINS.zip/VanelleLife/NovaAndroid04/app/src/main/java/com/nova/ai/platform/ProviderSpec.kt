package com.nova.ai.platform

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Provider definitions are data-driven; no provider is mandatory. */
data class ProviderSpec(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val endpoint: String,
    val authType: String = "bearer",
    val capabilities: Set<String> = emptySet(),
    val requestTemplate: String = "{}",
    val responsePath: String = "",
    val asyncStatusPath: String = "",
    val resultPath: String = "",
    val pollingUrlTemplate: String = "",
    val timeoutMs: Long = 120_000,
    val enabled: Boolean = true
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("endpoint", endpoint); put("authType", authType)
        put("capabilities", JSONArray(capabilities.toList())); put("requestTemplate", requestTemplate)
        put("responsePath", responsePath); put("asyncStatusPath", asyncStatusPath); put("resultPath", resultPath)
        put("pollingUrlTemplate", pollingUrlTemplate); put("timeoutMs", timeoutMs); put("enabled", enabled)
    }
    companion object { fun fromJson(o: JSONObject) = ProviderSpec(
        id=o.optString("id",UUID.randomUUID().toString()), name=o.optString("name","Provider"), endpoint=o.optString("endpoint"),
        authType=o.optString("authType","bearer"), capabilities=(0 until (o.optJSONArray("capabilities")?.length() ?: 0)).map{ i->o.optJSONArray("capabilities")?.optString(i).orEmpty()}.filter{it.isNotBlank()}.toSet(),
        requestTemplate=o.optString("requestTemplate","{}"), responsePath=o.optString("responsePath"), asyncStatusPath=o.optString("asyncStatusPath"),
        resultPath=o.optString("resultPath"), pollingUrlTemplate=o.optString("pollingUrlTemplate"), timeoutMs=o.optLong("timeoutMs",120000), enabled=o.optBoolean("enabled",true)) }
}
