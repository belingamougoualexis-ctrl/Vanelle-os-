package com.nova.ai

import java.util.Locale

/**
 * Langues supportées pour micro (reconnaissance) + TTS.
 * La mascotte apprend n'importe quel texte ; micro/voix suivent cette langue.
 */
object LanguageCatalog {

    data class Lang(
        val tag: String,       // BCP-47, ex: fr-FR
        val label: String,     // affiché
        val speechExtra: String // pour RecognizerIntent
    )

    val ALL = listOf(
        Lang("fr-FR", "Français (France)", "fr-FR"),
        Lang("fr-CA", "Français (Canada)", "fr-CA"),
        Lang("en-US", "English (US)", "en-US"),
        Lang("en-GB", "English (UK)", "en-GB"),
        Lang("es-ES", "Español (España)", "es-ES"),
        Lang("es-MX", "Español (México)", "es-MX"),
        Lang("pt-BR", "Português (Brasil)", "pt-BR"),
        Lang("pt-PT", "Português (Portugal)", "pt-PT"),
        Lang("de-DE", "Deutsch", "de-DE"),
        Lang("it-IT", "Italiano", "it-IT"),
        Lang("nl-NL", "Nederlands", "nl-NL"),
        Lang("ar-SA", "العربية", "ar-SA"),
        Lang("sw-KE", "Kiswahili", "sw-KE"),
        Lang("ln-CD", "Lingala", "ln-CD"),
        Lang("zh-CN", "中文 (简体)", "zh-CN"),
        Lang("ja-JP", "日本語", "ja-JP"),
        Lang("ko-KR", "한국어", "ko-KR"),
        Lang("ru-RU", "Русский", "ru-RU"),
        Lang("hi-IN", "हिन्दी", "hi-IN"),
        Lang("tr-TR", "Türkçe", "tr-TR"),
        Lang("pl-PL", "Polski", "pl-PL")
    )

    const val DEFAULT = "fr-FR"

    fun labelOf(tag: String): String =
        ALL.firstOrNull { it.tag.equals(tag, true) }?.label ?: tag

    fun speechOf(tag: String): String =
        ALL.firstOrNull { it.tag.equals(tag, true) }?.speechExtra ?: tag

    fun localeOf(tag: String): Locale {
        val parts = tag.replace('_', '-').split('-')
        return when (parts.size) {
            1 -> Locale(parts[0])
            2 -> Locale(parts[0], parts[1])
            else -> Locale(parts[0], parts[1])
        }
    }

    fun find(tag: String): Lang =
        ALL.firstOrNull { it.tag.equals(tag, true) } ?: ALL.first()
}
