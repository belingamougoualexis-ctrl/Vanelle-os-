package com.nova.ai.platform

/** Stable domain vocabulary for VanelleLife's AI platform. */
object AIArchitecture {
    const val SCHEMA_VERSION = 3
    enum class Modality { CHAT, IMAGE, VIDEO, AUDIO, VISION, MULTIMODAL }
    enum class Execution { LOCAL, USER_SERVER, EXTERNAL_API }
    enum class TrainingMode { FROM_SCRATCH, FINE_TUNE, ADAPTER }
    enum class JobState { QUEUED, RUNNING, PAUSED, SUCCEEDED, FAILED, CANCELLED }
}
