package com.nova.ai

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Téléchargement / vérification des packs TTS en arrière-plan à l'ouverture.
 * État par langue : idle / downloading / ready / missing.
 */
object LanguagePackManager {

    enum class State { IDLE, DOWNLOADING, READY, MISSING }

    private val states = ConcurrentHashMap<String, State>()
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val started = AtomicBoolean(false)
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    fun stateOf(tag: String): State =
        states[normalize(tag)] ?: State.IDLE

    fun isReady(tag: String): Boolean = stateOf(tag) == State.READY

    fun isDownloading(tag: String): Boolean = stateOf(tag) == State.DOWNLOADING

    fun reasonIfNotReady(tag: String): String? {
        return when (stateOf(tag)) {
            State.READY -> null
            State.DOWNLOADING ->
                "Le pack vocal « ${LanguageCatalog.labelOf(tag)} » est encore en cours de préparation en arrière-plan. Réessaie dans un instant."
            State.MISSING ->
                "Le pack « ${LanguageCatalog.labelOf(tag)} » n'est pas installé sur cet appareil. " +
                "Va dans Centre des voix → Installer données vocales système, ou attends la fin de la préparation automatique."
            State.IDLE ->
                "Préparation du pack « ${LanguageCatalog.labelOf(tag)} » pas encore terminée. Patiente quelques secondes."
        }
    }

    /** Lance la vérif de toutes les langues du catalogue (appel à l'ouverture). */
    fun startBackgroundPrepare(context: Context) {
        if (!started.compareAndSet(false, true)) {
            // déjà démarré : re-scan léger
            refreshAll()
            return
        }
        val app = context.applicationContext
        LanguageCatalog.ALL.forEach { states[normalize(it.tag)] = State.DOWNLOADING }

        tts = TextToSpeech(app) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            executor.execute { scanAndMark(app) }
        }
        // timeout de sécurité : si TTS lent, marquer selon dispo partielle
        main.postDelayed({
            if (!ttsReady) {
                LanguageCatalog.ALL.forEach {
                    if (states[normalize(it.tag)] == State.DOWNLOADING) {
                        states[normalize(it.tag)] = State.MISSING
                    }
                }
            }
        }, 15_000)
    }

    private fun scanAndMark(context: Context) {
        val engine = tts ?: return
        for (lang in LanguageCatalog.ALL) {
            val tag = normalize(lang.tag)
            states[tag] = State.DOWNLOADING
            val locale = LanguageCatalog.localeOf(lang.tag)
            val avail = try {
                engine.isLanguageAvailable(locale)
            } catch (_: Exception) {
                TextToSpeech.LANG_NOT_SUPPORTED
            }
            val ready = avail >= TextToSpeech.LANG_AVAILABLE
            states[tag] = if (ready) State.READY else State.MISSING
        }
        // Priorité : langue de la mascotte active
        try {
            val store = MascotStore(context)
            val active = store.active()
            val want = active?.voice?.languageTag ?: LanguageCatalog.DEFAULT
            ensureLanguage(context, want)
        } catch (_: Exception) {}
    }

    fun refreshAll() {
        val engine = tts ?: return
        if (!ttsReady) return
        executor.execute {
            for (lang in LanguageCatalog.ALL) {
                val tag = normalize(lang.tag)
                val avail = try {
                    engine.isLanguageAvailable(LanguageCatalog.localeOf(lang.tag))
                } catch (_: Exception) {
                    TextToSpeech.LANG_NOT_SUPPORTED
                }
                states[tag] = if (avail >= TextToSpeech.LANG_AVAILABLE) State.READY else State.MISSING
            }
        }
    }

    /**
     * Marque DOWNLOADING puis re-vérifie.
     * L'install réelle des données système nécessite souvent l'Intent utilisateur ;
     * on tente quand même une re-scan après délai.
     */
    fun ensureLanguage(context: Context, tag: String) {
        val n = normalize(tag)
        if (states[n] == State.READY) return
        states[n] = State.DOWNLOADING
        executor.execute {
            Thread.sleep(400)
            val engine = tts
            if (engine != null && ttsReady) {
                val avail = try {
                    engine.isLanguageAvailable(LanguageCatalog.localeOf(tag))
                } catch (_: Exception) {
                    TextToSpeech.LANG_NOT_SUPPORTED
                }
                states[n] = if (avail >= TextToSpeech.LANG_AVAILABLE) State.READY else State.MISSING
            } else {
                states[n] = State.MISSING
            }
        }
    }

    fun installSystemDataIntent(): Intent =
        Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)

    fun checkSystemDataIntent(): Intent =
        Intent(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA)

    private fun normalize(tag: String) = tag.replace('_', '-').lowercase(Locale.ROOT)

    fun statusSummary(): String {
        val ready = states.count { it.value == State.READY }
        val down = states.count { it.value == State.DOWNLOADING }
        val miss = states.count { it.value == State.MISSING }
        return "Packs voix : $ready prêts · $down en cours · $miss manquants"
    }
}
