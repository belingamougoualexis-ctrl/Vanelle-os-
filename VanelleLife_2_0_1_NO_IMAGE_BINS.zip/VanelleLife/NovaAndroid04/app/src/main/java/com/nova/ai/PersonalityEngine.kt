package com.nova.ai

/**
 * Fait évoluer les traits de personnalité de NOVA à partir de motifs observés dans un lot
 * d'expériences vécues (fréquence des questions, diversité des sujets, corrections essuyées,
 * retours positifs, profondeur des échanges) — au lieu de traits ajustés uniquement par des
 * règles ponctuelles câblées sur des mots-déclencheurs.
 */
class PersonalityEngine(private val learning: LearningStore) {

    fun developFromExperience(batch: List<Experience>) {
        if (batch.isEmpty()) return

        val questions = batch.count { it.event.contains("?") }
        if (questions >= (batch.size / 3.0)) learning.adjustTrait("curiosité", 0.02)

        val distinctTopics = batch.map { topicOf(it.event) }.filter { it.isNotBlank() }.distinct().size
        if (distinctTopics >= (batch.size * 0.6)) learning.adjustTrait("ouverture", 0.02)
        else learning.adjustTrait("constance", 0.01)

        val corrections = batch.count { it.result.contains("révisé", true) || it.result.contains("corrigé", true) }
        if (corrections > 0) learning.adjustTrait("humilité", (0.015 * corrections).coerceAtMost(0.08))

        val positive = batch.count { e -> listOf("merci", "bien", "content", "utile", "super", "génial").any { e.event.lowercase().contains(it) } }
        if (positive > 0) learning.adjustTrait("confiance", (0.01 * positive).coerceAtMost(0.06))

        val longExchanges = batch.count { it.event.length > 150 }
        if (longExchanges > 0) learning.adjustTrait("profondeur", (0.01 * longExchanges).coerceAtMost(0.06))

        // Sans aucun signal marquant, une légère tendance vers la prudence : le vécu neutre n'engendre pas d'assurance gratuite.
        if (questions == 0 && corrections == 0 && positive == 0) learning.adjustTrait("prudence", 0.01)
    }

    private fun topicOf(text: String) = text.lowercase().split(Regex("\\W+")).filter { it.length > 3 }.take(2).joinToString(" ")
}
