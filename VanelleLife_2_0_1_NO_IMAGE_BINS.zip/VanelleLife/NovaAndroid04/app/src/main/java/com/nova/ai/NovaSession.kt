package com.nova.ai

import android.content.Context

class NovaSession(val context: Context, val mascot: Mascot) {
    val ns = mascot.id
    val memory = MemoryStore(context, ns)
    val learning = LearningStore(context, ns)
    val development = DevelopmentEngine(context, memory, learning, ns)
    val brain = LocalBrain(development, learning, memory, mascot.name).also { it.systemPrompt = mascot.systemPrompt }
    val embedder = EmbeddingClient("", "", "local-hash", preferLocal = true)
    val journal = GrowthJournal(context, ns)

    fun progress(): GrowthSystem.Progress =
        GrowthSystem.compute(development.state(), GrowthSystem.bonusXp(context, mascot.id))

    fun statusLine(): String {
        val p = progress()
        val s = development.state()
        return "${p.label} · souv.${s.memories} exp.${s.experiences} concept.${s.concepts}"
    }
}
