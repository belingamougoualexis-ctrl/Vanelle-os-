package com.nova.ai.platform

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class ModelArtifact(val id:String=UUID.randomUUID().toString(),val name:String,val modality:String,val version:String,val path:String,val sha256:String,val sizeBytes:Long,val runtime:String,val source:String,val license:String,val createdAt:Long=System.currentTimeMillis()) {
    fun json()=JSONObject().apply{put("id",id);put("name",name);put("modality",modality);put("version",version);put("path",path);put("sha256",sha256);put("sizeBytes",sizeBytes);put("runtime",runtime);put("source",source);put("license",license);put("createdAt",createdAt)}
}
class ModelRegistry(context:Context){private val p=context.getSharedPreferences("model_registry_v1",0);fun all():List<ModelArtifact>{val a=JSONArray(p.getString("items","[]"));return(0 until a.length()).map{val o=a.getJSONObject(it);ModelArtifact(o.getString("id"),o.optString("name"),o.optString("modality"),o.optString("version"),o.optString("path"),o.optString("sha256"),o.optLong("sizeBytes"),o.optString("runtime"),o.optString("source"),o.optString("license"),o.optLong("createdAt"))}};fun save(m:ModelArtifact){val a=all().filterNot{it.id==m.id}+m;p.edit().putString("items",JSONArray(a.map{it.json()}).toString()).apply()}}
