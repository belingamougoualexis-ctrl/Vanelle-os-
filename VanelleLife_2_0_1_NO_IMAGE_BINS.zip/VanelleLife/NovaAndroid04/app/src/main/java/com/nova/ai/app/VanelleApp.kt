package com.nova.ai.app

import android.app.Application
import com.nova.ai.crash.CrashReporter
import com.nova.ai.crash.SentryBridge

class VanelleApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashReporter.install(this)
        // DSN: BuildConfig si fourni en CI, sinon prefs utilisateur
        val buildDsn = try {
            val f = Class.forName("com.nova.ai.BuildConfig").getField("SENTRY_DSN")
            (f.get(null) as? String).orEmpty()
        } catch (_: Throwable) {
            ""
        }
        if (buildDsn.isNotBlank() && SentryBridge.getDsn(this).isBlank()) {
            SentryBridge.setDsn(this, buildDsn)
        }
        SentryBridge.initIfAllowed(this)
    }
}
