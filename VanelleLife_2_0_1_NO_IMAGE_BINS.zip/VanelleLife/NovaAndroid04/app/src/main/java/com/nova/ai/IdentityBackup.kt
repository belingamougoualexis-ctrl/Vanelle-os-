package com.nova.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Export / import de l'IA construite par l'utilisateur.
 *
 * Formats :
 * - identity (v3) : prefs brutes pour réimport dans NOVA
 * - portable (v4) : structure claire pour d'autres apps / fine-tuning / RAG
 * - jsonl dataset : une ligne = un exemple (prompt/completion) pour entraînement externe
 */
object IdentityBackup {

    private fun storeNames(ns: String) = listOf(
        "nova_memory_$ns",
        "nova_learning_$ns",
        "nova_concepts_$ns",
        "nova_semantic_$ns",
        "nova_consolidation_$ns",
        "nova_vectors_$ns",
        "nova_supervised_$ns",
        "nova_journal_$ns",
        "nova_xp_$ns"
    )

    /** Export interne NOVA (réimportable). */
    fun export(context: Context, mascotId: String): String {
        val root = JSONObject()
        root.put("nova_identity_version", 3)
        root.put("format", "nova_identity")
        root.put("mascot_id", mascotId)
        root.put("exportedAt", System.currentTimeMillis())
        attachMascotMeta(context, mascotId, root)
        storeNames(mascotId).forEach { name ->
            val p = context.getSharedPreferences(name, Context.MODE_PRIVATE)
            val bundle = JSONObject()
            p.all.forEach { (k, v) ->
                when (v) {
                    is String -> bundle.put(k, v)
                    is Int -> bundle.put(k, v)
                    is Long -> bundle.put(k, v)
                    is Float -> bundle.put(k, v.toDouble())
                    is Boolean -> bundle.put(k, v)
                }
            }
            root.put(name, bundle)
        }
        return root.toString(2)
    }

    /**
     * Export portable : toute l'IA structurée pour usage externe
     * (autre app, site, fine-tuning, base RAG…).
     */
    fun exportPortable(context: Context, session: NovaSession): String {
        val m = session.mascot
        val state = session.development.state()
        val progress = session.progress()
        val root = JSONObject()
        root.put("format", "nova_portable_brain")
        root.put("version", 4)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("license_note", "Construit par l'utilisateur — contenu local, pas de modèle cloud.")

        root.put("mascot", JSONObject().apply {
            put("id", m.id)
            put("name", m.name)
            put("skin", m.skin)
            put("voice", JSONObject(m.voice.toJson()))
            put("createdAt", m.createdAt)
        })

        root.put("growth", JSONObject().apply {
            put("stage", progress.stage)
            put("xp", progress.xp)
            put("developmentStage", state.stage)
            put("memories", state.memories)
            put("experiences", state.experiences)
            put("knowledge", state.knowledge)
            put("concepts", state.concepts)
            put("supervised", state.supervised)
        })

        val knowledge = JSONArray()
        session.learning.knowledge().forEach { k ->
            knowledge.put(JSONObject()
                .put("subject", k.subject)
                .put("fact", k.fact)
                .put("confidence", k.confidence)
                .put("source", k.source))
        }
        root.put("knowledge", knowledge)

        val memories = JSONArray()
        session.memory.all().forEach { mem ->
            memories.put(JSONObject()
                .put("text", mem.text)
                .put("importance", mem.importance)
                .put("timestamp", mem.timestamp))
        }
        root.put("memories", memories)

        val experiences = JSONArray()
        session.learning.experiences().forEach { e ->
            experiences.put(JSONObject()
                .put("event", e.event)
                .put("result", e.result)
                .put("timestamp", e.timestamp))
        }
        root.put("experiences", experiences)

        val concepts = JSONArray()
        session.development.concepts.all().forEach { c ->
            concepts.put(JSONObject()
                .put("name", c.name)
                .put("summary", c.summary)
                .put("keywords", JSONArray(c.keywords))
                .put("confidence", c.confidence))
        }
        root.put("concepts", concepts)

        val supervised = JSONArray()
        session.development.supervised.all().forEach { s ->
            supervised.put(JSONObject()
                .put("question", s.input)
                .put("preferred", s.preferred)
                .put("timestamp", s.timestamp))
        }
        root.put("supervised_pairs", supervised)

        val traits = JSONArray()
        session.learning.traits().forEach { t ->
            traits.put(JSONObject().put("name", t.name).put("value", t.value))
        }
        root.put("personality_traits", traits)

        val journal = JSONArray()
        session.journal.all().forEach { j ->
            journal.put(JSONObject().put("at", j.at).put("kind", j.kind).put("text", j.text))
        }
        root.put("journal", journal)

        // Prêt pour RAG / prompts système
        root.put("system_prompt_suggestion", buildSystemPrompt(session, progress))

        return root.toString(2)
    }

    /**
     * Dataset JSONL : chaque ligne = {"prompt","completion"} pour fine-tuning
     * (OpenAI-compatible, HuggingFace, etc.).
     */
    fun exportDatasetJsonl(session: NovaSession): String {
        val lines = mutableListOf<String>()
        session.development.supervised.all().forEach { s ->
            lines.add(
                JSONObject()
                    .put("prompt", s.input)
                    .put("completion", s.preferred)
                    .put("source", "supervised")
                    .toString()
            )
        }
        session.learning.experiences().forEach { e ->
            val q = e.event.removePrefix("Question : ").removePrefix("Voix : ")
            val a = e.result.removePrefix("Réponse : ")
            if (q.isNotBlank() && a.isNotBlank()) {
                lines.add(
                    JSONObject()
                        .put("prompt", q)
                        .put("completion", a)
                        .put("source", "experience")
                        .toString()
                )
            }
        }
        session.learning.knowledge().forEach { k ->
            lines.add(
                JSONObject()
                    .put("prompt", "Que sais-tu sur ${k.subject} ?")
                    .put("completion", PhraseComposer.ensureSentence(k.fact))
                    .put("source", "knowledge")
                    .toString()
            )
        }
        return lines.joinToString("\n")
    }

    private fun buildSystemPrompt(session: NovaSession, progress: GrowthSystem.Progress): String {
        val traits = session.learning.traits()
            .sortedByDescending { kotlin.math.abs(it.value - 0.5) }
            .take(5)
            .joinToString(", ") { "${it.name}=${"%.2f".format(it.value)}" }
        val facts = session.learning.knowledge().take(20)
            .joinToString("\n") { "- ${it.subject}: ${it.fact}" }
        return """
Tu es ${session.mascot.name}, mascotte au stade ${progress.stage} (${progress.xp} XP).
Tu as été élevée uniquement par ton utilisateur. Tu ne inventes pas hors de ta mémoire.
Traits: $traits

Connaissances:
$facts
        """.trimIndent()
    }

    private fun attachMascotMeta(context: Context, mascotId: String, root: JSONObject) {
        val store = MascotStore(context)
        val m = store.all().firstOrNull { it.id == mascotId }
        if (m != null) {
            root.put("mascot_name", m.name)
            root.put("mascot_skin", m.skin)
            root.put("mascot_voice", m.voice.toJson())
        }
    }

    fun import(context: Context, json: String): Map<String, Int> {
        val root = JSONObject(json)
        val ns = root.optString("mascot_id", "default")
        val report = mutableMapOf<String, Int>()
        storeNames(ns).forEach { name ->
            if (root.has(name)) {
                val bundle = root.getJSONObject(name)
                val editor = context.getSharedPreferences(name, Context.MODE_PRIVATE).edit()
                var count = 0
                bundle.keys().forEach { k ->
                    val v = bundle.get(k)
                    when (v) {
                        is String -> editor.putString(k, v)
                        is Int -> editor.putInt(k, v)
                        is Long -> editor.putLong(k, v)
                        is Double -> editor.putFloat(k, v.toFloat())
                        is Boolean -> editor.putBoolean(k, v)
                    }
                    count++
                }
                editor.apply()
                report[name] = count
            }
        }
        return report
    }
}
