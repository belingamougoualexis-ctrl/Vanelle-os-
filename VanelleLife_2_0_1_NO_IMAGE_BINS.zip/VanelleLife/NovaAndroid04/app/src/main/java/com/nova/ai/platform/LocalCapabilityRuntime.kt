package com.nova.ai.platform

import android.content.Context

/**
 * Honest local adapter: it advertises no modality until a concrete native/ML runtime is linked.
 * This prevents fake image/video/training results while keeping runtime discovery stable.
 */
class LocalCapabilityRuntime : GenerationRuntime {
    override val id: String = "local-core"
    override val displayName: String = "Local Core"
    override val mode: ExecutionMode = ExecutionMode.LOCAL

    override fun capabilities(context: Context): List<RuntimeCapability> = emptyList()

    override fun supports(context: Context, request: GenerationRequest): Boolean = false

    override fun generate(context: Context, request: GenerationRequest): GenerationResult =
        HonestExecution.unavailable(
            request.modality,
            "Aucun moteur local compatible n'est lié à cette installation."
        )
}
