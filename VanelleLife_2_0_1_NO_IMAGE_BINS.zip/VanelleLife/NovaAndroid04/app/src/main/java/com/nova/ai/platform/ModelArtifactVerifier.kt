package com.nova.ai.platform

import java.io.File
import java.security.MessageDigest

object ModelArtifactVerifier {
    fun sha256(file: File): String { require(file.isFile){"Modèle absent"}; val md=MessageDigest.getInstance("SHA-256");file.inputStream().use{input->val b=ByteArray(1024*1024);while(true){val n=input.read(b);if(n<0)break;if(n>0)md.update(b,0,n)}};return md.digest().joinToString(""){String.format("%02x",it)} }
    fun verify(file: File, expected: String): Boolean = expected.isNotBlank() && sha256(file).equals(expected.trim(),true)
}
