package com.nova.ai

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.*
import android.view.animation.ScaleAnimation
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast

class MascotOverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var bubble: View? = null
    private var avatar: ImageView? = null
    private var params: WindowManager.LayoutParams? = null
    private var voiceEngine: VoiceEngine? = null
    private var recognizer: SpeechRecognizer? = null
    private var session: NovaSession? = null
    private var listening = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        voiceEngine = VoiceEngine(this)
        startAsForeground()
        reloadSession()
        showBubble()
    }

    private fun reloadSession() {
        val store = MascotStore(this)
        val m = store.active() ?: store.add("Vanelle", MascotStore.DEFAULT_SKIN)
        if (store.activeId().isBlank()) store.setActive(m.id)
        session = NovaSession(this, store.active() ?: m)
    }

    private fun startAsForeground() {
        val channelId = "nova_mascot"
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "Mascotte Vanelle", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val pending = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, channelId)
            .setContentTitle(session?.mascot?.name ?: "Vanelle")
            .setContentText("Touche = parler · Long = menu")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pending)
            .build()
        startForeground(42, notif)
    }

    private fun vibrateLight() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val vm = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
                else @Suppress("DEPRECATION") v.vibrate(30)
            }
        } catch (_: Exception) {}
    }

    private fun pulse(emotion: GrowthSystem.Emotion) {
        val iv = avatar ?: return
        val scale = when (emotion) {
            GrowthSystem.Emotion.LISTENING -> 1.12f
            GrowthSystem.Emotion.THINKING -> 0.92f
            GrowthSystem.Emotion.HAPPY, GrowthSystem.Emotion.PROUD -> 1.18f
            GrowthSystem.Emotion.SURPRISED -> 1.25f
            else -> 1.08f
        }
        val anim = ScaleAnimation(
            1f, scale, 1f, scale,
            ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
            ScaleAnimation.RELATIVE_TO_SELF, 0.5f
        ).apply {
            duration = 180
            repeatMode = ScaleAnimation.REVERSE
            repeatCount = 1
        }
        iv.startAnimation(anim)
        // teinte légère
        val filter = when (emotion) {
            GrowthSystem.Emotion.LISTENING -> android.graphics.ColorMatrixColorFilter(
                android.graphics.ColorMatrix().apply { setScale(0.85f, 0.95f, 1.2f, 1f) }
            )
            GrowthSystem.Emotion.PROUD, GrowthSystem.Emotion.HAPPY -> android.graphics.ColorMatrixColorFilter(
                android.graphics.ColorMatrix().apply { setScale(1.15f, 1.1f, 0.9f, 1f) }
            )
            GrowthSystem.Emotion.SURPRISED -> android.graphics.ColorMatrixColorFilter(
                android.graphics.ColorMatrix().apply { setScale(1.2f, 1.2f, 1.2f, 1f) }
            )
            else -> null
        }
        iv.colorFilter = filter
        iv.postDelayed({ iv.clearColorFilter() }, 600)
    }

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val skin = session?.mascot?.skin ?: MascotStore.DEFAULT_SKIN
        val resId = MascotStore.drawableId(this, skin)

        val iv = ImageView(this).apply {
            setImageResource(resId)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            // aura boutique
            val aura = session?.mascot?.id?.let { XpShop.activeAura(this@MascotOverlayService, it) } ?: ""
            val matrix = android.graphics.ColorMatrix()
            when (aura) {
                "aura_soft" -> matrix.setScale(1.1f, 1.0f, 1.25f, 1f)
                "aura_fire" -> matrix.setScale(1.25f, 1.05f, 0.85f, 1f)
                "aura_ocean" -> matrix.setScale(0.85f, 1.05f, 1.3f, 1f)
                "aura_gold" -> matrix.setScale(1.3f, 1.15f, 0.8f, 1f)
            }
            if (aura.isNotEmpty()) colorFilter = android.graphics.ColorMatrixColorFilter(matrix)
        }
        avatar = iv
        val size = (72 * resources.displayMetrics.density).toInt()
        val root = FrameLayout(this).apply {
            addView(iv, FrameLayout.LayoutParams(size, size))
            elevation = 16f
        }

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 200
        }

        var downX = 0f
        var downY = 0f
        var paramX = 0
        var paramY = 0
        var moved = false
        var downAt = 0L

        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    paramX = params!!.x; paramY = params!!.y
                    moved = false
                    downAt = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12) moved = true
                    params!!.x = paramX + dx
                    params!!.y = paramY + dy
                    windowManager?.updateViewLayout(root, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val longPress = System.currentTimeMillis() - downAt > 500
                    if (!moved) {
                        if (longPress) showQuickMenu()
                        else startListening()
                    }
                    true
                }
                else -> false
            }
        }

        bubble = root
        windowManager?.addView(root, params)
    }

    private fun showQuickMenu() {
        vibrateLight()
        val names = arrayOf("Parler", "Ouvrir NOVA", "Taire (stop voix)", "Arrêter la bulle")
        // Toast menu simple (pas d'Activity dialog fiable depuis service sans FLAG)
        Toast.makeText(this, "Parler = toucher court · Ouvrir = notification", Toast.LENGTH_SHORT).show()
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun startListening() {
        if (listening) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Reconnaissance vocale indisponible", Toast.LENGTH_SHORT).show()
            return
        }
        listening = true
        vibrateLight()
        pulse(GrowthSystem.Emotion.LISTENING)
        Toast.makeText(this, "${session?.mascot?.name ?: "Vanelle"} écoute…", Toast.LENGTH_SHORT).show()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: android.os.Bundle?) {
                listening = false
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) onHeard(text)
            }
            override fun onError(error: Int) { listening = false }
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val lang = session?.mascot?.voice?.languageTag?.ifBlank { LanguageCatalog.DEFAULT } ?: LanguageCatalog.DEFAULT
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, LanguageCatalog.speechOf(lang))
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, LanguageCatalog.speechOf(lang))
        }
        recognizer?.startListening(intent)
    }

    private fun onHeard(text: String) {
        val s = session ?: return
        pulse(GrowthSystem.Emotion.THINKING)
        s.development.observe(text)
        val answer = s.brain.reply(text)
        s.learning.addExperience("Voix : $text", "Réponse : $answer")
        s.journal.add("voix", text.take(80))
        GrowthSystem.addBonusXp(this, s.mascot.id, 2)
        pulse(GrowthSystem.Emotion.HAPPY)
        voiceEngine?.speak(answer, s.mascot.voice, "mascot_reply")
        Toast.makeText(this, "${s.mascot.name} : $answer", Toast.LENGTH_LONG).show()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RELOAD -> {
                bubble?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
                reloadSession()
                showBubble()
            }
            ACTION_STOP -> stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        bubble?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        recognizer?.destroy()
        voiceEngine?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_RELOAD = "com.nova.ai.RELOAD_MASCOT"
        const val ACTION_STOP = "com.nova.ai.STOP_OVERLAY"
    }
}
