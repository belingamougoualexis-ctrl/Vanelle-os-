package com.nova.ai.platform

import org.json.JSONObject

object PortableAI {
    const val FORMAT = "vanelle.ai"
    const val VERSION = 1

    fun manifest(ai: PersonalAI, models: List<ModelCard>): JSONObject = JSONObject().apply {
        put("format", FORMAT)
        put("version", VERSION)
        put("aiId", ai.id)
        put("name", ai.name)
        put("aiVersion", ai.version)
        put("portable", true)
        put("createdAt", ai.createdAt)
        put("updatedAt", ai.updatedAt)
        put("components", JSONObject().apply {
            put("identity", true)
            put("personality", true)
            put("memory", true)
            put("education", true)
            put("skills", true)
            put("knowledge", true)
            put("versions", true)
            put("modelReferences", true)
        })
        put("models", models.map {
            JSONObject().apply {
                put("id", it.id)
                put("version", it.version)
                put("sha256", it.sha256)
                put("source", it.source)
                put("license", it.license)
            }
        })
    }
}
