package com.nova.ai.platform

/** Safety boundary for tools and destructive actions. */
object CapabilityPolicy {
    private val confirm=setOf("share_file","delete_data","publish","payment","send_message")
    fun requiresConfirmation(action:String)=confirm.contains(action)
    fun validateExternalEndpoint(endpoint:String){require(endpoint.startsWith("https://")){"Endpoint refusé : HTTPS obligatoire."};require(!endpoint.contains("localhost")&&!endpoint.contains("127.0.0.1")){"Endpoint local explicite requis via un runtime dédié."}}
}
