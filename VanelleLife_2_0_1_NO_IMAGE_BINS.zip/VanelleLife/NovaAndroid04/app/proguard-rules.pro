# VanelleLife — règles ProGuard/R8 pour le build de release.
# Objectif : réduire la taille de l'APK, obfusquer le code, sans casser
# la sérialisation JSON ni les composants Android déclarés dans le manifeste.

# --- Android / AndroidX standard ---
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.appwidget.AppWidgetProvider

# --- org.json : les classes sont accédées par nom/reflection dans certains cas ---
-keep class org.json.** { *; }
-dontwarn org.json.**

# --- WorkManager : les Worker sont instanciés par réflexion via leur nom de classe ---
-keep class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}
-keep class com.nova.ai.NightlyConsolidationWorker { *; }

# --- Modèle de données interne sérialisé en JSON (évite le renommage des champs) ---
-keepclassmembers class com.nova.ai.** {
    <fields>;
}
-keepclassmembers class com.nova.ai.platform.** {
    <fields>;
}

# --- Kotlin metadata (nécessaire pour la reflection Kotlin de base) ---
-keep class kotlin.Metadata { *; }
-dontwarn kotlin.**

# --- Ne pas obfusquer les data class utilisées pour le (dé)sérialisation JSON manuelle ---
-keepclassmembers class * {
    public <init>(...);
}

# --- Logs : supprimés en release pour ne pas fuiter d'infos de debug ---
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
}

# MediaPipe GenAI
-keep class com.google.mediapipe.** { *; }
-dontwarn com.google.mediapipe.**

# Sentry
-keep class io.sentry.** { *; }
-dontwarn io.sentry.**

