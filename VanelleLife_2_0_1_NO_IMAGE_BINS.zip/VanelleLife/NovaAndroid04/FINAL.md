# VanelleLife 2.0.0-final

## Ce qui est 100 % réel et fonctionnel

| Fonction | Comportement réel |
|----------|-------------------|
| Compte local | Inscription / connexion / logout (SharedPreferences) |
| Consentement RGPD | Obligatoire au 1er lancement |
| Chat | Provider HTTPS **ou** Gemma on-device **ou** règles + mémoire |
| Clé API | Chiffrée (Android Keystore), POST HTTPS réel |
| Prompt système | Injecté provider + LLM + règles |
| Enseignements chat | Faits explicites + déclaratifs → learning/memory |
| Import fichiers | txt, md, json, jsonl, **zip**, gz |
| Téléchargement modèles | Auto au démarrage, **reprise** `.part` + Range |
| Espace disque | Contrôle avant download |
| Image | Provider HTTPS « image » uniquement |
| Crash | Trace locale ; Sentry si DSN + opt-in |
| Compose UI | Consent, auth, chat, settings, bootstrap |

## Ce qui dépend de toi / du réseau

- Clé API valide pour le cloud
- Wi‑Fi + espace pour Gemma (~550 Mo)
- Keystore Play Store pour publication

## Lancer

1. Android Studio → ouvrir `NovaAndroid04`
2. Sync Gradle
3. Run sur **téléphone réel** (recommandé pour MediaPipe)
4. Info → Preset OpenAI → clé → Tester → chat

## Périmètre honnête

Pas un GPT intégré offline de 100B paramètres.
Pas d’API publique partageable sans backend.
Pas de RAR natif (convertir en zip).
