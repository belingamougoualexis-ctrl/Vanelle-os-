# VanelleLife — AI Studio Pro production architecture

## What is real in this release
- User-owned AI profiles, education and skills are persisted locally.
- External provider requests use real HTTPS REST calls; no fake generation output is returned.
- API secrets are protected by Android Keystore and can be exported only through the app's password-protected secret envelope flow.
- Model Lab records reproducible model projects and performs real hardware/dataset inspection.
- Remote training has an HTTPS protocol for a user's own/authorized GPU server.
- A `TrainingRuntime` contract prevents the app from claiming local training unless a real runtime is installed and registered.
- Cleartext HTTP is disabled.

## What still requires a real ML implementation before claiming “from-scratch generation”
1. A native inference runtime for each supported model family.
2. A real image/video training implementation (data loader, optimizer, checkpoints, validation, mixed precision, GPU/NPU acceleration).
3. A signed model artifact format and checksum verification.
4. A full dataset manifest/annotation pipeline persisted in a durable database.
5. Device/remote job state persistence and cancellation/resume semantics.

These are deliberately represented as extension points rather than simulated features.

## Global-scale product gates
- Room/SQLite schema + migrations for AI state and large projects.
- End-to-end encrypted optional sync.
- Account/session security and device management.
- Signed packages/models, provenance and license enforcement.
- Marketplace moderation, malware scanning and sandboxing.
- SDK/plugin API with versioned contracts.
- Telemetry that is privacy-preserving and opt-in where required.
- Accessibility, localization, RTL, offline-first UX.
- Automated unit/integration/UI/security/performance tests.
- Reproducible CI builds, release signing, Play App Bundle, staged rollout and crash/ANR monitoring.
