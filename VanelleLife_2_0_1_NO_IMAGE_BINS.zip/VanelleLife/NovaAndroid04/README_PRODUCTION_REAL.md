# VanelleLife 2.1 — production-real architecture

This release strengthens the platform without pretending unavailable ML capabilities exist.

### Real in the Android project
- SQLite persistence for AI profiles, lessons, skills, model projects, datasets, jobs and audit events.
- Migration path from the previous SharedPreferences AI Studio store.
- Dataset import into private storage with SHA-256 manifests.
- HTTPS-only provider execution and configurable JSON response extraction.
- Android Keystore credential storage.
- Password-protected AI exports with AES-GCM encryption.
- Model artifact verification and compatibility checks.
- Durable WorkManager training jobs.
- Real remote-training submission protocol.
- Real Vulkan/NNAPI capability checks where Android exposes the corresponding hardware features.

### Explicitly not bundled
A high-quality image/video foundation model, a universal native GPU training runtime, a GPU cloud fleet, a global backend, marketplace, or developer ecosystem cannot be created merely by adding Android UI/classes. Those require real model implementations/weights, native runtimes, datasets, servers and operational infrastructure. The app fails honestly when those components are absent.
