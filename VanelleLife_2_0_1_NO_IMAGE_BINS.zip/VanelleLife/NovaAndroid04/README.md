# VanelleLife 1.2.0-final

Application Android — mascottes IA personnelles élevées par l'utilisateur (**100 % local** par défaut).

## Contenu production

- Compte local (PBKDF2, export/import chiffré)
- Mascottes Vanelle (skins, mémoire séparée, stades XP)
- Apprentissage : chat, enseigner, corriger, importer fichiers
- Bulle flottante + micro + TTS
- AI Studio (datasets, jobs, providers HTTPS)
- **Consentement RGPD** + politique de confidentialité + CGU
- **CrashReporter** local avec opt-in
- **Contrat LLM on-device** + Hub téléchargement (Gemma-3 1B, MiniLM)
- MediaPipe tasks-genai + Sentry optionnel (opt-in)
- **Prompt système** par mascotte (injecté réellement)
- **Génération d'image** via provider HTTPS / AI Studio
- Base SQLite durable (`AppDatabase`)
- Accessibilité de base
- CI GitHub Actions + signature release via env

## Build

```bash
# Debug
./gradlew assembleDebug

# Release (keystore via env)
export VANELLELIFE_KEYSTORE_PATH=...
export VANELLELIFE_KEYSTORE_PASSWORD=...
export VANELLELIFE_KEY_ALIAS=...
export VANELLELIFE_KEY_PASSWORD=...
./gradlew bundleRelease
```

minSdk 23 · applicationId `com.vanellelife.app` · versionName **1.2.0-final**

## Documentation

- [Comment ça marche](COMMENT_CA_MARCHE.md)
- [Checklist production](docs/PRODUCTION_CHECKLIST.md)
- [Fiche Play Store](docs/PLAY_STORE.md)
- [Réalité technique](PRODUCTION_REALITY.md)
- [Changements 1.0](CHANGES_PRODUCTION_1_0.md)

## Honnêteté

L’app ne prétend jamais qu’un modèle image/vidéo/LLM frontier est disponible tant qu’un runtime et des poids réels ne sont pas installés. Voir `PRODUCTION_REALITY.md`.
