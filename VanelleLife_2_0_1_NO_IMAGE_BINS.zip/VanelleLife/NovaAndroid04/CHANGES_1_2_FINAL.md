# VanelleLife 1.2.0-final

## Prompt système (réel)
- Champ `systemPrompt` par mascotte (persisté)
- Info → Plus… → **Prompt système de la mascotte**
- Injecté dans :
  - Provider HTTPS (`system` / `system_prompt` dans le template)
  - MediaPipe / LLM on-device (`systemHint`)
  - LocalBrain (directives déterministes : tutoiement, concision, emoji, etc.)

## Génération d'image
- Info → Plus… → **Générer une image**
- `ImageGenService` :
  1. Provider HTTPS capacité `image`
  2. Backend image AI Studio
  3. Sinon message honnête (pas de fausse image)
- Aperçu dialog + fichier dans `filesDir/generated_images/`

## Provider
- Cases à cocher chat et/ou image
- Template par défaut avec `system`

## Version
- versionName **1.2.0-final** · versionCode **70**
