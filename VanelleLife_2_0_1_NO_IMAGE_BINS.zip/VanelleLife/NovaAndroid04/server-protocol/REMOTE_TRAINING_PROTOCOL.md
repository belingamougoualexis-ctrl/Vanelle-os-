# VanelleLife Remote Training Protocol v1

This is a contract, not a simulated server.

## POST /v1/training/jobs
The VanelleLife client sends a JSON job describing `projectId`, `aiId`, modality, architecture, dataset manifest reference, output contract and training configuration.

A real server must return either:
- `202` with `{ "jobId": "...", "statusUrl": "https://..." }`, or
- `4xx/5xx` with a truthful error body.

## GET /v1/training/jobs/{jobId}
The server returns measured state:
`queued | running | paused | completed | failed | cancelled`, progress 0..100, step, loss when available, checkpoint reference when completed, and a truthful error when failed.

## Security
- HTTPS is mandatory.
- The server authenticates the user/job.
- Dataset/model references must be authorized.
- Checkpoints should be integrity checked with SHA-256.
- Never put provider secrets in job payloads unless the user explicitly requires it and the transport/server policy supports it.

VanelleLife must never turn a missing server or missing training runtime into a fake success.
