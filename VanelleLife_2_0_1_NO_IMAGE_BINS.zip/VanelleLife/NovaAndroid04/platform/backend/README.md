# Vanelle Backend Contract

This directory defines the production API boundary for personal servers and Vanelle Cloud.
It intentionally does not pretend that a GPU cluster exists inside the Android APK.

Required production services:
- authenticated API gateway;
- job service with durable state;
- object storage for datasets/checkpoints/results;
- GPU workers for models that cannot run locally;
- usage metering and quotas;
- audit/security logging;
- model registry and signed artifacts.

`openapi.yaml` is the contract the Android client can target. A deployment is only considered
available when a real service answers the health endpoint and accepts authenticated jobs.
