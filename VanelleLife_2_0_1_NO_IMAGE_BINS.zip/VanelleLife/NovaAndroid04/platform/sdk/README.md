# Vanelle SDK direction

The SDK exposes stable concepts: PersonalAI, ModelCard, AISkill, ToolManifest, ProviderClient,
GenerationRuntime and TrainingRuntime. Implementations must return measured results or explicit
errors; placeholder success is forbidden.

Recommended SDK packages for future releases:
- Kotlin Android client
- JVM/server client
- Python client for personal GPU servers
- TypeScript client for web/developer integrations
