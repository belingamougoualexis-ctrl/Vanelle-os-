# Vanelle Security Model

1. API secrets are credentials, never part of an AI personality or training dataset.
2. Portable AI exports contain references and encrypted secret material only when explicitly enabled.
3. Tools receive least-privilege permissions and may require confirmation.
4. Remote jobs require authenticated transport and server-side authorization.
5. Model artifacts must be integrity checked before execution.
6. No UI may claim generation/training succeeded until the runtime returns success.
