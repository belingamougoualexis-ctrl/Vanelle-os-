# VanelleLife AI Studio Pro

This version separates the user's AI identity from model runtimes and external providers.

## Modes
- Local model: runs only when a real compatible runtime/model is installed.
- User server: submits reproducible training jobs to an HTTPS server controlled/authorized by the user.
- External API: optional provider registry with capability mapping.

## Level 3 truthfulness
Model Lab creates and validates real training projects, datasets and configurations. It does not simulate model training. The included Android worker fails explicitly until a real ML runtime is installed. A production implementation must plug a real runtime (e.g. an ONNX/NNAPI/native training engine) or the user's own GPU training server into `TrainingWorker`.

## Education
Identity, memories, lessons, corrections and skills are stored as user-owned AI state and are not falsely described as model-weight training.

## Security
External endpoints require HTTPS. Cleartext traffic is disabled. Provider secrets remain in Android Keystore-backed storage. Export formats must use a password-protected envelope for transferable secrets; never put raw API keys in a shareable manifest.

## Next production gates
1. Ship a real inference runtime per supported model family.
2. Ship/plug a real training runtime for supported architectures, or the user's GPU server protocol.
3. Add automated unit/integration/UI/security tests and CI build artifacts.
4. Add a durable Room/SQLite schema with migrations for large-scale AI state.
5. Add signed model/package manifests and license/provenance validation before marketplace distribution.
