# Real-feature verification checklist

1. Build with a real Android SDK/Gradle environment.
2. Run unit tests.
3. Create an AI and verify it survives app restart.
4. Import a dataset and verify its private copy + manifest + SHA-256.
5. Configure an HTTPS provider and verify the response body is the provider response.
6. Verify an incorrect API key produces a truthful failure.
7. Export an AI and confirm API secrets are encrypted, never plaintext.
8. Import with the correct password and verify the secret can be recovered.
9. Import with a wrong password and verify the import fails without installing the secret.
10. Start training without a real runtime: it must fail, not progress.
11. Start training with a real runtime implementation: progress/checkpoints must come from that runtime.
12. Verify model SHA-256 before installation/use.
