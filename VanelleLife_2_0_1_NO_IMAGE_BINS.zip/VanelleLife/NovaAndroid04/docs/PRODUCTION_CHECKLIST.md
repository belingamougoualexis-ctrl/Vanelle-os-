# VanelleLife 1.0 — Checklist production & publication

## A. Technique (déjà en place dans ce paquet)

- [x] Signature release via variables d'environnement (jamais de keystore dans le repo)
- [x] ProGuard / R8 + shrinkResources en release
- [x] `usesCleartextTraffic="false"`
- [x] Mots de passe PBKDF2 (210k) + migration transparente
- [x] Secrets API dans Android Keystore
- [x] Exports AES-GCM
- [x] CI GitHub Actions (build, tests, lint, assembleRelease)
- [x] Politique de confidentialité + CGU (assets HTML + LegalActivity)
- [x] Consentement premier lancement (ConsentStore)
- [x] CrashReporter local + opt-in
- [x] Contrat LLM on-device honnête (pas de génération inventée)
- [x] Base SQLite durable (AppDatabase + PlatformDatabase)
- [x] Accessibilité de base (contentDescription helpers)

## B. À faire de votre côté avant soumission Play Store

1. **Keystore**
   ```bash
   keytool -genkeypair -v -keystore vanellelife-release.jks -alias vanelle -keyalg RSA -keysize 2048 -validity 10000
   ```
   Exporter en secrets CI : `VANELLELIFE_KEYSTORE_B64`, `VANELLELIFE_KEYSTORE_PASSWORD`, `VANELLELIFE_KEY_ALIAS`, `VANELLELIFE_KEY_PASSWORD`.

2. **AAB**
   ```bash
   ./gradlew bundleRelease
   ```

3. **Play Console**
   - Créer l'app `com.vanellelife.app`
   - Remplir **Data safety** (données locales, pas de partage par défaut)
   - Uploader privacy policy (héberger le HTML ou lien vers site)
   - Screenshots téléphone (min. 2), feature graphic 1024×500
   - Classification du contenu, public cible

4. **Optionnel mais recommandé**
   - Brancher Sentry ou Firebase Crashlytics sur `CrashReporter` (après opt-in)
   - Ajouter un vrai modèle GGUF + runtime llama.cpp / MediaPipe dans `filesDir/models/`
   - Tests instrumentés sur device

## C. Ce qui reste volontairement hors scope binaire

- Poids de modèles frontier (image/vidéo/LLM 7B+)
- Cluster GPU cloud
- Backend marketplace global

Voir `PRODUCTION_REALITY.md` et `AI_PLATFORM_REAL.md`.
