# Architecture VanelleLife 1.5 (pro)

```
com.nova.ai
├── app/           Application (Sentry, crash)
├── ui/            Jetpack Compose (thème, écrans)
│   ├── theme/
│   └── VanelleRoot.kt
├── llm/           Runtimes on-device (MediaPipe LLM + Image)
├── legal/         Consentement, LegalActivity
├── crash/         CrashReporter + SentryBridge
├── db/            SQLite durable
├── platform/      Providers HTTPS, jobs, readiness
└── *Store.kt      Domaine métier (mascotte, mémoire, compte…)
```

## Flux chat
Utilisateur → ChatEngine → Provider HTTPS? → MediaPipe LLM? → LocalBrain

## Flux image
ImageGenService → Provider image HTTPS → AI Studio?

## Bootstrap
ModelBootstrap au démarrage : embeddings + Gemma + zip image (si URL)
