# Fiche Play Store — VanelleLife

## Titre
VanelleLife — Mascottes IA personnelles

## Description courte (80 car. max)
Élève des mascottes IA 100 % locales. Mémoire, voix, bulle flottante.

## Description longue (FR)
VanelleLife te permet d’élever des mascottes IA personnelles qui vivent sur ton téléphone.

• Apprentissage local : enseigne, corrige, consolide  
• Mémoire et personnalité par mascotte  
• Bulle flottante + micro + synthèse vocale  
• Compte 100 % local (export pour changer de téléphone)  
• AI Studio : datasets, jobs, providers HTTPS optionnels  
• Aucune clé cloud obligatoire  

Tes données restent sur ton appareil. Les capacités avancées (modèles neuronaux) s’activent uniquement si tu installes un runtime/modèle réel — l’app ne prétend jamais le contraire.

## Mots-clés
IA, mascotte, local, offline, mémoire, TTS, apprentissage, companion

## Catégorie
Éducation / Divertissement

## Public
PEGI 3 / Everyone (pas de contenu sensible par défaut)

## Data safety (résumé)
- Données collectées : aucune par défaut  
- Données partagées : aucune par défaut  
- Stockage local : compte, mémoire mascotte  
- Optionnel : provider HTTPS configuré par l’utilisateur, crash reporting opt-in  

## Contact
À renseigner dans Play Console (email support).
