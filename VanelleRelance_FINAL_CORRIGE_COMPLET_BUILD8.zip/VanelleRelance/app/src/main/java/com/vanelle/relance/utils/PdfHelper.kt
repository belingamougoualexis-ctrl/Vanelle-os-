package com.vanelle.relance.utils

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.vanelle.relance.data.Client
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfHelper {
    fun generateDebtAcknowledgement(
        context: Context,
        client: Client,
        reference: String,
        signature: Bitmap?
    ): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
        paint.textSize = 22f
        paint.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText("RECONNAISSANCE DE DETTE", 50f, 70f, paint)
        paint.textSize = 13f
        paint.typeface = Typeface.DEFAULT
        canvas.drawText("Vanelle Relance", 50f, 95f, paint)
        canvas.drawText("Référence : $reference", 50f, 130f, paint)
        canvas.drawText("Date : ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date())}", 50f, 152f, paint)
        canvas.drawText("Débiteur : ${client.nom}", 50f, 200f, paint)
        canvas.drawText("Téléphone : ${client.telephone}", 50f, 222f, paint)
        canvas.drawText("Montant reconnu : ${"%,.0f".format(Locale.FRANCE, client.montant).replace(",", " ")} FCFA", 50f, 244f, paint)
        canvas.drawText("Échéance : ${SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(client.dateEcheance))}", 50f, 266f, paint)
        canvas.drawText("Le débiteur reconnaît devoir la somme indiquée ci-dessus.", 50f, 315f, paint)
        canvas.drawText("Signature du débiteur :", 50f, 390f, paint)
        canvas.drawRect(50f, 410f, 545f, 610f, Paint().apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = Color.DKGRAY
        })
        signature?.let {
            val scaled = Bitmap.createScaledBitmap(it, minOf(480, it.width), minOf(180, it.height), true)
            canvas.drawBitmap(scaled, 60f, 425f, Paint(Paint.ANTI_ALIAS_FLAG))
        }
        paint.textSize = 10f
        canvas.drawText("Signature recueillie dans l'application. Ce document n'est pas une certification électronique.", 50f, 650f, paint)
        canvas.drawText("À conserver avec les justificatifs de la transaction.", 50f, 670f, paint)
        document.finishPage(page)
        val dir = File(context.cacheDir, "documents").apply { mkdirs() }
        val file = File(dir, "reconnaissance_${reference.replace("[^A-Za-z0-9_-]".toRegex(), "_")}.pdf")
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()
        return file
    }

    fun share(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Partager le PDF"))
    }
}
