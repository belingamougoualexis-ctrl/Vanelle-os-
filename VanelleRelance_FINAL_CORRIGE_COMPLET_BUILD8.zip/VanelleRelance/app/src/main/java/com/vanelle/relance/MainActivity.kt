package com.vanelle.relance

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.vanelle.relance.security.CryptoManager
import com.vanelle.relance.ui.screens.*
import com.vanelle.relance.ui.theme.VanelleRelanceTheme
import com.vanelle.relance.ui.theme.DisableCopyText
import com.vanelle.relance.utils.PermissionHelper
import com.vanelle.relance.utils.PreferencesHelper

sealed class Onglet(val route: String, val label: String, val icone: ImageVector) {
    object Relance : Onglet("relance", "Relance", Icons.Default.Home)
    object Sommes : Onglet("sommes", "Sommes", Icons.Default.AccountBalanceWallet)
    object Radar : Onglet("radar", "Radar", Icons.Default.Notifications)
    object Oublies : Onglet("oublies", "Oubliés", Icons.Default.History)
    object Reglages : Onglet("reglages", "Réglages", Icons.Default.Settings)
    object Outils : Onglet("outils", "Outils", Icons.Default.Build)
}

val onglets = listOf(Onglet.Relance, Onglet.Sommes, Onglet.Radar, Onglet.Oublies, Onglet.Outils, Onglet.Reglages)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val context = androidx.compose.ui.platform.LocalContext.current
            val prefsHelper = remember { PreferencesHelper(context) }
            var darkPref by remember { mutableStateOf(prefsHelper.modeSombre) }
            val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
            val useDark = darkPref ?: systemDark

            VanelleRelanceTheme(darkTheme = useDark) {
                DisableCopyText {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        val cryptoManager = remember { CryptoManager(context) }

                        var conditionsOk by remember { mutableStateOf(prefsHelper.conditionsAcceptees) }
                        var deverrouille by remember { mutableStateOf(!cryptoManager.estConfigure()) }

                        when {
                            !conditionsOk -> {
                                LegalScreen(prefsHelper = prefsHelper) {
                                    conditionsOk = true
                                }
                            }
                            !deverrouille -> {
                                VerrouillageScreen(cryptoManager = cryptoManager) {
                                    deverrouille = true
                                }
                            }
                            else -> {
                                EcranPrincipalAvecPermissions()
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EcranPrincipalAvecPermissions() {
    val context = LocalContext.current
    var permissionsDemandees by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* résultats système */ }

    LaunchedEffect(Unit) {
        if (!permissionsDemandees) {
            val manquantes = PermissionHelper.permissionsManquantes(context)
            if (manquantes.isNotEmpty()) {
                launcher.launch(manquantes)
            }
            permissionsDemandees = true
        }
    }

    EcranPrincipal()
}

@Composable
fun EcranPrincipal() {
    val navController: NavHostController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar {
                val backStackEntry by navController.currentBackStackEntryAsState()
                val routeActuelle = backStackEntry?.destination?.route

                onglets.forEach { onglet ->
                    NavigationBarItem(
                        selected = routeActuelle == onglet.route,
                        onClick = {
                            navController.navigate(onglet.route) {
                                popUpTo(navController.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(onglet.icone, contentDescription = onglet.label) },
                        label = { Text(onglet.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Onglet.Relance.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Onglet.Relance.route) { RelanceScreen() }
            composable(Onglet.Sommes.route) { SommesScreen() }
            composable(Onglet.Radar.route) { RadarScreen() }
            composable(Onglet.Oublies.route) { OubliesScreen() }
            composable(Onglet.Outils.route) { OutilsScreen() }
            composable(Onglet.Reglages.route) { ReglagesScreen() }
        }
    }
}
