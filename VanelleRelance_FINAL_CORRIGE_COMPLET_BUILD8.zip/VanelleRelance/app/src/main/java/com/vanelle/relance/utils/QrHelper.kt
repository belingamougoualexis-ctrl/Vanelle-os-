package com.vanelle.relance.utils

import android.graphics.Bitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix

object QrHelper {
    fun generatePaymentRequest(
        nom: String,
        montant: Double,
        reference: String,
        devise: String = "XAF"
    ): Bitmap {
        val payload = "VANELLE|DEMANDE_PAIEMENT|NOM=${nom.trim()}|MONTANT=${montant}|DEVISE=$devise|REFERENCE=${reference.trim()}"
        val matrix: BitMatrix = MultiFormatWriter().encode(payload, BarcodeFormat.QR_CODE, 900, 900)
        val bitmap = Bitmap.createBitmap(900, 900, Bitmap.Config.ARGB_8888)
        for (x in 0 until 900) for (y in 0 until 900) {
            bitmap.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
        return bitmap
    }
}
