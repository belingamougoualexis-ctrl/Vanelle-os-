package com.vanelle.relance.ui.screens

import android.Manifest
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vanelle.relance.data.Client
import com.vanelle.relance.data.CanalRelance
import com.vanelle.relance.data.ClientViewModel
import com.vanelle.relance.data.StatutDette
import com.vanelle.relance.utils.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

enum class FiltreClient { TOUS, EN_COURS, EN_RETARD, PAYES }
enum class TriClient { ECHEANCE, MONTANT, NOM, RELANCES }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RelanceScreen(viewModel: ClientViewModel = viewModel()) {
    val context = LocalContext.current
    val clients by viewModel.tousLesClients.collectAsState(initial = emptyList())
    var afficherAjout by remember { mutableStateOf(false) }
    var clientAEditer by remember { mutableStateOf<Client?>(null) }
    var recherche by remember { mutableStateOf("") }
    var filtre by remember { mutableStateOf(FiltreClient.TOUS) }
    var tri by remember { mutableStateOf(TriClient.ECHEANCE) }
    var afficherImportContacts by remember { mutableStateOf(false) }
    var clientAConfirmerPaye by remember { mutableStateOf<Client?>(null) }
    var menuTriOuvert by remember { mutableStateOf(false) }
    var modeCampagne by remember { mutableStateOf(false) }
    var selectionCampagne by remember { mutableStateOf(setOf<Long>()) }

    var permissionADemander by remember { mutableStateOf<String?>(null) }
    var actionApresPermission by remember { mutableStateOf<(() -> Unit)?>(null) }

    val launcherPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { accordee ->
        if (accordee) actionApresPermission?.invoke()
        else Toast.makeText(context, "Permission refusée. Activez-la dans Réglages.", Toast.LENGTH_LONG).show()
        permissionADemander = null
        actionApresPermission = null
    }

    fun demanderPermissionSiBesoin(permission: String, action: () -> Unit) {
        if (PermissionHelper.estAccordee(context, permission)) action()
        else {
            permissionADemander = permission
            actionApresPermission = action
        }
    }

    val clientsFiltres = remember(clients, recherche, filtre, tri) {
        clients
            .filter { client ->
                when (filtre) {
                    FiltreClient.TOUS -> true
                    FiltreClient.EN_COURS -> client.statut == StatutDette.EN_COURS
                    FiltreClient.EN_RETARD -> client.statut == StatutDette.EN_RETARD
                    FiltreClient.PAYES -> client.statut == StatutDette.PAYEE
                }
            }
            .filter { client ->
                if (recherche.isBlank()) true
                else client.nom.contains(recherche, ignoreCase = true) ||
                        client.telephone.contains(recherche.filter { it.isDigit() })
            }
            .let { liste ->
                when (tri) {
                    TriClient.ECHEANCE -> liste.sortedBy { it.dateEcheance }
                    TriClient.MONTANT -> liste.sortedByDescending { it.montant }
                    TriClient.NOM -> liste.sortedBy { it.nom.lowercase(Locale.ROOT) }
                    TriClient.RELANCES -> liste.sortedByDescending { it.nombreRelances }
                }
            }
    }

    val compteurs = remember(clients) {
        mapOf(
            FiltreClient.TOUS to clients.size,
            FiltreClient.EN_COURS to clients.count { it.statut == StatutDette.EN_COURS },
            FiltreClient.EN_RETARD to clients.count { it.statut == StatutDette.EN_RETARD },
            FiltreClient.PAYES to clients.count { it.statut == StatutDette.PAYEE }
        )
    }

    fun exporterListe() {
        if (clients.isEmpty()) {
            Toast.makeText(context, "Aucun client à exporter", Toast.LENGTH_SHORT).show()
            return
        }
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
        val sb = StringBuilder()
        sb.appendLine("=== Vanelle Relance — Liste des clients ===")
        sb.appendLine("Exporté le ${dateFormat.format(Date())}")
        sb.appendLine()
        clients.forEach { c ->
            val statut = when (c.statut) {
                StatutDette.PAYEE -> "Payé"
                StatutDette.EN_RETARD -> "En retard"
                StatutDette.EN_COURS -> "En cours"
            }
            sb.appendLine("• ${c.nom}")
            sb.appendLine("  Tél: ${PhoneUtils.formaterAffichage(c.telephone)}")
            sb.appendLine("  Montant: ${"%,.0f".format(c.montant).replace(",", " ")} FCFA")
            sb.appendLine("  Échéance: ${SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(c.dateEcheance))} — $statut")
            if (c.nombreRelances > 0) sb.appendLine("  Relances: ${c.nombreRelances}")
            if (c.note.isNotBlank()) sb.appendLine("  Note: ${c.note}")
            sb.appendLine()
        }
        val totalDu = clients.filter { it.statut != StatutDette.PAYEE }.sumOf { it.montant }
        val totalRecupere = clients.filter { it.statut == StatutDette.PAYEE }.sumOf { it.montant }
        sb.appendLine("────────────────────────")
        sb.appendLine("Total encore dû : ${"%,.0f".format(totalDu).replace(",", " ")} FCFA")
        sb.appendLine("Total récupéré  : ${"%,.0f".format(totalRecupere).replace(",", " ")} FCFA")

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Vanelle Relance — Export clients")
            putExtra(Intent.EXTRA_TEXT, sb.toString())
        }
        context.startActivity(Intent.createChooser(intent, "Partager la liste"))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Relance") },
                actions = {
                    IconButton(onClick = {
                        demanderPermissionSiBesoin(Manifest.permission.READ_CONTACTS) {
                            afficherImportContacts = true
                        }
                    }) {
                        Icon(Icons.Default.Contacts, contentDescription = "Importer un contact")
                    }
                    Box {
                        IconButton(onClick = { menuTriOuvert = true }) {
                            Icon(Icons.Default.Sort, contentDescription = "Trier")
                        }
                        DropdownMenu(expanded = menuTriOuvert, onDismissRequest = { menuTriOuvert = false }) {
                            DropdownMenuItem(text = { Text("Par échéance") }, onClick = { tri = TriClient.ECHEANCE; menuTriOuvert = false })
                            DropdownMenuItem(text = { Text("Par montant") }, onClick = { tri = TriClient.MONTANT; menuTriOuvert = false })
                            DropdownMenuItem(text = { Text("Par nom") }, onClick = { tri = TriClient.NOM; menuTriOuvert = false })
                            DropdownMenuItem(text = { Text("Par nb relances") }, onClick = { tri = TriClient.RELANCES; menuTriOuvert = false })
                        }
                    }
                    IconButton(onClick = {
                        modeCampagne = !modeCampagne
                        if (!modeCampagne) selectionCampagne = emptySet()
                    }) {
                        Icon(Icons.Default.Send, contentDescription = "Campagne de masse")
                    }
                    IconButton(onClick = { exporterListe() }) {
                        Icon(Icons.Default.Share, contentDescription = "Exporter")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { afficherAjout = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ajouter")
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value = recherche,
                onValueChange = { recherche = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                placeholder = { Text("Rechercher un client…") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = {
                    if (recherche.isNotEmpty()) {
                        IconButton(onClick = { recherche = "" }) {
                            Icon(Icons.Default.Clear, "Effacer")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FiltreChip("Tous (${compteurs[FiltreClient.TOUS]})", filtre == FiltreClient.TOUS) { filtre = FiltreClient.TOUS }
                FiltreChip("En cours (${compteurs[FiltreClient.EN_COURS]})", filtre == FiltreClient.EN_COURS) { filtre = FiltreClient.EN_COURS }
                FiltreChip("En retard (${compteurs[FiltreClient.EN_RETARD]})", filtre == FiltreClient.EN_RETARD) { filtre = FiltreClient.EN_RETARD }
                FiltreChip("Payés (${compteurs[FiltreClient.PAYES]})", filtre == FiltreClient.PAYES) { filtre = FiltreClient.PAYES }
            }


            // Barre campagne de masse
            if (modeCampagne) {
                Surface(color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 8.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            "${selectionCampagne.size} sélectionné(s)",
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = {
                            val cibles = clientsFiltres.filter { it.id in selectionCampagne && it.statut != StatutDette.PAYEE }
                            cibles.forEach { c ->
                                if (SmsHelper.permissionAccordee(context)) {
                                    if (viewModel.peutRelancer(c)) {
                                    if (SmsHelper.envoyer(context, c, c.nombreRelances)) {
                                        viewModel.enregistrerRelanceSiAutorisee(c)
                                        HistoriqueHelper.enregistrer(context, "CAMPAGNE_SMS", c.nom, "Relance masse")
                                    }
                                }
                                }
                            }
                            modeCampagne = false
                            selectionCampagne = emptySet()
                        }) { Text("SMS masse") }
                        TextButton(onClick = {
                            modeCampagne = false
                            selectionCampagne = emptySet()
                        }) { Text("Annuler") }
                    }
                }
            }

            if (clientsFiltres.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            if (recherche.isBlank() && filtre == FiltreClient.TOUS) Icons.Default.Person else Icons.Default.Search,
                            null, Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                        )
                        Spacer(Modifier.height(16.dp))
                        Text(
                            when {
                                recherche.isNotBlank() -> "Aucun résultat pour « $recherche »"
                                filtre != FiltreClient.TOUS -> "Aucun client dans ce filtre"
                                else -> "Aucun client pour l'instant.\nAppuie sur + pour en ajouter un."
                            },
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(clientsFiltres, key = { it.id }) { client ->
                        if (modeCampagne && client.statut != StatutDette.PAYEE) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = client.id in selectionCampagne,
                                    onCheckedChange = { checked ->
                                        selectionCampagne = if (checked) selectionCampagne + client.id
                                        else selectionCampagne - client.id
                                    }
                                )
                                Box(Modifier.weight(1f)) {
                                    CarteClient(
                                        client = client,
                                        onSms = {},
                                        onWhatsApp = {},
                                        onEmail = {},
                                        onAppel = {},
                                        onPaye = {},
                                        onReouvrir = {},
                                        onEditer = {},
                                        onSupprimer = {}
                                    )

                                }
                            }
                        } else {
                        CarteClient(
                            client = client,
                            onSms = {
                                demanderPermissionSiBesoin(Manifest.permission.SEND_SMS) {
                                    if (SmsHelper.envoyer(context, client, client.nombreRelances)) {
                                        viewModel.enregistrerRelanceSiAutorisee(client)
                                        HistoriqueHelper.enregistrer(context, "SMS", client.nom, "Relance SMS")
                                    } else Toast.makeText(context, "Échec de l'envoi du SMS", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onWhatsApp = {
                                if (!AutomationHelper.serviceActive()) {
                                    Toast.makeText(context, "Activez le service d'accessibilité Vanelle dans Paramètres > Accessibilité.", Toast.LENGTH_LONG).show()
                                    AutomationHelper.openAccessibilitySettings(context)
                                } else {
                                    val message = MessageHelper.genererMessageRelance(context, client, client.nombreRelances)
                                    if (AutomationHelper.startWhatsApp(context, client, message)) {
                                        viewModel.enregistrerRelanceSiAutorisee(client)
                                        HistoriqueHelper.enregistrer(context, "WhatsApp", client.nom, "Envoi automatique via accessibilité")
                                    } else Toast.makeText(context, "WhatsApp non installé ou numéro invalide", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onEmail = {
                                if (client.email.isBlank()) {
                                    Toast.makeText(context, "Ajoutez l'e-mail du client dans Modifier.", Toast.LENGTH_LONG).show()
                                } else if (!AutomationHelper.serviceActive()) {
                                    Toast.makeText(context, "Activez le service d'accessibilité Vanelle dans Paramètres > Accessibilité.", Toast.LENGTH_LONG).show()
                                    AutomationHelper.openAccessibilitySettings(context)
                                } else {
                                    val body = MessageHelper.genererMessageRelance(context, client, client.nombreRelances)
                                    if (AutomationHelper.startEmail(context, client, "Relance de paiement", body)) {
                                        viewModel.enregistrerRelanceSiAutorisee(client)
                                        HistoriqueHelper.enregistrer(context, "EMAIL", client.nom, "Envoi automatique via accessibilité")
                                    } else Toast.makeText(context, "Gmail non disponible ou e-mail invalide", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onAppel = {
                                demanderPermissionSiBesoin(Manifest.permission.CALL_PHONE) {
                                    CallHelper.appeler(context, client)
                                    viewModel.enregistrerRelanceSiAutorisee(client)
                                    HistoriqueHelper.enregistrer(context, "APPEL", client.nom, "Appel de relance")
                                }
                            },
                            onPaye = { clientAConfirmerPaye = client },
                            onReouvrir = { viewModel.marquerEnCours(client) },
                            onEditer = { clientAEditer = client },
                            onSupprimer = { viewModel.supprimer(client) }
                        )
                        }
                    }
                }
            }
        }
    }

    if (afficherAjout) {
        DialogueClient(null, { afficherAjout = false }) { client ->
            // Anti-doublon simple
            val existe = clients.any {
                it.telephone == client.telephone || it.nom.equals(client.nom, ignoreCase = true)
            }
            if (existe) {
                Toast.makeText(context, "Un client similaire existe déjà", Toast.LENGTH_LONG).show()
            }
            viewModel.ajouter(client)
            afficherAjout = false
        }
    }

    clientAEditer?.let { client ->
        DialogueClient(client, { clientAEditer = null }) { clientModifie ->
            if (client.id == 0L) {
                viewModel.ajouter(clientModifie.copy(id = 0))
            } else {
                viewModel.mettreAJour(clientModifie)
            }
            clientAEditer = null
        }
    }

    clientAConfirmerPaye?.let { client ->
        AlertDialog(
            onDismissRequest = { clientAConfirmerPaye = null },
            icon = { Icon(Icons.Default.CheckCircle, null) },
            title = { Text("Marquer comme payé ?") },
            text = { Text(if (PreferencesHelper(context).modePudique) "Confirmer que ${client.nom} a réglé le montant ?" else "Confirmer que ${client.nom} a réglé les ${"%,.0f".format(client.montant).replace(",", " ")} FCFA ?") },
            confirmButton = {
                Button(onClick = {
                    viewModel.marquerPaye(client)
                    HistoriqueHelper.enregistrer(context, "PAYE", client.nom, "Montant ${client.montant}")
                    try {
                        context.startActivity(Intent.createChooser(RecuHelper.intentPartage(client), "Partager le reçu"))
                    } catch (_: Exception) { }
                    clientAConfirmerPaye = null
                }) { Text("Oui, payé") }
            },
            dismissButton = { TextButton(onClick = { clientAConfirmerPaye = null }) { Text("Annuler") } }
        )
    }

    if (afficherImportContacts) {
        DialogueImportContacts(
            onDismiss = { afficherImportContacts = false },
            onPreRemplir = { contact ->
                afficherImportContacts = false
                clientAEditer = Client(
                    nom = contact.nom,
                    telephone = contact.telephone.filter { it.isDigit() },
                    montant = 0.0,
                    dateEcheance = System.currentTimeMillis() + 7L * 24 * 60 * 60 * 1000
                )
            }
        )
    }

    permissionADemander?.let { perm ->
        AlertDialog(
            onDismissRequest = { permissionADemander = null; actionApresPermission = null },
            icon = { Icon(Icons.Default.Security, null) },
            title = { Text("Autorisation ${PermissionHelper.titrePermission(perm)}") },
            text = { Text(PermissionHelper.messageRaison(perm) + "\n\nSans cette autorisation, cette fonctionnalité ne pourra pas fonctionner.") },
            confirmButton = { Button(onClick = { launcherPermission.launch(perm) }) { Text("Autoriser") } },
            dismissButton = {
                TextButton(onClick = { permissionADemander = null; actionApresPermission = null }) { Text("Plus tard") }
            }
        )
    }
}

@Composable
private fun FiltreChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        leadingIcon = if (selected) {{ Icon(Icons.Default.Check, null, Modifier.size(16.dp)) }} else null
    )
}

@Composable
fun CarteClient(
    client: Client,
    onSms: () -> Unit,
    onWhatsApp: () -> Unit,
    onEmail: () -> Unit,
    onAppel: () -> Unit,
    onPaye: () -> Unit,
    onReouvrir: () -> Unit,
    onEditer: () -> Unit,
    onSupprimer: () -> Unit
) {
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE) }
    var confirmerSuppression by remember { mutableStateOf(false) }

    val dernierContactTexte = client.dernierContact?.let {
        val jours = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - it)
        when {
            jours == 0L -> "Dernier contact : aujourd'hui"
            jours == 1L -> "Dernier contact : hier"
            else -> "Dernier contact : il y a $jours jours"
        }
    } ?: "Jamais contacté"

    ElevatedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(client.nom, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(PhoneUtils.formaterAffichage(client.telephone), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                BadgeStatut(client.statut)
            }
            // Score de risque intelligent
            val risque = RiskScore.calculer(client)
            if (client.statut != StatutDette.PAYEE) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "Risque ${risque.niveau.label} · ${risque.detail}",
                    style = MaterialTheme.typography.labelSmall,
                    color = RiskScore.couleur(risque.niveau),
                    fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                MoneyFormatter.format(context, client.montant) + " — échéance " + dateFormat.format(Date(client.dateEcheance)),
                style = MaterialTheme.typography.bodyMedium
            )
            if (client.nombreRelances > 0) {
                Text("${client.nombreRelances} relance(s) — $dernierContactTexte", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
            } else {
                Text(dernierContactTexte, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (client.note.isNotBlank()) {
                Text("📝 ${client.note}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (client.statut != StatutDette.PAYEE) {
                    FilledTonalIconButton(onClick = onSms) { Icon(Icons.Default.Sms, "SMS") }
                    FilledTonalIconButton(onClick = onWhatsApp) { Icon(Icons.Default.Chat, "WhatsApp") }
                    FilledTonalIconButton(onClick = onEmail) { Icon(Icons.Default.Email, "E-mail") }
                    FilledTonalIconButton(onClick = onAppel) { Icon(Icons.Default.Call, "Appeler") }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onPaye) { Text("Payé") }
                } else {
                    TextButton(onClick = onReouvrir) { Text("Réouvrir") }
                    Spacer(Modifier.weight(1f))
                }
                IconButton(onClick = onEditer) { Icon(Icons.Default.Edit, "Modifier") }
                IconButton(onClick = { confirmerSuppression = true }) {
                    Icon(Icons.Default.Delete, "Supprimer", tint = MaterialTheme.colorScheme.error)
                }
            if (client.statut != StatutDette.PAYEE) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "Toutes les relances sont automatiques. Choisissez le canal à la création : WhatsApp, SMS ou Gmail. WhatsApp/Gmail nécessitent le Service d’Accessibilité activé volontairement.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            }
        }
    }

    if (confirmerSuppression) {
        AlertDialog(
            onDismissRequest = { confirmerSuppression = false },
            title = { Text("Supprimer ${client.nom} ?") },
            text = { Text("Cette action est définitive.") },
            confirmButton = {
                TextButton(onClick = { onSupprimer(); confirmerSuppression = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { confirmerSuppression = false }) { Text("Annuler") } }
        )
    }
}

@Composable
fun BadgeStatut(statut: StatutDette) {
    val (texte, couleur) = when (statut) {
        StatutDette.PAYEE -> "Payé" to MaterialTheme.colorScheme.primary
        StatutDette.EN_RETARD -> "En retard" to MaterialTheme.colorScheme.error
        StatutDette.EN_COURS -> "En cours" to MaterialTheme.colorScheme.tertiary
    }
    AssistChip(onClick = {}, label = { Text(texte) }, colors = AssistChipDefaults.assistChipColors(labelColor = couleur))
}

@Composable
fun DialogueImportContacts(onDismiss: () -> Unit, onPreRemplir: (ContactSimple) -> Unit) {
    val context = LocalContext.current
    var contacts by remember { mutableStateOf<List<ContactSimple>>(emptyList()) }
    var rechercheContact by remember { mutableStateOf("") }
    var chargement by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        contacts = ContactsHelper.chargerContacts(context)
        chargement = false
    }

    val contactsFiltres = remember(contacts, rechercheContact) {
        if (rechercheContact.isBlank()) contacts
        else contacts.filter {
            it.nom.contains(rechercheContact, ignoreCase = true) ||
                    it.telephone.contains(rechercheContact.filter { c -> c.isDigit() })
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Importer un contact", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(
                    value = rechercheContact,
                    onValueChange = { rechercheContact = it },
                    placeholder = { Text("Rechercher…") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                if (chargement) {
                    Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else if (contactsFiltres.isEmpty()) {
                    Text("Aucun contact trouvé.\nVérifiez la permission Contacts.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    LazyColumn(Modifier.heightIn(max = 350.dp)) {
                        items(contactsFiltres) { contact ->
                            ListItem(
                                headlineContent = { Text(contact.nom) },
                                supportingContent = { Text(contact.telephone) },
                                leadingContent = { Icon(Icons.Default.Person, null) },
                                modifier = Modifier.clickable { onPreRemplir(contact) }
                            )
                            HorizontalDivider()
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DialogueClient(
    clientInitial: Client?,
    onDismiss: () -> Unit,
    onValider: (Client) -> Unit
) {
    val estEdition = clientInitial != null && clientInitial.id != 0L
    val estPreRempli = clientInitial != null && clientInitial.id == 0L

    var nom by remember { mutableStateOf(clientInitial?.nom ?: "") }
    var paysSelectionne by remember {
        mutableStateOf(
            clientInitial?.telephone?.let { tel ->
                PhoneUtils.detecterPays(tel) ?: PhoneUtils.paysParDefaut()
            } ?: PhoneUtils.paysParDefaut()
        )
    }
    var numeroLocal by remember {
        mutableStateOf(
            clientInitial?.telephone?.let { tel ->
                val pays = PhoneUtils.detecterPays(tel)
                if (pays != null && pays.indicatif.isNotEmpty() && tel.startsWith(pays.indicatif)) {
                    tel.removePrefix(pays.indicatif)
                } else tel.filter { it.isDigit() }
            } ?: ""
        )
    }
    var montant by remember {
        mutableStateOf(
            clientInitial?.montant?.takeIf { it > 0 }?.let {
                "%,.0f".format(it).replace(",", " ").replace(" ", "")
            } ?: ""
        )
    }
    var joursEcheance by remember {
        mutableStateOf(
            if (clientInitial != null && clientInitial.id != 0L) {
                val joursRestants = ((clientInitial.dateEcheance - System.currentTimeMillis()) / (24 * 60 * 60 * 1000)).toInt()
                maxOf(0, joursRestants).toString()
            } else "7"
        )
    }
    var note by remember { mutableStateOf(clientInitial?.note ?: "") }
    var email by remember { mutableStateOf(clientInitial?.email ?: "") }
    var canalRelance by remember { mutableStateOf(clientInitial?.canalRelance ?: CanalRelance.SMS) }
    var menuCanalOuvert by remember { mutableStateOf(false) }
    var menuPaysOuvert by remember { mutableStateOf(false) }
    var erreur by remember { mutableStateOf<String?>(null) }
    var avertissement by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when {
                    estEdition -> "Modifier le client"
                    estPreRempli -> "Nouveau client (depuis contact)"
                    else -> "Nouveau client"
                },
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = nom, onValueChange = { nom = it },
                    label = { Text("Nom du client") }, singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Person, null) },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Téléphone (format international)", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedCard(
                        modifier = Modifier.clickable { menuPaysOuvert = true }.height(56.dp),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Box(Modifier.fillMaxHeight().padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
                            Text("${paysSelectionne.drapeau} +${paysSelectionne.indicatif.ifEmpty { "?" }}", style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                    DropdownMenu(expanded = menuPaysOuvert, onDismissRequest = { menuPaysOuvert = false }) {
                        PhoneUtils.paysSupportes.forEach { pays ->
                            DropdownMenuItem(
                                text = { Text("${pays.drapeau}  ${pays.nom}  (+${pays.indicatif.ifEmpty { "…" }})") },
                                onClick = { paysSelectionne = pays; menuPaysOuvert = false; erreur = null; avertissement = null }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = numeroLocal,
                        onValueChange = { numeroLocal = it; erreur = null; avertissement = null },
                        label = { Text("Numéro") },
                        placeholder = { Text(paysSelectionne.exempleLocal) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = montant,
                    onValueChange = { montant = it.filter { c -> c.isDigit() || c == '.' || c == ',' } },
                    label = { Text("Montant dû (FCFA)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    leadingIcon = { Icon(Icons.Default.AttachMoney, null) },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = joursEcheance,
                    onValueChange = { joursEcheance = it.filter { c -> c.isDigit() } },
                    label = { Text(if (estEdition) "Jours restants jusqu'à l'échéance" else "Échéance dans (jours)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    leadingIcon = { Icon(Icons.Default.CalendarToday, null) },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email, onValueChange = { email = it },
                    label = { Text("E-mail (optionnel)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    leadingIcon = { Icon(Icons.Default.Email, null) },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Canal de relance automatique", style = MaterialTheme.typography.labelMedium)
                Box {
                    OutlinedButton(
                        onClick = { menuCanalOuvert = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(when (canalRelance) {
                            CanalRelance.WHATSAPP -> "WhatsApp"
                            CanalRelance.SMS -> "SMS"
                            CanalRelance.GMAIL -> "Gmail"
                        })
                    }
                    DropdownMenu(
                        expanded = menuCanalOuvert,
                        onDismissRequest = { menuCanalOuvert = false }
                    ) {
                        DropdownMenuItem(text = { Text("WhatsApp — envoi automatique") }, onClick = { canalRelance = CanalRelance.WHATSAPP; menuCanalOuvert = false })
                        DropdownMenuItem(text = { Text("SMS — envoi automatique") }, onClick = { canalRelance = CanalRelance.SMS; menuCanalOuvert = false })
                        DropdownMenuItem(text = { Text("Gmail — envoi automatique") }, onClick = { canalRelance = CanalRelance.GMAIL; menuCanalOuvert = false })
                    }
                }
                Text(
                    when (canalRelance) {
                        CanalRelance.WHATSAPP -> "WhatsApp sera envoyé automatiquement après activation du Service d’Accessibilité."
                        CanalRelance.SMS -> "Le SMS sera envoyé automatiquement depuis la SIM du téléphone."
                        CanalRelance.GMAIL -> "Gmail sera envoyé automatiquement après activation du Service d’Accessibilité et si une adresse e-mail est renseignée."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = note, onValueChange = { note = it },
                    label = { Text("Note (optionnel)") }, maxLines = 2,
                    leadingIcon = { Icon(Icons.Default.Notes, null) },
                    modifier = Modifier.fillMaxWidth()
                )

                erreur?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                avertissement?.let { Text(it, color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val montantVal = montant.replace(",", ".").replace(" ", "").toDoubleOrNull()
                val jours = joursEcheance.toLongOrNull() ?: 7L
                val numeroComplet = PhoneUtils.construireNumeroInternational(paysSelectionne.indicatif, numeroLocal)

                val errNum = PhoneUtils.validerNumero(paysSelectionne, numeroLocal)
                val avert = PhoneUtils.avertissementPaysInconnu(paysSelectionne, numeroComplet)

                when {
                    nom.isBlank() -> erreur = "Le nom est obligatoire."
                    errNum != null -> erreur = errNum
                    montantVal == null || montantVal <= 0 -> erreur = "Indiquez un montant valide."
                    else -> {
                        if (avert != null) {
                            // On affiche l'avertissement mais on laisse l'utilisateur confirmer en cliquant une 2e fois
                            if (avertissement == null) {
                                avertissement = avert + "\nAppuyez encore sur Ajouter pour confirmer."
                                return@Button
                            }
                        }
                        val dateEcheance = System.currentTimeMillis() + jours * 24 * 60 * 60 * 1000
                        val base = clientInitial ?: Client(nom = "", telephone = "", montant = 0.0, dateEcheance = 0L)
                        onValider(
                            base.copy(
                                nom = nom.trim(),
                                telephone = numeroComplet,
                                montant = montantVal,
                                dateEcheance = dateEcheance,
                                email = email.trim(),
                                note = note.trim(),
                                canalRelance = canalRelance
                            )
                        )
                    }
                }
            }) { Text(if (estEdition) "Enregistrer" else "Ajouter") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}
