package com.vanelle.relance.utils

import android.content.Context
import java.util.Locale

object MoneyFormatter {
    fun format(context: Context, amount: Double, currency: String = "FCFA"): String {
        val prefs = PreferencesHelper(context)
        return if (prefs.modePudique) "•••••• $currency" else "%,.0f".format(Locale.FRANCE, amount).replace(",", " ") + " $currency"
    }
    fun hidden(context: Context, amount: Double, currency: String = "FCFA"): String = format(context, amount, currency)
}
