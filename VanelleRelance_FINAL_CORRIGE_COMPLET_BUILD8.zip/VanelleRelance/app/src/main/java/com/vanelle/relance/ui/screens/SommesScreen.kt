package com.vanelle.relance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.vanelle.relance.utils.MoneyFormatter
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vanelle.relance.data.ClientViewModel
import com.vanelle.relance.data.StatutDette

@Composable
fun SommesScreen(viewModel: ClientViewModel = viewModel()) {
    val context = LocalContext.current
    val totalDu by viewModel.totalDu.collectAsState(initial = 0.0)
    val totalRecupere by viewModel.totalRecupere.collectAsState(initial = 0.0)
    val clients by viewModel.tousLesClients.collectAsState(initial = emptyList())

    val nbEnRetard = clients.count { it.statut == StatutDette.EN_RETARD }
    val total = totalDu + totalRecupere
    val tauxRecouvrement = if (total > 0) (totalRecupere / total * 100) else 0.0

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            "Vue d'ensemble",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        CarteChiffre(
            titre = "Encore à récupérer",
            valeur = MoneyFormatter.format(context, totalDu),
            icone = Icons.Default.AccountBalanceWallet,
            couleur = MaterialTheme.colorScheme.error
        )
        CarteChiffre(
            titre = "Déjà récupéré",
            valeur = MoneyFormatter.format(context, totalRecupere),
            icone = Icons.Default.CheckCircle,
            couleur = MaterialTheme.colorScheme.primary
        )
        CarteChiffre(
            titre = "Taux de recouvrement",
            valeur = "${"%.0f".format(tauxRecouvrement)} %",
            icone = Icons.Default.TrendingUp,
            couleur = MaterialTheme.colorScheme.tertiary
        )

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Résumé", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("${clients.size} client(s) au total")
                Text("$nbEnRetard en retard de paiement")
                Text("${clients.count { it.statut == StatutDette.PAYEE }} payé(s)")
                Text("${clients.count { it.statut == StatutDette.EN_COURS }} en cours")
            }
        }
    }
}

@Composable
private fun CarteChiffre(
    titre: String,
    valeur: String,
    icone: ImageVector,
    couleur: androidx.compose.ui.graphics.Color
) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icone, contentDescription = null, tint = couleur, modifier = Modifier.size(36.dp))
            Spacer(Modifier.width(16.dp))
            Column {
                Text(titre, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(valeur, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = couleur)
            }
        }
    }
}
