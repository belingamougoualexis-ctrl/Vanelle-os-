package com.vanelle.relance.ui.screens

import android.graphics.Bitmap
import android.os.Environment
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.vanelle.relance.data.Client
import com.vanelle.relance.utils.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

@Composable
fun OutilsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var from by remember { mutableStateOf("XAF") }
    var to by remember { mutableStateOf("EUR") }
    var amount by remember { mutableStateOf("10000") }
    var result by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var rateInfo by remember { mutableStateOf("") }

    var qrNom by remember { mutableStateOf("") }
    var qrMontant by remember { mutableStateOf("10000") }
    var qrRef by remember { mutableStateOf("VNL-" + UUID.randomUUID().toString().take(8).uppercase()) }
    var qrBitmap by remember { mutableStateOf<Bitmap?>(null) }

    var debtNom by remember { mutableStateOf("") }
    var debtTel by remember { mutableStateOf("") }
    var debtMontant by remember { mutableStateOf("10000") }
    var debtRef by remember { mutableStateOf("DET-" + UUID.randomUUID().toString().take(8).uppercase()) }
    var signatureBitmap by remember { mutableStateOf<Bitmap?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text("Outils", style = MaterialTheme.typography.headlineSmall)

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row { Icon(Icons.Default.SwapHoriz, null); Spacer(Modifier.width(8.dp)); Text("Convertisseur de devises", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
                OutlinedTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, label = { Text("Montant") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(from, { from = it.uppercase().take(3) }, label = { Text("De") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(to, { to = it.uppercase().take(3) }, label = { Text("Vers") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Button(enabled = !loading, onClick = {
                    val value = amount.replace(",", ".").toDoubleOrNull()
                    if (value == null) { result = "Montant invalide"; return@Button }
                    loading = true
                    scope.launch {
                        val r = FrankfurterHelper.convert(context, value, from, to)
                        loading = false
                        r.onSuccess {
                            result = "%.2f %s".format(it.amount, it.to)
                            rateInfo = "Taux : %.8f • date : %s%s".format(it.rate, it.date, if (it.fromCache) " • hors connexion (cache)" else "")
                        }.onFailure { result = "Conversion indisponible : ${it.message ?: "erreur réseau"}"; rateInfo = "" }
                    }
                }) { Text(if (loading) "Chargement…" else "Convertir") }
                if (result.isNotBlank()) Text(result, style = MaterialTheme.typography.titleMedium)
                if (rateInfo.isNotBlank()) Text(rateInfo, style = MaterialTheme.typography.bodySmall)
                Text("Les taux Frankfurter sont des taux de référence, pas des cours de trading.", style = MaterialTheme.typography.bodySmall)
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row { Icon(Icons.Default.QrCode, null); Spacer(Modifier.width(8.dp)); Text("QR de demande de paiement", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
                OutlinedTextField(qrNom, { qrNom = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(qrMontant, { qrMontant = it }, label = { Text("Montant XAF") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(qrRef, { qrRef = it }, label = { Text("Référence") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val m = qrMontant.replace(",", ".").toDoubleOrNull()
                    if (qrNom.isBlank() || m == null || m <= 0) return@Button
                    qrBitmap = QrHelper.generatePaymentRequest(qrNom, m, qrRef)
                }) { Text("Générer le QR") }
                qrBitmap?.let { bmp ->
                    androidx.compose.foundation.Image(bitmap = bmp.asImageBitmap(), contentDescription = "QR de paiement", modifier = Modifier.fillMaxWidth().height(220.dp))
                    Text("QR lisible par un scanner : il encode une demande de paiement Vanelle. Il ne déclenche pas un paiement Mobile Money.", style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = {
                        val file = File(context.cacheDir, "qr_${qrRef}.png")
                        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                        val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                        val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "image/png"; putExtra(android.content.Intent.EXTRA_STREAM, uri); addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(android.content.Intent.createChooser(i, "Partager le QR"))
                    }) { Text("Partager le QR") }
                }
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row { Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text("Reconnaissance de dette PDF", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
                OutlinedTextField(debtNom, { debtNom = it }, label = { Text("Débiteur") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(debtTel, { debtTel = it }, label = { Text("Téléphone") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(debtMontant, { debtMontant = it }, label = { Text("Montant XAF") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(debtRef, { debtRef = it }, label = { Text("Référence") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("Signature du débiteur", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                SignaturePad(Modifier.fillMaxWidth().height(180.dp)) { signatureBitmap = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { signatureBitmap = null }) { Text("Effacer") }
                    Button(onClick = {
                        val m = debtMontant.replace(",", ".").toDoubleOrNull() ?: return@Button
                        if (debtNom.isBlank() || m <= 0) return@Button
                        val client = Client(nom = debtNom, telephone = debtTel, montant = m, dateEcheance = System.currentTimeMillis())
                        val file = PdfHelper.generateDebtAcknowledgement(context, client, debtRef, signatureBitmap)
                        PdfHelper.share(context, file)
                    }) { Text("Créer et partager le PDF") }
                }
                Text("La signature est insérée dans le PDF, mais le document n'est pas une certification électronique.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun SignaturePad(modifier: Modifier, onBitmapChanged: (Bitmap?) -> Unit) {
    val paths = remember { mutableStateListOf<Path>() }
    var current by remember { mutableStateOf<Path?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    Canvas(
        modifier.background(Color.White).pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { current = Path().apply { moveTo(it.x, it.y) }; current?.let(paths::add) },
                onDrag = { change, _ -> change.consume(); current?.lineTo(change.position.x, change.position.y); tick++ },
                onDragEnd = {
                    // Bitmap is rendered lazily by the button-triggered state update.
                    onBitmapChanged(renderPaths(paths, size.width.toInt(), size.height.toInt()))
                    current = null
                }
            )
        }
    ) {
        tick
        paths.forEach { drawPath(it, Color.Black, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f)) }
    }
}

private fun renderPaths(paths: List<Path>, width: Int, height: Int): Bitmap {
    val bitmap = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.BLACK
        style = android.graphics.Paint.Style.STROKE
        strokeWidth = 3f
        strokeCap = android.graphics.Paint.Cap.ROUND
    }
    paths.forEach { canvas.drawPath(it.asAndroidPath(), paint) }
    return bitmap
}
