package com.vanelle.relance.utils

import android.content.Context
import androidx.core.content.edit
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class EvenementHistorique(
    val timestamp: Long,
    val type: String,
    val clientNom: String,
    val detail: String
)

object HistoriqueHelper {

    private const val PREFS = "vanelle_historique"
    private const val KEY = "events"
    private const val MAX = 200

    fun enregistrer(context: Context, type: String, clientNom: String, detail: String = "") {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = try {
            JSONArray(prefs.getString(KEY, "[]"))
        } catch (_: Exception) {
            JSONArray()
        }
        val obj = JSONObject()
            .put("t", System.currentTimeMillis())
            .put("type", type)
            .put("nom", clientNom)
            .put("detail", detail)
        // prepend
        val nouveau = JSONArray()
        nouveau.put(obj)
        for (i in 0 until minOf(arr.length(), MAX - 1)) {
            nouveau.put(arr.get(i))
        }
        prefs.edit { putString(KEY, nouveau.toString()) }
    }

    fun lister(context: Context): List<EvenementHistorique> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = try {
            JSONArray(prefs.getString(KEY, "[]"))
        } catch (_: Exception) {
            return emptyList()
        }
        val list = mutableListOf<EvenementHistorique>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                EvenementHistorique(
                    timestamp = o.optLong("t"),
                    type = o.optString("type"),
                    clientNom = o.optString("nom"),
                    detail = o.optString("detail")
                )
            )
        }
        return list
    }

    fun effacer(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit { remove(KEY) }
    }

    fun formaterDate(ts: Long): String =
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(ts))
}
