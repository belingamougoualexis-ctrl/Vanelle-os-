package com.vanelle.relance.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.net.Uri
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.vanelle.relance.data.Client
import java.net.URLEncoder
import java.util.ArrayDeque

/**
 * Automatisation volontaire de l'action d'envoi dans les apps tierces.
 * L'utilisateur doit activer ce service lui-même dans Paramètres > Accessibilité.
 */
class VanelleAccessibilityService : AccessibilityService() {
    companion object {
        const val ACTION_SEND_WHATSAPP = "com.vanelle.relance.SEND_WHATSAPP"
        const val ACTION_SEND_EMAIL = "com.vanelle.relance.SEND_EMAIL"
        @Volatile var instance: VanelleAccessibilityService? = null
    }

    private data class Task(val type: String, val client: Client, val message: String, val subject: String = "")
    private val queue = ArrayDeque<Task>()
    private var activeTask: Task? = null
    private var clickInProgress = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val task = activeTask ?: return
        val packageName = event?.packageName?.toString() ?: return
        val expectedPackages = if (task.type == ACTION_SEND_WHATSAPP) setOf("com.whatsapp", "com.whatsapp.w4b") else setOf("com.google.android.gm")
        if (packageName !in expectedPackages) return
        if (clickInProgress) return
        val root = rootInActiveWindow ?: return
        val send = findClickable(root, listOf("Envoyer", "Send", "Envoyer le message", "Send message")) ?: return
        clickInProgress = true
        if (send.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            finishTask()
        } else {
            dispatchTap(send)
        }
    }

    override fun onInterrupt() {}

    fun queueWhatsApp(context: android.content.Context, client: Client, message: String) {
        queue.add(Task(ACTION_SEND_WHATSAPP, client, message))
        if (activeTask == null) startNext(context)
    }

    fun queueEmail(context: android.content.Context, client: Client, subject: String, body: String) {
        queue.add(Task(ACTION_SEND_EMAIL, client, body, subject))
        if (activeTask == null) startNext(context)
    }

    private fun startNext(context: android.content.Context) {
        if (queue.isEmpty()) {
            activeTask = null
            clickInProgress = false
            return
        }
        val task = queue.removeFirst()
        activeTask = task
        clickInProgress = false
        try {
            if (task.type == ACTION_SEND_WHATSAPP) {
                val phone = task.client.telephone.filter(Char::isDigit)
                val uri = Uri.parse("https://wa.me/$phone?text=${URLEncoder.encode(task.message, "UTF-8")}")
                context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("com.whatsapp")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            } else {
                context.startActivity(Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:${Uri.encode(task.client.email)}")
                    putExtra(Intent.EXTRA_SUBJECT, task.subject)
                    putExtra(Intent.EXTRA_TEXT, task.message)
                    setPackage("com.google.android.gm")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }
        } catch (_: Exception) {
            activeTask = null
            android.os.Handler(mainLooper).postDelayed({ startNext(context) }, 500)
        }
    }

    private fun finishTask() {
        activeTask = null
        clickInProgress = false
        android.os.Handler(mainLooper).postDelayed({ startNext(this) }, 900)
    }

    private fun dispatchTap(node: AccessibilityNodeInfo) {
        val bounds = android.graphics.Rect()
        node.getBoundsInScreen(bounds)
        if (bounds.isEmpty) { clickInProgress = false; return }
        val path = Path().apply { moveTo(bounds.exactCenterX(), bounds.exactCenterY()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { finishTask() }
            override fun onCancelled(gestureDescription: GestureDescription?) { clickInProgress = false }
        }, null)
    }

    private fun findClickable(root: AccessibilityNodeInfo, labels: List<String>): AccessibilityNodeInfo? {
        for (label in labels) {
            root.findAccessibilityNodeInfosByText(label).firstOrNull { it.isVisibleToUser && it.isEnabled }?.let { return it }
        }
        return findByContentDescription(root, labels)
    }

    private fun findByContentDescription(root: AccessibilityNodeInfo, labels: List<String>): AccessibilityNodeInfo? {
        val desc = root.contentDescription?.toString()?.lowercase() ?: ""
        if (root.isVisibleToUser && root.isEnabled && labels.any { desc.contains(it.lowercase()) }) return root
        for (i in 0 until root.childCount) {
            root.getChild(i)?.let { child -> findByContentDescription(child, labels)?.let { return it } }
        }
        return null
    }
}
