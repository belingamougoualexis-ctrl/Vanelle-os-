package com.vanelle.relance.utils

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.vanelle.relance.automation.VanelleAccessibilityService
import com.vanelle.relance.data.Client

object AutomationHelper {
    fun serviceActive(): Boolean = VanelleAccessibilityService.instance != null

    fun openAccessibilitySettings(context: Context) {
        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun startWhatsApp(context: Context, client: Client, message: String): Boolean {
        if (client.telephone.filter(Char::isDigit).length < 8) return false
        val service = VanelleAccessibilityService.instance ?: return false
        return try {
            service.queueWhatsApp(context, client, message)
            true
        } catch (_: Exception) { false }
    }

    fun startEmail(context: Context, client: Client, subject: String, body: String): Boolean {
        if (client.email.isBlank()) return false
        val service = VanelleAccessibilityService.instance ?: return false
        return try {
            service.queueEmail(context, client, subject, body)
            true
        } catch (_: Exception) { false }
    }
}
