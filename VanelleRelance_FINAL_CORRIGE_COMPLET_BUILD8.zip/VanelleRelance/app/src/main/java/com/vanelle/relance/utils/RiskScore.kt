package com.vanelle.relance.utils

import androidx.compose.ui.graphics.Color
import com.vanelle.relance.data.Client
import com.vanelle.relance.data.StatutDette
import java.util.concurrent.TimeUnit

enum class NiveauRisque(val label: String) {
    FAIBLE("Faible"),
    MOYEN("Moyen"),
    ELEVE("Élevé"),
    CRITIQUE("Critique")
}

data class ScoreRisque(
    val niveau: NiveauRisque,
    val points: Int,
    val detail: String
)

object RiskScore {

    fun calculer(client: Client, maintenant: Long = System.currentTimeMillis()): ScoreRisque {
        if (client.statut == StatutDette.PAYEE) {
            return ScoreRisque(NiveauRisque.FAIBLE, 0, "Dette réglée")
        }

        var points = 0
        val joursRetard = if (client.dateEcheance < maintenant) {
            TimeUnit.MILLISECONDS.toDays(maintenant - client.dateEcheance).toInt()
        } else 0

        points += when {
            joursRetard >= 60 -> 40
            joursRetard >= 30 -> 30
            joursRetard >= 14 -> 20
            joursRetard >= 1 -> 10
            else -> 0
        }
        points += when {
            client.nombreRelances >= 5 -> 25
            client.nombreRelances >= 3 -> 15
            client.nombreRelances >= 1 -> 5
            else -> 0
        }
        val joursSansContact = client.dernierContact?.let {
            TimeUnit.MILLISECONDS.toDays(maintenant - it).toInt()
        } ?: 99
        points += when {
            joursSansContact >= 21 -> 20
            joursSansContact >= 14 -> 12
            joursSansContact >= 7 -> 6
            else -> 0
        }
        if (client.montant >= 500_000) points += 10
        else if (client.montant >= 100_000) points += 5

        val niveau = when {
            points >= 55 -> NiveauRisque.CRITIQUE
            points >= 35 -> NiveauRisque.ELEVE
            points >= 15 -> NiveauRisque.MOYEN
            else -> NiveauRisque.FAIBLE
        }
        val detail = buildString {
            if (joursRetard > 0) append("${joursRetard}j de retard")
            if (client.nombreRelances > 0) {
                if (isNotEmpty()) append(" · ")
                append("${client.nombreRelances} relance(s)")
            }
            if (isEmpty()) append("Situation stable")
        }
        return ScoreRisque(niveau, points, detail)
    }

    fun couleur(niveau: NiveauRisque): Color = when (niveau) {
        NiveauRisque.FAIBLE -> Color(0xFF2E7D32)
        NiveauRisque.MOYEN -> Color(0xFFF9A825)
        NiveauRisque.ELEVE -> Color(0xFFEF6C00)
        NiveauRisque.CRITIQUE -> Color(0xFFC62828)
    }
}
