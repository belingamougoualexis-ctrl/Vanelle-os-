package com.vanelle.relance.utils

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

data class ExchangeResult(
    val amount: Double,
    val rate: Double,
    val date: String,
    val from: String,
    val to: String,
    val fromCache: Boolean
)

object FrankfurterHelper {
    private const val BASE = "https://api.frankfurter.dev/v2"
    private const val XAF_PER_EUR = 655.957
    private const val PREFS = "frankfurter_cache"

    suspend fun convert(context: Context, amount: Double, from: String, to: String): Result<ExchangeResult> =
        withContext(Dispatchers.IO) {
            val f = from.uppercase(Locale.US)
            val t = to.uppercase(Locale.US)
            if (amount < 0 || f.length != 3 || t.length != 3) return@withContext Result.failure(IllegalArgumentException("Paramètres invalides"))
            if (f == t) return@withContext Result.success(ExchangeResult(amount, 1.0, "local", f, t, false))

            try {
                val (rate, date) = rate(context, f, t)
                saveCache(context, f, t, rate, date)
                Result.success(ExchangeResult(amount * rate, rate, date, f, t, false))
            } catch (e: Exception) {
                val cached = cachedRate(context, f, t)
                if (cached != null) {
                    val cachedAmount = cached.first.toDouble()
                    Result.success(ExchangeResult(amount * cachedAmount, cachedAmount, cached.second.toString(), f, t, true))
                } else Result.failure(e)
            }
        }

    private fun rate(context: Context, from: String, to: String): Pair<Double, String> {
        if (from == "XAF") {
            val eurToTarget = if (to == "EUR") 1.0 else fetchRate("EUR", to).first
            return (eurToTarget / XAF_PER_EUR) to fetchRateDate("EUR", to)
        }
        if (to == "XAF") {
            val baseToEur = if (from == "EUR") 1.0 else fetchRate(from, "EUR").first
            val date = if (from == "EUR") "référence EUR" else fetchRateDate(from, "EUR")
            return (baseToEur * XAF_PER_EUR) to date
        }
        return fetchRate(from, to)
    }

    private fun fetchRate(from: String, to: String): Pair<Double, String> {
        val conn = (URL("$BASE/rate/$from/$to").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("Accept", "application/json")
        }
        try {
            if (conn.responseCode !in 200..299) error("Frankfurter HTTP ${conn.responseCode}")
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val obj = JSONObject(body)
            val rate = obj.getDouble("rate")
            val date = obj.optString("date", "inconnu")
            return rate to date
        } finally { conn.disconnect() }
    }

    private fun fetchRateDate(from: String, to: String): String {
        return try { fetchRate(from, to).second } catch (_: Exception) { "inconnu" }
    }

    private fun cachedRate(context: Context, from: String, to: String): Pair<Double, String>? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val r = p.getFloat("$from:$to:rate", Float.NaN)
        if (r.isNaN()) return null
        return r.toDouble() to p.getString("$from:$to:date", "cache")!!
    }

    private fun saveCache(context: Context, from: String, to: String, rate: Double, date: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat("$from:$to:rate", rate.toFloat())
            .putString("$from:$to:date", date)
            .apply()
    }
}
