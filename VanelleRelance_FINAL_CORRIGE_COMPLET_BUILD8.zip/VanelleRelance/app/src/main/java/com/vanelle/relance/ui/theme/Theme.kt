package com.vanelle.relance.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Palette Vanelle — bleu / blanc (logo)
val VanelleBlue = Color(0xFF1A56DB)          // bleu principal
val VanelleBlueDark = Color(0xFF0B3A9E)      // bleu profond
val VanelleCyan = Color(0xFF06B6D4)          // cyan accent logo
val VanelleBlueSoft = Color(0xFFE8F1FF)      // fond bleu très clair
val VanelleWhite = Color(0xFFFFFFFF)
val VanelleText = Color(0xFF0F172A)          // texte foncé lisible
val VanelleTextMuted = Color(0xFF475569)     // texte secondaire
val VanelleBgDark = Color(0xFF0B1220)
val VanelleSurfaceDark = Color(0xFF152238)

private val LightColors = lightColorScheme(
    primary = VanelleBlue,
    onPrimary = VanelleWhite,
    primaryContainer = VanelleBlueSoft,
    onPrimaryContainer = VanelleBlueDark,
    secondary = VanelleCyan,
    onSecondary = VanelleWhite,
    secondaryContainer = Color(0xFFCFFAFE),
    onSecondaryContainer = Color(0xFF0E7490),
    tertiary = VanelleBlueDark,
    onTertiary = VanelleWhite,
    background = VanelleWhite,
    onBackground = VanelleText,
    surface = VanelleWhite,
    onSurface = VanelleText,
    surfaceVariant = VanelleBlueSoft,
    onSurfaceVariant = VanelleTextMuted,
    outline = Color(0xFF94A3B8),
    error = Color(0xFFDC2626),
    onError = VanelleWhite
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF60A5FA),
    onPrimary = Color(0xFF0B1220),
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = Color(0xFFDBEAFE),
    secondary = VanelleCyan,
    onSecondary = Color(0xFF0B1220),
    background = VanelleBgDark,
    onBackground = Color(0xFFF1F5F9),
    surface = VanelleSurfaceDark,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF1E293B),
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF64748B),
    error = Color(0xFFF87171),
    onError = Color(0xFF0B1220)
)

@Composable
fun VanelleRelanceTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
