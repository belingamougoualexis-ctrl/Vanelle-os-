package com.vanelle.relance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.vanelle.relance.utils.MoneyFormatter
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vanelle.relance.data.ClientViewModel
import com.vanelle.relance.utils.PhoneUtils
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@Composable
fun OubliesScreen(viewModel: ClientViewModel = viewModel()) {
    val context = LocalContext.current
    val clientsOublies by viewModel.clientsOublies().collectAsState(initial = emptyList())
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE) }

    Column(Modifier.fillMaxSize()) {
        if (clientsOublies.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.History,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                    )
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "Aucun client oublié.\nVous êtes à jour sur les relances !",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        "Clients sans contact depuis 21 jours ou plus",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
                items(clientsOublies, key = { it.id }) { client ->
                    val joursSansContact = client.dernierContact?.let {
                        TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - it)
                    } ?: -1L

                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Person,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(client.nom, fontWeight = FontWeight.Bold)
                                Text(
                                    PhoneUtils.formaterAffichage(client.telephone),
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    MoneyFormatter.format(context, client.montant),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    if (joursSansContact >= 0)
                                        "Dernier contact il y a $joursSansContact jour(s)"
                                    else
                                        "Jamais contacté",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
