package com.vanelle.relance.utils

import android.content.Context
import android.content.Intent
import com.vanelle.relance.data.Client
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object RecuHelper {

    fun genererTexte(client: Client): String {
        val df = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
        val montant = "%,.0f".format(client.montant).replace(",", " ")
        return buildString {
            appendLine("─── REÇU DE PAIEMENT ───")
            appendLine("Vanelle Relance")
            appendLine()
            appendLine("Client : ${client.nom}")
            appendLine("Téléphone : ${client.telephone}")
            appendLine("Montant réglé : $montant FCFA")
            appendLine("Date : ${df.format(Date())}")
            appendLine()
            appendLine("Statut : PAYÉ")
            appendLine("────────────────────────")
            appendLine("Document généré localement.")
        }
    }

    fun intentPartage(client: Client): Intent {
        return Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Reçu de paiement — ${client.nom}")
            putExtra(Intent.EXTRA_TEXT, genererTexte(client))
        }
    }
}
