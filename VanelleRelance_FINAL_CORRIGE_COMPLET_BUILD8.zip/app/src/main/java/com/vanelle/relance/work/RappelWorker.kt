package com.vanelle.relance.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.vanelle.relance.data.AppDatabase
import com.vanelle.relance.data.StatutDette
import com.vanelle.relance.utils.NotificationHelper
import com.vanelle.relance.utils.PreferencesHelper
import com.vanelle.relance.utils.AutomationHelper
import com.vanelle.relance.utils.MessageHelper
import com.vanelle.relance.utils.HistoriqueHelper
import kotlinx.coroutines.flow.first

class RappelWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val dao = AppDatabase.getInstance(applicationContext).clientDao()
            val maintenant = System.currentTimeMillis()
            val clients = dao.getTous().first()

            val nouveauxNoms = mutableListOf<String>()

            clients.forEach { client ->
                if (client.statut != StatutDette.PAYEE &&
                    client.statut != StatutDette.EN_RETARD &&
                    client.dateEcheance < maintenant
                ) {
                    dao.mettreAJour(client.copy(statut = StatutDette.EN_RETARD))
                    nouveauxNoms.add(client.nom)
                }
            }

            // Liste à jour après mises à jour
            val apres = dao.getTous().first()
            val enRetard = apres.filter { it.statut == StatutDette.EN_RETARD }
            if (enRetard.isEmpty()) return Result.success()

            // Priorité : nouveaux retards du jour, sinon rappel des existants
            val noms = if (nouveauxNoms.isNotEmpty()) nouveauxNoms else enRetard.map { it.nom }
            NotificationHelper.notifierClientsEnRetard(
                applicationContext,
                noms,
                enRetard.size
            )

            // Automatisation facultative : elle ne s'exécute que si l'utilisateur a activé
            // le Service d'Accessibilité et les canaux correspondants. Le délai de 48 h
            // est toujours vérifié avant de mettre une relance en file.
            val prefs = PreferencesHelper(applicationContext)
            val serviceActif = AutomationHelper.serviceActive()
            if (serviceActif) {
                enRetard.filter { it.statut == StatutDette.EN_RETARD &&
                        (prefs.relancesAutomatiquesWhatsApp || (prefs.relancesAutomatiquesEmail && it.email.isNotBlank())) &&
                        (it.dernierContact == null || maintenant - it.dernierContact >= java.util.concurrent.TimeUnit.HOURS.toMillis(48))
                }.forEach { client ->
                    val message = MessageHelper.genererMessageRelance(applicationContext, client, client.nombreRelances)
                    var queued = false
                    if (prefs.relancesAutomatiquesWhatsApp) {
                        queued = AutomationHelper.startWhatsApp(applicationContext, client, message) || queued
                        if (queued) HistoriqueHelper.enregistrer(applicationContext, "WhatsApp AUTO", client.nom, "Relance automatique via accessibilité")
                    }
                    if (prefs.relancesAutomatiquesEmail && client.email.isNotBlank()) {
                        val emailQueued = AutomationHelper.startEmail(applicationContext, client, "Relance de paiement", message)
                        queued = emailQueued || queued
                        if (emailQueued) HistoriqueHelper.enregistrer(applicationContext, "EMAIL AUTO", client.nom, "Relance automatique via accessibilité")
                    }
                    if (queued) dao.mettreAJour(client.copy(
                        nombreRelances = client.nombreRelances + 1,
                        dernierContact = maintenant
                    ))
                }
            }

            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
