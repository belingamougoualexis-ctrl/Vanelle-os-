package com.vanelle.android

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.ForegroundInfo

object DownloadNotifications {
    const val CHANNEL_ID = "vanelle_downloads"
    private const val CHANNEL_ID_DONE = "vanelle_downloads_done"
    const val MODEL_NOTIF_ID = 4101
    const val EMBED_NOTIF_ID = 4102
    private const val MODEL_DONE_NOTIF_ID = 4111
    private const val EMBED_DONE_NOTIF_ID = 4112

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val mgr = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (mgr.getNotificationChannel(CHANNEL_ID) == null) {
            mgr.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Téléchargements Vanelle",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Progression du téléchargement du moteur Vanelle"
                    setShowBadge(false)
                }
            )
        }
        if (mgr.getNotificationChannel(CHANNEL_ID_DONE) == null) {
            mgr.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID_DONE,
                    "Vanelle prête",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Prévient quand le moteur Vanelle a fini de télécharger"
                }
            )
        }
    }

    fun foregroundInfo(
        context: Context,
        notificationId: Int,
        title: String,
        progress: Int,
        indeterminate: Boolean = false
    ): ForegroundInfo {
        ensureChannel(context)
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(
                when {
                    indeterminate -> "Préparation…"
                    progress >= 100 -> "Terminé"
                    else -> "Téléchargement $progress %"
                }
            )
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOnlyAlertOnce(true)
            .setOngoing(progress < 100)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
        if (!indeterminate) {
            builder.setProgress(100, progress.coerceIn(0, 100), false)
        } else {
            builder.setProgress(0, 0, true)
        }
        val notification = builder.build()
        // Type dataSync requis Android 14+ ; constante compileSdk 34+, valeur ignorée en dessous.
        return if (Build.VERSION.SDK_INT >= 29) {
            @Suppress("InlinedApi")
            ForegroundInfo(
                notificationId,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            ForegroundInfo(notificationId, notification)
        }
    }

    /**
     * Notification de fin de téléchargement, distincte de la notification "foreground" ci-dessus.
     * Celle-ci n'est PAS liée au cycle de vie du Worker : elle reste affichée dans le volet de
     * notifications même une fois le téléchargement terminé et le service arrêté.
     */
    private fun notifyDone(context: Context, notificationId: Int, title: String, text: String) {
        ensureChannel(context)
        try {
            val notification = NotificationCompat.Builder(context, CHANNEL_ID_DONE)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setAutoCancel(true)
                .setOngoing(false)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()
            androidx.core.app.NotificationManagerCompat.from(context).notify(notificationId, notification)
        } catch (_: SecurityException) {
            // Permission de notification refusée par l'utilisateur : le téléchargement a quand même réussi.
        } catch (_: Exception) {}
    }

    fun notifyModelReady(context: Context) = notifyDone(
        context, MODEL_DONE_NOTIF_ID,
        "Vanelle est prête",
        "Le moteur IA local a fini de télécharger. Vous pouvez lui parler."
    )

    fun notifyEmbeddingReady(context: Context) = notifyDone(
        context, EMBED_DONE_NOTIF_ID,
        "Vanelle — recherche documentaire prête",
        "Le module de connaissances a fini de télécharger."
    )
}

/**
 * setForeground peut lever une exception (permission notification refusée,
 * type de service non déclaré, etc.). On ne doit pas faire échouer le download pour ça.
 */
suspend fun androidx.work.CoroutineWorker.safeSetForeground(info: ForegroundInfo) {
    try {
        setForeground(info)
    } catch (_: Exception) {
        // ignore — le téléchargement continue sans notification
    }
}
