/* ===========================================================
   VANELLE — logique de l'application
   100% local : les données vivent dans IndexedDB du navigateur.
   =========================================================== */

/* ---------------------- stockage (IndexedDB) ---------------------- */
const DB_NAME = "vanelle-ai-db";
const DB_VERSION = 1;
let dbP = null;

function openDB(){
  if(dbP) return dbP;
  dbP = new Promise((resolve, reject)=>{
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e)=>{
      const db = e.target.result;
      if(!db.objectStoreNames.contains("ais")) db.createObjectStore("ais", {keyPath:"id"});
      if(!db.objectStoreNames.contains("profile")) db.createObjectStore("profile", {keyPath:"id"});
    };
    req.onsuccess = ()=> resolve(req.result);
    req.onerror = ()=> reject(req.error);
  });
  return dbP;
}

async function idbGetAll(store){
  const db = await openDB();
  return new Promise((resolve,reject)=>{
    const tx = db.transaction(store,"readonly");
    const req = tx.objectStore(store).getAll();
    req.onsuccess = ()=> resolve(req.result || []);
    req.onerror = ()=> reject(req.error);
  });
}
async function idbGet(store,id){
  const db = await openDB();
  return new Promise((resolve,reject)=>{
    const tx = db.transaction(store,"readonly");
    const req = tx.objectStore(store).get(id);
    req.onsuccess = ()=> resolve(req.result || null);
    req.onerror = ()=> reject(req.error);
  });
}
async function idbPut(store,val){
  const db = await openDB();
  return new Promise((resolve,reject)=>{
    const tx = db.transaction(store,"readwrite");
    tx.objectStore(store).put(val);
    tx.oncomplete = ()=> resolve(val);
    tx.onerror = ()=> reject(tx.error);
  });
}
async function idbDelete(store,id){
  const db = await openDB();
  return new Promise((resolve,reject)=>{
    const tx = db.transaction(store,"readwrite");
    tx.objectStore(store).delete(id);
    tx.oncomplete = ()=> resolve();
    tx.onerror = ()=> reject(tx.error);
  });
}

const Store = {
  getAllAIs: ()=> idbGetAll("ais"),
  getAI: (id)=> idbGet("ais", id),
  saveAI: (ai)=> idbPut("ais", ai),
  deleteAI: (id)=> idbDelete("ais", id),
  getProfile: async ()=> (await idbGet("profile","p1")) || {id:"p1", pseudo:"", createdAt: Date.now()},
  saveProfile: (p)=> idbPut("profile", p),
};

async function requireAI(id){
  const ai = await Store.getAI(id);
  if(!ai){ toast("Cette IA est introuvable.","err"); return null; }
  return ai;
}


/* ---------------------- utilitaires ---------------------- */
const uid = ()=> (crypto.randomUUID ? crypto.randomUUID() : "id-"+Date.now()+"-"+Math.random().toString(16).slice(2));
const esc = (s="")=> String(s).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const slug = (s="")=> s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,"") || "mon-ia";
const fmtDate = (ts)=> new Date(ts).toLocaleDateString("fr-FR", {day:"2-digit", month:"short", year:"numeric"});
const fmtSize = (b)=>{
  if(b < 1024) return b + " o";
  if(b < 1024*1024) return (b/1024).toFixed(1) + " Ko";
  if(b < 1024*1024*1024) return (b/1024/1024).toFixed(2) + " Mo";
  return (b/1024/1024/1024).toFixed(2) + " Go";
};
const MAX_UPLOAD_BYTES = 3 * 1024 * 1024 * 1024; // 3 Go

function toast(msg, kind="ok"){
  const zone = document.getElementById("toast-zone");
  if(!zone){ try{ console.warn("[toast]", msg); }catch(_){} return; }
  const el = document.createElement("div");
  el.className = "toast" + (kind==="err" ? " err" : "");
  el.textContent = msg;
  zone.appendChild(el);
  setTimeout(()=>{ el.style.opacity="0"; el.style.transition="opacity .3s"; setTimeout(()=>el.remove(),300); }, 3200);
}

function progressOf(ai){
  const score = Math.min(1,
    (ai.training.length / 12) * 0.5 +
    (ai.files.length / 5) * 0.25 +
    (ai.apis.length / 3) * 0.25
  );
  return Math.round(score*100);
}

const CATEGORIES = ["Identité", "Personnalité", "Connaissances", "Compétences", "Règles"];

/* ---------------------- IA conversationnelle locale : Vanelle ---------------------- */
const VanelleEngine = {
  modelId: "Qwen2.5-0.5B-Instruct-Q4_K_M",
  label: "Vanelle",
  estimatedDownload: "environ 420 Mo (téléchargement initial)",
  context: 4096,
  engine: null,
  state: "off",
  progress: "",
  adapter: null,
};
let llmEngine = null;
let llmState = "off";
let llmProgressText = "";
let embeddingPipeline = null;
let embeddingState = "off";

function setLlmState(state, text=""){
  llmState = state; llmProgressText = text;
  VanelleEngine.state = state; VanelleEngine.progress = text;
  const el = document.getElementById("llm-status");
  if(!el) return;
  // network_interrupted s'affiche comme "loading" avec un message spécifique
  const cssState = (state==="network_interrupted") ? "loading" : state;
  el.className = "llm-status " + cssState;
  const label = state==="off" ? "Vanelle : non activée"
    : state==="network_interrupted" ? "Vanelle : réseau interrompu — reprise auto…"
    : state==="loading" ? "Vanelle : " + (text||"chargement…")
    : state==="on" ? "Vanelle : prête"
    : "Vanelle : moteur indisponible";
  el.innerHTML = `<span class="dot"></span>${label}`;
}

function deviceProfile(){
  const dm = navigator.deviceMemory || 4;
  const cores = navigator.hardwareConcurrency || 4;
  return {
    ramGB: dm,
    cores,
    recommendedContext: dm >= 6 ? 4096 : dm >= 4 ? 3072 : 2048,
    warning: dm < 4 ? "Cet appareil dispose de peu de mémoire. Vanelle utilisera un contexte réduit." : ""
  };
}

/* Le téléchargement du moteur est déclenché automatiquement par l'app Android
   dès l'ouverture (voir MainActivity.onCreate). Ici on se contente de
   déclencher/relancer (idempotent côté natif) puis de suivre la progression.
   La progression reste visible dans la sidebar même quand le téléchargement
   tourne en arrière-plan (WorkManager). */
let llmWatchTimer = null;
function startLlmProgressWatch(){
  if(llmWatchTimer) return;
  llmWatchTimer = setInterval(()=>{
    if(!window.AndroidVanelle) return;
    try{
      let state = AndroidVanelle.modelState();
      const pct = AndroidVanelle.modelProgress();
      const detail = (AndroidVanelle.modelStatusDetail && AndroidVanelle.modelStatusDetail()) || state;
      // Fichier téléchargé → charger en mémoire (activateLocal charge le GGUF)
      if(state === "downloaded"){
        setLlmState("loading", "chargement en mémoire…");
        state = AndroidVanelle.activateLocal() || state;
      }
      if(state === "ready"){
        setLlmState("on");
        clearInterval(llmWatchTimer); llmWatchTimer = null;
        return;
      }
      if(state === "network_interrupted" || detail === "network_interrupted"){
        setLlmState("network_interrupted", pct > 0 ? pct + "%" : "");
        return;
      }
      if(state === "downloading" || state === "missing" || state === "downloaded"){
        const label = state === "downloaded"
          ? "chargement en mémoire…"
          : (pct > 0 ? pct + "% — reprise si coupure" : "téléchargement…");
        setLlmState("loading", label);
      }
    }catch(_){}
  }, 800);
}
async function ensureLLM(modelId=VanelleEngine.modelId){
  if(llmState==="on") return {native:true};
  if(window.AndroidVanelle){
    let state = AndroidVanelle.activateLocal();
    setLlmState("loading", state==="ready"?"prêt":"préparation…");
    startLlmProgressWatch();
    for(let i=0;i<900;i++){
      state = AndroidVanelle.modelState();
      const pct = AndroidVanelle.modelProgress();
      if(state==="downloaded"){
        setLlmState("loading", "chargement en mémoire…");
        state = AndroidVanelle.activateLocal() || state;
      }
      if(state==="ready"){ setLlmState("on"); return {native:true}; }
      if(state==="network_interrupted"){
        setLlmState("network_interrupted", pct > 0 ? pct + "%" : "");
      } else if(state==="downloaded"){
        setLlmState("loading", "chargement en mémoire…");
      } else {
        setLlmState("loading", pct > 0 ? pct + "% — reprise si coupure" : "téléchargement…");
      }
      await new Promise(r=>setTimeout(r,500));
    }
    throw new Error("model-timeout");
  }
  throw new Error("native-engine-required");
}
async function initLLMFromProfile(){
  const profile=await Store.getProfile();
  if(!profile.llmEnabled){ profile.llmEnabled=true; profile.llmModel=VanelleEngine.modelId; await Store.saveProfile(profile); }
  setLlmState("loading", "démarrage…");
  startLlmProgressWatch();
  try{
    await ensureLLM(VanelleEngine.modelId);
  }catch(e){
    // Le téléchargement continue réellement en arrière-plan ; la progression
    // reste visible dans la sidebar grâce au watch permanent.
    
  }
}

async function ensureEmbeddings(){
  if(embeddingState==="on") return true;
  if(!window.AndroidVanelle) throw new Error("native-engine-required");
  let state = AndroidVanelle.activateEmbedding() || AndroidVanelle.embeddingState();
  for(let i=0;i<360;i++){
    state = AndroidVanelle.embeddingState();
    if(state==="downloaded"){
      state = AndroidVanelle.activateEmbedding() || state;
    }
    if(state==="ready"){ embeddingState="on"; return true; }
    await new Promise(r=>setTimeout(r,500));
  }
  throw new Error("embedding-timeout");
}

function cleanText(text){
  return String(text||"").replace(/\r/g,"\n").replace(/[\t ]+/g," ").replace(/\n{3,}/g,"\n\n").trim();
}
function chunkText(text,size=900,overlap=120){
  const t=cleanText(text); if(!t) return [];
  const chunks=[]; let start=0;
  while(start<t.length){
    let end=Math.min(t.length,start+size);
    if(end<t.length){ const cut=t.lastIndexOf(" ",end); if(cut>start+Math.floor(size*.6)) end=cut; }
    chunks.push(t.slice(start,end).trim());
    if(end>=t.length) break;
    start=Math.max(end-overlap,start+1);
  }
  return chunks.filter(Boolean);
}
function normalizeVector(v){
  const a=Array.from(v||[]).map(Number); const n=Math.sqrt(a.reduce((s,x)=>s+x*x,0))||1; return a.map(x=>x/n);
}
function cosine(a,b){
  if(!a||!b||a.length!==b.length) return -1;
  let s=0; for(let i=0;i<a.length;i++) s+=a[i]*b[i]; return s;
}
async function embedTexts(texts){
  if(!texts.length) return [];
  await ensureEmbeddings();
  const out=[];
  for(const text of texts){
    const raw=AndroidVanelle.embed(String(text));
    if(!raw) throw new Error("embedding-failed");
    const v=raw.split(",").filter(Boolean).map(Number);
    if(!v.length) throw new Error("embedding-empty");
    out.push(normalizeVector(v));
  }
  return out;
}
async function rebuildKnowledgeIndex(ai){
  const docs=[];
  ai.training.forEach(t=>docs.push({sourceId:t.id,source:t.question,text:`${t.question}\n${t.reponse}`,kind:"training"}));
  ai.files.forEach(f=>(f.chunks||[]).forEach(c=>docs.push({sourceId:f.id,source:f.nom,text:c.text,kind:"file"})));
  if(!docs.length){ ai.knowledgeIndex=[]; return; }
  try{
    const vectors=await embedTexts(docs.map(d=>d.text));
    ai.knowledgeIndex=docs.map((d,i)=>({...d,embedding:vectors[i]}));
    ai.knowledgeIndexVersion=1;
    ai.embeddingModel="all-MiniLM-L6-v2-Q4_K_M";
    ai.knowledgeUpdatedAt=Date.now();
  }catch(e){
    // Index vectoriel optionnel : les fichiers restent exploitables via résumé
    ai.knowledgeIndex = ai.knowledgeIndex || [];
    throw e;
  }
}
async function retrieveKnowledge(ai,query,k=5){
  if(!ai.knowledgeIndex?.length || ai.knowledgeIndexVersion!==1 || ai.embeddingModel!=="all-MiniLM-L6-v2-Q4_K_M") return [];
  const [qv]=await embedTexts([query]);
  return ai.knowledgeIndex.map(x=>({...x,score:cosine(qv,x.embedding)})).filter(x=>x.score>=0.20).sort((a,b)=>b.score-a.score).slice(0,k);
}

function buildSystemPrompt(ai,knowledge=[]){
  const parts=[];
  const custom = (ai.systemPrompt||"").trim();
  if(custom){
    parts.push(custom);
  } else {
    parts.push(`Tu es ${ai.nom||"Vanelle"}, une IA locale configurée par l'utilisateur. ${ai.description||""}`.trim());
    parts.push(`RÈGLES : n'invente jamais une information. Si l'information n'est pas connue ou récupérée, dis clairement que tu ne la sais pas. Réponds en français sauf demande contraire.`);
  }
  parts.push(`Le nom affiché de l'assistant est ${ai.nom||"Vanelle"}. Ne révèle jamais le nom technique du modèle sous-jacent.`);
  if(knowledge.length){
    parts.push("CONNAISSANCES RÉCUPÉRÉES :");
    knowledge.forEach((x,i)=>parts.push(`[${i+1}] ${x.source}: ${x.text.slice(0,900)}`));
  }
  return parts.join("\n\n").slice(0,9000);
}

async function generateLLMReply(ai,history,userMessage,attachments=[]){
  const knowledge=await retrieveKnowledge(ai,userMessage,5).catch(()=>[]);
  const textAttachments = attachments.filter(a=>a.kind==="text");
  const imageAttachments = attachments.filter(a=>a.kind==="image");
  const attachedTextBlock = textAttachments.map(a=>`[Fichier joint : ${a.name}]\n${a.content}`).join("\n\n");
  // Version texte seule (moteur local + secours) : les images deviennent une simple mention.
  const userTextLocal = [
    userMessage,
    attachedTextBlock,
    imageAttachments.length ? `[${imageAttachments.length} image(s) jointe(s) — non analysée(s), moteur local texte seul]` : ""
  ].filter(Boolean).join("\n\n") || (imageAttachments.length ? "Voici une image." : "");
  // Version envoyée au moteur externe : images en pièces jointes réelles (format vision compatible OpenAI)
  const userTextRemote = [userMessage, attachedTextBlock].filter(Boolean).join("\n\n") || (imageAttachments.length ? "Décris cette image." : "");
  const remoteUserContent = imageAttachments.length
    ? [{type:"text", text:userTextRemote}, ...imageAttachments.map(a=>({type:"image_url", image_url:{url:a.dataUrl}}))]
    : userTextRemote;

  const messages=[
    {role:"system",content:buildSystemPrompt(ai,knowledge)},
    ...history.slice(-8).map(m=>({role:m.who==="user"?"user":"assistant",content:m.text})),
    {role:"user",content:userTextLocal}
  ];
  if(!window.AndroidVanelle) throw new Error("native-engine-required");

  let remote = "not_configured";
  try{ remote = AndroidVanelle.remoteState() || "not_configured"; }catch(_){}

  // Si des images sont jointes et qu'un moteur externe (vision) est configuré,
  // on lui donne la priorité : le moteur local est texte seul et ne peut pas les voir.
  const preferRemoteForImages = imageAttachments.length>0 && remote==="configured";

  // 1) Moteur local
  let localState = "missing";
  if(!preferRemoteForImages){
    try{ localState = AndroidVanelle.modelState() || "missing"; }catch(_){}
    if(localState==="downloaded" || localState==="ready"){
      try{ localState = AndroidVanelle.activateLocal() || localState; }catch(_){}
    } else if(localState==="missing"){
      try{ AndroidVanelle.activateLocal(); localState = AndroidVanelle.modelState() || "missing"; }catch(_){}
    }
    if(localState==="ready"){
      setLlmState("on");
      const transcript = messages.map(m => "<|im_start|>"+m.role+"\n"+m.content+"<|im_end|>\n").join("")+"<|im_start|>assistant\n";
      const text = (AndroidVanelle.generate(transcript, 512) || "").trim();
      if(text) return text;
      // si generate vide, tenter remote en secours
    }
  }

  // 2) Moteur externe (prioritaire si local pas prêt, ou secours)
  if(remote==="configured"){
    try{
      let text = "";
      if(AndroidVanelle.generateRemoteChat){
        // remplace le dernier message (texte local) par la version multimodale (texte + images)
        const remoteMessages = messages.slice(0,-1).concat([{role:"user", content: remoteUserContent}]);
        text = (AndroidVanelle.generateRemoteChat(JSON.stringify(remoteMessages), 512) || "").trim();
      }
      if(!text && !imageAttachments.length){
        const remotePrompt = messages.map(m => m.role.toUpperCase()+": "+m.content).join("\n\n");
        text = (AndroidVanelle.generateRemote(remotePrompt, 512) || "").trim();
      }
      if(text) return text;
      throw new Error("remote-inference-failed");
    }catch(e){
      if(e.message==="remote-inference-failed") throw e;
      throw new Error("remote-inference-failed");
    }
  }

  if(localState==="downloading" || localState==="network_interrupted" || localState==="loading_memory" || llmState==="loading")
    throw new Error("local-still-loading");
  if(localState==="downloaded")
    throw new Error("local-inference-failed");
  throw new Error("no-ai-engine-configured");
}



function blankAI({nom, description, modele}){
  return {
    id: uid(),
    nom: nom || "Nouvelle IA",
    description: description || "",
    modele: modele || "Généraliste",
    systemPrompt: "",
    createdAt: Date.now(),
    deployed: false,
    deployedAt: null,
    training: [],
    apis: [],
    files: [],
  };
}

/* ---------------------- routeur ---------------------- */
window.addEventListener("hashchange", route);
window.addEventListener("DOMContentLoaded", route);
window.addEventListener("DOMContentLoaded", initLLMFromProfile);
window.addEventListener("DOMContentLoaded", ()=>{
  if(window.AndroidVanelle){
    const host=document.querySelector(".tray");
    if(host && !document.getElementById("native-model-tools")){
      const box=document.createElement("div"); box.id="native-model-tools"; box.className="nav-group";
      box.innerHTML='<div class="nav-label">MOTEUR</div><button class="nav-item" id="native-download-btn" type="button">⟳ Vérifier Vanelle</button><button class="nav-item" id="native-import-btn" type="button">＋ Importer un modèle</button><button class="nav-item" id="remote-config-btn" type="button">☁ Configurer un moteur externe</button>';
      host.appendChild(box);
      document.getElementById("native-download-btn").onclick=()=>{
        startLlmProgressWatch();
        ensureLLM(VanelleEngine.modelId).then(()=>{}).catch(()=>{});
      };
      document.getElementById("native-import-btn").onclick=()=>AndroidVanelle.openModelPicker();
      document.getElementById("remote-config-btn").onclick=()=>{
        const endpoint=prompt("Adresse du moteur compatible OpenAI (ex: https://serveur/v1)",""); if(!endpoint) return;
        const model=prompt("Identifiant du modèle sur ce serveur",""); if(!model) return;
        const key=prompt("Clé API (elle sera stockée chiffrée sur l'appareil)","")||"";
        const r=AndroidVanelle.saveRemote(endpoint,model,key);
        if(r==="saved"){ /* silencieux */ }
        else if(r==="invalid_https") toast("L'endpoint doit commencer par https://","err");
        else toast("Configuration invalide (endpoint + modèle requis).","err");
      };
    }
  }
});

function currentRoute(){
  const h = (location.hash || "#creer").slice(1);
  const parts = h.split("/").filter(Boolean);
  return parts;
}

async function route(){
  const parts = currentRoute();
  document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active"));
  const app = document.getElementById("app");
  if(!app) return;

  if(parts[0] === "ia" && parts[1]){
    const ai = await Store.getAI(parts[1]);
    if(!ai){ app.innerHTML = `<div class="empty">Cette IA est introuvable. Elle a peut-être été supprimée.<br><br><a class="btn btn-stamp" href="#mes-ia">Retour à Mes IA</a></div>`; return; }
    document.querySelector('.nav-item[data-route="mes-ia"]')?.classList.add("active");
    renderAIProfile(app, ai, parts[2] || "vue");
    return;
  }

  const r = parts[0] || "creer";
  const navItem = document.querySelector(`.nav-item[data-route="${r}"]`);
  if(navItem) navItem.classList.add("active");

  if(r === "creer") return renderCreer(app);
  if(r === "mes-ia") return renderMesIA(app);
  if(r === "dashboard") return renderDashboard(app);
  if(r === "compte") return renderCompte(app);
  renderCreer(app);
}

/* ---------------------- page: créer une IA ---------------------- */
function renderCreer(app){
  app.innerHTML = `
    <div class="pagehead">
      <div class="eyebrow">ÉTAPE 0</div>
      <h1>Créer une nouvelle IA</h1>
      <p>Donnez-lui un nom et un point de départ. Tout le reste — ce qu'elle sait, ce qu'elle sait faire — c'est vous qui le lui apprenez, à l'étape suivante.</p>
    </div>
    <div class="card" style="max-width:520px;">
      <label>Nom de l'IA</label>
      <input type="text" id="f-nom" placeholder="Ex. Solutions Pro">
      <label>Description</label>
      <textarea id="f-desc" placeholder="En une phrase, à quoi sert cette IA ?"></textarea>
      <label>Style de base</label>
      <select id="f-modele">
        <option>Généraliste</option>
        <option>Expert technique</option>
        <option>Conseil &amp; vente</option>
        <option>Support client</option>
        <option>Créatif</option>
      </select>
      <button class="btn btn-stamp btn-block" style="margin-top:18px;" onclick="Actions.creerIA()">Commencer l'apprentissage</button>
    </div>
  `;
}

const Actions = {};
window.Actions = Actions;

Actions.creerIA = async ()=>{
  const nom = document.getElementById("f-nom").value.trim();
  const description = document.getElementById("f-desc").value.trim();
  const modele = document.getElementById("f-modele").value;
  if(!nom){ toast("Donnez un nom à votre IA avant de continuer.", "err"); return; }
  const ai = blankAI({nom, description, modele});
  await Store.saveAI(ai);
  
  location.hash = `#ia/${ai.id}/vue`;
};

/* ---------------------- page: mes IA ---------------------- */
async function renderMesIA(app){
  const ais = (await Store.getAllAIs()).sort((a,b)=>b.createdAt-a.createdAt);
  app.innerHTML = `
    <div class="pagehead">
      <div class="eyebrow">ATELIER</div>
      <h1>Mes IA</h1>
      <p>${ais.length} IA en cours de construction.</p>
    </div>
    ${ais.length===0 ? `
      <div class="empty">Vous n'avez encore créé aucune IA.
        <br><a class="btn btn-stamp" href="#creer">Créer ma première IA</a>
      </div>` : `
      <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(240px,1fr));">
        ${ais.map(ai=>`
          <div class="ai-card" onclick="location.hash='#ia/${ai.id}/vue'">
            <h3>${esc(ai.nom)}</h3>
            <p>${esc(ai.description || "Pas encore de description.")}</p>
            <div class="row">
              <span class="tag ${ai.deployed?'on':'off'}">${ai.deployed ? "déployée" : "en cours"}</span>
              <span class="meta" style="font-size:11px;">${ai.files.length} fichier(s) · ${ai.training.length} notion(s)</span>
            </div>
          </div>
        `).join("")}
      </div>
    `}
  `;
}

/* ---------------------- page: dashboard ---------------------- */
async function renderDashboard(app){
  const ais = await Store.getAllAIs();
  const totalTraining = ais.reduce((s,a)=>s+a.training.length,0);
  const totalFiles = ais.reduce((s,a)=>s+a.files.length,0);
  const totalApis = ais.reduce((s,a)=>s+a.apis.length,0);
  const deployed = ais.filter(a=>a.deployed).length;

  app.innerHTML = `
    <div class="pagehead">
      <div class="eyebrow">VUE D'ENSEMBLE</div>
      <h1>Tableau de bord</h1>
      <p>L'état de tout ce que vous construisez ici.</p>
    </div>
    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr)); margin-bottom:24px;">
      <div class="stat-card"><div class="num">${ais.length}</div><div class="lbl">IA créées</div></div>
      <div class="stat-card"><div class="num">${deployed}</div><div class="lbl">déployées</div></div>
      <div class="stat-card"><div class="num">${totalTraining}</div><div class="lbl">notions enseignées</div></div>
      <div class="stat-card"><div class="num">${totalFiles}</div><div class="lbl">fichiers analysés</div></div>
      <div class="stat-card"><div class="num">${totalApis}</div><div class="lbl">API connectées</div></div>
    </div>
    <div class="card">
      <h2>Progression par IA</h2>
      ${ais.length===0 ? `<p style="color:var(--ink-soft);font-size:13px;">Rien à afficher pour l'instant.</p>` : ais.map(ai=>`
        <div class="list-row">
          <div>
            <a href="#ia/${ai.id}/vue" style="text-decoration:none;color:var(--ink);font-weight:600;">${esc(ai.nom)}</a>
            <div class="meta">${ai.training.length} notions · ${ai.files.length} fichiers · ${ai.apis.length} API</div>
          </div>
          
        </div>
      `).join("")}
    </div>
  `;
}

/* ---------------------- page: compte ---------------------- */
async function renderCompte(app){
  const profile = await Store.getProfile();
  app.innerHTML = `
    <div class="pagehead">
      <div class="eyebrow">COMPTE</div>
      <h1>Compte &amp; données</h1>
      <p>Tout ce que vous construisez ici reste dans ce navigateur, sur cet appareil.</p>
    </div>
    <div class="grid cols-2">
      <div class="card">
        <h2>Profil</h2>
        <label>Votre nom ou pseudo</label>
        <input type="text" id="f-pseudo" value="${esc(profile.pseudo||"")}" placeholder="Ex. Camille">
        <button class="btn btn-stamp" style="margin-top:14px;" onclick="Actions.saveProfile()">Enregistrer</button>
      </div>
      <div class="card">
        <h2>Sauvegarde</h2>
        <p style="font-size:12.5px;color:var(--ink-soft);">Exportez toutes vos IA (config, apprentissage, fichiers analysés) dans un seul fichier, ou récupérez une sauvegarde précédente.</p>
        <button class="btn btn-ghost btn-sm" onclick="Actions.exportAll()">↓ Exporter toutes mes données</button>
        <label style="margin-top:14px;">Importer une sauvegarde (.json)</label>
        <input type="file" accept=".json" onchange="Actions.importAll(event)">
      </div>
    </div>
    <div class="card" style="margin-top:18px;">
      <h2>Vanelle locale <span class="tag ${llmState==='on'?'on':'off'}">${llmState==='on'?'activée':llmState==='loading'?'téléchargement…':'désactivée'}</span></h2>
      <p style="font-size:12.5px;color:var(--ink-soft);line-height:1.6;">
        Vanelle télécharge automatiquement son moteur local à l'ouverture de l'application (une seule fois, mis en cache sur l'appareil). Les conversations peuvent ensuite fonctionner sans serveur.
      </p>
      <div class="list-row"><span>Moteur</span><strong>Vanelle</strong></div>
      <div class="list-row"><span>Téléchargement initial</span><strong>~420 Mo</strong></div>
      <div class="list-row"><span>Contexte adaptatif</span><strong>${deviceProfile().recommendedContext} tokens</strong></div>
      <div style="display:flex;gap:8px;margin-top:12px;">
        <button class="btn btn-stamp btn-sm" onclick="Actions.activerLLM()">Réessayer maintenant</button>
        <button class="btn btn-ghost btn-sm" onclick="Actions.desactiverLLM()">Désactiver</button>
      </div>
      <p id="llm-detail" style="font-size:11.5px;color:var(--ink-soft);margin-top:10px;font-family:var(--mono);">${
        llmState==="network_interrupted"
          ? ("Réseau interrompu — reprise automatique dès le retour du réseau ("+(llmProgressText||"…")+")")
          : llmState==="loading"
            ? ("Téléchargement en cours : "+llmProgressText+" — en cas de coupure, reprise automatique")
            : llmState==="on"
              ? "Vanelle est prête."
              : llmState==="err"
                ? "Le moteur n'est pas disponible sur cet appareil."
                : "En attente du réseau pour démarrer le téléchargement."
      }</p>
    </div>

    <div class="card" style="margin-top:18px;">
      <h2>À propos de cette version</h2>
      <p style="font-size:12.5px;color:var(--ink-soft);line-height:1.6;">
        La création, l'apprentissage et l'analyse de fichiers se font entièrement dans ce
        navigateur, sans serveur. L'application peut utiliser un moteur externe réellement compatible OpenAI lorsque l'utilisateur le configure dans le moteur Vanelle. La clé est conservée chiffrée côté Android. Le modèle conversationnel local ci-dessus n'est pas "ré-entraîné" sur vos
        données : c'est un modèle généraliste à qui l'on donne, à chaque échange, tout ce que vous
        avez enseigné à cette IA — la même logique de configuration que la recherche par mots-clés,
        en plus naturel.
      </p>
    </div>
  `;
}

Actions.activerLLM = async ()=>{
  const profile=await Store.getProfile();
  profile.llmEnabled=true;
  profile.llmModel=VanelleEngine.modelId;
  await Store.saveProfile(profile);
  startLlmProgressWatch();
  try{
    await ensureLLM(VanelleEngine.modelId);
    
  }catch(e){
    
  }
  route();
};

Actions.desactiverLLM = async ()=>{
  const profile = await Store.getProfile();
  profile.llmEnabled = false;
  await Store.saveProfile(profile);
  llmEngine = null;
  setLlmState("off");
  
  route();
};

Actions.saveProfile = async ()=>{
  const p = await Store.getProfile();
  p.pseudo = document.getElementById("f-pseudo").value.trim();
  await Store.saveProfile(p);
  
};

Actions.exportAll = async ()=>{
  const ais = await Store.getAllAIs();
  const profile = await Store.getProfile();
  const blob = new Blob([JSON.stringify({profile, ais}, null, 2)], {type:"application/json"});
  downloadBlob(blob, "vanelle-sauvegarde.json");
  
};

Actions.importAll = async (evt)=>{
  const file = evt.target.files[0];
  if(!file) return;
  try{
    const text = await file.text();
    const data = JSON.parse(text);
    if(data.profile) await Store.saveProfile(data.profile);
    if(Array.isArray(data.ais)) for(const ai of data.ais) await Store.saveAI(ai);
    
    route();
  }catch(e){
    toast("Ce fichier n'a pas pu être lu.", "err");
  }
};

function downloadBlob(blob, filename){
  // Le WebView Android natif ne déclenche pas les téléchargements de blob: via <a download> :
  // on passe donc les octets en base64 au pont natif, qui les écrit dans Téléchargements.
  if(window.AndroidVanelle && window.AndroidVanelle.saveFile){
    const reader = new FileReader();
    reader.onload = ()=>{
      const base64 = String(reader.result).split(",")[1] || "";
      const mime = blob.type || "application/octet-stream";
      const result = AndroidVanelle.saveFile(filename, mime, base64);
      if(result !== "saved" && result !== "permission_pending") toast(`Impossible d'enregistrer "${filename}".`, "err");
    };
    reader.onerror = ()=> toast(`Impossible d'enregistrer "${filename}".`, "err");
    reader.readAsDataURL(blob);
    return;
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url), 4000);
}

/* ---------------------- page: profil d'une IA ---------------------- */
function tabBtn(ai, tab, label){
  const active = (currentRoute()[2]||"vue")===tab;
  return `<a class="btn ${active?'btn-stamp':'btn-ghost'} btn-sm" href="#ia/${ai.id}/${tab}">${label}</a>`;
}

function renderAIProfile(app, ai, tab){
  if(tab==="tester"){
    app.classList.add("chat-mode");
    app.innerHTML = `
      <div class="chat-tabs">
        ${tabBtn(ai,"vue","Vue")}
        ${tabBtn(ai,"apprentissage","Apprentissage")}
        ${tabBtn(ai,"fichiers","Fichiers")}
        ${tabBtn(ai,"api","API")}
        ${tabBtn(ai,"tester","Chat")}
      </div>
      <div id="tab-body" class="chat-body"></div>
    `;
    return renderTabTester(document.getElementById("tab-body"), ai);
  }
  app.classList.remove("chat-mode");
  app.innerHTML = `
    <div class="pagehead">
      <div class="eyebrow">PROFIL DE MON IA</div>
      <h1>"${esc(ai.nom)}"</h1>
      <p>${esc(ai.description || "")}</p>
      <div class="pill-row">
        ${tabBtn(ai,"vue","Vue d'ensemble")}
        ${tabBtn(ai,"apprentissage","Apprentissage (A à Z)")}
        ${tabBtn(ai,"fichiers","Fichiers &amp; données")}
        ${tabBtn(ai,"api","Intégrations API")}
        ${tabBtn(ai,"tester","Chat")}
      </div>
    </div>
    <div id="tab-body"></div>
  `;
  const body = document.getElementById("tab-body");
  if(tab==="vue") return renderTabVue(body, ai);
  if(tab==="apprentissage") return renderTabApprentissage(body, ai);
  if(tab==="fichiers") return renderTabFichiers(body, ai);
  if(tab==="api") return renderTabApi(body, ai);
}

/* --- tab: vue d'ensemble (reprend la mise en page de la maquette) --- */
function renderTabVue(body, ai){
  body.innerHTML = `
    <div class="grid cols-3">
      <div class="card">
        <h2>Fiche d'identité</h2>
        <label>Nom de l'IA</label>
        <input type="text" id="v-nom" value="${esc(ai.nom)}">
        <label>Description</label>
        <textarea id="v-desc">${esc(ai.description)}</textarea>
        <label>Style de base</label>
        <select id="v-modele">
          ${["Généraliste","Expert technique","Conseil & vente","Support client","Créatif"].map(m=>`<option ${ai.modele===m?"selected":""}>${m}</option>`).join("")}
        </select>
        <button class="btn btn-stamp btn-block" style="margin-top:16px;" onclick="Actions.saveIdentite('${ai.id}')">Enregistrer la fiche</button>
        <button class="btn btn-ghost btn-block" style="margin-top:8px;" onclick="Actions.supprimerIA('${ai.id}')">Supprimer cette IA</button>
      </div>

      <div class="card">
        <h2><span class="stepnum">1</span>Ajouter des données</h2>
        <p style="font-size:12px;color:var(--ink-soft);">Un .zip de documents, ou des fichiers texte / csv / json isolés. L'app les lit et les range en fiches de connaissance.</p>
        <div class="dashed-box" onclick="document.getElementById('v-upload').click()">
          ↑ Uploader<br><small>TXT, MD, CSV, JSON, HTML, JS, CSS, PDF, ZIP (max 3 Go)</small>
        </div>
        <button type="button" class="btn btn-ghost btn-sm btn-block" style="margin-top:8px;" onclick="Actions.openNativeZip('${ai.id}')">ZIP volumineux (streaming natif jusqu'à 3 Go)</button>
        <input type="file" id="v-upload" style="display:none" multiple accept=".zip,.txt,.md,.csv,.json,.html,.js,.css,.pdf,application/zip,text/*" onchange="Actions.uploadFichiers(event,'${ai.id}')">
        <div id="v-upload-status" style="font-size:12px;margin-top:8px;color:var(--ink-soft);"></div>

        <hr class="hr">
        <h2><span class="stepnum">2</span>Configurer une API</h2>
        <p style="font-size:12px;color:var(--ink-soft);">Documentez un service externe que votre IA devra utiliser une fois hébergée.</p>
        <input type="text" id="v-api-nom" placeholder="Nom de l'API">
        <input type="url" id="v-api-url" placeholder="Endpoint URL" style="margin-top:8px;">
        <input type="password" id="v-api-key" placeholder="Clé d'authentification (optionnel)" style="margin-top:8px;">
        <textarea id="v-api-desc" placeholder="Description de l'API" style="margin-top:8px;"></textarea>
        <button class="btn btn-ghost btn-block" style="margin-top:10px;" onclick="Actions.ajouterApi('${ai.id}')">Ajouter l'API</button>

        <hr class="hr">
        <h2><span class="stepnum">3</span>Ajouter une IA complète (ZIP)</h2>
        <p style="font-size:12px;color:var(--ink-soft);">Réimportez une IA déjà exportée depuis cette app pour continuer là où vous vous étiez arrêté.</p>
        <div class="dashed-box" onclick="document.getElementById('v-upload-ia').click()">↑ Uploader l'IA (.zip)</div>
        <input type="file" id="v-upload-ia" style="display:none" accept=".zip,application/zip,application/x-zip-compressed" onchange="Actions.importerIAZip(event,'${ai.id}')">
      </div>

      <div>
        <div class="card">
          <h2>Résumé</h2>
          <div class="list-row"><span>Notions enseignées</span><strong>${ai.training.length}</strong></div>
          <div class="list-row"><span>Fichiers analysés</span><strong>${ai.files.length}</strong></div>
          <div class="list-row"><span>API connectées</span><strong>${ai.apis.length}</strong></div>
          <div class="list-row"><span>Statut</span><span class="tag ${ai.deployed?'on':'off'}">${ai.deployed?"déployée":"brouillon"}</span></div>
        </div>
        <button class="btn btn-ok btn-block" style="margin-top:14px;" onclick="location.hash='#ia/${ai.id}/tester'">Ouvrir le chat de test →</button>
        <button class="btn btn-ghost btn-block" style="margin-top:8px;" onclick="Actions.exportIA('${ai.id}')">↓ Exporter cette IA</button>
      </div>
    </div>
  `;
}

Actions.saveIdentite = async (id)=>{
  const ai = await requireAI(id); if(!ai) return;
  ai.nom = document.getElementById("v-nom").value.trim() || ai.nom;
  ai.description = document.getElementById("v-desc").value.trim();
  ai.modele = document.getElementById("v-modele").value;
  await Store.saveAI(ai);
  
  route();
};

Actions.supprimerIA = async (id)=>{
  if(!(await Store.getAI(id))){ toast("Cette IA est introuvable.","err"); return; }
  if(!confirm("Supprimer définitivement cette IA et tout son apprentissage ?")) return;
  await Store.deleteAI(id);
  
  location.hash = "#mes-ia";
};

Actions.ajouterApi = async (id)=>{
  if(!(await Store.getAI(id))){ toast("Cette IA est introuvable.","err"); return; }
  const nom = document.getElementById("v-api-nom").value.trim();
  const endpoint = document.getElementById("v-api-url").value.trim();
  const cle = document.getElementById("v-api-key").value.trim();
  const description = document.getElementById("v-api-desc").value.trim();
  if(!nom || !endpoint){ toast("Indiquez au moins un nom et un endpoint.", "err"); return; }
  const ai = await Store.getAI(id);
  ai.apis.push({id:uid(), nom, endpoint, cle: cle ? "••••••••" : "", description, ts:Date.now()});
  await Store.saveAI(ai);
  
  route();
};

// Seuil : au-delà, le ZIP est traité en streaming natif Android (jusqu'à 3 Go).
const NATIVE_ZIP_THRESHOLD = 80 * 1024 * 1024; // 80 Mo

// Callback appelé par MainActivity après analyse native d'un gros ZIP.
window.VanelleNativeZipResult = async function(payloadJson){
  try{
    const data = typeof payloadJson === "string" ? JSON.parse(payloadJson) : payloadJson;
    const ai = await Store.getAI(data.aiId);
    if(!ai){ toast("IA introuvable.", "err"); return; }
    const files = data.files || [];
    files.forEach(f => ai.files.push(f));
    try{ await rebuildKnowledgeIndex(ai); }catch(e){
      toast("Documents lus ; index vectoriel partiel sur cet appareil.", "err");
    }
    await Store.saveAI(ai);
    
    route();
  }catch(e){
    toast("Résultat ZIP natif illisible.", "err");
  }
};

Actions.uploadFichiers = async (evt, id)=>{
  const files = Array.from(evt.target.files || []);
  // Réinitialiser immédiatement l'input pour permettre un nouvel upload
  // (même fichier ou autre) sans avoir à recharger la page.
  try{ evt.target.value = ""; }catch(_){}
  if(!files.length) return;
  const statusEl = document.getElementById("v-upload-status");
  const ai = await requireAI(id); if(!ai) return;
  let okCount = 0;
  for(const file of files){
    if(file.size > MAX_UPLOAD_BYTES){
      toast(`${file.name} dépasse la limite de 3 Go (${fmtSize(file.size)}).`, "err");
      continue;
    }
    // Gros ZIP → streaming natif Android (évite OOM WebView/JSZip)
    if(file.name.toLowerCase().endsWith(".zip") && file.size >= NATIVE_ZIP_THRESHOLD && window.AndroidVanelle?.openDataZipPicker){
      
      AndroidVanelle.openDataZipPicker(id);
      continue;
    }
    if(statusEl) statusEl.textContent = `Analyse de ${file.name} (${fmtSize(file.size)})…`;
    try{
      if(file.name.toLowerCase().endsWith(".zip")) await analyzeZip(file, ai);
      else await analyzePlainFile(file, ai);
      okCount++;
    }catch(e){ toast(`Impossible d'analyser ${file.name}.`, "err"); }
  }
  if(okCount === 0){
    if(statusEl) statusEl.textContent = "Aucun fichier analysé.";
    return;
  }
  try{ await rebuildKnowledgeIndex(ai); }catch(e){ toast("Les documents ont été lus, mais l'index vectoriel n'a pas pu être construit sur cet appareil.","err"); }
  await Store.saveAI(ai);
  if(statusEl) statusEl.textContent = okCount + " fichier(s) ajouté(s).";
  else toast(okCount + " fichier(s) ajouté(s) aux connaissances de " + (ai.nom||"l'IA") + ".", "ok");
  route();
};

Actions.openNativeZip = (id)=>{
  if(window.AndroidVanelle?.openDataZipPicker){
    AndroidVanelle.openDataZipPicker(id);
  } else {
    document.getElementById("v-upload")?.click();
  }
};

async function analyzeZip(file, ai){
  try{
    const zip = await JSZip.loadAsync(file);
    const entries = Object.values(zip.files).filter(f=>!f.dir);
    let added = 0;
    for(const entry of entries){
      const ext = (entry.name.split(".").pop()||"").toLowerCase();
      if(!["txt","md","csv","json","html","js","css","pdf"].includes(ext)) continue;
      let text = "";
      try{
        if(ext==="pdf"){
          if(!window.AndroidVanelle?.extractPdfText) continue; // pas de PDF hors app Android
          const b64 = await entry.async("base64");
          const r = AndroidVanelle.extractPdfText(b64) || "";
          text = r.startsWith("__error__") ? "" : r;
        } else {
          text = await entry.async("string");
        }
      }catch(e){ text = ""; }
      text = cleanText(text).slice(0, 5 * 1024 * 1024);
      if(!text) continue;
      const resume = text.slice(0, 600);
      const chunks = chunkText(text,900,120).map(t=>({id:uid(),text:t}));
      ai.files.push({
        id: uid(), nom: entry.name,
        taille: entry._data ? entry._data.uncompressedSize : text.length,
        type: ext, resume, chunks,
        source: file.name, ts: Date.now()
      });
      added++;
    }
    if(added === 0) throw new Error("zip-sans-texte");
  }catch(e){
    toast(`Impossible de lire ${file.name} (zip invalide).`, "err");
    throw e; // important : ne pas compter comme succès dans uploadFichiers
  }
}

async function analyzePlainFile(file, ai){
  const ext = (file.name.split(".").pop()||"").toLowerCase();
  if(!["txt","md","csv","json","html","js","css","pdf"].includes(ext)){
    throw new Error(`format-non-supporte:${ext||"inconnu"}`);
  }
  if(file.size > MAX_UPLOAD_BYTES) throw new Error("fichier-trop-grand");
  let text = "";
  if(ext==="pdf"){
    try{ text = await extractPdfTextViaNative(file); }
    catch(e){ throw new Error(e.message==="pdf-non-supporte" ? "pdf-non-supporte" : "lecture-pdf"); }
  } else {
    try{ text = await file.text(); }catch(e){ throw new Error("lecture-fichier"); }
  }
  text = cleanText(text).slice(0, 5 * 1024 * 1024);
  const resume = text.slice(0, 600);
  ai.files.push({
    id: uid(), nom: file.name, taille: file.size, type: ext,
    resume, chunks:chunkText(text,900,120).map(text=>({id:uid(),text})), source: file.name, ts: Date.now()
  });
}

Actions.importerIAZip = async (evt, id)=>{
  const file = evt.target.files?.[0];
  // Réinitialiser pour pouvoir importer un autre ZIP ensuite
  try{ evt.target.value = ""; }catch(_){}
  if(!file) return;
  if(file.size > MAX_UPLOAD_BYTES){
    toast(`${file.name} dépasse la limite de 3 Go (${fmtSize(file.size)}).`, "err");
    return;
  }
  try{
    const zip = await JSZip.loadAsync(file);
    const configEntry = zip.file("config.json");
    if(!configEntry){ toast("Ce zip ne contient pas de config.json — ce n'est pas une IA exportée par cette app.", "err"); return; }
    const configText = await configEntry.async("string");
    const imported = JSON.parse(configText);
    const ai = await Store.getAI(id);
    ai.training = [...ai.training, ...(imported.training||[])];
    ai.apis = [...ai.apis, ...(imported.apis||[])];
    ai.files = [...ai.files, ...(imported.files||[])];
    try{ await rebuildKnowledgeIndex(ai); }catch(e){}
    await Store.saveAI(ai);
        route();
  }catch(e){
    toast("Ce fichier zip n'a pas pu être lu.", "err");
  }
};

/* --- tab: apprentissage A à Z --- */
function renderTabApprentissage(body, ai){
  body.innerHTML = `
    <div class="grid cols-2">
      <div class="card">
        <h2>Enseigner une notion</h2>
        <p style="font-size:12px;color:var(--ink-soft);">Choisissez une catégorie, posez la question que quelqu'un pourrait poser, et donnez la réponse que votre IA doit connaître.</p>
        <label>Catégorie</label>
        <select id="t-cat">${CATEGORIES.map(c=>`<option>${c}</option>`).join("")}</select>
        <label>Question / situation</label>
        <input type="text" id="t-q" placeholder="Ex. Quels sont vos horaires ?">
        <label>Réponse que doit donner l'IA</label>
        <textarea id="t-a" placeholder="Ex. Nous répondons du lundi au vendredi, 9h–18h."></textarea>
        <button class="btn btn-stamp btn-block" style="margin-top:12px;" onclick="Actions.ajouterNotion('${ai.id}')">Ajouter à l'apprentissage</button>
      </div>
      <div class="card">
        <h2>Ce qu'elle sait déjà (${ai.training.length})</h2>
        ${CATEGORIES.map(cat=>{
          const items = ai.training.filter(t=>t.categorie===cat);
          if(!items.length) return "";
          return `<h3>${cat}</h3>` + items.map(t=>`
            <div class="list-row">
              <div><strong>${esc(t.question)}</strong><div class="meta">${esc(t.reponse)}</div></div>
              <button class="btn btn-ghost btn-sm" onclick="Actions.supprimerNotion('${ai.id}','${t.id}')">✕</button>
            </div>
          `).join("");
        }).join("") || `<p style="font-size:12.5px;color:var(--ink-soft);">Rien enseigné pour l'instant — commencez par l'identité de votre IA.</p>`}
      </div>
    </div>
  `;
}

Actions.ajouterNotion = async (id)=>{
  const categorie = document.getElementById("t-cat").value;
  const question = document.getElementById("t-q").value.trim();
  const reponse = document.getElementById("t-a").value.trim();
  if(!question || !reponse){ toast("Complétez la question et la réponse.", "err"); return; }
  const ai = await Store.getAI(id);
  ai.training.push({id:uid(), categorie, question, reponse, ts:Date.now()});
  try{ await rebuildKnowledgeIndex(ai); }catch(e){}
  await Store.saveAI(ai);
  
  route();
};

Actions.supprimerNotion = async (id, tid)=>{
  const ai = await Store.getAI(id);
  ai.training = ai.training.filter(t=>t.id!==tid);
  try{ await rebuildKnowledgeIndex(ai); }catch(e){ ai.knowledgeIndex=[]; }
  await Store.saveAI(ai);
  route();
};

/* --- tab: fichiers --- */
function renderTabFichiers(body, ai){
  body.innerHTML = `
    <div class="card">
      <h2>Fichiers analysés (${ai.files.length})</h2>
      ${ai.files.length===0 ? `<p style="font-size:12.5px;color:var(--ink-soft);">Aucun fichier pour l'instant. Ajoutez-en depuis l'onglet Vue d'ensemble.</p>` :
        ai.files.map(f=>`
          <div class="list-row">
            <div>
              <strong>${esc(f.nom)}</strong>
              <div class="meta">${f.type} · ${fmtSize(f.taille||0)} · issu de ${esc(f.source||"")}</div>
              ${f.resume ? `<div class="meta" style="margin-top:4px;font-style:italic;">${esc(f.resume.slice(0,140))}${f.resume.length>140?"…":""}</div>` : ""}
            </div>
            <button class="btn btn-ghost btn-sm" onclick="Actions.supprimerFichier('${ai.id}','${f.id}')">✕</button>
          </div>
        `).join("")}
    </div>
  `;
}

Actions.supprimerFichier = async (id, fid)=>{
  const ai = await Store.getAI(id);
  ai.files = ai.files.filter(f=>f.id!==fid);
  try{ await rebuildKnowledgeIndex(ai); }catch(e){ ai.knowledgeIndex=[]; }
  await Store.saveAI(ai);
  route();
};

/* --- tab: API --- */
function renderTabApi(body, ai){
  body.innerHTML = `
    <div class="card">
      <h2>Intégrations API (${ai.apis.length})</h2>
      ${ai.apis.length===0 ? `<p style="font-size:12.5px;color:var(--ink-soft);">Aucune API configurée. Ajoutez-en depuis l'onglet Vue d'ensemble.</p>` :
        ai.apis.map(a=>`
          <div class="list-row">
            <div>
              <strong>${esc(a.nom)}</strong>
              <div class="meta">${esc(a.endpoint)}${a.cle?" · clé enregistrée":""}</div>
              ${a.description ? `<div class="meta" style="margin-top:4px;">${esc(a.description)}</div>` : ""}
            </div>
            <button class="btn btn-ghost btn-sm" onclick="Actions.supprimerApi('${ai.id}','${a.id}')">✕</button>
          </div>
        `).join("")}
    </div>
  `;
}

Actions.supprimerApi = async (id, aid)=>{
  const ai = await Store.getAI(id);
  ai.apis = ai.apis.filter(a=>a.id!==aid);
  await Store.saveAI(ai);
  route();
};

/* --- tab: tester (interface type ChatGPT) --- */
function renderTabTester(body, ai){
  const remoteOk = !!(window.AndroidVanelle && AndroidVanelle.remoteState && AndroidVanelle.remoteState()==="configured");
  let localState = "";
  try{ localState = AndroidVanelle.modelState(); }catch(_){}
  const engineHint = (localState==="ready" || llmState==="on") ? "Moteur local prêt"
    : remoteOk ? "Moteur externe configuré"
    : (localState==="downloading" || llmState==="loading") ? ("Téléchargement… "+(llmProgressText||""))
    : localState==="downloaded" ? "Chargement en mémoire…"
    : "Menu ⋮ → Moteur externe, ou attendez Vanelle";
  const ep = (window.AndroidVanelle && AndroidVanelle.remoteEndpoint) ? (AndroidVanelle.remoteEndpoint()||"") : "";
  const md = (window.AndroidVanelle && AndroidVanelle.remoteModel) ? (AndroidVanelle.remoteModel()||"") : "";
  body.innerHTML = `
    <div class="gpt-shell">
      <div class="gpt-top">
        <div class="gpt-title">${esc(ai.nom)}</div>
        <div class="gpt-engine">${engineHint}</div>
        <div class="gpt-menu-wrap">
          <button type="button" class="gpt-menu-btn" id="gpt-menu-btn" aria-label="Menu">⋮</button>
          <div class="gpt-menu" id="gpt-menu" hidden>
            <button type="button" data-act="settings">Paramètres & system prompt</button>
            <button type="button" data-act="remote">Moteur externe</button>
            <button type="button" data-act="knowledge">📚 Ajouter aux connaissances</button>
            <button type="button" data-act="export">Exporter l'IA</button>
            <button type="button" data-act="deploy">Marquer déployée</button>
            <button type="button" data-act="clear">Effacer la conversation</button>
          </div>
          <input type="file" id="chat-knowledge-input" style="display:none" multiple accept=".zip,.txt,.md,.csv,.json,.html,.js,.css,.pdf,application/zip,text/*" onchange="Actions.uploadFichiers(event,'${ai.id}')">
        </div>
      </div>
      <div class="gpt-thread" id="chat-thread"></div>
      <div class="gpt-composer">
        <div class="gpt-attach-row" id="chat-attach-row" hidden></div>
        <div class="gpt-composer-input-row">
          <button type="button" class="gpt-attach-btn" id="chat-attach-btn" title="Joindre un fichier ou une image">+</button>
          <input type="file" id="chat-attach-input" style="display:none" multiple accept="image/*,.txt,.md,.csv,.json,.html,.js,.css,.pdf">
          <textarea id="chat-input" rows="1" placeholder="Envoyez un message…"></textarea>
          <button type="button" class="btn btn-stamp" id="chat-send">Envoyer</button>
        </div>
      </div>
    </div>
    <div class="gpt-modal" id="gpt-settings" hidden>
      <div class="gpt-modal-card">
        <h2>Paramètres — ${esc(ai.nom)}</h2>
        <label>System prompt (appliqué à chaque message)</label>
        <textarea id="set-system" rows="10" placeholder="Ex. Tu es un assistant commercial. Tu réponds toujours en français, de façon concise…">${esc(ai.systemPrompt||"")}</textarea>
        <p style="font-size:12px;color:var(--ink-soft);margin:8px 0 0;">Ce texte est injecté en instruction système réelle avant chaque réponse.</p>
        <label style="margin-top:14px;">Description</label>
        <textarea id="set-desc" rows="2">${esc(ai.description||"")}</textarea>
        <div class="gpt-modal-actions">
          <button type="button" class="btn btn-ghost" id="set-cancel">Fermer</button>
          <button type="button" class="btn btn-stamp" id="set-save">Enregistrer</button>
        </div>
      </div>
    </div>
    <div class="gpt-modal" id="gpt-remote" hidden>
      <div class="gpt-modal-card">
        <h2>Moteur externe (compatible OpenAI)</h2>
        <label>Endpoint HTTPS</label>
        <input type="url" id="rm-endpoint" placeholder="https://api.openai.com/v1" value="${esc(ep)}">
        <label>Modèle</label>
        <input type="text" id="rm-model" placeholder="gpt-4o-mini" value="${esc(md)}">
        <label>Clé API (chiffrée sur l'appareil)</label>
        <input type="password" id="rm-key" placeholder="sk-…">
        <p style="font-size:12px;color:var(--ink-soft);margin-top:8px;">Obligatoire en HTTPS. Utilisé si Vanelle locale n'est pas prête, ou en secours.</p>
        <div class="gpt-modal-actions">
          <button type="button" class="btn btn-ghost" id="rm-cancel">Fermer</button>
          <button type="button" class="btn btn-stamp" id="rm-save">Enregistrer</button>
        </div>
      </div>
    </div>
  `;
  renderChatThread(ai);

  const menuBtn = document.getElementById("gpt-menu-btn");
  const menu = document.getElementById("gpt-menu");
  menuBtn.onclick = (e)=>{
    e.preventDefault();
    e.stopPropagation();
    menu.hidden = !menu.hidden;
  };
  if(window._vanelleHideMenu) document.removeEventListener("click", window._vanelleHideMenu);
  window._vanelleHideMenu = (ev)=>{
    if(!menu || menu.hidden) return;
    if(menu.contains(ev.target) || ev.target===menuBtn) return;
    menu.hidden = true;
  };
  document.addEventListener("click", window._vanelleHideMenu);

  menu.querySelectorAll("button[data-act]").forEach(btn=>{
    btn.onclick = (e)=>{
      e.preventDefault();
      e.stopPropagation();
      menu.hidden = true;
      const act = btn.getAttribute("data-act");
      if(act==="settings") document.getElementById("gpt-settings").hidden = false;
      if(act==="remote") document.getElementById("gpt-remote").hidden = false;
      if(act==="knowledge") document.getElementById("chat-knowledge-input").click();
      if(act==="export") Actions.exportIA(ai.id);
      if(act==="deploy") Actions.deployer(ai.id);
      if(act==="clear"){ chatHistory[ai.id]=[]; renderChatThread(ai); }
    };
  });

  document.getElementById("set-cancel").onclick = ()=>{ document.getElementById("gpt-settings").hidden = true; };
  document.getElementById("set-save").onclick = async ()=>{
    const a = await Store.getAI(ai.id);
    a.systemPrompt = document.getElementById("set-system").value;
    a.description = document.getElementById("set-desc").value.trim();
    await Store.saveAI(a);
    document.getElementById("gpt-settings").hidden = true;
  };

  document.getElementById("rm-cancel").onclick = ()=>{ document.getElementById("gpt-remote").hidden = true; };
  document.getElementById("rm-save").onclick = ()=>{
    if(!window.AndroidVanelle || !AndroidVanelle.saveRemote){
      toast("Ouvrez cette page dans l'app Android Vanelle.","err");
      return;
    }
    const endpoint = document.getElementById("rm-endpoint").value.trim();
    const model = document.getElementById("rm-model").value.trim();
    const key = document.getElementById("rm-key").value;
    const r = AndroidVanelle.saveRemote(endpoint, model, key);
    if(r!=="saved"){
      toast(r==="invalid_https" ? "L'endpoint doit commencer par https://" : "Endpoint et modèle sont requis.","err");
      return;
    }
    document.getElementById("gpt-remote").hidden = true;
    // rafraîchir l'indicateur moteur sans perdre le chat
    const eng = document.querySelector(".gpt-engine");
    if(eng) eng.textContent = "Moteur externe configuré";
  };

  const input = document.getElementById("chat-input");
  const send = document.getElementById("chat-send");
  const doSend = ()=> Actions.envoyerMessage(ai.id);
  send.onclick = (e)=>{ e.preventDefault(); doSend(); };
  input.onkeydown = (e)=>{
    if(e.key==="Enter" && !e.shiftKey){ e.preventDefault(); doSend(); }
  };
  input.addEventListener("input", ()=>{
    input.style.height = "auto";
    input.style.height = Math.min(input.scrollHeight, 160) + "px";
  });

  const attachBtn = document.getElementById("chat-attach-btn");
  const attachInput = document.getElementById("chat-attach-input");
  attachBtn.onclick = (e)=>{ e.preventDefault(); attachInput.click(); };
  attachInput.onchange = (e)=> Actions.joindreFichiers(e, ai.id);
  renderAttachRow(ai.id);
}

/* --- pièces jointes du composer (par IA, avant envoi) --- */
const pendingAttachments = {};
const CHAT_ATTACH_MAX_BYTES = 8 * 1024 * 1024; // 8 Mo par fichier
const CHAT_ATTACH_TEXT_CLIP = 12000; // caractères max injectés en contexte

function renderAttachRow(aiId){
  const row = document.getElementById("chat-attach-row");
  if(!row) return;
  const items = pendingAttachments[aiId] || [];
  if(!items.length){ row.hidden = true; row.innerHTML = ""; return; }
  row.hidden = false;
  row.innerHTML = items.map(a=>`
    <span class="attach-chip" data-attach-id="${a.id}">
      ${a.kind==="image" ? `<img src="${a.dataUrl}" alt="">` : `<span>📄</span>`}
      <span class="attach-name">${esc(a.name)}</span>
      <button type="button" class="attach-remove" data-remove="${a.id}" title="Retirer">✕</button>
    </span>
  `).join("");
  row.querySelectorAll("[data-remove]").forEach(btn=>{
    btn.onclick = (e)=>{
      e.preventDefault();
      const rid = btn.getAttribute("data-remove");
      pendingAttachments[aiId] = (pendingAttachments[aiId]||[]).filter(a=>a.id!==rid);
      renderAttachRow(aiId);
    };
  });
}

Actions.joindreFichiers = async (evt, aiId)=>{
  const files = Array.from(evt.target.files || []);
  try{ evt.target.value = ""; }catch(_){}
  if(!files.length) return;
  pendingAttachments[aiId] = pendingAttachments[aiId] || [];
  const remoteOk = !!(window.AndroidVanelle && AndroidVanelle.remoteState && AndroidVanelle.remoteState()==="configured");
  let hasNewImage = false;
  for(const file of files){
    if(file.size > CHAT_ATTACH_MAX_BYTES){
      toast(`${file.name} dépasse ${fmtSize(CHAT_ATTACH_MAX_BYTES)}.`, "err");
      continue;
    }
    const isImage = file.type.startsWith("image/");
    const isPdf = file.name.toLowerCase().endsWith(".pdf");
    try{
      if(isImage){
        const dataUrl = await readFileAsDataUrl(file);
        pendingAttachments[aiId].push({id:uid(), kind:"image", name:file.name, mime:file.type, dataUrl});
        hasNewImage = true;
      } else if(isPdf){
        let text;
        try{ text = await extractPdfTextViaNative(file); }
        catch(e){
          toast(e.message==="pdf-non-supporte" ? "L'extraction PDF nécessite l'app Android Vanelle." : `Impossible de lire ${file.name}.`, "err");
          continue;
        }
        if(text.length > CHAT_ATTACH_TEXT_CLIP) text = text.slice(0, CHAT_ATTACH_TEXT_CLIP) + "\n[…tronqué]";
        pendingAttachments[aiId].push({id:uid(), kind:"text", name:file.name, content:text});
      } else {
        let text = await readFileAsText(file);
        if(text.length > CHAT_ATTACH_TEXT_CLIP) text = text.slice(0, CHAT_ATTACH_TEXT_CLIP) + "\n[…tronqué]";
        pendingAttachments[aiId].push({id:uid(), kind:"text", name:file.name, content:text});
      }
    }catch(e){ toast(`Impossible de lire ${file.name}.`, "err"); }
  }
  if(hasNewImage && !remoteOk){
    toast("Image jointe : configurez un moteur externe (⋮ → Moteur externe) pour qu'elle soit analysée.", "err");
  }
  renderAttachRow(aiId);
};

function readFileAsDataUrl(file){
  return new Promise((resolve, reject)=>{
    const r = new FileReader();
    r.onload = ()=> resolve(r.result);
    r.onerror = ()=> reject(r.error);
    r.readAsDataURL(file);
  });
}
function readFileAsText(file){
  return new Promise((resolve, reject)=>{
    const r = new FileReader();
    r.onload = ()=> resolve(String(r.result||""));
    r.onerror = ()=> reject(r.error);
    r.readAsText(file);
  });
}
function readFileAsBase64(file){
  return new Promise((resolve, reject)=>{
    const r = new FileReader();
    r.onload = ()=>{
      const s = String(r.result||"");
      resolve(s.slice(s.indexOf(",")+1)); // enlève le préfixe data:...;base64,
    };
    r.onerror = ()=> reject(r.error);
    r.readAsDataURL(file);
  });
}
const PDF_MAX_BYTES = 25 * 1024 * 1024; // 25 Mo, lu en mémoire par le pont natif
async function extractPdfTextViaNative(file){
  if(!window.AndroidVanelle?.extractPdfText) throw new Error("pdf-non-supporte");
  if(file.size > PDF_MAX_BYTES) throw new Error("pdf-trop-volumineux");
  const b64 = await readFileAsBase64(file);
  const text = AndroidVanelle.extractPdfText(b64) || "";
  if(text.startsWith("__error__")) throw new Error("pdf-extraction-echec");
  return text;
}

let chatHistory = {};

function renderChatThread(ai){
  const hist = chatHistory[ai.id] || [];
  const el = document.getElementById("chat-thread");
  if(!el) return;
  el.innerHTML = hist.map(m=>`<div class="msg ${m.who}">${esc(m.text)}${renderMsgAttachments(m.attachments)}</div>`).join("") ||
    `<div class="msg bot">Bonjour, je suis ${esc(ai.nom)}. Posez votre question.</div>`;
  el.scrollTop = el.scrollHeight;
}

function renderMsgAttachments(attachments){
  if(!attachments || !attachments.length) return "";
  return `<div class="msg-attachments">${attachments.map(a=>
    a.kind==="image"
      ? `<img src="${a.dataUrl}" alt="${esc(a.name)}">`
      : `<span class="msg-attach-file">📄 ${esc(a.name)}</span>`
  ).join("")}</div>`;
}

Actions.envoyerMessage = async (id)=>{
  const input = document.getElementById("chat-input");
  if(!input) return;
  const text = input.value.trim();
  const attachments = (pendingAttachments[id] || []).slice();
  if(!text && !attachments.length) return;
  const ai = await requireAI(id); if(!ai) return;
  chatHistory[id] = chatHistory[id] || [];
  chatHistory[id].push({who:"user", text, attachments});
  input.value = "";
  input.style.height = "auto";
  pendingAttachments[id] = [];
  renderAttachRow(id);
  renderChatThread(ai);
  chatHistory[id].push({who:"bot", text:"…"});
  renderChatThread(ai);
  try{
    const reply = await generateLLMReply(ai, chatHistory[id].slice(0,-1), text, attachments);
    chatHistory[id][chatHistory[id].length-1] = {who:"bot", text: reply};
  }catch(e){
    const reason = e?.message || "unknown-error";
    const human = {
      "no-ai-engine-configured":"Aucun moteur IA n'est prêt. Attendez la fin du téléchargement Vanelle, ou ouvrez ⋮ → Moteur externe.",
      "local-still-loading":"Vanelle télécharge encore le modèle. Réessayez dans un instant.",
      "local-inference-failed":"Le modèle est sur l'appareil mais n'a pas pu répondre (mémoire ou chargement).",
      "remote-inference-failed":"Le moteur externe n'a pas répondu. Vérifiez endpoint, modèle et clé (⋮ → Moteur externe).",
      "native-engine-required":"Ouvrez Vanelle dans l'application Android native."
    }[reason] || ("Échec du moteur IA ("+reason+").");
    chatHistory[id][chatHistory[id].length-1] = {who:"bot", text: human};
  }
  renderChatThread(ai);
};

Actions.exportIA = async (id)=>{
  try{
    const ai = await requireAI(id); if(!ai) return;
    const zip = new JSZip();
    const payload = {
      nom: ai.nom, description: ai.description, systemPrompt: ai.systemPrompt||"",
      modele: ai.modele, training: ai.training||[], apis: ai.apis||[],
      files: (ai.files||[]).map(f=>({
        id:f.id, nom:f.nom, taille:f.taille, type:f.type, resume:f.resume,
        chunks:f.chunks||[], source:f.source, ts:f.ts
      }))
    };
    zip.file("config.json", JSON.stringify(payload, null, 2));
    zip.file("README.txt", "IA exportée depuis Vanelle — réimportez via Vue d'ensemble > Ajouter une IA complète (ZIP).\n");
    const blob = await zip.generateAsync({type:"blob"});
    downloadBlob(blob, (slug(ai.nom)||"ia")+"-config.zip");
  }catch(e){
    toast("Export impossible.","err");
  }
};

Actions.deployer = async (id)=>{
  const ai = await Store.getAI(id);
  ai.deployed = true;
  ai.deployedAt = Date.now();
  await Store.saveAI(ai);

  const zip = new JSZip();
  zip.file("config.json", JSON.stringify(ai, null, 2));
  zip.file("chat.html", buildStandaloneChat(ai));
  zip.file("README.txt",
`"${ai.nom}" — déployée depuis Vanelle

Cette archive contient la configuration et les connaissances de l'IA.
Le moteur local Vanelle reste dans l’application Android. Pour une version
web réellement générative, configurez un endpoint distant compatible OpenAI
et utilisez-le avec un serveur sécurisé — aucune clé secrète ne doit être
placée dans un site statique.
`);
  const blob = await zip.generateAsync({type:"blob"});
  downloadBlob(blob, `${slug(ai.nom)}-deployee.zip`);
  
  route();
};

function buildStandaloneChat(ai){
  const dataJSON = JSON.stringify({
    nom: ai.nom, description: ai.description,
    training: ai.training, files: ai.files.map(f=>({nom:f.nom, resume:f.resume})),
  }).replace(/</g,"\\u003c");
  return `<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(ai.nom)}</title>
<style>
body{font-family:'Inter',system-ui,sans-serif;background:#0E0E10;color:#fff;margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}
.wrap{background:#fff;color:#0E0E10;max-width:440px;width:100%;border-radius:14px;padding:22px;box-shadow:0 20px 50px rgba(0,0,0,.35);}
h1{font-size:17px;margin:0 0 4px;font-weight:700;}
p.d{font-size:12.5px;color:#6B6B72;margin:0 0 10px;}
.thread{display:flex;flex-direction:column;gap:8px;max-height:340px;overflow-y:auto;margin-bottom:10px;}
.msg{padding:9px 12px;border-radius:8px;font-size:13.5px;max-width:82%;}
.user{align-self:flex-end;background:#3B8FCF;color:#fff;}
.bot{align-self:flex-start;background:#F7F7F9;color:#0E0E10;}
.row{display:flex;gap:8px;}
input{flex:1;padding:9px 11px;border-radius:8px;border:1.5px solid #E7E7EC;font-size:13.5px;}
button{background:#3B8FCF;color:#fff;border:none;border-radius:8px;padding:0 14px;font-weight:700;cursor:pointer;}
.llmbar{display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:11px;color:#6B6B72;font-family:monospace;margin-bottom:10px;border-top:1px solid #E7E7EC;padding-top:8px;}
.llmbar button{background:transparent;color:#0E0E10;border:1.5px solid #E7E7EC;padding:4px 8px;font-size:10.5px;font-weight:600;border-radius:6px;}
</style></head>
<body><div class="wrap">
<h1>${esc(ai.nom)}</h1>
<p class="d">${esc(ai.description||"")}</p>
<div class="thread" id="thread"></div>
<div class="row"><input id="in" placeholder="Écrivez un message…"><button onclick="send()">Envoyer</button></div>
<div class="llmbar"><span id="llmlabel">Vanelle locale non activée</span><button id="llmbtn" onclick="activerLLM()">Activer Vanelle</button></div>
</div>
<script type="module">
const DATA = ${dataJSON};
const thread = document.getElementById("thread");
let engine = null, llmOn = false;
function push(who,text){ const d=document.createElement("div"); d.className="msg "+who; d.textContent=text; thread.appendChild(d); thread.scrollTop=thread.scrollHeight; return d; }
function keywordAnswer(q){
  const words = new Set(q.toLowerCase().split(/[^a-zàâäéèêëïîôöùûüç0-9]+/i).filter(w=>w.length>2));
  let best=null,score=0;
  const pool = [
    ...DATA.training.map(t=>({text:t.reponse, hay:(t.question+" "+t.reponse).toLowerCase()})),
    ...DATA.files.map(f=>({text:"D'après "+f.nom+" : "+f.resume.slice(0,220), hay:(f.nom+" "+f.resume).toLowerCase()})),
  ];
  for(const item of pool){ let s=0; for(const w of words) if(item.hay.includes(w)) s++; if(s>score){score=s;best=item;} }
  if(best && score>0) return best.text;
  return "Je n'ai pas encore appris à répondre à ça.";
}
function systemPrompt(){
  const parts = ["Tu es \\""+DATA.nom+"\\", une IA. "+(DATA.description||"")];
  DATA.training.forEach(t=> parts.push("- "+t.question+" -> "+t.reponse));
  DATA.files.forEach(f=> parts.push("- "+f.nom+" : "+f.resume.slice(0,200)));
  parts.push("Réponds en français, en te basant sur ces informations quand elles s'appliquent. Si tu ne sais pas, dis-le.");
  return parts.join("\\n").slice(0,3500);
}
window.activerLLM = async function(){
  const label = document.getElementById("llmlabel");
  label.textContent = "Vanelle native est disponible dans l'application Android.";
};
window.send = async function(){
  const inp=document.getElementById("in"); const v=inp.value.trim(); if(!v) return;
  push("user",v); inp.value="";
  push("bot","Ce mini-site exporté contient les connaissances de cette IA, mais n'embarque pas le moteur natif Vanelle. Utilisez l'application Android pour l'inférence locale réelle.");
};
document.getElementById("in").addEventListener("keydown", e=>{ if(e.key==="Enter") window.send(); });
push("bot","Bonjour, je suis Vanelle. Posez-moi une question.");
</script>
</body></html>`;
}
