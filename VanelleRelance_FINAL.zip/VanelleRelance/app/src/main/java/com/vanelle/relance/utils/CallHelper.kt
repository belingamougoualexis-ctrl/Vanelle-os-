package com.vanelle.relance.utils

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat
import com.vanelle.relance.data.Client

object CallHelper {

    fun permissionAppelDirectAccordee(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED

    fun appeler(context: Context, client: Client) {
        val digits = client.telephone.filter { it.isDigit() }
        if (digits.isEmpty()) return
        val uri = Uri.parse("tel:+$digits")
        val action = if (permissionAppelDirectAccordee(context)) {
            Intent.ACTION_CALL
        } else {
            Intent.ACTION_DIAL
        }
        val intent = Intent(action, uri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
