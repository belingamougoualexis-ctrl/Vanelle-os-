package com.vanelle.relance.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.vanelle.relance.MainActivity

object NotificationHelper {

    const val CHANNEL_ID = "vanelle_rappels"
    private const val CHANNEL_NAME = "Rappels de relance"

    fun creerCanal(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alertes quand un client passe en retard de paiement"
                enableVibration(true)
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(canal)
        }
    }

    fun notifierClientsEnRetard(context: Context, noms: List<String>, nombre: Int) {
        if (nombre <= 0) return
        creerCanal(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val titre = if (nombre == 1) "1 client en retard" else "$nombre clients en retard"

        val texte = when {
            noms.isEmpty() -> "Ouvrez l'app pour relancer."
            noms.size == 1 -> "${noms[0]} — appuyez pour relancer (SMS / WhatsApp / Appel)"
            else -> {
                val liste = noms.take(3).joinToString(", ")
                val suite = if (noms.size > 3) "…" else ""
                "$liste$suite — ouvrez l'app pour relancer"
            }
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(titre)
            .setContentText(texte)
            .setStyle(NotificationCompat.BigTextStyle().bigText(texte))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .setVibrate(longArrayOf(0, 300, 200, 300))
            .build()

        try {
            NotificationManagerCompat.from(context).notify(1001, notification)
        } catch (_: SecurityException) {
            // Permission notifications refusée
        }
    }
}
