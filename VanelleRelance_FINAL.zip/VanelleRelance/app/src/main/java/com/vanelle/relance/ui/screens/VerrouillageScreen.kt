package com.vanelle.relance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.vanelle.relance.security.CryptoManager

@Composable
fun VerrouillageScreen(
    cryptoManager: CryptoManager,
    onDeverrouille: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var codeRecuperation by remember { mutableStateOf("") }
    var nouveauPin by remember { mutableStateOf("") }
    var modeRecuperation by remember { mutableStateOf(false) }
    var erreur by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.Lock,
            contentDescription = null,
            modifier = Modifier.size(56.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(16.dp))
        Text(
            "Vanelle Relance",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Entrez votre code PIN pour continuer",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(32.dp))

        if (!modeRecuperation) {
            OutlinedTextField(
                value = pin,
                onValueChange = {
                    if (it.length <= 6 && it.all { c -> c.isDigit() }) {
                        pin = it
                        erreur = null
                    }
                },
                label = { Text("Code PIN") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth()
            )
            erreur?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    if (cryptoManager.verifierPin(pin)) onDeverrouille()
                    else erreur = "Code PIN incorrect."
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Déverrouiller") }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { modeRecuperation = true; erreur = null }) {
                Text("PIN oublié ?")
            }
        } else {
            OutlinedTextField(
                value = codeRecuperation,
                onValueChange = { codeRecuperation = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(8) },
                label = { Text("Code de récupération") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = nouveauPin,
                onValueChange = {
                    if (it.length <= 6 && it.all { c -> c.isDigit() }) nouveauPin = it
                },
                label = { Text("Nouveau PIN (4-6 chiffres)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth()
            )
            erreur?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    if (nouveauPin.length !in 4..6) {
                        erreur = "Le nouveau PIN doit contenir 4 à 6 chiffres."
                    } else if (cryptoManager.reinitialiserAvecCodeRecuperation(codeRecuperation, nouveauPin)) {
                        onDeverrouille()
                    } else {
                        erreur = "Code de récupération incorrect."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Réinitialiser") }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { modeRecuperation = false; erreur = null }) {
                Text("Retour")
            }
        }
    }
}
