package com.vanelle.relance.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

data class ContactSimple(
    val nom: String,
    val telephone: String
)

object ContactsHelper {

    fun permissionAccordee(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    /**
     * Récupère les contacts qui ont au moins un numéro de téléphone.
     * Limité à 300 pour rester fluide.
     */
    fun chargerContacts(context: Context): List<ContactSimple> {
        if (!permissionAccordee(context)) return emptyList()

        val resultat = mutableListOf<ContactSimple>()
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )

        context.contentResolver.query(
            uri,
            projection,
            null,
            null,
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
        )?.use { cursor ->
            val idxNom = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val idxTel = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

            while (cursor.moveToNext() && resultat.size < 300) {
                val nom = cursor.getString(idxNom)?.trim().orEmpty()
                val telBrut = cursor.getString(idxTel)?.trim().orEmpty()
                val telPropre = telBrut.filter { it.isDigit() || it == '+' }

                if (nom.isNotBlank() && telPropre.length >= 8) {
                    // Évite les doublons exacts nom+numéro
                    if (resultat.none { it.nom == nom && it.telephone == telPropre }) {
                        resultat.add(ContactSimple(nom, telPropre))
                    }
                }
            }
        }
        return resultat
    }
}
