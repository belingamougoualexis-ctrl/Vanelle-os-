package com.vanelle.relance.work

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.vanelle.relance.VanelleRelanceApp

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            VanelleRelanceApp.planifierRappelsQuotidiens(context)
        }
    }
}
