package com.vanelle.relance.utils

import java.util.Locale

data class PaysTelephone(
    val codeIso: String,
    val nom: String,
    val indicatif: String,
    val drapeau: String,
    val exempleLocal: String,
    val longueurMinLocale: Int = 8,
    val longueurMaxLocale: Int = 12
)

object PhoneUtils {

    val paysSupportes = listOf(
        PaysTelephone("CI", "Côte d'Ivoire", "225", "🇨🇮", "07 00 00 00 00", 8, 10),
        PaysTelephone("SN", "Sénégal", "221", "🇸🇳", "77 000 00 00", 9, 9),
        PaysTelephone("BF", "Burkina Faso", "226", "🇧🇫", "70 00 00 00", 8, 8),
        PaysTelephone("ML", "Mali", "223", "🇲🇱", "70 00 00 00", 8, 8),
        PaysTelephone("GN", "Guinée", "224", "🇬🇳", "620 00 00 00", 9, 9),
        PaysTelephone("CM", "Cameroun", "237", "🇨🇲", "6 00 00 00 00", 9, 9),
        PaysTelephone("TG", "Togo", "228", "🇹🇬", "90 00 00 00", 8, 8),
        PaysTelephone("BJ", "Bénin", "229", "🇧🇯", "90 00 00 00", 8, 8),
        PaysTelephone("NE", "Niger", "227", "🇳🇪", "90 00 00 00", 8, 8),
        PaysTelephone("GA", "Gabon", "241", "🇬🇦", "06 00 00 00", 7, 9),
        PaysTelephone("CG", "Congo", "242", "🇨🇬", "06 000 00 00", 9, 9),
        PaysTelephone("CD", "RDC", "243", "🇨🇩", "81 000 00 00", 9, 9),
        PaysTelephone("FR", "France", "33", "🇫🇷", "6 00 00 00 00", 9, 9),
        PaysTelephone("BE", "Belgique", "32", "🇧🇪", "470 00 00 00", 8, 9),
        PaysTelephone("CH", "Suisse", "41", "🇨🇭", "78 000 00 00", 9, 9),
        PaysTelephone("CA", "Canada", "1", "🇨🇦", "514 000 0000", 10, 10),
        PaysTelephone("US", "États-Unis", "1", "🇺🇸", "202 000 0000", 10, 10),
        PaysTelephone("MA", "Maroc", "212", "🇲🇦", "6 00 00 00 00", 9, 9),
        PaysTelephone("TN", "Tunisie", "216", "🇹🇳", "20 000 000", 8, 8),
        PaysTelephone("DZ", "Algérie", "213", "🇩🇿", "5 00 00 00 00", 9, 9),
        PaysTelephone("OTHER", "Autre", "", "🌍", "numéro international complet", 8, 15)
    )

    fun paysParDefaut(): PaysTelephone {
        val codePays = Locale.getDefault().country.uppercase(Locale.ROOT)
        return paysSupportes.firstOrNull { it.codeIso == codePays }
            ?: paysSupportes.first { it.codeIso == "CI" }
    }

    fun construireNumeroInternational(indicatif: String, numeroLocal: String): String {
        val localPropre = numeroLocal.filter { it.isDigit() }
        val indicatifPropre = indicatif.filter { it.isDigit() }
        return if (indicatifPropre.isEmpty()) localPropre else "$indicatifPropre$localPropre"
    }

    fun formaterAffichage(numeroStocke: String): String {
        val digits = numeroStocke.filter { it.isDigit() }
        return if (digits.isNotEmpty()) "+$digits" else numeroStocke
    }

    /**
     * Détecte le pays à partir d'un numéro stocké (chiffres uniquement).
     * Retourne null si aucun indicatif connu ne correspond.
     */
    fun detecterPays(numeroStocke: String): PaysTelephone? {
        val digits = numeroStocke.filter { it.isDigit() }
        if (digits.isEmpty()) return null
        // On trie par longueur d'indicatif décroissante pour éviter les collisions (ex: 1 vs 12…)
        return paysSupportes
            .filter { it.indicatif.isNotEmpty() }
            .sortedByDescending { it.indicatif.length }
            .firstOrNull { digits.startsWith(it.indicatif) }
    }

    /**
     * Valide un numéro selon le pays sélectionné.
     * Retourne null si OK, sinon un message d'erreur lisible.
     */
    fun validerNumero(pays: PaysTelephone, numeroLocal: String): String? {
        val local = numeroLocal.filter { it.isDigit() }
        if (local.isEmpty()) return "Le numéro est obligatoire."

        if (pays.codeIso == "OTHER") {
            if (local.length < 8) return "Numéro trop court (minimum 8 chiffres)."
            if (local.length > 15) return "Numéro trop long (maximum 15 chiffres)."
            return null
        }

        if (local.length < pays.longueurMinLocale) {
            return "Numéro trop court pour ${pays.nom} (attendu ~${pays.longueurMinLocale} chiffres locaux)."
        }
        if (local.length > pays.longueurMaxLocale) {
            return "Numéro trop long pour ${pays.nom} (maximum ${pays.longueurMaxLocale} chiffres locaux)."
        }
        return null
    }

    /**
     * Message d'avertissement si le numéro final ne correspond à aucun pays connu
     * alors que l'utilisateur n'a pas choisi « Autre ».
     */
    fun avertissementPaysInconnu(paysChoisi: PaysTelephone, numeroComplet: String): String? {
        if (paysChoisi.codeIso == "OTHER") return null
        val detecte = detecterPays(numeroComplet)
        return if (detecte == null) {
            "Ce numéro ne correspond à aucun pays connu de la liste. Vérifiez l'indicatif ou choisissez « Autre »."
        } else null
    }
}
