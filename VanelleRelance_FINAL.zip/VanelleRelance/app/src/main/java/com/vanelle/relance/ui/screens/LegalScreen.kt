package com.vanelle.relance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.vanelle.relance.utils.PreferencesHelper

/**
 * Écran obligatoire au premier lancement.
 * L'utilisateur doit faire défiler jusqu'en bas pour activer le bouton Accepter.
 * Sans acceptation, l'app ne continue pas.
 */
@Composable
fun LegalScreen(
    prefsHelper: PreferencesHelper,
    onAccepte: () -> Unit
) {
    val scrollState = rememberScrollState()
    var aLuJusquAuBout by remember { mutableStateOf(false) }
    var caseCochee by remember { mutableStateOf(false) }

    // Détecte quand l'utilisateur arrive en bas du texte
    LaunchedEffect(scrollState.value, scrollState.maxValue) {
        if (scrollState.maxValue > 0 && scrollState.value >= scrollState.maxValue - 40) {
            aLuJusquAuBout = true
        }
    }

    val peutAccepter = aLuJusquAuBout && caseCochee

    Column(
        Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        Text(
            "Conditions & Confidentialité",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Veuillez lire entièrement ce document (faites défiler jusqu’en bas) puis accepter pour continuer.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))

        if (!aLuJusquAuBout) {
            Surface(
                color = MaterialTheme.colorScheme.tertiaryContainer,
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "⬇️ Faites défiler jusqu’en bas pour activer l’acceptation",
                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(8.dp))
        }

        Card(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ——— CONDITIONS D'UTILISATION ———
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Description, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Conditions d’utilisation", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }

                TextSection(
                    "1. Objet de l’application",
                    "Vanelle Relance est une application mobile destinée à la gestion locale de créances et à la relance de clients (rappels de paiement). Elle est fournie « en l’état » pour un usage professionnel ou personnel de suivi de dettes."
                )
                TextSection(
                    "2. Utilisation responsable",
                    "Vous vous engagez à utiliser l’application conformément aux lois en vigueur dans votre pays, notamment en matière de recouvrement amiable, de protection des données et de communications électroniques (SMS, appels, messageries). Toute utilisation abusive, harcèlement ou envoi de messages illicites est strictement interdite et relève de votre seule responsabilité."
                )
                TextSection(
                    "3. Relances (SMS, WhatsApp, appels)",
                    "• SMS : envoyés depuis la carte SIM de votre téléphone ; des frais opérateur peuvent s’appliquer.\n" +
                    "• WhatsApp : le message est pré-rempli ; vous devez valider manuellement l’envoi dans WhatsApp.\n" +
                    "• Appels : lancés depuis votre téléphone.\n" +
                    "Vous êtes seul responsable du contenu des messages et du respect du droit applicable (consentement, horaires de contact, etc.)."
                )
                TextSection(
                    "4. Compte et sécurité",
                    "L’application peut être protégée par un code PIN local. Vous êtes responsable de la confidentialité de ce code et du code de récupération. En cas de perte du téléphone sans sauvegarde, les données locales peuvent être irrécupérables."
                )
                TextSection(
                    "5. Disponibilité",
                    "Nous ne garantissons pas un fonctionnement ininterrompu. Les rappels automatiques dépendent des mécanismes du système Android (WorkManager) et des paramètres d’économie d’énergie de votre appareil."
                )
                TextSection(
                    "6. Limitation de responsabilité",
                    "L’éditeur ne saurait être tenu responsable des dommages directs ou indirects liés à l’usage de l’application, aux relances effectuées, à la perte de données locales, ou à un usage non conforme. L’application n’est pas un cabinet de recouvrement : elle est un outil d’aide à la gestion."
                )
                TextSection(
                    "7. Évolution",
                    "Les présentes conditions peuvent être mises à jour. Une nouvelle version pourra vous être présentée pour acceptation avant de continuer à utiliser l’application."
                )

                HorizontalDivider(Modifier.padding(vertical = 8.dp))

                // ——— POLITIQUE DE CONFIDENTIALITÉ ———
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Politique de confidentialité", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }

                TextSection(
                    "1. Données collectées",
                    "Toutes les données (noms, numéros de téléphone, montants, notes, historique de relances) sont stockées uniquement sur votre appareil. Aucune donnée client n’est envoyée vers un serveur distant par l’application."
                )
                TextSection(
                    "2. Finalités",
                    "Les données servent exclusivement à :\n" +
                    "• gérer votre liste de clients et de créances ;\n" +
                    "• préparer et envoyer des relances (SMS, WhatsApp, appels) ;\n" +
                    "• afficher des rappels et statistiques locales ;\n" +
                    "• sécuriser l’accès par PIN (empreintes stockées de façon chiffrée)."
                )
                TextSection(
                    "3. Permissions",
                    "L’application peut demander :\n" +
                    "• SMS — pour envoyer des relances ;\n" +
                    "• Appels — pour lancer un appel de relance ;\n" +
                    "• Contacts — pour importer un contact existant ;\n" +
                    "• Notifications — pour vous alerter des échéances.\n" +
                    "Vous pouvez refuser ; les fonctions concernées resteront indisponibles jusqu’à autorisation."
                )
                TextSection(
                    "4. Partage des données",
                    "L’application ne vend ni ne partage vos données avec des tiers. Les SMS, appels ou messages WhatsApp transitent uniquement par les services de votre opérateur ou de WhatsApp selon votre action."
                )
                TextSection(
                    "5. Conservation",
                    "Les données restent sur votre téléphone jusqu’à suppression manuelle (client par client ou désinstallation de l’application). La désinstallation efface en principe les données locales de l’app."
                )
                TextSection(
                    "6. Sécurité",
                    "Le code PIN et le code de récupération sont stockés sous forme d’empreinte (hash) dans un stockage chiffré (EncryptedSharedPreferences). Aucun mot de passe en clair n’est conservé."
                )
                TextSection(
                    "7. Vos droits",
                    "Vous pouvez à tout moment consulter, modifier ou supprimer les données clients dans l’application. Pour toute question relative à cette politique, contactez l’éditeur de l’application Vanelle Relance."
                )
                TextSection(
                    "8. Acceptation",
                    "En cochant la case et en appuyant sur « J’ai lu et j’accepte », vous confirmez avoir lu l’intégralité des Conditions d’utilisation et de la Politique de confidentialité, et vous en acceptez les termes."
                )

                Spacer(Modifier.height(24.dp))
                Text(
                    "— Fin du document —",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(8.dp))
            }
        }

        Spacer(Modifier.height(12.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Checkbox(
                checked = caseCochee,
                onCheckedChange = { if (aLuJusquAuBout) caseCochee = it },
                enabled = aLuJusquAuBout
            )
            Text(
                if (aLuJusquAuBout)
                    "J’ai lu l’intégralité et j’accepte les Conditions d’utilisation et la Politique de confidentialité."
                else
                    "Faites défiler jusqu’en bas pour pouvoir cocher cette case.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(8.dp))

        Button(
            onClick = {
                if (peutAccepter) {
                    prefsHelper.conditionsAcceptees = true
                    onAccepte()
                }
            },
            enabled = peutAccepter,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                if (peutAccepter) "J’ai lu et j’accepte"
                else "Lecture obligatoire jusqu’en bas"
            )
        }
    }
}

@Composable
private fun TextSection(titre: String, corps: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(titre, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
        Text(corps, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
