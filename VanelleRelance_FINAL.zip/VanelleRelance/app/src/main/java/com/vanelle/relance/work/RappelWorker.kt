package com.vanelle.relance.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.vanelle.relance.data.AppDatabase
import com.vanelle.relance.data.StatutDette
import com.vanelle.relance.utils.NotificationHelper
import kotlinx.coroutines.flow.first

class RappelWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val dao = AppDatabase.getInstance(applicationContext).clientDao()
            val maintenant = System.currentTimeMillis()
            val clients = dao.getTous().first()

            val nouveauxNoms = mutableListOf<String>()

            clients.forEach { client ->
                if (client.statut != StatutDette.PAYEE &&
                    client.statut != StatutDette.EN_RETARD &&
                    client.dateEcheance < maintenant
                ) {
                    dao.mettreAJour(client.copy(statut = StatutDette.EN_RETARD))
                    nouveauxNoms.add(client.nom)
                }
            }

            // Liste à jour après mises à jour
            val apres = dao.getTous().first()
            val enRetard = apres.filter { it.statut == StatutDette.EN_RETARD }
            if (enRetard.isEmpty()) return Result.success()

            // Priorité : nouveaux retards du jour, sinon rappel des existants
            val noms = if (nouveauxNoms.isNotEmpty()) nouveauxNoms else enRetard.map { it.nom }
            NotificationHelper.notifierClientsEnRetard(
                applicationContext,
                noms,
                enRetard.size
            )
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
