package com.vanelle.relance.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Gère le verrouillage de l'app :
 * - un code PIN à 4-6 chiffres, choisi par l'utilisateur
 * - un code de récupération à 8 caractères, généré une seule fois et
 *   affiché à l'utilisateur pour qu'il le note (permet de réinitialiser le PIN)
 *
 * Tout est stocké dans un fichier chiffré (EncryptedSharedPreferences),
 * jamais en clair. On ne stocke que des empreintes SHA-256, jamais le PIN
 * ou le code de récupération en clair.
 */
class CryptoManager(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "vanelle_relance_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private fun hash(valeur: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(valeur.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun estConfigure(): Boolean = prefs.contains("pin_hash")

    /** Retourne le code de récupération en clair UNE SEULE FOIS, à l'écran de création du PIN. */
    fun configurerPin(pin: String): String {
        val codeRecuperation = genererCodeRecuperation()
        prefs.edit()
            .putString("pin_hash", hash(pin))
            .putString("recovery_hash", hash(codeRecuperation))
            .apply()
        return codeRecuperation
    }

    fun verifierPin(pin: String): Boolean {
        return prefs.getString("pin_hash", null) == hash(pin)
    }

    fun reinitialiserAvecCodeRecuperation(codeRecuperation: String, nouveauPin: String): Boolean {
        val correspond = prefs.getString("recovery_hash", null) == hash(codeRecuperation)
        if (correspond) {
            prefs.edit().putString("pin_hash", hash(nouveauPin)).apply()
        }
        return correspond
    }

    private fun genererCodeRecuperation(): String {
        val caracteres = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // sans O/0/I/1 ambigus
        val random = SecureRandom()
        return (1..8).map { caracteres[random.nextInt(caracteres.length)] }.joinToString("")
    }
}
