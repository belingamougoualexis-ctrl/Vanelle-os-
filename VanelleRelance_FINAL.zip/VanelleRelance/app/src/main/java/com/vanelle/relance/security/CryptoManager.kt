package com.vanelle.relance.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Verrouillage PIN + code de récupération.
 * Stockage chiffré via EncryptedSharedPreferences (security-crypto 1.0.0).
 * On ne stocke que des empreintes SHA-256, jamais le PIN en clair.
 */
class CryptoManager(context: Context) {

    private val prefs: SharedPreferences = try {
        val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        EncryptedSharedPreferences.create(
            "vanelle_relance_secure_prefs",
            masterKeyAlias,
            context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Fallback si le chiffrement matériel échoue (émulateur rare)
        context.getSharedPreferences("vanelle_relance_secure_prefs_fallback", Context.MODE_PRIVATE)
    }

    private fun hash(valeur: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(valeur.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun estConfigure(): Boolean = prefs.contains("pin_hash")

    /** Retourne le code de récupération en clair UNE SEULE FOIS à la configuration. */
    fun configurerPin(pin: String): String {
        val codeRecuperation = genererCodeRecuperation()
        prefs.edit()
            .putString("pin_hash", hash(pin))
            .putString("recovery_hash", hash(codeRecuperation))
            .apply()
        return codeRecuperation
    }

    fun verifierPin(pin: String): Boolean {
        return prefs.getString("pin_hash", null) == hash(pin)
    }

    fun reinitialiserAvecCodeRecuperation(codeRecuperation: String, nouveauPin: String): Boolean {
        val correspond = prefs.getString("recovery_hash", null) == hash(codeRecuperation)
        if (correspond) {
            prefs.edit().putString("pin_hash", hash(nouveauPin)).apply()
        }
        return correspond
    }

    private fun genererCodeRecuperation(): String {
        val caracteres = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val random = SecureRandom()
        return (1..8).map { caracteres[random.nextInt(caracteres.length)] }.joinToString("")
    }
}
