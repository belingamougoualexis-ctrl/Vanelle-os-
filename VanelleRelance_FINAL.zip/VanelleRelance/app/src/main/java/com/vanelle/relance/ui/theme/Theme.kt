package com.vanelle.relance.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val VanelleOrange = Color(0xFFFF7A3D)
val VanelleOrangeDark = Color(0xFFE85D25)
val VanellePurple = Color(0xFF4A2C5E)
val VanelleGold = Color(0xFFF4B740)
val VanelleBg = Color(0xFFFFF8F2)
val VanelleBgDark = Color(0xFF1E1424)

private val LightColors = lightColorScheme(
    primary = VanelleOrange,
    onPrimary = Color.White,
    secondary = VanelleGold,
    tertiary = VanellePurple,
    background = VanelleBg,
    surface = Color.White
)

private val DarkColors = darkColorScheme(
    primary = VanelleOrange,
    onPrimary = Color.White,
    secondary = VanelleGold,
    tertiary = VanellePurple,
    background = VanelleBgDark,
    surface = Color(0xFF2A1E33)
)

@Composable
fun VanelleRelanceTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
