package com.vanelle.relance.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class ClientViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getInstance(application).clientDao()

    val tousLesClients = dao.getTous()
    val clientsEnRetard = dao.getEnRetard()
    val totalDu = dao.getTotalDu()
    val totalRecupere = dao.getTotalRecupere()

    fun clientsOublies() = dao.getOublies(
        System.currentTimeMillis() - TimeUnit.DAYS.toMillis(21)
    )

    fun ajouter(client: Client) = viewModelScope.launch {
        dao.inserer(client)
    }

    fun mettreAJour(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client)
    }

    fun supprimer(client: Client) = viewModelScope.launch {
        dao.supprimer(client)
    }

    fun marquerPaye(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client.copy(statut = StatutDette.PAYEE))
    }

    /** Remet une dette payée en « En cours » */
    fun marquerEnCours(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client.copy(statut = StatutDette.EN_COURS))
    }

    fun enregistrerRelance(client: Client) = viewModelScope.launch {
        dao.mettreAJour(
            client.copy(
                nombreRelances = client.nombreRelances + 1,
                dernierContact = System.currentTimeMillis()
            )
        )
    }
}
