package com.vanelle.relance.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

/**
 * Préférences utilisateur (messages personnalisés + acceptation légale).
 */
class PreferencesHelper(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("vanelle_relance_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_MSG_1 = "msg_relance_1"
        private const val KEY_MSG_2 = "msg_relance_2"
        private const val KEY_MSG_3 = "msg_relance_3"
        private const val KEY_LEGAL_ACCEPTED = "legal_accepted_v1"

        val MSG_DEFAUT_1 =
            "Bonjour {nom}, un rappel amical : vous devez {montant} FCFA, échéance le {date}. Merci de régulariser dès que possible."
        val MSG_DEFAUT_2 =
            "Bonjour {nom}, nous revenons vers vous concernant les {montant} FCFA dus depuis le {date}. Merci de nous contacter pour régulariser."
        val MSG_DEFAUT_3 =
            "Bonjour {nom}, ceci est une relance importante : {montant} FCFA restent dus depuis le {date}. Merci de nous recontacter rapidement."
    }

    var messageRelance1: String
        get() = prefs.getString(KEY_MSG_1, MSG_DEFAUT_1) ?: MSG_DEFAUT_1
        set(value) = prefs.edit { putString(KEY_MSG_1, value) }

    var messageRelance2: String
        get() = prefs.getString(KEY_MSG_2, MSG_DEFAUT_2) ?: MSG_DEFAUT_2
        set(value) = prefs.edit { putString(KEY_MSG_2, value) }

    var messageRelance3: String
        get() = prefs.getString(KEY_MSG_3, MSG_DEFAUT_3) ?: MSG_DEFAUT_3
        set(value) = prefs.edit { putString(KEY_MSG_3, value) }

    /** True uniquement après lecture complète + acceptation des CGU / confidentialité. */
    var conditionsAcceptees: Boolean
        get() = prefs.getBoolean(KEY_LEGAL_ACCEPTED, false)
        set(value) = prefs.edit { putBoolean(KEY_LEGAL_ACCEPTED, value) }

    fun resetMessages() {
        prefs.edit {
            remove(KEY_MSG_1)
            remove(KEY_MSG_2)
            remove(KEY_MSG_3)
        }
    }
}
