package com.vanelle.relance.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

object PermissionHelper {

    val PERMISSIONS_REQUISES: Array<String> = buildList {
        add(Manifest.permission.SEND_SMS)
        add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    fun estAccordee(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun toutesAccordees(context: Context): Boolean =
        PERMISSIONS_REQUISES.all { estAccordee(context, it) }

    fun permissionsManquantes(context: Context): Array<String> =
        PERMISSIONS_REQUISES.filter { !estAccordee(context, it) }.toTypedArray()

    fun messageRaison(permission: String): String = when (permission) {
        Manifest.permission.SEND_SMS ->
            "L'autorisation d'envoyer des SMS est nécessaire pour relancer vos clients directement depuis l'application."
        Manifest.permission.CALL_PHONE ->
            "L'autorisation d'appel est nécessaire pour passer des appels de relance en un clic."
        Manifest.permission.READ_CONTACTS ->
            "L'accès aux contacts permet de retrouver facilement un client déjà enregistré dans votre téléphone."
        Manifest.permission.POST_NOTIFICATIONS ->
            "Les notifications vous alertent des échéances et des clients en retard."
        else -> "Cette autorisation est nécessaire au bon fonctionnement de l'application."
    }

    fun titrePermission(permission: String): String = when (permission) {
        Manifest.permission.SEND_SMS -> "SMS"
        Manifest.permission.CALL_PHONE -> "Appels"
        Manifest.permission.READ_CONTACTS -> "Contacts"
        Manifest.permission.POST_NOTIFICATIONS -> "Notifications"
        else -> "Permission"
    }
}
