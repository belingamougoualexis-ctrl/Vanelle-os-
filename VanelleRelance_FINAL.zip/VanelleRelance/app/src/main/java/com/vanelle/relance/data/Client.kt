package com.vanelle.relance.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class StatutDette {
    EN_COURS,
    PAYEE,
    EN_RETARD
}

@Entity(tableName = "clients")
data class Client(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nom: String,
    val telephone: String,
    val montant: Double,
    val dateEcheance: Long,          // timestamp epoch millis
    val statut: StatutDette = StatutDette.EN_COURS,
    val nombreRelances: Int = 0,
    val dernierContact: Long? = null,
    val note: String = ""
)
