package com.vanelle.relance

import android.app.Application
import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.vanelle.relance.utils.NotificationHelper
import com.vanelle.relance.work.RappelWorker
import java.util.concurrent.TimeUnit

class VanelleRelanceApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.creerCanal(this)
        planifierRappelsQuotidiens(this)
    }

    companion object {
        fun planifierRappelsQuotidiens(context: Context) {
            val request = PeriodicWorkRequestBuilder<RappelWorker>(24, TimeUnit.HOURS)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "verification_echeances",
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }
}
