package com.vanelle.relance.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.platform.LocalTextToolbar
import androidx.compose.ui.platform.TextToolbar
import androidx.compose.ui.platform.TextToolbarStatus

/**
 * Barre d'outils texte vide : empêche le menu Copier / Partager
 * sur les textes statiques de l'interface.
 * Les champs de saisie (OutlinedTextField) restent éditables.
 */
object EmptyTextToolbar : TextToolbar {
    override val status: TextToolbarStatus = TextToolbarStatus.Hidden

    override fun hide() = Unit

    override fun showMenu(
        rect: Rect,
        onCopyRequested: (() -> Unit)?,
        onPasteRequested: (() -> Unit)?,
        onCutRequested: (() -> Unit)?,
        onSelectAllRequested: (() -> Unit)?
    ) = Unit
}

@Composable
fun DisableCopyText(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalTextToolbar provides EmptyTextToolbar) {
        content()
    }
}
