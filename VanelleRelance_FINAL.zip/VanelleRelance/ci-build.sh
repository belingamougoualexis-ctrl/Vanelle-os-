#!/usr/bin/env bash
set -euo pipefail

# Usage in GitHub Actions:
#   ANDROID_DIR=./VanelleRelance bash VanelleRelance/ci-build.sh
# or from repo root after checkout:
#   cd VanelleRelance && ./ci-build.sh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ANDROID_DIR="${ANDROID_DIR:-$SCRIPT_DIR}"

echo "==> Android project: $ANDROID_DIR"
cd "$ANDROID_DIR"

if [[ ! -f "./gradlew" ]]; then
  echo "ERROR: gradlew introuvable dans $ANDROID_DIR"
  echo "Contenu du dossier :"
  ls -la
  exit 1
fi

chmod +x ./gradlew

echo "==> Gradle assembleDebug"
./gradlew assembleDebug --stacktrace --no-daemon

echo "==> OK — APK généré dans app/build/outputs/apk/debug/"
