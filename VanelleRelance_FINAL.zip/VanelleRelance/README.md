# Vanelle Relance — Version finale 1.3

Application Android **réelle et complète** de gestion / relance de créances clients.

**100 % locale — aucune API externe requise.**

---

## Comportement des relances

| Canal | Comportement |
|-------|----------------|
| **SMS** | Envoi **automatique** depuis la carte SIM du téléphone |
| **WhatsApp** | Message **pré-rempli** → WhatsApp s’ouvre → **l’utilisateur appuie sur Envoyer** |
| **Appel** | L’appel est **lancé** depuis le téléphone |

### Rappels même si l’app est fermée
- WorkManager vérifie les échéances **tous les jours**
- Les clients en retard passent automatiquement au statut « En retard »
- Une **notification système** s’affiche (où que soit l’utilisateur)
- Au clic sur la notification → l’app s’ouvre pour relancer

---

## Fonctionnalités

### Clients
- Ajout / édition / suppression
- Import depuis les **Contacts** du téléphone
- Format téléphone **international** (sélecteur de pays, validation, avertissement si pays inconnu)
- Notes, recherche, **filtres avec compteurs**, **tri**
- Export / partage de la liste
- Réouvrir une dette payée
- Anti-doublon

### Relance
- SMS automatique, WhatsApp pré-rempli, Appel
- Messages **personnalisables** (3 niveaux) — placeholders `{nom}` `{montant}` `{date}`
- Confirmation avant « Marquer payé »
- Affichage du dernier contact

### Sécurité & permissions
- PIN + code de récupération (chiffré)
- Permissions demandées au démarrage + re-demande intelligente

### Autres écrans
- **Radar** (priorité du jour)
- **Oubliés** (≥ 21 jours sans contact)
- **Sommes** (total dû / récupéré / taux)

---

## Premier lancement

1. **Conditions d’utilisation + Politique de confidentialité**
   - Lecture obligatoire jusqu’en bas (défilement)
   - Case à cocher puis « J’ai lu et j’accepte »
   - Sans acceptation, l’app ne continue pas
2. Configuration / saisie du PIN (si activé)
3. Demande des permissions système
4. Accès à l’application

## Compiler & lancer

1. Installez **Android Studio**
2. `File → Open` → dossier `VanelleRelance`
3. Laissez Gradle synchroniser
4. Branchez un téléphone ou lancez un émulateur
5. Bouton **Run ▶**

- minSdk 26 / targetSdk 34  
- Kotlin + Jetpack Compose + Room + WorkManager  

---

## Structure

```
app/src/main/java/com/vanelle/relance/
├── MainActivity.kt
├── VanelleRelanceApp.kt
├── data/          (Client, Dao, Database, ViewModel)
├── ui/screens/    (tous les écrans)
├── ui/theme/
├── utils/         (Phone, Permissions, SMS, WhatsApp, Call, Contacts, Notifications, Prefs)
├── security/      (PIN)
└── work/          (RappelWorker + BootReceiver)
```

Prêt pour usage réel et publication (en justifiant les permissions SMS/Appel pour la gestion de créances).
