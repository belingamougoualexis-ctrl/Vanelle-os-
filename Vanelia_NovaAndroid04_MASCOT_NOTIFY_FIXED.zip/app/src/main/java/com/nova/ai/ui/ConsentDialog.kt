package com.nova.ai.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.nova.ai.ErrorCenter
import com.nova.ai.LegalConsent

@Composable
fun LocalAiConsentDialog(onAccepted: () -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Activer le moteur local de Vanelia") },
        text = {
            Column {
                Text("Vanelia peut télécharger un petit moteur IA open source et l'exécuter directement sur ton téléphone. Cela permet à la conversation de fonctionner localement, sans envoyer chaque message à un serveur IA.")
                Text("\nAvant le téléchargement, lis les conditions de licence. Si tu refuses, le moteur local ne sera pas installé et Vanelia utilisera uniquement les fonctions disponibles sans ce moteur.")
            }
        },
        confirmButton = {
            TextButton(onClick = {
                LegalConsent.setAccepted(context, true)
                onAccepted()
            }) { Text("J'accepte") }
        },
        dismissButton = {
            androidx.compose.foundation.layout.Row {
                TextButton(onClick = { LegalConsent.openLicense(context) }) { Text("Lire la licence") }
                TextButton(onClick = {
                    ErrorCenter.report(
                        "Moteur local non activé",
                        "Tu as refusé les conditions. Vanelia ne peut donc pas télécharger ni activer le moteur local tant que tu ne les as pas acceptées. Les autres fonctions de l'application peuvent continuer à fonctionner."
                    )
                    onDismiss()
                }) { Text("Refuser") }
            }
        }
    )
}
