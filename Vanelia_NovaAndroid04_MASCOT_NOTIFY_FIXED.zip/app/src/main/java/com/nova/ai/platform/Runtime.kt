package com.nova.ai.platform
enum class ReadinessState { READY, MODEL_MISSING, RUNTIME_MISSING, ERROR }
data class RuntimeCheck(val state: ReadinessState, val message: String)
