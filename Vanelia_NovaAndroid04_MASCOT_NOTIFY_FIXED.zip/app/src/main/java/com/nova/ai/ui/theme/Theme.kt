package com.nova.ai.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val Dark = darkColorScheme(primary=Color(0xFFFF4FA3), secondary=Color(0xFFFFD700), background=Color(0xFF0D0D0D), surface=Color(0xFF151515), onBackground=Color.White, onSurface=Color.White)
@Composable fun VanelleTheme(content: @Composable () -> Unit) { MaterialTheme(colorScheme=Dark, content=content) }
