package com.nova.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.nova.ai.ui.VanelleRoot

class MainActivity : ComponentActivity() {
    private lateinit var voice: VoiceEngine
    private lateinit var permissionManager: PermissionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        voice = VoiceEngine(this)
        permissionManager = PermissionManager(this)
        setContent { VanelleRoot() }
        // Les permissions sensibles sont demandées au premier démarrage, conformément au choix explicite demandé.
        permissionManager.requestAtStartup()
    }

    override fun onDestroy() {
        voice.shutdown()
        super.onDestroy()
    }
}
