package com.nova.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class PermissionManager(private val activity: ComponentActivity) {
    private val required = buildList {
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }

    private val launcher = activity.registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        results.filterValues { !it }.keys.forEach { permission ->
            val label = when (permission) {
                Manifest.permission.CAMERA -> "la caméra"
                Manifest.permission.RECORD_AUDIO -> "le microphone"
                Manifest.permission.POST_NOTIFICATIONS -> "les notifications"
                else -> permission
            }
            ErrorCenter.report(
                "Autorisation refusée",
                "Vanelia ne peut pas utiliser $label. Cette fonction restera indisponible tant que l'autorisation n'est pas accordée. Tu peux l'autoriser plus tard dans les réglages Android."
            )
        }
    }

    fun requestAtStartup() {
        val missing = required.filter {
            ContextCompat.checkSelfPermission(activity, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) launcher.launch(missing.toTypedArray())
    }

    companion object {
        fun has(context: Context, permission: String): Boolean =
            ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }
}
