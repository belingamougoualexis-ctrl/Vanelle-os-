package com.nova.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Centralise les erreurs réelles et les expose à toutes les interfaces de l'application. */
object ErrorCenter {
    data class AppError(val id: Long, val title: String, val reason: String)
    private val _current = MutableStateFlow<AppError?>(null)
    val current: StateFlow<AppError?> = _current.asStateFlow()
    private val main = Handler(Looper.getMainLooper())

    fun report(title: String, reason: String, context: Context? = null) {
        val safeReason = reason.trim().ifBlank { "La cause exacte n'a pas été fournie par le système." }
        main.post { _current.value = AppError(System.currentTimeMillis(), title, safeReason) }
    }

    fun clear(id: Long? = null) {
        main.post {
            if (id == null || _current.value?.id == id) _current.value = null
        }
    }
}
