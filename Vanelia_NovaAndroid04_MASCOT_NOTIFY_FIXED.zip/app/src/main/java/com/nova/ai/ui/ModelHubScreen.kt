package com.nova.ai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.nova.ai.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ModelHubScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var consent by remember { mutableStateOf(LegalConsent.accepted(context)) }
    var showConsent by remember { mutableStateOf(false) }
    var busyId by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Vanelia est prête.") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Vanelia", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("Le moteur local est téléchargé depuis une source publique et exécuté directement sur l'appareil. Lis la licence avant la première installation.")
        Spacer(Modifier.height(12.dp))
        ErrorOverlay()
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
            items(ModelDownloader.CATALOG) { spec ->
                val ready = ModelDownloader.isReady(context, spec.id)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                                        Text("Environ ${spec.approxMb} Mo", style = MaterialTheme.typography.bodyMedium)
                        Text(if (ready) "État : prêt" else "État : non installé")
                        Spacer(Modifier.height(8.dp))
                        Button(enabled = busyId == null && !ready, onClick = {
                            if (!consent) { showConsent = true; return@Button }
                            busyId = spec.id
                            scope.launch(Dispatchers.IO) {
                                val err = ModelDownloader.download(context, spec) { p ->
                                    launch(Dispatchers.Main) { status = "Téléchargement : $p%" }
                                }
                                withContext(Dispatchers.Main) {
                                    busyId = null
                                    if (err == null) status = "Moteur IA local installé et vérifié."
                                    else status = err
                                }
                            }
                        }) { Text(if (ready) "Installé" else "Installer le moteur") }
                    }
                }
            }
        }
        Text(status)
    }

    if (showConsent) {
        LocalAiConsentDialog(
            onAccepted = { consent = true; showConsent = false },
            onDismiss = { showConsent = false }
        )
    }
}
