package com.nova.ai

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceEngine(context: Context) {
    private val tts = TextToSpeech(context.applicationContext, null)
    fun speak(text: String, settings: VoiceSettings = VoiceSettings()) { tts.language = Locale.forLanguageTag(settings.languageTag); tts.setSpeechRate(settings.rate); tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "vanelle") }
    fun shutdown() { tts.shutdown() }
    data class VoiceSettings(val rate: Float = 1f, val languageTag: String = "fr-FR", val pack: String = "") {
        fun toJson() = "{\"rate\":$rate,\"languageTag\":\"$languageTag\",\"pack\":\"$pack\"}"
        companion object { fun fromJson(raw: String): VoiceSettings = try { org.json.JSONObject(raw).let { VoiceSettings(it.optDouble("rate",1.0).toFloat(), it.optString("languageTag","fr-FR"), it.optString("pack","")) } } catch (_: Throwable) { VoiceSettings() } }
    }
}

class LocalBrain(private val context: Context, private val mascotProvider: () -> Mascot = { MascotStore(context).activeOrDefault() }) {
    private val prefs = context.getSharedPreferences("vanelle_brain", Context.MODE_PRIVATE)
    fun remember(text: String) { prefs.edit().putString("last_memory", text.trim()).apply() }
    fun reply(prompt: String): String {
        val m = mascotProvider()
        val memory = prefs.getString("last_memory", null)
        val p = prompt.trim()
        if (p.isBlank()) return "Je t'écoute."
        if (p.equals("bonjour", true) || p.startsWith("salut", true)) return "Bonjour ! Je suis ${m.name}. Comment puis-je t'aider ?"
        if (p.contains("qui es-tu", true)) return "Je suis ${m.name}, ta mascotte Vanelle."
        if (p.contains("souviens", true) && memory != null) return "Je me souviens de : $memory"
        if (p.startsWith("souviens-toi", true)) { remember(p.substringAfter("souviens-toi").trim()); return "D'accord, je le garde en mémoire sur cet appareil." }
        return "Je peux te répondre avec mon moteur local lorsque le modèle IA est prêt. Pour l'instant, je n'invente pas une réponse que je ne connais pas."
    }
}
