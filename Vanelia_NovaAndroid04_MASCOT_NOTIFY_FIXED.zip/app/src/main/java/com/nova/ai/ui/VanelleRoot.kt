package com.nova.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nova.ai.*
import com.nova.ai.llm.*
import com.nova.ai.ui.theme.VanelleTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class Line(val user:Boolean,val text:String)

@Composable
fun VanelleRoot() {
    VanelleTheme {
        val context = LocalContext.current
        val scope = rememberCoroutineScope()
        val store = remember { MascotStore(context) }
        var mascot by remember { mutableStateOf(store.activeOrDefault()) }
        var input by remember { mutableStateOf("") }
        var lines by remember { mutableStateOf(listOf(Line(false, "Bonjour ! Je suis ${mascot.name}."))) }
        var busy by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("Vanelia est prête.") }
        var showConsent by remember { mutableStateOf(!LegalConsent.accepted(context)) }
        val router = remember { LlmRouter(rules = RuleBasedLlm { LocalBrain(context) }) }
        val voice = remember { VoiceEngine(context) }
        var modelDownloadStarted by remember { mutableStateOf(false) }

        fun startModelDownloadIfNeeded() {
            if (modelDownloadStarted || ModelDownloader.isReady(context, "vanelia_local_360m")) return
            modelDownloadStarted = true
            status = "Préparation du moteur local…"
            scope.launch(Dispatchers.IO) {
                val spec = ModelDownloader.CATALOG.first()
                val err = ModelDownloader.download(context, spec) { p ->
                    launch(Dispatchers.Main) { status = "Installation du moteur local : $p%" }
                }
                withContext(Dispatchers.Main) {
                    status = if (err == null) "Vanelia est prête." else "Moteur local non installé : ${err.take(120)}"
                    modelDownloadStarted = false
                }
            }
        }

        LaunchedEffect(showConsent) {
            if (!showConsent) startModelDownloadIfNeeded()
        }
        DisposableEffect(Unit) { onDispose { voice.shutdown() } }
        Column(Modifier.fillMaxSize().background(Color(0xFF0D0D0D)).padding(16.dp)) {
            ErrorOverlay()
            Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()) {
                Box(Modifier.size(48.dp).background(Color(0xFFFF4FA3), CircleShape), contentAlignment=Alignment.Center) { Text("V", color=Color.White, style=MaterialTheme.typography.titleLarge) }
                Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(mascot.name, style=MaterialTheme.typography.titleLarge); Text(status, style=MaterialTheme.typography.bodySmall, color=Color.LightGray) }
                TextButton(onClick={ context.startActivity(android.content.Intent(context, com.nova.ai.ModelHubActivity::class.java)) }) { Text("Modèles") }
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                items(lines) { l -> Surface(shape=MaterialTheme.shapes.large, color=if(l.user) Color(0xFF292029) else Color(0xFF181818), modifier=Modifier.fillMaxWidth()) { Text(l.text, Modifier.padding(14.dp)) } }
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value=input,onValueChange={input=it},modifier=Modifier.fillMaxWidth(),placeholder={Text("Écris à ${mascot.name}…")},enabled=!busy,singleLine=false)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={
                    val p=input.trim(); if(p.isBlank()||busy)return@Button
                    input=""; lines=lines+Line(true,p); busy=true
                    scope.launch(Dispatchers.IO) {
                        val result = router.generate(context, p, mascot.systemPrompt.ifBlank { null })
                        withContext(Dispatchers.Main) {
                            lines = lines + Line(false, result.second)
                            status = "Vanelia est prête."
                            busy = false
                        }
                    }
                }, modifier=Modifier.weight(1f),enabled=!busy){ Text(if(busy)"Réflexion…" else "Envoyer") }
                OutlinedButton(onClick={ mascot=store.activeOrDefault(); voice.speak(lines.lastOrNull{!it.user}?.text ?: "Je t'écoute.", mascot.voice) }) { Text("🔊") }
            }
        }
        if (showConsent) {
            LocalAiConsentDialog(onAccepted = { showConsent = false }, onDismiss = { showConsent = false })
        }
    }
}

