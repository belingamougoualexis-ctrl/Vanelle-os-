package com.nova.ai.llm

import android.content.Context
import com.nova.ai.ErrorCenter
import com.nova.ai.LocalBrain
import com.nova.ai.ModelDownloader
import com.nova.ai.platform.ReadinessState
import com.nova.ai.platform.RuntimeCheck
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

interface OnDeviceLlm {
    val id: String
    fun readiness(context: Context): RuntimeCheck
    suspend fun generate(context: Context, prompt: String, systemHint: String? = null): String?
}

/** Moteur de secours déterministe : aucune réponse inventée. */
class RuleBasedLlm(private val brainFactory: () -> LocalBrain) : OnDeviceLlm {
    override val id = "local_rules"
    override fun readiness(context: Context) = RuntimeCheck(ReadinessState.READY, "Secours local disponible")
    override suspend fun generate(context: Context, prompt: String, systemHint: String?): String = brainFactory().reply(prompt)
}

/**
 * Vrai moteur GGUF via llama.cpp Android AAR.
 * Le modèle est téléchargé par ModelDownloader puis chargé depuis le stockage privé de l'app.
 */
class VaneliaLocalLlm : OnDeviceLlm {
    override val id = "vanelia_local_360m"

    override fun readiness(context: Context): RuntimeCheck =
        if (ModelDownloader.isReady(context, id)) {
            RuntimeCheck(ReadinessState.READY, "Moteur local Vanelia prêt")
        } else {
            RuntimeCheck(ReadinessState.MODEL_MISSING, "Le moteur local Vanelia n'est pas encore installé.")
        }

    override suspend fun generate(context: Context, prompt: String, systemHint: String?): String? = withContext(Dispatchers.Default) {
        if (readiness(context).state != ReadinessState.READY) return@withContext null
        try {
            val spec = ModelDownloader.CATALOG.first { it.id == id }
            val path = ModelDownloader.fileFor(context, spec).absolutePath
            val loaded = Llama.loadModel(
                modelPath = path,
                config = LlamaConfig(
                    contextSize = 2048,
                    threads = maxOf(2, Runtime.getRuntime().availableProcessors() - 1)
                )
            )
            try {
                val result = Llama.complete(
                    loaded,
                    prompt = prompt,
                    systemPrompt = systemHint ?: "Tu es Vanelia, une assistante utile, honnête et concise. Si tu ne sais pas, dis-le clairement.",
                    maxTokens = 256
                )
                result.text.trim().ifBlank { null }
            } finally {
                Llama.releaseModel(loaded)
            }
        } catch (t: Throwable) {
            ErrorCenter.report("Vanelia n'a pas pu générer la réponse", t.message ?: t.javaClass.simpleName)
            null
        }
    }
}

class LlmRouter(
    private val local: OnDeviceLlm = VaneliaLocalLlm(),
    private val rules: OnDeviceLlm
) {
    fun bestAvailable(context: Context): OnDeviceLlm =
        if (local.readiness(context).state == ReadinessState.READY) local else rules

    suspend fun generate(context: Context, prompt: String, systemHint: String? = null): Pair<String, String> {
        val engine = bestAvailable(context)
        val text = try { engine.generate(context, prompt, systemHint) } catch (t: Throwable) {
            ErrorCenter.report("Réponse impossible", t.message ?: t.javaClass.simpleName)
            null
        }
        if (text != null) return engine.id to text

        if (engine !== rules) {
            val fallback = try { rules.generate(context, prompt, systemHint) } catch (t: Throwable) {
                ErrorCenter.report("Secours local indisponible", t.message ?: t.javaClass.simpleName)
                null
            }
            if (fallback != null) return rules.id to fallback
        }

        val reason = "Aucun moteur de réponse n'est actuellement disponible."
        ErrorCenter.report("Vanelia ne peut pas répondre", reason)
        return "unavailable" to reason
    }

    fun statusLine(context: Context): String = when (local.readiness(context).state) {
        ReadinessState.READY -> "Vanelia : moteur local actif"
        ReadinessState.MODEL_MISSING -> "Vanelia : moteur local non installé"
        ReadinessState.RUNTIME_MISSING -> "Vanelia : runtime local indisponible"
        else -> "Vanelia : moteur local en erreur"
    }
}
