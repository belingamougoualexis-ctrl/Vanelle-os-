package com.nova.ai

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Téléchargement réel avec reprise, contrôle d'espace et vérification SHA-256. */
object ModelDownloader {
    data class ModelSpec(
        val id: String,
        val label: String,
        val url: String,
        val fileName: String,
        val approxMb: Int,
        val sha256: String? = null
    )

    // SmolLM2-360M-Instruct Q4_K_M : ~271 MB, Apache-2.0, fichier GGUF public.
    // SHA-256 vérifié sur le fichier publié par Unsloth.
    val CATALOG = listOf(
        ModelSpec(
            id = "vanelia_local_360m",
            label = "Moteur IA local Vanelia",
            url = "https://huggingface.co/mfuntowicz/SmolLM2-360M-Instruct-Q4_K_M-GGUF/resolve/main/smollm2-360m-instruct-q4_k_m.gguf",
            fileName = "vanelia-local-360m-q4_k_m.gguf",
            approxMb = 271,
            sha256 = "8856952e27c65a87618f8347d1d06328c3953af04e8327b6dd1fab6670358fd0"
        )
    )

    fun modelDir(context: Context) = File(context.filesDir, "models").also { it.mkdirs() }
    fun fileFor(context: Context, spec: ModelSpec) = File(modelDir(context), spec.fileName)

    fun isReady(context: Context, id: String): Boolean {
        val s = CATALOG.find { it.id == id } ?: return false
        val f = fileFor(context, s)
        return f.isFile && f.length() > 10_000L &&
            (s.sha256.isNullOrBlank() || sha256(f).equals(s.sha256, true))
    }

    fun download(context: Context, spec: ModelSpec, onProgress: (Int) -> Unit): String? {
        if (!LegalConsent.accepted(context)) {
            val reason = "Le moteur local n'est pas activé : les conditions d'utilisation n'ont pas encore été acceptées. Lis-les puis appuie sur « J'accepte » pour autoriser le téléchargement."
            ErrorCenter.report("Téléchargement bloqué", reason)
            return reason
        }

        val dest = fileFor(context, spec)
        val part = File(dest.absolutePath + ".part")
        var offset = if (part.isFile) part.length() else 0L
        val free = context.filesDir.usableSpace
        val required = spec.approxMb.toLong() * 1024L * 1024L
        if (free < required + 32L * 1024L * 1024L) {
            val reason = "Espace insuffisant : environ ${spec.approxMb} Mo sont nécessaires, avec une marge de sécurité de 32 Mo. Il reste ${free / (1024 * 1024)} Mo."
            ErrorCenter.report("Téléchargement impossible", reason)
            return reason
        }

        return try {
            var conn = open(spec.url, offset)
            if (offset > 0 && conn.responseCode == HttpURLConnection.HTTP_OK) {
                conn.disconnect()
                part.delete()
                offset = 0L
                conn = open(spec.url, 0L)
            }
            if (conn.responseCode !in 200..299) {
                val reason = "Le serveur a répondu HTTP ${conn.responseCode}. Vanelia n'a pas considéré le fichier comme installé."
                conn.disconnect()
                ErrorCenter.report("Téléchargement refusé", reason)
                return reason
            }

            val total = if (conn.contentLengthLong > 0) conn.contentLengthLong + offset else -1L
            conn.inputStream.use { input ->
                FileOutputStream(part, offset > 0).use { out ->
                    val buffer = ByteArray(128 * 1024)
                    var done = offset
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        if (n == 0) continue
                        out.write(buffer, 0, n)
                        done += n
                        if (total > 0) onProgress((done * 100 / total).toInt().coerceIn(0, 100))
                    }
                    out.fd.sync()
                }
            }
            conn.disconnect()

            if (spec.sha256 != null && !sha256(part).equals(spec.sha256, true)) {
                part.delete()
                val reason = "La vérification SHA-256 a échoué : le fichier téléchargé est différent ou corrompu. Le fichier a été supprimé pour éviter d'utiliser un moteur invalide."
                ErrorCenter.report("Vérification du moteur échouée", reason)
                return reason
            }

            if (dest.exists()) dest.delete()
            if (!part.renameTo(dest)) {
                part.copyTo(dest, overwrite = true)
                part.delete()
            }
            onProgress(100)
            null
        } catch (t: Throwable) {
            val reason = t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
            ErrorCenter.report("Téléchargement impossible", reason)
            reason
        }
    }

    private fun open(url: String, offset: Long): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 120_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Vanelia/2.0")
            if (offset > 0) setRequestProperty("Range", "bytes=$offset-")
        }.also { it.connect() }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                if (n > 0) md.update(buffer, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
