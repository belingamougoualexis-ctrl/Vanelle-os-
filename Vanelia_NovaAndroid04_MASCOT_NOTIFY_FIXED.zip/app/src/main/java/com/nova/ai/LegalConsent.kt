package com.nova.ai

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Premier démarrage : acknowledgement explicite des conditions du moteur local.
 * Le moteur choisi utilise une licence open-source permissive ; aucune authentification
 * de compte n'est requise pour télécharger le fichier public.
 */
object LegalConsent {
    private const val PREFS = "vanelia_legal"
    private const val ACCEPTED = "local_ai_terms_acknowledged"

    fun accepted(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(ACCEPTED, false)

    fun setAccepted(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(ACCEPTED, value).apply()
    }

    fun openLicense(context: Context) {
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.apache.org/licenses/LICENSE-2.0")))
        } catch (t: Throwable) {
            ErrorCenter.report("Impossible d'ouvrir la licence", t.message ?: t.javaClass.simpleName)
        }
    }
}
