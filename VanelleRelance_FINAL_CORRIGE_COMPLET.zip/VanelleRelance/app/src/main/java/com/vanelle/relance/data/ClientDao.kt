package com.vanelle.relance.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ClientDao {

    @Query("SELECT * FROM clients ORDER BY dateEcheance ASC")
    fun getTous(): Flow<List<Client>>

    @Query("SELECT * FROM clients WHERE statut = 'EN_RETARD' ORDER BY dateEcheance ASC")
    fun getEnRetard(): Flow<List<Client>>

    // "Oubliés" = dette non payée et sans aucun contact depuis 21 jours ou plus
    @Query("""
        SELECT * FROM clients 
        WHERE statut != 'PAYEE' 
        AND (dernierContact IS NULL OR dernierContact < :seuilOubli)
        ORDER BY dernierContact ASC
    """)
    fun getOublies(seuilOubli: Long): Flow<List<Client>>

    @Query("SELECT COALESCE(SUM(montant), 0) FROM clients WHERE statut != 'PAYEE'")
    fun getTotalDu(): Flow<Double>

    @Query("SELECT COALESCE(SUM(montant), 0) FROM clients WHERE statut = 'PAYEE'")
    fun getTotalRecupere(): Flow<Double>

    @Insert
    suspend fun inserer(client: Client): Long

    @Update
    suspend fun mettreAJour(client: Client)

    @Delete
    suspend fun supprimer(client: Client)

    @Query("""
        UPDATE clients SET nombreRelances = nombreRelances + 1, dernierContact = :now
        WHERE id = :id AND statut != 'PAYEE'
        AND (dernierContact IS NULL OR dernierContact <= :cutoff)
    """)
    suspend fun enregistrerRelanceSiAutorisee(id: Long, now: Long, cutoff: Long): Int

    @Query("SELECT * FROM clients WHERE id = :id")
    suspend fun getParId(id: Long): Client?
}
