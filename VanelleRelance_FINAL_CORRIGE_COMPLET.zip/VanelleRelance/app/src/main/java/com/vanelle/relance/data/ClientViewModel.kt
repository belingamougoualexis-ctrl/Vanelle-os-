package com.vanelle.relance.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class ClientViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getInstance(application).clientDao()

    val tousLesClients = dao.getTous()
    val clientsEnRetard = dao.getEnRetard()
    val totalDu = dao.getTotalDu()
    val totalRecupere = dao.getTotalRecupere()

    fun clientsOublies() = dao.getOublies(
        System.currentTimeMillis() - TimeUnit.DAYS.toMillis(21)
    )

    fun ajouter(client: Client) = viewModelScope.launch {
        dao.inserer(client)
    }

    fun mettreAJour(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client)
    }

    fun supprimer(client: Client) = viewModelScope.launch {
        dao.supprimer(client)
    }

    fun marquerPaye(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client.copy(statut = StatutDette.PAYEE))
    }

    /** Remet une dette payée en « En cours » */
    fun marquerEnCours(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client.copy(statut = StatutDette.EN_COURS))
    }

    fun enregistrerRelanceSiAutorisee(client: Client, onResult: (Boolean) -> Unit = {}) = viewModelScope.launch {
        val now = System.currentTimeMillis()
        val cutoff = now - TimeUnit.HOURS.toMillis(48)
        val updated = dao.enregistrerRelanceSiAutorisee(client.id, now, cutoff)
        onResult(updated == 1)
    }

    fun peutRelancer(client: Client, now: Long = System.currentTimeMillis()): Boolean {
        return client.dernierContact == null ||
            now - client.dernierContact >= TimeUnit.HOURS.toMillis(48)
    }
}
