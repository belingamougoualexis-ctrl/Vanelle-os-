package com.vanelle.android

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

class DownloadEmbeddingWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            val dir = File(applicationContext.filesDir, "models").apply { mkdirs() }
            val target = File(dir, EMBEDDING_FILE)
            val part = File(dir, EMBEDDING_FILE + ".part")
            var existing = if (part.exists()) part.length() else 0L
            var conn = open(existing)
            if (existing > 0 && conn.responseCode == HttpURLConnection.HTTP_OK) { conn.disconnect(); part.delete(); existing = 0L; conn = open(0) }
            if (conn.responseCode !in listOf(200, 206)) throw IllegalStateException("HTTP ${conn.responseCode}")
            val append = existing > 0 && conn.responseCode == 206
            val total = if (conn.responseCode == 206) existing + conn.contentLengthLong else conn.contentLengthLong
            var done = existing
            conn.inputStream.use { input ->
                FileOutputStream(part, append).use { out ->
                    val b = ByteArray(512 * 1024)
                    while (true) {
                        val n = input.read(b)
                        if (n < 0) break
                        out.write(b, 0, n)
                        done += n
                        val p = if (total > 0) ((done * 100L) / total).toInt() else 0
                        setProgress(workDataOf("progress" to p, "bytes" to done, "total" to total))
                    }
                }
            }
            conn.disconnect()
            if (total > 0 && done != total) throw IllegalStateException("incomplete")
            val magic = part.inputStream().use { it.readNBytes(4) }
            if (!magic.contentEquals(byteArrayOf('G'.code.toByte(), 'G'.code.toByte(), 'U'.code.toByte(), 'F'.code.toByte()))) { part.delete(); throw IllegalStateException("invalid-gguf") }
            if (part.length() < 10L * 1024L * 1024L) { part.delete(); throw IllegalStateException("invalid-size") }
            if (sha256(part) != EMBEDDING_SHA256) { part.delete(); throw IllegalStateException("checksum") }
            if (!part.renameTo(target)) throw IllegalStateException("rename")
            applicationContext.getSharedPreferences(DownloadModelWorker.PREFS, Context.MODE_PRIVATE).edit().putBoolean("embedding_downloaded", true).putString("embedding_path", target.absolutePath).apply()
            Result.success()
        } catch (_: Exception) { Result.retry() }
    }

    private fun sha256(file: File): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val b = ByteArray(1024 * 1024)
            while (true) { val n = input.read(b); if (n < 0) break; md.update(b, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
    private fun open(range: Long): HttpURLConnection = (URL(EMBEDDING_URL).openConnection() as HttpURLConnection).apply { connectTimeout=20_000; readTimeout=120_000; instanceFollowRedirects=true; if(range>0) setRequestProperty("Range","bytes=$range-") }
    companion object {
        const val EMBEDDING_FILE = "Vanelle-all-MiniLM-L6-v2-Q4_K_M.gguf"
        const val EMBEDDING_SHA256 = "2ec4cee28a27a9c973d5f5230930d6ef6e52694bd2bc71be26a9bef5b1d755e6"
        const val EMBEDDING_URL = "https://huggingface.co/second-state/All-MiniLM-L6-v2-Embedding-GGUF/resolve/main/all-MiniLM-L6-v2-Q4_K_M.gguf?download=true"
    }
}
