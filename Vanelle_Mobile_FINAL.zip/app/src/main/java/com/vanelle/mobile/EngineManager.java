package com.vanelle.mobile;

import android.content.Context;
import android.os.StatFs;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.concurrent.*;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipException;
import java.util.zip.ZipInputStream;

public final class EngineManager {
    public static final String MODEL_NAME="smollm2-360m-instruct-q4_k_m.gguf";
    public static final long MODEL_SIZE=284164096L;
    public static final String MODEL_URL="https://huggingface.co/mfuntowicz/SmolLM2-360M-Instruct-Q4_K_M-GGUF/resolve/main/smollm2-360m-instruct-q4_k_m.gguf?download=true";
    public static final String MODEL_SHA256="8856952e27c65a87618f8347d1d06328c3953af04e8327b6dd1fab6670358fd0";
    public static final String RUNTIME_URL="https://github.com/ggml-org/llama.cpp/releases/download/b10516/llama-b10516-bin-android-arm64.tar.gz";
    public static final String RUNTIME_SHA256="1d2f78c13ec4a6197506288ba0aa0853d71c1b3048ff771ea37791be7f591cc6";
    private final Context c; private final File root, model, runtime;
    public EngineManager(Context c){this.c=c.getApplicationContext(); root=new File(this.c.getFilesDir(),"vanelle"); root.mkdirs(); model=new File(root,MODEL_NAME); runtime=new File(root,"runtime"); runtime.mkdirs();}
    public File model(){return model;} public File runtime(){return runtime;}
    public boolean modelReady(){return model.isFile() && model.length()>200_000_000L && sha256(model).equalsIgnoreCase(MODEL_SHA256);}
    public boolean runtimeReady(){return new File(runtime,"bin/llama-server").isFile() || new File(runtime,"llama-server").isFile();}
    public long freeBytes(){return new StatFs(root.getAbsolutePath()).getAvailableBytes();}
    public void deleteModel(){if(model.exists())model.delete(); new File(model.getPath()+".part").delete();}
    public void deleteRuntime(){deleteRec(runtime); runtime.mkdirs();}
    private static void deleteRec(File f){if(f.isDirectory()){File[] a=f.listFiles();if(a!=null)for(File x:a)deleteRec(x);}f.delete();}
    public interface Progress { void onUpdate(String phase,long done,long total); void onError(Exception e); void onDone(); }
    public void downloadModel(Progress cb){download(MODEL_URL,model,MODEL_SHA256,MODEL_SIZE,"model",cb);}
    public void downloadRuntime(Progress cb){download(RUNTIME_URL,new File(root,"runtime.tar.gz"),RUNTIME_SHA256,0,"runtime",new Progress(){public void onUpdate(String p,long d,long t){cb.onUpdate(p,d,t);} public void onError(Exception e){cb.onError(e);} public void onDone(){try{extractTarGz(new File(root,"runtime.tar.gz"),runtime);new File(root,"runtime.tar.gz").delete();cb.onDone();}catch(Exception e){cb.onError(e);}}});}
    private void download(String url,File target,String hash,long expected,String phase,Progress cb){
        ExecutorService ex=Executors.newSingleThreadExecutor(); ex.execute(()->{Exception last=null; try{
            File part=new File(target.getPath()+".part");
            if(freeBytes()<Math.max(500_000_000L, expected>0?expected*2:150_000_000L)) throw new IOException("Espace libre insuffisant pour le téléchargement et la vérification.");
            for(int attempt=1;attempt<=6;attempt++){
                try{
                    long existing=part.exists()?part.length():0; URL u=new URL(url); HttpURLConnection h=(HttpURLConnection)u.openConnection(); h.setConnectTimeout(20000); h.setReadTimeout(30000); h.setInstanceFollowRedirects(true); h.setRequestProperty("User-Agent","Vanelle/1.0 Android"); if(existing>0)h.setRequestProperty("Range","bytes="+existing+"-"); int code=h.getResponseCode();
                    if(existing>0 && code==200){part.delete();existing=0;} if(code!=200 && code!=206)throw new IOException("HTTP "+code);
                    long total=h.getContentLengthLong(); if(code==206 && total>0)total+=existing;
                    try(InputStream in=new BufferedInputStream(h.getInputStream()); OutputStream out=new BufferedOutputStream(new FileOutputStream(part,existing>0))){byte[] b=new byte[1024*1024];long done=existing;int n;while((n=in.read(b))!=-1){out.write(b,0,n);done+=n;if(cb!=null)cb.onUpdate(phase,done,total);}}
                    h.disconnect(); if(hash!=null&&!hash.isEmpty()){String got=sha256(part);if(!hash.equalsIgnoreCase(got))throw new IOException("Vérification SHA-256 échouée. Téléchargement supprimé pour éviter un fichier corrompu.");}
                    if(target.exists())target.delete(); if(!part.renameTo(target))throw new IOException("Impossible de finaliser le fichier téléchargé."); if(cb!=null)cb.onDone(); return;
                }catch(Exception e){last=e;try{Thread.sleep(1000L*attempt);}catch(InterruptedException ignored){}}
            } throw last==null?new IOException("Téléchargement échoué"):last;
        }catch(Exception e){if(cb!=null)cb.onError(e);}finally{ex.shutdown();}});
    }
    private static String sha256(File f)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[] b=new byte[1024*1024];int n;while((n=in.read(b))!=-1)md.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte x:md.digest())s.append(String.format("%02x",x));return s.toString();}
    private static void extractTarGz(File gz,File out)throws Exception{try(InputStream fi=new FileInputStream(gz); GZIPInputStream in=new GZIPInputStream(new BufferedInputStream(fi))){byte[] h=new byte[512];while(true){int r=readFully(in,h);if(r<512)break;boolean zero=true;for(byte x:h)if(x!=0){zero=false;break;}if(zero)break;String name=new String(h,0,100).trim();long size=0;for(int i=124;i<136;i++){int v=h[i]&255;if(v>=48&&v<=55)size=(size<<3)+(v-48);}File dest=new File(out,name);if(!dest.getCanonicalPath().startsWith(out.getCanonicalPath()+File.separator))throw new SecurityException("Archive path invalide");if(name.endsWith("/")){dest.mkdirs();}else{dest.getParentFile().mkdirs();try(OutputStream o=new BufferedOutputStream(new FileOutputStream(dest))){copyN(in,o,size);}dest.setExecutable(true,false);}long pad=(512-(size%512))%512;skipN(in,pad);}}
    }
    private static int readFully(InputStream in,byte[] b)throws IOException{int p=0,n;while(p<b.length&&(n=in.read(b,p,b.length-p))!=-1)p+=n;return p;}
    private static void copyN(InputStream in,OutputStream o,long n)throws IOException{byte[] b=new byte[64*1024];while(n>0){int r=in.read(b,0,(int)Math.min(b.length,n));if(r<0)throw new EOFException();o.write(b,0,r);n-=r;}}
    private static void skipN(InputStream in,long n)throws IOException{while(n>0){long r=in.skip(n);if(r<=0){if(in.read()<0)throw new EOFException();r=1;}n-=r;}}
}
