package com.vanelle.android

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences(DownloadModelWorker.PREFS, Context.MODE_PRIVATE) }
    private val secret by lazy { SecretStore(this) }
    @Volatile private var nativeLoaded = false

    private val modelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input)
                val safeName = (uri.lastPathSegment?.substringAfterLast('/') ?: "imported.gguf").replace(Regex("[^A-Za-z0-9._-]"), "_")
                val target = File(filesDir, "models/imported-$safeName")
                target.parentFile?.mkdirs()
                target.outputStream().use { output -> input.copyTo(output, bufferSize = 1024 * 1024) }
                val magic = target.inputStream().use { it.readNBytes(4) }
                require(magic.contentEquals(byteArrayOf('G'.code.toByte(), 'G'.code.toByte(), 'U'.code.toByte(), 'F'.code.toByte()))) { "Not GGUF" }
                prefs.edit().putBoolean("model_downloaded", true).putString("model_path", target.absolutePath).apply()
                Toast.makeText(this, "Modèle local ajouté. Vanelle peut maintenant l'utiliser.", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) { Toast.makeText(this, "Impossible d'importer le modèle.", Toast.LENGTH_LONG).show() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(NativeVanelle(this@MainActivity), "AndroidVanelle")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    fun activateLocalModel(): String {
        val current = modelState()
        if (current == "ready") return current
        if (current == "downloaded") return current
        val accepted = showConsentAndWait()
        return if (accepted) "downloading" else "declined"
    }

    private fun startModelDownload() {
        val request = OneTimeWorkRequestBuilder<DownloadModelWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork("vanelle-model", ExistingWorkPolicy.KEEP, request)
        val embeddingRequest = OneTimeWorkRequestBuilder<DownloadEmbeddingWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork("vanelle-embedding", ExistingWorkPolicy.KEEP, embeddingRequest)
        prefs.edit().putInt("model_progress", 0).apply()
    }

    fun modelState(): String {
        val path = prefs.getString("model_path", null)?.let(::File) ?: File(filesDir, "models/${DownloadModelWorker.MODEL_FILE}")
        if (!path.exists()) return if (WorkManager.getInstance(this).getWorkInfosForUniqueWork("vanelle-model").get().any { !it.state.isFinished }) "downloading" else "missing"
        if (nativeLoaded) return "ready"
        if (prefs.getBoolean("model_downloaded", false)) return "downloaded"
        return "missing"
    }

    fun modelProgress(): Int = try {
        val infos = WorkManager.getInstance(this).getWorkInfosForUniqueWork("vanelle-model").get()
        val p = infos.firstOrNull()?.progress?.getInt("progress", prefs.getInt("model_progress", 0)) ?: prefs.getInt("model_progress", 0)
        if (infos.firstOrNull()?.state?.isFinished == true && prefs.getBoolean("model_downloaded", false)) 100 else p
    } catch (_: Exception) { prefs.getInt("model_progress", 0) }

    fun generateLocal(prompt: String, maxTokens: Int): String {
        val path = prefs.getString("model_path", null)?.let(::File) ?: File(filesDir, "models/${DownloadModelWorker.MODEL_FILE}")
        if (!path.exists()) return ""
        if (modelState() != "ready") {
            val rc = NativeVanelleBridge.load(path.absolutePath, adaptiveContext())
            if (rc != 0) return ""
            nativeLoaded = true
            prefs.edit().putString("model_path", path.absolutePath).apply()
        }
        return NativeVanelleBridge.generate(prompt, maxTokens)
    }

    fun nativeSystemInfo(): String = NativeVanelleBridge.info()

    fun embeddingState(): String {
        val path = prefs.getString("embedding_path", null)?.let(::File) ?: File(filesDir, "models/${DownloadEmbeddingWorker.EMBEDDING_FILE}")
        if (!path.exists()) {
            return try {
                val infos = WorkManager.getInstance(this).getWorkInfosForUniqueWork("vanelle-embedding").get()
                if (infos.any { !it.state.isFinished }) "downloading" else "missing"
            } catch (_: Exception) { "missing" }
        }
        if (prefs.getBoolean("embedding_loaded", false)) return "ready"
        return "downloaded"
    }

    fun activateEmbedding(): String {
        val state = embeddingState()
        if (state == "ready" || state == "downloaded") return state
        val accepted = showEmbeddingConsentAndWait()
        if (!accepted) return "declined"
        startModelDownload()
        return "downloading"
    }

    fun embed(text: String): String {
        val path = prefs.getString("embedding_path", null)?.let(::File) ?: File(filesDir, "models/${DownloadEmbeddingWorker.EMBEDDING_FILE}")
        if (!path.exists()) return ""
        if (embeddingState() != "ready") {
            val rc = NativeVanelleBridge.loadEmbedding(path.absolutePath)
            if (rc != 0) return ""
            prefs.edit().putBoolean("embedding_loaded", true).apply()
        }
        return NativeVanelleBridge.embed(text).joinToString(",")
    }

    fun openModelPicker() { modelPicker.launch(arrayOf("application/octet-stream", "application/*")) }

    fun saveRemote(endpoint: String, model: String, apiKey: String): String {
        if (endpoint.isBlank() || model.isBlank()) return "invalid"
        if (!endpoint.trimEnd('/').startsWith("https://", ignoreCase = true)) return "invalid_https"
        prefs.edit().putString("remote_endpoint", endpoint.trimEnd('/')).putString("remote_model", model).apply()
        secret.put("remote_key", apiKey)
        return "saved"
    }

    fun remoteState(): String = if (prefs.getString("remote_endpoint", null).isNullOrBlank()) "not_configured" else "configured"

    fun generateRemote(prompt: String, maxTokens: Int): String {
        val endpoint = prefs.getString("remote_endpoint", null) ?: return ""
        val model = prefs.getString("remote_model", null) ?: return ""
        val key = secret.get("remote_key") ?: ""
        return try {
            val url = URL(if (endpoint.endsWith("/chat/completions")) endpoint else "$endpoint/chat/completions")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 20_000; readTimeout = 120_000; doOutput = true
                setRequestProperty("Content-Type", "application/json")
                if (key.isNotBlank()) setRequestProperty("Authorization", "Bearer $key")
            }
            val body = JSONObject().apply {
                put("model", model)
                put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
                put("temperature", 0.35); put("max_tokens", maxTokens.coerceIn(32, 1024))
            }.toString()
            conn.outputStream.use { it.write(body.toByteArray()) }
            val response = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
            if (conn.responseCode !in 200..299) return ""
            JSONObject(response).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content", "") ?: ""
        } catch (_: Exception) { "" }
    }

    private fun adaptiveContext(): Int = when {
        Runtime.getRuntime().maxMemory() >= 6L * 1024 * 1024 * 1024 -> 4096
        Runtime.getRuntime().maxMemory() >= 4L * 1024 * 1024 * 1024 -> 3072
        else -> 2048
    }

    override fun onDestroy() {
        if (nativeLoaded) { try { NativeVanelleBridge.unload() } catch (_: Throwable) {} }
        if (prefs.getBoolean("embedding_loaded", false)) { try { NativeVanelleBridge.unloadEmbedding() } catch (_: Throwable) {} }
        prefs.edit().putBoolean("embedding_loaded", false).apply()
        super.onDestroy()
    }

    private fun showEmbeddingConsentAndWait(): Boolean {
        var accepted = false
        val latch = java.util.concurrent.CountDownLatch(1)
        runOnUiThread {
            val dialog = AlertDialog.Builder(this)
                .setTitle("Activer la mémoire sémantique de Vanelle")
                .setMessage("Vanelle peut télécharger un petit moteur de recherche sémantique d'environ 21 Mo. Il permet de transformer les connaissances en vecteurs et d'effectuer une recherche locale hors ligne.")
                .setNegativeButton("Plus tard") { _, _ -> latch.countDown() }
                .setPositiveButton("Accepter") { _, _ -> accepted = true; latch.countDown() }
                .create()
            dialog.setOnCancelListener { latch.countDown() }
            dialog.show()
        }
        latch.await()
        return accepted
    }

    private fun showConsentAndWait(): Boolean {
        var accepted = false
        val latch = java.util.concurrent.CountDownLatch(1)
        runOnUiThread {
            val dialog = AlertDialog.Builder(this)
                .setTitle("Activer Vanelle")
                .setMessage("Vanelle doit télécharger son moteur IA local et son module de mémoire sémantique (environ 420 Mo au total). Le téléchargement n'est effectué qu'après ton accord. Il restera ensuite sur cet appareil.")
                .setNegativeButton("Plus tard") { _, _ -> latch.countDown() }
                .setPositiveButton("Accepter et télécharger") { _, _ -> accepted = true; startModelDownload(); latch.countDown() }
                .create()
            dialog.setOnCancelListener { latch.countDown() }
            dialog.show()
        }
        latch.await()
        return accepted
    }
}
