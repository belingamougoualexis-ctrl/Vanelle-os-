package com.vanelle.android

import android.webkit.JavascriptInterface

class NativeVanelle(private val activity: MainActivity) {
    @JavascriptInterface fun activateLocal(): String = activity.activateLocalModel()
    @JavascriptInterface fun modelState(): String = activity.modelState()
    @JavascriptInterface fun modelProgress(): Int = activity.modelProgress()
    @JavascriptInterface fun generate(prompt: String, maxTokens: Int): String = activity.generateLocal(prompt, maxTokens)
    @JavascriptInterface fun systemInfo(): String = activity.nativeSystemInfo()
    @JavascriptInterface fun openModelPicker(): String { activity.openModelPicker(); return "opened" }
    @JavascriptInterface fun saveRemote(endpoint: String, model: String, apiKey: String): String = activity.saveRemote(endpoint, model, apiKey)
    @JavascriptInterface fun remoteState(): String = activity.remoteState()
    @JavascriptInterface fun generateRemote(prompt: String, maxTokens: Int): String = activity.generateRemote(prompt, maxTokens)
    @JavascriptInterface fun embeddingState(): String = activity.embeddingState()
    @JavascriptInterface fun activateEmbedding(): String = activity.activateEmbedding()
    @JavascriptInterface fun embed(text: String): String = activity.embed(text)
}

object NativeVanelleBridge {
    init { System.loadLibrary("vanelle_jni") }
    external fun load(path: String, contextSize: Int): Int
    external fun generate(prompt: String, maxTokens: Int): String
    external fun unload()
    external fun info(): String
    external fun loadEmbedding(path: String): Int
    external fun embed(text: String): FloatArray
    external fun unloadEmbedding()
}
