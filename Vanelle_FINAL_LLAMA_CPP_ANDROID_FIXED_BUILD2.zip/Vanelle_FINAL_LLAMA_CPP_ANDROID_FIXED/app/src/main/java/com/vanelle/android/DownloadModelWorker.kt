package com.vanelle.android

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class DownloadModelWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            download(
                MODEL_URL,
                File(applicationContext.filesDir, "models/$MODEL_FILE"),
                MODEL_SHA256,
                "model"
            )
            applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("model_downloaded", true)
                .putInt("model_progress", 100)
                .putString("model_path", File(applicationContext.filesDir, "models/$MODEL_FILE").absolutePath)
                .apply()
            Result.success()
        } catch (_: Exception) { Result.retry() }
    }

    private fun download(url: String, target: File, expectedSha: String?, key: String) {
        target.parentFile?.mkdirs()
        val part = File(target.parentFile, target.name + ".part")
        var existing = if (part.exists()) part.length() else 0L
        var conn = open(url, existing)
        if (existing > 0 && conn.responseCode == HttpURLConnection.HTTP_OK) {
            conn.disconnect(); part.delete(); existing = 0L; conn = open(url, 0L)
        }
        if (conn.responseCode !in listOf(HttpURLConnection.HTTP_OK, HttpURLConnection.HTTP_PARTIAL)) {
            conn.disconnect(); throw IllegalStateException("HTTP ${conn.responseCode}")
        }
        val append = existing > 0 && conn.responseCode == HttpURLConnection.HTTP_PARTIAL
        val total = if (conn.responseCode == HttpURLConnection.HTTP_PARTIAL) existing + conn.contentLengthLong else conn.contentLengthLong
        var done = existing
        conn.inputStream.use { input ->
            part.outputStream(append).use { output ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    output.write(buffer, 0, n)
                    done += n
                    val pct = if (total > 0) ((done * 100L) / total).toInt().coerceIn(0, 100) else 0
                    setProgress(workDataOf("progress" to pct, "bytes" to done, "total" to total, "key" to key))
                }
            }
        }
        conn.disconnect()
        if (total > 0 && done != total) throw IllegalStateException("incomplete")
        if (expectedSha != null && sha256(part) != expectedSha.lowercase()) { part.delete(); throw IllegalStateException("checksum") }
        if (!part.renameTo(target)) { part.delete(); throw IllegalStateException("rename") }
    }

    private fun open(url: String, range: Long): HttpURLConnection = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 20_000; readTimeout = 120_000; instanceFollowRedirects = true
        if (range > 0) setRequestProperty("Range", "bytes=$range-")
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val b = ByteArray(1024 * 1024)
            while (true) { val n = input.read(b); if (n < 0) break; md.update(b, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    companion object {
        const val PREFS = "vanelle_model"
        const val MODEL_FILE = "Vanelle-Qwen2.5-0.5B-Instruct-Q4_K_M.gguf"
        const val MODEL_URL = "https://huggingface.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/Qwen2.5-0.5B-Instruct-Q4_K_M.gguf?download=true"
        const val MODEL_SHA256 = "fa4d41b65761ed565cac6b5f62e35135d050408b033114a128ab308c02b2e83a"
    }
}
