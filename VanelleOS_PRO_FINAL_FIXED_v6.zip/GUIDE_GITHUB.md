# VanelleOS — Guide GitHub & comportement de l'app

## 1. Mettre le projet sur GitHub

1. Crée un nouveau dépôt sur GitHub (vide, sans README ni .gitignore générés automatiquement).
2. En local, décompresse `VanelleOS_PRO_FINAL.zip` puis :
   ```
   cd VanelleOS_PRO_FINAL
   git init
   git add .
   git commit -m "VanelleOS - version initiale"
   git branch -M main
   git remote add origin https://github.com/<ton-compte>/<ton-repo>.git
   git push -u origin main
   ```
3. Le workflow `.github/workflows/android-build.yml` se déclenche automatiquement à ce push (déjà inclus dans le zip, rien à créer).
4. Onglet **Actions** du dépôt → le job "Android Build" tourne (3-5 min) → à la fin, un artefact **VanelleOS-debug** contenant `app-debug.apk` est téléchargeable, prêt à installer sur un téléphone.

Aucun secret, aucune clé à configurer pour ce build de test — c'est un APK debug, auto-signé.

## 2. Si le build échoue

Ouvre le job en erreur dans l'onglet Actions, copie le message d'erreur (la ligne rouge) et colle-le moi directement — je corrige.

## 3. Comment l'app se comporte, au quotidien

**Premier lancement**
L'app demande d'un coup les autorisations Micro, Contacts, Appel, SMS et Notifications via les popups Android standards. Une boîte de dialogue propose aussi d'activer le service d'Accessibilité (redirige vers les réglages système, obligatoire pour ce type de service).

**En fonctionnement normal**
Si l'écoute vocale est activée (onglet Configuration), l'app tourne en arrière-plan avec une notification persistante et écoute en continu. Dès qu'elle entend "Vanelle" suivi d'une commande, elle l'exécute :
- Ouvrir une app, chercher sur le web, YouTube, traduire, batterie, calculatrice, navigation → **exécution immédiate**, résultat affiché à l'écran.
- Appeler quelqu'un ou envoyer un SMS → **une fenêtre de confirmation s'affiche d'abord**, rien ne part sans que tu valides.
- "Programme X à telle heure" → crée une relance, visible dans l'onglet Relances, qui se déclenchera toute seule au moment dit — même app fermée.

**L'onglet Configuration**
C'est le centre de contrôle unique : le switch d'écoute vocale, le statut réel (Accordée/Non accordée) de chaque autorisation avec un bouton pour l'ouvrir dans les réglages si besoin, et l'effacement de la mémoire. Tout ce que l'utilisateur doit un jour autoriser ou vérifier est là, rien n'est caché ailleurs.

**Identité visuelle**
Noir / blanc / rose (#FF2D95), logo "D" (Duval) sur fond noir cerclé de rose, sans autre décoration.

## 4. Ce qui reste en dehors de mon contrôle

- La compilation réelle n'a jamais eu lieu dans mon environnement (pas de Gradle/SDK ici) — le vrai test, c'est le premier push.
- CALL_PHONE et SEND_SMS resteront bloquées si tu publies un jour sur le Google Play Store (réservées aux apps téléphone/SMS par défaut) — aucun souci pour un usage privé ou un sideload.

## 4. Build CI — versions obligatoires (ne pas modifier)

Le workflow **doit** utiliser :
- JDK **17**
- Gradle **8.11.1** via `./gradlew` (jamais `gradle` système 8.2)
- AGP **8.9.1** + Kotlin **2.1.10**

Si le log affiche `Welcome to Gradle 8.2`, le fichier `.github/workflows/android-build.yml` n’a **pas** été mis à jour sur GitHub.
Remplace-le entièrement par celui du ZIP, commit, push.
