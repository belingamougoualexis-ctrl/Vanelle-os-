package com.vanelle.os
import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class VanelleApp : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        CrashLogger.install(this)
        // Précharge les modèles acoustiques openWakeWord en arrière-plan (réels, ~4 Mo)
        appScope.launch {
            try {
                WakeWordModelManager.downloadIfNeeded(this@VanelleApp)
            } catch (_: Exception) {}
        }
    }
}
