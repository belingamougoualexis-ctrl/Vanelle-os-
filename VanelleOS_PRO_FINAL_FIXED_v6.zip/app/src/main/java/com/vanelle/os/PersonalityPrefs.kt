package com.vanelle.os
import android.content.Context

object PersonalityPrefs {
    private fun p(c: Context) = c.getSharedPreferences("vanelle_prefs", 0)

    /** calme | energique | coach | pote */
    fun getPersonality(c: Context) = p(c).getString("personality", "pote") ?: "pote"
    fun setPersonality(c: Context, id: String) {
        if (id in listOf("calme", "energique", "coach", "pote"))
            p(c).edit().putString("personality", id).apply()
    }

    fun personalityLabel(id: String) = when (id) {
        "calme" -> "Calme & posée"
        "energique" -> "Énergique"
        "coach" -> "Coach motivante"
        else -> "Pote bienveillante"
    }

    fun systemTone(c: Context): String = when (getPersonality(c)) {
        "calme" -> "Tu es calme, posée, rassurante. Phrases douces et claires."
        "energique" -> "Tu es dynamique, enthousiaste, positive, sans en faire trop."
        "coach" -> "Tu es une coach motivante: encourage, structure, pousse à l'action."
        else -> "Tu es une amie proche: chaleureuse, naturelle, un peu complice."
    }

    fun isGuestMode(c: Context) = p(c).getBoolean("guest_mode", false)
    fun setGuestMode(c: Context, on: Boolean) = p(c).edit().putBoolean("guest_mode", on).apply()

    fun preferOffline(c: Context) = p(c).getBoolean("prefer_offline", true)
    fun setPreferOffline(c: Context, on: Boolean) = p(c).edit().putBoolean("prefer_offline", on).apply()
}
