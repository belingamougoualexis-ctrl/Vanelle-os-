package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder

class StreamingHelper(private val c:Context){
    private fun isInstalled(pkg:String):Boolean = try{ c.packageManager.getPackageInfo(pkg,0); true }catch(_:Exception){ false }

    fun open(platformRaw:String,titleRaw:String):String{
        val platform=platformRaw.trim().lowercase()
        val title=titleRaw.trim()
        return when{
            platform.contains("youtube")-> {
                // Seule plateforme avec un vrai lien de recherche public et documente : autoplay possible.
                try{
                    val i=Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/results?search_query=${URLEncoder.encode(title,"UTF-8")}")).apply{ addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                    c.startActivity(i); "YouTube ouvert avec la recherche"
                }catch(_:Exception){ "Impossible d'ouvrir YouTube" }
            }
            platform.contains("netflix")-> openAppOrWeb("com.netflix.mediaclient","https://www.netflix.com/search?q=${URLEncoder.encode(title,"UTF-8")}","Netflix")
            platform.contains("disney")-> openAppOrWeb("com.disney.disneyplus","https://www.disneyplus.com/","Disney+")
            platform.contains("prime")-> openAppOrWeb("com.amazon.avod.thirdpartyclient","https://www.primevideo.com/","Prime Video")
            else-> "Plateforme non reconnue"
        }
    }
    private fun openAppOrWeb(pkg:String,webUrl:String,label:String):String{
        return try{
            if(isInstalled(pkg)){
                val li=c.packageManager.getLaunchIntentForPackage(pkg)
                if(li!=null){ li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(li); return "$label ouvert. Aucun lien officiel et public ne permet de rechercher directement un titre precis sur cette plateforme, tu devras chercher toi-meme une fois l'app ouverte" }
            }
            val i=Intent(Intent.ACTION_VIEW,Uri.parse(webUrl)).apply{ addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            c.startActivity(i); "$label n'est pas installe, ouverture du site web a la place"
        }catch(_:Exception){ "Impossible d'ouvrir $label" }
    }
}
