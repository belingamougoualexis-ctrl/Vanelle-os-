package com.vanelle.os
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
class ContactsRepository(private val context:Context){
    private fun findNumber(name:String):String?{
        var num:String?=null
        val safe=name.replace("\\","\\\\").replace("%","\\%").replace("_","\\_")
        val cur=try{ context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),"${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ? ESCAPE '\\'",arrayOf("%$safe%"),null) }catch(_:Exception){ null }
        cur?.use{ if(it.moveToFirst()){ val idx=it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER); if(idx>=0) num=it.getString(idx) } }
        return num
    }
    fun call(name:String):String{
        if(name.isBlank()) return "Nom requis"
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED) return "Permission contacts requise"
        val num=findNumber(name) ?: return "Contact introuvable"
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED) return "Permission appel requise"
        return try{
            val i=Intent(Intent.ACTION_CALL,Uri.fromParts("tel",num,null)).apply{ addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(i); "Appel en cours vers $name"
        }catch(_:Exception){ "Impossible" }
    }
    fun sendMessage(name:String,message:String):String{
        if(name.isBlank()) return "Nom requis"
        if(message.isBlank()) return "Message vide"
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED) return "Permission contacts requise"
        val num=findNumber(name) ?: return "Contact introuvable"
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED) return "Permission SMS requise"
        return try{
            val sms=SmsManager.getDefault()
            val parts=sms.divideMessage(message)
            sms.sendMultipartTextMessage(num,null,parts,null,null)
            "Message envoye a $name"
        }catch(_:Exception){ "Impossible d'envoyer le message" }
    }
}
