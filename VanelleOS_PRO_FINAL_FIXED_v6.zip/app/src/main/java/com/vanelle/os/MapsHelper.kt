package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.net.Uri
class MapsHelper(private val c:Context){
    fun open(q:String)= try{ val i=Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q=${Uri.encode(q)}")).apply{ addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }; c.startActivity(i); true }catch(_:Exception){ try{ val i=Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/maps/search/${Uri.encode(q)}")).apply{ addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }; c.startActivity(i); true }catch(_:Exception){ false } }
}
