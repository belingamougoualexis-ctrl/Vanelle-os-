package com.vanelle.os
import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object WakeWordModelManager{
    private const val MEL_URL="https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/melspectrogram.tflite"
    private const val EMB_URL="https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/embedding_model.tflite"

    fun melFile(c:Context)=File(c.filesDir,"melspectrogram.tflite")
    fun embFile(c:Context)=File(c.filesDir,"embedding_model.tflite")
    fun isReady(c:Context)= melFile(c).exists() && melFile(c).length()>1000 && embFile(c).exists() && embFile(c).length()>1000

    private fun downloadOne(url:String,dest:File):Boolean{
        return try{
            val conn=URL(url).openConnection() as HttpURLConnection
            conn.instanceFollowRedirects=true
            conn.connectTimeout=15000; conn.readTimeout=15000
            if(conn.responseCode !in 200..299) return false
            dest.outputStream().use{ out-> conn.inputStream.use{ it.copyTo(out) } }
            conn.disconnect()
            dest.length()>1000
        }catch(_:Exception){ false }
    }

    suspend fun downloadIfNeeded(c:Context):Boolean{
        if(isReady(c)) return true
        val a=downloadOne(MEL_URL,melFile(c))
        val b=downloadOne(EMB_URL,embFile(c))
        return a && b
    }
}
