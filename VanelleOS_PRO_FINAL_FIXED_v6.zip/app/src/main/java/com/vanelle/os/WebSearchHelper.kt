package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.net.Uri
class WebSearchHelper(private val c:Context){
    fun search(q:String)= try{ val i=Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q=${Uri.encode(q)}")).apply{ addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }; c.startActivity(i); true }catch(_:Exception){ false }
}
