package com.vanelle.os
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object AlarmScheduler{
    fun canScheduleExact(c:Context):Boolean{
        if(Build.VERSION.SDK_INT<31) return true
        val am=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }
    private fun pendingIntentFor(c:Context, taskId:Long):PendingIntent{
        val i=Intent(c,ScheduledTaskReceiver::class.java).apply{ putExtra("task_id",taskId) }
        return PendingIntent.getBroadcast(c,taskId.toInt(),i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    fun scheduleNext(c:Context, task:ScheduledTask){
        val am=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val cal=Calendar.getInstance().apply{
            set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0)
            set(Calendar.HOUR_OF_DAY,task.hour); set(Calendar.MINUTE,task.minute)
        }
        if(cal.timeInMillis<=System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR,1)
        val pi=pendingIntentFor(c,task.id)
        try{
            if(Build.VERSION.SDK_INT>=23 && canScheduleExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
            else am.set(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
        }catch(_:SecurityException){ try{ am.set(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi) }catch(_:Exception){} }
    }
    fun cancel(c:Context, taskId:Long){
        val am=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntentFor(c,taskId))
    }
}
