package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.net.Uri
class EmergencyManager(private val c:Context){
    fun sos()= try{ val i=Intent(Intent.ACTION_DIAL,Uri.parse("tel:112")).apply{ addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }; c.startActivity(i); "Urgence ouverte" }catch(_:Exception){ "Impossible" }
}
