package com.vanelle.os
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import java.util.Locale
import kotlinx.coroutines.launch
class MainActivity:AppCompatActivity(){
    private lateinit var vp:ViewPager2
    private lateinit var tl:TabLayout
    private var tts:TextToSpeech?=null
    private val mouthHandler=Handler(Looper.getMainLooper())
    private var mouthRunnable:Runnable?=null
    @Volatile private var processingCommand=false
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){ results ->
        if(results[Manifest.permission.RECORD_AUDIO]==true && WakeWordPrefs.isEnabled(this)) startWakeService()
    }
    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        vp=findViewById(R.id.viewPager)
        tl=findViewById(R.id.tabLayout)
        vp.adapter=Adapter(this)
        TabLayoutMediator(tl,vp){ tab,pos-> tab.text=when(pos){0->"Mascotte";1->"Configuration";2->"Fonctions";else->"Relances"} }.attach()
        requestNeededPermissions()
        tts=TextToSpeech(this){ status-> if(status==TextToSpeech.SUCCESS) tts?.language=Locale.FRANCE }
        if(!isEnabled()){
            AlertDialog.Builder(this).setTitle("Accessibilite requise").setMessage("Active l acces pour les actions systeme").setPositiveButton("Activer"){_,_-> startActivity(android.content.Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }.setNegativeButton("Plus tard",null).show()
        }
        handleIncomingIntent(intent)
        // Téléchargement automatique silencieux des données avancées (Wi-Fi uniquement)
        DataDownloadScreen.maybeShow(this)
        maybeShowOnboarding()
    }

    override fun onNewIntent(i:Intent){
        super.onNewIntent(i)
        setIntent(i)
        handleIncomingIntent(i)
    }
    private fun handleIncomingIntent(i:Intent){
        val confirmType=i.getStringExtra("confirm_type")
        if(!confirmType.isNullOrBlank()){
            val name=i.getStringExtra("confirm_name") ?: ""
            val message=i.getStringExtra("confirm_message") ?: ""
            val msg=if(confirmType=="call") "Confirmer l'appel vers $name ?" else "Confirmer l'envoi du message a $name :\n\"$message\""
            AlertDialog.Builder(this).setTitle("Confirmation requise").setMessage(msg)
                .setPositiveButton("Confirmer"){_,_->
                    val contacts=ContactsRepository(this)
                    val res=if(confirmType=="call") contacts.call(name) else contacts.sendMessage(name,message)
                    WorkflowLearner(this).log("[confirme] $confirmType $name")
                    android.widget.Toast.makeText(this,res,android.widget.Toast.LENGTH_LONG).show()
                }
                .setNegativeButton("Annuler"){_,_-> android.widget.Toast.makeText(this,"Annule",android.widget.Toast.LENGTH_SHORT).show() }
                .setCancelable(false).show()
            i.removeExtra("confirm_type")
            return
        }
        val pendingCommand = i.getStringExtra("pending_command")
        if(!pendingCommand.isNullOrBlank()){
            i.removeExtra("pending_command")
            if(processingCommand) return
            processingCommand=true
            lifecycleScope.launch{
                try {
                val res=CommandInterpreter(this@MainActivity).execute(pendingCommand)
                if(OverlayHelper.canDraw(this@MainActivity)){
                    val sel=MascotManager.getSelected(this@MainActivity)
                    val mid=try{ MascotManager.getDrawableId(this@MainActivity,sel) }catch(_:Exception){0}
                    OverlayHelper.show(this@MainActivity,mid,pendingCommand,res)
                    // Synchro labiale : onStart + onRangeStart (syllabes) + onDone
                    val spoken = res
                    tts?.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
                        override fun onStart(id:String?){ OverlayHelper.startTalking() }
                        override fun onDone(id:String?){ OverlayHelper.stopTalking() }
                        override fun onError(id:String?){ OverlayHelper.stopTalking() }
                        override fun onRangeStart(utteranceId:String?, start:Int, end:Int, frame:Int){
                            // Segment de texte en cours de prononciation → pulse de bouche
                            val chunk = try {
                                if(start>=0 && end>start && end<=spoken.length) spoken.substring(start, end) else null
                            } catch(_:Exception){ null }
                            OverlayHelper.pulseMouth(chunk)
                        }
                    })
                    if(res.isNotBlank()){
                        try{
                            val params = android.os.Bundle()
                            // Demande les callbacks de plage pour une meilleure synchro (API 26+)
                            tts?.speak(res, TextToSpeech.QUEUE_FLUSH, params, "vanelle_utt")
                        }catch(_:Exception){
                            try{ tts?.speak(res,TextToSpeech.QUEUE_FLUSH,null,"vanelle_utt") }catch(_:Exception){}
                        }
                    }
                    moveTaskToBack(true)
                }else{
                    showMascotDialog(pendingCommand,res)
                }
                } finally {
                    processingCommand=false
                }
            }
        }
    }
    private fun showMascotDialog(voiceText:String,voiceResult:String){
            val sel = MascotManager.getSelected(this)
            val mascotId = try { MascotManager.getDrawableId(this, sel) } catch (_:Exception){ 0 }
            val imageView = ImageView(this).apply {
                if (mascotId != 0) setImageResource(mascotId)
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = FrameLayout.LayoutParams(420,420)
            }
            val mouth = View(this).apply{
                layoutParams = FrameLayout.LayoutParams(50,16).apply{ gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL; topMargin=185 }
                background = GradientDrawable().apply{ setColor(0xFF3A2A2A.toInt()); cornerRadius=10f }
                visibility = View.INVISIBLE
            }
            val frame = FrameLayout(this).apply{
                layoutParams = android.widget.LinearLayout.LayoutParams(420,420).apply{ setMargins(0,20,0,20) }
                addView(imageView); addView(mouth)
            }
            val pulse=android.animation.ObjectAnimator.ofPropertyValuesHolder(frame,
                android.animation.PropertyValuesHolder.ofFloat(android.view.View.SCALE_X,1f,1.06f,1f),
                android.animation.PropertyValuesHolder.ofFloat(android.view.View.SCALE_Y,1f,1.06f,1f)
            ).apply{ duration=900; repeatCount=android.animation.ValueAnimator.INFINITE }
            fun startMouth(){
                mouthRunnable?.let{ mouthHandler.removeCallbacks(it) }
                val r=object:Runnable{ override fun run(){ mouth.visibility=if(mouth.visibility==View.VISIBLE) View.INVISIBLE else View.VISIBLE; mouthHandler.postDelayed(this,130) } }
                mouthRunnable=r; mouthHandler.post(r)
            }
            fun stopMouth(){ mouthRunnable?.let{ mouthHandler.removeCallbacks(it) }; mouth.visibility=View.INVISIBLE }
            val qView = TextView(this).apply { text = "Tu: $voiceText"; setTextColor(0xFF6B6B70.toInt()); textSize = 12f; setPadding(24,0,24,12) }
            val aView = TextView(this).apply { text = voiceResult; setTextColor(0xFF0A0A0A.toInt()); textSize = 14f; setPadding(24,0,24,24) }
            val container = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                setPadding(24,24,24,24)
                background=UiKit.card(this@MainActivity)
                addView(frame); addView(qView); addView(aView)
            }
            val spokenDialog = voiceResult
            tts?.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
                override fun onStart(id:String?){ runOnUiThread{ startMouth() } }
                override fun onDone(id:String?){ runOnUiThread{ stopMouth() } }
                override fun onError(id:String?){ runOnUiThread{ stopMouth() } }
                override fun onRangeStart(utteranceId:String?, start:Int, end:Int, frame:Int){
                    runOnUiThread{ startMouth() } // relance le rythme à chaque segment
                }
            })
            AlertDialog.Builder(this).setView(container).setPositiveButton("Fermer",null)
                .setOnDismissListener{ pulse.cancel(); stopMouth(); try{ tts?.stop() }catch(_:Exception){} }
                .show()
            pulse.start()
            if(voiceResult.isNotBlank()){
                try{ tts?.speak(voiceResult,TextToSpeech.QUEUE_FLUSH,null,"vanelle_utt") }catch(_:Exception){}
            }
    }
    
    private fun maybeShowOnboarding(){
        if(OnboardingPrefs.isDone(this)) return
        // Petit délai pour laisser l'UI se poser
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if(isFinishing) return@postDelayed
            val name = MascotManager.getDisplayName(this)
            AlertDialog.Builder(this)
                .setTitle("Bienvenue dans VanelleOS")
                .setMessage("Je suis $name, ta mascotte.\n\nPremiers pas magiques :\n• « Cassandra, batterie »\n• « Cassandra, ouvre calculatrice »\n• « Cassandra, je m'appelle … »\n• « Cassandra, retiens que … »\n\nEnsuite : style de mascotte, personnalité (calme / coach / pote), routines du matin, mode invité et journal dans Configuration.\n\nJe reste sur ton téléphone — tes souvenirs sont locaux.")
                .setPositiveButton("C'est parti"){ _,_ ->
                    OnboardingPrefs.setDone(this)
                    RoutineManager.ensureDefaultMorning(this)
                    val mid = try{ MascotManager.getDrawableId(this, MascotManager.getSelected(this)) }catch(_:Exception){0}
                    if(OverlayHelper.canDraw(this)){
                        OverlayHelper.showMascot(this, mid, "Salut ! Dis Cassandra suivi de ta demande.")
                    }
                    try{ tts?.speak("Salut ! Dis Cassandra suivi de ta demande.", android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "onboard") }catch(_:Exception){}
                }
                .setCancelable(false)
                .show()
        }, 1200)
    }

    override fun onDestroy(){ tts?.stop(); tts?.shutdown(); mouthRunnable?.let{ mouthHandler.removeCallbacks(it) }; super.onDestroy() }
    private fun requestNeededPermissions(){
        val needed=mutableListOf(Manifest.permission.RECORD_AUDIO,Manifest.permission.READ_CONTACTS,Manifest.permission.CALL_PHONE,Manifest.permission.SEND_SMS)
        if(Build.VERSION.SDK_INT>=33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing=needed.filter{ ContextCompat.checkSelfPermission(this,it)!=PackageManager.PERMISSION_GRANTED }
        if(missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
        else if(WakeWordPrefs.isEnabled(this)) startWakeService()
    }
    private fun startWakeService(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) return
        ContextCompat.startForegroundService(this,Intent(this,WakeWordService::class.java))
    }
    private fun isEnabled():Boolean{
        val exp="$packageName/${VanelleAccessibilityService::class.java.canonicalName}"
        val en=Settings.Secure.getString(contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val split=TextUtils.SimpleStringSplitter(':')
        split.setString(en)
        while(split.hasNext()){ if(split.next().equals(exp,true)) return true }
        return false
    }
}
class Adapter(a:AppCompatActivity): androidx.viewpager2.adapter.FragmentStateAdapter(a){
    override fun getItemCount()=4
    override fun createFragment(p:Int)= when(p){0->MascotFragment();1->ConfigFragment();2->FeaturesFragment();else->RelanceFragment()}
}
