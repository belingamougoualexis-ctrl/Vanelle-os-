package com.vanelle.os
import android.content.Context
object WakeWordPrefs{
    fun isEnabled(c:Context)= c.getSharedPreferences("vanelle_prefs",0).getBoolean("enabled",false)
    fun setEnabled(c:Context,e:Boolean){ c.getSharedPreferences("vanelle_prefs",0).edit().putBoolean("enabled",e).apply() }
}
