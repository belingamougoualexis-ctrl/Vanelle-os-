package com.vanelle.os
import android.content.Context
class WorkflowLearner(c:Context){
    private val v=MemoryVault(c)
    fun log(q:String){ try{ v.save("log_${System.currentTimeMillis()}",q) }catch(_:Exception){} }
}
