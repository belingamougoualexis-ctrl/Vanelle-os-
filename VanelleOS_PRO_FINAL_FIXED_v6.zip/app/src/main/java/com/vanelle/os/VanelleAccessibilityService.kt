package com.vanelle.os
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
class VanelleAccessibilityService:AccessibilityService(){
    companion object{ var instance:VanelleAccessibilityService?=null }
    override fun onServiceConnected(){ instance=this }
    override fun onUnbind(i:android.content.Intent?):Boolean{ instance=null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e:AccessibilityEvent?){}
    override fun onInterrupt(){}
    fun action(a:String)= when(a){
        "back"->performGlobalAction(GLOBAL_ACTION_BACK)
        "home"->performGlobalAction(GLOBAL_ACTION_HOME)
        "notifications"->performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "recents"->performGlobalAction(GLOBAL_ACTION_RECENTS)
        else->false
    }
    fun captureScreenText():String{
        val root=try{ rootInActiveWindow }catch(_:Exception){ null } ?: return ""
        return ScreenAnalysisHelper().capture(root)
    }
    fun clickNodeWithText(query:String):Boolean{
        if(query.isBlank()) return false
        val root=try{ rootInActiveWindow }catch(_:Exception){ null } ?: return false
        return try{ findAndClick(root,query.lowercase()) }finally{ try{ root.recycle() }catch(_:Exception){} }
    }
    private fun findAndClick(node:AccessibilityNodeInfo,query:String,depth:Int=0):Boolean{
        if(depth>30) return false
        try{
            val text=(node.text?.toString() ?: "").lowercase()
            val desc=(node.contentDescription?.toString() ?: "").lowercase()
            if((text.contains(query)||desc.contains(query))){
                var n:AccessibilityNodeInfo?=node
                var hops=0
                while(n!=null && hops<6){
                    if(n.isClickable){ val ok=n.performAction(AccessibilityNodeInfo.ACTION_CLICK); return ok }
                    n=n.parent; hops++
                }
            }
            for(i in 0 until node.childCount){
                val c=try{ node.getChild(i) }catch(_:Exception){ null } ?: continue
                try{ if(findAndClick(c,query,depth+1)) return true }finally{ try{ c.recycle() }catch(_:Exception){} }
            }
        }catch(_:Exception){}
        return false
    }

    /** Copilote : saisit du texte dans le champ focalisé ou le premier EditText trouvé. */
    fun fillFocusedOrFirstField(value: String): Boolean {
        if (value.isBlank()) return false
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        return try {
            val args = android.os.Bundle().apply {
                putCharSequence(android.view.accessibility.AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
            }
            // 1) nœud focalisé
            val focused = root.findFocus(android.view.accessibility.AccessibilityNodeInfo.FOCUS_INPUT)
            if (focused != null) {
                val ok = focused.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                try { focused.recycle() } catch (_: Exception) {}
                if (ok) return true
            }
            // 2) premier champ éditable
            return fillEditable(root, value, args, 0)
        } finally {
            try { root.recycle() } catch (_: Exception) {}
        }
    }
    private fun fillEditable(node: android.view.accessibility.AccessibilityNodeInfo, value: String, args: android.os.Bundle, depth: Int): Boolean {
        if (depth > 35) return false
        try {
            if (node.isEditable || node.className?.toString()?.contains("EditText", true) == true) {
                if (node.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_FOCUS)) {
                    // continue
                }
                if (node.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true
            }
            for (i in 0 until node.childCount) {
                val c = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
                try { if (fillEditable(c, value, args, depth + 1)) return true } finally { try { c.recycle() } catch (_: Exception) {} }
            }
        } catch (_: Exception) {}
        return false
    }

}
