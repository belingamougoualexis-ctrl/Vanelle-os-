package com.vanelle.os
import android.content.Context

object OnboardingPrefs {
    private fun p(c: Context) = c.getSharedPreferences("vanelle_prefs", 0)
    fun isDone(c: Context) = p(c).getBoolean("onboarding_done", false)
    fun setDone(c: Context) = p(c).edit().putBoolean("onboarding_done", true).apply()
}
