package com.vanelle.os
import android.view.accessibility.AccessibilityNodeInfo
class ScreenAnalysisHelper{
    fun capture(root:AccessibilityNodeInfo?):String{
        if(root==null) return ""
        val b=StringBuilder()
        try{ trav(root,b,0) }finally{ root.recycle() }
        return b.toString().replace(Regex("\\s+")," ").trim().take(8000)
    }
    private fun trav(n:AccessibilityNodeInfo,b:StringBuilder,d:Int){
        if(d>25) return
        try{
            n.text?.let{ if(it.isNotBlank()) b.append(it).append(" ") }
            for(i in 0 until n.childCount){ val c=try{ n.getChild(i) }catch(_:Exception){null} ?: continue; try{ trav(c,b,d+1) }finally{ c.recycle() } }
        }catch(_:Exception){}
    }
}
