package com.vanelle.os
import android.content.Context
object TranslateModePrefs{
    fun isActive(c:Context)= c.getSharedPreferences("vanelle_prefs",0).getBoolean("translate_active",false)
    fun source(c:Context)= c.getSharedPreferences("vanelle_prefs",0).getString("translate_source","auto") ?: "auto"
    fun target(c:Context)= c.getSharedPreferences("vanelle_prefs",0).getString("translate_target","fr") ?: "fr"
    fun start(c:Context,source:String,target:String){
        c.getSharedPreferences("vanelle_prefs",0).edit()
            .putBoolean("translate_active",true).putString("translate_source",source).putString("translate_target",target).apply()
    }
    fun stop(c:Context){ c.getSharedPreferences("vanelle_prefs",0).edit().putBoolean("translate_active",false).apply() }
}
