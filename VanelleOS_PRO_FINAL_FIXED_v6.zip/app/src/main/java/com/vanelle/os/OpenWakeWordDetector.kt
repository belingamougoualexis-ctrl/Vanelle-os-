package com.vanelle.os
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.nio.channels.FileChannel
import kotlinx.coroutines.*

/**
 * Pipeline openWakeWord (melspectrogram → embedding → classifieur custom "Cassandra").
 * Audio 16 kHz / 16-bit / mono, fenêtres de 1280 échantillons (80 ms),
 * fenêtre glissante de 16 embeddings pour le classifieur.
 * THRESHOLD réglé à 0.35 pour une meilleure sensibilité à voix normale
 * (l'utilisateur n'a pas besoin de crier).
 * Si détection trop sensible ou trop faible, ajuster THRESHOLD (0.30–0.55) ou EMBED_WINDOW.
 */
class OpenWakeWordDetector(private val context:Context){
    companion object{
        private const val SAMPLE_RATE=16000
        private const val CHUNK_SAMPLES=1280 // 80 ms
        private const val EMBED_WINDOW=16 // nombre d'embeddings consommes par le classifieur
        private const val THRESHOLD=0.35f
    }
    private var melInterp:Interpreter?=null
    private var embInterp:Interpreter?=null
    private var clsInterp:Interpreter?=null
    private val embedBuffer=ArrayDeque<FloatArray>()
    private var record:AudioRecord?=null
    private var job:Job?=null
    private val scope=CoroutineScope(Dispatchers.Default+SupervisorJob())

    private fun loadModel(file:File):Interpreter?{
        return try{
            val fis=FileInputStream(file)
            val channel=fis.channel
            val buffer=channel.map(FileChannel.MapMode.READ_ONLY,0,channel.size())
            Interpreter(buffer)
        }catch(_:Exception){ null }
    }
    private fun loadAssetModel(name:String):Interpreter?{
        return try{
            val afd=context.assets.openFd(name)
            val fis=FileInputStream(afd.fileDescriptor)
            val buffer=fis.channel.map(FileChannel.MapMode.READ_ONLY,afd.startOffset,afd.declaredLength)
            Interpreter(buffer)
        }catch(_:Exception){ null }
    }

    fun prepare():Boolean{
        if(!WakeWordModelManager.isReady(context)) return false
        melInterp=loadModel(WakeWordModelManager.melFile(context))
        embInterp=loadModel(WakeWordModelManager.embFile(context))
        clsInterp=loadAssetModel("wakeword_classifier.tflite")
        return melInterp!=null && embInterp!=null && clsInterp!=null
    }

    /** Ecoute en continu (sans bip systeme) et appelle onDetected() des qu'une detection franchit le seuil. */
    @Suppress("MissingPermission")
    fun start(onDetected:()->Unit){
        stop()
        if(melInterp==null && !prepare()) return
        val minBuf=AudioRecord.getMinBufferSize(SAMPLE_RATE,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
        if(minBuf<=0) return
        val rec=try{
            AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,SAMPLE_RATE,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,maxOf(minBuf,CHUNK_SAMPLES*4))
        }catch(_:Exception){ null } ?: return
        record=rec
        try{ rec.startRecording() }catch(_:Exception){ return }
        job=scope.launch{
            val buf=ShortArray(CHUNK_SAMPLES)
            while(isActive){
                val n=try{ rec.read(buf,0,CHUNK_SAMPLES) }catch(_:Exception){ -1 }
                if(n<=0){ delay(20); continue }
                try{
                    val mel=runMel(buf)
                    val emb=runEmbedding(mel) ?: continue
                    embedBuffer.addLast(emb)
                    while(embedBuffer.size>EMBED_WINDOW) embedBuffer.removeFirst()
                    if(embedBuffer.size==EMBED_WINDOW){
                        val score=runClassifier(embedBuffer.toList())
                        if(score>THRESHOLD) withContext(Dispatchers.Main){ onDetected() }
                    }
                }catch(_:Exception){}
            }
        }
    }

    fun stop(){
        job?.cancel(); job=null
        try{ record?.stop() }catch(_:Exception){}
        try{ record?.release() }catch(_:Exception){}
        record=null
        embedBuffer.clear()
    }

    private fun runMel(pcm:ShortArray):FloatArray{
        val input=Array(1){ FloatArray(pcm.size){ i-> pcm[i]/32768f } }
        val outShape=melInterp!!.getOutputTensor(0).shape()
        val outSize=outShape.fold(1){a,b->a*b}
        val output=Array(1){ FloatArray(outSize) }
        melInterp!!.run(input,output)
        return output[0]
    }
    private fun runEmbedding(melFrame:FloatArray):FloatArray?{
        return try{
            val input=arrayOf(melFrame)
            val outShape=embInterp!!.getOutputTensor(0).shape()
            val outSize=outShape.fold(1){a,b->a*b}
            val output=Array(1){ FloatArray(outSize) }
            embInterp!!.run(input,output)
            output[0]
        }catch(_:Exception){ null }
    }
    private fun runClassifier(embeddings:List<FloatArray>):Float{
        return try{
            val input=Array(1){ Array(embeddings.size){ i-> embeddings[i] } }
            val output=Array(1){ FloatArray(1) }
            clsInterp!!.run(input,output)
            output[0][0]
        }catch(_:Exception){ 0f }
    }
}
