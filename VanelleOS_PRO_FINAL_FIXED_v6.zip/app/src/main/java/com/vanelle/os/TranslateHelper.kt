package com.vanelle.os
import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class TranslateHelper(private val c:Context){
    companion object{
        val LANG_CODES=mapOf(
            "francais" to "fr","anglais" to "en","espagnol" to "es","allemand" to "de",
            "italien" to "it","portugais" to "pt","arabe" to "ar","chinois" to "zh-CN",
            "japonais" to "ja","coreen" to "ko","russe" to "ru","neerlandais" to "nl",
            "turc" to "tr","polonais" to "pl","suedois" to "sv","auto" to "auto"
        )
        fun codeFor(name:String):String?{
            val n=name.trim().lowercase()
                .replace("é","e").replace("è","e").replace("ê","e").replace("ç","c").replace("î","i")
            return LANG_CODES[n]
        }
    }
    fun translateText(text:String,source:String,target:String):String{
        if(text.isBlank()) return ""
        return try{
            val q=URLEncoder.encode(text,"UTF-8")
            val url=URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=$source&tl=$target&dt=t&q=$q")
            val conn=url.openConnection() as HttpURLConnection
            conn.connectTimeout=8000; conn.readTimeout=8000
            conn.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
            if(conn.responseCode !in 200..299) return "Traduction indisponible (serveur a repondu ${conn.responseCode})"
            val body=conn.inputStream.bufferedReader().readText()
            conn.disconnect()
            val arr=org.json.JSONArray(body)
            val segments=arr.getJSONArray(0)
            val sb=StringBuilder()
            for(i in 0 until segments.length()){ sb.append(segments.getJSONArray(i).getString(0)) }
            sb.toString().ifBlank{ "Traduction indisponible" }
        }catch(_:Exception){ "Traduction indisponible, verifie ta connexion" }
    }
}
