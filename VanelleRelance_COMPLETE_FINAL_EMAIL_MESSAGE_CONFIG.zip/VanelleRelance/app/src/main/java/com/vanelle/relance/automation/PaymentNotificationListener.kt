package com.vanelle.relance.automation

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import com.vanelle.relance.utils.PaymentDetectionHelper
import com.vanelle.relance.utils.ReplyDetectionHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class PaymentNotificationListener : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val notification = sbn.notification ?: return
        val extras = notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val combined = listOf(title, text, bigText).filter { it.isNotBlank() }.distinct().joinToString(" — ")
        if (combined.isBlank()) return

        scope.launch {
            val resultat = PaymentDetectionHelper.traiterTexte(
                applicationContext,
                combined,
                "Notification (${sbn.packageName})"
            )
            if (resultat !is PaymentDetectionHelper.DetectionResult.Paye) {
                ReplyDetectionHelper.traiterNotification(applicationContext, sbn.packageName, title, "$text $bigText")
            }
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
    }
}
