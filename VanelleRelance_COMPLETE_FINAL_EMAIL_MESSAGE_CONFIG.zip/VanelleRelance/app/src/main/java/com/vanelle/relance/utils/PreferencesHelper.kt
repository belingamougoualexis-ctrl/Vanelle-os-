package com.vanelle.relance.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

class PreferencesHelper(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("vanelle_relance_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_MSG_1 = "msg_relance_1"
        private const val KEY_MSG_2 = "msg_relance_2"
        private const val KEY_MSG_3 = "msg_relance_3"
        private const val KEY_NEG_1 = "msg_nego_douce"
        private const val KEY_NEG_2 = "msg_nego_plan"
        private const val KEY_NEG_3 = "msg_nego_offre"
        private const val KEY_LEGAL_ACCEPTED = "legal_accepted_v1"
        private const val KEY_DARK_MODE = "dark_mode"
        private const val KEY_MODE_PUDIQUE = "mode_pudique"
        private const val KEY_AUTO_WHATSAPP = "auto_whatsapp"
        private const val KEY_AUTO_EMAIL = "auto_email"
        private const val KEY_AUTO_PAYMENT_DETECTION = "auto_payment_detection"
        private const val KEY_PAUSE_SUR_REPONSE = "pause_relances_sur_reponse"

        val MSG_DEFAUT_1 =
            "Bonjour {nom}, un rappel amical : vous devez {montant} FCFA, échéance le {date}. Merci de régulariser dès que possible."
        val MSG_DEFAUT_2 =
            "Bonjour {nom}, nous revenons vers vous concernant les {montant} FCFA dus depuis le {date}. Merci de nous contacter pour régulariser."
        val MSG_DEFAUT_3 =
            "Bonjour {nom}, ceci est une relance importante : {montant} FCFA restent dus depuis le {date}. Merci de nous recontacter rapidement."

        val NEGO_DEFAUT_1 =
            "Bonjour {nom}, concernant les {montant} FCFA dus (échéance {date}), nous sommes ouverts à une discussion pour trouver un arrangement amiable. Merci de nous répondre."
        val NEGO_DEFAUT_2 =
            "Bonjour {nom}, pour faciliter le règlement des {montant} FCFA (échéance {date}), nous pouvons envisager un échéancier de paiement. Contactez-nous pour convenir des modalités."
        val NEGO_DEFAUT_3 =
            "Bonjour {nom}, dernière proposition concernant les {montant} FCFA dus depuis le {date} : nous sommes prêts à discuter d'une réduction ou d'un arrangement final. Merci de nous répondre rapidement."
    }

    var messageRelance1: String
        get() = prefs.getString(KEY_MSG_1, MSG_DEFAUT_1) ?: MSG_DEFAUT_1
        set(value) = prefs.edit { putString(KEY_MSG_1, value) }

    var messageRelance2: String
        get() = prefs.getString(KEY_MSG_2, MSG_DEFAUT_2) ?: MSG_DEFAUT_2
        set(value) = prefs.edit { putString(KEY_MSG_2, value) }

    var messageRelance3: String
        get() = prefs.getString(KEY_MSG_3, MSG_DEFAUT_3) ?: MSG_DEFAUT_3
        set(value) = prefs.edit { putString(KEY_MSG_3, value) }

    var messageNegoDouce: String
        get() = prefs.getString(KEY_NEG_1, NEGO_DEFAUT_1) ?: NEGO_DEFAUT_1
        set(value) = prefs.edit { putString(KEY_NEG_1, value) }

    var messageNegoPlan: String
        get() = prefs.getString(KEY_NEG_2, NEGO_DEFAUT_2) ?: NEGO_DEFAUT_2
        set(value) = prefs.edit { putString(KEY_NEG_2, value) }

    var messageNegoOffre: String
        get() = prefs.getString(KEY_NEG_3, NEGO_DEFAUT_3) ?: NEGO_DEFAUT_3
        set(value) = prefs.edit { putString(KEY_NEG_3, value) }

    var conditionsAcceptees: Boolean
        get() = prefs.getBoolean(KEY_LEGAL_ACCEPTED, false)
        set(value) = prefs.edit { putBoolean(KEY_LEGAL_ACCEPTED, value) }

    var modePudique: Boolean
        get() = prefs.getBoolean(KEY_MODE_PUDIQUE, false)
        set(value) = prefs.edit { putBoolean(KEY_MODE_PUDIQUE, value) }

    var relancesAutomatiquesWhatsApp: Boolean
        get() = prefs.getBoolean(KEY_AUTO_WHATSAPP, false)
        set(value) = prefs.edit { putBoolean(KEY_AUTO_WHATSAPP, value) }

    var relancesAutomatiquesEmail: Boolean
        get() = prefs.getBoolean(KEY_AUTO_EMAIL, false)
        set(value) = prefs.edit { putBoolean(KEY_AUTO_EMAIL, value) }

    var detectionAutomatiquePaiements: Boolean
        get() = prefs.getBoolean(KEY_AUTO_PAYMENT_DETECTION, true)
        set(value) = prefs.edit { putBoolean(KEY_AUTO_PAYMENT_DETECTION, value) }

    /** Quand un client répond (SMS/WhatsApp/e-mail détecté), faut-il mettre ses relances
     *  automatiques en pause ? C'est toujours l'utilisateur qui choisit, ici ou par client. */
    var pauseRelancesSurReponse: Boolean
        get() = prefs.getBoolean(KEY_PAUSE_SUR_REPONSE, true)
        set(value) = prefs.edit { putBoolean(KEY_PAUSE_SUR_REPONSE, value) }

    var modeSombre: Boolean?
        get() = if (!prefs.contains(KEY_DARK_MODE)) null else prefs.getBoolean(KEY_DARK_MODE, false)
        set(value) {
            if (value == null) prefs.edit { remove(KEY_DARK_MODE) }
            else prefs.edit { putBoolean(KEY_DARK_MODE, value) }
        }

    fun resetMessages() {
        prefs.edit {
            remove(KEY_MSG_1)
            remove(KEY_MSG_2)
            remove(KEY_MSG_3)
        }
    }

    fun resetMessagesNegociation() {
        prefs.edit {
            remove(KEY_NEG_1)
            remove(KEY_NEG_2)
            remove(KEY_NEG_3)
        }
    }
}
