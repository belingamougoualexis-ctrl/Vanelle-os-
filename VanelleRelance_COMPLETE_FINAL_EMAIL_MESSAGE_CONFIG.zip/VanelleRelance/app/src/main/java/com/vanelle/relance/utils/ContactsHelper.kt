package com.vanelle.relance.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

data class ContactSimple(
    val nom: String,
    val telephone: String,
    val email: String = ""
)

object ContactsHelper {

    fun permissionAccordee(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    /**
     * Récupère les contacts qui ont au moins un numéro de téléphone.
     * Limité à 300 pour rester fluide.
     */
    fun chargerContacts(context: Context): List<ContactSimple> {
        if (!permissionAccordee(context)) return emptyList()

        val resultat = mutableListOf<ContactSimple>()
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )

        context.contentResolver.query(uri, projection, null, null,
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC")?.use { cursor ->
            val idxId = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val idxNom = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val idxTel = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

            while (cursor.moveToNext() && resultat.size < 300) {
                val contactId = cursor.getLong(idxId)
                val nom = cursor.getString(idxNom)?.trim().orEmpty()
                val telBrut = cursor.getString(idxTel)?.trim().orEmpty()
                val telPropre = telBrut.filter { it.isDigit() || it == '+' }
                if (nom.isNotBlank() && telPropre.length >= 8) {
                    val email = emailPourContact(context, contactId)
                    if (resultat.none { it.nom == nom && it.telephone == telPropre }) {
                        resultat.add(ContactSimple(nom, telPropre, email))
                    }
                }
            }
        }
        return resultat
    }

    /** Retrouve automatiquement l'e-mail enregistré dans le contact correspondant au numéro. */
    fun emailPourTelephone(context: Context, telephone: String): String {
        if (!permissionAccordee(context)) return ""
        val cible = telephone.filter { it.isDigit() }
        if (cible.length < 8) return ""
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection,
            "${ContactsContract.CommonDataKinds.Phone.NUMBER} LIKE ?", arrayOf("%$cible"), null
        )?.use { c ->
            val idx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            if (c.moveToFirst()) return emailPourContact(context, c.getLong(idx))
        }
        return ""
    }

    private fun emailPourContact(context: Context, contactId: Long): String {
        val projection = arrayOf(ContactsContract.CommonDataKinds.Email.ADDRESS)
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI, projection,
            "${ContactsContract.CommonDataKinds.Email.CONTACT_ID} = ?", arrayOf(contactId.toString()), null
        )?.use { c ->
            val idx = c.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS)
            if (c.moveToFirst()) return c.getString(idx)?.trim().orEmpty()
        }
        return ""
    }
}
