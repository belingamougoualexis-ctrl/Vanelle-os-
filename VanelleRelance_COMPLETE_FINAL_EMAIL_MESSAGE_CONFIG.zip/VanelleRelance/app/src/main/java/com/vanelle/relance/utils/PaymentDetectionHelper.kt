package com.vanelle.relance.utils

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils
import com.vanelle.relance.automation.PaymentNotificationListener
import com.vanelle.relance.data.AppDatabase
import com.vanelle.relance.data.Client
import com.vanelle.relance.data.StatutDette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/**
 * Détecte les confirmations de paiement présentes dans les SMS entrants et les notifications
 * (Mobile Money, banques, etc.). L'identité du client (nom ou numéro) est toujours vérifiée
 * en premier ; le montant détecté sert ensuite à déterminer s'il s'agit d'un paiement total
 * ou seulement partiel (le solde restant est alors simplement réduit).
 */
object PaymentDetectionHelper {

    private val amountAfterCurrency = Regex(
        pattern = "(?i)([0-9][0-9\\s\\u00A0.,]{1,})\\s*(?:FCFA|XAF|CFA|F\\s?CFA)\\b"
    )
    private val amountBeforeCurrency = Regex(
        pattern = "(?i)(?:FCFA|XAF|CFA)\\s*([0-9][0-9\\s\\u00A0.,]{1,})\\b"
    )

    private val incomingKeywords = listOf(
        "vous avez reçu", "vous avez recu", "paiement reçu", "paiement recu",
        "transfert reçu", "transfert recu", "argent reçu", "argent recu",
        "versement reçu", "versement recu", "dépôt reçu", "depot recu",
        "reçu de", "recu de", "reçu un paiement", "recu un paiement",
        "a été crédité", "a ete credite", "crédité de", "credite de",
        "vous avez été crédité", "vous avez ete credite",
        "encaissement", "encaissé", "encaisse",
        "received", "payment received", "transfer received", "cash in", "credited",
        "credit received", "deposit received", "money received", "you have received"
    )

    // Signatures de services Mobile Money / bancaires courants en Afrique francophone.
    // Présents ou non, ils ne suffisent jamais seuls : les mots-clés "entrant" restent requis.
    private val providerHints = listOf(
        "orange money", "mtn mobile money", "mtn momo", "moov money", "wave",
        "airtel money", "express union", "afriland", "ecobank", "uba", "sabc",
        "western union", "ria money", "moneygram"
    )

    private val outgoingKeywords = listOf(
        "vous avez envoyé", "vous avez envoye", "envoyé à", "envoye a", "sent to",
        "transfert sortant", "retrait", "withdrawal", "achat", "purchase", "debit",
        "débit", "debité", "debite", "vous avez payé", "vous avez paye"
    )

    suspend fun traiterTexte(context: Context, texte: String, source: String): DetectionResult = withContext(Dispatchers.IO) {
        if (texte.isBlank()) return@withContext DetectionResult.Ignore

        val prefs = PreferencesHelper(context)
        if (!prefs.detectionAutomatiquePaiements) return@withContext DetectionResult.Ignore

        val normalized = texte.lowercase().replace('\u00A0', ' ')
        if (outgoingKeywords.any { normalized.contains(it) }) return@withContext DetectionResult.Ignore
        val ressembleAUnPaiement = incomingKeywords.any { normalized.contains(it) } ||
            (providerHints.any { normalized.contains(it) } && Regex("(?i)recu|reçu|credit").containsMatchIn(normalized))
        if (!ressembleAUnPaiement) return@withContext DetectionResult.Ignore

        val montants = extractAmounts(texte)
        if (montants.isEmpty()) return@withContext DetectionResult.Ignore

        val dao = AppDatabase.getInstance(context).clientDao()
        val ouverts = dao.getTous().first().filter { it.statut != StatutDette.PAYEE && it.detectionPaiementAuto }
        if (ouverts.isEmpty()) return@withContext DetectionResult.Ignore

        // IMPORTANT : le montant seul ne suffit jamais à identifier une personne.
        // On identifie d'abord le(s) client(s) mentionné(s) par nom ou numéro.
        val identifies = ouverts.filter { ClientMatcher.correspond(normalized, it) }
        val candidat = when {
            identifies.size == 1 -> identifies.single()
            else -> null // 0 = identité inconnue, >1 = identité ambiguë entre plusieurs clients
        } ?: return@withContext DetectionResult.NonAssociee(montants.first())

        // Parmi les montants détectés dans le message, on retient celui qui se rapproche le
        // plus du solde restant (les frais d'agent font parfois varier le montant affiché).
        val montant = montants.minByOrNull { kotlin.math.abs(it - candidat.montantRestant) } ?: montants.first()

        val montantEncaisse = montant.coerceAtMost(candidat.montantRestant)
        val nouveauCumul = candidat.montantPaye + montantEncaisse
        val soldeRestant = candidat.montant - nouveauCumul
        val paiementTotal = soldeRestant <= 0.01

        dao.mettreAJour(
            candidat.copy(
                montantPaye = nouveauCumul,
                statut = if (paiementTotal) StatutDette.PAYEE else candidat.statut,
                enAttenteReponse = if (paiementTotal) false else true,
                dernierContact = System.currentTimeMillis()
            )
        )
        HistoriqueHelper.enregistrer(
            context,
            if (paiementTotal) "PAIEMENT AUTO" else "PAIEMENT PARTIEL AUTO",
            candidat.nom,
            "$source — ${formatAmount(montant)} FCFA détectés automatiquement" +
                if (!paiementTotal) " (reste ${formatAmount(soldeRestant)} FCFA)" else ""
        )
        NotificationHelper.notifierPaiementDetecte(context, candidat, montant, source)
        DetectionResult.Paye(candidat, montant, paiementTotal)
    }

    private fun extractAmounts(text: String): List<Double> {
        val all = mutableListOf<Double>()
        for (match in amountAfterCurrency.findAll(text)) {
            parseAmount(match.groupValues[1])?.let(all::add)
        }
        for (match in amountBeforeCurrency.findAll(text)) {
            parseAmount(match.groupValues[1])?.let(all::add)
        }
        return all.distinct()
    }

    private fun parseAmount(raw: String): Double? {
        val digits = raw.filter(Char::isDigit)
        return if (digits.isEmpty()) null else digits.toDoubleOrNull()
    }

    private fun formatAmount(value: Double): String =
        "%,.0f".format(value).replace(',', ' ')

    fun notificationAccessActive(context: Context): Boolean {
        val expected = ComponentName(context, PaymentNotificationListener::class.java)
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            if (ComponentName.unflattenFromString(splitter.next()) == expected) return true
        }
        return false
    }

    fun openNotificationAccessSettings(context: Context) {
        context.startActivity(
            Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    sealed interface DetectionResult {
        data object Ignore : DetectionResult
        data class Paye(val client: Client, val montant: Double, val total: Boolean) : DetectionResult
        data class NonAssociee(val montant: Double) : DetectionResult
    }
}
