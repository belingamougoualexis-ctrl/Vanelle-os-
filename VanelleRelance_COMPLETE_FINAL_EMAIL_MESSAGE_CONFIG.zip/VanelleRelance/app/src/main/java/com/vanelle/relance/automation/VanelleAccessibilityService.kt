package com.vanelle.relance.automation

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.vanelle.relance.data.Client
import java.net.URLEncoder
import java.util.ArrayDeque

/**
 * Automatisation volontaire de l'action d'envoi dans les applications choisies.
 * L'utilisateur doit activer ce service lui-même dans Paramètres > Accessibilité.
 *
 * Le service est strictement limité à WhatsApp/WhatsApp Business et Gmail et
 * utilise uniquement ACTION_CLICK sur un nœud d'accessibilité identifié.
 * Aucun geste tactile par coordonnées n'est généré.
 */
class VanelleAccessibilityService : AccessibilityService() {

    private data class Task(
        val type: String,
        val client: Client,
        val message: String,
        val subject: String = ""
    )

    private val queue = ArrayDeque<Task>()
    private var activeTask: Task? = null
    private var clickInProgress = false
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    // Déclenche une vérification courte après un événement d'interface, au lieu
    // d'interroger continuellement l'écran avec un polling périodique.
    private val eventCheckRunnable = Runnable {
        activeTask?.let { tryClickSend(it) }
    }

    // Limite la durée pendant laquelle une tâche peut rester active si l'application
    // tierce n'affiche jamais le bouton d'envoi.
    private val timeoutRunnable = Runnable {
        activeTask?.let { onTaskTimedOut(it) }
    }

    companion object {
        const val ACTION_SEND_WHATSAPP = "com.vanelle.relance.SEND_WHATSAPP"
        const val ACTION_SEND_EMAIL = "com.vanelle.relance.SEND_EMAIL"
        private const val EVENT_CHECK_DELAY_MS = 250L
        private const val TASK_TIMEOUT_MS = 15_000L
        @Volatile var instance: VanelleAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        handler.removeCallbacks(eventCheckRunnable)
        handler.removeCallbacks(timeoutRunnable)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val task = activeTask ?: return
        val packageName = event?.packageName?.toString() ?: return
        if (!isExpectedPackage(task, packageName)) return

        // Les événements d'interface servent uniquement de déclencheurs.
        // Une seule vérification est planifiée après une courte stabilisation.
        handler.removeCallbacks(eventCheckRunnable)
        handler.postDelayed(eventCheckRunnable, EVENT_CHECK_DELAY_MS)
    }

    private fun isExpectedPackage(task: Task, packageName: String): Boolean {
        return if (task.type == ACTION_SEND_WHATSAPP) {
            packageName == "com.whatsapp" || packageName == "com.whatsapp.w4b"
        } else {
            packageName == "com.google.android.gm"
        }
    }

    /**
     * Trouve le bouton d'envoi dans la fenêtre active et utilise uniquement
     * AccessibilityNodeInfo.ACTION_CLICK. Aucun clic par coordonnées n'est utilisé.
     */
    private fun tryClickSend(task: Task): Boolean {
        if (clickInProgress) return true

        val root = rootInActiveWindow ?: return false
        val labels = listOf(
            "Envoyer",
            "Send",
            "Envoyer le message",
            "Send message",
            "Envoyer l'e-mail"
        )

        val send = findClickable(root, labels)
            ?: findByViewId(root, listOf("send"))
            ?: return false

        clickInProgress = true
        handler.removeCallbacks(timeoutRunnable)

        if (send.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            finishTask()
        } else {
            // Si l'application tierce refuse ACTION_CLICK, Vanelle n'essaie pas
            // de simuler un toucher physique : l'utilisateur peut terminer l'envoi.
            onTaskTimedOut(task)
        }
        return true
    }

    private fun onTaskTimedOut(task: Task) {
        handler.removeCallbacks(eventCheckRunnable)
        handler.removeCallbacks(timeoutRunnable)
        android.widget.Toast.makeText(
            this,
            "Vanelle n'a pas pu envoyer automatiquement le message à ${task.client.nom}. Terminez l'envoi manuellement (bouton Envoyer), la relance suivante attend en file.",
            android.widget.Toast.LENGTH_LONG
        ).show()
        activeTask = null
        clickInProgress = false
        startNext(this)
    }

    override fun onInterrupt() {
        // Aucun traitement spécial requis.
    }

    fun queueWhatsApp(context: android.content.Context, client: Client, message: String) {
        queue.add(Task(ACTION_SEND_WHATSAPP, client, message))
        if (activeTask == null) startNext(context)
    }

    fun queueEmail(context: android.content.Context, client: Client, subject: String, body: String) {
        queue.add(Task(ACTION_SEND_EMAIL, client, body, subject))
        if (activeTask == null) startNext(context)
    }

    private fun startNext(context: android.content.Context) {
        if (queue.isEmpty()) {
            activeTask = null
            clickInProgress = false
            return
        }

        val task = queue.removeFirst()
        activeTask = task
        clickInProgress = false
        handler.removeCallbacks(eventCheckRunnable)
        handler.removeCallbacks(timeoutRunnable)

        try {
            if (task.type == ACTION_SEND_WHATSAPP) {
                val phone = task.client.telephone.filter(Char::isDigit)
                val uri = Uri.parse(
                    "https://wa.me/$phone?text=${URLEncoder.encode(task.message, "UTF-8")}"
                )
                context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("com.whatsapp")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            } else {
                val uriMailto = "mailto:" + Uri.encode(task.client.email) +
                    "?subject=" + Uri.encode(task.subject) +
                    "&body=" + Uri.encode(task.message)
                context.startActivity(Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse(uriMailto)
                    putExtra(Intent.EXTRA_SUBJECT, task.subject)
                    putExtra(Intent.EXTRA_TEXT, task.message)
                    setPackage("com.google.android.gm")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }

            // Un seul délai de sécurité pour éviter qu'une tâche reste bloquée.
            // La détection du bouton elle-même reste déclenchée par les événements.
            handler.postDelayed(timeoutRunnable, TASK_TIMEOUT_MS)
        } catch (_: Exception) {
            activeTask = null
            handler.postDelayed({ startNext(this) }, 500)
        }
    }

    private fun finishTask() {
        handler.removeCallbacks(eventCheckRunnable)
        handler.removeCallbacks(timeoutRunnable)
        activeTask = null
        clickInProgress = false
        handler.postDelayed({ startNext(this) }, 900)
    }

    private fun findClickable(
        root: AccessibilityNodeInfo,
        labels: List<String>
    ): AccessibilityNodeInfo? {
        for (label in labels) {
            root.findAccessibilityNodeInfosByText(label)
                .firstOrNull { it.isVisibleToUser && it.isEnabled }
                ?.let { node ->
                    findClickableAncestor(node)?.let { return it }
                }
        }
        return findByContentDescription(root, labels)
    }


    private fun findClickableAncestor(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var current: AccessibilityNodeInfo? = node
        repeat(8) {
            val candidate = current ?: return null
            if (candidate.isVisibleToUser && candidate.isEnabled && candidate.isClickable) {
                return candidate
            }
            current = candidate.parent
        }
        return null
    }

    private fun findByContentDescription(
        root: AccessibilityNodeInfo,
        labels: List<String>
    ): AccessibilityNodeInfo? {
        val desc = root.contentDescription?.toString()?.lowercase() ?: ""
        if (root.isVisibleToUser && root.isEnabled && root.isClickable &&
            labels.any { desc.contains(it.lowercase()) }
        ) return root

        for (i in 0 until root.childCount) {
            root.getChild(i)?.let { child ->
                findByContentDescription(child, labels)?.let { return it }
            }
        }
        return null
    }

    /**
     * Recherche par identifiant de ressource, notamment pour les boutons icône
     * de Gmail qui peuvent ne pas exposer de texte accessible.
     */
    private fun findByViewId(
        root: AccessibilityNodeInfo,
        idKeywords: List<String>
    ): AccessibilityNodeInfo? {
        val id = root.viewIdResourceName?.lowercase() ?: ""
        if (root.isVisibleToUser && root.isEnabled && root.isClickable &&
            idKeywords.any { id.contains(it) }
        ) return root

        for (i in 0 until root.childCount) {
            root.getChild(i)?.let { child ->
                findByViewId(child, idKeywords)?.let { return it }
            }
        }
        return null
    }
}
