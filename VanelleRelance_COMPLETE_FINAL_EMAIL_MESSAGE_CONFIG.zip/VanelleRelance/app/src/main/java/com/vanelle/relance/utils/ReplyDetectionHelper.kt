package com.vanelle.relance.utils

import android.content.Context
import com.vanelle.relance.data.AppDatabase
import com.vanelle.relance.data.Client
import com.vanelle.relance.data.StatutDette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/**
 * Détecte qu'un client a répondu (SMS, WhatsApp, e-mail) pour mettre ses relances
 * automatiques en pause. C'est toujours réversible : l'utilisateur choisit, globalement
 * dans Réglages ou client par client, s'il veut arrêter ou continuer malgré tout.
 */
object ReplyDetectionHelper {

    // Packages de messagerie surveillés pour la détection de réponse via notification.
    // On ignore volontairement les autres apps pour éviter les faux positifs.
    private val packagesMessagerie = setOf(
        "com.whatsapp", "com.whatsapp.w4b",
        "com.google.android.gm", "com.google.android.apps.messaging",
        "com.android.mms", "com.samsung.android.messaging"
    )

    /** Un SMS entrant vient de [numeroExpediteur] : correspond-il à un client suivi ? */
    suspend fun traiterSms(context: Context, numeroExpediteur: String, corps: String) = withContext(Dispatchers.IO) {
        if (numeroExpediteur.isBlank()) return@withContext
        val dao = AppDatabase.getInstance(context).clientDao()
        val ouverts = dao.getTous().first().filter { it.statut != StatutDette.PAYEE && !it.enAttenteReponse }
        val client = ouverts.firstOrNull { ClientMatcher.correspondNumero(numeroExpediteur, it) } ?: return@withContext
        marquerReponse(context, client, "SMS")
    }

    /** Une notification (WhatsApp, Gmail, SMS) est arrivée : correspond-elle à un client suivi ? */
    suspend fun traiterNotification(context: Context, packageName: String, titre: String, texte: String) = withContext(Dispatchers.IO) {
        if (packageName !in packagesMessagerie) return@withContext
        val combine = "$titre $texte".lowercase().replace('\u00A0', ' ')
        if (combine.isBlank()) return@withContext

        val dao = AppDatabase.getInstance(context).clientDao()
        val ouverts = dao.getTous().first().filter { it.statut != StatutDette.PAYEE && !it.enAttenteReponse }
        val identifies = ouverts.filter { ClientMatcher.correspond(combine, it) }
        // On exige une identité non-ambiguë, comme pour la détection de paiement.
        val client = identifies.singleOrNull() ?: return@withContext
        val source = when (packageName) {
            "com.whatsapp", "com.whatsapp.w4b" -> "WhatsApp"
            "com.google.android.gm" -> "E-mail"
            else -> "SMS"
        }
        marquerReponse(context, client, source)
    }

    private suspend fun marquerReponse(context: Context, client: Client, source: String) {
        val prefs = PreferencesHelper(context)
        val dao = AppDatabase.getInstance(context).clientDao()
        val actuel = dao.getParId(client.id) ?: return
        if (actuel.enAttenteReponse) return
        dao.mettreAJour(actuel.copy(enAttenteReponse = true))
        HistoriqueHelper.enregistrer(
            context,
            "REPONSE_CLIENT",
            actuel.nom,
            if (prefs.pauseRelancesSurReponse)
                "Réponse détectée via $source — relances automatiques mises en pause"
            else
                "Réponse détectée via $source — relances automatiques poursuivies (choix utilisateur)"
        )
        NotificationHelper.notifierReponseClient(context, actuel, source)
    }
}
