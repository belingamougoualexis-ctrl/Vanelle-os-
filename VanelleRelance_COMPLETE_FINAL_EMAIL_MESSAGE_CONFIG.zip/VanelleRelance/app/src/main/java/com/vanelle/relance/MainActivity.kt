package com.vanelle.relance

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.vanelle.relance.security.CryptoManager
import com.vanelle.relance.ui.screens.*
import com.vanelle.relance.ui.theme.VanelleRelanceTheme
import com.vanelle.relance.ui.theme.DisableCopyText
import com.vanelle.relance.utils.AutomationHelper
import com.vanelle.relance.utils.PermissionHelper
import com.vanelle.relance.utils.PreferencesHelper
import kotlinx.coroutines.delay

sealed class Onglet(val route: String, val label: String, val icone: ImageVector) {
    object Relance : Onglet("relance", "Relance", Icons.Default.Home)
    object Sommes : Onglet("sommes", "Sommes", Icons.Default.AccountBalanceWallet)
    object Radar : Onglet("radar", "Radar", Icons.Default.Notifications)
    object Oublies : Onglet("oublies", "Oubliés", Icons.Default.History)
    object Reglages : Onglet("reglages", "Réglages", Icons.Default.Settings)
    object Outils : Onglet("outils", "Outils", Icons.Default.Build)
}

val onglets = listOf(Onglet.Relance, Onglet.Sommes, Onglet.Radar, Onglet.Oublies, Onglet.Outils, Onglet.Reglages)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val context = LocalContext.current
            val prefsHelper = remember { PreferencesHelper(context) }
            var darkPref by remember { mutableStateOf(prefsHelper.modeSombre) }
            val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
            val useDark = darkPref ?: systemDark

            VanelleRelanceTheme(darkTheme = useDark) {
                DisableCopyText {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        val cryptoManager = remember { CryptoManager(context) }

                        var conditionsOk by remember { mutableStateOf(prefsHelper.conditionsAcceptees) }
                        var deverrouille by remember { mutableStateOf(!cryptoManager.estConfigure()) }
                        var accessibiliteOk by remember { mutableStateOf(AutomationHelper.serviceActive(context)) }

                        // Re-vérifie à chaque retour au premier plan (après Paramètres)
                        val lifecycleOwner = LocalLifecycleOwner.current
                        DisposableEffect(lifecycleOwner) {
                            val observer = LifecycleEventObserver { _, event ->
                                if (event == Lifecycle.Event.ON_RESUME) {
                                    accessibiliteOk = AutomationHelper.serviceActive(context)
                                }
                            }
                            lifecycleOwner.lifecycle.addObserver(observer)
                            onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
                        }

                        when {
                            !conditionsOk -> {
                                LegalScreen(prefsHelper = prefsHelper) {
                                    conditionsOk = true
                                }
                            }
                            !deverrouille -> {
                                VerrouillageScreen(cryptoManager = cryptoManager) {
                                    deverrouille = true
                                }
                            }
                            else -> {
                                // L'accessibilité n'est pas imposée à tous les utilisateurs.
                                // Elle est demandée uniquement lorsqu'une fonction qui en a
                                // réellement besoin (WhatsApp/Gmail automatiques) est utilisée.
                                EcranPrincipalAvecPermissions()
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Écran bloquant : l'app ne continue pas tant que le service d'accessibilité
 * n'est pas activé. Si l'utilisateur refuse / revient sans activer,
 * un message reste affiché en bas.
 */
@Composable
fun AccessibilityGateScreen(
    onActivated: () -> Unit,
    onStillRefused: () -> Unit
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var aRefuse by remember { mutableStateOf(false) }
    var verificationEnCours by remember { mutableStateOf(false) }

    // Message permanent en bas si l'utilisateur a déjà refusé / est revenu sans activer
    LaunchedEffect(aRefuse) {
        if (aRefuse) {
            while (true) {
                snackbarHostState.showSnackbar(
                    message = "Le service d'accessibilité est obligatoire. Activez-le pour continuer.",
                    duration = SnackbarDuration.Indefinite,
                    withDismissAction = false
                )
                delay(500)
            }
        }
    }

    // Vérifie périodiquement si l'utilisateur a activé le service
    LaunchedEffect(Unit) {
        while (true) {
            delay(800)
            if (AutomationHelper.serviceActive(context)) {
                onActivated()
                break
            }
        }
    }

    Scaffold(
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                Icons.Default.Accessibility,
                contentDescription = null,
                modifier = Modifier.size(72.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(20.dp))
            Text(
                "Service d'accessibilité requis",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "Pour envoyer automatiquement les relances WhatsApp et Gmail, " +
                    "Vanelle Relance a besoin du Service d'accessibilité Android.\n\n" +
                    "Cette activation est volontaire et uniquement sous votre contrôle. " +
                    "Sans cette activation, l'application ne peut pas continuer.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(32.dp))

            Button(
                onClick = {
                    verificationEnCours = true
                    AutomationHelper.openAccessibilitySettings(context)
                    // Si l'utilisateur revient sans activer → message en bas
                    aRefuse = true
                    onStillRefused()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Accessibility, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Activer le service d'accessibilité")
            }

            Spacer(Modifier.height(12.dp))

            OutlinedButton(
                onClick = {
                    aRefuse = true
                    onStillRefused()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Plus tard")
            }

            if (verificationEnCours || aRefuse) {
                Spacer(Modifier.height(24.dp))
                Text(
                    "En attente de votre activation…\nRien ne continue tant que le service n'est pas activé.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun EcranPrincipalAvecPermissions() {
    val context = LocalContext.current
    var permissionsDemandees by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* résultats système */ }

    LaunchedEffect(Unit) {
        if (!permissionsDemandees) {
            val manquantes = PermissionHelper.permissionsManquantes(context)
            if (manquantes.isNotEmpty()) {
                launcher.launch(manquantes)
            }
            permissionsDemandees = true
        }
    }

    EcranPrincipal()
}

@Composable
fun EcranPrincipal() {
    val navController: NavHostController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar {
                val backStackEntry by navController.currentBackStackEntryAsState()
                val routeActuelle = backStackEntry?.destination?.route

                onglets.forEach { onglet ->
                    NavigationBarItem(
                        selected = routeActuelle == onglet.route,
                        onClick = {
                            navController.navigate(onglet.route) {
                                popUpTo(navController.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(onglet.icone, contentDescription = onglet.label) },
                        label = { Text(onglet.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Onglet.Relance.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Onglet.Relance.route) { RelanceScreen() }
            composable(Onglet.Sommes.route) { SommesScreen() }
            composable(Onglet.Radar.route) { RadarScreen() }
            composable(Onglet.Oublies.route) { OubliesScreen() }
            composable(Onglet.Outils.route) { OutilsScreen() }
            composable(Onglet.Reglages.route) { ReglagesScreen() }
        }
    }
}
