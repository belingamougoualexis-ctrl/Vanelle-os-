package com.vanelle.relance.utils

import com.vanelle.relance.data.Client

/**
 * Logique de correspondance texte <-> client, partagée entre la détection de paiement
 * et la détection de réponse d'un client (SMS, WhatsApp, e-mail).
 */
object ClientMatcher {

    /** Le [texteNormalise] (déjà en minuscules) mentionne-t-il clairement ce [client] ? */
    fun correspond(texteNormalise: String, client: Client): Boolean {
        val textAscii = texteNormalise.normalizeToAscii()
        val normalizedName = client.nom
            .lowercase()
            .normalizeToAscii()
            .replace(Regex("\\s+"), " ")
            .trim()

        // 1) Correspondance forte sur le nom complet.
        // On exige au moins 4 caractères pour éviter les faux positifs (ex. "Ali").
        if (normalizedName.length >= 4 && textAscii.contains(normalizedName)) return true

        // 2) Correspondance forte sur le numéro : on compare les 8 derniers chiffres,
        // ce qui fonctionne même si le message affiche +237XXXXXXXXX ou seulement XXXXXXXX.
        val phoneDigits = client.telephone.filter(Char::isDigit)
        val textDigits = textAscii.filter(Char::isDigit)
        if (phoneDigits.length >= 8) {
            val suffix8 = phoneDigits.takeLast(8)
            if (textDigits.contains(suffix8)) return true
        }

        // 3) Certaines passerelles affichent prénom + nom séparément. On accepte
        // une correspondance par tokens significatifs uniquement si au moins deux
        // morceaux du nom sont présents dans le message.
        val nameParts = normalizedName.split(Regex("\\s+"))
            .filter { it.length >= 3 }
            .distinct()
        if (nameParts.size >= 2) {
            val matched = nameParts.count { textAscii.contains(it) }
            if (matched >= 2) return true
        }

        return false
    }

    /** Le numéro d'un SMS entrant (originatingAddress) correspond-il à ce client ? */
    fun correspondNumero(numeroEntrant: String, client: Client): Boolean {
        val entrant = numeroEntrant.filter(Char::isDigit)
        val duClient = client.telephone.filter(Char::isDigit)
        if (entrant.length < 8 || duClient.length < 8) return false
        return entrant.takeLast(8) == duClient.takeLast(8)
    }

    fun String.normalizeToAscii(): String =
        java.text.Normalizer.normalize(this, java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
}
