package com.vanelle.relance.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vanelle.relance.utils.AutomationHelper
import com.vanelle.relance.utils.HistoriqueHelper
import com.vanelle.relance.utils.MessageHelper
import com.vanelle.relance.utils.SmsHelper
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class ClientViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getInstance(application).clientDao()

    val tousLesClients = dao.getTous()
    val clientsEnRetard = dao.getEnRetard()
    val totalDu = dao.getTotalDu()
    val totalRecupere = dao.getTotalRecupere()

    fun clientsOublies() = dao.getOublies(
        System.currentTimeMillis() - TimeUnit.DAYS.toMillis(21)
    )

    fun ajouter(client: Client) = viewModelScope.launch {
        dao.inserer(client)
    }


    /** Ajoute le client puis tente la première relance immédiatement.
     *  Aucun paiement ou envoi n'est considéré comme réussi sans retour positif du canal.
     */
    fun ajouterEtRelancerImmediatement(client: Client) = viewModelScope.launch {
        val id = dao.inserer(client)
        val saved = dao.getParId(id) ?: return@launch
        val context = getApplication<Application>()
        val message = MessageHelper.genererMessageRelance(context, saved, saved.nombreRelances)
        val sent = when (saved.canalRelance) {
            CanalRelance.SMS -> SmsHelper.envoyerTexte(context, saved, message)
            CanalRelance.WHATSAPP -> AutomationHelper.serviceActive(context) &&
                AutomationHelper.startWhatsApp(context, saved, message)
            CanalRelance.GMAIL -> AutomationHelper.serviceActive(context) &&
                AutomationHelper.startEmail(context, saved, saved.objetEmail, message)
        }
        if (sent) {
            dao.mettreAJour(saved.copy(nombreRelances = 1, dernierContact = System.currentTimeMillis()))
            HistoriqueHelper.enregistrer(context, "PREMIERE_RELANCE", saved.nom, "Première relance automatique")
        }
    }

    fun mettreAJour(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client)
    }

    fun supprimer(client: Client) = viewModelScope.launch {
        dao.supprimer(client)
    }

    /**
     * Marque un paiement. Si [montant] est null (ou couvre tout le reste dû), la dette
     * passe entièrement à PAYEE. Sinon, il s'agit d'un paiement partiel : le solde restant
     * est réduit mais le client reste "En cours"/"En retard" jusqu'à ce que tout soit réglé.
     */
    fun marquerPaye(client: Client, montant: Double? = null) = viewModelScope.launch {
        val restantAvant = client.montantRestant
        val montantEncaisse = (montant ?: restantAvant).coerceIn(0.0, restantAvant)
        val nouveauCumul = client.montantPaye + montantEncaisse
        val soldeRestant = client.montant - nouveauCumul
        dao.mettreAJour(
            client.copy(
                montantPaye = nouveauCumul,
                statut = if (soldeRestant <= 0.01) StatutDette.PAYEE else client.statut,
                enAttenteReponse = if (soldeRestant <= 0.01) false else client.enAttenteReponse
            )
        )
    }

    /** Remet une dette payée en « En cours » ; le solde redevient intégralement dû. */
    fun marquerEnCours(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client.copy(statut = StatutDette.EN_COURS, montantPaye = 0.0))
    }

    /** Le client a répondu (SMS, WhatsApp ou e-mail détecté) : on met les relances en pause. */
    fun marquerReponseRecue(client: Client) = viewModelScope.launch {
        val actuel = dao.getParId(client.id) ?: return@launch
        if (!actuel.enAttenteReponse) {
            dao.mettreAJour(actuel.copy(enAttenteReponse = true))
        }
    }

    /** L'utilisateur choisit de reprendre les relances malgré la réponse du client. */
    fun reprendreRelances(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client.copy(enAttenteReponse = false))
    }


    /** Les relances sont immédiates/automatiques : aucun délai minimum n'est appliqué. */
    fun peutRelancer(client: Client, maintenant: Long = System.currentTimeMillis()): Boolean = true

    /** Enregistre toute relance sans blocage temporel. */
    fun enregistrerRelanceSiAutorisee(client: Client) = viewModelScope.launch {
        val actuel = dao.getParId(client.id) ?: return@launch
        dao.mettreAJour(
            actuel.copy(
                nombreRelances = actuel.nombreRelances + 1,
                dernierContact = System.currentTimeMillis()
            )
        )
    }

    fun enregistrerRelance(client: Client) = viewModelScope.launch {
        dao.mettreAJour(
            client.copy(
                nombreRelances = client.nombreRelances + 1,
                dernierContact = System.currentTimeMillis()
            )
        )
    }
}
