package com.vanelle.os

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.yield
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min

/**
 * Wrapper optimisé autour de llamacpp-kotlin (réflexion).
 *
 * Optimisations :
 * - Instance unique process-wide (un seul chargement du modèle)
 * - n_ctx adapté à la RAM (384–1024) pour limiter OOM
 * - Prompt système compact (moins de tokens de préfill)
 * - Contexte utilisateur tronqué
 * - Timeout adaptatif selon la taille de la requête
 * - warmUp() au démarrage de l'app
 * - Mutex pour sérialiser les inférences (un seul contexte natif)
 * - Succès de charge détecté via callback (Long) ET événement Loaded du SharedFlow
 * - Pas de boucle de 10+ tentatives : 2 essais max (ctx optimal puis repli)
 */
class LocalLlamaHelper private constructor(private val appContext: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val events = MutableSharedFlow<Any>(extraBufferCapacity = 512, replay = 0)

    @Volatile private var loaded = false
    @Volatile private var loading = false
    @Volatile private var loadFailedPermanently = false
    @Volatile private var helper: Any? = null
    @Volatile private var resolvedClass: Class<*>? = null
    private val answerMutex = Mutex()
    private val loadMutex = Mutex()

    private fun resolveLlamaClass(): Class<*>? {
        resolvedClass?.let { return it }
        val candidates = listOf(
            "org.nehuatl.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacppkotlin.LlamaHelper",
            "com.ljcamargo.llamacpp.LlamaHelper"
        )
        for (name in candidates) {
            try {
                val c = Class.forName(name)
                resolvedClass = c
                android.util.Log.i("VanelleLlama", "LlamaHelper résolu: $name")
                return c
            } catch (_: ClassNotFoundException) {}
        }
        android.util.Log.e("VanelleLlama", "Aucune classe LlamaHelper trouvée parmi: $candidates")
        return null
    }

    /** Fenêtre de contexte selon la mémoire disponible (moins de RAM → plus rapide / stable). */
    private fun optimalContextLength(): Int {
        // Contextes volontairement modestes = chargement plus rapide et moins d'OOM.
        return try {
            val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memMb = am.largeMemoryClass
            val ramMb = LlamaModelManager.totalRamMb(appContext)
            when {
                ramMb >= 6144 && memMb >= 768 -> 768
                ramMb >= 4096 && memMb >= 512 -> 512
                else -> 256
            }
        } catch (_: Exception) {
            256
        }
    }

    @Volatile private var lastLoadError: String? = null

    fun lastError(): String? = lastLoadError

    private suspend fun ensureLoaded(): Boolean {
        if (loaded && helper != null) return true
        if (loadFailedPermanently) return false
        if (!LlamaModelManager.isReady(appContext)) {
            lastLoadError = "Modèle non téléchargé."
            return false
        }
        return loadMutex.withLock {
            if (loaded && helper != null) return@withLock true
            if (loadFailedPermanently) return@withLock false
            if (loading) {
                // Attendre un chargement concurrent déjà en cours (max 120 s)
                repeat(120) {
                    kotlinx.coroutines.delay(1000)
                    if (loaded && helper != null) return@withLock true
                    if (!loading) return@withLock (loaded && helper != null)
                }
                return@withLock (loaded && helper != null)
            }
            loading = true
            try {
                // Llama est toujours tenté en priorité. Plusieurs contextes
                // permettent de réduire la mémoire KV/cache sur les appareils faibles.
                val contexts = listOf(optimalContextLength(), 192, 128).distinct()
                var ok = false
                for ((attempt, nCtx) in contexts.withIndex()) {
                    if (attempt > 0) {
                        try { System.gc() } catch (_: Exception) {}
                        kotlinx.coroutines.delay(1500)
                    }
                    ok = tryLoadOnce(nCtx, timeoutMs = 120_000L)
                    if (ok) {
                        lastLoadError = null
                        android.util.Log.i("VanelleLlama", "Modèle chargé (n_ctx=$nCtx, tentative=${attempt + 1})")
                        AiLoadDiagnostics.logSuccess(appContext, "chargé avec n_ctx=$nCtx (tentative ${attempt + 1}/${contexts.size})")
                        return@withLock true
                    }
                }
                loadFailedPermanently = true
                if (lastLoadError == null) {
                    lastLoadError = LlamaModelManager.memoryWarning(appContext)
                        ?: "Impossible de charger l'IA en mémoire. Ferme d'autres apps, libère de la RAM, puis rouvre VanelleOS."
                }
                android.util.Log.e("VanelleLlama", "Échec du chargement unique: $lastLoadError")
                AiLoadDiagnostics.logFailure(appContext, lastLoadError ?: "cause inconnue", attempt = contexts.size)
                false
            } catch (e: Exception) {
                android.util.Log.e("VanelleLlama", "ensureLoaded exception", e)
                loadFailedPermanently = true
                lastLoadError = "Erreur de chargement : ${e.message ?: "inconnue"}"
                AiLoadDiagnostics.logFailure(appContext, lastLoadError ?: "exception inconnue")
                false
            } finally {
                loading = false
            }
        }
    }

    private suspend fun tryLoadOnce(nCtx: Int, timeoutMs: Long): Boolean {
        return try {
            val klass = resolveLlamaClass()
            if (klass == null) {
                lastLoadError = "Bibliothèque IA locale absente (variante modern / 64 bits requise)."
                return false
            }
            val ctor = try {
                klass.getConstructor(
                    android.content.ContentResolver::class.java,
                    CoroutineScope::class.java,
                    MutableSharedFlow::class.java
                )
            } catch (e: Exception) {
                android.util.Log.e("VanelleLlama", "Constructeur LlamaHelper introuvable", e)
                lastLoadError = "API LlamaHelper incompatible."
                null
            } ?: return false

            val modelFile = LlamaModelManager.modelFile(appContext)
            if (!modelFile.exists() || modelFile.length() != LlamaModelManager.EXPECTED_MIN_BYTES ||
                !LlamaModelManager.verifyModelIntegrity(appContext)) {
                lastLoadError = "Fichier modèle manquant, tronqué ou corrompu. Le téléchargement sera vérifié avant un nouvel essai."
                android.util.Log.e("VanelleLlama", "Intégrité GGUF invalide: ${modelFile.length()} octets")
                return false
            }

            // URI stable : FileProvider si possible, sinon file://
            val modelUri = try {
                androidx.core.content.FileProvider.getUriForFile(
                    appContext,
                    "${appContext.packageName}.fileprovider",
                    modelFile
                ).toString()
            } catch (_: Exception) {
                Uri.fromFile(modelFile).toString()
            }

            // Libère un peu de heap avant le gros mmap/load natif
            try { System.gc() } catch (_: Exception) {}

            val h = ctor.newInstance(appContext.contentResolver, scope, events)

            // Signature officielle v0.4.0 :
            // load(path, contextLength, mmprojPath?, loaded: (Long) -> Unit)
            val loadMethod = try {
                klass.getMethod(
                    "load",
                    String::class.java,
                    Int::class.javaPrimitiveType,
                    String::class.java,
                    kotlin.jvm.functions.Function1::class.java
                )
            } catch (_: Exception) {
                klass.methods.firstOrNull { m -> m.name == "load" && m.parameterTypes.size >= 2 }
            }
            if (loadMethod == null) {
                lastLoadError = "Méthode load() introuvable dans la bibliothèque IA."
                return false
            }

            val ok = withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    val done = java.util.concurrent.atomic.AtomicBoolean(false)
                    fun complete(success: Boolean) {
                        if (done.compareAndSet(false, true) && cont.isActive) {
                            cont.resume(success)
                        }
                    }

                    val watchJob = scope.launch {
                        try {
                            events.takeWhile { event ->
                                when (event.javaClass.simpleName) {
                                    "Loaded" -> {
                                        complete(true)
                                        false
                                    }
                                    "Error" -> {
                                        android.util.Log.w("VanelleLlama", "LLMEvent.Error: $event")
                                        lastLoadError = "Erreur native lors du chargement du modèle."
                                        complete(false)
                                        false
                                    }
                                    else -> true
                                }
                            }.collect { }
                        } catch (_: Exception) {}
                    }

                    try {
                        val callback = object : kotlin.jvm.functions.Function1<Long, Unit> {
                            override fun invoke(id: Long) {
                                android.util.Log.i("VanelleLlama", "Callback load OK, contextId=$id")
                                complete(true)
                            }
                        }
                        when (loadMethod.parameterTypes.size) {
                            4 -> loadMethod.invoke(h, modelUri, nCtx, null, callback)
                            3 -> {
                                try {
                                    loadMethod.invoke(h, modelUri, nCtx, callback)
                                } catch (_: Exception) {
                                    loadMethod.invoke(h, modelUri, nCtx, null)
                                }
                            }
                            2 -> loadMethod.invoke(h, modelUri, nCtx)
                            else -> loadMethod.invoke(h, modelUri)
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("VanelleLlama", "invoke load failed", e)
                        lastLoadError = "Échec chargement : ${e.message ?: e.javaClass.simpleName}"
                        complete(false)
                    }

                    cont.invokeOnCancellation { watchJob.cancel() }
                }
            } ?: run {
                lastLoadError = "Délai dépassé lors du chargement en mémoire."
                false
            }

            if (ok) {
                helper = h
                loaded = true
                loadFailedPermanently = false
                lastLoadError = null
            } else {
                android.util.Log.w("VanelleLlama", "tryLoadOnce(nCtx=$nCtx): échec — $lastLoadError")
            }
            ok
        } catch (e: Exception) {
            android.util.Log.e("VanelleLlama", "tryLoadOnce(nCtx=$nCtx) exception", e)
            lastLoadError = "Erreur : ${e.message ?: "inconnue"}"
            false
        }
    }

    /**
     * Précharge le modèle. ensureLoaded() gère déjà son propre réessai interne
     * (contexte optimal puis repli) — pas besoin de reboucler par-dessus ici.
     */
    suspend fun warmUp(): Boolean = withContext(Dispatchers.IO) {
        if (!LlamaModelManager.isReady(appContext)) return@withContext false
        if (loaded && helper != null) return@withContext true
        if (loadFailedPermanently) return@withContext false
        ensureLoaded()
    }

    fun isLoaded(): Boolean = loaded && helper != null

    /** Réinitialise le flag d'échec permanent (ex. après redémarrage app ou nouvel essai manuel). */
    fun resetLoadFailure() {
        loadFailedPermanently = false
        lastLoadError = null
    }

    /**
     * @param maxTokensHint limite soft côté collecteur (coupe tôt si réponse déjà longue)
     * @param fastMode prompt encore plus court + timeout réduit (commandes simples)
     */
    suspend fun answer(
        userPrompt: String,
        extraContext: String = "",
        fastMode: Boolean = false,
        maxTokensHint: Int = if (fastMode) 64 else 120
    ): String = answerMutex.withLock {
        if (!ensureLoaded()) return@withLock NOT_READY
        val h = helper ?: return@withLock NOT_READY
        val klass = h.javaClass

        val formatted = buildPrompt(userPrompt, extraContext, fastMode)
        val timeoutMs = adaptiveTimeoutMs(formatted.length, fastMode)

        return@withLock try {
            val predictMethod = listOf(
                arrayOf(String::class.java, String::class.java),
                arrayOf(String::class.java)
            ).firstNotNullOfOrNull { types ->
                try { klass.getMethod("predict", *types) } catch (_: Exception) { null }
            } ?: listOf("generate", "complete", "chat", "ask").firstNotNullOfOrNull { name ->
                try { klass.getMethod(name, String::class.java) } catch (_: Exception) { null }
            } ?: return@withLock NOT_READY

            withTimeoutOrNull(timeoutMs) {
                // 1) Essai synchrone : si predict retourne une String
                try {
                    val raw = when (predictMethod.parameterTypes.size) {
                        2 -> predictMethod.invoke(h, formatted, null)
                        else -> predictMethod.invoke(h, formatted)
                    }
                    when (raw) {
                        is String -> {
                            val cleaned = raw.trim()
                                .removePrefix("assistant")
                                .trim()
                            if (cleaned.isNotBlank()) return@withTimeoutOrNull cleaned
                        }
                    }
                } catch (_: Exception) { /* mode flux */ }

                // 2) Mode streaming via SharedFlow
                suspendCancellableCoroutine<String> { cont ->
                    val job = scope.launch {
                        try {
                            val sb = StringBuilder(maxTokensHint * 4)
                            var tokenApprox = 0

                            val collector = launch {
                                try {
                                    events.takeWhile { event ->
                                        val name = event.javaClass.simpleName
                                        when (name) {
                                            "Ongoing" -> {
                                                val word = extractToken(event)
                                                if (word.isNotEmpty()) {
                                                    sb.append(word)
                                                    tokenApprox++
                                                }
                                                tokenApprox < maxTokensHint && sb.length < maxTokensHint * 8
                                            }
                                            "Done" -> {
                                                val finalTxt = extractToken(event)
                                                if (finalTxt.isNotEmpty() && sb.isEmpty()) sb.append(finalTxt)
                                                false
                                            }
                                            "Error" -> false
                                            else -> {
                                                val word = extractToken(event)
                                                if (word.isNotEmpty()) {
                                                    sb.append(word)
                                                    tokenApprox++
                                                }
                                                tokenApprox < maxTokensHint
                                            }
                                        }
                                    }.collect { }
                                } catch (_: Exception) {}
                            }

                            yield()
                            when (predictMethod.parameterTypes.size) {
                                2 -> predictMethod.invoke(h, formatted, null)
                                else -> predictMethod.invoke(h, formatted)
                            }
                            withTimeoutOrNull(timeoutMs) { collector.join() }
                            collector.cancel()

                            val text = sb.toString().trim()
                                .removePrefix("assistant")
                                .trim()
                            if (cont.isActive) {
                                cont.resume(text.ifBlank { NOT_READY })
                            }
                        } catch (_: Exception) {
                            if (cont.isActive) cont.resume(NOT_READY)
                        }
                    }
                    cont.invokeOnCancellation { job.cancel() }
                }
            } ?: NOT_READY
        } catch (_: Exception) {
            NOT_READY
        }
    }

    private fun extractToken(event: Any): String {
        for (method in listOf("getWord", "getToken", "getText", "getContent", "getMessage")) {
            try {
                val v = event.javaClass.getMethod(method).invoke(event)
                if (v is String && v.isNotEmpty()) return v
            } catch (_: Exception) {}
        }
        try {
            for (f in event.javaClass.declaredFields) {
                f.isAccessible = true
                val v = f.get(event)
                if (v is String && v.isNotEmpty() && v.length < 200) return v
            }
        } catch (_: Exception) {}
        return ""
    }

    private fun buildPrompt(userPrompt: String, extraContext: String, fastMode: Boolean): String {
        val system = if (fastMode) {
            "Tu es Vanelle, assistante vocale réelle et locale sur Android. Mission : aider concrètement " +
                "l'utilisateur sur son téléphone. Français, 1-2 phrases, naturel. " +
                "Utilise le prénom de l'utilisateur s'il est dans le contexte. " +
                "Aucune réponse inventée. Si action téléphone : ligne ACTION:TYPE|arg."
        } else {
            "Tu es Vanelle, assistante IA réelle et locale installée sur le téléphone de l'utilisateur. " +
                "Ta mission : comprendre ses intentions, exécuter des actions sur l'appareil, " +
                "lire et analyser l'écran (service d'accessibilité), mémoriser le contexte utile, " +
                "et répondre en français naturel (1-3 phrases). Tu n'es pas une IA cloud : " +
                "tu es présente ici, maintenant, sur cet appareil. " +
                "Si le prénom de l'utilisateur est dans le contexte, utilise-le quand c'est naturel. " +
                "Ne simule rien, ne donne pas d'exemples fictifs, base-toi uniquement sur le contexte et la demande. " +
                "Pour une action téléphone, mets EN PREMIER: " +
                "ACTION:YOUTUBE|requête ou ACTION:OPEN_APP|nom ou ACTION:CALL|nom ou " +
                "ACTION:MESSAGE|nom|texte ou ACTION:SEARCH|requête ou ACTION:MAPS|lieu ou " +
                "ACTION:TIMER|minutes ou ACTION:FLASHLIGHT|on/off ou ACTION:VOLUME|up/down ou " +
                "ACTION:SCREEN_SUMMARY ou ACTION:CLICK|texte. " +
                "Sinon réponds normalement sans ligne ACTION."
        }
        val ctx = extraContext.trim().take(if (fastMode) 180 else 500)
        val user = userPrompt.trim().take(if (fastMode) 200 else 360)

        return buildString(capacity = 2200) {
            append("<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n")
            append(system)
            if (ctx.isNotBlank()) {
                append("\nContexte: ")
                append(ctx)
            }
            append("\n<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n")
            append(user)
            append("\n<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n")
        }
    }

    private fun adaptiveTimeoutMs(promptChars: Int, fastMode: Boolean): Long {
        val base = if (fastMode) 30_000L else 60_000L
        val extra = (promptChars / 8).toLong()
        return min(120_000L, max(base, base + extra))
    }

    companion object {
        const val NOT_READY = "__LLAMA_NOT_READY__"

        @Volatile private var instance: LocalLlamaHelper? = null

        fun get(context: Context): LocalLlamaHelper {
            instance?.let { return it }
            synchronized(this) {
                instance?.let { return it }
                val created = LocalLlamaHelper(context.applicationContext)
                instance = created
                return created
            }
        }
    }
}
