# Vanelle Relance — Version finale 1.3

Application Android **réelle et complète** de gestion / relance de créances clients.

**100 % locale — aucune API externe requise.**

---

## Comportement des relances

| Canal | Comportement |
|-------|----------------|
| **SMS** | Envoi **automatique** depuis la carte SIM du téléphone |
| **WhatsApp** | Message **pré-rempli** → WhatsApp s’ouvre → **l’utilisateur appuie sur Envoyer** |
| **Appel** | L’appel est **lancé** depuis le téléphone |
| **E-mail / Gmail** | La première relance part **immédiatement à l’enregistrement** ; les suivantes sont automatiques à l’heure choisie |

### Rappels même si l’app est fermée
- WorkManager vérifie les échéances régulièrement
- Les clients en retard passent automatiquement au statut « En retard »
- L’heure de relance configurée est respectée même si le worker Android démarre légèrement après cette heure
- Le nombre maximal de relances est respecté (`0 = illimité`)
- Une **notification système** s’affiche pour les retards et les paiements détectés

### Détection automatique des paiements
- **SMS entrants** : Vanelle analyse les confirmations de paiement reçues sur le téléphone
- **Notifications des apps de paiement** : après activation de l’accès aux notifications Android
- Le moteur recherche un **paiement reçu**, extrait le montant et tente de l’associer à un client via son nom/numéro ; si un seul client correspond au montant, la dette peut être marquée automatiquement comme **Payée**
- Les paiements ambigus ou partiels ne sont pas automatiquement attribués afin d’éviter les faux positifs
- Une intégration bancaire/fintech réellement serveur-à-serveur nécessitera l’API ou le webhook du prestataire

---

## Fonctionnalités

### Clients
- Ajout / édition / suppression
- Import depuis les **Contacts** du téléphone
- Format téléphone **international** (sélecteur de pays, validation, avertissement si pays inconnu)
- Notes, recherche, **filtres avec compteurs**, **tri**
- Export / partage de la liste
- Réouvrir une dette payée
- Anti-doublon

### Relance
- SMS automatique, WhatsApp automatique, Gmail automatique via le Service d’Accessibilité activé volontairement
- E-mail : quand Gmail est choisi, les champs **adresse e-mail** et **objet** apparaissent ; la première relance est lancée immédiatement après « Ajouter / Enregistrer »
- Choix de **l’heure quotidienne** de relance et du **nombre maximal** de relances (`0 = illimité`)
- Messages **personnalisables** (3 niveaux) — placeholders `{nom}` `{montant}` `{date}`
- Confirmation avant « Marquer payé »
- Affichage du dernier contact

### Sécurité & permissions
- PIN + code de récupération (chiffré)
- Permissions demandées au démarrage + re-demande intelligente

### Autres écrans
- **Radar** (priorité du jour)
- **Oubliés** (≥ 21 jours sans contact)
- **Sommes** (total dû / récupéré / taux)

---

## Premier lancement

1. **Conditions d’utilisation + Politique de confidentialité**
   - Lecture obligatoire jusqu’en bas (défilement)
   - Case à cocher puis « J’ai lu et j’accepte »
   - Sans acceptation, l’app ne continue pas
2. Configuration / saisie du PIN (si activé)
3. Demande des permissions système
4. Accès à l’application

## Compiler & lancer

1. Installez **Android Studio**
2. `File → Open` → dossier `VanelleRelance`
3. Laissez Gradle synchroniser
4. Branchez un téléphone ou lancez un émulateur
5. Bouton **Run ▶**

- minSdk 26 / targetSdk 34  
- Kotlin + Jetpack Compose + Room + WorkManager  

---

## Structure

```
app/src/main/java/com/vanelle/relance/
├── MainActivity.kt
├── VanelleRelanceApp.kt
├── data/          (Client, Dao, Database, ViewModel)
├── ui/screens/    (tous les écrans)
├── ui/theme/
├── utils/         (Phone, Permissions, SMS, WhatsApp, Call, Contacts, Notifications, Prefs)
├── security/      (PIN)
└── work/          (RappelWorker + BootReceiver)
```

Prêt pour usage réel et publication (en justifiant les permissions SMS/Appel pour la gestion de créances).

## Build CI / GitHub Actions

Le dossier du projet **doit** s’appeler `VanelleRelance` à la racine du dépôt (ou adapte `ANDROID_DIR`).

Exemple d’étape workflow :

```yaml
- name: Build Android
  run: |
    set -euo pipefail
    ANDROID_DIR=./VanelleRelance
    if [ ! -d "$ANDROID_DIR" ]; then
      echo "Dossier $ANDROID_DIR introuvable. Contenu racine :"
      ls -la
      exit 1
    fi
    cd "$ANDROID_DIR"
    chmod +x ./gradlew
    ./gradlew assembleDebug --stacktrace --no-daemon
```

Variables :
- `ANDROID_DIR` = chemin vers ce projet Android natif (pas React Native)
- `RN_ROOT` n’est **pas** utilisé par cette app (app 100 % Android / Kotlin)

Erreur `exit code 1` fréquente :
1. Le dossier `VanelleRelance` n’est pas dans le repo clôné
2. `gradlew` non exécutable → `chmod +x gradlew`
3. SDK Android absent sur le runner → utiliser `android-actions/setup-android` ou image `macos`/`ubuntu` avec SDK
