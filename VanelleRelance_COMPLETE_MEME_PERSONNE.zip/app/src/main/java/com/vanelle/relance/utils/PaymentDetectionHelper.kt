package com.vanelle.relance.utils

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils
import com.vanelle.relance.automation.PaymentNotificationListener
import com.vanelle.relance.data.AppDatabase
import com.vanelle.relance.data.Client
import com.vanelle.relance.data.StatutDette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Détecte les confirmations de paiement présentes dans les SMS entrants et les notifications.
 * L'app ne marque automatiquement une dette comme payée que lorsque le montant correspond
 * exactement à une dette ouverte et que l'identification du client est suffisamment fiable.
 */
object PaymentDetectionHelper {

    private val amountAfterCurrency = Regex(
        pattern = "(?i)([0-9][0-9\\s\\u00A0.,]{1,})\\s*(?:FCFA|XAF|CFA)\\b"
    )
    private val amountBeforeCurrency = Regex(
        pattern = "(?i)(?:FCFA|XAF|CFA)\\s*([0-9][0-9\\s\\u00A0.,]{1,})\\b"
    )

    private val incomingKeywords = listOf(
        "vous avez reçu", "vous avez recu", "paiement reçu", "paiement recu",
        "transfert reçu", "transfert recu", "argent reçu", "argent recu",
        "versement reçu", "versement recu", "dépôt reçu", "depot recu",
        "received", "payment received", "transfer received", "cash in", "credited",
        "credit received", "deposit received", "money received"
    )

    private val outgoingKeywords = listOf(
        "vous avez envoyé", "vous avez envoye", "envoyé à", "envoye a", "sent to",
        "transfert sortant", "retrait", "withdrawal", "achat", "purchase", "debit",
        "débit", "debité", "debite"
    )

    suspend fun traiterTexte(context: Context, texte: String, source: String): DetectionResult = withContext(Dispatchers.IO) {
        if (texte.isBlank()) return@withContext DetectionResult.Ignore

        val prefs = PreferencesHelper(context)
        if (!prefs.detectionAutomatiquePaiements) return@withContext DetectionResult.Ignore

        val normalized = texte.lowercase().replace('\u00A0', ' ')
        if (outgoingKeywords.any { normalized.contains(it) }) return@withContext DetectionResult.Ignore
        if (!incomingKeywords.any { normalized.contains(it) }) return@withContext DetectionResult.Ignore

        val montants = extractAmounts(texte)
        if (montants.isEmpty()) return@withContext DetectionResult.Ignore

        val dao = AppDatabase.getInstance(context).clientDao()
        val ouverts = dao.getTous().first().filter { it.statut != StatutDette.PAYEE }
        if (ouverts.isEmpty()) return@withContext DetectionResult.Ignore

        for (montant in montants.distinct()) {
            val candidatsMontant = ouverts.filter { abs(it.montant - montant) < 0.01 }
            if (candidatsMontant.isEmpty()) continue

            // IMPORTANT : le montant seul ne suffit jamais pour identifier une personne.
            // On exige une identité correspondant au client (nom ou numéro de téléphone).
            // Cela évite de marquer comme payée la mauvaise personne lorsque plusieurs
            // clients doivent exactement le même montant.
            val candidatsIdentifies = candidatsMontant.filter { correspondAuClient(normalized, it) }
            val candidat = when {
                candidatsIdentifies.size == 1 -> candidatsIdentifies.single()
                else -> null // 0 = identité inconnue, >1 = identité ambiguë
            } ?: continue

            dao.mettreAJour(
                candidat.copy(
                    statut = StatutDette.PAYEE,
                    dernierContact = System.currentTimeMillis()
                )
            )
            HistoriqueHelper.enregistrer(
                context,
                "PAIEMENT AUTO",
                candidat.nom,
                "$source — ${formatAmount(montant)} FCFA détectés automatiquement"
            )
            NotificationHelper.notifierPaiementDetecte(context, candidat, montant, source)
            return@withContext DetectionResult.Paye(candidat, montant)
        }

        DetectionResult.NonAssociee(montants.first())
    }

    private fun extractAmounts(text: String): List<Double> {
        val all = mutableListOf<Double>()
        for (match in amountAfterCurrency.findAll(text)) {
            parseAmount(match.groupValues[1])?.let(all::add)
        }
        for (match in amountBeforeCurrency.findAll(text)) {
            parseAmount(match.groupValues[1])?.let(all::add)
        }
        return all.distinct()
    }

    private fun parseAmount(raw: String): Double? {
        val digits = raw.filter(Char::isDigit)
        return if (digits.isEmpty()) null else digits.toDoubleOrNull()
    }

    private fun correspondAuClient(normalizedText: String, client: Client): Boolean {
        val textAscii = normalizedText.normalizeToAscii()
        val normalizedName = client.nom
            .lowercase()
            .normalizeToAscii()
            .replace(Regex("\\s+"), " ")
            .trim()

        // 1) Correspondance forte sur le nom complet.
        // On exige au moins 4 caractères pour éviter les faux positifs (ex. "Ali").
        if (normalizedName.length >= 4 && textAscii.contains(normalizedName)) return true

        // 2) Correspondance forte sur le numéro : on compare les 8 derniers chiffres,
        // ce qui fonctionne même si le SMS affiche +237XXXXXXXXX ou seulement XXXXXXXX.
        val phoneDigits = client.telephone.filter(Char::isDigit)
        val textDigits = textAscii.filter(Char::isDigit)
        if (phoneDigits.length >= 8) {
            val suffix8 = phoneDigits.takeLast(8)
            if (textDigits.contains(suffix8)) return true
        }

        // 3) Certaines passerelles affichent prénom + nom séparément. On accepte
        // une correspondance par tokens significatifs uniquement si au moins deux
        // morceaux du nom sont présents dans le message.
        val nameParts = normalizedName.split(Regex("\\s+"))
            .filter { it.length >= 3 }
            .distinct()
        if (nameParts.size >= 2) {
            val matched = nameParts.count { textAscii.contains(it) }
            if (matched >= 2) return true
        }

        return false
    }

    private fun String.normalizeToAscii(): String =
        java.text.Normalizer.normalize(this, java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")

    private fun formatAmount(value: Double): String =
        "%,.0f".format(value).replace(',', ' ')

    fun notificationAccessActive(context: Context): Boolean {
        val expected = ComponentName(context, PaymentNotificationListener::class.java)
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            if (ComponentName.unflattenFromString(splitter.next()) == expected) return true
        }
        return false
    }

    fun openNotificationAccessSettings(context: Context) {
        context.startActivity(
            Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    sealed interface DetectionResult {
        data object Ignore : DetectionResult
        data class Paye(val client: Client, val montant: Double) : DetectionResult
        data class NonAssociee(val montant: Double) : DetectionResult
    }
}
