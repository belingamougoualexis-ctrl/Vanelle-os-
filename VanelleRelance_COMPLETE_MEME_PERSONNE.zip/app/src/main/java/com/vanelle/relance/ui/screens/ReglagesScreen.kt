package com.vanelle.relance.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.vanelle.relance.security.CryptoManager
import com.vanelle.relance.utils.PreferencesHelper
import com.vanelle.relance.utils.BackupHelper
import com.vanelle.relance.utils.HistoriqueHelper
import com.vanelle.relance.utils.AutomationHelper
import com.vanelle.relance.utils.PaymentDetectionHelper
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

@Composable
fun ReglagesScreen() {
    val context = LocalContext.current
    val cryptoManager = remember { CryptoManager(context) }
    val prefsHelper = remember { PreferencesHelper(context) }

    var permSms by remember { mutableStateOf(estAccordee(context, Manifest.permission.SEND_SMS)) }
    var permReceiveSms by remember { mutableStateOf(estAccordee(context, Manifest.permission.RECEIVE_SMS)) }
    var permAppel by remember { mutableStateOf(estAccordee(context, Manifest.permission.CALL_PHONE)) }
    var permContacts by remember { mutableStateOf(estAccordee(context, Manifest.permission.READ_CONTACTS)) }
    var permNotif by remember {
        mutableStateOf(
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU)
                estAccordee(context, Manifest.permission.POST_NOTIFICATIONS)
            else true
        )
    }

    var afficherConfigPin by remember { mutableStateOf(false) }
    var codeRecuperationAffiche by remember { mutableStateOf<String?>(null) }
    var afficherMessages by remember { mutableStateOf(false) }
    var afficherMessagesNego by remember { mutableStateOf(false) }
    var afficherDesinstall by remember { mutableStateOf(false) }
    var afficherHistorique by remember { mutableStateOf(false) }
    var modeSombreLocal by remember { mutableStateOf(prefsHelper.modeSombre) }
    val scope = rememberCoroutineScope()

    val demanderSms = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { accorde ->
        permSms = accorde
    }
    val demanderReceiveSms = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { accorde ->
        permReceiveSms = accorde
    }
    val demanderAppel = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { accorde ->
        permAppel = accorde
    }
    val demanderContacts = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { accorde ->
        permContacts = accorde
    }
    val demanderNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { accorde ->
        permNotif = accorde
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Permissions", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            "Ces autorisations sont demandées au démarrage. Vous pouvez les gérer ici à tout moment.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        LignePermission(
            titre = "Envoyer des SMS",
            icone = Icons.Default.Sms,
            accordee = permSms
        ) { demanderSms.launch(Manifest.permission.SEND_SMS) }

        LignePermission(
            titre = "Détection des paiements par SMS",
            icone = Icons.Default.Payment,
            accordee = permReceiveSms
        ) { demanderReceiveSms.launch(Manifest.permission.RECEIVE_SMS) }

        LignePermission(
            titre = "Passer des appels",
            icone = Icons.Default.Call,
            accordee = permAppel
        ) { demanderAppel.launch(Manifest.permission.CALL_PHONE) }

        LignePermission(
            titre = "Lire les contacts",
            icone = Icons.Default.Contacts,
            accordee = permContacts
        ) { demanderContacts.launch(Manifest.permission.READ_CONTACTS) }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            LignePermission(
                titre = "Notifications",
                icone = Icons.Default.Notifications,
                accordee = permNotif
            ) { demanderNotif.launch(Manifest.permission.POST_NOTIFICATIONS) }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Autorenew, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Détection automatique des paiements", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                var detectionActive by remember { mutableStateOf(prefsHelper.detectionAutomatiquePaiements) }
                Text(
                    "Vanelle surveille les SMS entrants et, après votre autorisation système, les notifications des services de paiement. Un client n'est marqué payé que si le montant correspond à une dette ouverte et que le message ressemble clairement à un paiement reçu.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text(if (detectionActive) "Détection active" else "Détection désactivée", fontWeight = FontWeight.Medium)
                    Switch(
                        checked = detectionActive,
                        onCheckedChange = {
                            detectionActive = it
                            prefsHelper.detectionAutomatiquePaiements = it
                        }
                    )
                }
                Button(onClick = { PaymentDetectionHelper.openNotificationAccessSettings(context) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.NotificationsActive, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (PaymentDetectionHelper.notificationAccessActive(context)) "Accès aux notifications activé" else "Autoriser les notifications de paiement")
                }
                Text(
                    "L'accès aux notifications est séparé des permissions SMS et doit être activé dans les réglages Android. Sur certains appareils, le système peut limiter les services de notification en arrière-plan.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Automatisation des relances", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Vanelle peut ouvrir WhatsApp ou Gmail et cliquer sur « Envoyer » à votre place. Cette fonction ne nécessite pas d'API. Elle fonctionne uniquement après votre activation manuelle du Service d’Accessibilité Android.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(onClick = { AutomationHelper.openAccessibilitySettings(context) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Accessibility, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (AutomationHelper.serviceActive()) "Service d'accessibilité activé" else "Activer le service d'accessibilité")
                }
                Text(
                    "Toutes les relances configurées sont automatiques. Le canal (WhatsApp, SMS ou Gmail) est choisi lors de la création de chaque relance. WhatsApp et Gmail nécessitent le Service d’Accessibilité activé volontairement.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        HorizontalDivider()

        Text("Messages de relance", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            "Personnalisez les textes envoyés par SMS et WhatsApp. Utilisez les placeholders {nom}, {montant} et {date}.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("1ère relance, 2ème/3ème, relance importante…", style = MaterialTheme.typography.bodyMedium)
                Button(
                    onClick = { afficherMessages = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Modifier les messages")
                }
            }
        }

        HorizontalDivider()

        Text("Messages de négociation", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            "Proposez un arrangement amiable, un échéancier ou une offre finale. Placeholders : {nom}, {montant}, {date}.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Discussion amiable, plan de paiement, offre finale…", style = MaterialTheme.typography.bodyMedium)
                Button(
                    onClick = { afficherMessagesNego = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Handshake, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Modifier les messages de négociation")
                }
            }
        }

        HorizontalDivider()

        Text("Sécurité", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (cryptoManager.estConfigure()) Icons.Default.Lock else Icons.Default.Lock,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        if (cryptoManager.estConfigure()) "Verrouillage PIN activé"
                        else "Aucun code PIN configuré",
                        fontWeight = FontWeight.Medium
                    )
                }
                Button(
                    onClick = { afficherConfigPin = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (cryptoManager.estConfigure()) "Modifier le code PIN" else "Configurer un code PIN")
                }
            }
        }

        HorizontalDivider()

        Text("Apparence", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Thème de l'application", fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = modeSombreLocal == null,
                        onClick = {
                            modeSombreLocal = null
                            prefsHelper.modeSombre = null
                        },
                        label = { Text("Système") }
                    )
                    FilterChip(
                        selected = modeSombreLocal == false,
                        onClick = {
                            modeSombreLocal = false
                            prefsHelper.modeSombre = false
                        },
                        label = { Text("Clair") }
                    )
                    FilterChip(
                        selected = modeSombreLocal == true,
                        onClick = {
                            modeSombreLocal = true
                            prefsHelper.modeSombre = true
                        },
                        label = { Text("Sombre") }
                    )
                }
                Text(
                    "Redémarrez l'écran principal pour appliquer le thème si besoin.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        HorizontalDivider()

        Text("Données", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        scope.launch {
                            try {
                                val json = BackupHelper.exporterJson(context)
                                context.startActivity(
                                    Intent.createChooser(BackupHelper.intentPartage(json), "Exporter la sauvegarde")
                                )
                            } catch (e: Exception) {
                                android.widget.Toast.makeText(context, "Erreur export: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Sauvegarder / exporter les clients") }

                OutlinedButton(
                    onClick = { afficherHistorique = true },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Historique des actions") }
            }
        }

        HorizontalDivider()

                Text("À propos", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Vanelle Relance", fontWeight = FontWeight.Bold)
                Text("Version 1.3", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Toutes les données (montants, contacts, notes) sont stockées uniquement sur votre téléphone. " +
                    "Rien n'est jamais envoyé sur internet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        HorizontalDivider()

        Text("Application", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "La désinstallation supprime l'application et ses données locales (clients, montants, PIN).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(
                    onClick = { afficherDesinstall = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Désinstaller l'application")
                }
            }
        }
    }



    if (afficherHistorique) {
        val events = remember { HistoriqueHelper.lister(context) }
        AlertDialog(
            onDismissRequest = { afficherHistorique = false },
            title = { Text("Historique") },
            text = {
                if (events.isEmpty()) {
                    Text("Aucune action enregistrée pour le moment.")
                } else {
                    Column(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
                        events.take(50).forEach { e ->
                            Text(
                                "${HistoriqueHelper.formaterDate(e.timestamp)} — ${e.type} — ${e.clientNom}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (e.detail.isNotBlank()) {
                                Text(e.detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { afficherHistorique = false }) { Text("Fermer") }
            },
            dismissButton = {
                TextButton(onClick = {
                    HistoriqueHelper.effacer(context)
                    afficherHistorique = false
                }) { Text("Effacer") }
            }
        )
    }

    if (afficherDesinstall) {
        AlertDialog(
            onDismissRequest = { afficherDesinstall = false },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Désinstaller Vanelle Relance ?") },
            text = {
                Text(
                    "Cette action ouvre l'écran système de désinstallation. " +
                    "Toutes les données de l'application (clients, montants, messages, PIN) seront effacées définitivement."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        afficherDesinstall = false
                        try {
                            val intent = Intent(Intent.ACTION_DELETE).apply {
                                data = Uri.parse("package:${context.packageName}")
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            // Fallback : ouvrir les infos de l'app
                            val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.parse("package:${context.packageName}")
                            }
                            context.startActivity(intent)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Continuer") }
            },
            dismissButton = {
                TextButton(onClick = { afficherDesinstall = false }) { Text("Annuler") }
            }
        )
    }

    if (afficherConfigPin) {
        DialogueConfigurationPin(
            onDismiss = { afficherConfigPin = false },
            onValide = { nouveauPin ->
                val code = cryptoManager.configurerPin(nouveauPin)
                codeRecuperationAffiche = code
                afficherConfigPin = false
            }
        )
    }

    if (afficherMessages) {
        DialogueMessagesPersonnalises(
            prefsHelper = prefsHelper,
            onDismiss = { afficherMessages = false }
        )
    }

    if (afficherMessagesNego) {
        DialogueMessagesNegociation(
            prefsHelper = prefsHelper,
            onDismiss = { afficherMessagesNego = false }
        )
    }

    codeRecuperationAffiche?.let { code ->
        AlertDialog(
            onDismissRequest = { },
            icon = { Icon(Icons.Default.Key, contentDescription = null) },
            title = { Text("Notez bien ce code") },
            text = {
                Column {
                    Text("Votre code de récupération (à conserver en lieu sûr) :")
                    Spacer(Modifier.height(12.dp))
                    Text(
                        code,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Il permet de réinitialiser votre PIN si vous l'oubliez. Il ne sera plus jamais affiché.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                Button(onClick = { codeRecuperationAffiche = null }) {
                    Text("J'ai noté le code")
                }
            }
        )
    }
}

@Composable
private fun LignePermission(
    titre: String,
    icone: androidx.compose.ui.graphics.vector.ImageVector,
    accordee: Boolean,
    onDemander: () -> Unit
) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(icone, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(titre, fontWeight = FontWeight.Medium)
                    Text(
                        if (accordee) "Autorisé ✓" else "Non autorisé",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (accordee) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.error
                    )
                }
            }
            if (!accordee) {
                TextButton(onClick = onDemander) {
                    Text("Autoriser")
                }
            } else {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DialogueConfigurationPin(
    onDismiss: () -> Unit,
    onValide: (String) -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var confirmation by remember { mutableStateOf("") }
    var erreur by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Configurer le code PIN") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Choisissez un code PIN de 4 à 6 chiffres. Il protégera l'accès à vos données clients.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) pin = it },
                    label = { Text("Nouveau PIN") },
                    singleLine = true,
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                )
                OutlinedTextField(
                    value = confirmation,
                    onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) confirmation = it },
                    label = { Text("Confirmer le PIN") },
                    singleLine = true,
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                )
                erreur?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (pin.length !in 4..6 || pin.any { !it.isDigit() }) {
                    erreur = "Le PIN doit contenir 4 à 6 chiffres."
                } else if (pin != confirmation) {
                    erreur = "Les deux codes ne correspondent pas."
                } else {
                    onValide(pin)
                }
            }) { Text("Valider") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}

@Composable
fun DialogueMessagesPersonnalises(
    prefsHelper: PreferencesHelper,
    onDismiss: () -> Unit
) {
    var msg1 by remember { mutableStateOf(prefsHelper.messageRelance1) }
    var msg2 by remember { mutableStateOf(prefsHelper.messageRelance2) }
    var msg3 by remember { mutableStateOf(prefsHelper.messageRelance3) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Messages de relance", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .heightIn(max = 450.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Placeholders disponibles : {nom}  {montant}  {date}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = msg1,
                    onValueChange = { msg1 = it },
                    label = { Text("1ère relance (amicale)") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = msg2,
                    onValueChange = { msg2 = it },
                    label = { Text("2ème / 3ème relance") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = msg3,
                    onValueChange = { msg3 = it },
                    label = { Text("Relance importante (≥ 3)") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                prefsHelper.messageRelance1 = msg1.trim().ifBlank { PreferencesHelper.MSG_DEFAUT_1 }
                prefsHelper.messageRelance2 = msg2.trim().ifBlank { PreferencesHelper.MSG_DEFAUT_2 }
                prefsHelper.messageRelance3 = msg3.trim().ifBlank { PreferencesHelper.MSG_DEFAUT_3 }
                onDismiss()
            }) {
                Text("Enregistrer")
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = {
                    prefsHelper.resetMessages()
                    msg1 = PreferencesHelper.MSG_DEFAUT_1
                    msg2 = PreferencesHelper.MSG_DEFAUT_2
                    msg3 = PreferencesHelper.MSG_DEFAUT_3
                }) {
                    Text("Réinitialiser")
                }
                TextButton(onClick = onDismiss) {
                    Text("Annuler")
                }
            }
        }
    )
}

private fun estAccordee(context: android.content.Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED


@Composable
fun DialogueMessagesNegociation(
    prefsHelper: PreferencesHelper,
    onDismiss: () -> Unit
) {
    var msg1 by remember { mutableStateOf(prefsHelper.messageNegoDouce) }
    var msg2 by remember { mutableStateOf(prefsHelper.messageNegoPlan) }
    var msg3 by remember { mutableStateOf(prefsHelper.messageNegoOffre) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Messages de négociation", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .heightIn(max = 450.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Placeholders : {nom}  {montant}  {date}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                OutlinedTextField(
                    value = msg1,
                    onValueChange = { msg1 = it },
                    label = { Text("Discussion amiable") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = msg2,
                    onValueChange = { msg2 = it },
                    label = { Text("Plan / échéancier de paiement") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = msg3,
                    onValueChange = { msg3 = it },
                    label = { Text("Offre finale / arrangement") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                prefsHelper.messageNegoDouce = msg1.trim().ifBlank { PreferencesHelper.NEGO_DEFAUT_1 }
                prefsHelper.messageNegoPlan = msg2.trim().ifBlank { PreferencesHelper.NEGO_DEFAUT_2 }
                prefsHelper.messageNegoOffre = msg3.trim().ifBlank { PreferencesHelper.NEGO_DEFAUT_3 }
                onDismiss()
            }) { Text("Enregistrer") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = {
                    prefsHelper.resetMessagesNegociation()
                    msg1 = PreferencesHelper.NEGO_DEFAUT_1
                    msg2 = PreferencesHelper.NEGO_DEFAUT_2
                    msg3 = PreferencesHelper.NEGO_DEFAUT_3
                }) { Text("Réinitialiser") }
                TextButton(onClick = onDismiss) { Text("Annuler") }
            }
        }
    )
}
