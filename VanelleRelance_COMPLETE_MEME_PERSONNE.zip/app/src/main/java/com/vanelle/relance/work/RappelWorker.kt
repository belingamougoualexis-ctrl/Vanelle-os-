package com.vanelle.relance.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.vanelle.relance.data.AppDatabase
import com.vanelle.relance.data.StatutDette
import com.vanelle.relance.utils.NotificationHelper
import com.vanelle.relance.utils.AutomationHelper
import com.vanelle.relance.utils.MessageHelper
import com.vanelle.relance.utils.HistoriqueHelper
import kotlinx.coroutines.flow.first

class RappelWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val dao = AppDatabase.getInstance(applicationContext).clientDao()
            val maintenant = System.currentTimeMillis()
            val calendrier = java.util.Calendar.getInstance()
            val heureActuelle = calendrier.get(java.util.Calendar.HOUR_OF_DAY)
            val jourActuel = calendrier.get(java.util.Calendar.DAY_OF_YEAR)
            val clients = dao.getTous().first()

            val nouveauxNoms = mutableListOf<String>()

            clients.forEach { client ->
                if (client.statut != StatutDette.PAYEE &&
                    client.statut != StatutDette.EN_RETARD &&
                    client.dateEcheance < maintenant
                ) {
                    dao.mettreAJour(client.copy(statut = StatutDette.EN_RETARD))
                    nouveauxNoms.add(client.nom)
                }
            }

            // Liste à jour après mises à jour
            val apres = dao.getTous().first()
            val enRetard = apres.filter { it.statut == StatutDette.EN_RETARD }
            if (enRetard.isNotEmpty()) {
                // Priorité : nouveaux retards du jour, sinon rappel des existants
                val noms = if (nouveauxNoms.isNotEmpty()) nouveauxNoms else enRetard.map { it.nom }
                NotificationHelper.notifierClientsEnRetard(
                    applicationContext,
                    noms,
                    enRetard.size
                )
            }

            // Toutes les relances configurées sont automatiques.
            // Le canal, l'heure et le nombre max sont choisis lors de la création/modification du client.
            // SMS est envoyé directement par SmsManager ; WhatsApp et Gmail sont
            // automatisés via le Service d’Accessibilité activé volontairement.
            val serviceActif = AutomationHelper.serviceActive()
            apres.filter { it.statut != StatutDette.PAYEE }.forEach { client ->
                // WorkManager est volontairement inexact : si le worker passe quelques minutes
                // après l'heure choisie, la relance doit quand même partir aujourd'hui.
                if (heureActuelle < client.heureRelance) return@forEach

                // On ne relance qu'une seule fois par jour, même si le worker tourne plus souvent.
                val dernierContactCal = client.dernierContact?.let {
                    java.util.Calendar.getInstance().apply { timeInMillis = it }
                }
                val dejaContacteAujourdhui = dernierContactCal?.get(java.util.Calendar.DAY_OF_YEAR) == jourActuel &&
                    dernierContactCal?.get(java.util.Calendar.YEAR) == calendrier.get(java.util.Calendar.YEAR)
                if (dejaContacteAujourdhui) return@forEach

                // Si aucune relance n'a encore eu lieu, SMS/WhatsApp attendent l'échéance.
                // Un e-mail initial peut déjà avoir été envoyé lors de la création.
                if (client.nombreRelances == 0 &&
                    client.canalRelance != com.vanelle.relance.data.CanalRelance.GMAIL &&
                    client.dateEcheance >= maintenant
                ) return@forEach

                // Nombre de relances max atteint (0 = illimité).
                if (client.nombreRelancesMax > 0 && client.nombreRelances >= client.nombreRelancesMax) return@forEach

                val message = MessageHelper.genererMessageRelance(applicationContext, client, client.nombreRelances)
                var queued = false
                when (client.canalRelance) {
                    com.vanelle.relance.data.CanalRelance.SMS -> {
                        queued = com.vanelle.relance.utils.SmsHelper.envoyer(applicationContext, client, client.nombreRelances)
                        if (queued) HistoriqueHelper.enregistrer(applicationContext, "SMS AUTO", client.nom, "Relance SMS automatique")
                    }
                    com.vanelle.relance.data.CanalRelance.WHATSAPP -> {
                        if (serviceActif) {
                            queued = AutomationHelper.startWhatsApp(applicationContext, client, message)
                            if (queued) HistoriqueHelper.enregistrer(applicationContext, "WhatsApp AUTO", client.nom, "Envoi automatique via accessibilité")
                        }
                    }
                    com.vanelle.relance.data.CanalRelance.GMAIL -> {
                        if (serviceActif && client.email.isNotBlank()) {
                            queued = AutomationHelper.startEmail(applicationContext, client, client.objetEmail, message)
                            if (queued) HistoriqueHelper.enregistrer(applicationContext, "GMAIL AUTO", client.nom, "Envoi automatique via accessibilité")
                        }
                    }
                }
                if (queued) {
                    dao.mettreAJour(client.copy(
                        nombreRelances = client.nombreRelances + 1,
                        dernierContact = maintenant
                    ))
                }
            }

            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
