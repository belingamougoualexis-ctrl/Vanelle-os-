package com.vanelle.relance.automation

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.vanelle.relance.utils.PaymentDetectionHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class PaymentSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val pending = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
                val body = messages.joinToString(" ") { it.messageBody.orEmpty() }
                if (body.isNotBlank()) {
                    PaymentDetectionHelper.traiterTexte(
                        appContext,
                        body,
                        "SMS entrant"
                    )
                }
            } finally {
                pending.finish()
            }
        }
    }
}
