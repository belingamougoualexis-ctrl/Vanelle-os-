package com.vanelle.relance.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class CanalRelance {
    WHATSAPP,
    SMS,
    GMAIL
}

enum class StatutDette {
    EN_COURS,
    PAYEE,
    EN_RETARD
}

@Entity(tableName = "clients")
data class Client(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nom: String,
    val telephone: String,
    val email: String = "",
    val montant: Double,
    val dateEcheance: Long,          // timestamp epoch millis
    val statut: StatutDette = StatutDette.EN_COURS,
    val nombreRelances: Int = 0,
    val dernierContact: Long? = null,
    val note: String = "",
    val canalRelance: CanalRelance = CanalRelance.SMS,
    val objetEmail: String = "Relance de paiement",   // objet utilisé pour le canal Gmail
    val heureRelance: Int = 9,                        // heure (0-23) à laquelle envoyer la relance
    val nombreRelancesMax: Int = 0                    // 0 = illimité
)
