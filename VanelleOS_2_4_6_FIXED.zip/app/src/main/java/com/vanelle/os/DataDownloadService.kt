package com.vanelle.os
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

/**
 * Service de téléchargement des données de l'app.
 * - Modèle IA local (GGUF) dans le même flux
 * - Continue si l'utilisateur quitte l'app (foreground service)
 * - Pause si plus de réseau
 * - Reprend automatiquement au même offset (.part + HTTP Range) pour le GGUF
 */
class DataDownloadService : Service() {

    companion object {
        private const val TAG = "DataDownload"
        const val CHANNEL_ID = "vanelle_data_download"
        const val CHANNEL_DONE_ID = "vanelle_data_ready"
        const val NOTIF_ID = 4201
        const val NOTIF_DONE_ID = 4202
        const val ACTION_PROGRESS = "com.vanelle.os.DATA_DOWNLOAD_PROGRESS"
        const val ACTION_DONE = "com.vanelle.os.DATA_DOWNLOAD_DONE"
        const val ACTION_WAITING = "com.vanelle.os.DATA_DOWNLOAD_WAITING"
        const val EXTRA_PERCENT = "percent"
        const val EXTRA_STATUS = "status"

        @Volatile var isRunning = false
            private set

        fun allDataReady(c: Context): Boolean =
            !LlamaModelManager.isLocalAiSupported() || LlamaModelManager.isReady(c)

        /** Vrai seulement si le modèle est à la fois téléchargé ET chargé en mémoire (utilisable). */
        fun isUsable(c: Context): Boolean =
            !LlamaModelManager.isLocalAiSupported() ||
                (LlamaModelManager.isReady(c) &&
                    try { LocalLlamaHelper.get(c).isLoaded() } catch (_: Exception) { false })

        fun start(c: Context) {
            if (isUsable(c)) return
            val i = Intent(c, DataDownloadService::class.java)
            ContextCompat.startForegroundService(c, i)
        }

        /** Programme une reprise automatique dans [delayMs] si l'IA n'est pas encore utilisable. */
        fun scheduleAutoRetry(c: Context, delayMs: Long = 60_000L) {
            if (isUsable(c)) return
            try {
                val am = c.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                val intent = Intent(c, DataDownloadService::class.java)
                val flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (android.os.Build.VERSION.SDK_INT >= 23) android.app.PendingIntent.FLAG_IMMUTABLE else 0)
                val pi = android.app.PendingIntent.getService(c, 42099, intent, flags)
                val at = System.currentTimeMillis() + delayMs.coerceIn(15_000L, 15 * 60_000L)
                if (android.os.Build.VERSION.SDK_INT >= 23) {
                    am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, at, pi)
                } else {
                    @Suppress("DEPRECATION")
                    am.set(android.app.AlarmManager.RTC_WAKEUP, at, pi)
                }
            } catch (_: Exception) {}
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var cancelled = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Fichier déjà téléchargé : charger en mémoire si besoin, puis notification
        if (allDataReady(this)) {
            isRunning = true
            startAsForeground(100, "Chargement de l'IA en mémoire…")
            if (job?.isActive != true) {
                job = scope.launch {
                    val alreadyLoaded = try {
                        LocalLlamaHelper.get(applicationContext).isLoaded()
                    } catch (_: Exception) { false }
                    if (alreadyLoaded) {
                        notifyDownloadComplete(loaded = true)
                        activateMascotIfReady()
                        delay(400)
                        stopSelfSafely()
                    } else {
                        finishWithMemoryLoad()
                    }
                }
            }
            return START_NOT_STICKY
        }
        startAsForeground(overallPercent(), "Préparation des données…")
        isRunning = true
        cancelled = false
        registerNetworkWatcher()
        if (job?.isActive != true) {
            job = scope.launch { runDownloadLoop() }
        }
        return START_STICKY
    }

    private suspend fun runDownloadLoop() {
        // Vérif stockage dès le début — message factuel uniquement
        LlamaModelManager.storageWarning(this)?.let { msg ->
            updateNotif(0, "Stockage insuffisant")
            broadcastWaiting(msg)
            notifyDownloadComplete(loaded = false, cause = msg)
            stopSelfSafely()
            return
        }

        // Compteur de cycles sans Wi‑Fi : après ~30 s on autorise les données mobiles
        // pour ne pas bloquer indéfiniment l'utilisateur.
        var noWifiCycles = 0
        var consecutiveErrors = 0

        while (!cancelled && !allDataReady(this)) {
            if (!LlamaModelManager.isNetworkAvailable(this)) {
                broadcastWaiting("Pas de connexion Internet — reprise automatique dès que le réseau revient.")
                updateNotif(overallPercent(), "En attente du réseau…")
                delay(3000)
                continue
            }

            if (LlamaModelManager.isReady(this)) {
                finishWithMemoryLoad()
                return
            }

            val onWifi = LlamaModelManager.isOnWifi(this)
            // Wi‑Fi préféré, mais pas obligatoire après quelques cycles d'attente
            val allowMobile = noWifiCycles >= 5 // ~20–25 s d'attente Wi‑Fi
            if (!onWifi && !allowMobile) {
                noWifiCycles++
                val left = (5 - noWifiCycles).coerceAtLeast(0)
                broadcastWaiting(
                    if (left > 0)
                        "Wi‑Fi recommandé pour l'IA (~2 Go). Encore $left essais, puis téléchargement sur données mobiles autorisé."
                    else
                        "Téléchargement autorisé sur données mobiles (Wi‑Fi non détecté)."
                )
                updateNotif(overallPercent(), "Wi‑Fi recommandé…")
                delay(4000)
                continue
            }
            if (onWifi) noWifiCycles = 0

            val wifiOnly = onWifi // si on est déjà sur Wi‑Fi, rester strict ; sinon autoriser mobile
            val result = LlamaModelManager.downloadResumable(
                this,
                wifiOnly = wifiOnly && !allowMobile,
                isCancelled = { cancelled }
            ) { pct, downloaded, total ->
                val mapped = pct.coerceIn(0, 100)
                val status = if (total > 0) {
                    val mb = downloaded / (1024 * 1024)
                    val totalMb = total / (1024 * 1024)
                    "$mapped % · ${mb} / ${totalMb} Mo"
                } else "$mapped %"
                updateNotif(mapped, status)
                broadcastProgress(mapped, status)
            }

            when {
                result == "DONE" -> {
                    consecutiveErrors = 0
                    finishWithMemoryLoad()
                    return
                }
                result == "CANCELLED" -> {
                    stopSelfSafely()
                    return
                }
                result == "NO_WIFI" -> {
                    noWifiCycles++
                    broadcastWaiting("Wi‑Fi perdu — reprise au même point dès que possible.")
                    updateNotif(overallPercent(), "Wi‑Fi interrompu — reprise auto")
                    delay(2500)
                }
                result == "NO_NETWORK" -> {
                    broadcastWaiting("Connexion interrompue — reprise au même point (aucune perte).")
                    updateNotif(overallPercent(), "Réseau interrompu — reprise auto")
                    delay(2500)
                }
                result.startsWith("ERROR:STORAGE:") -> {
                    val msg = result.removePrefix("ERROR:STORAGE:")
                    updateNotif(overallPercent(), "Stockage insuffisant")
                    broadcastWaiting(msg)
                    notifyDownloadComplete(loaded = false, cause = msg)
                    delay(800)
                    stopSelfSafely()
                    return
                }
                result == "UNSUPPORTED_ABI" -> {
                    val msg = "Cet appareil n'est pas compatible avec l'IA locale (processeur 32 bits). Les fonctions sans IA restent disponibles."
                    updateNotif(0, "Appareil non compatible")
                    broadcastWaiting(msg)
                    notifyDownloadComplete(loaded = false, cause = msg)
                    stopSelfSafely()
                    return
                }
                else -> {
                    consecutiveErrors++
                    val human = when {
                        result.startsWith("ERROR:CHECKSUM") ->
                            "Fichier modèle corrompu — nouveau téléchargement."
                        result.startsWith("ERROR:incomplet") ->
                            "Téléchargement incomplet — reprise au même point."
                        result.startsWith("ERROR:timeout") ->
                            "Connexion trop lente (timeout) — nouvel essai."
                        result.startsWith("ERROR:dns") ->
                            "Serveur inaccessible — vérifie ta connexion."
                        result.startsWith("ERROR:HTTP") ->
                            "Erreur serveur ($result) — nouvel essai."
                        result.startsWith("ERROR:io") ->
                            "Interruption réseau ou écriture — reprise auto."
                        else ->
                            "Interruption temporaire — nouvel essai (${result.take(80)})."
                    }
                    updateNotif(overallPercent(), human.take(60))
                    broadcastWaiting(human)
                    // Backoff progressif, max ~30 s
                    val wait = (3000L * consecutiveErrors.coerceAtMost(10)).coerceAtMost(30_000L)
                    delay(if (result.startsWith("ERROR:CHECKSUM")) 2000 else wait)
                }
            }
        }
        if (allDataReady(this)) {
            finishWithMemoryLoad()
            return
        }
        // Sortie de boucle sans être prêt → reprise auto (réseau, Wi‑Fi, etc.)
        if (!cancelled && !isUsable(this)) {
            scheduleAutoRetry(applicationContext, 45_000L)
        }
        stopSelfSafely()
    }

    /**
     * Après téléchargement réussi : charge le modèle en mémoire (réessais auto),
     * puis seulement envoie la notification « IA prête ».
     */
    private suspend fun finishWithMemoryLoad() {
        // Courte pause pour laisser le système finir les écritures disque avant le mmap.
        updateNotif(100, "Finalisation du modèle…")
        broadcastProgress(100, "Finalisation du modèle…")
        delay(2_500)

        // Avertir si RAM faible (on tente quand même le chargement)
        LlamaModelManager.memoryWarning(applicationContext)?.let { msg ->
            updateNotif(100, "RAM limitée — tentative…")
            broadcastWaiting(msg)
            delay(2500)
        }

        // Le moteur Llama est toujours tenté; paramètres adaptés dans LocalLlamaHelper.
        updateNotif(100, "Chargement de l'IA en mémoire…")
        broadcastProgress(100, "Chargement de l'IA en mémoire…")
        var ok = false
        // Llama est toujours prioritaire; warmUp() effectue plusieurs tentatives mémoire.
        try {
            val helper = LocalLlamaHelper.get(applicationContext)
            helper.resetLoadFailure()
            ok = helper.warmUp()
            if (!ok) {
                val err = helper.lastError()
                if (!err.isNullOrBlank()) {
                    updateNotif(100, "IA non chargée")
                    broadcastProgress(100, err)
                    Log.w(TAG, "warmUp fail: $err")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "warmUp: ${e.message}")
            ok = false
        }
        if (!ok) {
            ok = try {
                LocalLlamaHelper.get(applicationContext).isLoaded()
            } catch (_: Exception) { false }
        }
        updateNotif(100, if (ok) "IA prête" else "Chargement — nouvel essai auto…")
        broadcastDone()
        notifyDownloadComplete(loaded = ok)
        if (ok) {
            activateMascotIfReady()
            delay(600)
            stopSelfSafely()
        } else {
            // Échec de chargement mémoire : reprogrammer automatiquement sans action utilisateur
            broadcastWaiting("Chargement mémoire en attente — nouvel essai automatique dans une minute.")
            scheduleAutoRetry(applicationContext, 60_000L)
            delay(800)
            stopSelfSafely()
        }
    }

    /** Progression globale du téléchargement du modèle IA local. */
    private fun overallPercent(): Int {
        if (allDataReady(this)) return 100
        val p = LlamaModelManager.partialBytes(this)
        if (p <= 0) return 0
        return ((p * 100) / LlamaModelManager.EXPECTED_MIN_BYTES).toInt().coerceIn(0, 99)
    }

    private fun registerNetworkWatcher() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            networkCallback?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (job?.isActive != true && !allDataReady(this@DataDownloadService)) {
                        job = scope.launch { runDownloadLoop() }
                    }
                }
                override fun onLost(network: Network) {
                    broadcastWaiting("Connexion interrompue — reprise auto")
                }
            }
            networkCallback = cb
            val req = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            cm.registerNetworkCallback(req, cb)
        } catch (_: Exception) {}
    }

    private fun broadcastProgress(pct: Int, status: String) {
        sendBroadcast(Intent(ACTION_PROGRESS).setPackage(packageName).apply {
            putExtra(EXTRA_PERCENT, pct)
            putExtra(EXTRA_STATUS, status)
        })
    }

    private fun broadcastWaiting(msg: String) {
        sendBroadcast(Intent(ACTION_WAITING).setPackage(packageName).apply {
            putExtra(EXTRA_STATUS, msg)
            putExtra(EXTRA_PERCENT, overallPercent())
        })
    }

    private fun broadcastDone() {
        sendBroadcast(Intent(ACTION_DONE).setPackage(packageName))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                CHANNEL_ID,
                "Mise à jour des données",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Téléchargement des données de VanelleOS"
                setShowBadge(false)
            }
            nm.createNotificationChannel(ch)
            // Canal haute priorité pour la notification de fin
            val done = NotificationChannel(
                CHANNEL_DONE_ID,
                "IA prête",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notification quand le modèle IA est téléchargé"
                setShowBadge(true)
            }
            nm.createNotificationChannel(done)
        }
    }

    private fun startAsForeground(pct: Int, text: String) {
        val notif = buildNotif(pct, text)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun updateNotif(pct: Int, text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotif(pct, text))
    }

    private fun buildNotif(pct: Int, text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VanelleOS · données")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct.coerceIn(0, 100), pct <= 0)
            .setContentIntent(open)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .build()
    }

    /** Notification finale uniquement lorsque l’IA est prête. */
    private fun notifyDownloadComplete(loaded: Boolean, cause: String? = null) {
        if (!loaded) {
            if (cause != null) {
                AiLoadDiagnostics.logFailure(applicationContext, cause)
            }
            return
        }
        try {
            createChannel()
            val open = PendingIntent.getActivity(
                this, 1,
                Intent(this, MainActivity::class.java).addFlags(
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                ),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val text = "L’IA est prête. Vanelle peut maintenant t’assister, même hors-ligne."
            val notif = NotificationCompat.Builder(this, CHANNEL_DONE_ID)
                .setContentTitle("VanelleOS · IA prête")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setAutoCancel(true)
                .setOngoing(false)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(open)
                .setCategory(NotificationCompat.CATEGORY_STATUS)
                .build()
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_DONE_ID, notif)
        } catch (e: Exception) {
            Log.w(TAG, "notification ready: ${e.message}")
        }
    }

    /** Active la mascotte flottante uniquement après téléchargement + chargement mémoire réussis. */
    private fun activateMascotIfReady() {
        if (!isUsable(applicationContext)) return
        if (!OverlayHelper.canDraw(applicationContext)) return
        try {
            FloatingMascotButton.setEnabled(applicationContext, true)
            FloatingMascotButton.show(applicationContext)
        } catch (e: Exception) {
            Log.w(TAG, "Impossible d'afficher la mascotte: ${e.message}")
        }
    }

    private fun stopSelfSafely() {
        isRunning = false
        cancelled = true
        try {
            networkCallback?.let {
                val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                cm.unregisterNetworkCallback(it)
            }
        } catch (_: Exception) {}
        networkCallback = null
        job?.cancel()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        cancelled = true
        isRunning = false
        scope.cancel()
        super.onDestroy()
    }
}
