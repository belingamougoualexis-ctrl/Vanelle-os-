package com.vanelle.os
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CommandInterpreter(private val context: Context) {
    companion object {
        // Actions purement locales/appareil : pas besoin de journaliser l'épisode ni
        // de passer par la détection d'humeur avant de les exécuter (chemin rapide).
        private val FAST_INTENTS = setOf(
            CommandIntent.FLASHLIGHT,
            CommandIntent.VOLUME,
            CommandIntent.RINGER,
            CommandIntent.CLIPBOARD_READ,
            CommandIntent.CLIPBOARD_WRITE,
            CommandIntent.OPEN_URL,
            CommandIntent.SHARE_TEXT,
            CommandIntent.TIMER,
            CommandIntent.BATTERY,
            CommandIntent.OPEN_APP,
            CommandIntent.CALL_CONTACT,
            CommandIntent.SEND_MESSAGE,
            CommandIntent.YOUTUBE,
            CommandIntent.SEARCH_WEB,
            CommandIntent.MAPS,
            CommandIntent.TRANSLATE,
            CommandIntent.SHOW_MASCOT,
            CommandIntent.OPEN_CAMERA,
            CommandIntent.OPEN_GALLERY,
            CommandIntent.EMERGENCY,
            CommandIntent.LOST_PHONE,
            CommandIntent.ACCESSIBILITY_ACTION,
            CommandIntent.READ_SCREEN,
            CommandIntent.MEMORY_GET,
            CommandIntent.MEMORY_SAVE,
            CommandIntent.REMEMBER_FACT,
            CommandIntent.QUICK_NOTE,
            CommandIntent.QUICK_NOTE_LIST,
            CommandIntent.QUICK_NOTE_CLEAR
        )
        private val SIMPLE_GREETING = Regex(
            "(?i)^(bonjour|bonsoir|salut|coucou|hello|hey|yo|cc)\\s*[!.,\\s]*$"
        )
        private fun isIdentityQuestion(t: String): Boolean {
            val low = t.lowercase().trim()
            if (low.length >= 100) return false
            return low.contains("qui es-tu") || low.contains("qui es tu") || low.contains("t'es qui") ||
                low.contains("tes qui") || low.contains("c'est qui") || low.contains("quel modele") ||
                low.contains("quel modèle") || low.contains("tu es qwen") || low.contains("tu es chatgpt") ||
                low.contains("tu es claude") || low.contains("c'est quoi vanelle") ||
                low.contains("who are you") || low.contains("what model") || low == "qui es-tu?"
        }
    }
    private val apps = AppsRepository(context)
    private val contacts = ContactsRepository(context)
    private val web = WebSearchHelper(context)
    private val yt = YouTubeHelper(context)
    private val tr = TranslateHelper(context)
    private val bat = BatteryHelper(context)
    private val em = EmergencyManager(context)
    private val vault = MemoryVault(context)
    private val maps = MapsHelper(context)
    private val tool = MiniToolGenerator(context)
    private val learner = WorkflowLearner(context)
    private val freeAI = FreeAIHelper(context)
    private val localAI = LocalLlamaHelper.get(context)
    private val relance = RelanceRepository(context)
    private val streaming = StreamingHelper(context)
    private val relational = RelationalMemory(context)
    private val agent = AutonomousAgent(context)
    private val episodic = EpisodicMemory(context)
    private val spatial = SpatialContext(context)
    private val dynamicUi = DynamicUiGenerator(context)
    private val emotion = EmotionEngine(context)
    private val device = DeviceActions(context)

    suspend fun execute(t: String, allowAgents: Boolean = true): String {
        return try {
            val result = executeInner(t, allowAgents)
            ensureSpoken(result)
        } catch (e: Exception) {
            // Classer l'erreur de façon factuelle — jamais une excuse au hasard.
            val msg = (e.message ?: "").lowercase()
            val isNet = e is java.net.UnknownHostException ||
                e is java.net.SocketException ||
                e is java.net.SocketTimeoutException ||
                msg.contains("unknownhost") || msg.contains("sockettimeout") ||
                (msg.contains("failed to connect") || msg.contains("unable to resolve"))
            val isOom = e is OutOfMemoryError || msg.contains("out of memory") || msg.contains("oom")
            ensureSpoken(
                when {
                    isOom ->
                        "Mémoire insuffisante pour cette demande. Ferme d'autres applications, puis réessaie."
                    isNet ->
                        "Problème réseau temporaire sur cette action. Vérifie ta connexion, puis réessaie."
                    !LlamaModelManager.isReady(context) || !LocalLlamaHelper.get(context).isLoaded() ->
                        aiUnavailableReason()
                    else ->
                        "Je n'ai pas pu terminer cette demande (${e.javaClass.simpleName}). Réessaie ou reformule."
                }
            )
        }
    }

    /** Garantit une phrase parlable : raison + quoi faire. Jamais vide. */
    private fun ensureSpoken(msg: String?): String {
        var m = msg?.trim().orEmpty()
        if (m.isBlank()) {
            return "Je n'ai pas pu repondre correctement. Reformule ou reessaie."
        }
        // Nettoyage legers symboles si reponse hors LlamaHelper
        m = m.replace(Regex("""[$#*%_=]{2,}"""), " ")
            .replace(Regex("""<\|[^|>]+\|>"""), " ")
            .replace(Regex("""[ \t]{2,}"""), " ")
            .trim()
        return m
    }

    private fun aiUnavailableReason(): String {
        if (!LlamaModelManager.isLocalAiSupported()) {
            return "Cette demande nécessite l'IA locale, mais ton téléphone (processeur 32 bits) n'est pas compatible. Les fonctions sans IA restent disponibles."
        }
        if (!LlamaModelManager.isReady(context)) {
            val partial = LlamaModelManager.partialBytes(context)
            val pct = if (partial > 0) {
                ((partial * 100) / LlamaModelManager.EXPECTED_MIN_BYTES).toInt().coerceIn(1, 99)
            } else 0
            val storage = LlamaModelManager.storageWarning(context)
            return when {
                storage != null ->
                    "Je ne peux pas encore répondre librement : $storage"
                pct in 1..99 ->
                    "Le téléchargement de l'IA est en cours ($pct %). Les commandes de base marchent déjà ; le chat libre sera dispo à 100 %."
                DataDownloadService.isRunning ->
                    "Le téléchargement de l'IA vient de démarrer. Les commandes de base marchent déjà ; réessaie le chat libre dans quelques minutes."
                else ->
                    "L'IA n'est pas encore téléchargée. Ouvre l'onglet Configuration ou relance l'app pour reprendre le téléchargement. Les commandes de base restent disponibles."
            }
        }
        val local = LocalLlamaHelper.get(context)
        if (local.isLoading()) {
            return "L'IA est téléchargée et se charge en mémoire. Attends quelques secondes, puis réessaie."
        }
        val reason = local.lastError()
        val mem = LlamaModelManager.memoryWarning(context)
        return when {
            !reason.isNullOrBlank() ->
                "L'IA n'a pas pu se charger en mémoire. Cause : ${reason.take(160)}. " +
                    "Ferme les autres apps, puis rouvre Vanelle pour réessayer. Les commandes de base restent disponibles."
            mem != null ->
                "L'IA n'a pas pu se charger : $mem Les commandes de base restent disponibles."
            else ->
                "L'IA n'est pas encore chargée en mémoire. Relance le chargement depuis Configuration, ou rouvre l'app."
        }
    }

    private suspend fun executeInner(t: String, allowAgents: Boolean = true): String {
        if (t.isBlank()) return "Je n'ai rien entendu. Appuie à nouveau sur la mascotte et parle clairement."

        // Mode traduction actif : chaque phrase est traduite (sauf commande d'arrêt)
        if (TranslateModePrefs.isActive(context)) {
            val low = t.lowercase().trim()
            if (low.contains("arrête") && (low.contains("traduction") || low.contains("mode")) ||
                low == "stop traduction" || low == "désactive traduction" || low == "desactive traduction"
            ) {
                TranslateModePrefs.stop(context)
                return "Mode traduction désactivé."
            }
            return withContext(Dispatchers.IO) {
                tr.translateText(
                    t,
                    TranslateModePrefs.source(context),
                    TranslateModePrefs.target(context)
                )
            }
        }

        // 0) Filet de sécurité salutations : jamais de recherche web/Wikipédia pour un simple
        // « bonjour », même si l'IA locale n'est pas encore prête. Réponse immédiate, sans réseau,
        // avant même de vérifier l'état de l'IA.
        // Identite Vanelle — reponse instantanee, jamais de nom de modele sous-jacent
        if (isIdentityQuestion(t)) {
            val reply = "Je suis Vanelle, ton assistante personnelle."
            ActivityLog.add(context, "action", reply)
            return reply
        }

        if (SIMPLE_GREETING.matches(t.trim())) {
            val prenom = try { relational.displayName() } catch (_: Exception) { "" }
            val reply = if (prenom.isNotBlank()) "Bonjour $prenom, comment puis-je t'aider ?" else "Bonjour, comment puis-je t'aider ?"
            ActivityLog.add(context, "action", reply.take(120))
            return reply
        }

        // 1) Actions appareil / systeme : TOUJOURS disponibles, meme si l'IA telecharge encore
        val quick = CommandParser.parse(t)
        val route = SystemCommandRouter.classify(t)
        val isFastAction = quick.intent in FAST_INTENTS || route == SystemCommandRouter.Route.SYSTEM
        if (isFastAction && quick.intent != CommandIntent.UNKNOWN) {
            val res = executeSingle(t, allowAgents)
            ActivityLog.add(context, "action", res.take(120))
            return res
        }
        // Calculs triviaux sans modele
        ReasoningHelper.tryDeterministicMath(t)?.let {
            ActivityLog.add(context, "action", it.take(120))
            return it
        }
        QuickFacts.answer(t)?.let {
            ActivityLog.add(context, "action", it.take(120))
            return it
        }

        // 2) Conversation libre : nécessite le modèle local réellement téléchargé et chargé.
        // Aucun faux cerveau et aucune réponse simulée : la mascotte explique exactement ce qui manque.
        if (!DataDownloadService.isUsable(context)) {
            return aiUnavailableReason()
        }

        ActivityLog.add(context, "entendu", t.take(80))
        // Emotion / épisodes en arrière-plan uniquement pour les requêtes libres (évite la latence)

        // 2) Cerveau au centre : Llama seulement si fichier prêt ET déjà chargé en mémoire
        // (évite d'attendre 60–90 s de tentative de load à chaque requête si le load a échoué)
        if (LlamaModelManager.isReady(context) && localAI.isLoaded()) {
            val brain = try {
                brainFirst(t, allowAgents)
            } catch (_: Exception) {
                null
            }
            if (brain != null) {
                withContext(Dispatchers.IO) { learner.log(t) }
                ActivityLog.add(context, "action", brain.take(120))
                return brain
            }
        }

        // 3) Fallback : chaînes d'intentions connues via parser, puis executeSingle
        val parts = splitChain(t)
        if (parts.size >= 2) {
            val parsedParts = parts.map { CommandParser.parse(it) }
            if (parsedParts.all { it.intent != CommandIntent.UNKNOWN }) {
                val results = parts.map { executeSingle(it, allowAgents) }
                withContext(Dispatchers.IO) { learner.log(t) }
                val joined = results.joinToString(". ")
                ActivityLog.add(context, "action", joined.take(120))
                return joined
            }
        }
        val res = executeSingle(t, allowAgents)
        withContext(Dispatchers.IO) { learner.log(t) }
        ActivityLog.add(context, "action", res.take(120))
        return res
    }

    /**
     * Llama au centre : comprend l'intention, répond, et peut déclencher des outils
     * via une ligne ACTION:TYPE|args en tête de réponse.
     */
    
    private suspend fun brainFirst(t: String, allowAgents: Boolean): String? {
        // Calcul trivial / faits de base → code, pas le modèle
        ReasoningHelper.tryDeterministicMath(t)?.let { return it }
        QuickFacts.answer(t)?.let { return it }

        // Cache réponses fréquentes
        ResponseCache.get(context, t)?.let { cached ->
            relational.addTurn("user", t)
            relational.addTurn("assistant", cached)
            return cached
        }

        // Faits hors domaine → web/RAG d’abord (pas de cloud LLM)
        // Toute question de connaissance : web d'abord (le 1B n'est pas une encyclopédie)
        val looksKnowledge = ReasoningHelper.isFactualLookup(t) ||
            (t.contains('?') && t.length in 12..140 &&
                !t.lowercase().let { it.startsWith("ouvre") || it.startsWith("appelle") ||
                    it.startsWith("envoie") || it.startsWith("lance") || it.startsWith("mets ") })
        if (looksKnowledge && PrivacyFirewall.allowWeb(context) &&
            LlamaModelManager.isNetworkAvailable(context)
        ) {
            val webFirst = try { synthesizeAnswer(t) } catch (_: Exception) { null }
            if (!webFirst.isNullOrBlank() && !isGenericIntro(webFirst)) {
                ResponseCache.put(context, t, webFirst)
                relational.addTurn("user", t)
                relational.addTurn("assistant", webFirst)
                return webFirst
            }
        }

        val extra = relational.fullContextForAi(dialogTurns = MemoryEngine.SHORT_TURNS, maxChars = 900)
        val needsContext = needsConversationalContext(t)
        val complex = ReasoningHelper.isComplex(t)
        try { relational.learnFromUserUtterance(t) } catch (_: Exception) {}
        try {
            val lastAsst = relational.recentDialog(2).lines().lastOrNull { it.startsWith("Vanelle:") }
                ?.removePrefix("Vanelle:")?.trim()
            FeedbackMemory.maybeCapture(context, t, lastAsst)
        } catch (_: Exception) {}

        val userPrompt = buildString {
            if (complex) {
                append(ReasoningHelper.buildStructuredPrompt(t, hasExternalFacts = false))
            } else {
                append(ReasoningHelper.buildSimplePrompt(t))
            }
            if (needsContext) {
                append(" Relie aux sujets précédents ; résous pronoms et suites.")
            }
            append(" Si action téléphone vraiment utile → commence par ACTION:…")
        }
        // Le chat conversationnel privilégie désormais la qualité/contexte.
        // Le mode rapide reste réservé aux commandes très courtes sans contexte.
        val conversationalFast = !needsContext && !complex && t.length < 60
        val profile = AIConfiguration.profile(context)
        var raw = localAI.answer(
            userPrompt,
            extraContext = if (complex) extra else extra.take(if (needsContext) profile.contextChars else 900),
            fastMode = conversationalFast,
            maxTokensHint = if (complex) profile.maxOutputTokens else profile.maxOutputTokens.coerceAtMost(if (needsContext) 384 else 256)
        )
        if (raw != LocalLlamaHelper.NOT_READY && raw.isNotBlank() && isGenericIntro(raw)) {
            raw = localAI.answer(
                ReasoningHelper.buildSimplePrompt(t),
                extraContext = extra.take(500),
                fastMode = true,
                maxTokensHint = 150
            )
        }
        // Pas de 2e passe « anti-bluff » (trop lent) sauf texte très suspect et court
        if (raw != LocalLlamaHelper.NOT_READY && !raw.isNullOrBlank() &&
            !isGenericIntro(raw) && ReasoningHelper.looksOverconfidentBluff(raw) && raw.length > 200
        ) {
            // Une seule passe déjà faite — on élague juste le ton en post-traitement
            raw = raw.replace(Regex("(?i)il est évident que|sans aucun doute|absolument certain"), "il semble que")
        }

        if (raw == LocalLlamaHelper.NOT_READY || raw.isNullOrBlank()) return null
        if (isGenericIntro(raw)) return null

        relational.addTurn("user", t)
        val (actionLine, spoken) = splitActionAndReply(raw)
        if (actionLine != null) {
            val toolResult = runToolLine(actionLine, allowAgents)
            val reply = when {
                spoken.isNotBlank() && toolResult.isNotBlank() -> "$spoken $toolResult".trim()
                spoken.isNotBlank() -> spoken
                else -> toolResult.ifBlank { "C'est fait." }
            }
            relational.addTurn("assistant", reply)
            return reply
        }
        val text = ReasoningHelper.extractSpokenAnswer(spoken.ifBlank { raw.trim() })
        if (isGenericIntro(text)) return null
        relational.addTurn("assistant", text)
        ResponseCache.put(context, t, text)
        return text
    }

/** Messages qui s'appuient sur le fil (pronoms, suites de sujet, comparaisons). */
    private fun needsConversationalContext(t: String): Boolean {
        val lower = t.lowercase().trim()
        if (relational.recentDialog(4).isBlank()) return false
        if (Regex("(?i)^\\s*(et |mais |donc |alors |sinon )").containsMatchIn(lower)) return true
        if (Regex("(?i)\\b(il|elle|ils|elles|on)\\b").containsMatchIn(lower) && lower.length < 90) return true
        val cues = listOf(
            "ça", "cela", "celui", "celle", "ceux", "celles",
            "lui", "elle", "eux", "leur",
            "pareil", "pareille", "le même", "la même",
            "et pour", "et avec", "et si", "par contre",
            "aussi", "également", "comme tout à l'heure", "comme avant",
            "tu as dit", "tu m'as", "on parlait", "par rapport",
            "celui-là", "celle-là", "ce truc", "pourquoi", "comment ça",
            "et ensuite", "et après"
        )
        return cues.any { lower.contains(it) }
    }

    /** Détecte les réponses purement présentationnelles sans contenu utile. */
    private fun isGenericIntro(text: String): Boolean {
        val t = text.trim()
        if (t.length > 400) return false
        val lower = t.lowercase()
        val markers = listOf(
            "je suis vanelle",
            "votre assistante personnelle",
            "assistante personnelle, chaleureuse",
            "chaleureuse et précise",
            "qu'est-ce que vous souhaitez accomplir",
            "que souhaitez-vous accomplir",
            "conseils personnalisés",
            "trouver des solutions et à résoudre",
            "comment puis-je vous aider aujourd"
        )
        val hits = markers.count { lower.contains(it) }
        // La phrase exacte observée en prod touche ≥3 marqueurs
        return hits >= 2 || (hits >= 1 && t.length < 260)
    }

    private fun splitActionAndReply(raw: String): Pair<String?, String> {
        val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return null to ""
        val first = lines.first()
        val actionRegex = Regex("(?i)^ACTION\\s*:\\s*([A-Z_]+)\\s*(?:\\|\\s*(.*))?$")
        val m = actionRegex.find(first)
        return if (m != null) {
            val type = m.groupValues[1].uppercase()
            val args = m.groupValues.getOrNull(2)?.trim().orEmpty()
            val line = if (args.isNotEmpty()) "$type|$args" else type
            val rest = lines.drop(1).joinToString(" ").trim()
            line to rest
        } else {
            null to raw.trim()
                .removePrefix("assistant")
                .trim()
        }
    }

    private suspend fun runToolLine(line: String, allowAgents: Boolean): String {
        val parts = line.split("|", limit = 3).map { it.trim() }
        val type = parts.getOrNull(0)?.uppercase().orEmpty()
        val a1 = parts.getOrNull(1).orEmpty()
        val a2 = parts.getOrNull(2).orEmpty()
        return when (type) {
            "YOUTUBE" -> yt.searchSmart(QueryCleaner.subject(a1).ifBlank { a1 })
            "OPEN_APP" -> withContext(Dispatchers.IO) { apps.launch(a1) }
            "CALL" -> contacts.call(a1)
            "MESSAGE" -> contacts.sendMessage(a1, a2.ifBlank { "" })
            "SEARCH" -> answerSearchIntent(QueryCleaner.subject(a1).ifBlank { a1.ifBlank { line } })
            "MAPS" -> maps.open(QueryCleaner.subject(a1).ifBlank { a1 })
            "TIMER" -> {
                val m = a1.toIntOrNull() ?: 5
                device.timerMinutes(m)
            }
            "FLASHLIGHT" -> {
                val on = when (a1.lowercase()) {
                    "on", "1", "allume", "allumer" -> true
                    "off", "0", "eteins", "éteins" -> false
                    else -> null
                }
                device.flashlight(on)
            }
            "VOLUME" -> device.volume(
                when (a1.lowercase()) {
                    "up", "plus", "augmenter" -> "up"
                    "down", "moins", "baisser" -> "down"
                    else -> "status"
                }
            )
            "TRANSLATE" -> withContext(Dispatchers.IO) {
                tr.translateText(a1.ifBlank { a2 }, "auto", "fr")
            }
            "AGENT" -> {
                if (!allowAgents) "Action agent refusée."
                else agent.run(a1.ifBlank { "aide" })
            }
            else -> {
                // Dernier recours : parser classique sur la ligne
                val fallback = CommandParser.parse(
                    when (type) {
                        "YOUTUBE" -> "youtube $a1"
                        else -> a1.ifBlank { line }
                    }
                )
                if (fallback.intent != CommandIntent.UNKNOWN) {
                    executeSingle(
                        when (fallback.intent) {
                            CommandIntent.YOUTUBE -> "youtube ${fallback.args["query"] ?: a1}"
                            CommandIntent.OPEN_APP -> "ouvre ${fallback.args["app"] ?: a1}"
                            else -> a1
                        },
                        allowAgents
                    )
                } else "Je n'ai pas compris l'action demandée. Reformule clairement, par exemple « ouvre YouTube » ou « appelle Paul »."
            }
        }
    }

    private fun splitChain(text: String): List<String> =
        text.split(Regex("(?i)\\s+et\\s+puis\\s+|\\s+puis\\s+|\\s+et\\s+"))
            .map { it.trim() }.filter { it.isNotBlank() }

    private suspend fun executeSingle(t: String, allowAgents: Boolean = true): String {
        val clean = t.trim().lowercase()
        if (MascotManager.isMascotNameSpoken(context, clean) &&
            clean.split(Regex("\\s+")).size <= 3 &&
            !clean.contains("ouvre") && !clean.contains("appelle") &&
            !clean.contains("cherche") && !clean.contains("envoie")
        ) return showMascotNow()

        val p = CommandParser.parse(t)
        return when (p.intent) {
            CommandIntent.SHOW_MASCOT -> showMascotNow()
            CommandIntent.OPEN_APP -> withContext(Dispatchers.IO) { apps.launch(p.args["app"] ?: "") }
            CommandIntent.CALL_CONTACT -> contacts.call(p.args["name"] ?: "")
            CommandIntent.SEND_MESSAGE -> contacts.sendMessage(p.args["name"] ?: "", p.args["message"] ?: "")
            CommandIntent.SEARCH_WEB -> answerSearchIntent(p.args["query"] ?: t)
            CommandIntent.YOUTUBE -> yt.searchSmart(p.args["query"] ?: "")
            CommandIntent.STREAMING -> withContext(Dispatchers.IO) {
                streaming.open(p.args["platform"] ?: "", p.args["title"] ?: "")
            }
            CommandIntent.TRANSLATE -> withContext(Dispatchers.IO) {
                tr.translateText(p.args["text"] ?: "", "auto", "fr")
            }
            CommandIntent.TRANSLATE_MODE_ON -> {
                val src = p.args["source"] ?: "auto"; val tgt = p.args["target"] ?: "fr"
                TranslateModePrefs.start(context, src, tgt)
                "Mode traduction activé."
            }
            CommandIntent.TRANSLATE_MODE_OFF -> {
                TranslateModePrefs.stop(context); "Mode traduction désactivé."
            }
            CommandIntent.MEMORY_SAVE -> withContext(Dispatchers.IO) {
                val key = p.args["key"] ?: "note"
                val data = p.args["data"] ?: ""
                vault.save(key, data)
                relational.rememberFact(data)
                "C'est noté."
            }
            CommandIntent.MEMORY_GET -> withContext(Dispatchers.IO) {
                val key = p.args["key"] ?: ""
                val all = vault.getAll()
                val exact = all[key]
                val contains = all.entries.firstOrNull { it.key.contains(key, true) }?.value
                val fuzzyKey = FuzzyMatch.findBest(key, all.keys.toList())
                val fuzzy = fuzzyKey?.let { all[it] }
                exact?.toString() ?: contains?.toString() ?: fuzzy?.toString() ?: freeAI.answer(key)
            }
            CommandIntent.MEMORY_CLEAR -> withContext(Dispatchers.IO) {
                vault.clear()
                relational.clearAll()
                "D'accord, j'ai tout effacé de ma mémoire."
            }
            CommandIntent.QUICK_NOTE -> withContext(Dispatchers.IO) {
                val text = p.args["text"] ?: ""
                val note = VoiceNotes.add(context, text)
                if (note != null) "C'est noté." else "Je n'ai rien compris à noter."
            }
            CommandIntent.QUICK_NOTE_LIST -> withContext(Dispatchers.IO) {
                val notes = VoiceNotes.all(context)
                if (notes.isEmpty()) "Tu n'as aucune note pour l'instant."
                else notes.take(5).joinToString(". ") { it.text }
            }
            CommandIntent.QUICK_NOTE_CLEAR -> withContext(Dispatchers.IO) {
                VoiceNotes.clear(context)
                "Toutes tes notes ont été effacées."
            }
            CommandIntent.REMEMBER_FACT -> {
                val fact = p.args["fact"] ?: t
                relational.rememberFact(fact)
                "OK, je m'en souviendrai."
            }
            CommandIntent.SET_PROFILE -> {
                val key = p.args["key"] ?: "prenom"
                val value = p.args["value"] ?: ""
                relational.setProfileField(key, value)
                if (key == "prenom") "OK." // le prénom sera déjà dit en tête de la phrase
                else "C'est noté."
            }
            CommandIntent.EMERGENCY -> em.sos()
            CommandIntent.BATTERY -> "Batterie ${bat.level()} %."
            CommandIntent.RESTAURANT -> {
                val q = QueryCleaner.subject(p.args["query"] ?: "").ifBlank {
                    QueryCleaner.subject(t).ifBlank { "" }
                }
                if (q.isBlank()) "Quel type de restaurant ou quel lieu veux-tu ?"
                else maps.open(q) // Maps dynamique, pas de requête pré-écrite
            }
            CommandIntent.TOOL -> tool.open()
            CommandIntent.LOST_PHONE -> LostPhoneManager.trigger(context)
            CommandIntent.MAPS -> maps.open(p.args["query"] ?: "")
            CommandIntent.ACCESSIBILITY_ACTION -> {
                val svc = VanelleAccessibilityService.instance
                if (svc == null) "Active le service d'accessibilité dans Configuration pour que je puisse faire cette action système."
                else {
                    svc.action(p.args["action"] ?: "")
                    "C'est fait."
                }
            }
            CommandIntent.READ_SCREEN -> screenRead()
            CommandIntent.SCREEN_SUMMARY -> screenSummary()
            CommandIntent.SCREEN_FILL -> screenFill(p.args["text"] ?: "")
            CommandIntent.CLICK_SCREEN -> {
                val svc = VanelleAccessibilityService.instance
                if (svc == null) "Active l'accessibilité dans Configuration."
                else {
                    val ok = svc.clickNodeWithText(p.args["target"] ?: "")
                    if (ok) "C'est fait." else "Élément introuvable à l'écran. Dis-moi le texte exact visible ou active mieux l'accessibilité."
                }
            }
            CommandIntent.SCHEDULE_TASK -> withContext(Dispatchers.IO) {
                var desc = (p.args["description"] ?: "Rappel").trim()
                desc = desc.replace(Regex("(?i)^rappelle[- ]?moi\\s+"), "")
                    .replace(Regex("(?i)^souviens[- ]?moi\\s+"), "")
                    .replace(Regex("(?i)^programme +"), "")
                    .replace(Regex("(?i)^planifie +"), "")
                    .trim()
                    .ifBlank { "Rappel" }
                val hour = p.args["hour"]?.toIntOrNull() ?: 8
                val minute = p.args["minute"]?.toIntOrNull() ?: 0
                val repeat = p.args["repeat"]?.toBoolean() ?: false
                val task = relance.addTask(desc, hour, minute, repeat)
                AlarmScheduler.scheduleNext(context, task)
                val exactOk = AlarmScheduler.canScheduleExact(context)
                val timeStr = "${hour}h${minute.toString().padStart(2, '0')}"
                val base = "Relance enregistrée : « $desc » à $timeStr. Tu la vois dans l'onglet Relances."
                if (!exactOk) {
                    try {
                        val i = android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                            data = android.net.Uri.parse("package:${context.packageName}")
                            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(i)
                    } catch (_: Exception) {}
                    base + " Important : active les alarmes exactes dans les réglages qui viennent de s'ouvrir, sinon la relance peut ne pas sonner."
                } else base
            }
            CommandIntent.CREATE_ROUTINE -> {
                val hour = p.args["hour"]?.toIntOrNull() ?: 7
                val minute = p.args["minute"]?.toIntOrNull() ?: 30
                val actions = p.args["actions"] ?: "briefing"
                RoutineManager.add(context, "Routine", hour, minute, actions)
                "Routine créée pour ${hour}h${minute.toString().padStart(2, '0')}. Je t'en parlerai à ce moment-là."
            }
            CommandIntent.LIST_ROUTINES -> RoutineManager.describe(context)
            CommandIntent.SET_PERSONALITY ->
                "Je garde un seul style de réponse, clair et naturel."
            CommandIntent.OPEN_CAMERA -> MultimodalHelper.openCamera(context)
            CommandIntent.OPEN_GALLERY -> MultimodalHelper.openGallery(context)
            CommandIntent.SHOW_ACTIVITY_LOG -> {
                val lines = ActivityLog.all(context).take(8)
                if (lines.isEmpty()) "Le journal est vide pour l'instant."
                else lines.joinToString("\n") { ActivityLog.formatLine(it.first, it.second, it.third) }
            }
            CommandIntent.AGENT_GOAL -> {
                if (!allowAgents) "Sous-étape agent refusée (garde anti-récursion)."
                else {
                    HapticLanguage.play(context, HapticLanguage.Signal.LISTENING)
                    agent.run(p.args["goal"] ?: t)
                }
            }
            CommandIntent.EPISODIC_SUMMARY -> episodic.todaySummary()
            CommandIntent.EPISODIC_CONSOLIDATE -> episodic.consolidate()
            CommandIntent.SPATIAL_CONTEXT -> withContext(Dispatchers.IO) {
                val desc = spatial.describe()
                val mode = spatial.suggestedMode()
                "$desc. Mode suggéré : $mode."
            }
            CommandIntent.HAPTIC_DEMO -> {
                HapticLanguage.play(context, HapticLanguage.Signal.SUCCESS)
                HapticLanguage.describe()
            }
            CommandIntent.DYNAMIC_TOOL -> dynamicUi.create(p.args["request"] ?: t)
            CommandIntent.FLASHLIGHT -> {
                val on = when (p.args["on"]) {
                    "1" -> true
                    "0" -> false
                    else -> null
                }
                device.flashlight(on)
            }
            CommandIntent.VOLUME -> device.volume(p.args["dir"] ?: "status")
            CommandIntent.RINGER -> device.ringer(p.args["mode"] ?: "status")
            CommandIntent.CLIPBOARD_READ -> device.clipboardRead()
            CommandIntent.CLIPBOARD_WRITE -> device.clipboardWrite(p.args["text"] ?: "")
            CommandIntent.OPEN_URL -> device.openUrl(p.args["url"] ?: "")
            CommandIntent.SHARE_TEXT -> device.shareText(p.args["text"] ?: "")
            CommandIntent.TIMER -> {
                val m = p.args["minutes"]?.toIntOrNull() ?: 5
                device.timerMinutes(m)
            }
            CommandIntent.POINT_NODE -> {
                val target = p.args["target"] ?: ""
                if (target.isBlank()) "Élément à pointer non précisé."
                else GuidanceOverlay.pointToNode(context, target)
            }
            CommandIntent.GUIDANCE_OVERLAY -> {
                val msg = p.args["message"] ?: "Regarde ici"
                GuidanceOverlay.show(context, msg)
            }
            CommandIntent.FORCE_NIGHTLY -> NightlyConsolidation.runNow(context)
            CommandIntent.PRIVACY_STATUS -> PrivacyFirewall.status(context)
            CommandIntent.PRIVACY_LOCKDOWN -> {
                PrivacyFirewall.lockdown(context)
                HapticLanguage.play(context, HapticLanguage.Signal.WARNING)
                "Lockdown activé. " + PrivacyFirewall.status(context)
            }
            else -> answerSmart(t)
        }
    }


    private suspend fun answerSmart(t: String): String {
        ReasoningHelper.tryDeterministicMath(t)?.let { return it }
        val contextDependent = needsConversationalContext(t)
        if (!contextDependent) ResponseCache.get(context, t)?.let { return it }

        // 1) Intention dynamique (sujet + destination)
        val routed = QueryCleaner.route(t)
        if (routed.subject.isNotBlank()) {
            when (routed.dest) {
                QueryCleaner.Dest.YOUTUBE -> return yt.searchSmart(routed.subject)
                QueryCleaner.Dest.MAPS -> return maps.open(routed.subject)
                QueryCleaner.Dest.WEB -> return answerSearchIntent(routed.subject)
                QueryCleaner.Dest.STREAMING -> { /* laisse Llama / web */ }
                QueryCleaner.Dest.NONE -> { }
            }
        }

        // Faits / hors domaine → web systématique (vérification croisée)
        if (ReasoningHelper.isFactualLookup(t) || ReasoningHelper.isComplex(t)) {
            if (PrivacyFirewall.allowWeb(context) && LlamaModelManager.isNetworkAvailable(context)) {
                val viaWeb = try { synthesizeAnswer(t) } catch (_: Exception) { null }
                if (!viaWeb.isNullOrBlank() && !isGenericIntro(viaWeb)) {
                    ResponseCache.put(context, t, viaWeb)
                    return viaWeb
                }
            }
        }

        // 2) Cerveau Llama local + mémoire
        if (LlamaModelManager.isReady(context) && localAI.isLoaded()) {
            val ctx = MemoryEngine.promptContext(context, AIConfiguration.profile(context).contextChars.coerceAtMost(6500))
            val needsCtx = needsConversationalContext(t)
            val prompt = buildString {
                append(t.trim())
                append("\n\nComprends le message dans son contexte, réponds de façon cohérente et claire. ")
                if (needsCtx) append("Relie aux sujets précédents et résous les pronoms / suites. ")
                append("Si tu n'as pas l'info, dis-le clairement plutôt qu'inventer. Pas de présentation.")
            }
            val llamaRes = localAI.answer(
                prompt,
                extraContext = ctx,
                fastMode = false,
                maxTokensHint = AIConfiguration.profile(context).maxOutputTokens.coerceAtMost(if (t.length < 80) 256 else 384)
            )
            if (llamaRes != LocalLlamaHelper.NOT_READY && llamaRes.isNotBlank() && !isGenericIntro(llamaRes)) {
                val spoken = ReasoningHelper.extractSpokenAnswer(llamaRes)
                relational.addTurn("user", t)
                relational.addTurn("assistant", spoken)
                if (!contextDependent) ResponseCache.put(context, t, spoken)
                return spoken
            }
        }
        if (PersonalityPrefs.preferOffline(context) && !LlamaModelManager.isNetworkAvailable(context)) {
            return elegantUnknown(
                offline = true,
                canSearch = false
            )
        }
        return fallbackAi(t)
    }

    /** Gestion d'erreur élégante — « assistant sérieux » plutôt que plantage / bluff. */
    private fun elegantUnknown(offline: Boolean, canSearch: Boolean): String = when {
        offline ->
            "Je n'ai pas cette info en local pour le moment, et le mode hors-ligne est actif. " +
                "Active le réseau ou pose une commande concrète (ouvrir une app, batterie, relance…)."
        canSearch ->
            "Je n'ai pas cette information sous la main. Reformule un peu ta question, j'essaierai de trouver autrement."
        else ->
            "Je ne suis pas sûre de pouvoir répondre correctement à ça. Reformule avec d'autres mots, j'écoute."
    }

    private fun screenRead(): String {
        val svc = VanelleAccessibilityService.instance
            ?: return "Active le service d'accessibilité dans Configuration pour lire l'écran."
        val txt = svc.captureScreenText()
        return if (txt.isBlank()) "Je ne vois pas de texte lisible sur cet écran."
        else "Voici ce que je lis : ${txt.take(500)}"
    }

    private suspend fun screenSummary(): String {
        val svc = VanelleAccessibilityService.instance
            ?: return "Active l'accessibilité dans Configuration pour que je voie l'écran."
        val txt = svc.captureScreenText()
        if (txt.isBlank()) return "Écran vide ou non lisible pour moi."
        if (LlamaModelManager.isReady(context)) {
            val sum = localAI.answer(
                "Résume clairement et complètement en 2-4 phrases :\n${txt.take(800)}",
                extraContext = "",
                fastMode = false,
                maxTokensHint = 180
            )
            if (sum != LocalLlamaHelper.NOT_READY) return sum
        }
        val clean = txt.replace(Regex("\\s+"), " ").trim()
        return "Résumé de l'écran : ${clean.take(320)}"
    }

    private fun screenFill(value: String): String {
        val svc = VanelleAccessibilityService.instance
            ?: return "Active l'accessibilité dans Configuration."
        val ok = svc.fillFocusedOrFirstField(value)
        return if (ok) "Champ rempli : « ${value.take(60)} »."
        else "Aucun champ trouvé. Touche d'abord la zone de texte à l'écran, puis redis : remplis avec …"
    }

    private fun showMascotNow(): String {
        val name = MascotManager.getDisplayName(context)
        return "Salut, je suis $name ! Tu peux me parler…"
    }

    /**
     * Raisonne avant d'ouvrir une application :
     * 1) modèle local si disponible ;
     * 2) réponse Web rapide si elle est suffisamment informative ;
     * 3) sinon seulement, ouverture d'une vraie recherche Web.
     */
    private suspend fun answerSearchIntent(query: String): String {
        // Nettoie la requête — la réponse reste toujours parlée, jamais d'ouverture navigateur.
        val q = YouTubeHelper.cleanQuery(query).ifBlank { query.trim() }
        if (q.isBlank()) return "Que veux-tu que je recherche ?"
        return synthesizeAnswer(q)
    }

    /**
     * Toujours passer par l'IA pour produire une réponse parlée, professionnelle,
     * dans ses propres mots — jamais recopier tel quel un extrait Wikipédia/DDG,
     * et jamais ouvrir de navigateur. Les faits bruts trouvés en ligne ne servent
     * que de contexte à reformuler pour l'IA locale.
     */
    
    private suspend fun synthesizeAnswer(q: String): String {
        ReasoningHelper.tryDeterministicMath(q)?.let { return it }
        QuickFacts.answer(q)?.let { return it }

        val factual = ReasoningHelper.isFactualLookup(q)
        // Requête web optimisée (évite confusion superficie / population)
        val searchQ = try { ReasoningHelper.searchQueryFor(q) } catch (_: Exception) { q }

        val raw = try { freeAI.fetchRawFacts(searchQ) } catch (_: Exception) { null }
            ?: try { freeAI.fetchRawFacts(q) } catch (_: Exception) { null }

        // Faits culture G : privilégier le web, le 1B invente trop souvent
        if (factual && !raw.isNullOrBlank()) {
            val cleaned = formatWebFact(q, raw)
            // Optionnel : micro-reformulation seulement si le modèle est chargé
            // et qu'on garde les chiffres du web (sinon on garde cleaned)
            if (LlamaModelManager.isReady(context) && localAI.isLoaded()) {
                try {
                    val local = localAI.answer(
                        "Question : ${q.trim()}\n\n" +
                            "À partir UNIQUEMENT de ces faits, réponds en 1-3 phrases claires. " +
                            "Ne change aucun chiffre, nom de pays ou unité. Si les faits ne suffisent pas, dis-le.\n\n" +
                            "Faits :\n${raw.take(600)}",
                        extraContext = "",
                        fastMode = true,
                        maxTokensHint = 150
                    )
                    if (local != LocalLlamaHelper.NOT_READY && local.isNotBlank() &&
                        !isGenericIntro(local) && factsLookConsistent(raw, local)
                    ) {
                        return ReasoningHelper.extractSpokenAnswer(local)
                    }
                } catch (_: Exception) {}
            }
            return cleaned
        }

        if (LlamaModelManager.isReady(context) && localAI.isLoaded()) {
            val extraCtx = buildString {
                if (!raw.isNullOrBlank()) {
                    append("FAITS RÉCUPÉRÉS (ne pas inventer au-delà) :\n")
                    append(raw.take(700))
                } else {
                    append("Aucun fait externe. Si tu n'as pas l'info, dis-le clairement.")
                }
                val profile = relational.fullContextForAi(dialogTurns = 4, maxChars = 400)
                if (profile.isNotBlank()) {
                    if (isNotEmpty()) append("\n")
                    append(profile)
                }
            }
            try {
                val prompt = when {
                    !raw.isNullOrBlank() -> ReasoningHelper.buildRagPrompt(q)
                    ReasoningHelper.isComplex(q) -> ReasoningHelper.buildStructuredPrompt(q, false)
                    else -> ReasoningHelper.buildSimplePrompt(q)
                }
                val local = localAI.answer(
                    prompt,
                    extraContext = extraCtx,
                    fastMode = false,
                    maxTokensHint = if (ReasoningHelper.isComplex(q)) 200 else 160
                )
                if (local != LocalLlamaHelper.NOT_READY && local.isNotBlank() &&
                    !local.contains("pas trouvé de réponse fiable", ignoreCase = true) &&
                    !isGenericIntro(local)
                ) {
                    val spoken = ReasoningHelper.extractSpokenAnswer(local)
                    // Si on avait des faits web et que la réponse locale les contredit, garder le web
                    if (!raw.isNullOrBlank() && !factsLookConsistent(raw, spoken)) {
                        return formatWebFact(q, raw)
                    }
                    return spoken
                }
            } catch (_: Exception) {}
        }

        if (!raw.isNullOrBlank()) return formatWebFact(q, raw)

        try {
            val web = freeAI.answer(searchQ)
            if (web.isNotBlank()) return web
        } catch (_: Exception) {}

        val modelOk = LlamaModelManager.isReady(context)
        val loaded = try { localAI.isLoaded() } catch (_: Exception) { false }
        val online = try { LlamaModelManager.isNetworkAvailable(context) } catch (_: Exception) { false }
        return when {
            modelOk && !loaded ->
                "Le modèle est téléchargé mais pas encore en mémoire. Attends la fin du chargement, puis réessaie."
            modelOk && loaded ->
                elegantUnknown(offline = !online, canSearch = online && PrivacyFirewall.allowWeb(context))
            else ->
                "Vanelle prépare encore ses ressources. Réessaie dans quelques instants."
        }
    }

    /** Présente un extrait web de façon parlable, sans inventer. */
    private fun formatWebFact(question: String, raw: String): String {
        var t = raw.replace(Regex("\\s+"), " ").trim()
        if (t.isBlank()) return "Je n'ai pas trouvé d'info claire là-dessus. Tu peux reformuler ta question ?"

        // 1 à 3 phrases utiles, style conversation (pas un pavé encyclopédique)
        val sentences = t.split(Regex("(?<=[.!?])\\s+")).map { it.trim() }.filter { it.isNotBlank() }
        val useful = mutableListOf<String>()
        var total = 0
        for (s in sentences) {
            if (useful.isEmpty()) {
                useful.add(s)
                total += s.length
                continue
            }
            if (total + s.length > 320) break
            useful.add(s)
            total += s.length
            if (useful.size >= 3) break
        }
        t = useful.joinToString(" ").trim()
        if (t.isBlank()) t = raw.replace(Regex("\\s+"), " ").trim().take(320)

        if (t.length > 400) t = t.take(397).trimEnd('.', ',', ';', ' ') + "…"
        if (t.isNotEmpty() && t.last() !in listOf('.', '!', '?', '…')) t += "."
        return t
    }

    /**
     * Heuristique anti-hallucination : si le web cite un pays/chiffre majeur
     * et que la réponse locale n'en garde aucun, on considère l'incohérence.
     */
    private fun factsLookConsistent(rawFacts: String, answer: String): Boolean {
        val raw = rawFacts.lowercase()
        val ans = answer.lowercase()
        if (ans.length < 8) return false
        // Noms / indices géo fréquents
        val keys = listOf(
            "russie", "russia", "canada", "chine", "china", "états-unis", "united states",
            "inde", "india", "brésil", "brazil", "australie", "km²", "km2", "million", "milliard"
        )
        val presentInRaw = keys.filter { raw.contains(it) }
        if (presentInRaw.isEmpty()) return true // pas de signal fort → on fait confiance
        // Au moins un signal du web doit apparaître dans la réponse
        if (presentInRaw.any { ans.contains(it) }) return true
        // Chiffres à 2+ digits partagés
        val rawNums = Regex("""\d{2,}""").findAll(raw).map { it.value }.toSet()
        val ansNums = Regex("""\d{2,}""").findAll(ans).map { it.value }.toSet()
        if (rawNums.isNotEmpty() && rawNums.intersect(ansNums).isNotEmpty()) return true
        return false
    }

private suspend fun fallbackAi(t: String): String = synthesizeAnswer(t)
}
