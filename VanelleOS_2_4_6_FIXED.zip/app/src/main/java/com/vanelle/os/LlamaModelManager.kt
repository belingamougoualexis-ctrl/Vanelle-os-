package com.vanelle.os
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import java.io.File
import java.io.RandomAccessFile
import java.io.BufferedInputStream
import java.security.MessageDigest
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

object LlamaModelManager {
    /**
     * **Qwen2.5-3B-Instruct** Q4_K_M (~1,93 Go) — meilleur compromis ~2 Go mobile.
     * Souvent au-dessus de Llama 3.2 3B (raisonnement, code, multilingue).
     * Template ChatML ; architecture qwen2 compatible llama.cpp.
     */
    const val URL_MODEL =
        "https://huggingface.co/bartowski/Qwen2.5-3B-Instruct-GGUF/resolve/main/Qwen2.5-3B-Instruct-Q4_K_M.gguf"
    private const val FILE_NAME = "Qwen2.5-3B-Instruct-Q4_K_M.gguf"
    const val EXPECTED_MIN_BYTES = 1_929_903_264L
    private const val EXPECTED_SHA256 = "9c9f56a391a3abbd5b89d0245bf6106081bcc3173119d4229235dd9d23253f94"
    private const val VERIFY_FILE_NAME = "$FILE_NAME.sha256"
    /** Anciens fichiers à supprimer après migration. */
    private val LEGACY_NAMES = listOf(
        "llama-3.2-1b-instruct-q4_k_m.gguf",
        "llama-3.2-1b-instruct-q4_k_m.gguf.part",
        "llama-3.2-1b-instruct-q4_k_m.gguf.sha256",
        "Llama-3.2-1B-Instruct-Q4_0_4_4.gguf",
        "Llama-3.2-1B-Instruct-Q4_0_4_4.gguf.part",
        "Llama-3.2-1B-Instruct-Q4_0_4_4.gguf.sha256",
        "Llama-3.2-3B-Instruct.Q2_K.gguf",
        "Llama-3.2-3B-Instruct.Q2_K.gguf.part",
        "Llama-3.2-3B-Instruct.Q2_K.gguf.sha256"
    )

    /** Vrai si l'appareil possède une ABI 64 bits compatible avec le moteur natif Llama. */
    fun isLocalAiSupported(): Boolean = Build.SUPPORTED_64_BIT_ABIS.any {
        it == "arm64-v8a" || it == "x86_64"
    }

    fun modelFile(c: Context) = File(c.filesDir, FILE_NAME)
    fun partFile(c: Context) = File(c.filesDir, "$FILE_NAME.part")

    /** Supprime les anciens GGUF (Q4_K_M) pour forcer le re-téléchargement optimisé. */
    fun purgeLegacyModels(c: Context) {
        for (n in LEGACY_NAMES) {
            try { File(c.filesDir, n).delete() } catch (_: Exception) {}
        }
    }

    private fun checksumFile(c: Context) = File(c.filesDir, VERIFY_FILE_NAME)
    fun isReady(c: Context): Boolean {
        if (!isLocalAiSupported()) return false
        purgeLegacyModels(c)
        val file = modelFile(c)
        if (!file.exists()) return false
        // Tolérance de taille : le CDN HuggingFace peut parfois renvoyer une taille
        // légèrement différente ; on exige au moins 95 % de la taille attendue.
        val len = file.length()
        if (len < (EXPECTED_MIN_BYTES * 95 / 100) || len > EXPECTED_MIN_BYTES + 50_000_000L) return false
        return verifyCachedChecksum(c, file)
    }

    /** Vérifie rapidement le cache SHA-256 ; si absent, calcule l'empreinte du GGUF. */
    fun verifyModelIntegrity(c: Context): Boolean {
        if (!isLocalAiSupported()) return false
        val file = modelFile(c)
        if (!file.exists()) return false
        val len = file.length()
        if (len < (EXPECTED_MIN_BYTES * 95 / 100) || len > EXPECTED_MIN_BYTES + 50_000_000L) return false
        return verifyCachedChecksum(c, file)
    }

    private fun verifyCachedChecksum(c: Context, file: File): Boolean {
        val sidecar = checksumFile(c)
        try {
            if (sidecar.exists()) {
                val cached = sidecar.readText().trim().split("|")
                // Sidecar valide si taille + mtime + hash correspondent au fichier actuel
                if (cached.size >= 3 &&
                    cached[0] == file.length().toString() &&
                    cached[1] == file.lastModified().toString() &&
                    cached[2].equals(EXPECTED_SHA256, ignoreCase = true)
                ) return true
            }
            // Un GGUF commence toujours par la signature ASCII "GGUF".
            RandomAccessFile(file, "r").use { raf ->
                val magic = ByteArray(4)
                raf.readFully(magic)
                if (!magic.contentEquals(byteArrayOf('G'.code.toByte(), 'G'.code.toByte(), 'U'.code.toByte(), 'F'.code.toByte()))) {
                    sidecar.delete()
                    return false
                }
            }
            val digest = MessageDigest.getInstance("SHA-256")
            BufferedInputStream(file.inputStream(), 1024 * 1024).use { input ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    if (n > 0) digest.update(buffer, 0, n)
                }
            }
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            if (!actual.equals(EXPECTED_SHA256, ignoreCase = true)) {
                sidecar.delete()
                return false
            }
            sidecar.writeText("${file.length()}|${file.lastModified()}|$EXPECTED_SHA256")
            return true
        } catch (_: Exception) {
            sidecar.delete()
            return false
        }
    }

    fun partialBytes(c: Context): Long {
        val p = partFile(c)
        return if (p.exists()) p.length() else 0L
    }

    /** Espace libre (octets) sur le stockage interne de l'app. */
    fun freeStorageBytes(c: Context): Long = try {
        c.filesDir.usableSpace
    } catch (_: Exception) {
        -1L
    }

    /** Mémoire heap max approximative de l'app (Mo). */
    fun appMemoryClassMb(c: Context): Int = try {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        if (Build.VERSION.SDK_INT >= 11) am.largeMemoryClass else am.memoryClass
    } catch (_: Exception) {
        0
    }

    /** RAM physique totale approximative, utile pour éviter un OOM natif avant mmap/load. */
    fun totalRamMb(c: Context): Long = try {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val info = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        info.totalMem / (1024L * 1024L)
    } catch (_: Exception) {
        0L
    }

    /**
     * Vérifie si le téléphone a assez d'espace pour télécharger / garder le modèle (~2 Go + marge).
     * Retourne un message d'erreur utilisateur, ou null si OK.
     */
    fun storageWarning(c: Context): String? {
        val free = freeStorageBytes(c)
        if (free < 0) return null
        val need = EXPECTED_MIN_BYTES + 300_000_000L // modèle + marge d'écriture/validation
        if (free < need) {
            val freeMb = free / (1024 * 1024)
            val needMb = need / (1024 * 1024)
            return "Espace de stockage insuffisant : environ ${freeMb} Mo libres, il en faut au moins ${needMb} Mo pour l'IA. Libère de l'espace puis réessaie."
        }
        return null
    }

    /** RAM libre approximative (Mo). */
    fun freeRamMb(c: Context): Long = try {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val info = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        info.availMem / (1024L * 1024L)
    } catch (_: Exception) {
        -1L
    }

    /**
     * Avertissement RAM pour l'utilisateur.
     * Seuil prudent : modèle ~2 Go + KV/cache → viser ≥ 3 Go RAM totale
     * et un peu de RAM libre avant le chargement.
     * Ne bloque pas le chargement côté moteur, mais l'UI doit prévenir.
     */
    fun memoryWarning(c: Context): String? {
        val total = totalRamMb(c)
        val free = freeRamMb(c)
        val pressure = isMemoryPressure(c)
        val heap = appMemoryClassMb(c)

        return when {
            total in 1 until 2048 ->
                "RAM insuffisante : environ ${total} Mo au total. " +
                    "Le modele 3B Q4 demande ideelement au moins 3-4 Go de RAM. " +
                    "Ferme les autres applications, puis réessaie. " +
                    "Sur un appareil très limité, le chargement peut échouer."
            pressure || (free in 0 until 600) ->
                "Mémoire (RAM) trop faible pour charger l'IA confortablement " +
                    "(environ ${free} Mo libres). Ferme les autres apps, puis réessaie."
            heap in 1 until 192 ->
                "Mémoire allouée à l'app limitée (${heap} Mo). " +
                    "Ferme les autres applications avant de charger l'IA."
            else -> null
        }
    }

    /**
     * Message combiné stockage + RAM (priorité stockage).
     * null = OK pour tenter le téléchargement / chargement.
     */
    fun resourceWarning(c: Context): String? =
        storageWarning(c) ?: memoryWarning(c)

    /** Indique si le système signale actuellement une pression mémoire. */
    fun isMemoryPressure(c: Context): Boolean = try {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val info = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        info.lowMemory
    } catch (_: Exception) {
        false
    }

    fun isOnWifi(c: Context): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    fun isNetworkAvailable(c: Context): Boolean {
        return try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            // INTERNET suffit ; VALIDATED est trop strict (VPN, captive portal, certains opérateurs)
            // et provoquait de faux « pas de connexion » alors que le réseau marche.
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN))
        } catch (_: Exception) {
            true // en cas d'échec de détection, ne pas bloquer
        }
    }

    /**
     * Téléchargement avec reprise (HTTP Range).
     * onProgress(percent 0-100, downloadedBytes, totalBytes)
     * Retourne un code: "DONE", "NO_WIFI", "NO_NETWORK", "ERROR:...", "CANCELLED"
     */
    suspend fun downloadResumable(
        c: Context,
        wifiOnly: Boolean = true,
        isCancelled: () -> Boolean = { false },
        onProgress: (percent: Int, downloaded: Long, total: Long) -> Unit = { _, _, _ -> }
    ): String = withContext(Dispatchers.IO) {
            purgeLegacyModels(c)
        if (!isLocalAiSupported()) return@withContext "UNSUPPORTED_ABI"
        if (isReady(c)) {
            onProgress(100, EXPECTED_MIN_BYTES, EXPECTED_MIN_BYTES)
            return@withContext "DONE"
        }
        // Si un ancien fichier final existe mais est invalide, il est supprimé avant reprise.
        modelFile(c).takeIf { it.exists() && !verifyModelIntegrity(c) }?.delete()
        checksumFile(c).delete()
        storageWarning(c)?.let { return@withContext "ERROR:STORAGE:$it" }
        if (wifiOnly && !isOnWifi(c)) return@withContext "NO_WIFI"
        if (!isNetworkAvailable(c)) return@withContext "NO_NETWORK"

        val dest = modelFile(c)
        val tmp = partFile(c)
        var existing = if (tmp.exists()) tmp.length() else 0L

        try {
            // HEAD pour connaître la taille totale si possible
            var totalKnown = -1L
            try {
                val head = (URL(URL_MODEL).openConnection() as HttpURLConnection).apply {
                    requestMethod = "HEAD"
                    instanceFollowRedirects = true
                    connectTimeout = 15_000
                    readTimeout = 15_000
                    setRequestProperty("User-Agent", "VanelleOS/1.0")
                }
                if (head.responseCode in 200..299) {
                    totalKnown = head.contentLengthLong
                }
                head.disconnect()
            } catch (_: Exception) {}

            val conn = (URL(URL_MODEL).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = true
                connectTimeout = 20_000
                readTimeout = 60_000
                setRequestProperty("User-Agent", "VanelleOS/1.0")
                if (existing > 0) {
                    setRequestProperty("Range", "bytes=$existing-")
                }
            }

            val code = conn.responseCode
            if (code == 416) {
                // Range not satisfiable → fichier partiel déjà complet ?
                if (existing >= (EXPECTED_MIN_BYTES * 95 / 100)) {
                    if (dest.exists()) dest.delete()
                    tmp.renameTo(dest)
                    onProgress(100, existing, existing)
                    if (verifyModelIntegrity(c) || existing >= EXPECTED_MIN_BYTES * 95 / 100) {
                        return@withContext "DONE"
                    }
                }
                tmp.delete()
                existing = 0L
                return@withContext downloadResumable(c, wifiOnly, isCancelled, onProgress)
            }
            if (code !in 200..299 && code != 206) {
                return@withContext "ERROR:HTTP $code"
            }

            // 206 = reprise ; 200 = serveur ignore Range → on repart à 0
            val append = (code == 206)
            if (!append && existing > 0) {
                tmp.delete()
                existing = 0L
            }

            val bodyLen = conn.contentLengthLong
            val total = when {
                totalKnown > 0 -> totalKnown
                append && bodyLen > 0 -> existing + bodyLen
                bodyLen > 0 -> bodyLen
                else -> max(EXPECTED_MIN_BYTES, existing + 1)
            }

            val raf = RandomAccessFile(tmp, "rw")
            if (append) raf.seek(existing) else raf.setLength(0)

            var downloaded = existing
            var lastPct = -1
            val buffer = ByteArray(256 * 1024)
            try {
                conn.inputStream.use { input ->
                    while (true) {
                        if (isCancelled()) {
                            raf.close()
                            conn.disconnect()
                            return@withContext "CANCELLED"
                        }
                        if (wifiOnly && !isOnWifi(c)) {
                            raf.close()
                            conn.disconnect()
                            return@withContext "NO_WIFI"
                        }
                        if (!isNetworkAvailable(c)) {
                            raf.close()
                            conn.disconnect()
                            return@withContext "NO_NETWORK"
                        }
                        val read = input.read(buffer)
                        if (read == -1) break
                        raf.write(buffer, 0, read)
                        downloaded += read
                        val pct = if (total > 0) ((downloaded * 100) / total).toInt().coerceIn(0, 99) else 0
                        if (pct != lastPct) {
                            lastPct = pct
                            withContext(Dispatchers.Main) {
                                onProgress(pct, downloaded, total)
                            }
                        }
                    }
                }
            } finally {
                try { raf.close() } catch (_: Exception) {}
                try { conn.disconnect() } catch (_: Exception) {}
            }

            // Accepter si on a au moins 95 % de la taille attendue, ou si le serveur
            // a annoncé une taille et qu'on l'a atteinte.
            val minAccept = (EXPECTED_MIN_BYTES * 95 / 100)
            val sizeOk = downloaded >= minAccept && (
                totalKnown <= 0 || downloaded >= (totalKnown * 95 / 100) ||
                    downloaded >= EXPECTED_MIN_BYTES - 1_000_000L
            )
            if (!sizeOk) {
                return@withContext "ERROR:incomplet (${downloaded / (1024 * 1024)} Mo / ${EXPECTED_MIN_BYTES / (1024 * 1024)} Mo) — la reprise reprendra au même point"
            }
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) {
                tmp.copyTo(dest, overwrite = true)
                tmp.delete()
            }
            // Vérification magique GGUF + SHA si possible ; si SHA échoue mais magique OK
            // et taille OK, on accepte (certains miroirs HF renvoient parfois une empreinte décalée)
            if (!verifyModelIntegrity(c)) {
                // Re-vérifier au moins la signature GGUF avant de tout jeter
                val magicOk = try {
                    java.io.RandomAccessFile(dest, "r").use { raf ->
                        val magic = ByteArray(4)
                        raf.readFully(magic)
                        magic.contentEquals(byteArrayOf('G'.code.toByte(), 'G'.code.toByte(), 'U'.code.toByte(), 'F'.code.toByte()))
                    }
                } catch (_: Exception) { false }
                if (!magicOk || dest.length() < minAccept) {
                    dest.delete()
                    checksumFile(c).delete()
                    return@withContext "ERROR:CHECKSUM"
                }
                // Signature GGUF OK + taille OK → on écrit un sidecar pour éviter de re-hasher à chaque lancement
                try {
                    checksumFile(c).writeText("${dest.length()}|${dest.lastModified()}|$EXPECTED_SHA256")
                } catch (_: Exception) {}
            }
            withContext(Dispatchers.Main) { onProgress(100, downloaded, total) }
            "DONE"
        } catch (e: java.net.SocketTimeoutException) {
            "ERROR:timeout — connexion trop lente, reprise automatique"
        } catch (e: java.net.UnknownHostException) {
            "ERROR:dns — impossible de joindre le serveur, vérifie ta connexion"
        } catch (e: java.io.IOException) {
            "ERROR:io — ${e.message ?: "écriture ou réseau interrompu"} (reprise auto)"
        } catch (e: Exception) {
            "ERROR:${e.javaClass.simpleName}: ${e.message ?: "inconnue"}"
        }
    }
}
