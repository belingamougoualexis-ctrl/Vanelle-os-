package com.vanelle.app

import android.os.Bundle
import android.content.Intent
import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.ReactApplication
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.fabricEnabled
import com.facebook.react.defaults.DefaultReactActivityDelegate

class MainActivity : ReactActivity() {
    override fun getMainComponentName() = "Vanelle"

    override fun createReactActivityDelegate(): ReactActivityDelegate =
        DefaultReactActivityDelegate(this, mainComponentName, fabricEnabled)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleVanelleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleVanelleIntent(intent)
    }

    // reactInstanceManager n'est plus disponible en mode Bridgeless (New Architecture) :
    // l'appeler provoque un crash immédiat et systématique à chaque ouverture.
    // On récupère le ReactContext via reactHost, l'API compatible Bridgeless.
    private fun handleVanelleIntent(intent: Intent) {
        val reactContext = (application as ReactApplication).reactHost?.currentReactContext
        reactContext?.getNativeModule(VanelleNativeModule::class.java)?.handleIntent(intent)
    }
}
