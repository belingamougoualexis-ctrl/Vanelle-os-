# Vanelle — Android natif, llama.cpp + RAG local

Cette version corrige les points de la version précédente :

- inference LLM **réelle** avec llama.cpp natif Android/ARM64 ;
- modèle conversationnel Qwen2.5-0.5B-Instruct Q4_K_M (~398 MB) ;
- téléchargement **après consentement** et reprise HTTP Range ;
- vérification SHA-256 du modèle officiel choisi ;
- moteur d'embeddings **réel et natif** avec all-MiniLM-L6-v2 Q4_K_M (~21.3 MB), exécuté par llama.cpp en mode embedding ;
- ETL : extraction, nettoyage, chunking, embeddings, index local, recherche cosine et injection RAG ;
- mémoire persistante dans IndexedDB ;
- import de n'importe quel GGUF compatible après validation du magic GGUF ;
- moteur distant réellement configurable via endpoint OpenAI-compatible, avec clé chiffrée Android Keystore ;
- aucun autre nom de modèle n'est affiché dans l'interface utilisateur ;
- mode hors ligne pour le moteur local après téléchargement ;
- adaptation du contexte et des threads au matériel ;
- workflow GitHub Actions reproductible pour compiler l'APK ARM64 release.

## Taille des téléchargements

Le moteur LLM fait environ 398 MB. Le modèle d'embeddings fait environ 21.3 MB. Le téléchargement initial est donc d'environ **420 MB**, hors reprise/cache HTTP. Le modèle MiniLM Q4_K_M est publié comme modèle d'embeddings GGUF utilisable en mode embedding avec llama.cpp.

## Important

Le ZIP contient le code source et la configuration de compilation. Il ne contient pas les 398 MB + 21.3 MB de poids : ils sont téléchargés uniquement après consentement de l'utilisateur.

L'APK doit être construit sur GitHub Actions ou une machine Android/Gradle correctement équipée. Je n'affirme pas qu'un APK release a été compilé dans cet environnement si aucun SDK/NDK/Gradle n'y est disponible.

## Compilation

Linux/macOS/Termux with Java 17, Android SDK/NDK, CMake and Git:

```bash
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
```

The launcher bootstraps Gradle 8.9 automatically. CI uses the same launcher.

The native dependency is pinned to llama.cpp `b10516`.
