package com.vanelle.os

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class MemoryVault(context: Context) {
    private val appContext = context.applicationContext
    private var preferences: SharedPreferences? = null

    private fun pref(): SharedPreferences? {
        preferences?.let { return it }

        return try {
            val masterKey = MasterKey.Builder(appContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                appContext,
                "vault",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            ).also { preferences = it }
        } catch (_: Exception) {
            null
        }
    }

    fun save(k: String, v: String) {
        pref()?.edit()?.putString(k.lowercase().trim(), v)?.apply()
    }

    fun get(k: String): String? =
        pref()?.getString(k.lowercase().trim(), null)

    fun getAll(): Map<String, String> {
        val stored = pref() ?: return emptyMap()
        return stored.all.mapNotNull { (key, value) ->
            (value as? String)?.let { key to it }
        }.toMap()
    }

    fun clear() {
        pref()?.edit()?.clear()?.apply()
    }
}
