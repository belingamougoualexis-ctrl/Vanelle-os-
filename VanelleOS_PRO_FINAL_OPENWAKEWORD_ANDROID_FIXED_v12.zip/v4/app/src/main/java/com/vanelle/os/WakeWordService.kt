package com.vanelle.os

import android.app.*
import android.content.pm.ServiceInfo
import android.content.Intent
import android.os.Bundle
import android.os.IBinder
import android.speech.*
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

/**
 * Service d'écoute du mot d'activation "Cassandra".
 *
 * UNIQUEMENT openWakeWord (AudioRecord silencieux) — aucun SpeechRecognizer
 * en boucle en arrière-plan (pas de bip permanent).
 * SpeechRecognizer n'est lancé qu'UNE fois après détection du wake word,
 * pour capturer la commande.
 */
class WakeWordService : Service() {
    companion object {
        private const val TAG = "WakeWordService"
    }

    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var commandTimeoutJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val detector by lazy { OpenWakeWordDetector(this) }

    @Volatile
    private var isServiceDestroyed = false

    @Volatile
    private var capturingCommand = false

    private val wakeVariants = listOf(
        "cassandra", "cassandre", "casandra", "cassandras", "kasandra", "cass", "sandra"
    )

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isServiceDestroyed = false
        Log.i(TAG, "onCreate")
        WakeWordDiagnostics.log(this, TAG, "service démarré (onCreate)")
        try {
            val id = "vanelle_wake"
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(
                NotificationChannel(id, "Vanelle", NotificationManager.IMPORTANCE_LOW)
            )
            val n = NotificationCompat.Builder(this, id)
                .setContentTitle("VanelleOS")
                .setContentText("Écoute active — dis Cassandra")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
            if (androidx.core.content.ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.RECORD_AUDIO
                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                WakeWordDiagnostics.log(this, TAG, "micro désactivé: RECORD_AUDIO non accordé")
                stopSelf()
                return
            }

            if (android.os.Build.VERSION.SDK_INT >= 29) {
                androidx.core.app.ServiceCompat.startForeground(
                    this,
                    1,
                    n,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(1, n)
            }
            tts = TextToSpeech(this) { status ->
                if (status == TextToSpeech.SUCCESS) tts?.language = Locale.FRANCE
            }
            scope.launch {
                withContext(Dispatchers.IO) {
                    WakeWordModelManager.downloadIfNeeded(this@WakeWordService)
                }
                if (isServiceDestroyed) return@launch
                startOpenWakeWordListening()
            }
        } catch (e: Exception) {
            Log.e(TAG, "onCreate failed: ${e.message}")
            WakeWordDiagnostics.log(this, TAG, "ERREUR onCreate : ${e.message}")
            stopSelf()
        }
    }

    /** Démarre uniquement openWakeWord. Si modèles absents → retry, jamais SpeechRecognizer en boucle. */
    private fun startOpenWakeWordListening() {
        if (isServiceDestroyed || capturingCommand) return
        if (WakeWordModelManager.isReady(this) && detector.prepare()) {
            try {
                Log.i(TAG, "starting openWakeWord detector")
                detector.start { onWakeDetected() }
            } catch (e: Exception) {
                Log.e(TAG, "detector.start failed: ${e.message}")
                WakeWordDiagnostics.log(this, TAG, "ERREUR detector.start : ${e.message}")
                scheduleModelRetry()
            }
        } else {
            Log.w(TAG, "models not ready, scheduling retry")
            WakeWordDiagnostics.log(this, TAG, "modèles pas prêts (isReady=${WakeWordModelManager.isReady(this)}), nouvelle tentative dans 4s")
            scheduleModelRetry()
        }
    }

    private fun scheduleModelRetry() {
        scope.launch {
            delay(4000)
            if (isServiceDestroyed) return@launch
            withContext(Dispatchers.IO) {
                WakeWordModelManager.downloadIfNeeded(this@WakeWordService)
            }
            if (!isServiceDestroyed) startOpenWakeWordListening()
        }
    }

    /**
     * Après détection silencieuse du wake word :
     * arrête AudioRecord, lance UN SpeechRecognizer pour la commande uniquement.
     */
    private fun onWakeDetected() {
        if (isServiceDestroyed || capturingCommand) return
        Log.i(TAG, "wake word detected — launching SpeechRecognizer")
        WakeWordDiagnostics.log(this, TAG, "Cassandra détectée → lancement de SpeechRecognizer pour capter la commande")
        capturingCommand = true
        commandTimeoutJob?.cancel()
        detector.stop()

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            WakeWordDiagnostics.log(this, TAG, "ERREUR : SpeechRecognizer.isRecognitionAvailable=false (aucun moteur de reconnaissance vocale sur cet appareil/cette ROM)")
            capturingCommand = false
            resumeOpenWakeWord()
            return
        }
        try {
            rec?.destroy()
            rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onResults(r: Bundle?) {
                        if (isServiceDestroyed) return
                        val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull() ?: ""
                        WakeWordDiagnostics.log(this@WakeWordService, TAG, "commande captée : \"$t\"")
                        if (t.isNotBlank()) handleCommand(t)
                        try { rec?.destroy() } catch (_: Exception) {}
                        rec = null
                        commandTimeoutJob?.cancel()
                        capturingCommand = false
                        resumeOpenWakeWord()
                    }

                    override fun onError(e: Int) {
                        WakeWordDiagnostics.log(this@WakeWordService, TAG, "ERREUR SpeechRecognizer : ${speechErrorLabel(e)}")
                        try { rec?.destroy() } catch (_: Exception) {}
                        rec = null
                        commandTimeoutJob?.cancel()
                        capturingCommand = false
                        if (!isServiceDestroyed) resumeOpenWakeWord()
                    }

                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                    override fun onPartialResults(p: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    // Fin de phrase plus rapide → réponse plus réactive
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 800)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 600)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 200)
                }
                try {
                    startListening(intent)
                    commandTimeoutJob = scope.launch {
                        // Timeout plus court : si rien n'est dit, on revient vite à Cassandra
                        delay(5_000)
                        if (!isServiceDestroyed && capturingCommand) {
                            WakeWordDiagnostics.log(
                                this@WakeWordService, TAG,
                                "timeout SpeechRecognizer (5s) → retour à openWakeWord"
                            )
                            try { rec?.cancel() } catch (_: Exception) {}
                            try { rec?.destroy() } catch (_: Exception) {}
                            rec = null
                            capturingCommand = false
                            resumeOpenWakeWord()
                        }
                    }
                } catch (e: Exception) {
                    WakeWordDiagnostics.log(this@WakeWordService, TAG, "ERREUR startListening : ${e.message}")
                    try { rec?.destroy() } catch (_: Exception) {}
                    rec = null
                    capturingCommand = false
                    resumeOpenWakeWord()
                }
            }
        } catch (e: Exception) {
            WakeWordDiagnostics.log(this, TAG, "ERREUR création SpeechRecognizer : ${e.message}")
            capturingCommand = false
            resumeOpenWakeWord()
        }
    }

    private fun speechErrorLabel(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH -> "aucune parole reconnue (ERROR_NO_MATCH)"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "silence, personne n'a parlé à temps (ERROR_SPEECH_TIMEOUT)"
        SpeechRecognizer.ERROR_NETWORK -> "erreur réseau (ERROR_NETWORK)"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "délai réseau dépassé (ERROR_NETWORK_TIMEOUT)"
        SpeechRecognizer.ERROR_AUDIO -> "erreur audio matérielle (ERROR_AUDIO)"
        SpeechRecognizer.ERROR_CLIENT -> "erreur côté app (ERROR_CLIENT)"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "permission micro refusée (ERROR_INSUFFICIENT_PERMISSIONS)"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "moteur de reconnaissance déjà occupé (ERROR_RECOGNIZER_BUSY)"
        SpeechRecognizer.ERROR_SERVER -> "erreur serveur du moteur de reconnaissance (ERROR_SERVER)"
        else -> "code $code"
    }

    private fun resumeOpenWakeWord() {
        if (isServiceDestroyed) return
        capturingCommand = false
        scope.launch {
            // Réarme Cassandra très rapidement (~0.2 s)
            delay(200)
            if (!isServiceDestroyed) startOpenWakeWordListening()
        }
    }

    private fun findWakeIndex(text: String): Int {
        val lower = text.lowercase()
        val regex = Regex("[a-zàâäéèêëîïôöùûüç]+")
        for (m in regex.findAll(lower)) {
            val w = m.value
            if (w in wakeVariants ||
                FuzzyMatch.close(w, "cassandra", 2) ||
                FuzzyMatch.close(w, "cassandre", 2)
            ) return m.range.first
        }
        return -1
    }

    private fun wakeWordEnd(text: String, startIdx: Int): Int {
        val lower = text.lowercase()
        val regex = Regex("[a-zàâäéèêëîïôöùûüç]+")
        val m = regex.find(lower, startIdx) ?: return startIdx
        return m.range.last + 1
    }

    private fun handleCommand(text: String) {
        if (isServiceDestroyed || text.isBlank()) return
        if (TranslateModePrefs.isActive(this)) {
            handleTranslateMode(text)
            return
        }
        val idx = findWakeIndex(text)
        val original = if (idx >= 0) {
            val endIdx = wakeWordEnd(text, idx)
            text.substring(endIdx.coerceAtMost(text.length)).trim().ifEmpty { text.trim() }
        } else text.trim()
        dispatchCommand(original, original.lowercase())
    }

    private fun dispatchCommand(originalCmd: String, cmd: String) {
        if (isServiceDestroyed) return
        val parsed = CommandParser.parse(originalCmd)
        if (parsed.intent == CommandIntent.CALL_CONTACT ||
            parsed.intent == CommandIntent.SEND_MESSAGE
        ) {
            try {
                val i = Intent(this@WakeWordService, MainActivity::class.java).apply {
                    putExtra(
                        "confirm_type",
                        if (parsed.intent == CommandIntent.CALL_CONTACT) "call" else "sms"
                    )
                    putExtra("confirm_name", parsed.args["name"] ?: "")
                    putExtra("confirm_message", parsed.args["message"] ?: "")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(i)
            } catch (_: Exception) {
            }
            return
        }
        scope.launch {
            if (isServiceDestroyed) return@launch
            try {
                val i = Intent(this@WakeWordService, MainActivity::class.java).apply {
                    putExtra("pending_command", originalCmd.ifBlank { cmd })
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(i)
            } catch (_: Exception) {
            }
        }
    }

    private fun handleTranslateMode(text: String) {
        if (isServiceDestroyed) return
        val lower = text.lowercase()
        val parsed = CommandParser.parse(text)
        if (parsed.intent == CommandIntent.TRANSLATE_MODE_OFF ||
            lower.contains("quitte mode") ||
            lower.contains("stop traduction") ||
            lower.contains("arrête traduction") ||
            lower.contains("arrete traduction")
        ) {
            TranslateModePrefs.stop(this)
            try {
                tts?.language = Locale.FRANCE
                tts?.speak("Mode traduction désactivé", TextToSpeech.QUEUE_FLUSH, null, "tr_off")
            } catch (_: Exception) {
            }
            return
        }
        val src = TranslateModePrefs.source(this)
        val tgt = TranslateModePrefs.target(this)
        scope.launch {
            if (isServiceDestroyed) return@launch
            val translated = withContext(Dispatchers.IO) {
                TranslateHelper(this@WakeWordService).translateText(text, src, tgt)
            }
            if (isServiceDestroyed) return@launch
            try {
                val tag = when (tgt) {
                    "zh-CN" -> "zh"
                    "auto" -> "fr"
                    else -> tgt
                }
                tts?.language = Locale.forLanguageTag(tag)
            } catch (_: Exception) {
                try { tts?.language = Locale.FRANCE } catch (_: Exception) {}
            }
            try {
                if (translated.isNotBlank() &&
                    !translated.startsWith("Traduction indisponible")
                ) {
                    tts?.speak(translated, TextToSpeech.QUEUE_FLUSH, null, "tr_out")
                } else {
                    tts?.language = Locale.FRANCE
                    tts?.speak(
                        "Traduction indisponible, vérifie ta connexion",
                        TextToSpeech.QUEUE_FLUSH, null, "tr_err"
                    )
                }
            } catch (_: Exception) {
            }
        }
    }

    override fun onDestroy() {
        isServiceDestroyed = true
        capturingCommand = false
        commandTimeoutJob?.cancel()
        try { rec?.destroy() } catch (_: Exception) {}
        rec = null
        try { detector.stop() } catch (_: Exception) {}
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        scope.cancel()
        super.onDestroy()
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int = START_STICKY
}
