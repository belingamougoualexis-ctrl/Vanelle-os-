package com.vanelle.os
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Mémoire relationnelle : profil, faits, humeurs, contexte de conversation.
 * Stockage chiffré via MemoryVault + prefs structurées.
 */
class RelationalMemory(private val c: Context) {
    private val vault = MemoryVault(c)
    private val prefs = c.getSharedPreferences("vanelle_relational", 0)

    fun setProfileField(key: String, value: String) {
        vault.save("profile_$key", value.trim())
        logEvent("memory", "Profil: $key")
    }

    fun getProfileField(key: String): String? = vault.get("profile_$key")

    fun getProfileSummary(): String {
        val keys = listOf("prenom", "ville", "travail", "humeur", "projet", "preference_ton")
        val parts = keys.mapNotNull { k ->
            getProfileField(k)?.let { v -> if (v.isNotBlank()) "$k: $v" else null }
        }
        return parts.joinToString(". ")
    }

    fun rememberFact(fact: String) {
        val arr = JSONArray(prefs.getString("facts", "[]"))
        arr.put(JSONObject().put("t", System.currentTimeMillis()).put("f", fact.take(300)))
        // garde les 40 derniers
        val trimmed = JSONArray()
        val start = (arr.length() - 40).coerceAtLeast(0)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        prefs.edit().putString("facts", trimmed.toString()).apply()
        vault.save("fact_${System.currentTimeMillis()}", fact.take(300))
        logEvent("memory", "Fait: ${fact.take(80)}")
    }

    fun recentFacts(limit: Int = 8): List<String> {
        val arr = JSONArray(prefs.getString("facts", "[]"))
        val out = mutableListOf<String>()
        for (i in (arr.length() - 1) downTo 0) {
            if (out.size >= limit) break
            out.add(arr.getJSONObject(i).optString("f"))
        }
        return out
    }

    fun setMood(mood: String) {
        setProfileField("humeur", mood)
        prefs.edit().putLong("mood_ts", System.currentTimeMillis()).apply()
    }

    fun displayName(): String =
        getProfileField("prenom")?.takeIf { it.isNotBlank() } ?: ""

    fun profilePhotoFile(): File = File(c.filesDir, "profile_photo.jpg")

    fun hasProfilePhoto(): Boolean = profilePhotoFile().let { it.exists() && it.length() > 0 }

    fun saveProfilePhotoFromUri(uri: android.net.Uri): Boolean {
        return try {
            c.contentResolver.openInputStream(uri)?.use { input ->
                profilePhotoFile().outputStream().use { output -> input.copyTo(output) }
            }
            hasProfilePhoto()
        } catch (_: Exception) {
            false
        }
    }

    fun clearProfilePhoto() {
        try { profilePhotoFile().delete() } catch (_: Exception) {}
    }

    /** Contexte injecté dans le prompt IA — nom et profil réels uniquement */
    fun contextForAi(): String {
        if (PersonalityPrefs.isGuestMode(c)) return ""
        val sb = StringBuilder()
        val prenom = displayName()
        if (prenom.isNotBlank()) {
            sb.append("L'utilisateur s'appelle ").append(prenom).append(". ")
            sb.append("Adresse-toi à ").append(prenom).append(" par son prénom quand c'est naturel. ")
        }
        val profile = getProfileSummary().take(200)
        if (profile.isNotBlank()) sb.append("Profil: ").append(profile).append(". ")
        val facts = recentFacts(5)
        if (facts.isNotEmpty()) {
            sb.append("Faits: ").append(facts.joinToString(" | ") { it.take(80) })
        }
        return sb.toString().trim().take(450)
    }

    /** Historique de dialogue (multi-tours) pour le cerveau Llama. */
    fun addTurn(role: String, text: String) {
        if (PersonalityPrefs.isGuestMode(c)) return
        val arr = JSONArray(prefs.getString("dialog", "[]"))
        arr.put(
            JSONObject()
                .put("r", role.take(12))
                .put("t", text.take(220))
                .put("ts", System.currentTimeMillis())
        )
        // Conserve les 40 derniers tours en stockage (≈ 20 user + 20 assistant)
        val trimmed = JSONArray()
        val start = (arr.length() - 40).coerceAtLeast(0)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        prefs.edit().putString("dialog", trimmed.toString()).apply()
    }

    fun recentDialog(limit: Int = 20): String {
        if (PersonalityPrefs.isGuestMode(c)) return ""
        val arr = JSONArray(prefs.getString("dialog", "[]"))
        if (arr.length() == 0) return ""
        val sb = StringBuilder()
        val from = (arr.length() - limit).coerceAtLeast(0)
        for (i in from until arr.length()) {
            val o = arr.getJSONObject(i)
            val role = if (o.optString("r") == "user") "U" else "V"
            sb.append(role).append(": ").append(o.optString("t")).append('\n')
        }
        // Budget plus large pour injecter jusqu'à 20 tours dans le prompt
        return sb.toString().trim().take(1200)
    }

    fun clearDialog() {
        prefs.edit().remove("dialog").apply()
    }

    fun clearAll() {
        vault.clear()
        prefs.edit().clear().apply()
        logEvent("memory", "Mémoire effacée")
    }

    private fun logEvent(type: String, detail: String) {
        ActivityLog.add(c, type, detail)
    }
}
