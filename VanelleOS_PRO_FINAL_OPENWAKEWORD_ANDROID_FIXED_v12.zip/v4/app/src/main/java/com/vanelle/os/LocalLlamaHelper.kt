package com.vanelle.os

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.yield
import kotlin.coroutines.resume
import kotlin.jvm.functions.Function1
import kotlin.math.max
import kotlin.math.min

/**
 * Wrapper optimisé autour de llamacpp-kotlin (réflexion).
 *
 * Optimisations :
 * - Instance unique process-wide (un seul chargement du modèle)
 * - n_ctx adapté à la RAM (512–1536) au lieu de 2048 fixe
 * - Prompt système compact (moins de tokens de préfill)
 * - Contexte utilisateur tronqué
 * - Timeout adaptatif selon la taille de la requête
 * - warmUp() au démarrage de l'app
 * - Mutex pour sérialiser les inférences (un seul contexte natif)
 */
class LocalLlamaHelper private constructor(private val appContext: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val events = MutableSharedFlow<Any>(extraBufferCapacity = 512, replay = 0)

    @Volatile private var loaded = false
    @Volatile private var loading = false
    @Volatile private var helper: Any? = null
    @Volatile private var resolvedClass: Class<*>? = null
    private val answerMutex = Mutex()
    private val loadMutex = Mutex()

    private fun resolveLlamaClass(): Class<*>? {
        resolvedClass?.let { return it }
        val candidates = listOf(
            "org.nehuatl.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacppkotlin.LlamaHelper",
            "com.ljcamargo.llamacpp.LlamaHelper"
        )
        for (name in candidates) {
            try {
                val c = Class.forName(name)
                resolvedClass = c
                return c
            } catch (_: ClassNotFoundException) {}
        }
        return null
    }

    /** Fenêtre de contexte selon la mémoire disponible (moins de RAM → plus rapide / stable). */
    private fun optimalContextLength(): Int {
        return try {
            val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memMb = am.memoryClass
            when {
                memMb >= 512 -> 1536
                memMb >= 384 -> 1024
                memMb >= 256 -> 768
                else -> 512
            }
        } catch (_: Exception) {
            1024
        }
    }

    private suspend fun ensureLoaded(): Boolean {
        if (loaded && helper != null) return true
        if (!LlamaModelManager.isReady(appContext)) return false

        return loadMutex.withLock {
            if (loaded && helper != null) return@withLock true
            if (loading) {
                // Attente active bornée pendant un chargement concurrent
                repeat(90) {
                    kotlinx.coroutines.delay(200)
                    if (loaded && helper != null) return@withLock true
                    if (!loading) return@withLock (loaded && helper != null)
                }
                return@withLock false
            }
            loading = true
            try {
                val klass = resolveLlamaClass() ?: return@withLock false
                val ctor = klass.getConstructor(
                    android.content.ContentResolver::class.java,
                    CoroutineScope::class.java,
                    MutableSharedFlow::class.java
                )
                val h = ctor.newInstance(appContext.contentResolver, scope, events)
                val modelUri = Uri.fromFile(LlamaModelManager.modelFile(appContext)).toString()
                val nCtx = optimalContextLength()

                val loadMethod = klass.getMethod(
                    "load",
                    String::class.java,
                    Int::class.javaPrimitiveType,
                    String::class.java,
                    Function1::class.java
                )

                val ok = withTimeoutOrNull(120_000L) {
                    suspendCancellableCoroutine<Boolean> { cont ->
                        try {
                            val callback = object : Function1<Any?, Unit> {
                                override fun invoke(p1: Any?) {
                                    if (cont.isActive) cont.resume(true)
                                }
                            }
                            // n_ctx réduit = moins de KV-cache, préfill et decode plus rapides
                            loadMethod.invoke(h, modelUri, nCtx, null, callback)
                        } catch (_: Exception) {
                            if (cont.isActive) cont.resume(false)
                        }
                    }
                } ?: false

                if (ok) {
                    helper = h
                    loaded = true
                }
                ok
            } catch (_: Exception) {
                false
            } finally {
                loading = false
            }
        }
    }

    /** Précharge le modèle en arrière-plan (appelé depuis VanelleApp). */
    suspend fun warmUp(): Boolean = withContext(Dispatchers.IO) {
        if (!LlamaModelManager.isReady(appContext)) return@withContext false
        ensureLoaded()
    }

    fun isLoaded(): Boolean = loaded && helper != null

    /**
     * @param maxTokensHint limite soft côté collecteur (coupe tôt si réponse déjà longue)
     * @param fastMode prompt encore plus court + timeout réduit (commandes simples)
     */
    suspend fun answer(
        userPrompt: String,
        extraContext: String = "",
        fastMode: Boolean = false,
        maxTokensHint: Int = if (fastMode) 120 else 220
    ): String = answerMutex.withLock {
        if (!ensureLoaded()) return@withLock NOT_READY
        val h = helper ?: return@withLock NOT_READY
        val klass = h.javaClass

        val formatted = buildPrompt(userPrompt, extraContext, fastMode)
        val timeoutMs = adaptiveTimeoutMs(formatted.length, fastMode)

        return@withLock try {
            val predictMethod = try {
                klass.getMethod("predict", String::class.java, String::class.java)
            } catch (_: NoSuchMethodException) {
                try {
                    klass.getMethod("predict", String::class.java)
                } catch (_: NoSuchMethodException) {
                    null
                }
            } ?: return@withLock NOT_READY

            withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<String> { cont ->
                    val job = scope.launch {
                        try {
                            val sb = StringBuilder(maxTokensHint * 4)
                            var tokenApprox = 0

                            val collector = launch {
                                events.takeWhile { event ->
                                    when (event.javaClass.simpleName) {
                                        "Ongoing" -> {
                                            val word = try {
                                                (event.javaClass.getMethod("getWord").invoke(event) as? String).orEmpty()
                                            } catch (_: Exception) {
                                                try {
                                                    // certains builds exposent "token" / champ text
                                                    (event.javaClass.getMethod("getToken").invoke(event) as? String).orEmpty()
                                                } catch (_: Exception) { "" }
                                            }
                                            if (word.isNotEmpty()) {
                                                sb.append(word)
                                                tokenApprox++
                                            }
                                            // Coupe tôt : réponse déjà assez longue pour une UI vocale
                                            tokenApprox < maxTokensHint && sb.length < maxTokensHint * 6
                                        }
                                        "Done", "Error" -> false
                                        "Started" -> true
                                        else -> true
                                    }
                                }.collect { }
                            }

                            yield()
                            when (predictMethod.parameterTypes.size) {
                                2 -> predictMethod.invoke(h, formatted, null)
                                else -> predictMethod.invoke(h, formatted)
                            }
                            collector.join()

                            val text = sb.toString().trim()
                                .removePrefix("assistant")
                                .trim()
                            if (cont.isActive) {
                                cont.resume(text.ifBlank { NOT_READY })
                            }
                        } catch (_: Exception) {
                            if (cont.isActive) cont.resume(NOT_READY)
                        }
                    }
                    cont.invokeOnCancellation { job.cancel() }
                }
            } ?: NOT_READY
        } catch (_: Exception) {
            NOT_READY
        }
    }

    private fun buildPrompt(userPrompt: String, extraContext: String, fastMode: Boolean): String {
        val system = if (fastMode) {
            "Tu es Vanelle, assistante vocale réelle sur Android. Français, 1-2 phrases, naturel. " +
                "Utilise le prénom de l'utilisateur s'il est dans le contexte. " +
                "Aucune réponse inventée ou d'exemple. Si action téléphone : ligne ACTION:TYPE|arg."
        } else {
            "Tu es Vanelle, assistante réelle sur le téléphone. Français naturel, 1-3 phrases. " +
                "Tu comprends les intentions, tu analyses, tu te souviens du contexte fourni. " +
                "Si le prénom de l'utilisateur est dans le contexte, utilise-le quand c'est naturel. " +
                "Ne simule rien, ne donne pas d'exemples fictifs, base-toi sur le contexte et la demande. " +
                "Pour une action téléphone, mets EN PREMIER: " +
                "ACTION:YOUTUBE|requête ou ACTION:OPEN_APP|nom ou ACTION:CALL|nom ou " +
                "ACTION:MESSAGE|nom|texte ou ACTION:SEARCH|requête ou ACTION:MAPS|lieu ou " +
                "ACTION:TIMER|minutes ou ACTION:FLASHLIGHT|on/off ou ACTION:VOLUME|up/down. " +
                "Sinon réponds normalement sans ligne ACTION."
        }
        val ctx = extraContext.trim().take(if (fastMode) 400 else 1400)
        val user = userPrompt.trim().take(if (fastMode) 320 else 560)

        return buildString(capacity = 2200) {
            append("<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n")
            append(system)
            if (ctx.isNotBlank()) {
                append("\nContexte: ")
                append(ctx)
            }
            append("\n<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n")
            append(user)
            append("\n<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n")
        }
    }

    private fun adaptiveTimeoutMs(promptChars: Int, fastMode: Boolean): Long {
        // Prefill ≈ proportionnel à la taille du prompt ; decode borné par maxTokensHint
        val base = if (fastMode) 18_000L else 35_000L
        val extra = (promptChars / 4).toLong() // ~ms grossier
        return min(75_000L, max(base, base + extra))
    }

    companion object {
        const val NOT_READY = "__LLAMA_NOT_READY__"

        @Volatile private var instance: LocalLlamaHelper? = null

        fun get(context: Context): LocalLlamaHelper {
            instance?.let { return it }
            synchronized(this) {
                instance?.let { return it }
                val created = LocalLlamaHelper(context.applicationContext)
                instance = created
                return created
            }
        }
    }
}
