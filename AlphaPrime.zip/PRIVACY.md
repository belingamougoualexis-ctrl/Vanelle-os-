# Politique de confidentialité — Alpha Prime

> **Statut de ce document : gabarit technique, pas un texte juridique validé.**
> Je (l'assistant qui a généré ce projet) ne suis pas juriste et je ne peux pas
> délivrer une politique de confidentialité juridiquement opposable. Ce fichier
> décrit honnêtement ce que le logiciel fait réellement (vérifié dans le code),
> avec les sections qu'un texte légal (RGPD / Loi 25 au Québec / etc.)
> contiendrait généralement, en clair-marqué [À COMPLÉTER] là où seule une
> personne qualifiée (toi, ou un avocat) peut trancher. Aucune automatisation
> ne peut remplacer cette validation — je te le dis directement plutôt que de
> prétendre le contraire.

## 1. Responsable du traitement

- Nom / organisation : **Alpha Prime**
- Contact : **[À COMPLÉTER — email]**
- Juridiction principale : **[À COMPLÉTER — ex. Québec/Canada, France/UE...]**

## 2. Ce que le logiciel fait réellement avec les données (vérifié dans le code)

- **Aucun serveur central.** Alpha Prime lance un serveur HTTP local (`127.0.0.1`) sur la machine de l'utilisateur. Il n'est pas exposé sur Internet par défaut.
- **Aucune télémétrie.** Le code ne contient aucun appel réseau vers un service tiers d'analytics ou de collecte de données.
- **Stockage 100 % local.** Toutes les données (base SQLite, datasets, modèles, checkpoints, artefacts, logs) sont écrites dans le dossier `workspace/` choisi par l'utilisateur, sur son disque.
- **Pas d'envoi automatique.** Aucune donnée du workspace n'est transmise à un tiers sans action explicite de l'utilisateur (ex. export manuel, activation volontaire d'un provider externe).
- **Modules externes optionnels et désactivés par défaut.** LLM distant, providers cloud : existent comme interfaces mais restent `UNAVAILABLE` tant qu'ils ne sont pas configurés explicitement (clé API, endpoint) par l'utilisateur.
- **États honnêtes.** Chaque donnée affichée porte un statut `REAL`, `ESTIMATED`, `PROPOSED`, `UNAVAILABLE`, `SIMULATED (TEST)` ou `FAILED`.

## 3. Données traitées (si l'app est utilisée avec des données de tiers/clients)

**[À COMPLÉTER]** — liste les catégories réelles selon ton usage : ex. datasets clients importés, identifiants de compte utilisateur, logs d'activité. Le code ne collecte rien de plus que ce que l'utilisateur importe volontairement dans son workspace.

## 4. Finalités

**[À COMPLÉTER]** — ex. entraînement de modèles pour le compte du client, expérimentation interne.

## 5. Durée de conservation

**[À COMPLÉTER]** — techniquement les données restent dans `workspace/` tant que l'utilisateur ne les supprime pas ; aucune purge automatique n'existe dans le code actuel.

## 6. Droits des personnes concernées (si applicable — RGPD/Loi 25)

**[À COMPLÉTER]** — droit d'accès, de rectification, de suppression, de portabilité. Techniquement : les données étant en local dans SQLite/fichiers, l'export (`export_import.py`) et la suppression manuelle du workspace couvrent l'aspect technique ; le processus pour répondre à une demande doit être défini par toi.

## 7. Sécurité

- Chiffrement au repos : **non implémenté par défaut** — à ajouter si des données sensibles sont stockées (voir recommandations).
- Contrôle d'accès : authentification/rôles multi-utilisateurs — voir l'état réel du module correspondant dans le code avant d'en garantir l'existence à des tiers.

## 8. Recommandations avant distribution à des clients/utilisateurs finaux

- Faire valider ce texte par un professionnel du droit, dans ta juridiction.
- Ajouter un chiffrement au repos du dossier `workspace/` si des données sensibles y sont stockées.
- Documenter précisément, pour chaque module optionnel (LLM distant, cloud), quelles données quittent la machine si l'utilisateur l'active.
- Vérifier la couverture réelle du journal d'audit (`ai_training_os/audit.py`) sur tous les points de sortie de données.
