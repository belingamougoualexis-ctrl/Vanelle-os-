#!/bin/sh
set -eu
python3 run_server.py --workspace "${AITOS_WORKSPACE:-./workspace}" --port "${AITOS_PORT:-8787}"
