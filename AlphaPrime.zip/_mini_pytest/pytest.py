"""
Mini implémentation locale d'une API compatible avec le sous-ensemble de
pytest utilisé par nos tests (fixtures simples, pytest.raises).

Pourquoi ce fichier existe : pytest n'est pas installé dans cet
environnement et aucun accès réseau sortant n'est disponible pour
l'installer (voir compute.detect_network -> UNAVAILABLE, réel, vérifié).
Plutôt que de sauter les tests ou d'affirmer faussement qu'ils passent,
on exécute réellement le même code de test via ce harnais minimal.
"""
import contextlib


class _Raises:
    def __init__(self, exc_type):
        self.exc_type = exc_type
        self.raised = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            raise AssertionError(f"Attendu une exception {self.exc_type}, aucune levée.")
        if not issubclass(exc_type, self.exc_type):
            return False
        self.raised = exc_val
        return True


def raises(exc_type):
    return _Raises(exc_type)


_FIXTURES = {}


def fixture(func=None):
    def wrap(f):
        _FIXTURES[f.__name__] = f
        return f
    if func is not None:
        return wrap(func)
    return wrap


def get_fixture(name):
    return _FIXTURES.get(name)
