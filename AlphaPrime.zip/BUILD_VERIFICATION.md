# AI Training OS 0.4.0 — Vérification de build

Cette archive est la distribution source locale de production vérifiée dans l'environnement de construction.

## Vérifications réalisées

- Tests projet : 52 PASS / 0 FAIL.
- Parcours E2E local tabulaire CPU : exécuté réellement sur un workspace temporaire.
- Compilation Python : vérifiée.
- JavaScript du dashboard : vérifié avec `node --check`.
- Dashboard : structure locale, navigation, modes Simple/Expert, responsive mobile, thème clair/sombre et stockage local tolérant aux navigateurs sans `localStorage` vérifiés statiquement.
- Distribution : aucun dataset, modèle, checkpoint, expérience, métrique ou déploiement de démonstration n'est inclus dans le workspace de production.

## Capacités non considérées comme disponibles par défaut

- GPU CUDA/MPS : dépend du matériel et des bibliothèques présents chez l'utilisateur.
- Local LLM : nécessite un backend local réellement installé et un modèle réellement présent.
- Parquet : nécessite `pyarrow` ou `fastparquet`.
- Exécution de code utilisateur non sandboxée : volontairement indisponible.
- Cloud / remote GPU / distributed : interfaces d'extension uniquement.

Les états affichés par l'application suivent les règles REAL / ESTIMATED / PROPOSED / UNAVAILABLE / FAILED / SIMULATED (TEST).
