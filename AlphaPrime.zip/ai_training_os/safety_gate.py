from . import utils


class SafetyGate:
    """
    Avant tout passage en statut VALIDATED/DEPLOYED, exécute réellement
    les vérifications disponibles localement. Une vérification qui ne
    peut pas être exécutée est marquée None (ni pass ni fail inventés).
    """
    def __init__(self, conn, audit=None):
        self.conn = conn
        self.audit = audit

    def review(self, model_version_id: str, metrics: dict, min_accuracy: float = 0.5,
               known_dependencies_ok: bool = True, regression_baseline: dict = None,
               security_policy: dict = None):
        model=self.conn.execute("SELECT * FROM model_versions WHERE id=?",(model_version_id,)).fetchone()
        if not model: raise ValueError("Version de modèle introuvable")
        model=dict(model); quality_pass=True
        if "accuracy" in (metrics or {}): quality_pass=float(metrics.get("accuracy",0))>=float(min_accuracy)
        elif not metrics: quality_pass=False
        regression_pass=True if regression_baseline is None else all(float(metrics.get(k, float("-inf")))>=float(v) for k,v in regression_baseline.items())
        data_pass=False; data_note="Dataset associé non vérifiable."
        if model.get("dataset_version_id"):
            dv=self.conn.execute("SELECT * FROM dataset_versions WHERE id=?",(model["dataset_version_id"],)).fetchone()
            if dv:
                dv=dict(dv)
                try: data_pass=utils.sha256_file(dv["file_path"])==dv["sha256"]; data_note="Hash du dataset versionné vérifié." if data_pass else "Hash du dataset invalide."
                except OSError: data_pass=False; data_note="Fichier dataset absent."
        eval_row=self.conn.execute("SELECT id,status FROM evaluations WHERE model_version_id=? ORDER BY created_at DESC LIMIT 1",(model_version_id,)).fetchone()
        evaluation_pass=bool(eval_row and eval_row["status"] in ("COMPLETED","VALIDATED"))
        red=self.conn.execute("SELECT status,summary_json FROM red_team_runs WHERE model_version_id=? ORDER BY created_at DESC LIMIT 1",(model_version_id,)).fetchone()
        security_pass=None; security_note="Red Team non exécuté."
        if red:
            try: summary=utils.loads(red["summary_json"] or "{}")
            except Exception: summary={}
            if red["status"]=="COMPLETED":
                policy=security_policy or {}
                limit=policy.get("max_prediction_flip_rate")
                if limit is None:
                    security_pass=None
                    security_note="Red Team réel exécuté; aucune politique de seuil explicite n'est fournie, donc validation PENDING."
                else:
                    security_pass=float(summary.get("prediction_flip_rate",1.0))<=float(limit)
                    security_note="Red Team réel comparé à la politique de sécurité explicite."
            else: security_pass=False; security_note=f"Dernier Red Team: {red["status"]}."
        dependencies_pass=bool(known_dependencies_ok)
        provenance_pass=bool(model.get("code_version") and model.get("configuration_json") and model.get("hardware_json"))
        regression_note="Aucune baseline fournie : comparaison de régression non applicable pour cette revue." if regression_baseline is None else "Comparaison à la baseline réellement fournie."
        checks={"quality_pass":quality_pass,"security_pass":security_pass,"regression_pass":regression_pass,"data_pass":data_pass,"dependencies_pass":dependencies_pass,"evaluation_pass":evaluation_pass,"provenance_pass":provenance_pass}
        missing=[k for k,v in checks.items() if v is None]
        if missing or any(v is False for v in checks.values()): final_status="PENDING" if missing and not any(v is False for v in checks.values()) else ("REJECTED" if any(v is False for v in checks.values()) else "PENDING")
        else: final_status="APPROVED"
        review_id=utils.new_id("safety")
        details={"checks":checks,"notes":{"data":data_note,"security":security_note,"regression":regression_note},"metrics":metrics,"policy":security_policy or {}}
        self.conn.execute("INSERT INTO safety_gate_reviews (id,model_version_id,quality_pass,security_pass,regression_pass,data_pass,dependencies_pass,final_status,details_json,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",(review_id,model_version_id,int(quality_pass),None if security_pass is None else int(security_pass),None if regression_pass is None else int(regression_pass),int(data_pass),int(dependencies_pass),final_status,utils.dumps(details),utils.now_iso()))
        self.conn.commit()
        if final_status=="APPROVED": self.conn.execute("UPDATE model_versions SET status='VALIDATED' WHERE id=?",(model_version_id,)); self.conn.commit()
        if self.audit:self.audit.log("system","SAFETY_GATE_REVIEW","model_version",model_version_id,checks)
        return {"review_id":review_id,"checks":checks,"final_status":final_status,"details":details}

