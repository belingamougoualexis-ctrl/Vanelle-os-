"""Compute Engine: measured local hardware only."""
import os, platform, shutil, subprocess, tempfile, json

def detect_cpu():
    try: cores=os.cpu_count() or 1
    except Exception as e: return {"status":"UNAVAILABLE","reason":str(e)}
    try: arch=platform.machine()
    except Exception: arch="unknown"
    return {"status":"REAL","logical_cores":cores,"architecture":arch,"processor":platform.processor() or "unknown","os":platform.system()+" "+platform.release()}

def detect_ram():
    try:
        with open("/proc/meminfo") as f: info={k.strip():v.strip() for k,v in (line.split(":",1) for line in f if ":" in line)}
        total_kb=int(info.get("MemTotal","0 kB").split()[0]); avail_kb=int(info.get("MemAvailable","0 kB").split()[0])
        return {"status":"REAL","total_mb":round(total_kb/1024,1),"available_mb":round(avail_kb/1024,1)}
    except Exception:
        try:
            import psutil
            return {"status":"REAL","total_mb":round(psutil.virtual_memory().total/1024/1024,1),"available_mb":round(psutil.virtual_memory().available/1024/1024,1)}
        except Exception as e: return {"status":"UNAVAILABLE","reason":str(e)}

def detect_gpu():
    gpus=[]
    # PyTorch is the source of truth when installed because it can expose CUDA/MPS devices even without nvidia-smi.
    try:
        import torch
        if torch.cuda.is_available():
            for i in range(torch.cuda.device_count()):
                props=torch.cuda.get_device_properties(i)
                gpus.append({"index":i,"name":torch.cuda.get_device_name(i),"backend":"CUDA","vram_mb":round(props.total_memory/1024/1024,1)})
            return {"status":"REAL","backend":"CUDA","n_gpus":len(gpus),"gpus":gpus}
        if getattr(torch.backends,"mps",None) is not None and torch.backends.mps.is_available():
            return {"status":"REAL","backend":"MPS","n_gpus":1,"gpus":[{"index":0,"name":"Apple GPU (MPS)","backend":"MPS","vram_mb":None}]}
    except Exception: pass
    path=shutil.which("nvidia-smi")
    if path:
        try:
            out=subprocess.run([path,"--query-gpu=index,name,memory.total","--format=csv,noheader,nounits"],capture_output=True,text=True,timeout=5)
            if out.returncode==0 and out.stdout.strip():
                for line in out.stdout.strip().splitlines():
                    parts=[p.strip() for p in line.split(",")]; gpus.append({"index":int(parts[0]),"name":parts[1],"backend":"NVIDIA-SMI","vram_mb":float(parts[2])})
                return {"status":"REAL","backend":"NVIDIA-SMI","n_gpus":len(gpus),"gpus":gpus}
        except Exception: pass
    return {"status":"UNAVAILABLE","reason":"Aucun accélérateur GPU local détecté par les backends disponibles (CUDA/MPS/nvidia-smi)."}

def detect_accelerators():
    try:
        import torch
        out={"torch_version":torch.__version__,"cuda_available":bool(torch.cuda.is_available()),"cuda_device_count":int(torch.cuda.device_count()) if torch.cuda.is_available() else 0,"mps_available":bool(getattr(torch.backends,"mps",None) and torch.backends.mps.is_available())}
        return {"status":"REAL","backend":out}
    except Exception as e:return {"status":"UNAVAILABLE","reason":str(e)}

def detect_disk(path="."):
    try:
        total,used,free=shutil.disk_usage(path); return {"status":"REAL","total_gb":round(total/1024**3,2),"used_gb":round(used/1024**3,2),"free_gb":round(free/1024**3,2),"path":os.path.abspath(path)}
    except Exception as e:return {"status":"UNAVAILABLE","reason":str(e)}

def detect_temp_disk():
    return detect_disk(tempfile.gettempdir())

def detect_network():
    import socket
    s=None
    try:
        s=socket.create_connection(("1.1.1.1",53),timeout=1.0); return {"status":"REAL","outbound_network":True}
    except Exception as e:return {"status":"UNAVAILABLE","outbound_network":False,"reason":str(e)}
    finally:
        if s: s.close()

def detect_torch_backend():
    g=detect_gpu()
    if g["status"]!="REAL": return {"status":"UNAVAILABLE","reason":g["reason"]}
    return {"status":"REAL","backend":g.get("backend"),"n_devices":g.get("n_gpus"),"device_names":[x.get("name") for x in g.get("gpus",[])]}

def full_report(workspace="."):
    return {"status":"REAL","cpu":detect_cpu(),"ram":detect_ram(),"gpu":detect_gpu(),"accelerators":detect_accelerators(),"disk":detect_disk(workspace),"temp_disk":detect_temp_disk(),"network":detect_network()}


class ComputeEngine:
    """Facade publique du Compute Engine local, sans cache ni valeur fictive."""
    def cpu(self): return detect_cpu()
    def ram(self): return detect_ram()
    def gpu(self): return detect_gpu()
    def accelerators(self): return detect_accelerators()
    def disk(self, path="."): return detect_disk(path)
    def temp_disk(self): return detect_temp_disk()
    def network(self): return detect_network()
    def full_report(self, workspace="."): return full_report(workspace)
