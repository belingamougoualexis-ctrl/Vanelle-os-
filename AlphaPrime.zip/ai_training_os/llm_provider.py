"""LOCAL_LLM_PROVIDER with managed llama.cpp runtime support."""
from __future__ import annotations
import glob
import json
import os
import socket
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path


class LLMBackend:
    name = "BASE"
    def detect(self) -> dict: raise NotImplementedError
    def complete(self, system: str, prompt: str, max_tokens: int = 512, model: str = None) -> dict: raise NotImplementedError


class OllamaBackend(LLMBackend):
    name = "OLLAMA_LOCAL"
    HOST = "127.0.0.1"; PORT = 11434
    def _reachable(self):
        try:
            with socket.create_connection((self.HOST,self.PORT),timeout=.5): return True
        except OSError: return False
    def detect(self):
        if not self._reachable(): return {"available":False,"reason":f"Aucun démon Ollama local détecté sur {self.HOST}:{self.PORT}.","models":[]}
        try:
            req=urllib.request.Request(f"http://{self.HOST}:{self.PORT}/api/tags")
            with urllib.request.urlopen(req,timeout=1.5) as resp: data=json.loads(resp.read().decode())
            models=[m.get("name") for m in data.get("models",[]) if m.get("name")]
            return {"available":bool(models),"reason":"Ollama local actif." if models else "Ollama actif sans modèle.","models":models}
        except Exception as e: return {"available":False,"reason":f"Ollama local injoignable : {e}","models":[]}
    def complete(self,system,prompt,max_tokens=512,model=None):
        info=self.detect()
        if not info["available"]: raise RuntimeError(f"LLM REQUIRED — {info['reason']}")
        model=model or info["models"][0]
        body=json.dumps({"model":model,"prompt":prompt,"system":system,"stream":False}).encode()
        req=urllib.request.Request(f"http://{self.HOST}:{self.PORT}/api/generate",data=body,headers={"Content-Type":"application/json"},method="POST")
        with urllib.request.urlopen(req,timeout=300) as resp: data=json.loads(resp.read().decode())
        return {"text":data.get("response",""),"model":model,"backend":self.name,"tokens":data.get("eval_count")}


class ManagedLlamaServerBackend(LLMBackend):
    name = "MANAGED_LLAMA_CPP_LOCAL"
    HOST = "127.0.0.1"; PORT = 18178
    def __init__(self, models_dir, startup_manager):
        self.models_dir=models_dir; self.startup_manager=startup_manager; self._process=None; self._model=None
    def _model_files(self):
        return sorted(glob.glob(os.path.join(self.models_dir,"*.gguf")))
    def _healthy(self):
        try:
            req=urllib.request.Request(f"http://{self.HOST}:{self.PORT}/health")
            with urllib.request.urlopen(req,timeout=.8) as r: return r.status == 200
        except Exception: return False
    def detect(self):
        binary=self.startup_manager.runtime_binary(); models=self._model_files()
        valid=[]
        for f in models:
            try:
                with open(f,"rb") as h:
                    if h.read(4)==b"GGUF": valid.append(os.path.basename(f))
            except OSError: pass
        if not binary: return {"available":False,"reason":"Runtime llama.cpp local non installé. Ouvrir Installation locale pour le télécharger.","models":[]}
        if not valid: return {"available":False,"reason":"Runtime llama.cpp installé mais aucun GGUF local vérifié.","models":[]}
        return {"available":True,"reason":"Runtime llama.cpp et modèle GGUF locaux détectés.","models":valid,"binary":binary}
    def _start(self, model):
        if self._healthy() and self._model==model: return
        if self._process and self._process.poll() is None and self._model != model:
            self._process.terminate()
            try: self._process.wait(timeout=5)
            except subprocess.TimeoutExpired: self._process.kill()
        binary=self.startup_manager.runtime_binary()
        path=os.path.join(self.models_dir,model)
        if not binary or not os.path.isfile(path): raise RuntimeError("Runtime ou modèle local indisponible.")
        cmd=[binary,"-m",path,"--host",self.HOST,"--port",str(self.PORT),"-c","2048","-ngl","0"]
        self._process=subprocess.Popen(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        self._model=model
        deadline=time.time()+120
        while time.time()<deadline:
            if self._healthy(): return
            if self._process.poll() is not None: raise RuntimeError(f"llama-server s'est arrêté avec le code {self._process.returncode}.")
            time.sleep(.5)
        raise RuntimeError("llama-server n'est pas devenu prêt après 120 secondes.")
    def complete(self,system,prompt,max_tokens=512,model=None):
        info=self.detect()
        if not info["available"]: raise RuntimeError(f"LLM REQUIRED — {info['reason']}")
        model=model or info["models"][0]
        if model not in info["models"]: raise RuntimeError(f"Modèle GGUF local indisponible: {model}")
        self._start(model)
        body=json.dumps({"model":model,"messages":[{"role":"system","content":system},{"role":"user","content":prompt}],"max_tokens":max_tokens,"stream":False}).encode()
        req=urllib.request.Request(f"http://{self.HOST}:{self.PORT}/v1/chat/completions",data=body,headers={"Content-Type":"application/json"},method="POST")
        with urllib.request.urlopen(req,timeout=300) as resp: data=json.loads(resp.read().decode())
        text=data["choices"][0]["message"]["content"]
        return {"text":text,"model":model,"backend":self.name,"tokens":data.get("usage",{}).get("total_tokens")}


class LlamaCppBackend(LLMBackend):
    name="LLAMA_CPP_GGUF"
    def __init__(self,models_dir): self.models_dir=models_dir
    def _gguf_files(self): os.makedirs(self.models_dir,exist_ok=True); return sorted(glob.glob(os.path.join(self.models_dir,"*.gguf")))
    def detect(self):
        os.makedirs(self.models_dir, exist_ok=True)
        try: import llama_cpp
        except ImportError: return {"available":False,"reason":"Le paquet llama-cpp-python n'est pas installé.","models":[]}
        models=[]
        for f in self._gguf_files():
            try:
                with open(f,"rb") as h:
                    if h.read(4)==b"GGUF": models.append(os.path.basename(f))
            except OSError: pass
        return {"available":bool(models),"reason":"GGUF local détecté via llama-cpp-python.","models":models}
    def complete(self,system,prompt,max_tokens=512,model=None):
        info=self.detect()
        if not info["available"]: raise RuntimeError(f"LLM REQUIRED — {info['reason']}")
        from llama_cpp import Llama
        selected=model or info["models"][0]
        llm=Llama(model_path=os.path.join(self.models_dir,selected),n_ctx=2048,verbose=False)
        out=llm.create_chat_completion(messages=[{"role":"system","content":system},{"role":"user","content":prompt}],max_tokens=max_tokens)
        return {"text":out["choices"][0]["message"]["content"],"model":selected,"backend":self.name,"tokens":out.get("usage",{}).get("total_tokens")}


class TransformersLocalBackend(LLMBackend):
    name="TRANSFORMERS_LOCAL_DIR"
    def __init__(self,models_dir): self.models_dir=models_dir
    def _dirs(self):
        os.makedirs(self.models_dir,exist_ok=True)
        return sorted([e.path for e in os.scandir(self.models_dir) if e.is_dir() and os.path.exists(os.path.join(e.path,"config.json"))])
    def detect(self):
        try: import transformers
        except ImportError: return {"available":False,"reason":"Le paquet transformers n'est pas installé.","models":[]}
        dirs=[]
        for d in self._dirs():
            names={e.name for e in os.scandir(d)}
            if names.intersection({"model.safetensors","pytorch_model.bin","model.safetensors.index.json"}): dirs.append(os.path.basename(d))
        return {"available":bool(dirs),"reason":"Modèle Transformers local détecté.","models":dirs}
    def complete(self,system,prompt,max_tokens=512,model=None):
        info=self.detect()
        if not info["available"]: raise RuntimeError(f"LLM REQUIRED — {info['reason']}")
        from transformers import pipeline
        selected=model or info["models"][0]; path=os.path.join(self.models_dir,selected)
        pipe=pipeline("text-generation",model=path,tokenizer=path,local_files_only=True)
        out=pipe(f"{system}\n\n{prompt}",max_new_tokens=max_tokens)
        return {"text":out[0]["generated_text"],"model":selected,"backend":self.name,"tokens":None}


class LocalLLMProvider:
    def __init__(self,base_dir:str,startup_manager=None):
        self.models_dir=os.path.join(base_dir,"llm_models"); os.makedirs(self.models_dir,exist_ok=True)
        self.selection_path=os.path.join(self.models_dir,".selected_model.json")
        self.selected_model=None; self.selected_backend=None
        self.startup_manager=startup_manager
        self._load_selection()
        self.backends=[]
        if startup_manager: self.backends.append(ManagedLlamaServerBackend(self.models_dir,startup_manager))
        self.backends += [OllamaBackend(),LlamaCppBackend(self.models_dir),TransformersLocalBackend(self.models_dir)]
    def _load_selection(self):
        try:
            d=json.loads(Path(self.selection_path).read_text()); self.selected_model=d.get("model"); self.selected_backend=d.get("backend")
        except (OSError,json.JSONDecodeError): self.selected_model=None; self.selected_backend=None
    def _save_selection(self):
        tmp=self.selection_path+".tmp"; Path(tmp).write_text(json.dumps({"model":self.selected_model,"backend":self.selected_backend},ensure_ascii=False,indent=2)); os.replace(tmp,self.selection_path)
    def status(self):
        checks={b.name:b.detect() for b in self.backends}; active=next((n for n,i in checks.items() if i["available"]),None)
        if self.selected_model and not (self.selected_backend in checks and self.selected_model in checks[self.selected_backend].get("models",[])):
            self.selected_model=None; self.selected_backend=None; self._save_selection()
        return {"status":"READY" if active else "LLM REQUIRED","active_backend":active,"selected_backend":self.selected_backend,"selected_model":self.selected_model,"selection_persisted":os.path.isfile(self.selection_path),"backends":checks,"message":"Aucun modèle de langage local compatible n'est actuellement disponible. Utilisez Installation locale pour télécharger le runtime et le modèle." if not active else "LLM local détecté; la sélection/inférence utilise le backend local réel."}
    def available_models(self):
        st=self.status(); return [{"backend":n,"model":m,"selected":n==st.get("selected_backend") and m==st.get("selected_model")} for n,i in st["backends"].items() for m in i.get("models",[])]
    def _find_backend(self,model,backend_name=None):
        for b in self.backends:
            if backend_name and b.name!=backend_name: continue
            i=b.detect()
            if i["available"] and model in i.get("models",[]): return b,i
        return None,None
    def verify_model(self,model,backend=None):
        b,info=self._find_backend(model,backend)
        if not b: return {"status":"UNAVAILABLE","model":model,"backend":backend,"reason":"Modèle local introuvable ou backend indisponible."}
        try:
            if isinstance(b,OllamaBackend):
                body=json.dumps({"model":model}).encode(); req=urllib.request.Request(f"http://{b.HOST}:{b.PORT}/api/show",data=body,headers={"Content-Type":"application/json"},method="POST")
                with urllib.request.urlopen(req,timeout=15): pass
                return {"status":"REAL","verified":True,"model":model,"backend":b.name}
            # A real completion is the strongest verification for managed runtime.
            if isinstance(b,ManagedLlamaServerBackend):
                r=b.complete("You are a local verification process. Return only OK.","Reply with OK.",max_tokens=4,model=model)
                return {"status":"REAL","verified":r.get("text","").strip()!="","model":model,"backend":b.name,"probe":r.get("text","")}
            if isinstance(b,LlamaCppBackend):
                from llama_cpp import Llama; Llama(model_path=os.path.join(b.models_dir,model),n_ctx=128,verbose=False)
            elif isinstance(b,TransformersLocalBackend):
                from transformers import AutoTokenizer,AutoModelForCausalLM
                p=os.path.join(b.models_dir,model); AutoTokenizer.from_pretrained(p,local_files_only=True); AutoModelForCausalLM.from_pretrained(p,local_files_only=True)
            return {"status":"REAL","verified":True,"model":model,"backend":b.name}
        except Exception as exc: return {"status":"FAILED","verified":False,"model":model,"backend":b.name,"reason":str(exc)}
    def set_model(self,model,backend=None):
        v=self.verify_model(model,backend)
        if v["status"]!="REAL": return v
        self.selected_model=model; self.selected_backend=v["backend"]; self._save_selection(); return {"status":"REAL","selected_model":model,"selected_backend":self.selected_backend,"verified":True}
    def is_available(self): return self.status()["status"]=="READY"
    def complete(self,system,prompt,max_tokens=512,model=None):
        st=self.status()
        if st["status"]!="READY": raise RuntimeError(f"LLM REQUIRED — {st['message']}")
        chosen=model or st.get("selected_model"); backend,_=self._find_backend(chosen,st.get("selected_backend")) if chosen else (None,None)
        if backend is None:
            backend=next(b for b in self.backends if b.name==st["active_backend"]); chosen=None
        return backend.complete(system,prompt,max_tokens,chosen)
