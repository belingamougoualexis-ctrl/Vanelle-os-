from .local_cpu import LocalCPUProvider
from .local_gpu import LocalGPUProvider
from .local_multi_gpu import LocalMultiGPUProvider
from .base import UnavailableProvider

PROVIDER_REGISTRY = {
    "LOCAL_CPU_PROVIDER": LocalCPUProvider(),
    # Réellement adaptatifs : is_available() revérifie le matériel de LA
    # machine locale à chaque appel. Pas de stub figé — sur une machine
    # utilisateur avec GPU + PyTorch, ces deux providers s'activent seuls.
    "LOCAL_GPU_PROVIDER": LocalGPUProvider(),
    "LOCAL_MULTI_GPU_PROVIDER": LocalMultiGPUProvider(),
    "REMOTE_GPU_PROVIDER": UnavailableProvider(
        "REMOTE_GPU_PROVIDER",
        "Aucun accès réseau sortant dans cet environnement. "
        "Nécessite la configuration d'un endpoint distant (host, clé API, credentials).",
    ),
    "DISTRIBUTED_PROVIDER": UnavailableProvider(
        "DISTRIBUTED_PROVIDER",
        "Nécessite plusieurs nœuds réellement connectés en réseau (non disponible ici).",
    ),
    "CLOUD_PROVIDER": UnavailableProvider(
        "CLOUD_PROVIDER",
        "Nécessite des identifiants cloud (AWS/GCP/Azure) et un accès réseau sortant, absents ici.",
    ),
}


def get_provider(name: str):
    if name not in PROVIDER_REGISTRY:
        raise KeyError(f"Provider inconnu: {name}")
    return PROVIDER_REGISTRY[name]


def list_providers():
    return {name: p.is_available() for name, p in PROVIDER_REGISTRY.items()}
