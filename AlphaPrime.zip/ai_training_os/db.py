"""
db.py — Couche de persistance réelle (SQLite).

Aucune donnée n'est préremplie. Au premier lancement, toutes les tables
sont vides. C'est la seule source de vérité de l'application.
"""
import sqlite3
import os
import threading

DB_LOCK = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    created_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE'
);

CREATE TABLE IF NOT EXISTS ai_missions (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    raw_request TEXT NOT NULL,
    objective TEXT,
    problem_type TEXT,
    data_type TEXT,
    model_strategy TEXT,
    training_strategy TEXT,
    metrics_json TEXT,
    risks_json TEXT,
    success_criteria_json TEXT,
    training_plan_json TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY(project_id) REFERENCES projects(id)
);

CREATE TABLE IF NOT EXISTS datasets (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    name TEXT NOT NULL,
    origin_path TEXT NOT NULL,
    license TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS dataset_versions (
    id TEXT PRIMARY KEY,
    dataset_id TEXT NOT NULL,
    version_number INTEGER NOT NULL,
    file_path TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    n_rows INTEGER NOT NULL,
    n_cols INTEGER NOT NULL,
    n_duplicates_removed INTEGER NOT NULL,
    n_missing_values INTEGER NOT NULL,
    n_corrupted_rows INTEGER NOT NULL,
    class_balance_json TEXT,
    transformations_json TEXT NOT NULL,
    split_json TEXT,
    status TEXT NOT NULL,
    metadata_json TEXT,
    provenance_json TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY(dataset_id) REFERENCES datasets(id)
);

CREATE TABLE IF NOT EXISTS models (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    name TEXT NOT NULL,
    architecture TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS model_versions (
    id TEXT PRIMARY KEY,
    model_id TEXT NOT NULL,
    version_number INTEGER NOT NULL,
    dataset_version_id TEXT,
    code_version TEXT,
    dependencies_json TEXT,
    configuration_json TEXT,
    hyperparameters_json TEXT,
    hardware_json TEXT,
    file_path TEXT,
    sha256 TEXT,
    metrics_json TEXT,
    status TEXT NOT NULL DEFAULT 'DRAFT',
    created_at TEXT NOT NULL,
    FOREIGN KEY(model_id) REFERENCES models(id)
);

CREATE TABLE IF NOT EXISTS experiments (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    mission_id TEXT,
    dataset_version_id TEXT,
    model_version_id TEXT,
    provider TEXT NOT NULL,
    hyperparameters_json TEXT,
    status TEXT NOT NULL DEFAULT 'NOT_STARTED',
    started_at TEXT,
    finished_at TEXT,
    duration_seconds REAL,
    metrics_json TEXT,
    logs_path TEXT,
    error_message TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    experiment_id TEXT,
    kind TEXT NOT NULL,
    provider TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'QUEUED',
    progress REAL NOT NULL DEFAULT 0.0,
    config_json TEXT,
    checkpoint_path TEXT,
    last_epoch INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS checkpoints (
    id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL,
    epoch INTEGER NOT NULL,
    file_path TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    metrics_json TEXT,
    is_valid INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS evaluations (
    id TEXT PRIMARY KEY,
    model_version_id TEXT NOT NULL,
    dataset_version_id TEXT NOT NULL,
    metrics_json TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS error_clusters (
    id TEXT PRIMARY KEY,
    evaluation_id TEXT NOT NULL,
    cluster_label TEXT NOT NULL,
    n_examples INTEGER NOT NULL,
    example_indices_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS registered_models (
    id TEXT PRIMARY KEY,
    model_version_id TEXT NOT NULL,
    manifest_json TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'DRAFT',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
    id TEXT PRIMARY KEY,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    target_type TEXT,
    target_id TEXT,
    details_json TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS council_sessions (
    id TEXT PRIMARY KEY,
    mission_id TEXT,
    project_id TEXT,
    status TEXT NOT NULL,
    llm_status_json TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS council_decisions (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    agent_role TEXT NOT NULL,
    reasoning TEXT,
    recommendation TEXT,
    confidence REAL,
    assumptions_json TEXT,
    evidence_json TEXT,
    artifact_type TEXT,
    artifact_id TEXT,
    status TEXT NOT NULL DEFAULT 'REAL',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS safety_gate_reviews (
    id TEXT PRIMARY KEY,
    model_version_id TEXT NOT NULL,
    quality_pass INTEGER,
    security_pass INTEGER,
    regression_pass INTEGER,
    data_pass INTEGER,
    dependencies_pass INTEGER,
    final_status TEXT NOT NULL DEFAULT 'PENDING',
    details_json TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS red_team_runs (
    id TEXT PRIMARY KEY,
    project_id TEXT,
    model_version_id TEXT NOT NULL,
    evaluation_id TEXT NOT NULL,
    status TEXT NOT NULL,
    summary_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS red_team_tests (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL,
    test_type TEXT NOT NULL,
    input_index INTEGER,
    expected TEXT,
    clean_prediction TEXT,
    attack_prediction TEXT,
    passed INTEGER,
    details_json TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY(run_id) REFERENCES red_team_runs(id)
);

CREATE TABLE IF NOT EXISTS scientist_reports (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    status TEXT NOT NULL,
    experiments_analyzed INTEGER NOT NULL,
    report_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(project_id) REFERENCES projects(id)
);


CREATE TABLE IF NOT EXISTS artifacts (
    id TEXT PRIMARY KEY,
    project_id TEXT,
    kind TEXT NOT NULL,
    path TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    metadata_json TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS autolab_runs (
    id TEXT PRIMARY KEY, project_id TEXT NOT NULL, status TEXT NOT NULL,
    config_json TEXT NOT NULL, details_json TEXT, started_at TEXT NOT NULL, finished_at TEXT
);

CREATE TABLE IF NOT EXISTS synthetic_data_runs (
    id TEXT PRIMARY KEY, project_id TEXT, source_dataset_version_id TEXT NOT NULL,
    method TEXT NOT NULL, output_path TEXT NOT NULL, sha256 TEXT NOT NULL,
    metadata_json TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS champion_challenger (
    project_id TEXT PRIMARY KEY, id TEXT UNIQUE NOT NULL, champion_model_version_id TEXT NOT NULL, updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS continuous_training_runs (
    id TEXT PRIMARY KEY, project_id TEXT NOT NULL, dataset_version_id TEXT NOT NULL,
    base_model_version_id TEXT, new_model_version_id TEXT, status TEXT NOT NULL,
    config_json TEXT NOT NULL, details_json TEXT, created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS deployments (
    id TEXT PRIMARY KEY, model_version_id TEXT NOT NULL, target TEXT NOT NULL,
    status TEXT NOT NULL, metadata_json TEXT NOT NULL, created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS backup_runs (
    id TEXT PRIMARY KEY, workspace TEXT NOT NULL, path TEXT NOT NULL, sha256 TEXT NOT NULL,
    status TEXT NOT NULL, metadata_json TEXT NOT NULL, created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS observability_snapshots (
    id TEXT PRIMARY KEY, status TEXT NOT NULL, snapshot_json TEXT NOT NULL, created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS security_events (
    id TEXT PRIMARY KEY, severity TEXT NOT NULL, action TEXT NOT NULL, target TEXT,
    status TEXT NOT NULL, details_json TEXT NOT NULL, created_at TEXT NOT NULL
);
"""


def get_connection(db_path: str) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db(db_path: str) -> sqlite3.Connection:
    with DB_LOCK:
        conn = get_connection(db_path)
        conn.executescript(SCHEMA)
        # Backward-compatible migrations for workspaces created by v0.3.x.
        migrations = {
            "datasets": [("license", "TEXT")],
            "dataset_versions": [("metadata_json", "TEXT"), ("provenance_json", "TEXT")],
        }
        for table, columns in migrations.items():
            existing={r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
            for name, typ in columns:
                if name not in existing:
                    conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {typ}")
        conn.commit()
        return conn
