"""api_server.py — serveur HTTP local pour AI Training OS.

Le serveur écoute par défaut uniquement sur 127.0.0.1 et sert le dashboard
ainsi que des routes JSON. Aucune donnée n'est envoyée vers un service externe.
"""
import json
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from .core import AITrainingOS

MAX_BODY_BYTES = 2 * 1024 * 1024


class AITOSRequestHandler(BaseHTTPRequestHandler):
    server_version = "AITrainingOS/1.0-local"

    def log_message(self, fmt, *args):
        # Journal serveur minimal et non intrusif.
        print(f"[AITrainingOS] {self.address_string()} - {fmt % args}")

    @property
    def base_dir(self):
        return self.server.base_dir

    def _app(self):
        # Connexion SQLite indépendante par requête: évite qu'un long Council
        # bloque les lectures du dashboard et reste compatible avec le serveur
        # multi-thread local.
        return AITrainingOS(self.base_dir)

    def _send(self, status, payload, content_type="application/json; charset=utf-8"):
        body = payload if isinstance(payload, (bytes, bytearray)) else (
            json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        )
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json_body(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ValueError("Content-Length invalide")
        if length < 0 or length > MAX_BODY_BYTES:
            raise ValueError("Corps de requête trop volumineux")
        raw = self.rfile.read(length)
        if not raw:
            return {}
        return json.loads(raw.decode("utf-8"))

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        try:
            path = urlparse(self.path).path.rstrip("/") or "/"
            qs = parse_qs(urlparse(self.path).query)
            if path == "/":
                return self._serve_dashboard()
            if path == "/api/health":
                app = self._app()
                return self._send(200, {"status": "REAL", "service": "AI Training OS", "council": app.council.status()})
            if path == "/api/dashboard":
                app = self._app()
                data = app.dashboard(qs.get("project_id", [None])[0])
                data["council"] = app.council.status()
                data["red_team"] = app.red_team.status()
                data["scientist"] = app.scientist.status()
                data["projects"] = self._projects(app)
                return self._send(200, data)
            if path == "/api/projects":
                app = self._app()
                return self._send(200, {"status": "REAL", "projects": self._projects(app)})
            if path == "/api/council/status":
                return self._send(200, self._app().council.status())
            if path == "/api/system":
                app = self._app(); return self._send(200, app.orchestrator.inspect())
            if path == "/api/capabilities/data":
                return self._send(200, __import__("ai_training_os.data_engine", fromlist=["capabilities"]).capabilities())
            if path == "/api/observability":
                app=self._app(); return self._send(200, app.observability.snapshot(app.base_dir))
            if path == "/api/jobs":
                app=self._app(); return self._send(200,{"status":"REAL","jobs":app.jobs.list_jobs()})
            if path == "/api/experiments":
                app=self._app(); pid=qs.get("project_id",[None])[0]; return self._send(200,{"status":"REAL","experiments":app.experiments.list_for_project(pid) if pid else [dict(r) for r in app.conn.execute("SELECT * FROM experiments ORDER BY created_at DESC LIMIT 100").fetchall()]})
            if path == "/api/datasets":
                app=self._app(); pid=qs.get("project_id",[None])[0]; sql="SELECT d.*,COUNT(v.id) AS versions_count FROM datasets d LEFT JOIN dataset_versions v ON v.dataset_id=d.id"; args=[];
                if pid: sql += " WHERE d.project_id=?"; args.append(pid)
                sql += " GROUP BY d.id ORDER BY d.created_at DESC"; rows=app.conn.execute(sql,args).fetchall(); return self._send(200,{"status":"REAL","datasets":[dict(r) for r in rows]})
            if path == "/api/dataset-versions":
                app=self._app(); did=qs.get("dataset_id",[None])[0]
                rows=app.conn.execute("SELECT * FROM dataset_versions WHERE dataset_id=? ORDER BY version_number DESC",(did,)).fetchall() if did else app.conn.execute("SELECT * FROM dataset_versions ORDER BY created_at DESC LIMIT 100").fetchall()
                return self._send(200,{"status":"REAL","versions":[dict(r) for r in rows]})
            if path == "/api/models":
                app=self._app(); pid=qs.get("project_id",[None])[0]; sql="SELECT m.*,COUNT(mv.id) AS versions_count FROM models m LEFT JOIN model_versions mv ON mv.model_id=m.id"; args=[];
                if pid: sql += " WHERE m.project_id=?"; args.append(pid)
                sql += " GROUP BY m.id ORDER BY m.created_at DESC"; rows=app.conn.execute(sql,args).fetchall(); return self._send(200,{"status":"REAL","models":[dict(r) for r in rows]})
            if path == "/api/model-versions":
                app=self._app(); mid=qs.get("model_id",[None])[0]; pid=qs.get("project_id",[None])[0]
                if mid:
                    rows=app.conn.execute("SELECT * FROM model_versions WHERE model_id=? ORDER BY version_number DESC",(mid,)).fetchall()
                elif pid:
                    rows=app.conn.execute("SELECT mv.* FROM model_versions mv JOIN models m ON mv.model_id=m.id WHERE m.project_id=? ORDER BY mv.created_at DESC LIMIT 100",(pid,)).fetchall()
                else:
                    rows=app.conn.execute("SELECT * FROM model_versions ORDER BY created_at DESC LIMIT 100").fetchall()
                return self._send(200,{"status":"REAL","versions":[dict(r) for r in rows]})
            if path == "/api/model-genome":
                mvid=self._required(qs,"model_version_id") if False else qs.get("model_version_id",[None])[0]
                if not mvid: return self._send(400,{"status":"FAILED","error":"model_version_id est obligatoire"})
                return self._send(200,self._app().model_genome.build(mvid))
            if path == "/api/local-models":
                app=self._app(); return self._send(200,{"status":"REAL","provider":app.llm_provider.status(),"models":app.llm_provider.available_models(),"bootstrap":app.startup.status()})
            if path == "/api/startup/status":
                return self._send(200, self._app().startup.status())
            if path == "/api/champion":
                app=self._app(); pid=qs.get("project_id",[None])[0]; return self._send(200,{"status":"REAL","champion":app.champion_challenger.get_champion(pid) if pid else None})
            if path == "/api/deployments":
                app=self._app(); rows=app.conn.execute("SELECT * FROM deployments ORDER BY created_at DESC LIMIT 100").fetchall(); return self._send(200,{"status":"REAL","deployments":[dict(r) for r in rows]})
            if path == "/api/backups":
                app=self._app(); rows=app.conn.execute("SELECT * FROM backup_runs ORDER BY created_at DESC LIMIT 100").fetchall(); return self._send(200,{"status":"REAL","backups":[dict(r) for r in rows]})
            if path == "/api/auto-lab":
                app=self._app(); rows=app.conn.execute("SELECT * FROM autolab_runs ORDER BY started_at DESC LIMIT 50").fetchall(); return self._send(200,{"status":"REAL","runs":[dict(r) for r in rows]})
            if path == "/api/synthetic":
                app=self._app(); pid=qs.get("project_id",[None])[0]
                rows=app.conn.execute("SELECT * FROM synthetic_data_runs" + (" WHERE project_id=?" if pid else "") + " ORDER BY created_at DESC LIMIT 50", (pid,) if pid else ()).fetchall()
                return self._send(200,{"status":"REAL","runs":[dict(r) for r in rows]})
            if path == "/api/artifacts":
                app=self._app(); pid=qs.get("project_id",[None])[0]
                rows=app.conn.execute("SELECT * FROM artifacts" + (" WHERE project_id=?" if pid else "") + " ORDER BY created_at DESC LIMIT 100", (pid,) if pid else ()).fetchall()
                return self._send(200,{"status":"REAL","artifacts":[dict(r) for r in rows]})
            if path == "/api/continuous-training":
                app=self._app(); pid=qs.get("project_id",[None])[0]
                rows=app.conn.execute("SELECT * FROM continuous_training_runs" + (" WHERE project_id=?" if pid else "") + " ORDER BY created_at DESC LIMIT 50", (pid,) if pid else ()).fetchall()
                return self._send(200,{"status":"REAL","runs":[dict(r) for r in rows]})
            if path == "/api/champion/compare":
                app=self._app(); a=self._required(qs,"champion_model_version_id"); b=self._required(qs,"challenger_model_version_id")
                ev_raw=qs.get("evaluation_id",[])
                return self._send(200,app.champion_challenger.compare(a,b,ev_raw))
            if path == "/api/security":
                app=self._app(); return self._send(200,{"status":"REAL","code_execution":app.security.code_execution_status(),"dependencies":app.security.dependency_report(["numpy","pandas","sklearn","torch","transformers","llama_cpp","pypdf","PIL","soundfile","cv2"])})
            if path == "/api/error-clusters":
                app=self._app(); project_id=qs.get("project_id",[None])[0]
                sql="SELECT ec.* FROM error_clusters ec JOIN evaluations ev ON ec.evaluation_id=ev.id JOIN model_versions mv ON ev.model_version_id=mv.id JOIN models m ON mv.model_id=m.id"
                args=[]
                if project_id: sql += " WHERE m.project_id=?"; args.append(project_id)
                sql += " ORDER BY ec.created_at DESC LIMIT 200"
                rows=app.conn.execute(sql,args).fetchall(); return self._send(200,{"status":"REAL","clusters":[dict(r) for r in rows]})
            if path == "/api/evaluations":
                app = self._app()
                project_id = qs.get("project_id", [None])[0]
                sql = """SELECT ev.id, ev.model_version_id, ev.dataset_version_id, ev.status, ev.metrics_json, ev.created_at
                         FROM evaluations ev
                         JOIN model_versions mv ON ev.model_version_id=mv.id
                         JOIN models m ON mv.model_id=m.id"""
                args = []
                if project_id:
                    sql += " WHERE m.project_id=?"
                    args.append(project_id)
                sql += " ORDER BY ev.created_at DESC LIMIT 100"
                rows = app.conn.execute(sql, args).fetchall()
                out=[]
                for r in rows:
                    d=dict(r)
                    try:d["metrics"]=json.loads(d.pop("metrics_json") or "{}")
                    except Exception: d["metrics"]={}
                    out.append(d)
                return self._send(200, {"status":"REAL", "evaluations":out})
            if path == "/api/council/sessions":
                app = self._app()
                project_id = qs.get("project_id", [None])[0]
                rows = app.conn.execute(
                    "SELECT * FROM council_sessions" + (" WHERE project_id=?" if project_id else "") + " ORDER BY created_at DESC LIMIT 50",
                    (project_id,) if project_id else (),
                ).fetchall()
                return self._send(200, {"status": "REAL", "sessions": [dict(r) for r in rows]})
            if path.startswith("/api/council/sessions/"):
                sid = path.split("/")[-1]
                app = self._app()
                row = app.conn.execute("SELECT * FROM council_sessions WHERE id=?", (sid,)).fetchone()
                if not row:
                    return self._send(404, {"status": "FAILED", "error": "Council session introuvable"})
                decisions = app.council.list_decisions(sid)
                result = dict(row)
                try:
                    result["llm_status"] = json.loads(result.pop("llm_status_json") or "{}")
                except Exception:
                    pass
                result["decisions"] = decisions
                return self._send(200, {"status": "REAL", "session": result})
            if path == "/api/red-team/status":
                return self._send(200, self._app().red_team.status())
            if path == "/api/red-team/runs":
                app = self._app()
                return self._send(200, {"status": "REAL", "runs": app.red_team.list_runs(qs.get("project_id", [None])[0])})
            if path.startswith("/api/red-team/runs/"):
                rid = path.split("/")[-1]
                run = self._app().red_team.get_run(rid)
                if not run:
                    return self._send(404, {"status": "FAILED", "error": "Red Team run introuvable"})
                return self._send(200, run)
            if path == "/api/scientist/status":
                return self._send(200, self._app().scientist.status())
            if path == "/api/scientist/reports":
                app = self._app()
                return self._send(200, {"status": "REAL", "reports": app.scientist.list_reports(qs.get("project_id", [None])[0])})
            return self._send(404, {"status": "FAILED", "error": "Route introuvable"})
        except Exception as exc:
            return self._send(500, {"status": "FAILED", "error": f"{type(exc).__name__}: {exc}"})

    def do_POST(self):
        try:
            path = urlparse(self.path).path.rstrip("/") or "/"
            body = self._json_body()
            app = self._app()
            if path == "/api/projects":
                name = str(body.get("name", "")).strip()
                if not name:
                    return self._send(400, {"status": "FAILED", "error": "name est obligatoire"})
                pid = app.create_project(name)
                return self._send(201, {"status": "REAL", "project_id": pid})
            if path == "/api/datasets/import":
                pid=self._required(body,"project_id"); self._require_project(app,pid); name=self._required(body,"name"); src=self._required(body,"source_path")
                ds_id=app.datasets.create_dataset(pid,name,src); dv_id,result=app.datasets.import_version(ds_id,src)
                return self._send(201,{"status":"REAL","dataset_id":ds_id,"dataset_version_id":dv_id,"result":result})
            if path == "/api/missions/analyze":
                pid = self._required(body, "project_id")
                raw = self._required(body, "raw_request")
                self._require_project(app, pid)
                return self._send(201, {"status": "REAL", "mission": app.missions.analyze(pid, raw)})
            if path == "/api/council/convene":
                pid = self._required(body, "project_id")
                raw = self._required(body, "raw_request")
                self._require_project(app, pid)
                context = body.get("context") or self._real_context(app, pid)
                mission_id = body.get("mission_id")
                if mission_id:
                    result = app.council.convene(pid, raw, context, mission_id=mission_id)
                    if result.get("status") == "COMPLETED":
                        self._link_pm(app, result.get("decisions", []), mission_id)
                else:
                    result = app.council.convene_and_create_training_plan(pid, raw, context)
                return self._send(200, {"status": result.get("status", "FAILED"), "council": result})
            if path == "/api/startup/install":
                return self._send(200, self._app().startup.consent_and_start())
            if path == "/api/startup/retry":
                app=self._app(); app.startup.state["status"]="PENDING"; app.startup.state["last_error"]=None; app.startup._save(); return self._send(200, app.startup.start())
            if path == "/api/local-models/select":
                model=self._required(body,"model"); return self._send(200,self._app().llm_provider.set_model(model,body.get("backend")))
            if path == "/api/local-models/verify":
                model=self._required(body,"model"); return self._send(200,self._app().llm_provider.verify_model(model,body.get("backend")))
            if path == "/api/training/run-tabular":
                pid=self._required(body,"project_id"); self._require_project(app,pid); src=self._required(body,"source_path")
                result=app.orchestrator.run_tabular_classification(pid,src,body.get("dataset_name","dataset"),body.get("model_name","local-classifier"),body.get("model_type","sgd_incremental"),int(body.get("n_epochs",3)),body.get("security_policy")); return self._send(200,result)
            if path == "/api/training/resume":
                jid=self._required(body,"job_id"); result=app.training.resume(jid); return self._send(200,result)
            if path == "/api/auto-lab/run":
                pid=self._required(body,"project_id"); self._require_project(app,pid)
                source=self._required(body,"source_path")
                candidates=body.get("model_types") or ["sgd_incremental","logistic_regression","random_forest"]
                candidates=[str(x) for x in candidates][:int(body.get("max_experiments",3))]
                plan={"max_experiments":len(candidates),"model_types":candidates,"n_epochs":int(body.get("n_epochs",3)),"security_policy":body.get("security_policy")}
                def run_experiment(i,plan_):
                    model_type=plan_["model_types"][i]
                    return app.orchestrator.run_tabular_classification(pid,source,body.get("dataset_name","autolab-dataset"),f"AutoLab-{model_type}",model_type,int(plan_.get("n_epochs",3)),plan_.get("security_policy"))
                def success(result):
                    threshold=body.get("objective_metric_threshold")
                    metric=body.get("objective_metric","accuracy")
                    if threshold is None: return False
                    metrics=result.get("training",{}).get("metrics") or {}
                    try: return float(metrics.get(metric)) >= float(threshold)
                    except (TypeError,ValueError): return False
                return self._send(200,app.auto_lab.run(pid,plan,run_experiment,success))
            if path == "/api/model-manager/import":
                mid=self._required(body,"model_id"); src=self._required(body,"source_file"); return self._send(201,app.model_manager.import_file(mid,src))
            if path == "/api/model-manager/package":
                mid=self._required(body,"model_id"); src=self._required(body,"source_file"); return self._send(201,app.model_manager.package(mid,src))
            if path == "/api/model-manager/validate":
                mid=self._required(body,"model_id"); return self._send(200,app.model_manager.validate(mid))
            if path == "/api/model-manager/download":
                mid=self._required(body,"model_id"); url=self._required(body,"url"); return self._send(200,app.model_manager.download(mid,url,body.get("expected_sha256"),max_bytes=body.get("max_bytes")))
            if path == "/api/model-manager/repair":
                mid=self._required(body,"model_id"); idx=int(self._required(body,"shard_index")); src=self._required(body,"source_file"); return self._send(200,app.model_manager.repair_shard(mid,idx,src))
            if path == "/api/model-manager/progress":
                mid=self._required(body,"model_id"); return self._send(200,app.model_manager.progress(mid))
            if path == "/api/model-manager/cleanup":
                mid=self._required(body,"model_id"); return self._send(200,app.model_manager.cleanup_temp(mid))
            if path == "/api/model-manager/inspect":
                src=self._required(body,"source_file"); return self._send(200,app.model_manager.inspect_model_file(src))
            if path == "/api/synthetic/bootstrap":
                dsv=self._required(body,"dataset_version_id"); return self._send(201,app.synthetic_lab.generate_bootstrap(dsv,int(body.get("n_rows") or 0) or None,int(body.get("seed",42))))
            if path == "/api/champion/set":
                pid=self._required(body,"project_id"); mvid=self._required(body,"model_version_id"); self._require_project(app,pid); return self._send(200,app.champion_challenger.set_champion(pid,mvid))
            if path == "/api/continuous-training/propose":
                pid=self._required(body,"project_id"); dsv=self._required(body,"dataset_version_id"); self._require_project(app,pid)
                return self._send(201,app.continuous_training.create_cycle(pid,dsv,body.get("base_model_version_id"),body.get("config")))
            if path == "/api/continuous-training/run":
                pid=self._required(body,"project_id"); source=self._required(body,"source_path"); self._require_project(app,pid)
                result=app.continuous_training.run_tabular(
                    app, pid, source, body.get("dataset_name","continuous-data"), body.get("model_name","continuous-model"),
                    body.get("base_model_version_id"), body.get("model_type","auto"), int(body.get("n_epochs",3)), body.get("security_policy")
                )
                return self._send(200,result)
            if path == "/api/continuous-training/mark":
                cid=self._required(body,"cycle_id"); return self._send(200,app.continuous_training.mark(cid,self._required(body,"status"),body.get("model_version_id"),body.get("details")))
            if path == "/api/deployment/export":
                mvid=self._required(body,"model_version_id"); target=self._required(body,"output_dir"); return self._send(200,app.deployment.export(mvid,target))
            if path == "/api/deployment/local":
                mvid=self._required(body,"model_version_id"); target=self._required(body,"target_dir"); return self._send(200,app.deployment.deploy_local(mvid,target))
            if path == "/api/backup":
                target=self._required(body,"output_zip"); result=app.disaster_recovery.backup(target); app.conn.execute("INSERT INTO backup_runs (id,workspace,path,sha256,status,metadata_json,created_at) VALUES (?,?,?,?,?,?,?)",((__import__("ai_training_os.utils",fromlist=["new_id"]).new_id("backup")),app.base_dir,target,result["sha256"],"COMPLETED",json.dumps(result),__import__("ai_training_os.utils",fromlist=["now_iso"]).now_iso())); app.conn.commit(); return self._send(201,result)
            if path == "/api/backup/verify":
                target=self._required(body,"backup_zip"); return self._send(200,app.disaster_recovery.verify(target))
            if path == "/api/restore":
                target=self._required(body,"backup_zip"); dest=self._required(body,"target_dir"); return self._send(200,app.disaster_recovery.restore(target,dest))
            if path == "/api/project/import":
                source=self._required(body,"zip_path"); dest=self._required(body,"target_workspace"); return self._send(200,app.exporter.import_project(source,dest))
            if path == "/api/red-team/run":
                evaluation_id = self._required(body, "evaluation_id")
                result = app.red_team.run_for_evaluation(evaluation_id, body.get("project_id"))
                status = 200 if result["status"] in ("COMPLETED", "UNAVAILABLE") else 500
                return self._send(status, result)
            if path == "/api/scientist/analyze":
                pid = self._required(body, "project_id")
                self._require_project(app, pid)
                return self._send(200, app.scientist.analyze(pid))
            return self._send(404, {"status": "FAILED", "error": "Route introuvable"})
        except ValueError as exc:
            return self._send(400, {"status": "FAILED", "error": str(exc)})
        except Exception as exc:
            return self._send(500, {"status": "FAILED", "error": f"{type(exc).__name__}: {exc}"})

    def _serve_dashboard(self):
        dashboard_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend", "dashboard.html")
        with open(dashboard_path, "rb") as f:
            body = f.read()
        return self._send(200, body, "text/html; charset=utf-8")

    @staticmethod
    def _required(body, key):
        value = body.get(key)
        if value is None or str(value).strip() == "":
            raise ValueError(f"{key} est obligatoire")
        return value

    @staticmethod
    def _require_project(app, project_id):
        row = app.conn.execute("SELECT id FROM projects WHERE id=?", (project_id,)).fetchone()
        if not row:
            raise ValueError(f"Projet introuvable: {project_id}")

    @staticmethod
    def _projects(app):
        rows = app.conn.execute(
            "SELECT p.*, (SELECT COUNT(*) FROM experiments e WHERE e.project_id=p.id) AS experiments_count, "
            "(SELECT COUNT(*) FROM datasets d WHERE d.project_id=p.id) AS datasets_count, "
            "(SELECT COUNT(*) FROM models m WHERE m.project_id=p.id) AS models_count "
            "FROM projects p ORDER BY p.created_at DESC"
        ).fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    def _real_context(app, project_id):
        dashboard = app.dashboard(project_id)
        history = app.conn.execute(
            "SELECT id,status,provider,metrics_json,created_at FROM experiments WHERE project_id=? ORDER BY created_at DESC LIMIT 20",
            (project_id,),
        ).fetchall()
        return {
            "hardware": dashboard["compute"],
            "compute_plan": dashboard["compute_plan"],
            "project_counts": dashboard["counts"],
            "experiments": [dict(r) for r in history],
        }

    @staticmethod
    def _link_pm(app, decisions, mission_id):
        pm = next((d for d in decisions if d.get("agent_role") == "project_manager" or d.get("role") == "project_manager"), None)
        if pm:
            did = pm.get("id") or pm.get("decision_id")
            if did:
                app.conn.execute(
                    "UPDATE council_decisions SET artifact_type=?, artifact_id=? WHERE id=?",
                    ("training_plan", mission_id, did),
                )
                app.conn.commit()


def create_server(base_dir: str, host="127.0.0.1", port=8787):
    os.makedirs(base_dir, exist_ok=True)
    server = ThreadingHTTPServer((host, int(port)), AITOSRequestHandler)
    server.base_dir = os.path.abspath(base_dir)
    return server


def serve_forever(base_dir: str, host="127.0.0.1", port=8787):
    server = create_server(base_dir, host, port)
    print(f"AI Training OS — serveur local REAL: http://{host}:{server.server_address[1]}/")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()
        server.server_close()
