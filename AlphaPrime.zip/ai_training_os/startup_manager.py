"""First-launch local AI bootstrap.

Downloads only real, declared resources after explicit user consent. All downloads
are resumable, SHA-256 verified, persisted, and kept inside the user's workspace.
No resource is reported READY before its local integrity check succeeds.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import stat
import subprocess
import tarfile
import threading
import time
import urllib.request
import urllib.error
import zipfile
from pathlib import Path

from . import utils

HF_BASE = "https://huggingface.co"
GITHUB_RELEASES = "https://api.github.com/repos/ggml-org/llama.cpp/releases/latest"
SMOLLM_URL = (HF_BASE + "/unsloth/SmolLM2-360M-Instruct-GGUF/resolve/main/"
              "SmolLM2-360M-Instruct-Q4_K_M.gguf?download=true")
SMOLLM_SHA256 = "16c7f1667fea34bacad196a57b548effcb37614db4ab5677a20c8c7b823b9e63"
NOMIC_URL = (HF_BASE + "/nomic-ai/nomic-embed-text-v1.5-GGUF/resolve/main/"
             "nomic-embed-text-v1.5.Q4_K_M.gguf?download=true")
NOMIC_SHA256 = "d4e388894e09cf3816e8b0896d81d265b55e7a9fff9ab03fe8bf4ef5e11295ac"


class StartupManager:
    def __init__(self, base_dir: str, audit=None):
        self.base_dir = base_dir
        self.audit = audit
        self.root = Path(base_dir) / "bootstrap"
        self.downloads = self.root / "downloads"
        self.runtime = self.root / "runtime"
        self.models = Path(base_dir) / "llm_models"
        self.state_path = self.root / "state.json"
        self.root.mkdir(parents=True, exist_ok=True)
        self.downloads.mkdir(parents=True, exist_ok=True)
        self.runtime.mkdir(parents=True, exist_ok=True)
        self.models.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._thread = None
        self.state = self._load_state()

    def _load_state(self):
        default = {"version": 1, "consent": False, "status": "PENDING", "resources": {}, "last_error": None}
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
            default.update(data)
        except (OSError, json.JSONDecodeError):
            pass
        return default

    def _save(self):
        tmp = self.state_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.state, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, self.state_path)

    @staticmethod
    def _sha256(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    def _set_resource(self, rid, **updates):
        with self._lock:
            cur = dict(self.state.setdefault("resources", {}).get(rid, {}))
            cur.update(updates)
            self.state["resources"][rid] = cur
            self._save()

    def _download(self, rid: str, url: str, target: Path, expected_sha256: str | None, source: str):
        target.parent.mkdir(parents=True, exist_ok=True)
        part = target.with_suffix(target.suffix + ".part")
        existing = part.stat().st_size if part.exists() else 0
        self._set_resource(rid, status="DOWNLOADING", truth_status="REAL", url=url,
                          path=str(target), partial_path=str(part), source=source,
                          bytes_downloaded=existing, started_at=utils.now_iso())

        def request(offset=0):
            headers = {"User-Agent": "AI-Training-OS/0.6.0"}
            if offset:
                headers["Range"] = f"bytes={offset}-"
            req = urllib.request.Request(url, headers=headers)
            return urllib.request.urlopen(req, timeout=30)

        try:
            with request(existing) as resp:
                code = getattr(resp, "status", None) or resp.getcode()
                if existing and code != 206:
                    existing = 0
                    if part.exists():
                        part.unlink()
                    resp.close()
                    resp = request(0)
                total = resp.headers.get("Content-Length")
                total_bytes = int(total) + existing if total and code == 206 else (int(total) if total else None)
                mode = "ab" if existing else "wb"
                written = existing
                with part.open(mode) as out:
                    while True:
                        chunk = resp.read(1024 * 1024)
                        if not chunk:
                            break
                        out.write(chunk)
                        written += len(chunk)
                        pct = round((written / total_bytes) * 100, 2) if total_bytes else None
                        self._set_resource(rid, bytes_downloaded=written, bytes_total=total_bytes,
                                           progress_percent=pct, updated_at=utils.now_iso())
        except Exception as exc:
            self._set_resource(rid, status="FAILED", truth_status="FAILED", error=str(exc),
                               bytes_downloaded=part.stat().st_size if part.exists() else 0)
            raise

        actual = self._sha256(part)
        if expected_sha256 and actual.lower() != expected_sha256.lower():
            self._set_resource(rid, status="FAILED", truth_status="FAILED", error="SHA-256 mismatch",
                               actual_sha256=actual, expected_sha256=expected_sha256)
            raise RuntimeError(f"SHA-256 mismatch for {rid}: {actual} != {expected_sha256}")
        os.replace(part, target)
        self._set_resource(rid, status="READY", truth_status="REAL", bytes_downloaded=target.stat().st_size,
                           bytes_total=target.stat().st_size, progress_percent=100, sha256=actual,
                           verified_at=utils.now_iso())
        return target

    def _runtime_asset(self):
        req = urllib.request.Request(GITHUB_RELEASES, headers={"User-Agent": "AI-Training-OS/0.6.0", "Accept": "application/vnd.github+json"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            release = json.loads(resp.read().decode("utf-8"))
        system = platform.system().lower()
        machine = platform.machine().lower()
        if system == "windows":
            needle = "win-cpu-arm64" if machine in {"aarch64", "arm64"} else "win-cpu-x64"
        elif system == "darwin":
            needle = "macos-arm64" if machine in {"aarch64", "arm64"} else "macos-x64"
        elif system == "linux":
            needle = "ubuntu-arm64" if machine in {"aarch64", "arm64"} else "ubuntu-x64"
        else:
            raise RuntimeError(f"OS non pris en charge automatiquement: {platform.system()}")
        assets = release.get("assets") or []
        chosen = next((a for a in assets if needle in a.get("name", "") and "llama-b" in a.get("name", "")), None)
        if not chosen:
            chosen = next((a for a in assets if needle in a.get("name", "")), None)
        if not chosen:
            raise RuntimeError(f"Aucun binaire llama.cpp pour {needle} dans la release {release.get('tag_name')}")
        digest = chosen.get("digest") or ""
        if not digest.startswith("sha256:"):
            raise RuntimeError("La release llama.cpp ne fournit pas de digest SHA-256 vérifiable pour cet asset.")
        return {"release": release.get("tag_name"), "asset": chosen["name"], "url": chosen["browser_download_url"], "sha256": digest.split(":", 1)[1], "size": chosen.get("size")}

    def resources(self):
        rt = self.state.get("resources", {}).get("llama_runtime", {})
        sm = self.state.get("resources", {}).get("smollm2", {})
        nm = self.state.get("resources", {}).get("nomic_embed", {})
        return {
            "llama_runtime": {"id": "llama_runtime", "name": "llama.cpp local runtime", "description": "Moteur natif local pour exécuter le LLM GGUF sans API distante.", **rt},
            "smollm2": {"id": "smollm2", "name": "SmolLM2 360M Instruct Q4_K_M", "description": "LLM local léger pour AI Council et missions.", "url": SMOLLM_URL, "sha256": SMOLLM_SHA256, "size_estimate_bytes": 271 * 1024 * 1024, **sm},
            "nomic_embed": {"id": "nomic_embed", "name": "nomic-embed-text-v1.5 Q4_K_M", "description": "Modèle local d'embeddings pour la recherche sémantique future.", "url": NOMIC_URL, "sha256": NOMIC_SHA256, "size_estimate_bytes": 84 * 1024 * 1024, **nm},
        }

    def status(self):
        with self._lock:
            resources = self.resources()
            statuses = [r.get("status") for r in resources.values()]
            if all(s == "READY" for s in statuses):
                status = "READY"
            elif any(s == "FAILED" for s in statuses):
                status = "FAILED"
            elif any(s == "DOWNLOADING" for s in statuses):
                status = "DOWNLOADING"
            else:
                status = "PENDING"
            self.state["status"] = status
            self._save()
            return {"status": "REAL", "bootstrap_status": status, "consent": bool(self.state.get("consent")),
                    "resources": resources, "workspace": str(self.root), "message": "Téléchargement local réel après consentement."}

    def start(self):
        with self._lock:
            if not self.state.get("consent"):
                return {"status": "PROPOSED", "bootstrap_status": "CONSENT_REQUIRED", "message": "Consentement requis avant tout téléchargement."}
            if self._thread and self._thread.is_alive():
                return self.status()
            self.state["status"] = "DOWNLOADING"
            self.state["last_error"] = None
            self._save()
            self._thread = threading.Thread(target=self._run, name="aitos-bootstrap", daemon=True)
            self._thread.start()
            return {"status": "REAL", "bootstrap_status": "DOWNLOADING"}

    def consent_and_start(self):
        with self._lock:
            self.state["consent"] = True
            self.state["consent_at"] = utils.now_iso()
            self._save()
        return self.start()

    def _run(self):
        try:
            rt = self._runtime_asset()
            self._set_resource("llama_runtime", status="DISCOVERED", truth_status="REAL", **rt)
            ext = ".zip" if rt["asset"].endswith(".zip") else ".tar.gz"
            archive = self.downloads / ("llama-runtime" + ext)
            runtime_dir = self.runtime / rt["release"]
            marker = runtime_dir / ".installed.json"
            if marker.exists():
                data = json.loads(marker.read_text(encoding="utf-8"))
                if data.get("sha256") == rt["sha256"] and self._find_server_binary(runtime_dir):
                    self._set_resource("llama_runtime", status="READY", truth_status="REAL", path=str(runtime_dir), verified_at=utils.now_iso(), progress_percent=100)
                else:
                    marker.unlink(missing_ok=True)
            if self.state["resources"].get("llama_runtime", {}).get("status") != "READY":
                self._download("llama_runtime", rt["url"], archive, rt["sha256"], "GitHub release: ggml-org/llama.cpp")
                self._safe_extract(archive, runtime_dir)
                binary = self._find_server_binary(runtime_dir)
                if not binary:
                    raise RuntimeError("llama-server introuvable après extraction du runtime.")
                if os.name != "nt":
                    mode = os.stat(binary).st_mode
                    os.chmod(binary, mode | stat.S_IXUSR | stat.S_IXGRP)
                marker.write_text(json.dumps({"release": rt["release"], "sha256": rt["sha256"], "binary": str(binary)}, indent=2), encoding="utf-8")
                self._set_resource("llama_runtime", status="READY", truth_status="REAL", path=str(runtime_dir), binary=str(binary), verified_at=utils.now_iso())

            if not (self.models / "SmolLM2-360M-Instruct-Q4_K_M.gguf").exists():
                self._download("smollm2", SMOLLM_URL, self.models / "SmolLM2-360M-Instruct-Q4_K_M.gguf", SMOLLM_SHA256, "Hugging Face: unsloth/SmolLM2-360M-Instruct-GGUF")
            else:
                p = self.models / "SmolLM2-360M-Instruct-Q4_K_M.gguf"
                if self._sha256(p) != SMOLLM_SHA256:
                    self._set_resource("smollm2", status="FAILED", truth_status="FAILED", error="Fichier local présent mais SHA-256 invalide; suppression avant nouveau téléchargement.")
                    p.unlink()
                    self._download("smollm2", SMOLLM_URL, p, SMOLLM_SHA256, "Hugging Face: unsloth/SmolLM2-360M-Instruct-GGUF")
                else:
                    self._set_resource("smollm2", status="READY", truth_status="REAL", path=str(p), progress_percent=100, bytes_downloaded=p.stat().st_size, bytes_total=p.stat().st_size)

            if not (self.models / "nomic-embed-text-v1.5.Q4_K_M.gguf").exists():
                self._download("nomic_embed", NOMIC_URL, self.models / "nomic-embed-text-v1.5.Q4_K_M.gguf", NOMIC_SHA256, "Hugging Face: nomic-ai/nomic-embed-text-v1.5-GGUF")
            else:
                p = self.models / "nomic-embed-text-v1.5.Q4_K_M.gguf"
                if self._sha256(p) != NOMIC_SHA256:
                    p.unlink()
                    self._download("nomic_embed", NOMIC_URL, p, NOMIC_SHA256, "Hugging Face: nomic-ai/nomic-embed-text-v1.5-GGUF")
                else:
                    self._set_resource("nomic_embed", status="READY", truth_status="REAL", path=str(p), progress_percent=100, bytes_downloaded=p.stat().st_size, bytes_total=p.stat().st_size)
            with self._lock:
                self.state["status"] = "READY"
                self.state["ready_at"] = utils.now_iso()
                self._save()
            if self.audit:
                self.audit.log("system", "LOCAL_AI_BOOTSTRAP_READY", "bootstrap", "local", {"resources": list(self.state["resources"].keys())})
        except Exception as exc:
            with self._lock:
                self.state["status"] = "FAILED"
                self.state["last_error"] = str(exc)
                self._save()
            if self.audit:
                self.audit.log("system", "LOCAL_AI_BOOTSTRAP_FAILED", "bootstrap", "local", {"error": str(exc)})

    @staticmethod
    def _safe_extract(archive: Path, dest: Path):
        tmp = dest.with_name(dest.name + ".extracting")
        shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True, exist_ok=True)
        base = tmp.resolve()
        if archive.suffix == ".zip":
            with zipfile.ZipFile(archive) as z:
                for info in z.infolist():
                    target = (tmp / info.filename).resolve()
                    if not str(target).startswith(str(base)):
                        raise RuntimeError("Archive path traversal détecté")
                z.extractall(tmp)
        else:
            with tarfile.open(archive, "r:gz") as t:
                for member in t.getmembers():
                    target = (tmp / member.name).resolve()
                    if not str(target).startswith(str(base)):
                        raise RuntimeError("Archive path traversal détecté")
                t.extractall(tmp)
        shutil.rmtree(dest, ignore_errors=True)
        os.replace(tmp, dest)

    @staticmethod
    def _find_server_binary(root: Path):
        names = {"llama-server.exe", "llama-server"}
        for p in root.rglob("*"):
            if p.is_file() and p.name in names:
                return p
        return None

    def runtime_binary(self):
        for r in self.resources().values():
            if r.get("id") != "llama_runtime":
                continue
            p = r.get("binary")
            if p and Path(p).is_file():
                return p
            root = r.get("path")
            if root and (b := self._find_server_binary(Path(root))):
                return str(b)
        return None
