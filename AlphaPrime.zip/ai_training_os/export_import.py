"""Project export/import with scoped relational snapshot and integrity verification.

The export is self-contained: database rows belonging to one project are
captured together with referenced artifacts. Import rebuilds a fresh local
workspace and rewrites file paths to the imported artifact locations.
"""
import os, json, shutil, zipfile, tempfile
from . import utils, db

SCOPED_TABLES = [
    "projects", "ai_missions", "datasets", "dataset_versions", "models", "model_versions",
    "experiments", "jobs", "checkpoints", "evaluations", "error_clusters", "registered_models",
    "safety_gate_reviews", "red_team_runs", "red_team_tests", "scientist_reports",
    "council_sessions", "council_decisions", "artifacts", "autolab_runs", "synthetic_data_runs",
    "champion_challenger", "continuous_training_runs", "deployments",
]

INSERT_ORDER = [
    "projects", "ai_missions", "datasets", "dataset_versions", "models", "model_versions",
    "experiments", "jobs", "checkpoints", "evaluations", "error_clusters", "registered_models",
    "safety_gate_reviews", "red_team_runs", "red_team_tests", "scientist_reports",
    "council_sessions", "council_decisions", "artifacts", "autolab_runs", "synthetic_data_runs",
    "champion_challenger", "continuous_training_runs", "deployments",
]

PATH_FIELDS = {
    "dataset_versions": ("file_path",),
    "model_versions": ("file_path",),
    "checkpoints": ("file_path",),
    "jobs": ("checkpoint_path",),
    "experiments": ("logs_path",),
    "artifacts": ("path",),
    "synthetic_data_runs": ("output_path",),
}


def _in_clause(values):
    return ",".join("?" for _ in values)


def _select_in(conn, table, column, values):
    if not values:
        return []
    q = f"SELECT * FROM {table} WHERE {column} IN ({_in_clause(values)})"
    return [dict(r) for r in conn.execute(q, tuple(values)).fetchall()]


class ProjectExporter:
    def __init__(self, conn, audit=None):
        self.conn = conn
        self.audit = audit

    def _scoped(self, project_id):
        projects = [dict(r) for r in self.conn.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchall()]
        if not projects:
            raise ValueError(f"Projet introuvable: {project_id}")
        missions = [dict(r) for r in self.conn.execute("SELECT * FROM ai_missions WHERE project_id=?", (project_id,)).fetchall()]
        datasets = [dict(r) for r in self.conn.execute("SELECT * FROM datasets WHERE project_id=?", (project_id,)).fetchall()]
        dsids = [d["id"] for d in datasets]
        dvs = _select_in(self.conn, "dataset_versions", "dataset_id", dsids)
        models = [dict(r) for r in self.conn.execute("SELECT * FROM models WHERE project_id=?", (project_id,)).fetchall()]
        mids = [m["id"] for m in models]
        mvs = _select_in(self.conn, "model_versions", "model_id", mids)
        mvids = [m["id"] for m in mvs]
        experiments = [dict(r) for r in self.conn.execute("SELECT * FROM experiments WHERE project_id=?", (project_id,)).fetchall()]
        eids = [e["id"] for e in experiments]
        jobs = _select_in(self.conn, "jobs", "experiment_id", eids)
        jids = [j["id"] for j in jobs]
        checkpoints = _select_in(self.conn, "checkpoints", "job_id", jids)
        evaluations = _select_in(self.conn, "evaluations", "model_version_id", mvids)
        evids = [e["id"] for e in evaluations]
        error_clusters = _select_in(self.conn, "error_clusters", "evaluation_id", evids)
        registered_models = _select_in(self.conn, "registered_models", "model_version_id", mvids)
        safety = _select_in(self.conn, "safety_gate_reviews", "model_version_id", mvids)
        red_runs = [dict(r) for r in self.conn.execute("SELECT * FROM red_team_runs WHERE project_id=?", (project_id,)).fetchall()]
        red_runs += [dict(r) for r in _select_in(self.conn, "red_team_runs", "model_version_id", mvids) if r["id"] not in {x["id"] for x in red_runs}]
        red_ids = [r["id"] for r in red_runs]
        red_tests = _select_in(self.conn, "red_team_tests", "run_id", red_ids)
        scientist = [dict(r) for r in self.conn.execute("SELECT * FROM scientist_reports WHERE project_id=?", (project_id,)).fetchall()]
        council_sessions = [dict(r) for r in self.conn.execute("SELECT * FROM council_sessions WHERE project_id=?", (project_id,)).fetchall()]
        council_ids = [x["id"] for x in council_sessions]
        council_decisions = _select_in(self.conn, "council_decisions", "session_id", council_ids)
        artifacts = [dict(r) for r in self.conn.execute("SELECT * FROM artifacts WHERE project_id=?", (project_id,)).fetchall()]
        autolab = [dict(r) for r in self.conn.execute("SELECT * FROM autolab_runs WHERE project_id=?", (project_id,)).fetchall()]
        synthetic = [dict(r) for r in self.conn.execute("SELECT * FROM synthetic_data_runs WHERE project_id=?", (project_id,)).fetchall()]
        champion = [dict(r) for r in self.conn.execute("SELECT * FROM champion_challenger WHERE project_id=?", (project_id,)).fetchall()]
        continuous = [dict(r) for r in self.conn.execute("SELECT * FROM continuous_training_runs WHERE project_id=?", (project_id,)).fetchall()]
        deployments = [dict(r) for r in _select_in(self.conn, "deployments", "model_version_id", mvids)]

        related_ids = {project_id}
        for rows in (missions, datasets, dvs, models, mvs, experiments, jobs, checkpoints, evaluations,
                     error_clusters, registered_models, safety, red_runs, red_tests, scientist,
                     council_sessions, council_decisions, artifacts, autolab, synthetic, champion,
                     continuous, deployments):
            for row in rows:
                for k in ("id", "project_id", "mission_id", "dataset_id", "model_id", "model_version_id",
                          "experiment_id", "job_id", "evaluation_id", "run_id", "session_id", "artifact_id"):
                    if row.get(k):
                        related_ids.add(str(row[k]))
        audit = []
        if related_ids:
            vals = tuple(related_ids)
            q = f"SELECT * FROM audit_log WHERE target_id IN ({_in_clause(vals)}) ORDER BY created_at"
            audit = [dict(r) for r in self.conn.execute(q, vals).fetchall()]

        return {
            "projects": projects, "ai_missions": missions, "datasets": datasets,
            "dataset_versions": dvs, "models": models, "model_versions": mvs,
            "experiments": experiments, "jobs": jobs, "checkpoints": checkpoints,
            "evaluations": evaluations, "error_clusters": error_clusters,
            "registered_models": registered_models, "safety_gate_reviews": safety,
            "red_team_runs": red_runs, "red_team_tests": red_tests,
            "scientist_reports": scientist, "council_sessions": council_sessions,
            "council_decisions": council_decisions, "artifacts": artifacts,
            "autolab_runs": autolab, "synthetic_data_runs": synthetic,
            "champion_challenger": champion, "continuous_training_runs": continuous,
            "deployments": deployments, "audit_log": audit,
        }

    def export(self, project_id, output_zip_path):
        output_zip_path = os.path.abspath(output_zip_path)
        tmp = tempfile.mkdtemp(prefix="aitos_export_")
        try:
            files_dir = os.path.join(tmp, "files")
            os.makedirs(files_dir, exist_ok=True)
            scoped = self._scoped(project_id)
            dump = os.path.join(tmp, "database_dump.json")
            with open(dump, "w", encoding="utf-8") as f:
                json.dump(scoped, f, ensure_ascii=False, indent=2, default=str)

            paths = set()
            for table, fields in PATH_FIELDS.items():
                for row in scoped.get(table, []):
                    for field in fields:
                        p = row.get(field)
                        if p and os.path.isfile(p):
                            paths.add(os.path.abspath(p))

            hashes = {}
            file_map = {}
            for fp in sorted(paths):
                name = hashlib_name(fp)
                dest = os.path.join(files_dir, name)
                shutil.copy2(fp, dest)
                rel = os.path.join("files", name).replace(os.sep, "/")
                file_map[fp] = rel
                hashes[rel] = utils.sha256_file(dest)

            manifest = {
                "status": "REAL", "project_id": project_id,
                "exported_at": utils.now_iso(),
                "database_dump_sha256": utils.sha256_file(dump),
                "file_hashes": hashes, "file_map": file_map,
                "tables": {k: len(v) for k, v in scoped.items()},
            }
            with open(os.path.join(tmp, "export_manifest.json"), "w", encoding="utf-8") as f:
                json.dump(manifest, f, ensure_ascii=False, indent=2)

            os.makedirs(os.path.dirname(output_zip_path), exist_ok=True)
            with zipfile.ZipFile(output_zip_path, "w", zipfile.ZIP_DEFLATED) as z:
                for root, _, names in os.walk(tmp):
                    for fn in names:
                        path = os.path.join(root, fn)
                        z.write(path, os.path.relpath(path, tmp))
            if self.audit:
                self.audit.log("system", "EXPORT_PROJECT", "project", project_id,
                                {"zip": output_zip_path, "files": len(hashes)})
            return {**manifest, "path": output_zip_path}
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    @staticmethod
    def _safe_extract(zip_path, extract_dir):
        extract_dir = os.path.abspath(extract_dir)
        with zipfile.ZipFile(zip_path) as z:
            for info in z.infolist():
                dest = os.path.abspath(os.path.join(extract_dir, info.filename))
                if os.path.commonpath([extract_dir, dest]) != extract_dir:
                    raise RuntimeError("Archive path traversal détecté")
            z.extractall(extract_dir)

    def verify_and_import(self, zip_path, extract_dir):
        os.makedirs(extract_dir, exist_ok=True)
        self._safe_extract(zip_path, extract_dir)
        with open(os.path.join(extract_dir, "export_manifest.json"), encoding="utf-8") as f:
            manifest = json.load(f)
        dump = os.path.join(extract_dir, "database_dump.json")
        dump_ok = os.path.isfile(dump) and utils.sha256_file(dump) == manifest["database_dump_sha256"]
        results = {}
        for rel, h in manifest.get("file_hashes", {}).items():
            p = os.path.join(extract_dir, rel)
            results[rel] = "OK" if os.path.isfile(p) and utils.sha256_file(p) == h else ("MISSING" if not os.path.isfile(p) else "CORRUPTED")
        return {"integrity": "OK" if dump_ok and all(v == "OK" for v in results.values()) else "FAILED",
                "dump_ok": dump_ok, "files": results, "status": "REAL"}

    def import_project(self, zip_path, target_workspace):
        """Rebuilds a fresh local workspace from a verified project export."""
        target_workspace = os.path.abspath(target_workspace)
        os.makedirs(target_workspace, exist_ok=True)
        existing = [x for x in os.listdir(target_workspace) if x not in {".", ".."}]
        if existing:
            raise ValueError("Le workspace cible doit être vide pour un import de projet sécurisé.")

        tmp = tempfile.mkdtemp(prefix="aitos_import_")
        try:
            verification = self.verify_and_import(zip_path, tmp)
            if verification["integrity"] != "OK":
                return {"status": "FAILED", "reason": "Archive export invalide ou corrompue.", "verification": verification}
            with open(os.path.join(tmp, "database_dump.json"), encoding="utf-8") as f:
                dump = json.load(f)
            with open(os.path.join(tmp, "export_manifest.json"), encoding="utf-8") as f:
                manifest = json.load(f)

            imported_root = os.path.join(target_workspace, "imported_artifacts")
            os.makedirs(imported_root, exist_ok=True)
            path_map = {}
            for original, rel in manifest.get("file_map", {}).items():
                source = os.path.join(tmp, rel)
                dest = os.path.join(imported_root, os.path.basename(rel))
                shutil.copy2(source, dest)
                path_map[os.path.abspath(original)] = dest

            conn = db.init_db(os.path.join(target_workspace, "aitos.db"))
            try:
                def rewrite(value):
                    if value is None:
                        return None
                    if isinstance(value, str):
                        ap = os.path.abspath(value)
                        return path_map.get(ap, value)
                    return value

                inserted = {}
                for table in INSERT_ORDER:
                    rows = dump.get(table, [])
                    if not rows:
                        inserted[table] = 0
                        continue
                    columns = sorted(rows[0].keys())
                    placeholders = ",".join("?" for _ in columns)
                    sql = f"INSERT INTO {table} ({','.join(columns)}) VALUES ({placeholders})"
                    for row in rows:
                        values = [rewrite(row.get(c)) for c in columns]
                        conn.execute(sql, values)
                    inserted[table] = len(rows)

                # audit_log is intentionally project-scoped in the export.
                for row in dump.get("audit_log", []):
                    columns = sorted(row.keys())
                    placeholders = ",".join("?" for _ in columns)
                    conn.execute(f"INSERT INTO audit_log ({','.join(columns)}) VALUES ({placeholders})",
                                 [rewrite(row.get(c)) for c in columns])
                conn.commit()
            finally:
                conn.close()

            check = db.init_db(os.path.join(target_workspace, "aitos.db"))
            try:
                project_id = dump["projects"][0]["id"] if dump.get("projects") else None
                project_exists = check.execute("SELECT COUNT(*) FROM projects WHERE id=?", (project_id,)).fetchone()[0] if project_id else 0
                counts = {table: check.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] for table in INSERT_ORDER}
                return {"status": "REAL", "integrity": "OK", "target_workspace": target_workspace,
                        "project_id": project_id, "project_exists": bool(project_exists),
                        "inserted": inserted, "workspace_counts": counts}
            finally:
                check.close()
        except Exception as exc:
            shutil.rmtree(target_workspace, ignore_errors=True)
            return {"status": "FAILED", "reason": str(exc)}
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


def hashlib_name(path):
    return os.path.basename(path) + "." + utils.sha256_file(path)[:12]
