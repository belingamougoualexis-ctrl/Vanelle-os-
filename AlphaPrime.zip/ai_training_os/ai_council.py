"""
ai_council.py — Local AI Council.

Le Council est composé d'agents à rôle fixe (AI Architect, Data Scientist,
ML Engineer, Research AI, Optimization AI, Evaluation AI, Security AI,
Project Manager). Chaque agent produit un raisonnement RÉEL en appelant
LocalLLMProvider.complete(). Si aucun LLM local n'est disponible, le Council
ne fabrique AUCUNE réponse : il renvoie un statut LLM REQUIRED explicite,
exactement comme demandé.

Toute décision est enregistrée (council_decisions) avec : rôle, raisonnement
brut du modèle, recommandation extraite, confiance déclarée par l'agent,
hypothèses, preuves (contexte réellement fourni), et — quand la décision
crée un artefact concret (Training Plan via AIMissionEngine) — le type et
l'id de cet artefact, pour rester traçable (exigence §4 / §32 du cahier des
charges).
"""
import json
import re
from . import utils
from .llm_provider import LocalLLMProvider

AGENT_ROLES = [
    ("ai_architect", "AI Architect",
     "Tu proposes une architecture de modèle adaptée au problème, au dataset et aux ressources matérielles données. "
     "Sois concret : type de modèle, taille approximative, stratégie (from scratch / fine-tuning / LoRA / QLoRA)."),
    ("data_scientist", "Data Scientist",
     "Tu analyses la qualité et la pertinence des données décrites (dataset stats fournis) et proposes des "
     "transformations concrètes (nettoyage, équilibrage, split)."),
    ("ml_engineer", "ML Engineer",
     "Tu proposes une configuration d'entraînement réaliste compte tenu des ressources matérielles détectées "
     "(CPU/GPU/RAM fournies) : batch size, epochs, learning rate, precision."),
    ("research_ai", "Research AI",
     "Tu analyses l'historique d'expériences fourni (s'il existe) et formules une hypothèse d'amélioration testable."),
    ("optimization_ai", "Optimization AI",
     "Tu proposes des optimisations de coût/temps/mémoire compte tenu des contraintes matérielles fournies."),
    ("evaluation_ai", "Evaluation AI",
     "Tu proposes les métriques d'évaluation pertinentes pour ce type de problème et un seuil de succès raisonnable."),
    ("security_ai", "Security AI",
     "Tu identifies les risques de sécurité/robustesse pertinents (données sensibles, empoisonnement, fuite) pour ce cas précis."),
    ("project_manager", "Project Manager",
     "Tu synthétises les avis des autres rôles en un plan d'action séquencé avec risques et prochaine étape concrète."),
]

_CONFIDENCE_RE = re.compile(r"confiance\s*[:=]?\s*(\d{1,3})\s*%", re.IGNORECASE)
_HYPOTHESES_RE = re.compile(r"(?:hypoth(?:è|e)ses?)\s*[:\-]\s*(.+?)(?=(?:\n[A-ZÉÈÀÙÂÊÎÔÛÇ][^\n]{0,80}:)|\Z)", re.IGNORECASE | re.DOTALL)


class AICouncil:
    def __init__(self, conn, base_dir: str, audit=None, missions=None, llm_provider=None):
        self.conn = conn
        self.audit = audit
        self.missions = missions
        self.llm = llm_provider or LocalLLMProvider(base_dir)

    def status(self) -> dict:
        """État réel et honnête du Council (sonde le LLM local à chaque appel)."""
        return self.llm.status()

    def _record_session(self, project_id: str, mission_id: str, status: str, llm_status: dict) -> str:
        sid = utils.new_id("council")
        self.conn.execute(
            "INSERT INTO council_sessions (id, mission_id, project_id, status, llm_status_json, created_at) "
            "VALUES (?,?,?,?,?,?)",
            (sid, mission_id, project_id, status, utils.dumps(llm_status), utils.now_iso()),
        )
        self.conn.commit()
        return sid

    def _record_decision(self, session_id: str, role: str, reasoning: str, recommendation: str,
                          confidence, evidence: dict, artifact_type: str = None, artifact_id: str = None) -> str:
        did = utils.new_id("decision")
        hypotheses = []
        match = _HYPOTHESES_RE.search(reasoning or "")
        if match:
            raw = match.group(1).strip()
            hypotheses = [x.strip(" -•\t") for x in re.split(r"[\n;]|(?<=[.!?])\s+(?=[A-ZÉÈÀÙÂÊÎÔÛÇ])", raw) if x.strip()]
        assumptions = {
            "hypotheses": hypotheses,
            "confidence_source": "LLM_TEXT" if confidence is not None else "NOT_DECLARED",
        }
        self.conn.execute(
            "INSERT INTO council_decisions (id, session_id, agent_role, reasoning, recommendation, confidence, "
            "assumptions_json, evidence_json, artifact_type, artifact_id, status, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (did, session_id, role, reasoning, recommendation, confidence,
             utils.dumps(assumptions), utils.dumps(evidence), artifact_type, artifact_id, "REAL", utils.now_iso()),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("ai_council", "decision_recorded", "council_decision", did,
                            {"role": role, "session_id": session_id, "artifact_type": artifact_type})
        return did

    def convene(self, project_id: str, raw_request: str, context: dict, mission_id: str = None) -> dict:
        """
        Convoque le Council sur une demande utilisateur + contexte réel (stats
        dataset, ressources matérielles, historique d'expériences — fournis
        par l'appelant, jamais inventés ici).

        Retourne soit un statut LLM REQUIRED (aucune décision fabriquée),
        soit les décisions réellement produites par le LLM local, une par
        agent, enregistrées et traçables.
        """
        llm_status = self.llm.status()
        if llm_status["status"] != "READY":
            session_id = self._record_session(project_id, mission_id, "LLM_REQUIRED", llm_status)
            return {
                "session_id": session_id,
                "status": "LLM REQUIRED",
                "message": llm_status["message"],
                "decisions": [],
            }

        session_id = self._record_session(project_id, mission_id, "IN_PROGRESS", llm_status)
        context_json = json.dumps(context, ensure_ascii=False, indent=2)
        decisions = []
        for role_key, role_label, role_brief in AGENT_ROLES:
            system = (
                f"Tu es {role_label} au sein d'un AI Council local d'entraînement de modèles. {role_brief} "
                "Réponds en français, de façon concrète et actionnable, en te basant STRICTEMENT sur le "
                "contexte fourni (ne suppose aucune donnée non fournie). Termine par une ligne "
                "'Confiance: NN%' reflétant honnêtement ton niveau de certitude."
            )
            prompt = f"Demande utilisateur:\n{raw_request}\n\nContexte réel disponible:\n{context_json}"
            try:
                result = self.llm.complete(system, prompt, max_tokens=400)
            except RuntimeError as e:
                # Le LLM a répondu READY lors du status() mais est devenu indisponible
                # entre-temps (ex: démon arrêté). On ferme la session explicitement
                # au lieu de laisser un état IN_PROGRESS trompeur.
                self.conn.execute("UPDATE council_sessions SET status=? WHERE id=?", ("FAILED", session_id))
                self.conn.commit()
                if self.audit:
                    self.audit.log("system", "COUNCIL_RUNTIME_FAILURE", "council_session", session_id, {"error": str(e)})
                return {
                    "session_id": session_id, "status": "FAILED",
                    "message": str(e), "decisions": decisions,
                }
            text = result["text"].strip()
            match = _CONFIDENCE_RE.search(text)
            confidence = int(match.group(1)) / 100.0 if match else None
            did = self._record_decision(
                session_id, role_key, text, text[:400], confidence,
                evidence={"model": result["model"], "backend": result["backend"], "context": context},
            )
            decisions.append({
                "decision_id": did, "role": role_key, "role_label": role_label,
                "reasoning": text, "confidence": confidence,
                "model": result["model"], "backend": result["backend"],
            })

        self.conn.execute("UPDATE council_sessions SET status=? WHERE id=?", ("COMPLETED", session_id))
        self.conn.commit()
        return {"session_id": session_id, "status": "COMPLETED", "message": "Décisions produites par le LLM local.",
                "decisions": decisions}

    def convene_and_create_training_plan(self, project_id: str, raw_request: str, context: dict) -> dict:
        """
        Variante qui relie explicitement une décision du Council à un artefact
        réel : si le Council est READY, il délibère, PUIS un vrai Training Plan
        est créé via AIMissionEngine (analyseur par règles réel, cf ai_mission.py)
        et la décision du Project Manager est liée à cet artefact (traçabilité §4/§32).
        """
        result = self.convene(project_id, raw_request, context)
        if result["status"] != "COMPLETED" or not self.missions:
            return result
        mission = self.missions.analyze(project_id, raw_request)
        pm_decision = next((d for d in result["decisions"] if d["role"] == "project_manager"), None)
        if pm_decision:
            self.conn.execute(
                "UPDATE council_decisions SET artifact_type=?, artifact_id=? WHERE id=?",
                ("training_plan", mission["mission_id"], pm_decision["decision_id"]),
            )
            self.conn.commit()
        result["training_plan"] = mission
        return result

    def list_decisions(self, session_id: str) -> list:
        rows = self.conn.execute(
            "SELECT * FROM council_decisions WHERE session_id=? ORDER BY created_at", (session_id,)
        ).fetchall()
        return [dict(r) for r in rows]
