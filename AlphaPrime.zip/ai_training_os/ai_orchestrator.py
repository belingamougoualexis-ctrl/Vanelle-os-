"""AI Orchestrator: end-to-end local workflows over real engines."""
import json
import os
from . import utils


class AIOrchestrator:
    def __init__(self, os_app):
        self.app = os_app

    def inspect(self):
        return {
            "status": "REAL",
            "local_only": True,
            "modules": [
                "Frontend", "Local Backend", "AI Orchestrator", "AI Mission Engine",
                "Local AI Council", "Universal Data Engine", "Dataset Registry", "Model Engine",
                "Model Registry", "Local Model Manager", "Compute Engine", "Smart Compute Planner",
                "Training Engine", "Experiment Engine", "Evaluation Engine", "Auto Lab",
                "Error Mining", "Synthetic Data Lab", "Red Team Engine", "AI Scientist",
                "Champion/Challenger", "Model Genome", "Continuous Training", "Safety Gate",
                "Deployment Engine", "Cost Guardian", "Disaster Recovery", "Observability",
                "Security", "Artifact Storage", "Local Configuration/SQLite",
            ],
        }

    def _read_rows(self, dv):
        rows = [json.loads(l) for l in open(dv["file_path"], encoding="utf-8") if l.strip()]
        label = next((c for c in ("label", "class", "target", "category") if rows and c in rows[0]), None)
        if not label:
            raise ValueError("Aucune colonne label/class/target/category détectée.")
        split = utils.loads(dv["split_json"] or "{}")

        # Dataset multimédia généré par le Data Engine (class-folder).
        if rows and "asset_relpath" in rows[0]:
            from .feature_engine import modality_for_path
            modalities = {modality_for_path(r.get("asset_relpath", r.get("extension", ""))) for r in rows}
            modalities.discard("unknown")
            if len(modalities) != 1:
                raise ValueError(f"Dataset multimédia hétérogène ou non supporté: {sorted(modalities)}")
            modality = next(iter(modalities))
            root = os.path.dirname(os.path.abspath(dv["file_path"]))

            def asset_group(indices):
                paths=[]; labels=[]
                for i in indices:
                    if i >= len(rows): continue
                    r=rows[i]; rel=r.get("asset_relpath")
                    if not rel: continue
                    candidate=os.path.abspath(os.path.join(root, rel))
                    if not os.path.isfile(candidate): continue
                    paths.append(candidate); labels.append(r[label])
                return paths, labels
            train_paths, train_labels = asset_group(split.get("train", []))
            val_paths, val_labels = asset_group(split.get("val", []) + split.get("test", []))
            return train_paths, train_labels, val_paths, val_labels, {
                "label_col": label, "feature_cols": ["asset"], "task_type": "classification",
                "modality": modality, "asset_root": root,
                "asset_train_paths": [os.path.relpath(x, root) for x in train_paths],
                "asset_val_paths": [os.path.relpath(x, root) for x in val_paths],
            }

        features = []
        for c in rows[0].keys():
            if c == label: continue
            vals=[]
            for r in rows:
                try: float(r.get(c)); vals.append(r.get(c))
                except (TypeError,ValueError): pass
            if vals and len(vals) / max(1,len(rows)) >= 0.8: features.append(c)
        if not features:
            raise ValueError("Aucune feature numérique locale exploitable.")

        def build(indices):
            X=[]; y=[]
            for i in indices:
                if i>=len(rows): continue
                r=rows[i]
                try: X.append([float(r[c]) for c in features]); y.append(r[label])
                except (TypeError,ValueError,KeyError): pass
            return X,y
        Xt,yt=build(split.get("train",[])); Xv,yv=build(split.get("val",[])+split.get("test",[]))
        return Xt,yt,Xv,yv,{"label_col":label,"feature_cols":features,"task_type":"classification","modality":"tabular"}

    @staticmethod
    def _torch_available():
        try:
            import torch  # noqa: F401
            return True
        except ImportError:
            return False

    def _base_checkpoint(self, model_version_id):
        if not model_version_id:
            return None
        row = self.app.conn.execute(
            """SELECT c.* FROM checkpoints c
               JOIN jobs j ON c.job_id=j.id
               JOIN experiments e ON j.experiment_id=e.id
               WHERE e.model_version_id=? ORDER BY c.epoch DESC, c.created_at DESC LIMIT 1""",
            (model_version_id,),
        ).fetchone()
        if not row:
            return None
        ck = dict(row)
        try:
            if os.path.isfile(ck["file_path"]) and utils.sha256_file(ck["file_path"]) == ck["sha256"]:
                return ck
        except Exception:
            pass
        return None

    def _run_on_dataset_version(self, project_id, dv_id, model_name, model_type="auto", n_epochs=3,
                                security_policy=None, regression_baseline=None, mission_text=None,
                                base_model_version_id=None, resume_from=None, start_epoch=0):
        dv = self.app.datasets.get_version(dv_id)
        if not dv:
            raise ValueError("Version de dataset introuvable")

        mission = self.app.missions.analyze(
            project_id,
            mission_text or f"Entraîner localement un classifieur tabulaire sur la version de dataset {dv_id}",
        )
        Xt, yt, Xv, yv, layout = self._read_rows(dv)
        data_stats = {"n_rows": dv["n_rows"], "n_cols": dv["n_cols"], "n_features": len(layout["feature_cols"]), "modality": layout.get("modality"), "torch_available": self._torch_available()}
        compute_plan = self.app.compute_planner.plan(data_stats["n_rows"], data_stats["n_features"])
        strategy = self.app.model_engine.plan("classification", data_stats, compute_plan, model_type)
        if strategy["status"] != "REAL":
            return {
                "status": "UNAVAILABLE", "reason": strategy["reason"], "mission": mission,
                "dataset_version_id": dv_id, "cost_estimate": self.app.cost_guardian.estimate(
                    data_stats["n_rows"], data_stats["n_features"], model_type, "LOCAL_CPU_PROVIDER"
                ),
            }

        resolved_type = strategy["selected"]
        provider = strategy["selected_provider"]
        estimate = self.app.cost_guardian.estimate(
            data_stats["n_rows"], data_stats["n_features"], resolved_type, provider
        )
        mission_plan = mission["plan"]
        mission_plan["analysis_backend"] = "RULE_BASED_LOCAL"
        mission_plan["observed_dataset"] = data_stats
        mission_plan["model_engine"] = strategy
        mission_plan["estimates"] = estimate
        self.app.conn.execute(
            "UPDATE ai_missions SET training_plan_json=? WHERE id=?",
            (utils.dumps(mission_plan), mission["mission_id"]),
        )
        self.app.conn.commit()
        mission["plan"] = mission_plan

        model_id = self.app.models.create_model(project_id, model_name, resolved_type)
        hardware = self.app.observability.snapshot()["compute"]
        dep_map = {"scikit-learn": "installed-runtime"}
        if layout.get("modality") in {"image"}: dep_map["Pillow"] = "installed-runtime"
        if layout.get("modality") == "pdf": dep_map["pypdf"] = "installed-runtime"
        if layout.get("modality") == "audio": dep_map["soundfile"] = "installed-runtime"
        if layout.get("modality") == "video": dep_map["opencv-python"] = "installed-runtime"
        if resolved_type in ("mlp_torch",): dep_map["torch"] = "installed-runtime"
        if resolved_type == "mlp_sklearn": dep_map["scikit-learn"] = "installed-runtime"
        config = {
            "code_version": "local-1",
            "dependencies": dep_map,
            "strategy": strategy,
            "provider": provider,
            "base_model_version_id": base_model_version_id,
        }
        mv = self.app.models.create_version(
            model_id, dv_id, config,
            {"model_type": resolved_type, "n_epochs": int(n_epochs)},
            {"provider": provider, "compute": hardware, "data": data_stats},
        )
        exp = self.app.experiments.create(
            project_id, mission["mission_id"], dv_id, mv, provider,
            {"model_type": resolved_type, "n_epochs": int(n_epochs), "base_model_version_id": base_model_version_id},
        )
        training_config = {
            "X_train": Xt, "y_train": yt, "X_val": Xv, "y_val": yv,
            "model_type": resolved_type, "n_epochs": int(n_epochs), "task_type": "classification",
        }
        if layout.get("modality") not in (None, "tabular"):
            training_config.update({
                "modality": layout["modality"],
                "asset_root": layout["asset_root"],
                "asset_train_paths": layout["asset_train_paths"],
                "asset_val_paths": layout["asset_val_paths"],
                "asset_y_train": yt,
                "asset_y_val": yv,
            })
        if resume_from:
            training_config["resume_from"] = resume_from
            training_config["start_epoch"] = int(start_epoch)

        train = self.app.training.run(exp, provider, training_config)
        if train.get("status") != "COMPLETED":
            return {
                "status": train.get("status"), "mission": mission, "dataset_version_id": dv_id,
                "model_version_id": mv, "experiment_id": exp, "training": train,
                "cost_estimate": estimate, "base_model_version_id": base_model_version_id,
            }

        artifacts = []
        if train.get("final_model_path"):
            artifacts.append(self.app.artifacts.put_file(
                train["final_model_path"], "model",
                {"project_id": project_id, "model_version_id": mv, "experiment_id": exp, "source": "training_engine"},
            ))
        cost_actual = self.app.cost_guardian.actual(
            train["duration_seconds"], [train.get("final_model_path"), train.get("logs_path")]
        )
        eval_id = self.app.evaluations.record(mv, dv_id, train["metrics"])
        errors = self.app.error_mining.mine(eval_id, train["y_val"], train["predictions"])
        red = self.app.red_team.run_for_evaluation(eval_id, project_id)
        gate = self.app.safety_gate.review(
            mv, train["metrics"], security_policy=security_policy,
            regression_baseline=regression_baseline,
        )
        genome = self.app.model_genome.build(mv)
        return {
            "status": "REAL", "mission": mission, "dataset_version_id": dv_id,
            "model_version_id": mv, "experiment_id": exp, "training": train,
            "evaluation_id": eval_id, "error_clusters": errors, "red_team": red,
            "safety_gate": gate, "model_genome": genome, "layout": layout,
            "artifacts": artifacts, "cost_estimate": estimate, "cost_actual": cost_actual,
            "base_model_version_id": base_model_version_id,
            "training_method": "CONTINUATION_FROM_CHECKPOINT" if resume_from else "FROM_SCRATCH",
        }

    def run_tabular_classification(self, project_id, source_path, dataset_name="dataset",
                                   model_name="local-classifier", model_type="auto", n_epochs=3,
                                   security_policy=None, regression_baseline=None, base_model_version_id=None):
        ds = self.app.datasets.create_dataset(project_id, dataset_name, source_path)
        dv_id, _ = self.app.datasets.import_version(ds, source_path)
        resume_from = None
        start_epoch = 0
        if base_model_version_id and (model_type in ("auto", "", None, "sgd_incremental")):
            ck = self._base_checkpoint(base_model_version_id)
            if ck:
                resume_from, start_epoch = ck["file_path"], int(ck["epoch"])
                model_type = "sgd_incremental"
        return self._run_on_dataset_version(
            project_id, dv_id, model_name, model_type, n_epochs, security_policy,
            regression_baseline=regression_baseline,
            mission_text=f"Classifier localement les nouvelles données du fichier {source_path}",
            base_model_version_id=base_model_version_id,
            resume_from=resume_from, start_epoch=start_epoch,
        )

    def run_tabular_from_dataset_version(self, project_id, dataset_version_id, model_name="local-classifier",
                                         model_type="auto", n_epochs=3, security_policy=None,
                                         regression_baseline=None, base_model_version_id=None,
                                         mission_text=None, resume_from=None, start_epoch=0):
        return self._run_on_dataset_version(
            project_id, dataset_version_id, model_name, model_type, n_epochs, security_policy,
            regression_baseline=regression_baseline, mission_text=mission_text,
            base_model_version_id=base_model_version_id,
            resume_from=resume_from, start_epoch=start_epoch,
        )

    def train_and_evaluate(self, project_id, mission_id, dataset_version_id, model_version_id, provider, train_config):
        exp_id = self.app.experiments.create(project_id, mission_id, dataset_version_id, model_version_id, provider, train_config)
        train = self.app.training.run(exp_id, provider, train_config)
        result = {"status": train["status"], "experiment_id": exp_id, "training": train}
        if train["status"] == "COMPLETED":
            result["evaluation_id"] = self.app.evaluations.record(model_version_id, dataset_version_id, train["metrics"])
            result["model_genome"] = self.app.model_genome.build(model_version_id)
        return result
