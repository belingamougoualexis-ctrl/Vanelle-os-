package com.vanelle.relance.utils

import android.content.Context
import android.content.Intent
import com.vanelle.relance.data.AppDatabase
import com.vanelle.relance.data.Client
import com.vanelle.relance.data.StatutDette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

object BackupHelper {

    suspend fun exporterJson(context: Context): String = withContext(Dispatchers.IO) {
        val clients = AppDatabase.getInstance(context).clientDao().getTous().first()
        val arr = JSONArray()
        clients.forEach { c ->
            arr.put(
                JSONObject()
                    .put("nom", c.nom)
                    .put("telephone", c.telephone)
                    .put("montant", c.montant)
                    .put("dateEcheance", c.dateEcheance)
                    .put("statut", c.statut.name)
                    .put("nombreRelances", c.nombreRelances)
                    .put("dernierContact", c.dernierContact)
                    .put("note", c.note)
            )
        }
        JSONObject()
            .put("app", "VanelleRelance")
            .put("version", 1)
            .put("exportedAt", System.currentTimeMillis())
            .put("clients", arr)
            .toString(2)
    }

    fun intentPartage(json: String): Intent {
        return Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_SUBJECT, "Sauvegarde Vanelle Relance")
            putExtra(Intent.EXTRA_TEXT, json)
        }
    }

    suspend fun importerJson(context: Context, json: String): Int = withContext(Dispatchers.IO) {
        val root = JSONObject(json)
        val arr = root.getJSONArray("clients")
        val dao = AppDatabase.getInstance(context).clientDao()
        var count = 0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val statut = try {
                StatutDette.valueOf(o.optString("statut", "EN_COURS"))
            } catch (_: Exception) {
                StatutDette.EN_COURS
            }
            val dc = if (o.isNull("dernierContact")) null else o.optLong("dernierContact")
            dao.inserer(
                Client(
                    nom = o.getString("nom"),
                    telephone = o.getString("telephone"),
                    montant = o.getDouble("montant"),
                    dateEcheance = o.getLong("dateEcheance"),
                    statut = statut,
                    nombreRelances = o.optInt("nombreRelances", 0),
                    dernierContact = dc,
                    note = o.optString("note", "")
                )
            )
            count++
        }
        count
    }
}
