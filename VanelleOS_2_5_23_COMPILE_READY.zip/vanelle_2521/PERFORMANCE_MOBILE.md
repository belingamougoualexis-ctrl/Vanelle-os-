# Vanelle — perf mobile (3B local)

## Ce que le code contrôle

| Levier | Réglage Vanelle |
|--------|-----------------|
| n_ctx | 384–768 (défaut ~512) — conversations courtes |
| max_tokens | ~160–280 selon complexité |
| CoT visible | Format BROUILLON/RÉPONSE → seule RÉPONSE parlée |
| Préchargement | `warmUp()` au démarrage (`VanelleApp`, `MainActivity`, `DataDownloadService`) |
| Calculs | Code déterministe, 0 token LLM |

## Ce que le **build natif** contrôle (hors Kotlin)

| Levier | Action |
|--------|--------|
| **NNAPI / GPU** | Rebuild `llamacpp-kotlin` / llama.cpp avec backend NNAPI (ou Vulkan). Le wrapper 0.4.0 expose peu d’options runtime : si le .so est CPU-only, Vanelle reste CPU. |
| n_threads | Souvent fixé dans le native (`n_threads=0` = auto dans le helper upstream). Tester 4 cores perf. |
| Flash Attention | Flag de compile llama.cpp |
| Speculative decoding | Non supporté dans ce wrapper |

## Priorité pour 30–60 tok/s

1. Confirmer que le AAR embarque un backend **NNAPI** (ou Vulkan), pas seulement GGML CPU  
2. Garder n_ctx bas (déjà fait)  
3. Préchargement (déjà fait)  
4. max_tokens bas + CoT non parlé (déjà fait)  

Sans NNAPI, un 3B Q4 reste souvent à ~5–15 tok/s sur CPU mid-range — c’est une limite hardware/build, pas seulement de prompts.
