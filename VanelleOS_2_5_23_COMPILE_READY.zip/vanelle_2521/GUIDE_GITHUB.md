# VanelleOS — Guide GitHub & comportement de l'app

## 1. Mettre le projet sur GitHub

1. Crée un nouveau dépôt sur GitHub (vide, sans README ni .gitignore générés automatiquement).
2. En local, décompresse `VanelleOS_PRO_FINAL.zip` puis :
   ```
   cd VanelleOS_PRO_FINAL
   git init
   git add .
   git commit -m "VanelleOS - version initiale"
   git branch -M main
   git remote add origin https://github.com/<ton-compte>/<ton-repo>.git
   git push -u origin main
   ```
3. Le workflow `.github/workflows/android-build.yml` se déclenche automatiquement à ce push (déjà inclus dans le zip, rien à créer).
4. Onglet **Actions** du dépôt → le job "Build VanelleOS APK" tourne (3-5 min) → à la fin, un artefact **VanelleOS-debug-apk** contenant `app-debug.apk` est téléchargeable, prêt à installer sur un téléphone.

**Note technique** : ce projet n'inclut pas le wrapper Gradle (`gradlew`/`gradlew.bat`) — ces fichiers contiennent un binaire (`gradle-wrapper.jar`) que je ne peux pas générer sans accès réseau. Le workflow installe Gradle directement via l'action officielle `gradle/actions/setup-gradle`, ce qui revient exactement au même résultat pour la compilation. Si tu préfères avoir le wrapper (par exemple pour compiler en local sans installer Gradle toi-même), lance une fois `gradle wrapper --gradle-version 8.11.1` depuis IntelliJ/Android Studio ou en local, puis commit les fichiers générés.

Aucun secret, aucune clé à configurer pour ce build de test — c'est un APK debug, auto-signé.

## 2. Si le build échoue

Ouvre le job en erreur dans l'onglet Actions, copie le message d'erreur (la ligne rouge) et colle-le moi directement — je corrige.

## 3. Comment l'app se comporte, au quotidien

**Premier lancement**
L'app demande d'un coup les autorisations Micro, Contacts, Appel, SMS et Notifications via les popups Android standards. Une boîte de dialogue propose aussi d'activer le service d'Accessibilité (redirige vers les réglages système, obligatoire pour ce type de service).

**En fonctionnement normal**
Les commandes vocales sont déclenchées uniquement lorsque l’utilisateur appuie sur le bouton mascotte.

**L'onglet Configuration**
C'est le centre de contrôle unique : le switch d'écoute vocale, le statut réel (Accordée/Non accordée) de chaque autorisation avec un bouton pour l'ouvrir dans les réglages si besoin, et l'effacement de la mémoire. Tout ce que l'utilisateur doit un jour autoriser ou vérifier est là, rien n'est caché ailleurs.

**Identité visuelle**
Fond blanc, texte noir, accents rose (#FF2D95), logo mascotte robot blanc/bleu sur fond clair.

## 4. Ce qui reste en dehors de mon contrôle

- La compilation réelle n'a jamais eu lieu dans mon environnement (pas de Gradle/SDK ici) — le vrai test, c'est le premier push.
- CALL_PHONE et SEND_SMS resteront bloquées si tu publies un jour sur le Google Play Store (réservées aux apps téléphone/SMS par défaut) — aucun souci pour un usage privé ou un sideload.

## 5. Build CI — versions obligatoires (ne pas modifier)

Le workflow **doit** utiliser :
- JDK **17**
- Gradle **8.11.1** (installé directement par `gradle/actions/setup-gradle`, pas de wrapper)
- AGP **8.7.2** + Kotlin **2.1.10**

Si le log affiche une autre version de Gradle que 8.11.1, le fichier `.github/workflows/android-build.yml` n'a **pas** été mis à jour sur GitHub.
Remplace-le entièrement par celui du ZIP, commit, push.


## v1.9.20 — chargement Llama renforcé
- `android:largeHeap="true"` activé pour la variante Android.
- Le GGUF est vérifié par taille exacte, signature `GGUF` et SHA-256 avant tout chargement.
- SHA-256 attendu : `1d0e9419ec4e12aef73ccf4ffd122703e94c48344a96bc7c5f0f2772c2152ce3`.
- Pause de 12 secondes après téléchargement avant le chargement natif.
- Timeout de chargement porté à 120 secondes.
- Les appareils 64 bits avec RAM trop faible ne forcent plus un chargement susceptible de faire planter l'application.
