# Vanelle OS — polish produit

| Point | Statut |
|-------|--------|
| Onboarding + démo < 30 s | `OnboardingActivity` |
| 100 % privé / offline marketing | Bannière + offline par défaut |
| Personnalité contrôlable | Pote / Calme / Coach / Énergie |
| Export conversation | `ChatExport.share` |
| Widget | `VanelleAppWidget` |
| Stats transparentes | `UsageStats` |
| Mises à jour modèle | `DataDownloadService` (existant) |
| Identité Rose/Blanc/Noir | `VanelleBrand` + colors.xml |
| Historique dossiers/tags | Partiel (Conversation + tags mémoire) — à enrichir |
