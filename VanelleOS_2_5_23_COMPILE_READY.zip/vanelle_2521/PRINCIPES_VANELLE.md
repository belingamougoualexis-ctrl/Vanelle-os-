# Vanelle — principes d'expérience (pas de course aux paramètres)

Un petit modèle local bien intégré peut **surpasser en expérience perçue** un gros modèle générique amnésique. Voici la boussole produit.

## 1. Fiabilité factuelle avant tout
Mieux vaut « je ne sais pas » qu'une invention assurée. La confiance se gagne sur la durée.

## 2. Mémoire persistante et contextuelle
Se souvenir de l'utilisateur, de ses projets et préférences : vrai différenciateur vs cloud amnésique.

## 3. Spécialisation plutôt que généralité
Téléphone, relances, aide concrète, explications claires — pas une encyclopédie universelle.

## 4. Latence et disponibilité
Réponse locale, même sans réseau : valeur d'usage énorme au quotidien.

## 5. Alignement avec l'intention réelle
Comprendre ce que la personne *veut*, pas seulement ce qu'elle a écrit mot à mot.

## 6. Honnêteté sur les limites
Admettre une erreur ou une incertitude plutôt que de doubler la mise.

## 7. Personnalité cohérente (Vanelle)
Ton propre, aligné marque — pas une imitation de Claude / GPT / Gemini.

---

Implémentation code :
- `PersonalityPrefs.systemTone` + system prompt `LocalLlamaHelper` → charte injectée à chaque génération
- `RelationalMemory.learnFromUserUtterance` → prénom, préférences, projet, ville
- `fullContextForAi` → profil + faits + dialogue multi-tours
- Logique système (parser, actions) **avant** l'IA quand c'est déterministe
