# VanelleOS — classification réelle des fonctionnalités

Cette classification distingue **modèle IA local**, **logique système sans IA** et **Internet sans modèle IA**.

## 1. Sans modèle IA local — logique système

Ces fonctions restent utilisables pendant le téléchargement ou si le modèle local n'est pas disponible :
- batterie
- lampe torche
- volume / sonnerie
- ouverture d'applications
- caméra / galerie
- appels / SMS / urgence
- minuteur
- partage
- mémoire locale (enregistrer / rappeler)
- presse-papiers
- retour / accueil via accessibilité
- lecture brute de l'écran
- journal d'activité
- statut de confidentialité
- navigation / ouverture d'une destination quand la commande est déterministe
- rappels / alarmes lorsqu'ils sont déjà structurés

## 2. Sans modèle IA local, mais Internet requis

Ces fonctions ne dépendent pas de Llama, mais elles ne peuvent pas être garanties hors connexion :
- recherche Web
- recherche YouTube / ouverture YouTube avec une requête
- traduction en ligne
- résolution d'informations actuelles sur Internet

Une panne réseau ne doit donc pas être présentée comme « IA non prête ».

## 3. Avec modèle IA local

Ces fonctions nécessitent le modèle local chargé :
- conversation libre
- génération de texte
- raisonnement sur une demande ouverte
- compréhension avancée du contexte
- résumé / interprétation d'écran
- reformulation et analyse complexes

## 4. Routage hybride

Une commande naturelle est d'abord analysée par la logique déterministe. Si elle contient plusieurs actions, le moteur sépare les étapes et exécute chaque intention dans l'ordre. Le modèle IA n'est utilisé que lorsque la compréhension libre ou le raisonnement sont réellement nécessaires.

Exemple générique :
`Ouvre <application> et <action>`

Le nom de l'application ne doit jamais englober le reste de la phrase. Le même mécanisme s'applique à YouTube, musique, recherche, messages, navigation et autres applications prises en charge.
