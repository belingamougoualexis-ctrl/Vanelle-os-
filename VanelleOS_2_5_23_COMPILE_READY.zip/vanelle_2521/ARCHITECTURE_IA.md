# VanelleOS — Où intervient l'IA, où c'est la logique système

Ce document répond à une seule question à chaque fois qu'on regarde un
fichier ou une fonction : **est-ce que ça passe par le modèle IA local
(Llama), ou est-ce que c'est du code déterministe (règles, regex,
API système) qui ne "réfléchit" jamais ?**

Règle d'or du projet : **la logique système est toujours essayée en
premier**. L'IA n'intervient que là où une règle fixe ne peut pas
suffire (comprendre une phrase libre, résumer, reformuler). Si un
comportement peut être décrit par un algorithme fixe, il est fait en
logique système — jamais par l'IA, même si l'IA pourrait aussi le
faire (plus rapide, gratuit, fonctionne sans modèle téléchargé,
résultat prévisible à 100%).

## 🧠 Là où l'IA locale (Llama) intervient réellement

Un seul point d'entrée vers le modèle dans tout le projet :
`LocalLlamaHelper.get(context)`. Tout appel IA passe par lui. Si vous
cherchez "est-ce que ce fichier utilise l'IA ?", cherchez
`LocalLlamaHelper` dedans — s'il n'y est pas, ce fichier n'utilise
jamais l'IA.

| Fichier | Fonction | Rôle de l'IA |
|---|---|---|
| `CommandInterpreter.kt` | `brainFirst()` | Dernier recours pour une phrase que `CommandParser` (regex) n'a pas reconnue comme une commande précise — l'IA essaie de comprendre l'intention libre. |
| `CommandInterpreter.kt` | `synthesizeAnswer()` | Reformule un résultat de recherche web en réponse parlée, au lieu de lire un extrait brut. |
| `CommandInterpreter.kt` | `answerSmart()` / `screenSummary()` | Résume le contenu de l'écran capturé par le service d'accessibilité. |
| `CommandInterpreter.kt` | `fallbackAi()` | Filet de sécurité final si rien d'autre (règles, recherche, mémoire) n'a répondu. |
| `AutonomousAgent.kt` | `run()` / `parseLlamaPlan()` | Découpe un objectif complexe ("organise-moi une soirée") en étapes, quand aucune règle toute faite ne couvre le cas. |

Tout le reste de ces deux fichiers (`splitActionAndReply`,
`runToolLine`, `executeSingle`, `heuristicSteps`, `isAgentLike`...) est
**logique système** : ils décident *si* l'IA doit être appelée, mais
ne sont pas eux-mêmes de l'IA.

Les appels à `LocalLlamaHelper` dans `DataDownloadService.kt`,
`MainActivity.kt` et `VanelleApp.kt` ne sont **pas des fonctionnalités
IA** : ils gèrent juste le téléchargement et le préchargement du
modèle en mémoire (cycle de vie), pas une réponse à l'utilisateur.

## ⚙️ Là où c'est 100% logique système (aucune IA, jamais)

| Domaine | Fichiers | Ce qu'ils font sans IA |
|---|---|---|
| Compréhension de commande | `CommandParser.kt`, `SystemCommandRouter.kt` | Détection d'intention par regex/mots-clés (ouvrir une app, appeler, SMS, minuteur, relance...). C'est ce qui est essayé **avant** l'IA. |
| Actions réelles sur le téléphone | `DeviceActions.kt`, `MultimodalHelper.kt`, `MapsHelper.kt`, `YouTubeHelper.kt`, `WebSearchHelper.kt` | Ouvrir une app, appeler, lancer Maps/YouTube/une recherche — de simples `Intent` Android. |
| Traduction | `TranslateHelper.kt` | Appelle l'API de traduction Google (endpoint GTX), pas le modèle Llama local. |
| Détection d'humeur | `EmotionEngine.kt` | Liste de mots-clés fixe (`"stress"`, `"urgent"`, `"content"`...) — pas d'IA. |
| Mémoire | `RelationalMemory.kt`, `EpisodicMemory.kt`, `MemoryVault.kt` | Stockage/relecture de faits déjà formulés par l'utilisateur — aucune génération. |
| Habitudes | `WorkflowLearner.kt`, `RoutineManager.kt` | Comptage d'occurrences répétées — pas de raisonnement IA. |
| Outils à la volée | `DynamicUiGenerator.kt`, `MiniToolGenerator.kt` | Choix du type d'outil (compteur/budget/checklist) par simple test de mots-clés. |
| Lecture d'écran | `ScreenAnalysisHelper.kt`, `VanelleAccessibilityService.kt` | Récupèrent le texte brut de l'écran (l'IA n'intervient qu'ensuite, dans `screenSummary()`, si demandé). |
| Overlay / mascotte | `OverlayHelper.kt`, `FloatingMascotButton.kt`, `GuidanceOverlay.kt`, `MascotManager.kt` | Affichage, animation, choix du skin — interface pure. |
| Sécurité / système | `LocalAuth.kt`, `PrivacyFirewall.kt`, `EmergencyManager.kt`, `LostPhoneManager.kt`, `BatteryHelper.kt`, `AlarmScheduler.kt`, `NightlyConsolidation.kt` | Authentification, urgence, batterie, alarmes — API Android classiques. |
| Contacts / apps / relances | `ContactsRepository.kt`, `AppsRepository.kt`, `RelanceRepository.kt` | Lecture/écriture de données locales (SQLite/SharedPreferences). |

## Comment vérifier soi-même en 5 secondes

```
grep -rl "LocalLlamaHelper" app/src/main/java/com/vanelle/os
```

Cette commande liste les **5 seuls fichiers** du projet qui touchent à
l'IA de près ou de loin. Tout fichier absent de cette liste ne fera
jamais appel au modèle, quelle que soit la fonctionnalité qu'il gère.

## Pourquoi cette séparation est maintenue strictement

- **Fiabilité** : une regex donne toujours le même résultat ; l'IA
  peut varier. Toute commande qui a une syntaxe reconnaissable
  (heure, nom d'app, numéro...) doit rester en logique système.
- **Vitesse et disponibilité** : la logique système répond
  instantanément, même si le modèle n'est pas encore téléchargé/chargé
  en mémoire (voir l'historique des bugs "IA absente").
- **Maintenabilité** : quand un bug de compréhension est signalé, ce
  tableau permet de savoir en un coup d'œil s'il faut corriger une
  regex (`CommandParser.kt`) ou ajuster un prompt IA
  (`CommandInterpreter.kt`).

Quand une nouvelle fonctionnalité est ajoutée : se demander d'abord
"est-ce qu'une règle fixe suffit ?". Si oui → logique système. Si non
(langage libre, résumé, reformulation) → passer par
`LocalLlamaHelper.get(context)`, et ajouter la ligne correspondante
dans ce document.
