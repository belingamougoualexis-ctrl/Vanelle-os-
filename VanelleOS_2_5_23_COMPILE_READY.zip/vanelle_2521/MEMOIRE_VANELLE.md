# Mémoire Vanelle — court terme / long terme

Calibrée pour **n_ctx 384–768** et CPU mobile : sélectif > exhaustif.

## Court terme (fil courant)
- **4–6 tours** bruts injectés (`MemoryEngine.SHORT_TURNS`)
- Au-delà → résumé extractif (~220 car.) en tête de prompt
- Pas de roman dans le KV cache

## Long terme (entre sessions)
| Stockage | Contenu |
|----------|---------|
| Profil (MemoryVault) | prénom, ville, projet, ton… |
| `memory_facts` | faits durables + catégorie + date |
| FeedbackMemory | corrections utilisateur |

## Filtrage
On **ne stocke pas** : questions ponctuelles, commandes, salutations.
On **stocke** : préférences, identité, projets, « souviens-toi que… ».

## Injection (budget)
```
Profil + ~6 faits (~420 car.)
+ résumé passé (~220)
+ feedback (~180)
+ 6 tours récents (~700)
≤ ~1200 caractères
```

## Après chaque message user
1. `learnFromUserUtterance` / `MemoryEngine.extractFromUserMessage`
2. INSERT si durable
3. `condenseIfNeeded` si trop de faits

## Fichiers
- `MemoryEngine.kt` — cœur
- `RelationalMemory.kt` — profil + dialogue + bridge
- `ChatHistory.kt` — UI Conversation
- `FeedbackMemory.kt` — corrections
