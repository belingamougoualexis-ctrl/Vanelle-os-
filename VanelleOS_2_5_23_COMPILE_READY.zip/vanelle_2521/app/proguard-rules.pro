# Règles ProGuard/R8 — VanelleOS

# --- Bibliothèque IA locale (llamacpp-kotlin) ---
# LocalLlamaHelper.resolveLlamaClass() charge cette classe UNIQUEMENT par
# réflexion (Class.forName sur plusieurs noms candidats, aucune référence
# statique dans le code). Sans ces règles, R8 supprime ou renomme la
# bibliothèque en variante "modern" release, et l'IA locale échoue au
# chargement pour tout le monde malgré une variante/APK correcte.
-keep class org.nehuatl.llamacpp.** { *; }
-keep class io.github.ljcamargo.llamacpp.** { *; }
-keep class io.github.ljcamargo.llamacppkotlin.** { *; }
-keep class com.ljcamargo.llamacpp.** { *; }
-keepclassmembers class * {
    public <init>(android.content.ContentResolver, kotlinx.coroutines.CoroutineScope, kotlinx.coroutines.flow.MutableSharedFlow);
}
-keepclassmembers class * {
    public java.lang.Object load(...);
}

# Ne pas avertir sur les classes optionnelles de la lib native / JNI
-dontwarn org.nehuatl.llamacpp.**
-dontwarn io.github.ljcamargo.**
-dontwarn com.ljcamargo.llamacpp.**

# --- Réflexion générique utilisée par LocalLlamaHelper (getMethod / getConstructor) ---
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes *Annotation*

# --- Kotlin coroutines / SharedFlow (utilisés dans les signatures réfléchies) ---
-dontwarn kotlinx.coroutines.**
-keep class kotlin.jvm.functions.Function1 { *; }

# --- Enums (utilisés par ex. par LLMEvent.Loaded / LLMEvent.Error) ---
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# --- Composants Android déjà déclarés dans le manifest (garde-fou standard) ---
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider

# --- Parcelable / Serializable (sécurité générale) ---
-keepclassmembers class * implements android.os.Parcelable {
    public static final ** CREATOR;
}
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
}

# --- Ne pas obscurcir les noms de fichiers/lignes pour des traces de crash lisibles ---
-keepattributes SourceFile, LineNumberTable
-renamesourcefileattribute SourceFile


# --- Bibliothèques natives JNI (llama.cpp) ---
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class **.R$* { *; }
# Empêcher R8 de supprimer les classes utilisées uniquement par réflexion
-keep class org.nehuatl.** { *; }
-keep class io.github.ljcamargo.** { *; }
