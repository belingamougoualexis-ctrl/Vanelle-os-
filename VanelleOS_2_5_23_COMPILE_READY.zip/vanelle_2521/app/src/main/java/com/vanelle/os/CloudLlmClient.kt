package com.vanelle.os

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Client cloud compatible OpenAI Chat Completions
 * (OpenAI, Groq, Together, OpenRouter, proxy auto-hébergé, etc.).
 *
 * Secrets dans MemoryVault (EncryptedSharedPreferences).
 * Jamais de clé en clair dans les logs.
 */
object CloudLlmClient {
    private const val KEY_API = "cloud_llm_api_key"
    private const val KEY_BASE = "cloud_llm_base_url"
    private const val KEY_MODEL = "cloud_llm_model"

    private const val DEFAULT_BASE = "https://api.openai.com/v1"
    private const val DEFAULT_MODEL = "gpt-4o-mini"

    fun isConfigured(c: Context): Boolean {
        val key = apiKey(c)
        return !key.isNullOrBlank() && key.length >= 8
    }

    fun apiKey(c: Context): String? = try {
        MemoryVault(c).get(KEY_API)?.takeIf { it.isNotBlank() }
    } catch (_: Exception) {
        null
    }

    fun baseUrl(c: Context): String = try {
        MemoryVault(c).get(KEY_BASE)?.takeIf { it.isNotBlank() } ?: DEFAULT_BASE
    } catch (_: Exception) {
        DEFAULT_BASE
    }

    fun model(c: Context): String = try {
        MemoryVault(c).get(KEY_MODEL)?.takeIf { it.isNotBlank() } ?: DEFAULT_MODEL
    } catch (_: Exception) {
        DEFAULT_MODEL
    }

    fun configure(c: Context, apiKey: String, baseUrl: String? = null, model: String? = null) {
        val vault = MemoryVault(c)
        vault.save(KEY_API, apiKey.trim())
        if (!baseUrl.isNullOrBlank()) vault.save(KEY_BASE, baseUrl.trim().trimEnd('/'))
        if (!model.isNullOrBlank()) vault.save(KEY_MODEL, model.trim())
    }

    fun clear(c: Context) {
        try {
            val vault = MemoryVault(c)
            vault.save(KEY_API, "")
            vault.save(KEY_BASE, "")
            vault.save(KEY_MODEL, "")
        } catch (_: Exception) {}
    }

    /**
     * Appel chat.completions. Retourne le texte assistant ou null en échec.
     */
    suspend fun complete(
        c: Context,
        userMessage: String,
        systemPrompt: String,
        extraContext: String = "",
        maxTokens: Int = 500
    ): String? = withContext(Dispatchers.IO) {
        if (!isConfigured(c)) return@withContext null
        if (!PrivacyFirewall.allowWeb(c)) return@withContext null
        if (PersonalityPrefs.preferOffline(c)) return@withContext null
        if (!LlamaModelManager.isNetworkAvailable(c)) return@withContext null

        val key = apiKey(c) ?: return@withContext null
        val base = baseUrl(c).trimEnd('/')
        val modelName = model(c)

        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt.take(2000)))
        if (extraContext.isNotBlank()) {
            messages.put(
                JSONObject().put("role", "system")
                    .put("content", "Contexte utilisateur / mémoire :\n${extraContext.take(2500)}")
            )
        }
        messages.put(JSONObject().put("role", "user").put("content", userMessage.take(4000)))

        val body = JSONObject()
            .put("model", modelName)
            .put("messages", messages)
            .put("max_tokens", maxTokens.coerceIn(64, 1200))
            .put("temperature", 0.4)

        try {
            val url = URL("$base/chat/completions")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 60_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer $key")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "VanelleOS/hybrid")
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.readText().orEmpty()
            if (code !in 200..299) {
                android.util.Log.w("VanelleCloud", "HTTP $code ${raw.take(120)}")
                return@withContext null
            }
            val json = JSONObject(raw)
            val content = json.optJSONArray("choices")
                ?.optJSONObject(0)
                ?.optJSONObject("message")
                ?.optString("content")
                ?.trim()
            content?.takeIf { it.isNotBlank() }
        } catch (e: Exception) {
            android.util.Log.w("VanelleCloud", "complete failed: ${e.message}")
            null
        }
    }

    fun vanelleSystemPrompt(c: Context): String =
        PersonalityPrefs.systemTone(c) +
            " Tu es appelée en renfort cloud pour un cas difficile. " +
            "Reste Vanelle : utile, honnête, concise, en français. " +
            "Ne mentionne pas que tu es un modèle cloud sauf si on te le demande."
}
