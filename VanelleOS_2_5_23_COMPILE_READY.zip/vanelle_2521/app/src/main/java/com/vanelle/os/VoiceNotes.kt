package com.vanelle.os
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Notes vocales rapides : dicter → sauvegarder → relire/effacer.
 * Séparé de MemoryEngine (faits durables sur l'utilisateur) et de vault (clé/valeur)
 * car ce sont des notes ponctuelles horodatées, affichées comme une liste.
 */
object VoiceNotes {
    private const val PREFS = "vanelle_voice_notes"
    private const val KEY = "notes_v1"
    private const val MAX_NOTES = 200

    data class Note(val id: Long, val text: String, val ts: Long)

    private fun p(c: Context) = c.getSharedPreferences(PREFS, 0)

    fun all(c: Context): List<Note> {
        return try {
            val arr = JSONArray(p(c).getString(KEY, "[]"))
            val out = mutableListOf<Note>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += Note(o.optLong("id"), o.optString("t"), o.optLong("ts"))
            }
            out.sortedByDescending { it.ts }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun add(c: Context, text: String): Note? {
        val clean = text.trim().take(500)
        if (clean.isEmpty()) return null
        val note = Note(System.currentTimeMillis(), clean, System.currentTimeMillis())
        val current = all(c).toMutableList()
        current.add(0, note)
        val trimmed = current.take(MAX_NOTES)
        save(c, trimmed)
        return note
    }

    fun delete(c: Context, id: Long) {
        val current = all(c).filterNot { it.id == id }
        save(c, current)
    }

    fun clear(c: Context) {
        p(c).edit().remove(KEY).apply()
    }

    fun latest(c: Context): Note? = all(c).firstOrNull()

    private fun save(c: Context, notes: List<Note>) {
        val arr = JSONArray()
        for (n in notes) {
            arr.put(JSONObject().apply {
                put("id", n.id); put("t", n.text); put("ts", n.ts)
            })
        }
        p(c).edit().putString(KEY, arr.toString()).apply()
    }
}
