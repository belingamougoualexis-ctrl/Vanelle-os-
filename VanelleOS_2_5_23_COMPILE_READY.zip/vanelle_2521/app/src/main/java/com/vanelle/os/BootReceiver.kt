package com.vanelle.os

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        val action = i?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED &&
            action != Intent.ACTION_LOCKED_BOOT_COMPLETED
        ) return

        try { AlarmScheduler.rescheduleAll(c) } catch (_: Exception) {}
        try { NightlyConsolidation.schedule(c) } catch (_: Exception) {}

        // Reprendre automatiquement téléchargement / chargement de l'IA
        // sans intervention de l'utilisateur (boot, mise à jour APK).
        try {
            if (!DataDownloadService.isUsable(c)) {
                DataDownloadService.start(c)
            } else if (LlamaModelManager.isReady(c)) {
                // Déjà téléchargé : s'assurer que le modèle est en mémoire au prochain usage
                // (warmUp léger via le service si pas encore chargé)
                if (!try {
                        LocalLlamaHelper.get(c).isLoaded()
                    } catch (_: Exception) { false }) {
                    DataDownloadService.start(c)
                }
            }
        } catch (_: Exception) {}

        // Ne PAS démarrer le service micro depuis BOOT (interdit Android 14+).
    }
}
