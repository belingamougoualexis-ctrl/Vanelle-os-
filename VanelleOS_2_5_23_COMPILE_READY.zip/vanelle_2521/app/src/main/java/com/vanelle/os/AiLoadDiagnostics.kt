package com.vanelle.os

import android.app.ActivityManager
import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Journal persistant des tentatives de chargement/génération de l'IA locale.
 * Permet d'afficher à l'utilisateur la cause réelle d'un échec (RAM insuffisante,
 * modèle corrompu, bibliothèque absente, timeout, exception...) au lieu d'un
 * message générique "IA non chargée".
 */
object AiLoadDiagnostics {

    private const val TAG = "VanelleLlama"
    private const val FILE_NAME = "ai_load_diagnostics.log"
    private const val MAX_ENTRIES = 25

    private val mutex = Mutex()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    private fun file(context: Context): File = File(context.filesDir, FILE_NAME)

    private fun deviceRamInfo(context: Context): String {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            val totalMb = info.totalMem / (1024 * 1024)
            val availMb = info.availMem / (1024 * 1024)
            "RAM totale=${totalMb}Mo, disponible=${availMb}Mo, faible=${info.lowMemory}"
        } catch (e: Exception) {
            "RAM inconnue (${e.message ?: e.javaClass.simpleName})"
        }
    }

    private fun appendEntry(context: Context, line: String) {
        scope.launch {
            mutex.withLock {
                try {
                    val f = file(context)
                    val existing = if (f.exists()) f.readLines() else emptyList()
                    val updated = (existing + line).takeLast(MAX_ENTRIES)
                    f.writeText(updated.joinToString("\n"))
                } catch (e: Exception) {
                    Log.w(TAG, "AiLoadDiagnostics: écriture journal impossible: ${e.message}")
                }
            }
        }
    }

    /** Enregistre un succès de chargement ou de génération. */
    fun logSuccess(context: Context, message: String) {
        val line = "[${dateFormat.format(Date())}] OK — $message"
        Log.i(TAG, line)
        appendEntry(context, line)
    }

    /** Enregistre un échec, avec la cause exacte. `attempt` est optionnel (numéro de tentative). */
    fun logFailure(context: Context, message: String, attempt: Int? = null) {
        val suffix = if (attempt != null) " (tentative $attempt)" else ""
        val line = "[${dateFormat.format(Date())}] ÉCHEC$suffix — $message — ${deviceRamInfo(context)}"
        Log.e(TAG, line)
        appendEntry(context, line)
    }

    /** Lit le journal complet (entrées les plus anciennes en premier). */
    fun readLog(context: Context): List<String> {
        return try {
            val f = file(context)
            if (f.exists()) f.readLines() else emptyList()
        } catch (e: Exception) {
            listOf("Journal illisible: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Efface le journal. */
    fun clear(context: Context) {
        try {
            val f = file(context)
            if (f.exists()) f.delete()
        } catch (e: Exception) {
            Log.w(TAG, "AiLoadDiagnostics: effacement impossible: ${e.message}")
        }
    }

    /** True si au moins un échec a été enregistré. */
    fun hasFailure(context: Context): Boolean =
        readLog(context).any { it.contains("ÉCHEC") }
}
