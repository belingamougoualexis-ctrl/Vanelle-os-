package com.vanelle.os
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Réponses web réelles uniquement (Wikipedia FR + DuckDuckGo).
 * Les résultats proviennent uniquement des services interrogés.
 */
class FreeAIHelper(private val context: Context) {

    /**
     * Récupère des faits bruts (Wikipédia FR ou résumé DuckDuckGo), sans mise
     * en forme — destiné à servir de contexte à l'IA locale pour qu'elle
     * reformule avec ses propres mots, jamais à être lu tel quel à l'utilisateur.
     */
    suspend fun fetchRawFacts(q0: String): String? = withContext(Dispatchers.IO) {
        val q = q0.trim()
        if (q.isBlank() || !PrivacyFirewall.allowWeb(context)) return@withContext null
        val topic = try {
            ReasoningHelper.searchQueryFor(q)
        } catch (_: Exception) {
            q.replace(
                Regex("(?i)c'est quoi|c est quoi|qu'est-ce que|qui est|dis[- ]moi|explique[- ]moi|parle[- ]moi de|vanelle|quel est|quelle est"),
                ""
            ).trim()
        }.take(100).ifEmpty { q.take(40) }
        fetchWiki(topic) ?: fetchDDG(topic)
    }


    suspend fun answer(q0: String): String = withContext(Dispatchers.IO) {
        val q = q0.trim()
        if (q.isBlank()) return@withContext "Je n'ai rien entendu, tu peux répéter ?"
        if (!PrivacyFirewall.allowWeb(context)) {
            return@withContext "Pare-feu confidentialité : accès web bloqué. Active le web dans les réglages privacy ou désactive le lockdown."
        }

        val topic = try {
            ReasoningHelper.searchQueryFor(q)
        } catch (_: Exception) {
            q.replace(
                Regex("(?i)c'est quoi|c est quoi|qu'est-ce que|qui est|dis[- ]moi|explique[- ]moi|parle[- ]moi de|vanelle|quel est|quelle est"),
                ""
            ).trim()
        }.take(100).ifEmpty { q.take(40) }

        val wiki = fetchWiki(topic)
        if (wiki != null) {
            val t = wiki.trim()
            return@withContext if (t.length > 420) t.take(417).trimEnd() + "…" else t
        }

        val ddg = fetchDDG(topic)
        if (ddg != null) {
            val t = ddg.trim()
            return@withContext if (t.length > 420) t.take(417).trimEnd() + "…" else t
        }

        // Distinguer : pas de résultat utile ≠ pas d'Internet
        val online = try {
            LlamaModelManager.isNetworkAvailable(context)
        } catch (_: Exception) {
            true // en cas de doute, ne pas accuser le réseau
        }
        if (!online) {
            return@withContext "Pas de connexion Internet détectée pour cette recherche. Vérifie le Wi-Fi ou les données mobiles, puis réessaie."
        }
        // Pas de résultat utile des APIs — réponse parlée, jamais d'ouverture navigateur.
        "Je n'ai pas trouvé d'info claire sur « $topic ». Reformule un peu ta question, j'essaierai autrement."
    }

    private fun fetchWiki(t: String): String? = try {
        val encoded = URLEncoder.encode(t, "UTF-8").replace("+", "%20")
        val u = URL("https://fr.wikipedia.org/api/rest_v1/page/summary/$encoded")
        val c = u.openConnection() as HttpURLConnection
        // User-Agent plus standard (certains CDN bloquent les UA trop exotiques)
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 VanelleOS/1.9")
        c.setRequestProperty("Accept", "application/json")
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.instanceFollowRedirects = true
        if (c.responseCode == 200) {
            val o = JSONObject(c.inputStream.bufferedReader().readText())
            val e = o.optString("extract")
            if (e.isNotBlank()) e else null
        } else null
    } catch (_: Exception) { null }

    private fun fetchDDG(t: String): String? = try {
        val u = URL("https://api.duckduckgo.com/?q=${URLEncoder.encode(t, "UTF-8")}&format=json&no_html=1&skip_disambig=1")
        val c = u.openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 VanelleOS/1.9")
        c.setRequestProperty("Accept", "application/json")
        c.connectTimeout = 8000
        c.readTimeout = 8000
        if (c.responseCode == 200) {
            val o = JSONObject(c.inputStream.bufferedReader().readText())
            val a = o.optString("AbstractText")
            if (a.isNotBlank()) a else null
        } else null
    } catch (_: Exception) { null }
}
