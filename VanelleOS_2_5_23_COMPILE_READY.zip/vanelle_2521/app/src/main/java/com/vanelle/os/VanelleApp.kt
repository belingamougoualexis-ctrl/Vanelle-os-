package com.vanelle.os

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class VanelleApp : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        CrashLogger.install(this)
        try { UserDataSnapshot.restoreIfNeeded(this) } catch (_: Exception) {}
        appScope.launch {
            try {
                NightlyConsolidation.schedule(this@VanelleApp)
            } catch (_: Exception) {}
            try { UserDataSnapshot.save(this@VanelleApp) } catch (_: Exception) {}

            // Téléchargement / chargement 100 % automatique — jamais besoin de relancer à la main.
            try {
                if (!DataDownloadService.isUsable(this@VanelleApp)) {
                    DataDownloadService.start(this@VanelleApp)
                } else if (LlamaModelManager.isReady(this@VanelleApp)) {
                    LocalLlamaHelper.get(this@VanelleApp).resetLoadFailure()
                    LocalLlamaHelper.get(this@VanelleApp).warmUp()
                }
            } catch (_: Exception) {}
        }
    }
}
