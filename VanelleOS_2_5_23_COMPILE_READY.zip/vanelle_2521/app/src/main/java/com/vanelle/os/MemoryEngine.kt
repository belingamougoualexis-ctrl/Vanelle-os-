package com.vanelle.os

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Mémoire structurée Vanelle (court terme + long terme), calibrée pour n_ctx bas.
 *
 * Court terme : 4–6 derniers tours bruts + résumé extractif du reste.
 * Long terme : faits durables (catégorie, date) — pas chaque question ponctuelle.
 * Injection : budget caractères strict pour ne pas ralentir le CPU.
 */
object MemoryEngine {

    private const val PREFS = "vanelle_memory_facts"
    private const val KEY = "facts_v2"
    private const val MAX_FACTS = 40
    private const val INJECT_FACTS = 6
    private const val FACT_CHAR = 90

    /** Budget total contexte mémoire (hors dialogue récent). */
    const val LONG_TERM_BUDGET = 900
    /** Tours bruts injectés (user+assistant confondus). */
    const val SHORT_TURNS = 12
    const val SHORT_DIALOG_CHARS = 1800
    const val SUMMARY_CHARS = 500

    data class Fact(
        val content: String,
        val category: String,
        val ts: Long
    )

    private fun p(c: Context) = c.getSharedPreferences(PREFS, 0)

    fun allFacts(c: Context): List<Fact> {
        return try {
            val arr = JSONArray(p(c).getString(KEY, "[]"))
            val out = mutableListOf<Fact>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += Fact(
                    o.optString("c"),
                    o.optString("cat", "general"),
                    o.optLong("ts", 0L)
                )
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun insertFact(c: Context, content: String, category: String) {
        val clean = content.trim().take(180)
        if (clean.length < 6) return
        if (!isDurableCandidate(clean)) return
        // Dédup approximative
        val existing = allFacts(c)
        if (existing.any { similar(it.content, clean) }) return
        try {
            val arr = JSONArray(p(c).getString(KEY, "[]"))
            arr.put(
                JSONObject()
                    .put("c", clean)
                    .put("cat", category.take(24))
                    .put("ts", System.currentTimeMillis())
            )
            val trimmed = JSONArray()
            val start = (arr.length() - MAX_FACTS).coerceAtLeast(0)
            for (i in start until arr.length()) trimmed.put(arr.get(i))
            p(c).edit().putString(KEY, trimmed.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun similar(a: String, b: String): Boolean {
        val x = a.lowercase().take(40)
        val y = b.lowercase().take(40)
        return x == y || x.contains(y) || y.contains(x)
    }

    /**
     * Filtre : ne garde que ce qui semble stable (préférence, identité, projet…),
     * pas une question ponctuelle.
     */
    fun isDurableCandidate(text: String): Boolean {
        val t = text.lowercase().trim()
        if (t.length < 6 || t.length > 180) return false
        // Rejette questions / commandes ponctuelles
        if (t.endsWith("?") || t.startsWith("ouvre ") || t.startsWith("lance ") ||
            t.startsWith("appelle ") || t.startsWith("cherche ") || t.startsWith("traduis ")
        ) return false
        if (Regex("""(?i)^(bonjour|salut|ok|merci|oui|non|d'accord)\b""").containsMatchIn(t) && t.length < 20)
            return false
        val durableHints = listOf(
            "préfère", "j'aime", "je déteste", "je n'aime", "j'habite", "je vis",
            "je m'appelle", "appelle-moi", "mon projet", "je travaille", "je bosse",
            "ma ville", "mon métier", "je suis", "toujours", "jamais", "habitude",
            "rappelle", "souviens", "n'oublie pas", "retenir"
        )
        return durableHints.any { t.contains(it) }
    }

    /**
     * Extraction déterministe (0 token LLM).
     * Ne rappelle PAS learnFromUserUtterance (évite boucle récursive).
     */
    fun extractFromUserMessage(c: Context, userText: String) {
        if (PersonalityPrefs.isGuestMode(c)) return
        val t = userText.trim()

        Regex("""(?i)(?:souviens[- ]toi que|n'oublie pas que|retenir que|note que)\s+(.{8,140})""")
            .find(t)?.groupValues?.getOrNull(1)?.let {
                insertFact(c, it.trim().trimEnd('.', '!'), "explicit")
            }
        Regex("""(?i)(?:je préfère|j'aime bien|j'aime|je déteste|je n'aime pas)\s+(.{5,120})""")
            .find(t)?.groupValues?.getOrNull(1)?.let {
                insertFact(c, it.trim().trimEnd('.', '!'), "preference")
            }
        Regex("""(?i)(?:mon projet(?: c'est)?|je travaille sur|je bosse sur)\s+(.{5,120})""")
            .find(t)?.groupValues?.getOrNull(1)?.let {
                insertFact(c, it.trim().trimEnd('.', '!'), "project")
            }
        Regex("""(?i)(?:j'habite (?:à|au|en)|je vis (?:à|au|en)|ma ville c'est)\s+([A-Za-zÀ-ÿ\-]{2,40})""")
            .find(t)?.groupValues?.getOrNull(1)?.let {
                insertFact(c, "Ville : ${it.replaceFirstChar { ch -> ch.uppercase() }}", "profile")
            }
    }

    /** Bloc long terme compact pour le prompt. */
    fun longTermBlock(c: Context, maxChars: Int = LONG_TERM_BUDGET): String {
        if (PersonalityPrefs.isGuestMode(c)) return ""
        val sb = StringBuilder()
        try {
            val rel = RelationalMemory(c)
            val prenom = rel.displayName()
            if (prenom.isNotBlank()) {
                sb.append("Prénom: ").append(prenom).append(". ")
            }
            val profile = rel.getProfileSummary().take(160)
            if (profile.isNotBlank()) sb.append("Profil: ").append(profile).append(". ")
        } catch (_: Exception) {}

        val facts = allFacts(c).asReversed().take(INJECT_FACTS)
        if (facts.isNotEmpty()) {
            sb.append("Faits durables: ")
            sb.append(facts.joinToString(" | ") { it.content.take(FACT_CHAR) })
        }
        // Aussi anciens faits RelationalMemory (compat)
        try {
            val legacy = RelationalMemory(c).recentFacts(4)
            if (legacy.isNotEmpty() && sb.length < maxChars - 40) {
                if (facts.isEmpty()) sb.append("Faits: ")
                else sb.append(" | ")
                sb.append(legacy.joinToString(" | ") { it.take(60) })
            }
        } catch (_: Exception) {}

        return sb.toString().trim().take(maxChars)
    }

    /**
     * Contexte complet optimisé vitesse :
     * long terme (sélectif) + résumé court + 4–6 tours récents.
     */
    fun promptContext(c: Context, maxChars: Int = AIConfiguration.profile(c).contextChars.coerceAtMost(6500)): String {
        if (PersonalityPrefs.isGuestMode(c)) return ""
        val sb = StringBuilder()
        val longTerm = longTermBlock(c, LONG_TERM_BUDGET)
        if (longTerm.isNotBlank()) sb.append(longTerm)

        try {
            val rel = RelationalMemory(c)
            val summary = rel.dialogSummary().take(SUMMARY_CHARS)
            if (summary.isNotBlank()) {
                if (sb.isNotEmpty()) sb.append("\n")
                sb.append("Résumé passé: ").append(summary)
            }
            val feedback = FeedbackMemory.asPromptBlock(c, maxChars = 420)
            if (feedback.isNotBlank()) {
                if (sb.isNotEmpty()) sb.append("\n")
                sb.append(feedback)
            }
            val budget = (maxChars - sb.length).coerceAtLeast(420)
            val dialog = rel.recentDialog(SHORT_TURNS, maxChars = budget.coerceAtMost(SHORT_DIALOG_CHARS))
            if (dialog.isNotBlank()) {
                if (sb.isNotEmpty()) sb.append("\n")
                sb.append("Fil récent:\n").append(dialog)
            }
        } catch (_: Exception) {}

        return sb.toString().trim().take(maxChars)
    }

    /** Condensation périodique des faits trop nombreux (fusion simple). */
    fun condenseIfNeeded(c: Context) {
        val facts = allFacts(c)
        if (facts.size < 28) return
        // Garde les 20 plus récents + 5 plus anciens divers
        val recent = facts.takeLast(20)
        val older = facts.dropLast(20).takeLast(5)
        val merged = older + recent
        try {
            val arr = JSONArray()
            merged.forEach { f ->
                arr.put(
                    JSONObject().put("c", f.content).put("cat", f.category).put("ts", f.ts)
                )
            }
            p(c).edit().putString(KEY, arr.toString()).apply()
        } catch (_: Exception) {}
    }
}
