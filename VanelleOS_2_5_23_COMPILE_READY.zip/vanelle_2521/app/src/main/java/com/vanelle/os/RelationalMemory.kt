package com.vanelle.os
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Mémoire relationnelle : profil, faits, humeurs, contexte de conversation.
 * Stockage chiffré via MemoryVault + prefs structurées.
 */
class RelationalMemory(private val c: Context) {
    private val vault = MemoryVault(c)
    private val prefs = c.getSharedPreferences("vanelle_relational", 0)

    fun setProfileField(key: String, value: String) {
        vault.save("profile_$key", value.trim())
        logEvent("memory", "Profil: $key")
    }

    fun getProfileField(key: String): String? = vault.get("profile_$key")

    fun getProfileSummary(): String {
        val keys = listOf("prenom", "ville", "travail", "humeur", "projet", "preference_ton")
        val parts = keys.mapNotNull { k ->
            getProfileField(k)?.let { v -> if (v.isNotBlank()) "$k: $v" else null }
        }
        return parts.joinToString(". ")
    }

    fun rememberFact(fact: String) {
        val arr = JSONArray(prefs.getString("facts", "[]"))
        arr.put(JSONObject().put("t", System.currentTimeMillis()).put("f", fact.take(300)))
        // garde les 40 derniers
        val trimmed = JSONArray()
        val start = (arr.length() - 40).coerceAtLeast(0)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        prefs.edit().putString("facts", trimmed.toString()).apply()
        try { UserDataSnapshot.save(c) } catch (_: Exception) {}
        vault.save("fact_${System.currentTimeMillis()}", fact.take(300))
        logEvent("memory", "Fait: ${fact.take(80)}")
    }

    fun recentFacts(limit: Int = 8): List<String> {
        val arr = JSONArray(prefs.getString("facts", "[]"))
        val out = mutableListOf<String>()
        for (i in (arr.length() - 1) downTo 0) {
            if (out.size >= limit) break
            out.add(arr.getJSONObject(i).optString("f"))
        }
        return out
    }

    fun setMood(mood: String) {
        setProfileField("humeur", mood)
        prefs.edit().putLong("mood_ts", System.currentTimeMillis()).apply()
    }

    fun displayName(): String =
        getProfileField("prenom")?.takeIf { it.isNotBlank() }?.trim() ?: ""

    /**
     * Texte à faire dire à la mascotte : uniquement le prénom en tête, puis la réponse.
     * Jamais « je m'appelle … ».
     */
    fun withSpokenName(answer: String): String {
        val prenom = displayName()
        var body = answer.trim()
        // Nettoie si le modèle a glissé une formule du type « je m'appelle X »
        body = body.replace(Regex("(?i)je m['']appelle\\s+\\w+[,.]?\\s*"), "")
            .replace(Regex("(?i)enchant[ée]e?[,.]?\\s*"), "")
            .trim()
        if (prenom.isBlank()) return body
        // Évite « Paul, Paul, … »
        val lower = body.lowercase()
        if (lower.startsWith(prenom.lowercase() + ",") || lower.startsWith(prenom.lowercase() + " ")) {
            return body
        }
        return "$prenom, $body"
    }

    fun profilePhotoFile(): File = File(c.filesDir, "profile_photo.jpg")

    fun hasProfilePhoto(): Boolean = profilePhotoFile().let { it.exists() && it.length() > 0 }

    fun saveProfilePhotoFromUri(uri: android.net.Uri): Boolean {
        return try {
            c.contentResolver.openInputStream(uri)?.use { input ->
                profilePhotoFile().outputStream().use { output -> input.copyTo(output) }
            }
            hasProfilePhoto()
        } catch (_: Exception) {
            false
        }
    }

    fun clearProfilePhoto() {
        try { profilePhotoFile().delete() } catch (_: Exception) {}
    }

    /** Contexte injecté dans le prompt IA — profil + faits (sans l'historique dialogue). */
    fun contextForAi(): String {
        if (PersonalityPrefs.isGuestMode(c)) return ""
        val sb = StringBuilder()
        val prenom = displayName()
        if (prenom.isNotBlank()) {
            sb.append("Prénom de l'utilisateur : ").append(prenom).append(". ")
            sb.append("Utilise seulement le prénom ").append(prenom).append(". Ne dis jamais « je m'appelle ». ")
        }
        val profile = getProfileSummary().take(240)
        if (profile.isNotBlank()) sb.append("Profil: ").append(profile).append(". ")
        val facts = recentFacts(8)
        if (facts.isNotEmpty()) {
            sb.append("Faits mémorisés: ").append(facts.joinToString(" | ") { it.take(100) })
        }
        return sb.toString().trim().take(550)
    }

    /**
     * Contexte complet via MemoryEngine :
     * long terme sélectif + résumé + 4–6 tours (budget serré pour n_ctx / CPU).
     */
    fun fullContextForAi(dialogTurns: Int = MemoryEngine.SHORT_TURNS, maxChars: Int = 900): String {
        return try {
            MemoryEngine.promptContext(c, maxChars = maxChars)
        } catch (_: Exception) {
            // Fallback minimal
            contextForAi().take(maxChars)
        }
    }

    /** Historique de dialogue (multi-tours) pour le cerveau Llama. */
    fun addTurn(role: String, text: String) {
        if (PersonalityPrefs.isGuestMode(c)) return
        val clean = text.trim()
        if (clean.isBlank()) return
        val arr = JSONArray(prefs.getString("dialog", "[]"))
        // Court terme : au-delà de ~6 échanges, compresser le vieux en résumé
        if (arr.length() >= 14) {
            compressOldDialogIntoSummary(arr)
        }
        arr.put(
            JSONObject()
                .put("r", role.take(12))
                .put("t", clean.take(400))
                .put("ts", System.currentTimeMillis())
        )
        val trimmed = JSONArray()
        val start = (arr.length() - 60).coerceAtLeast(0)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        prefs.edit().putString("dialog", trimmed.toString()).apply()
        try { ChatHistory.add(c, role, clean, alsoRelational = false) } catch (_: Exception) {}
        try { UserDataSnapshot.save(c) } catch (_: Exception) {}
    }

    /** Résumé extractif des vieux tours (sans LLM — déterministe, gratuit). */
    fun dialogSummary(): String = prefs.getString("dialog_summary", "")?.trim().orEmpty()

    private fun compressOldDialogIntoSummary(arr: JSONArray) {
        try {
            val keepRecent = MemoryEngine.SHORT_TURNS
            if (arr.length() <= keepRecent + 2) return
            val toCompress = (arr.length() - keepRecent).coerceAtMost(16)
            val bits = mutableListOf<String>()
            for (i in 0 until toCompress) {
                val o = arr.getJSONObject(i)
                val role = if (o.optString("r") == "user") "U" else "V"
                val t = o.optString("t").trim().take(55)
                if (t.isNotBlank()) bits += "$role:$t"
            }
            if (bits.isEmpty()) return
            val prev = dialogSummary()
            val chunk = bits.joinToString(" · ")
            val merged = (if (prev.isNotBlank()) "$prev · $chunk" else chunk).take(MemoryEngine.SUMMARY_CHARS)
            prefs.edit().putString("dialog_summary", merged).apply()
            // Réécrit le tableau sans les tours compressés
            val kept = JSONArray()
            for (i in toCompress until arr.length()) kept.put(arr.get(i))
            // Mutate arr in place for caller
            while (arr.length() > 0) arr.remove(0)
            for (i in 0 until kept.length()) arr.put(kept.get(i))
        } catch (_: Exception) {}
    }

    /**
     * @param limit nombre de tours (user+assistant)
     * @param maxChars budget caractères (n_ctx limité sur mobile)
     */
    fun recentDialog(limit: Int = 12, maxChars: Int = 1400): String {
        if (PersonalityPrefs.isGuestMode(c)) return ""
        val arr = JSONArray(prefs.getString("dialog", "[]"))
        if (arr.length() == 0) return ""
        val from = (arr.length() - limit).coerceAtLeast(0)
        // Priorise les tours les plus récents dans le budget
        val lines = mutableListOf<String>()
        var used = 0
        for (i in (arr.length() - 1) downTo from) {
            val o = arr.getJSONObject(i)
            val role = if (o.optString("r") == "user") "Utilisateur" else "Vanelle"
            val content = o.optString("t").trim()
            if (content.isBlank()) continue
            val line = "$role: $content"
            if (used + line.length + 1 > maxChars && lines.isNotEmpty()) break
            lines.add(0, line)
            used += line.length + 1
        }
        return lines.joinToString("\n").trim()
    }

    fun clearDialog() {
        prefs.edit().remove("dialog").apply()
    }

    /**
     * Extraction légère de préférences / identité depuis un message utilisateur.
     * Mémoire persistante = vrai différenciateur vs modèle cloud amnésique.
     */
    fun learnFromUserUtterance(text: String) {
        if (PersonalityPrefs.isGuestMode(c)) return
        val t = text.trim()
        if (t.length < 4) return
        Regex(
            """(?i)(?:je m['']appelle|appelle[- ]moi|mon prénom c['']est|mon prénom est)\s+([A-Za-zÀ-ÿ]{2,20})"""
        ).find(t)?.groupValues?.getOrNull(1)?.let { name ->
            if (displayName().isBlank() || !displayName().equals(name, ignoreCase = true)) {
                setProfileField("prenom", name.replaceFirstChar { it.uppercase() })
            }
        }
        Regex("""(?i)(?:je préfère|j['']aime bien|j['']aime|je déteste|je n['']aime pas)\s+(.{5,120})""")
            .find(t)?.groupValues?.getOrNull(1)?.let { pref ->
                val clean = pref.trim().trimEnd('.', '!', '?')
                if (clean.length in 5..120) {
                    rememberFact(clean)
                    MemoryEngine.insertFact(c, clean, "preference")
                }
            }
        Regex("""(?i)(?:mon projet(?: c['']est)?|je travaille sur|je bosse sur)\s+(.{5,120})""")
            .find(t)?.groupValues?.getOrNull(1)?.let { proj ->
                val p = proj.trim().trimEnd('.', '!', '?').take(120)
                setProfileField("projet", p)
                MemoryEngine.insertFact(c, "Projet: $p", "project")
            }
        Regex("""(?i)(?:j['']habite (?:à|au|en)|je vis (?:à|au|en)|ma ville c['']est)\s+([A-Za-zÀ-ÿ\-]{2,40})""")
            .find(t)?.groupValues?.getOrNull(1)?.let { ville ->
                val v = ville.replaceFirstChar { it.uppercase() }
                setProfileField("ville", v)
                MemoryEngine.insertFact(c, "Ville: $v", "profile")
            }
        // Délègue aussi extraction explicite (« souviens-toi que… »)
        try { MemoryEngine.extractFromUserMessage(c, t) } catch (_: Exception) {}
        try { MemoryEngine.condenseIfNeeded(c) } catch (_: Exception) {}
    }

    fun clearAll() {
        vault.clear()
        prefs.edit().clear().apply()
        logEvent("memory", "Mémoire effacée")
    }

    private fun logEvent(type: String, detail: String) {
        ActivityLog.add(c, type, detail)
    }
}
