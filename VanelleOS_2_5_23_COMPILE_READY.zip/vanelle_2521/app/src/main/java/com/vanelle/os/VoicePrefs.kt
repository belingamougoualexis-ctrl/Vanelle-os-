package com.vanelle.os

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/**
 * Personnalisation de la voix IA (TTS système) :
 * débit, hauteur, voix française installée sur l'appareil.
 */
object VoicePrefs {
    private const val PREFS = "vanelle_voice"
    private const val KEY_RATE = "speech_rate"   // 0.5 – 2.0
    private const val KEY_PITCH = "pitch"        // 0.5 – 2.0
    private const val KEY_VOICE = "voice_name"   // Voice.name or ""

    private fun p(c: Context) = c.getSharedPreferences(PREFS, 0)

    fun getRate(c: Context): Float = p(c).getFloat(KEY_RATE, 1.0f).coerceIn(0.5f, 2.0f)
    fun getPitch(c: Context): Float = p(c).getFloat(KEY_PITCH, 1.05f).coerceIn(0.5f, 2.0f)
    fun getVoiceName(c: Context): String = p(c).getString(KEY_VOICE, "") ?: ""

    fun setRate(c: Context, v: Float) {
        p(c).edit().putFloat(KEY_RATE, v.coerceIn(0.5f, 2.0f)).apply()
    }
    fun setPitch(c: Context, v: Float) {
        p(c).edit().putFloat(KEY_PITCH, v.coerceIn(0.5f, 2.0f)).apply()
    }
    fun setVoiceName(c: Context, name: String) {
        p(c).edit().putString(KEY_VOICE, name).apply()
    }

    /** Applique débit, hauteur et voix FR préférée sur une instance TTS. */
    fun apply(c: Context, tts: TextToSpeech?) {
        if (tts == null) return
        try {
            tts.language = Locale.FRANCE
            tts.setSpeechRate(getRate(c))
            tts.setPitch(getPitch(c))
            val wanted = getVoiceName(c)
            if (wanted.isNotBlank()) {
                val match = tts.voices?.firstOrNull { it.name == wanted }
                if (match != null) tts.voice = match
            } else {
                // Première voix française de qualité si possible
                val fr = tts.voices
                    ?.filter { v ->
                        val loc = v.locale ?: return@filter false
                        loc.language.equals("fr", true)
                    }
                    ?.sortedByDescending { qualityScore(it) }
                    ?.firstOrNull()
                if (fr != null) tts.voice = fr
            }
        } catch (_: Exception) {}
    }

    private fun qualityScore(v: Voice): Int {
        // Qualité plus élevée = mieux ; évite les voix réseau si possible
        var s = when (v.quality) {
            Voice.QUALITY_VERY_HIGH -> 40
            Voice.QUALITY_HIGH -> 30
            Voice.QUALITY_NORMAL -> 20
            else -> 10
        }
        if (!v.isNetworkConnectionRequired) s += 15
        if (v.locale?.country.equals("FR", true)) s += 5
        return s
    }

    /**
     * Détecte la langue probable d'un texte (heuristique légère, alignée sur celle utilisée
     * pour la réponse texte de l'IA) et renvoie la Locale TTS correspondante.
     */
    fun detectLocale(text: String): Locale {
        val s = text.lowercase()
        if (s.any { it in '\u0600'..'\u06FF' || it in '\u0750'..'\u077F' }) return Locale("ar")
        if (s.any { it in '\u0590'..'\u05FF' }) return Locale("iw")
        if (s.any { it in '\u3040'..'\u30FF' }) return Locale.JAPANESE
        if (s.any { it in '\uAC00'..'\uD7A3' }) return Locale.KOREAN
        if (s.any { it in '\u4e00'..'\u9fff' }) return Locale.CHINESE
        if (s.any { it in '\u0E00'..'\u0E7F' }) return Locale("th")
        if (s.any { it in '\u0900'..'\u097F' }) return Locale("hi")
        if (s.any { it in '\u0370'..'\u03FF' }) return Locale("el")
        if (s.any { it in '\u0400'..'\u04FF' }) return Locale("ru")

        val padded = " ${s.replace(Regex("[^\\p{L}\\s]"), " ")} "
        val scores = linkedMapOf(
            Locale.FRANCE to listOf(" le ", " la ", " les ", " un ", " une ", " des ", " je ", " tu ", " est ", " quoi", " quel", " pour", " avec", " dans", " c'est", " pas "),
            Locale.US to listOf(" the ", " is ", " are ", " what", " how", " why", " please", " can ", " you ", " this ", " that "),
            Locale("es") to listOf(" el ", " la ", " los ", " las ", " que ", " como", " por ", " para ", " esta", " hola"),
            Locale("pt") to listOf(" nao ", " você", " voce", " para ", " como ", " que ", " uma ", " os "),
            Locale.GERMANY to listOf(" der ", " die ", " das ", " und ", " ist ", " was ", " wie ", " nicht "),
            Locale.ITALY to listOf(" che ", " non ", " una ", " per ", " come ", " cosa", " sono "),
            Locale("nl") to listOf(" de ", " het ", " een ", " niet ", " wat ", " hoe ", " jij ", " ben "),
            Locale("tr") to listOf(" bir ", " ve ", " bu ", " için ", " nasıl", " nedir", " değil"),
            Locale("pl") to listOf(" jest ", " nie ", " co ", " jak ", " dla ", " czy ", " tak "),
            Locale("sv") to listOf(" och ", " är ", " inte ", " vad ", " hur ", " jag ", " du "),
            Locale("ro") to listOf(" este ", " nu ", " ce ", " cum ", " pentru", " sunt "),
            Locale("vi") to listOf(" là ", " không", " của ", " với ", " gì ", " bạn ")
        )
        var best = Locale.FRANCE
        var bestScore = 0
        for ((loc, cues) in scores) {
            val sc = cues.count { padded.contains(it) }
            if (sc > bestScore) { bestScore = sc; best = loc }
        }
        return best // par défaut français si rien de clair
    }

    /**
     * Règle la langue TTS sur celle du texte à prononcer juste avant de parler.
     * Repli propre sur le français (voix déjà configurée) si la langue détectée
     * n'a pas de données TTS installées sur l'appareil.
     */
    fun applyForText(c: Context, tts: TextToSpeech?, text: String) {
        if (tts == null || text.isBlank()) return
        val target = detectLocale(text)
        try {
            if (target.language == "fr") {
                apply(c, tts)
                return
            }
            val result = tts.setLanguage(target)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                apply(c, tts) // langue non disponible sur l'appareil → repli français
            } else {
                tts.setSpeechRate(getRate(c))
                tts.setPitch(getPitch(c))
            }
        } catch (_: Exception) {
            try { apply(c, tts) } catch (_: Exception) {}
        }
    }

    /** Liste des voix françaises disponibles (pour l'UI). */
    fun listFrenchVoices(tts: TextToSpeech?): List<Voice> {
        if (tts == null) return emptyList()
        return try {
            tts.voices
                ?.filter { v ->
                    val loc = v.locale ?: return@filter false
                    loc.language.equals("fr", true)
                }
                ?.sortedByDescending { qualityScore(it) }
                ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun labelFor(v: Voice): String {
        val q = when (v.quality) {
            Voice.QUALITY_VERY_HIGH -> "très haute"
            Voice.QUALITY_HIGH -> "haute"
            Voice.QUALITY_NORMAL -> "normale"
            else -> "basique"
        }
        val net = if (v.isNetworkConnectionRequired) " · réseau" else " · hors-ligne"
        val name = v.name.substringAfterLast(":").ifBlank { v.name }
        return "${v.locale?.displayName ?: "Français"} · $q$net · $name"
    }
}
