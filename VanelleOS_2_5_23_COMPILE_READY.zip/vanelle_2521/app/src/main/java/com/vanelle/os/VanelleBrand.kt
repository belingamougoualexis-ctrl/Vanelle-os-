package com.vanelle.os

import android.content.Context
import android.graphics.drawable.GradientDrawable

/**
 * Identité visuelle Vanelle : Bleu Maldives / Blanc / Noir
 * (cohérent Vanelle OS · Studio · Négociation)
 */
object VanelleBrand {
    const val BLUE_MALDIVES = 0xFF007C86.toInt()       // bleu principal
    const val BLUE_MALDIVES_SOFT = 0xFFDDF7F8.toInt()  // fond bleu léger
    const val BLUE_MALDIVES_DEEP = 0xFF00545C.toInt()  // accent
    const val ROSE = BLUE_MALDIVES
    const val ROSE_SOFT = BLUE_MALDIVES_SOFT
    const val ROSE_DEEP = BLUE_MALDIVES_DEEP
    const val WHITE = UiKit.WHITE
    const val BLACK = 0xFF050708.toInt()
    const val GRAY = UiKit.TEXT_MUTED
    const val SURFACE = 0xFFFFFFFF.toInt()

    fun rosePill(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(BLUE_MALDIVES)
            cornerRadius = 24f * d
        }
    }

    fun roseOutline(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(WHITE)
            setStroke((1.5f * d).toInt(), BLUE_MALDIVES)
            cornerRadius = 16f * d
        }
    }

    fun card(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(WHITE)
            setStroke((1f * d).toInt(), 0xFFC8E9EC.toInt())
            cornerRadius = 14f * d
        }
    }

    fun privacyBanner(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(BLUE_MALDIVES_SOFT)
            setStroke((1f * d).toInt(), BLUE_MALDIVES)
            cornerRadius = 12f * d
        }
    }
}
