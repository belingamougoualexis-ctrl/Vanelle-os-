package com.vanelle.os

import android.content.Context

/**
 * Construit le contexte de conversation actif sans mélanger les anciens fils.
 * Le contexte récent est toujours conservé ; quelques messages plus anciens sont
 * récupérés lorsqu'ils partagent des mots significatifs avec la demande courante.
 */
object ConversationContext {
    private val STOP = setOf(
        "je","tu","il","elle","on","nous","vous","ils","elles","me","te","se","ce","ça",
        "cette","ces","le","la","les","un","une","des","du","de","d","au","aux","et","ou",
        "mais","donc","que","qui","quoi","pour","dans","sur","avec","sans","est","sont","as","a",
        "ai","en","y","à","mon","ma","mes","ton","ta","tes","son","sa","ses","leur","leurs",
        "the","a","an","and","or","is","are","to","of","in","on","for","with"
    )

    fun activeThreadBlock(c: Context, userText: String, maxChars: Int = 2600): String {
        val messages = try { ChatHistory.messages(c) } catch (_: Exception) { emptyList() }
        if (messages.isEmpty()) return ""
        val current = tokens(userText)
        val recent = messages.takeLast(12)
        val older = messages.dropLast(recent.size)
            .mapIndexed { index, m -> index to m }
            .mapNotNull { (index, m) ->
                val score = overlap(current, tokens(m.text))
                if (score > 0) score to Pair(index, m) else null
            }
            .sortedWith(compareByDescending<Pair<Int, Pair<Int, ChatHistory.Msg>>> { it.first }
                .thenByDescending { it.second.first })
            .take(4)
            .map { it.second.second }

        val selected = (older + recent).distinctBy { it.ts to it.text }
            .sortedBy { it.ts }
        val sb = StringBuilder("Fil de la conversation active. Utilise-le pour comprendre les suites, pronoms, corrections et références :\n")
        for (m in selected) {
            val role = if (m.role.equals("user", true)) "Utilisateur" else "Vanelle"
            val line = "$role: ${m.text.trim()}"
            if (sb.length + line.length + 1 > maxChars && sb.length > 40) continue
            sb.append(line).append('\n')
        }
        return sb.toString().trim().take(maxChars)
    }

    private fun tokens(text: String): Set<String> = Regex("[\\p{L}\\p{Nd}]{3,}")
        .findAll(text.lowercase())
        .map { it.value }
        .filterNot { it in STOP }
        .toSet()

    private fun overlap(a: Set<String>, b: Set<String>): Int = a.intersect(b).size
}
