package com.vanelle.os

/**
 * Point de décision unique : le système décide d'abord si une demande est une
 * commande déterministe ou une conversation. L'IA n'est jamais appelée pour
 * les commandes système reconnues par le parser.
 */
object SystemCommandRouter {
    enum class Route { SYSTEM, AI }

    fun classify(input: String): Route {
        val parsed = CommandParser.parse(input)
        return if (parsed.intent != CommandIntent.UNKNOWN) Route.SYSTEM else Route.AI
    }
}
