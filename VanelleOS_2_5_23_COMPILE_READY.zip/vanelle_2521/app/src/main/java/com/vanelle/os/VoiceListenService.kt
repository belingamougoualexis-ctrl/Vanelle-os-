package com.vanelle.os

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Capture vocale **en Service** : l'écran courant ne change pas.
 * Overlay + TTS pour le feedback. Remplace le besoin d'une Activity opaque.
 */
class VoiceListenService : Service() {

    companion object {
        private const val CH = "vanelle_voice"
        private const val NID = 4402
        @Volatile private var running = false

        fun isRunning(): Boolean = running

        fun start(c: Context) {
            val i = Intent(c, VoiceListenService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    ContextCompat.startForegroundService(c, i)
                } else {
                    c.startService(i)
                }
            } catch (e: Exception) {
                // Fallback Activity transparente
                try {
                    c.startActivity(
                        Intent(c, VoiceCaptureActivity::class.java).addFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK or
                                Intent.FLAG_ACTIVITY_NO_ANIMATION or
                                Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                        )
                    )
                } catch (_: Exception) {
                    Toast.makeText(c, "Impossible de démarrer l'écoute", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private var speech: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var finished = false
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        val notif = buildNotif("Vanelle t'écoute…")
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                startForeground(NID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } catch (_: Exception) {
                startForeground(NID, notif)
            }
        } else {
            startForeground(NID, notif)
        }
        running = true
        initTts()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (finished) return START_NOT_STICKY
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "Autorise le micro dans les réglages Vanelle", Toast.LENGTH_LONG).show()
            // Ouvre l'activity pour demander la permission
            try {
                startActivity(
                    Intent(this, VoiceCaptureActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {}
            stopSelfSafely()
            return START_NOT_STICKY
        }
        // La mascotte reste disponible pendant le téléchargement/chargement.
        // Les demandes qui nécessitent le cerveau local reçoivent alors une réponse
        // claire indiquant d'attendre, tandis que les actions rapides continuent de fonctionner.
        startListening()
        return START_NOT_STICKY
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java) ?: return
        val ch = NotificationChannel(CH, "Vanelle voix", NotificationManager.IMPORTANCE_LOW)
        ch.description = "Écoute vocale en cours"
        nm.createNotificationChannel(ch)
    }

    private fun buildNotif(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        return NotificationCompat.Builder(this, CH)
            .setContentTitle("Vanelle")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun initTts() {
        tts = TextToSpeech(applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale.FRANCE
                try { VoicePrefs.apply(this, tts) } catch (_: Exception) {}
            }
        }
    }

    private fun startListening() {
        try { speech?.destroy() } catch (_: Exception) {}
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speakThenStop("Reconnaissance vocale indisponible. Installe Speech Services by Google.")
            return
        }
        showOverlayHint("Je t'écoute…")
        // Ouvre immédiatement le sourire de la mascotte pendant l'écoute.
        OverlayHelper.startListening()
        updateNotif("Parle maintenant…")

        speech = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    updateNotif("Parle maintenant…")
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    updateNotif("Je réfléchis…")
                    // Le sourire reste animé seulement pour le retour vocal ; le moteur
                    // passe ensuite à startTalking() au moment réel du TTS.
                }
                override fun onError(error: Int) {
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            "Je n'ai rien entendu. Retouche la mascotte et reparle."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                            "Permission micro manquante."
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "Dictée : problème réseau. Réessaie."
                        else -> "Dictée échouée. Android a renvoyé le code d'erreur $error ; aucune cause plus précise n'a été fournie. Réessaie."
                    }
                    speakThenStop(msg)
                }
                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()
                    if (text.isBlank()) {
                        speakThenStop("Je n'ai rien compris. Réessaie.")
                    } else {
                        handleText(text)
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = RecognizerIntent.ACTION_RECOGNIZE_SPEECH.let {
            Intent(it).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
        }
        try {
            speech?.startListening(intent)
        } catch (e: Exception) {
            speakThenStop("Impossible d'écouter : ${e.message}")
        }
    }

    private fun handleText(text: String) {
        updateNotif("Traitement…")
        scope.launch {
            try {
                var res = withContext(Dispatchers.IO) {
                    CommandInterpreter(this@VoiceListenService).execute(text)
                }
                if (res.isBlank()) {
                    res = "Je n'ai pas pu répondre. Vérifie que l'IA est chargée."
                }
                val spoken = try {
                    RelationalMemory(this@VoiceListenService).withSpokenName(res)
                } catch (_: Exception) {
                    res
                }
                if (OverlayHelper.canDraw(this@VoiceListenService)) {
                    val sel = MascotManager.getSelected(this@VoiceListenService)
                    val mid = try {
                        MascotManager.getDrawableId(this@VoiceListenService, sel)
                    } catch (_: Exception) { 0 }
                    OverlayHelper.show(this@VoiceListenService, mid, text, res)
                }
                speakThenStop(spoken)
            } catch (e: Exception) {
                speakThenStop("Erreur : ${e.message ?: "inconnue"}")
            }
        }
    }

    private fun showOverlayHint(msg: String) {
        if (!OverlayHelper.canDraw(this)) return
        try {
            val sel = MascotManager.getSelected(this)
            val mid = try { MascotManager.getDrawableId(this, sel) } catch (_: Exception) { 0 }
            OverlayHelper.showMascot(this, mid, msg)
        } catch (_: Exception) {}
    }

    private fun updateNotif(text: String) {
        try {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            nm.notify(NID, buildNotif(text))
        } catch (_: Exception) {}
    }

    private fun speakThenStop(msg: String) {
        if (finished) return
        finished = true
        OverlayHelper.startTalking()
        val t = tts
        if (t == null) {
            Toast.makeText(this, msg.take(120), Toast.LENGTH_LONG).show()
            handler.postDelayed({ stopSelfSafely() }, 800)
            return
        }
        try {
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    OverlayHelper.stopTalking()
                    handler.post { stopSelfSafely() }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    OverlayHelper.stopTalking()
                    handler.post { stopSelfSafely() }
                }
            })
            val params = Bundle()
            VoicePrefs.applyForText(applicationContext, t, msg)
            t.speak(msg, TextToSpeech.QUEUE_FLUSH, params, "vanelle_svc")
        } catch (_: Exception) {
            Toast.makeText(this, msg.take(120), Toast.LENGTH_LONG).show()
            stopSelfSafely()
        }
        // Sécurité : stop après 60s max
        handler.postDelayed({ stopSelfSafely() }, 60_000)
    }

    private fun stopSelfSafely() {
        running = false
        try { speech?.destroy() } catch (_: Exception) {}
        speech = null
        try { tts?.stop() } catch (_: Exception) {}
        try { tts?.shutdown() } catch (_: Exception) {}
        tts = null
        try {
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE)
            else @Suppress("DEPRECATION") stopForeground(true)
        } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        try { speech?.destroy() } catch (_: Exception) {}
        try { tts?.shutdown() } catch (_: Exception) {}
        super.onDestroy()
    }
}
