package com.vanelle.os

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager

/** Configuration IA adaptative : aucun appareil ne reçoit une charge fixe. */
object AIConfiguration {
    data class Profile(
        val ramTotalMb: Long,
        val ramAvailableMb: Long,
        val nCtx: Int,
        val threads: Int,
        val maxOutputTokens: Int,
        val contextChars: Int,
        val thermalLimited: Boolean,
        val tier: String,
        val recommendedBatch: Int,
        val recommendedUbatch: Int,
        val maxPromptChars: Int,
        val threadsBatch: Int
    )

    fun profile(c: Context): Profile {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val total = info.totalMem / MB
        val available = info.availMem / MB
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val thermalLimited = isThermalLimited(c)

        // Le KV cache grandit avec n_ctx. On réserve donc les grands contextes aux
        // appareils réellement confortables afin de réduire le temps de pré-remplissage
        // et la pression mémoire sans sacrifier le fil de conversation.
        val baseCtx = when {
            total >= 12288 && available >= 5000 -> 4096
            total >= 8192 && available >= 3200 -> 3072
            total >= 6144 && available >= 2400 -> 2048
            total >= 4096 && available >= 1500 -> 1536
            total >= 3072 && available >= 1000 -> 1024
            else -> 768
        }
        val nCtx = if (thermalLimited) (baseCtx / 2).coerceAtLeast(768) else baseCtx

        // Génération : garder un cœur pour Android/UI évite les freezes.
        val threads = (cores - 1).coerceAtLeast(1).coerceAtMost(8)
        val safeThreads = if (thermalLimited) (threads - 1).coerceAtLeast(1) else threads
        // Ne pas ajouter artificiellement des threads au batch : sur mobile cela peut
        // augmenter la contention et la chaleur sans améliorer la génération.
        val threadsBatch = safeThreads
        val output = when {
            nCtx >= 4096 -> 512
            nCtx >= 3072 -> 448
            nCtx >= 2048 -> 384
            nCtx >= 1536 -> 320
            nCtx >= 1024 -> 256
            else -> 192
        }
        // Budget caractère/token volontairement conservateur pour le multilingue.
        // Il évite de remplir le contexte avant la fin de la réponse.
        val chars = (nCtx * 4).coerceIn(1400, 15000)
        val recommendedBatch = when {
            nCtx >= 4096 -> 512
            nCtx >= 2048 -> 384
            nCtx >= 1536 -> 256
            nCtx >= 1024 -> 192
            else -> 128
        }
        val recommendedUbatch = (recommendedBatch / 2).coerceAtLeast(64)
        val tier = when {
            nCtx >= 4096 -> "MAX"
            nCtx >= 2048 -> "HIGH"
            nCtx >= 1024 -> "STANDARD"
            nCtx >= 768 -> "BALANCED"
            else -> "SAFE"
        }
        val maxPromptChars = (chars - (output * 4) - 1300).coerceAtLeast(450)
        return Profile(
            total, available, nCtx, safeThreads, output, chars, thermalLimited, tier,
            recommendedBatch, recommendedUbatch, maxPromptChars, threadsBatch
        )
    }

    fun status(c: Context): String {
        val p = profile(c)
        return "IA ${p.tier} · contexte ${p.nCtx} · ${p.threads} threads · batch ${p.recommendedBatch}/${p.recommendedUbatch} · RAM ${p.ramAvailableMb} Mo libres" +
            if (p.thermalLimited) " · mode thermique" else ""
    }

    private fun isThermalLimited(c: Context): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE
        } catch (_: Exception) { false }
    }

    private const val MB = 1024L * 1024L
}
