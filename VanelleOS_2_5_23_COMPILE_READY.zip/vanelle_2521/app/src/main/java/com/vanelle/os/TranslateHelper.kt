package com.vanelle.os

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class TranslateHelper(private val c: Context) {
    companion object {
        val UI_LANGUAGES = listOf(
            "Auto-détection" to "auto",
            "Français" to "fr", "Anglais" to "en", "Espagnol" to "es",
            "Allemand" to "de", "Italien" to "it", "Portugais" to "pt",
            "Arabe" to "ar", "Chinois" to "zh-CN", "Japonais" to "ja",
            "Coréen" to "ko", "Russe" to "ru", "Néerlandais" to "nl",
            "Turc" to "tr", "Polonais" to "pl", "Suédois" to "sv",
            "Hindi" to "hi", "Swahili" to "sw", "Lingala" to "ln",
            "Wolof" to "wo", "Vietnamien" to "vi", "Thaï" to "th",
            "Grec" to "el", "Hébreu" to "he", "Roumain" to "ro", "Ukrainien" to "uk"
        )

        val LANG_CODES = mapOf(
            "francais" to "fr", "français" to "fr", "french" to "fr", "fr" to "fr",
            "anglais" to "en", "english" to "en", "en" to "en",
            "espagnol" to "es", "spanish" to "es", "es" to "es",
            "allemand" to "de", "german" to "de", "de" to "de",
            "italien" to "it", "italian" to "it", "it" to "it",
            "portugais" to "pt", "portuguese" to "pt", "pt" to "pt",
            "arabe" to "ar", "arabic" to "ar", "ar" to "ar",
            "chinois" to "zh-CN", "chinese" to "zh-CN", "zh" to "zh-CN",
            "japonais" to "ja", "japanese" to "ja", "ja" to "ja",
            "coreen" to "ko", "coréen" to "ko", "korean" to "ko", "ko" to "ko",
            "russe" to "ru", "russian" to "ru", "ru" to "ru",
            "neerlandais" to "nl", "néerlandais" to "nl", "dutch" to "nl", "nl" to "nl",
            "turc" to "tr", "turkish" to "tr", "tr" to "tr",
            "polonais" to "pl", "polish" to "pl", "pl" to "pl",
            "suedois" to "sv", "suédois" to "sv", "swedish" to "sv", "sv" to "sv",
            "hindi" to "hi", "hi" to "hi", "swahili" to "sw", "sw" to "sw",
            "lingala" to "ln", "ln" to "ln", "wolof" to "wo", "wo" to "wo",
            "vietnamien" to "vi", "vi" to "vi", "thai" to "th", "thaï" to "th", "th" to "th",
            "grec" to "el", "el" to "el", "hebreu" to "he", "hébreu" to "he", "he" to "he",
            "roumain" to "ro", "ro" to "ro", "ukrainien" to "uk", "uk" to "uk",
            "auto" to "auto", "auto-detection" to "auto", "auto-détection" to "auto"
        )

        fun codeFor(name: String): String? {
            val n = name.trim().lowercase()
                .replace("é", "e").replace("è", "e").replace("ê", "e")
                .replace("ç", "c").replace("î", "i").replace("ï", "i")
            return LANG_CODES[n] ?: LANG_CODES[name.trim().lowercase()]
        }

        fun labelFor(code: String): String =
            UI_LANGUAGES.firstOrNull { it.second.equals(code, true) }?.first ?: code
    }

    fun translateText(text: String, source: String, target: String): String {
        if (text.isBlank()) return "Quel texte veux-tu que je traduise ?"
        val sl = normalizeCode(source)
        val tl = normalizeCode(target).let { if (it == "auto") "fr" else it }
        // Essai principal Google Translate (endpoint public gtx)
        val primary = tryTranslate(text, sl, tl)
        if (primary != null) return primary
        // Second essai avec source auto
        if (sl != "auto") {
            val second = tryTranslate(text, "auto", tl)
            if (second != null) return second
        }
        return "Je ne peux pas joindre le service de traduction pour le moment. Cette fonction n'a pas besoin du modèle IA local, mais elle nécessite une connexion Internet. Vérifie ta connexion puis réessaie."
    }

    private fun normalizeCode(code: String): String {
        val c = code.trim().lowercase()
        return when {
            c in listOf("zh", "zh-cn", "zh_cn") -> "zh-CN"
            c == "auto" || c.isBlank() -> "auto"
            else -> codeFor(c) ?: c
        }
    }

    private fun tryTranslate(text: String, sl: String, tl: String): String? {
        return try {
            val q = URLEncoder.encode(text, "UTF-8")
            val url = URL(
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=$tl&dt=t&q=$q"
            )
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 10000
                readTimeout = 10000
                instanceFollowRedirects = true
                setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"
                )
                setRequestProperty("Accept", "*/*")
            }
            if (conn.responseCode !in 200..299) {
                conn.disconnect()
                return null
            }
            val body = conn.inputStream.bufferedReader().readText()
            conn.disconnect()
            parseGtx(body)
        } catch (_: Exception) {
            null
        }
    }

    private fun parseGtx(body: String): String? {
        return try {
            val arr = org.json.JSONArray(body)
            val segments = arr.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until segments.length()) {
                val seg = segments.optJSONArray(i) ?: continue
                sb.append(seg.optString(0, ""))
            }
            sb.toString().trim().ifBlank { null }
        } catch (_: Exception) {
            null
        }
    }
}
