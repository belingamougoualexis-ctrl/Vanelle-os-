package com.vanelle.os

import android.content.Context

/**
 * Stats transparentes : transforme les contraintes techniques en confiance.
 */
object UsageStats {
    private fun p(c: Context) = c.getSharedPreferences("vanelle_usage_stats", 0)

    fun recordLocalReply(c: Context, chars: Int, durationMs: Long) {
        p(c).edit()
            .putLong("local_replies", p(c).getLong("local_replies", 0) + 1)
            .putLong("local_chars", p(c).getLong("local_chars", 0) + chars)
            .putLong("local_ms", p(c).getLong("local_ms", 0) + durationMs.coerceAtLeast(0))
            .apply()
    }

    fun recordCloudReply(c: Context) {
        p(c).edit().putLong("cloud_replies", p(c).getLong("cloud_replies", 0) + 1).apply()
    }

    fun summary(c: Context): String {
        val local = p(c).getLong("local_replies", 0)
        val cloud = p(c).getLong("cloud_replies", 0)
        val ms = p(c).getLong("local_ms", 0)
        val chars = p(c).getLong("local_chars", 0)
        val avgMs = if (local > 0) ms / local else 0
        val model = try {
            if (LlamaModelManager.isReady(c)) "Modèle local prêt" else "Modèle en attente"
        } catch (_: Exception) { "—" }
        val loaded = try { LocalLlamaHelper.get(c).isLoaded() } catch (_: Exception) { false }
        val offline = PersonalityPrefs.preferOffline(c)
        return buildString {
            appendLine("📊 Transparence Vanelle")
            appendLine("• $model · chargé en mémoire : ${if (loaded) "oui" else "non"}")
            appendLine("• Réponses 100 % locales : $local")
            appendLine("• Renforts cloud : $cloud")
            appendLine("• Latence moyenne locale : ${avgMs} ms")
            appendLine("• Caractères générés localement : $chars")
            appendLine("• Mode offline préféré : ${if (offline) "oui" else "non"}")
            appendLine("• Données : restent sur ton téléphone (sauf web/cloud explicitement autorisés)")
            append("• Économie : chaque réponse locale = 0 € cloud et 0 envoi de prompt")
        }
    }
}
