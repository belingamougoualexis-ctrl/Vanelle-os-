package com.vanelle.os
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.View

/**
 * Design system VanelleOS.
 * Base neutre (blanc / noir doux) + un unique accent de marque (Bleu Maldives Vanelle)
 * réservé aux actions principales, exactement comme le font les apps pro
 * (un seul accent = identité forte, pas un arc-en-ciel de couleurs).
 */
object UiKit {
    // Neutres
    const val BLACK = 0xFF050708.toInt()          // texte principal (noir doux, pas #000 dur)
    const val TEXT_DARK = 0xFF050708.toInt()
    const val TEXT_MUTED = 0xFF00545C.toInt()      // texte secondaire
    const val TEXT_FAINT = 0xFF007C86.toInt()      // champs indicatifs / aides
    const val WHITE = 0xFFFFFFFF.toInt()
    const val SURFACE = 0xFFF4FCFD.toInt()         // fond de section / carte neutre
    const val BORDER = 0xFFBDECEF.toInt()          // liseré fin (remplace les bordures noires épaisses)
    const val BORDER_STRONG = 0xFF6FC3CA.toInt()

    // Accent de marque — Bleu Maldives Vanelle, réservé aux actions principales
    const val ACCENT = 0xFF007C86.toInt()
    const val ACCENT_SOFT = 0xFFDDF7F8.toInt()     // fond teinté clair pour badges/pills actifs
    const val ACCENT_DARK = 0xFF00545C.toInt()

    // Sémantique
    const val SUCCESS = 0xFF007C86.toInt()
    const val SUCCESS_SOFT = 0xFFDDF7F8.toInt()
    const val DANGER = 0xFF00545C.toInt()
    const val DANGER_SOFT = 0xFFE8F1F2.toInt()

    // Anciens alias conservés pour compatibilité avec le code existant
    const val FOREST = BLACK
    const val EMERALD = ACCENT
    const val TURQUOISE = ACCENT_DARK
    const val MINT = ACCENT_SOFT

    private fun Context.dp(v: Float) = v * resources.displayMetrics.density

    /** Carte standard : fond blanc, liseré fin, coins 14dp, légère élévation. */
    fun card(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(WHITE)
        setStroke(ctx.dp(1f).toInt(), BORDER)
        cornerRadius = ctx.dp(14f)
    }

    /** Applique l'ombre douce standard à une vue (à utiliser avec card()). */
    fun elevate(ctx: Context, view: View, dp: Float = 3f) {
        view.elevation = ctx.dp(dp)
        view.translationZ = 0f
    }

    /** Carte sélectionnée / mise en avant : liseré accent + fond teinté. */
    fun selected(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(ACCENT_SOFT)
        setStroke(ctx.dp(1.5f).toInt(), ACCENT)
        cornerRadius = ctx.dp(14f)
    }

    /** Pill neutre (tag, filtre inactif). */
    fun pill(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(WHITE)
        setStroke(ctx.dp(1f).toInt(), BORDER_STRONG)
        cornerRadius = ctx.dp(20f)
    }

    /** Pill accent (tag actif, statut positif). */
    fun pillAccent(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(ACCENT_SOFT)
        cornerRadius = ctx.dp(20f)
    }

    /** Bouton principal plein (CTA) — fond accent, texte blanc. */
    fun buttonPrimary(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(ACCENT)
        cornerRadius = ctx.dp(12f)
    }

    /** Bouton secondaire — contour discret, fond blanc. */
    fun buttonSecondary(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(WHITE)
        setStroke(ctx.dp(1.5f).toInt(), BORDER_STRONG)
        cornerRadius = ctx.dp(12f)
    }

    /** Badge de statut "actif/accordé". */
    fun badgeSuccess(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(SUCCESS_SOFT)
        cornerRadius = ctx.dp(8f)
    }

    /** Badge de statut "refusé/erreur". */
    fun badgeDanger(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(DANGER_SOFT)
        cornerRadius = ctx.dp(8f)
    }
}
