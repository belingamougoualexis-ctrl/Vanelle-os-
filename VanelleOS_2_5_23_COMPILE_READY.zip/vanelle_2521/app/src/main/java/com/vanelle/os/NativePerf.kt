package com.vanelle.os

import android.content.Context
import android.os.Build

/** Configuration native réellement utilisée par Vanelle. Les hooks optionnels
 * sont appliqués uniquement s'ils existent dans la version de la bibliothèque. */
object NativePerf {
    fun status(c: Context): String {
        val p = AIConfiguration.profile(c)
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val abi = try { Build.SUPPORTED_ABIS.joinToString(", ") } catch (_: Exception) { Build.CPU_ABI }
        return buildString {
            appendLine("Moteur IA")
            appendLine("• Profil : ${p.tier}")
            appendLine("• Contexte : ${p.nCtx} tokens")
            appendLine("• Sortie max : ${p.maxOutputTokens} tokens")
            appendLine("• Threads : ${p.threads} / $cores cœurs")
            appendLine("• Batch : ${p.recommendedBatch} · ubatch : ${p.recommendedUbatch}")
            appendLine("• RAM libre : ${p.ramAvailableMb} Mo / ${p.ramTotalMb} Mo")
            appendLine("• ABI : $abi")
            append("• Thermique : ${if (p.thermalLimited) "limité" else "normal"}")
        }
    }

    fun tryTuneHelper(helper: Any?, c: Context? = null) {
        if (helper == null) return
        val profile = c?.let { AIConfiguration.profile(it) }
        val threads = profile?.threads
            ?: (Runtime.getRuntime().availableProcessors() - 1).coerceAtLeast(1).coerceAtMost(8)
        val batchThreads = profile?.threadsBatch ?: threads

        fun invokeInt(names: List<String>, value: Int): Boolean {
            for (name in names) {
                try {
                    val m = helper.javaClass.methods.firstOrNull { it.name.equals(name, true) && it.parameterTypes.size == 1 } ?: continue
                    val type = m.parameterTypes[0]
                    if (type == Int::class.javaPrimitiveType || type == Integer::class.java) {
                        m.invoke(helper, value)
                        android.util.Log.i("VanellePerf", "$name=$value")
                        return true
                    }
                } catch (_: Exception) { }
            }
            return false
        }

        invokeInt(listOf("setThreads", "setNThreads", "nThreads"), threads)
        invokeInt(listOf("setThreadsBatch", "setNThreadsBatch", "threadsBatch", "nThreadsBatch"), batchThreads)
    }
}
