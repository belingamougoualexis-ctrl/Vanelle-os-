package com.vanelle.os

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.graphics.Rect
import android.graphics.Bitmap
import android.hardware.HardwareBuffer
import android.view.Display
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import java.util.concurrent.atomic.AtomicBoolean
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.os.Build
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityNodeInfo

class VanelleAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: VanelleAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(i: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(i)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        // L'événement est volontairement léger : le service ne lance aucune IA ici.
        // Les commandes lisent rootInActiveWindow uniquement au moment de l'action.
    }
    override fun onInterrupt() {}

    fun action(a: String): Boolean = when (a) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        else -> false
    }

    fun captureScreenText(): String {
        val root = try {
            rootInActiveWindow
        } catch (_: Exception) {
            null
        } ?: return ""
        return try {
            ScreenAnalysisHelper().capture(root)
        } finally {
            try {
                root.recycle()
            } catch (_: Exception) {
            }
        }
    }

    fun clickNodeWithText(query: String): Boolean {
        if (query.isBlank()) return false
        val root = try {
            rootInActiveWindow
        } catch (_: Exception) {
            null
        } ?: return false
        return try {
            findAndClick(root, query.lowercase().trim())
        } finally {
            try {
                root.recycle()
            } catch (_: Exception) {
            }
        }
    }

    private fun findAndClick(node: AccessibilityNodeInfo, query: String, depth: Int = 0): Boolean {
        if (depth > 40) return false
        try {
            val text = (node.text?.toString() ?: "").lowercase()
            val desc = (node.contentDescription?.toString() ?: "").lowercase()
            val hint = try {
                node.hintText?.toString()?.lowercase() ?: ""
            } catch (_: Exception) {
                ""
            }
            if (text.contains(query) || desc.contains(query) || hint.contains(query)) {
                var n: AccessibilityNodeInfo? = node
                var hops = 0
                while (n != null && hops < 8) {
                    if (n.isClickable && n.isEnabled) {
                        if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                    }
                    n = n.parent
                    hops++
                }
            }
            for (i in 0 until node.childCount) {
                val c = try {
                    node.getChild(i)
                } catch (_: Exception) {
                    null
                } ?: continue
                try {
                    if (findAndClick(c, query, depth + 1)) return true
                } finally {
                    try {
                        c.recycle()
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
        }
        return false
    }

    /** Copilote : saisit du texte dans le champ focalisé, sinon le premier EditText. */
    fun fillFocusedOrFirstField(value: String): Boolean {
        if (value.isBlank()) return false
        val root = try {
            rootInActiveWindow
        } catch (_: Exception) {
            null
        } ?: return false
        return try {
            val args = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    value
                )
            }
            // 1) Champ focalisé (input)
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focused != null) {
                try {
                    focused.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                    if (focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                        return true
                    }
                    // Fallback : ACTION_PASTE si disponible
                    val clipArgs = Bundle().apply {
                        putCharSequence(
                            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                            value
                        )
                    }
                    if (focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, clipArgs)) return true
                } finally {
                    try {
                        focused.recycle()
                    } catch (_: Exception) {
                    }
                }
            }
            // 2) Premier champ éditable
            fillEditable(root, value, args, 0)
        } finally {
            try {
                root.recycle()
            } catch (_: Exception) {
            }
        }
    }

    private fun fillEditable(
        node: AccessibilityNodeInfo,
        value: String,
        args: Bundle,
        depth: Int
    ): Boolean {
        if (depth > 40) return false
        try {
            val cls = node.className?.toString() ?: ""
            val editable = node.isEditable ||
                cls.contains("EditText", true) ||
                cls.contains("TextField", true) ||
                cls.contains("AutoComplete", true)
            if (editable) {
                node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true
            }
            for (i in 0 until node.childCount) {
                val c = try {
                    node.getChild(i)
                } catch (_: Exception) {
                    null
                } ?: continue
                try {
                    if (fillEditable(c, value, args, depth + 1)) return true
                } finally {
                    try {
                        c.recycle()
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
        }
        return false
    }


    /** Défilement via l'arbre d'accessibilité, avec fallback gestuel. */
    fun scroll(forward: Boolean): Boolean {
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        try {
            if (scrollNode(root, forward, 0)) return true
        } finally {
            try { root.recycle() } catch (_: Exception) {}
        }
        return false
    }

    private fun scrollNode(node: AccessibilityNodeInfo, forward: Boolean, depth: Int): Boolean {
        if (depth > 40) return false
        try {
            if (node.isScrollable && node.isEnabled) {
                val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                             else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                if (node.performAction(action)) return true
            }
            for (i in 0 until node.childCount) {
                val c = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
                try { if (scrollNode(c, forward, depth + 1)) return true }
                finally { try { c.recycle() } catch (_: Exception) {} }
            }
        } catch (_: Exception) {}
        return false
    }

    /** Clic à une position écran, utilisé uniquement comme fallback quand aucun nœud n'est cliquable. */
    fun tapAt(x: Float, y: Float): Boolean {
        if (Build.VERSION.SDK_INT < 24) return false
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 60L))
            .build()
        return try { dispatchGesture(gesture, null, null) } catch (_: Exception) { false }
    }

    data class NodeHit(val label: String, val bounds: Rect, val clickable: Boolean)

    /** Trouve le premier nœud correspondant et renvoie ses bounds écran. */
    fun findNodeBounds(query: String): Rect? {
        if (query.isBlank()) return null
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return null
        return try {
            findBounds(root, query.lowercase().trim(), 0)
        } finally {
            try { root.recycle() } catch (_: Exception) {}
        }
    }

    private fun findBounds(node: AccessibilityNodeInfo, query: String, depth: Int): Rect? {
        if (depth > 40) return null
        try {
            val text = (node.text?.toString() ?: "").lowercase()
            val desc = (node.contentDescription?.toString() ?: "").lowercase()
            val hint = try { node.hintText?.toString()?.lowercase() ?: "" } catch (_: Exception) { "" }
            if (text.contains(query) || desc.contains(query) || hint.contains(query)) {
                val r = Rect()
                node.getBoundsInScreen(r)
                if (r.width() > 0 && r.height() > 0) return r
            }
            for (i in 0 until node.childCount) {
                val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
                try {
                    val hit = findBounds(child, query, depth + 1)
                    if (hit != null) return hit
                } finally {
                    try { child.recycle() } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {}
        return null
    }
    data class ScreenContent(val text: String, val screenshotCaptured: Boolean)

    /** Capture réelle de l'écran (API 30+) + OCR local. Aucun texte n'est prérempli. */
    suspend fun captureScreenContent(): ScreenContent {
        val treeText = captureScreenText()
        if (Build.VERSION.SDK_INT < 30) return ScreenContent(treeText, false)
        return suspendCancellableCoroutine { cont ->
            val completed = AtomicBoolean(false)
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        try {
                            val buffer = result.hardwareBuffer
                            val bitmap = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                                ?.copy(Bitmap.Config.ARGB_8888, false)
                            buffer.close()
                            if (bitmap == null) {
                                if (completed.compareAndSet(false, true) && cont.isActive) cont.resume(ScreenContent(treeText, false))
                                return
                            }
                            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                                .addOnSuccessListener { vision ->
                                    val ocr = vision.text.trim()
                                    val merged = listOf(treeText, ocr).filter { it.isNotBlank() }.joinToString(" ")
                                        .replace(Regex("\\s+"), " ").trim().take(10000)
                                    recognizer.close()
                                    bitmap.recycle()
                                    if (completed.compareAndSet(false, true) && cont.isActive) cont.resume(ScreenContent(merged, true))
                                }
                                .addOnFailureListener {
                                    recognizer.close()
                                    bitmap.recycle()
                                    if (completed.compareAndSet(false, true) && cont.isActive) cont.resume(ScreenContent(treeText, true))
                                }
                        } catch (_: Exception) {
                            if (completed.compareAndSet(false, true) && cont.isActive) cont.resume(ScreenContent(treeText, false))
                        }
                    }
                    override fun onFailure(errorCode: Int) {
                        if (completed.compareAndSet(false, true) && cont.isActive) cont.resume(ScreenContent(treeText, false))
                    }
                })
            } catch (_: Exception) {
                if (completed.compareAndSet(false, true) && cont.isActive) cont.resume(ScreenContent(treeText, false))
            }
            cont.invokeOnCancellation { completed.set(true) }
        }
    }

}
