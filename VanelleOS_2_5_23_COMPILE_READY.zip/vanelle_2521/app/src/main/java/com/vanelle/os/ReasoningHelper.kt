package com.vanelle.os

/**
 * Orchestration du raisonnement pour un petit modèle local.
 *
 * Principe : le 3B ne "raisonne" pas bien en une passe libre.
 * On force une structure (décomposition, faits vs déductions, auto-check)
 * et on réserve le CoT aux questions qui en ont besoin.
 *
 * Ce n'est pas un second cerveau — c'est un pipeline autour de Llama.
 */
object ReasoningHelper {

    private val COMPLEX = Regex(
        """(?i)(pourquoi|comment\s+(?:ça|fonctionne|marche|expliquer)|explique|compar(?:e|er)|différence|analyse|prouve|déduis|calcule|étape|raisonne|avantages?\s+et\s+inconvénients?|pour\s+ou\s+contre|que\s+se\s+passe|implique|conséquence)"""
    )
    private val MATH = Regex(
        """(?i)(?:combien|calcule|calcul|somme|produit|différence|divis|multipli|\d+\s*[\+\-\*/×÷]\s*\d+|pourcentage|%|\d+\s*(?:plus|moins|fois))"""
    )
    private val FACTUAL = Regex(
        """(?i)(?:c['']est\s+quoi|qu['']est[- ]ce\s+que|qui\s+est|quelle?s?\s+est|quel\s+est|défini|date|capitale|population|superficie|mesure|plus\s+(?:grand|grande|petit|petite|haut|haute|long|longue|peuplé|peuplée|riche)|record|combien\s+de|où\s+(?:est|se\s+trouve)|pays|continent|océan|montagne|ville)"""
    )

    /**
     * Détecte une vraie charge de raisonnement, pas simplement un message long.
     * Un message de 100 caractères peut être une conversation banale ; le traiter
     * comme une tâche complexe ajoutait inutilement du préfill et de la latence.
     */
    fun isComplex(t: String): Boolean {
        val s = t.trim()
        if (s.isEmpty()) return false
        val multiConstraint = Regex("""(?i)\b(et|puis|ensuite|également|aussi|avec|sans|mais|tout en)\b""").findAll(s).count() >= 2
        val expert = Regex("""(?i)(debug|bug|erreur|code|algorithme|architecture|optimise|optimiser|preuve|démontre|démontres|prouve|raisonne|analyse en profondeur|compare|comparaison|avantages?|inconvénients?|stratégie|plan|diagnostic|cause|conséquence|pourquoi|comment fonctionne)""").containsMatchIn(s)
        return expert || (MATH.containsMatchIn(s) && s.length > 20) || (s.length > 220 && multiConstraint)
    }

    /** Raisonnement profond : réservé aux tâches où une seconde vérification mentale
     * et une réponse plus structurée apportent réellement quelque chose. */
    fun needsDeepReasoning(t: String): Boolean {
        val s = t.trim()
        return Regex("""(?i)(preuve|prouve|démontre|analyse en profondeur|debug|débog|architecture|algorithme|stratégie|plan détaillé|compare|comparaison|avantages?\s+et\s+inconvénients?|cause.*conséquence|raisonne|étape par étape|résous|résolution|math|équation|probabilité)""").containsMatchIn(s) ||
            (MATH.containsMatchIn(s) && s.length > 35)
    }

    enum class ReasoningTier { SIMPLE, STANDARD, DEEP }

    /** Niveau de traitement demandé. Le niveau ne révèle jamais la chaîne de pensée. */
    fun tier(t: String): ReasoningTier = when {
        needsDeepReasoning(t) -> ReasoningTier.DEEP
        isComplex(t) -> ReasoningTier.STANDARD
        else -> ReasoningTier.SIMPLE
    }

    fun isMathLike(t: String): Boolean = MATH.containsMatchIn(t)

    // Demande de narration/création : à ne JAMAIS traiter comme une recherche factuelle,
    // même si le mot "histoire"/"history" apparaît ("raconte-moi une histoire",
    // "invente une histoire", "écris-moi un conte..."). Bug réel corrigé : ces phrases
    // étaient interceptées par le mot-clé "histoire" ci-dessous et envoyées au web/RAG,
    // qui ne trouve rien à "chercher" pour un récit inventé → réponse d'échec générique
    // au lieu de laisser l'IA locale raconter l'histoire.
    private val CREATIVE_STORY = Regex(
        """(?i)(racont|invente|inventer|imagine|imaginer|écri[st]|ecri[st]|crée|creer|créer)[a-zàâéèêëîïôûùüç\s-]*(histoire|conte|récit|recit|aventure|blague)"""
    )

    /** Questions de culture générale / faits : le 3B doit s'appuyer sur le web, pas inventer. */
    fun isFactualLookup(t: String): Boolean {
        if (t.length >= 160) return false
        if (CREATIVE_STORY.containsMatchIn(t)) return false
        if (FACTUAL.containsMatchIn(t)) return true
        // Formulations libres type « le plus grand pays du monde »
        val low = t.lowercase()
        val cues = listOf(
            "plus grand", "plus grande", "plus petit", "plus haute", "plus haut",
            "capitale", "population", "superficie", "combien d", "c'est quoi", "c est quoi",
            "qui a inventé", "en quelle année", "quel pays", "quelle ville",
            "what is", "who is", "where is", "how many", "how much", "when did",
            "que es", "quien es", "donde", "cuanto",
            "histoire", "history", "definition", "définition", "inventeur", "président", "president"
        )
        return cues.any { low.contains(it) }
    }

    /**
     * Réécrit une question en requête de recherche plus exploitable
     * (ex. « quel est le plus grand pays » → « plus grand pays du monde superficie »).
     */
    fun searchQueryFor(t: String): String {
        var q = t.trim()
        q = q.replace(Regex("""(?i)^(dis[- ]moi|vanelle|s'il te plaît|svp)[, ]*"""), "")
        q = q.replace(Regex("""(?i)\?$"""), "").trim()
        val low = q.lowercase()
        // Désambiguïser superficie vs population
        if (Regex("""(?i)plus\s+grand(?:e)?\s+pays""").containsMatchIn(low) &&
            !low.contains("population") && !low.contains("habitant")
        ) {
            return "plus grand pays du monde par superficie"
        }
        if (Regex("""(?i)plus\s+peuplé""").containsMatchIn(low) ||
            (low.contains("plus grand pays") && low.contains("population"))
        ) {
            return "pays le plus peuplé du monde"
        }
        if (Regex("""(?i)capitale\s+(?:de|d')""").containsMatchIn(low)) {
            return q
        }
        return q.take(100)
    }

    /**
     * Raisonnement forcé mais **réponse finale seule à afficher**.
     * Format strict pour pouvoir élague le CoT visible (latence perçue).
     */
    fun buildStructuredPrompt(userMessage: String, hasExternalFacts: Boolean): String {
        val base = userMessage.trim()
        return buildString {
            append(base)
            append("\n\nMode raisonnement approfondi. Analyse silencieusement avant de répondre : objectif réel, contraintes, informations fiables disponibles, calculs éventuels, puis conclusion. Vérifie que ta conclusion répond exactement à la demande et qu'elle ne contredit pas les faits fournis.")
            if (hasExternalFacts) append(" Les faits externes fournis sont prioritaires sur tes souvenirs.")
            append(" Si plusieurs interprétations sont possibles, choisis la plus probable seulement si le contexte permet de le faire ; sinon pose une seule question courte. Pour une comparaison ou un problème, examine les éléments importants avant de conclure.")
            append(" Ne révèle jamais une chaîne de pensée privée et ne produis pas de brouillon. Une justification utilisateur peut être résumée très brièvement et de façon vérifiable, sans exposer le raisonnement interne. N'invente aucun fait ; si une information manque ou reste incertaine, dis-le franchement.")
        }
    }

    /**
     * Extrait la partie parlée / affichée : priorise « RÉPONSE: », sinon texte nettoyé.
     * Coupe le chain-of-thought visible pour la latence et le confort vocal.
     */
    fun extractSpokenAnswer(raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return t
        Regex("(?is)(?:RÉPONSE|REPONSE)\\s*:\\s*(.+)$").find(t)?.groupValues?.getOrNull(1)?.let { body ->
            val clean = body.trim().removePrefix("assistant").trim()
            if (clean.length >= 4) return clean
        }
        Regex("(?is)\\[\\[REPONSE\\]\\]\\s*(.+?)(?:\\[\\[/REPONSE\\]\\]|$)").find(t)?.groupValues?.getOrNull(1)?.let { body ->
            if (body.trim().length >= 4) return body.trim()
        }
        Regex("(?is)(?:conclusion|réponse finale)\\s*:\\s*(.+)$").find(t)?.groupValues?.getOrNull(1)?.let { body ->
            val clean = body.trim()
            if (clean.length >= 4) return clean
        }
        var out = t
        out = Regex("(?is)\\[\\[ANALYSE_BREVE\\]\\].*?\\[\\[/ANALYSE_BREVE\\]\\]").replace(out, " ")
        out = Regex("(?is)^\\s*ANALYSE(?:[_\\s-]+)BREVE\\s*:\\s*.*?(?=\\n\\s*(?:RÉPONSE|REPONSE)\\s*:|$)").replace(out, " ")
        val lines = out.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val withoutSteps = lines.filterNot { line ->
            Regex("^(?:BROUILLON|FAITS|DÉDUCTIONS|DEDUCTIONS)\\s*:").containsMatchIn(line) ||
                Regex("^\\d+\\)\\s*(?:Reformule|Liste|Sépare|Raisonne|Conclusion|Auto-check)").containsMatchIn(line)
        }
        return withoutSteps.joinToString(" ").ifBlank { out }.trim()
    }


    /**
     * Révision finale ultra-courte pour les tâches réellement difficiles.
     * On ne demande pas au modèle d'afficher sa chaîne de pensée : il vérifie
     * seulement la fidélité, les contraintes et les erreurs manifestes du brouillon.
     */
    fun buildReflectionPrompt(userMessage: String, draft: String): String = buildString {
        append("Demande initiale : ").append(userMessage.trim().take(900))
        append("\n\nRéponse proposée : ").append(draft.trim().take(1400))
        append("\n\nRévise silencieusement cette réponse. Vérifie : 1) répond-elle exactement à la demande ? 2) respecte-t-elle toutes les contraintes ? 3) contient-elle une contradiction, un calcul douteux ou une affirmation inventée ? 4) son ton est-il naturel et humain ? Corrige uniquement ce qui est nécessaire. Réponds uniquement avec la version finale, sans analyse, sans brouillon et sans commentaire sur ta révision.")
    }

    /** Prompt court : humain, intention, langue du user, zero invention. */
    fun buildSimplePrompt(userMessage: String): String {
        val m = userMessage.trim()
        return m + "\n\nRéponds comme un humain attentif : comprends l'intention réelle, les sous-entendus et les corrections de l'utilisateur. " +
            "Réponds dans la langue de la demande, naturellement et sans formule automatique. " +
            "Va droit au but pour une demande simple ; développe seulement si cela aide. " +
            "Ne répète pas inutilement la question, ne fabrique aucun fait et ne prétends pas avoir fait une action que tu n'as pas faite. " +
            "Si une information manque ou si tu n'es pas sûr, dis-le clairement. " +
            "Si la demande est réellement ambiguë, pose une seule question courte. " +
            "N'affiche jamais ton raisonnement interne, ton brouillon ou des étapes de chaîne de pensée."
    }

    /** Reformulation apres faits web. */
    fun buildRagPrompt(question: String): String =
        "Question : ${question.trim()}\n\n" +
            "Utilise UNIQUEMENT les faits fournis dans le contexte. " +
            "Reponds dans la langue de la question, comme un humain clair et naturel. " +
            "Phrases completes. Ne change pas les chiffres ni les noms. " +
            "Si le contexte ne suffit pas, dis-le. Pas de presentation."

    fun tryDeterministicMath(t: String): String? {
        val s = t.lowercase()
            .replace('×', '*')
            .replace('÷', '/')
            .replace("plus", "+")
            .replace("moins", "-")
            .replace("fois", "*")
            .replace(',', '.')
        val m = Regex("""(\d+(?:\.\d+)?)\s*([\+\-\*/])\s*(\d+(?:\.\d+)?)""").find(s) ?: return null
        val a = m.groupValues[1].toDoubleOrNull() ?: return null
        val op = m.groupValues[2]
        val b = m.groupValues[3].toDoubleOrNull() ?: return null
        val r = when (op) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            "/" -> if (b == 0.0) return "Division par zero : impossible." else a / b
            else -> return null
        }
        val pretty = if (r == r.toLong().toDouble()) r.toLong().toString()
        else String.format("%.4f", r).trimEnd('0').trimEnd('.')
        return "Resultat : $pretty (calcul exact, pas une estimation)."
    }

    fun looksOverconfidentBluff(text: String): Boolean {
        val t = text.lowercase()
        if (t.length < 40) return false
        val bluff = listOf(
            "il est evident que", "tout le monde sait", "sans aucun doute",
            "c'est certain que", "absolument certain", "je peux garantir"
        )
        val hedge = listOf("peut-etre", "probablement", "il semble", "je ne suis pas", "hypothese", "si je comprends")
        val bluffHits = bluff.count { t.contains(it) }
        val hedgeHits = hedge.count { t.contains(it) }
        return bluffHits >= 1 && hedgeHits == 0 && !t.contains("je ne sais")
    }
    /** Extrait uniquement un résumé de justification utilisateur, jamais la chaîne de pensée privée. */
    fun extractVisibleReasoningSummary(raw: String): String {
        val t = raw.trim()
        val patterns = listOf(
            Regex("""(?is)\[\[ANALYSE_BREVE\]\](.+?)\[\[/ANALYSE_BREVE\]\]"""),
            Regex("""(?is)ANALYSE(?:[_\s-]+)BREVE\s*:\s*(.+?)(?:\n\s*(?:RÉPONSE|REPONSE)\s*:|$)"""),
            Regex("""(?is)JUSTIFICATION\s*:\s*(.+?)(?:\n\s*(?:RÉPONSE|REPONSE)\s*:|$)""")
        )
        for (r in patterns) {
            val body = r.find(t)?.groupValues?.getOrNull(1)?.trim().orEmpty()
            if (body.length >= 8) return body.take(700)
        }
        return ""
    }

}
