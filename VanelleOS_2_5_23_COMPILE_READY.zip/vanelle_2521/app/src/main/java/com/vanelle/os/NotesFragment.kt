package com.vanelle.os
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import java.text.SimpleDateFormat
import java.util.Locale

/** Notes vocales rapides : dicter → sauvegarder → relire/effacer. */
class NotesFragment : Fragment() {

    private lateinit var listContainer: LinearLayout
    private lateinit var emptyState: TextView

    private val dictateLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                ?.trim()
            if (!text.isNullOrEmpty()) {
                VoiceNotes.add(requireContext(), text)
                refreshList()
                Toast.makeText(requireContext(), "Note enregistrée", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(UiKit.WHITE)
        }

        val title = TextView(ctx).apply {
            text = "MES NOTES"
            setTextColor(UiKit.TEXT_MUTED); textSize = 11f; letterSpacing = 0.1f
            setPadding(4, 0, 0, 14)
        }
        root.addView(title)

        val dictateBtn = TextView(ctx).apply {
            text = "🎙  Dicter une note"
            setTextColor(UiKit.WHITE); textSize = 14f
            gravity = android.view.Gravity.CENTER
            setPadding(0, 30, 0, 30)
            background = UiKit.buttonPrimary(ctx)
            isClickable = true; isFocusable = true
            setOnClickListener { startDictation() }
        }
        root.addView(dictateBtn, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 20 })

        val scroll = ScrollView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        listContainer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listContainer)
        root.addView(scroll)

        emptyState = TextView(ctx).apply {
            text = "Aucune note pour l'instant.\nDicte-en une, ou dis \"note que...\" à Vanelle."
            setTextColor(UiKit.TEXT_FAINT); textSize = 13f
            gravity = android.view.Gravity.CENTER
            setPadding(0, 60, 0, 0)
        }

        refreshList()
        return root
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun startDictation() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Dicte ta note…")
        }
        try {
            dictateLauncher.launch(intent)
        } catch (_: Exception) {
            Toast.makeText(requireContext(), "Reconnaissance vocale indisponible sur cet appareil.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshList() {
        val ctx = requireContext()
        listContainer.removeAllViews()
        val notes = VoiceNotes.all(ctx)
        if (notes.isEmpty()) {
            listContainer.addView(emptyState)
            return
        }
        val fmt = SimpleDateFormat("dd/MM à HH:mm", Locale.FRANCE)
        for (note in notes) {
            val card = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(20, 18, 14, 18)
                background = UiKit.card(ctx)
                UiKit.elevate(ctx, this, 2f)
            }
            val textCol = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            textCol.addView(TextView(ctx).apply {
                text = note.text
                setTextColor(UiKit.TEXT_DARK); textSize = 13.5f
            })
            textCol.addView(TextView(ctx).apply {
                text = fmt.format(java.util.Date(note.ts))
                setTextColor(UiKit.TEXT_FAINT); textSize = 10.5f
                setPadding(0, 6, 0, 0)
            })
            card.addView(textCol)

            val deleteBtn = TextView(ctx).apply {
                text = "✕"
                setTextColor(UiKit.TEXT_FAINT); textSize = 15f
                setPadding(20, 0, 4, 0)
                isClickable = true; isFocusable = true
                setOnClickListener {
                    VoiceNotes.delete(ctx, note.id)
                    refreshList()
                }
            }
            card.addView(deleteBtn)

            listContainer.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
    }
}
