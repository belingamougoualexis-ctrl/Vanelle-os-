package com.vanelle.os

import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Export / partage propre des conversations. */
object ChatExport {

    fun asPlainText(c: Context): String {
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
        val sb = StringBuilder()
        sb.append("Conversation Vanelle\n")
        sb.append("Exporté le ").append(fmt.format(Date())).append("\n")
        sb.append("— 100% local / privé —\n\n")
        for (m in ChatHistory.all(c)) {
            val who = if (m.role.equals("user", true)) "Toi" else "Vanelle"
            sb.append(who).append(" (").append(fmt.format(Date(m.ts))).append(")\n")
            sb.append(m.text).append("\n\n")
        }
        return sb.toString().trim()
    }

    fun share(c: Context) {
        val text = asPlainText(c)
        if (text.length < 40) {
            android.widget.Toast.makeText(c, "Aucune conversation à exporter", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Conversation Vanelle")
            putExtra(Intent.EXTRA_TEXT, text)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        c.startActivity(Intent.createChooser(i, "Exporter la conversation").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
