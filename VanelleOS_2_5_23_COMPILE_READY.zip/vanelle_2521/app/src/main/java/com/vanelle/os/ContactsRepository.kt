package com.vanelle.os
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
class ContactsRepository(private val context:Context){
    private fun findNumber(name:String):String?{
        var num:String?=null
        val safe=name.replace("\\","\\\\").replace("%","\\%").replace("_","\\_")
        val cur=try{ context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),"${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ? ESCAPE '\\'",arrayOf("%$safe%"),null) }catch(_:Exception){ null }
        cur?.use{ if(it.moveToFirst()){ val idx=it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER); if(idx>=0) num=it.getString(idx) } }
        return num
    }
    fun call(name:String):String{
        if(!PrivacyFirewall.allowContacts(context)) return "Pare-feu confidentialité : accès contacts bloqué. Désactive le lockdown pour appeler."
        if(name.isBlank()) return "Je n'ai pas compris le nom du contact."
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)
            return "Je n'ai pas la permission de lire tes contacts. Active-la dans Configuration ou Paramètres Android."
        val num=findNumber(name) ?: return "Je ne trouve aucun contact nommé « $name ». Vérifie l'orthographe ou le nom enregistré."
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED)
            return "Je n'ai pas la permission d'appeler. Active « Téléphone » dans les permissions de l'application."
        return try{
            val i=Intent(Intent.ACTION_CALL,Uri.fromParts("tel",num,null)).apply{ addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(i)
            "Appel en cours vers $name."
        }catch(e:Exception){
            "Je n'ai pas pu lancer l'appel vers $name. Raison réelle détectée : ${FailureReason.from(e)}."
        }
    }
    fun sendMessage(name:String,message:String):String{
        if(!PrivacyFirewall.allowContacts(context)) return "Pare-feu confidentialité : accès contacts/SMS bloqué."
        if(name.isBlank()) return "Je n'ai pas compris le nom du destinataire ou le message est incomplet."
        if(message.isBlank()) return "Le message est vide. Dis-moi le texte à envoyer après le nom du contact."
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)
            return "Je n'ai pas la permission de lire tes contacts. Active-la dans Configuration."
        val num=findNumber(name) ?: return "Je ne trouve aucun contact nommé « $name ». Vérifie le nom enregistré."
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED)
            return "Je n'ai pas la permission d'envoyer des SMS. Active-la dans les permissions de l'application."
        return try{
            val sms=SmsManager.getDefault()
            val parts=sms.divideMessage(message)
            sms.sendMultipartTextMessage(num,null,parts,null,null)
            "Message envoyé à $name."
        }catch(e:Exception){
            "Impossible d'envoyer le message à $name. Raison réelle détectée : ${FailureReason.from(e)}."
        }
    }
}
