package com.vanelle.os

import android.content.Intent
import android.content.ActivityNotFoundException
import java.io.IOException
import java.net.ConnectException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * Centralise les causes d'échec réellement observées.
 * Règle: ne jamais transformer une hypothèse en fait.
 */
object FailureReason {
    fun from(t: Throwable): String {
        val root = generateSequence(t) { it.cause }.lastOrNull() ?: t
        val message = root.message?.trim().orEmpty()
        return when (root) {
            is UnknownHostException -> "impossible de résoudre le nom du serveur (${message.ifBlank { "UnknownHostException" }})"
            is SocketTimeoutException -> "délai d'attente réseau dépassé (${message.ifBlank { "SocketTimeoutException" }})"
            is ConnectException -> "connexion au serveur refusée (${message.ifBlank { "ConnectException" }})"
            is SocketException -> "erreur de connexion réseau (${message.ifBlank { "SocketException" }})"
            is ActivityNotFoundException -> "Android n'a trouvé aucune activité compatible (${message.ifBlank { "ActivityNotFoundException" }})"
            is SecurityException -> "Android a refusé l'action pour des raisons de sécurité/permission (${message.ifBlank { "SecurityException" }})"
            is IOException -> "erreur d'entrée/sortie (${message.ifBlank { "IOException" }})"
            else -> "Android a signalé ${root.javaClass.simpleName}${message.takeIf { it.isNotBlank() }?.let { ": $it" } ?: "; aucune cause plus précise n'a été fournie"}"
        }
    }
}
