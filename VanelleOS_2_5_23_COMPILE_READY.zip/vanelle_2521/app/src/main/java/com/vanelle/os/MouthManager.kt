package com.vanelle.os

import android.content.Context
import android.graphics.drawable.Drawable
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream

/** Persistance réelle de la bouche choisie et de son placement pour chaque mascotte. */
object MouthManager {
    data class Config(
        val asset: String = "",
        val x: Float = 0.5f,
        val y: Float = 0.53f,
        val scale: Float = 1f,
        val rotation: Float = 0f
    )

    private const val PREFS = "vanelle_mouth_customization"
    private const val CUSTOM_PREFIX = "custom:"
    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun key(id: String, field: String) = "${id}_$field"

    /** 24 bouches/lèvres livrées avec l'application. */
    val library: List<String> = (1..24).map { "mouth_${it.toString().padStart(2, '0')}" }

    fun get(c: Context, mascotId: String = MascotManager.getSelected(c)): Config {
        val p = prefs(c)
        val yDefault = MascotManager.mouthPositionFraction(c, mascotId)
        return Config(
            asset = p.getString(key(mascotId, "asset"), "") ?: "",
            x = p.getFloat(key(mascotId, "x"), 0.5f).coerceIn(0f, 1f),
            y = p.getFloat(key(mascotId, "y"), yDefault).coerceIn(0.05f, 0.95f),
            scale = p.getFloat(key(mascotId, "scale"), 1f).coerceIn(0.45f, 2.2f),
            rotation = p.getFloat(key(mascotId, "rotation"), 0f).coerceIn(-25f, 25f)
        )
    }

    fun save(c: Context, mascotId: String, config: Config) {
        prefs(c).edit()
            .putString(key(mascotId, "asset"), config.asset)
            .putFloat(key(mascotId, "x"), config.x.coerceIn(0f, 1f))
            .putFloat(key(mascotId, "y"), config.y.coerceIn(0.05f, 0.95f))
            .putFloat(key(mascotId, "scale"), config.scale.coerceIn(0.45f, 2.2f))
            .putFloat(key(mascotId, "rotation"), config.rotation.coerceIn(-25f, 25f))
            .apply()
    }

    /** Copie la photo choisie par l'utilisateur dans le stockage privé de l'application.
     * Aucune permission de stockage n'est nécessaire avec ACTION_OPEN_DOCUMENT. */
    fun importCustomPhoto(c: Context, mascotId: String, source: android.net.Uri): String? {
        val dir = File(c.filesDir, "custom_mouths").apply { mkdirs() }
        val file = File(dir, "${mascotId}_mouth.jpg")
        return try {
            c.contentResolver.openInputStream(source)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            } ?: return null
            CUSTOM_PREFIX + file.name
        } catch (_: Exception) {
            null
        }
    }

    fun isCustomPhoto(asset: String): Boolean = asset.startsWith(CUSTOM_PREFIX)

    fun customFile(c: Context, asset: String): File? {
        if (!isCustomPhoto(asset)) return null
        val name = asset.removePrefix(CUSTOM_PREFIX)
        if (name.isBlank() || name.contains('/') || name.contains('\\')) return null
        val file = File(File(c.filesDir, "custom_mouths"), name)
        return if (file.isFile) file else null
    }

    fun getDrawable(c: Context, mascotId: String = MascotManager.getSelected(c)): Drawable? {
        val asset = get(c, mascotId).asset
        if (asset.isBlank()) return null
        customFile(c, asset)?.let { return Drawable.createFromPath(it.absolutePath) }
        val id = c.resources.getIdentifier(asset, "drawable", c.packageName)
        return if (id != 0) ContextCompat.getDrawable(c, id) else null
    }

    fun getDrawableId(c: Context, mascotId: String = MascotManager.getSelected(c)): Int {
        val asset = get(c, mascotId).asset
        if (asset.isBlank() || isCustomPhoto(asset)) return 0
        return c.resources.getIdentifier(asset, "drawable", c.packageName)
    }

    fun hasCustom(c: Context, mascotId: String = MascotManager.getSelected(c)): Boolean = getDrawable(c, mascotId) != null

    fun reset(c: Context, mascotId: String) {
        val old = get(c, mascotId).asset
        customFile(c, old)?.delete()
        prefs(c).edit()
            .remove(key(mascotId, "asset"))
            .remove(key(mascotId, "x"))
            .remove(key(mascotId, "y"))
            .remove(key(mascotId, "scale"))
            .remove(key(mascotId, "rotation"))
            .apply()
    }
}
