package com.vanelle.os

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Corrections utilisateur → few-shot dynamiques dans le prompt.
 * « Non, X veut dire Y » devient un exemple réutilisé.
 */
object FeedbackMemory {
    private const val PREFS = "vanelle_feedback"
    private const val KEY = "corrections"
    private const val MAX = 30

    private fun p(c: Context) = c.getSharedPreferences(PREFS, 0)

    /** Détecte une correction du type « non, … », « en fait … », « corrige : … » */
    fun maybeCapture(c: Context, userText: String, previousAssistant: String?) {
        val t = userText.trim()
        if (t.length < 8) return
        val isCorrection = Regex(
            """(?i)^(non[, ]|en fait[, ]|corrige[: ]|c['']est pas ça|pas exactement|je voulais dire)"""
        ).containsMatchIn(t)
        if (!isCorrection) return
        val prev = previousAssistant?.take(160).orEmpty()
        add(c, wrong = prev.ifBlank { "(réponse précédente)" }, right = t.take(220))
    }

    fun add(c: Context, wrong: String, right: String) {
        try {
            val arr = JSONArray(p(c).getString(KEY, "[]"))
            arr.put(
                JSONObject()
                    .put("w", wrong.take(160))
                    .put("r", right.take(220))
                    .put("ts", System.currentTimeMillis())
            )
            val trimmed = JSONArray()
            val start = (arr.length() - MAX).coerceAtLeast(0)
            for (i in start until arr.length()) trimmed.put(arr.get(i))
            p(c).edit().putString(KEY, trimmed.toString()).apply()
        } catch (_: Exception) {}
    }

    /** Bloc few-shot compact pour le prompt (budget caractères). */
    fun asPromptBlock(c: Context, maxChars: Int = 400): String {
        return try {
            val arr = JSONArray(p(c).getString(KEY, "[]"))
            if (arr.length() == 0) return ""
            val sb = StringBuilder("Corrections passées (suis ces préférences) :\n")
            var used = sb.length
            for (i in (arr.length() - 1) downTo 0) {
                val o = arr.getJSONObject(i)
                val line = "• Éviter « ${o.optString("w").take(50)} » → préférer « ${o.optString("r").take(80)} »\n"
                if (used + line.length > maxChars) break
                sb.append(line)
                used += line.length
            }
            sb.toString().trim()
        } catch (_: Exception) {
            ""
        }
    }
}
