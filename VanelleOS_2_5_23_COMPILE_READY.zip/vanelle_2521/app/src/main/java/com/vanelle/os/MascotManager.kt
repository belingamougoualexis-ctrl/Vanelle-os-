package com.vanelle.os
import android.content.Context

object MascotManager {
    /** id -> label affiché */
    val mascots = listOf(
        "kawaii" to "Kawaii",
        "ice" to "Glace",
        "pastel" to "Pastel",
        "crystal" to "Cristal",
        "gold" to "Or",
        "cyber" to "Cyber",
        "candy" to "Barbe à Papa",
        "galaxy" to "Galaxie",
        "abyss" to "Abysses"
    )

    private fun prefs(c: Context) = c.getSharedPreferences("vanelle_prefs", 0)

    fun getSelected(c: Context): String =
        prefs(c).getString("mascot", "kawaii") ?: "kawaii"

    fun setSelected(c: Context, id: String) {
        if (mascots.any { it.first == id }) {
            prefs(c).edit().putString("mascot", id).apply()
        }
    }

    fun getDrawableId(c: Context, id: String): Int =
        c.resources.getIdentifier("mascot_$id", "drawable", c.packageName)

    /** Nom personnalisé donné par l'utilisateur (ex: "Luna", "Buddy"). Vide = utilise le label par défaut. */
    fun getCustomName(c: Context): String =
        prefs(c).getString("mascot_custom_name", "") ?: ""

    fun setCustomName(c: Context, name: String) {
        prefs(c).edit().putString("mascot_custom_name", name.trim()).apply()
    }

    /** Nom affiché / dit à voix haute : nom custom si défini, sinon label du style. */
    /** Position verticale réelle du sourire dans les assets 512x640.
     * Valeurs calibrées par style pour que la bouche virtuelle tombe sur le sourire
     * dessiné, au lieu d'être placée à une hauteur fixe pour toutes les mascottes.
     */
    fun mouthPositionFraction(c: Context, id: String = getSelected(c)): Float = when (id) {
        // Calibré sur les sourires réellement présents dans chaque asset 512x640.
        // La valeur est relative à la hauteur effectivement affichée, donc reste stable
        // dans MainActivity, VoiceCaptureActivity et l'overlay.
        "pastel" -> 0.586f
        "galaxy" -> 0.531f
        "cyber" -> 0.422f
        "gold" -> 0.477f
        // L'asset Abyss ne possède pas de sourire dessiné clairement visible :
        // on garde une bouche virtuelle centrée dans la zone inférieure du visage.
        "abyss" -> 0.550f
        "crystal" -> 0.538f
        "kawaii" -> 0.664f
        "ice" -> 0.531f
        "candy" -> 0.481f
        else -> 0.531f
    }

    fun getDisplayName(c: Context): String {
        val custom = getCustomName(c)
        if (custom.isNotBlank()) return custom
        val id = getSelected(c)
        return mascots.find { it.first == id }?.second ?: "Vanelle"
    }

    /**
     * Vérifie si le texte reconnu contient le nom de la mascotte
     * (nom custom OU label du style, tolérant aux accents / casse).
     */
    fun isMascotNameSpoken(c: Context, spoken: String): Boolean {
        val lower = spoken.lowercase().trim()
        if (lower.isBlank()) return false
        val names = mutableListOf<String>()
        val custom = getCustomName(c).lowercase()
        if (custom.isNotBlank()) names.add(custom)
        val id = getSelected(c)
        mascots.find { it.first == id }?.second?.lowercase()?.let { names.add(it) }
        // Aussi accepter "mascotte" et "vanelle" comme appel générique
        names.addAll(listOf("mascotte", "vanelle"))
        return names.any { n ->
            n.isNotBlank() && (lower.contains(n) || FuzzyMatch.close(lower, n, 2) ||
                lower.split(Regex("\\s+")).any { w -> w == n || FuzzyMatch.close(w, n, 2) })
        }
    }
}
