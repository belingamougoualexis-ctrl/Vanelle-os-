# VanelleOS 2.5.19 — Vérification finale disponible

## Corrections de cette version
- Affichage de l'état réel du pipeline dans le chat : analyse, mise en relation avec le fil, analyse approfondie, vérification.
- Aucun affichage de chaîne de pensée privée : seule une synthèse courte et vérifiable peut être montrée après une tâche complexe.
- Contexte conversationnel basé sur le fil actif, sans réinjecter le dialogue global d'un autre fil.
- Bouche de la fenêtre vocale principale recalée sur `MascotManager.mouthPositionFraction()` comme les autres vues.
- Les 9 mascottes utilisent leurs coordonnées de sourire calibrées par asset 512x640.
- Les permissions runtime déjà accordées sont systématiquement ignorées.
- Une permission refusée n'est plus relancée automatiquement à chaque `onResume`; l'état est mémorisé jusqu'à une action explicite de l'utilisateur ou à l'accord réel de la permission.
- Ajout d'un workflow CI qui utilise Gradle 8.11.1 et JDK 17 pour compiler debug et release.

## Audits effectués
- `verify_project.sh`: SOURCE AUDIT OK.
- Manifeste : toutes les classes déclarées sont présentes.
- Aucun `!!` Kotlin détecté.
- Aucun marqueur de simulation détecté par le contrôle de production.
- Constantes d'intégrité du modèle présentes.
- `ReasoningHelper.kt`: compilation Kotlin isolée OK.
- Ensemble des sources Kotlin : passage du parseur du compilateur Kotlin 2.0 sans erreur syntaxique détectée ; les erreurs restantes dans cet environnement sont des références Android/dépendances manquantes, pas des erreurs de syntaxe.
- XML Android : parsing XML OK.
- Archive finale : ZIP valide.

## Compilation Android
Le projet cible compileSdk 36 avec AGP 8.9.1. La documentation Android indique que AGP 8.9 nécessite au minimum Gradle 8.11.1; le workflow CI utilise donc Gradle 8.11.1 et JDK 17.

Une compilation Android complète n'a pas été exécutée dans cet environnement car l'Android SDK et les dépendances Gradle ne sont pas installés localement ici. Le workflow CI est inclus pour effectuer la compilation réelle dans un environnement Android propre.
