# VanelleOS — IA finale verrouillée

## Moteur
- Qwen2.5-3B-Instruct Q4_K_M GGUF (~1,93 Go), téléchargé séparément de l’APK.
- SHA-256 vérifié avant chargement.
- Le fichier modèle reste dans le stockage privé de l’application et survit aux mises à jour normales de l’APK.
- Un seul moteur local réel, sans variante legacy/test et sans réponses simulées.

## Génération
- API publique `predict()` de llamacpp-kotlin 0.4.0.
- Streaming via les événements `Started` / `Ongoing` / `Done` / `Error`.
- Un seul contexte natif et une seule inférence à la fois.
- Arrêt propre sur timeout/annulation.
- Budget de sortie adaptatif : les questions simples ne consomment pas un long budget.
- Prompt système compact, même langue que l’utilisateur, pas de raisonnement interne affiché.
- Nettoyage des balises et suites de symboles parasites en sortie.

## Performance
- `n_ctx` adapté à la RAM disponible.
- Threads CPU adaptés au nombre de cœurs, avec réduction thermique.
- Pas de thread batch supplémentaire artificiel.
- Contexte mémoire tronqué intelligemment pour réduire le pré-remplissage.
- Le modèle est chargé une seule fois par processus et réutilisé.

## Comportement
- Réponses de base possibles sans dépendre inutilement du LLM.
- Si le modèle n’est pas téléchargé ou chargé, Vanelle donne la raison exacte disponible.
- Si une capacité n’existe pas, Vanelle ne prétend pas l’avoir exécutée.
- Le raisonnement interne n’est jamais envoyé à l’utilisateur.

## Validation
La compilation finale doit être exécutée dans Android Studio/Gradle avec le SDK Android du projet et idéalement vérifiée sur un appareil physique. Les performances exactes dépendent du SoC, de la RAM, de la température et du système Android.
