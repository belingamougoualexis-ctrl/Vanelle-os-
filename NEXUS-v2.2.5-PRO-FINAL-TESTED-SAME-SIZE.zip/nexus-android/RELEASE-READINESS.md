# NEXUS Android 2.1.0 — production readiness

## Implemented

The 2.1.0 release adds the edge cache/CDN layer, universal database synchronization, 2+1 XOR erasure coding, signed capability tokens, a native SDK facade, and explainable health diagnostics.

NEXUS 2.0.0 keeps the distributed network engine from previous releases and adds a real authenticated service plane for local/distributed database records, deferred messaging, deterministic compute operations, resource advertisements, database replication, content auto-repair, and a stable `nexus://` runtime URI.

The Android UI exposes the real local state and does not ship with pre-filled remote nodes, fake metrics, dummy service responses, or simulated network capacity.

## Automated verification performed in this build environment

- Static QA: PASS.
- NEXUS service two-node TCP integration: PASS.
- Physical backhaul / external-link / multipath core: PASS.
- Android physical-backhaul inventory and USB/NXL1 path self-tests: PASS in the available host-side tests.
- IPv6 ICMPv6 / Neighbor Discovery / MLD: PASS.
- NAT traversal: PASS.
- DTN / QoS: PASS.
- E2E TCP/UDP: PASS.
- Mesh routing/failover: PASS.
- Distributed core: PASS.
- Persistence/content/credits/naming: PASS.
- Secure protocol: PASS.
- Userspace IP core: PASS.
- ZIP integrity is checked before release packaging.

## Tests that cannot honestly be claimed from this environment

- A physical two-phone radio/Wi-Fi test was not executed here because no two physical Android devices or `adb` test environment is attached.
- A real Android Gradle APK build was not executed locally because this build environment does not contain the Android SDK/Gradle installation required by the project.
- The GitHub Actions workflow is therefore the reproducible Android build path and contains emulator smoke tests for API 35 and API 36 plus debug/release APK assembly.
- The release APK is intentionally unsigned in CI. A production upload must be signed with the developer's private release key; the key itself is not bundled in this source archive.

## Uptodown readiness

The project includes `UPTODOWN-CHECKLIST.md`, `LEGAL.md`, `PRIVACY.md`, and `NOTICE.md`. The Android manifest avoids install-permission abuse and exposes only the network/Bluetooth/Wi-Fi/VPN capabilities needed by the implemented functionality.

Before publication, the developer must provide the signed APK, accurate app information, genuine screenshots, the official website/developer information, and confirm ownership/distribution rights. Uptodown performs its own editorial and security review, so compliance can be prepared but publication cannot be guaranteed by the project itself.
