# NEXUS — checklist Uptodown

Préparation de la fiche :

- Nom : NEXUS
- Version : 2.2.5 (versionCode 25)
- Application ID : com.nexus.network
- Format de distribution : APK Android
- Min SDK : 26
- Target SDK : 37
- Description courte proposée : `Réseau distribué, services P2P et connexions résilientes.`
- Description longue : utiliser README.md et fournir au minimum les informations de fonctionnement, permissions, compatibilité et limites.
- Icône : `app/src/main/res/drawable/ic_nexus.xml`, format carré vectoriel sans marque tierce.
- Publicité : aucune intégrée.
- Achats intégrés : aucun mécanisme intégré dans cette version.
- Permission d'installation de paquets : supprimée car NEXUS partage des fichiers APK sans les installer lui-même.
- Informations de confidentialité : PRIVACY.md.
- Conditions : LEGAL.md.
- Informations de distribution : NOTICE.md.

Avant envoi :

1. Compiler un APK release avec une clé de signature de production appartenant au propriétaire autorisé de l'application.
2. Tester l'APK installé sur plusieurs appareils Android réels et sur au moins deux profils d'émulateur.
3. Vérifier tous les parcours d'ouverture, consentement, connexion, réseau, partage, services, VPN et déconnexion.
4. Vérifier les permissions demandées et leur utilité réelle. Depuis 2.2.5, un écran explique chaque autorisation au premier lancement, avant toute demande système ; refuser ne ferme pas l'application.
5. Fournir des captures d'écran réelles de l'application et ses informations de version.
6. Soumettre uniquement une version dont le distributeur possède les droits nécessaires.
