# NEXUS — Conditions d'utilisation

Version de l'application : 2.0.0

NEXUS fournit un logiciel réseau décentralisé destiné à relier des appareils et services compatibles au moyen des transports réellement disponibles sur les appareils.

## Utilisation responsable

L'utilisateur doit disposer des autorisations nécessaires pour utiliser les réseaux, appareils, accessoires et points d'entrée auxquels NEXUS se connecte. L'utilisateur reste responsable des données qu'il publie, transmet, stocke ou réplique.

## Participation volontaire

Les fonctions de relais, de stockage distribué et de réplication sont contrôlées localement. Leur activation ne signifie pas qu'un appareil restera disponible en permanence. Un appareil peut être éteint, déconnecté, réinitialisé ou retiré du réseau.

## Capacités réseau

NEXUS ne crée pas de capacité radio, satellite, fibre, câble ou bande passante qui n'existe pas physiquement. Les fonctions externes dépendent du matériel, des pilotes, des permissions Android et du réseau réellement fourni.

## Services distribués

Les services NEXUS utilisent des pairs réellement joignables. Le calcul distribué de cette version est limité à des opérations intégrées et déterministes. Aucun code arbitraire fourni par un pair distant n'est exécuté par ce service.

## Propriété intellectuelle

Le nom, les logos, le code et les contenus utilisés dans une distribution NEXUS doivent être publiés avec les droits, licences et autorisations nécessaires. Toute soumission sur une plateforme tierce doit être effectuée par une personne autorisée à distribuer le logiciel.

## Disponibilité

Aucune garantie de disponibilité continue, de débit minimal, de couverture géographique ou de conservation permanente des données distribuées n'est fournie par le seul logiciel NEXUS.
