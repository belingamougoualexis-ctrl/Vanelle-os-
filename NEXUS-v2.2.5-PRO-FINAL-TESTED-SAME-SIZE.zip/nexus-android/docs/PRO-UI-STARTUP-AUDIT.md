# NEXUS 2.2.5 — correctif UI, démarrage et tutoriel

## Changements appliqués

- Écran d'entrée refondu avec une mascotte unique, cartes inclinées de façon légère et style sportif rouge/blanc/violet fluorescent.
- Les actions d'entrée sont simplifiées autour de `GET STARTED` / `LOG IN`.
- La déconnexion est présentée comme une action `SIGN OUT` dans le profil.
- Le tutoriel guidé utilise la mascotte et la même palette.
- Le service réseau lourd n'est plus lancé automatiquement au moment exact de la sortie de l'écran d'autorisations. L'interface principale s'affiche d'abord ; le démarrage du réseau se fait depuis l'action de connexion automatique.
- Le démarrage du service au premier plan appelle maintenant `startForeground()` immédiatement, avant l'initialisation des composants réseau.
- Les erreurs de démarrage du service sont contenues : elles ne ferment pas l'activité principale.
- Les appels de découverte Wi-Fi Direct sont protégés afin qu'une API ou une permission indisponible ne ferme pas l'interface.
- La mascotte est isolée de la scène d'origine et intégrée comme ressource PNG transparente optimisée.

## Vérifications exécutées dans l'environnement disponible

- QA statique du dépôt : OK, 84 fichiers Kotlin et 6 XML analysés.
- XML de `app/src/main` : parse valide.
- SELF-TEST partage de lien : OK.
- SELF-TEST backhaul physique : OK.
- SELF-TEST services NEXUS v2 : OK.

## Limites de validation

Le projet ne contient pas d'Android SDK, d'émulateur ou d'appareil physique dans cet environnement. Le build APK Gradle et les tests instrumentés de l'interface n'ont donc pas pu être exécutés ici.
Certains anciens scripts de self-test attendent davantage de stubs ou de services et n'ont pas terminé dans l'environnement local ; ils sont signalés comme non conclusifs plutôt que déclarés valides.
