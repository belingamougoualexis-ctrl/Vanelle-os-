# NEXUS 2.2.4 — rapport de tests (repris tel quel ; non ré-exécuté pour 2.2.5)

Date : 29 septembre 2026

## Résultat

Les tests disponibles sans SDK Android ni appareils physiques ont été exécutés sur le code actuel. Les composants cœur réseau concernés par la découverte, le routage, le failover, le transport multipath, le NXP, le NAT, le DTN/QoS, l'E2E, l'IPv6, la persistance, l'USB et le userspace IP passent leurs auto-tests dédiés.

Aucun mécanisme de succès réseau simulé n'a été ajouté à la production. Les tests utilisant des stubs Android servent uniquement à fournir les API Android au compilateur hors appareil ; ils ne remplacent pas un test sur téléphone réel.

## Tests PASS

- QA statique NEXUS 2.2.4 : 84 fichiers Kotlin et 6 XML vérifiés.
- Adresse / identité / requêtes : OK.
- NXP connection-request TCP : OK.
- Long-haul / RTT / fenêtres / timeouts : OK.
- Services NEXUS v2 : OK.
- Services NEXUS v2.1 : OK.
- Backhauls physiques / satellite / USB / multipath : OK.
- Share Link : OK.
- NAT UDP punch : OK.
- DHT / routage global / admission / interop : OK.
- DTN store-and-forward / QoS : OK.
- ICMPv6 / Neighbor Discovery / MLD : OK.
- Persistance / contenu / crédits / nommage : OK.
- Route mesh / failover : OK.
- USB NXL1 : OK.
- Protocole / secure framing : OK.
- Userspace core : OK.
- E2E cryptographique TCP + UDP : OK.
- Fast Dial multipath : OK, avec le chemin rapide gagnant en ~153 ms contre plusieurs chemins artificiellement lents dans le test de concurrence.
- Compilation smoke ciblée des sources modifiées `NexusTransportManager.kt` + `UserSpaceIpStack.kt` avec API Android contrôlées : OK.
- Parsing de tous les XML de `app/src/main` : OK.
- Intégrité du ZIP : OK.
- Logo NEXUS : ressource PNG valide et présente.
- Aucun marqueur `simulation`, `fake metric`, `dummy` ou `placeholder` trouvé dans le code Kotlin de production lors du contrôle statique.

## Optimisations validées

Le chemin TCP tente maintenant plusieurs backhauls Android en parallèle et conserve le premier établissement TCP réel. Le chemin relais NEXUS met également plusieurs relais en concurrence. La protection VPN intervient avant la connexion TCP sur les backhauls sélectionnés. La récupération de route continue en arrière-plan et vérifie rapidement l'apparition d'un nouveau chemin au lieu d'attendre une seconde complète entre deux vérifications.

## Vérifications non réalisables dans cet environnement

Le SDK Android, Gradle/Gradle Wrapper utilisable et un appareil Android réel ne sont pas disponibles ici. Il n'a donc pas été possible de produire puis lancer un APK sur téléphone, ni de valider les performances radio/4G/5G/Wi-Fi réelles, le Wi-Fi Direct réel, le satellite réel, l'USB réel ou les connexions France-Cameroun sur Internet réel.

Le script historique `nexus-v0_5-real-selftest.sh` reste dépendant d'un ancien jeu de dépendances/stubs et ne constitue pas une validation du code de production actuel ; son échec de compilation est lié au harnais de test, pas à un succès réseau fictif dans l'application.

La suite monolithique `nexus-v1_2-targeted-selftest.sh` n'a pas été retenue comme preuve finale, car son exécution complète a dépassé le délai d'exécution de l'environnement après plusieurs compilations séquentielles. Les mêmes blocs ont été exécutés séparément lorsque leurs scripts dédiés étaient disponibles.
