# NEXUS 2.2.2 - rapport d'audit (factuel)

Environnement : Ubuntu, JDK 21, Python 3. Absents : kotlinc, Gradle, SDK Android, appareil, émulateur, réseau.

## Corrections effectuées
- Version incohérente : code/Gradle en 2.2.1 alors que le paquet est 2.2.2 -> 2.2.2 / versionCode 24 (Gradle, NexusConfig, README, CI, script QA).
- Symbole décoratif dans les diagnostics (NexusHealth) remplacé par "OK" / "!!".
- Didacticiel : pointe de bulle orientée vers la cible, emplacement de mascotte remplaçable (Lottie possible) via GuidedTourBuilder.mascot.
- 39 documents d'historique déplacés dans docs/archive.

## Tests réellement exécutés
- tools/nexus-v1_2-static-qa.sh : PASS (80 fichiers Kotlin, 6 XML : cohérence versions, XML valide, manifeste, CI). Contrôle statique, pas une compilation.
- Recherche d'emoji / données fictives / TODO dans app/src/main : aucun emoji ; aucun code de démonstration trouvé.
- Équilibre accolades/parenthèses des fichiers modifiés : PASS (ne prouve pas la compilation).

## BLOCKED (non testé, raison exacte)
- Compilation Kotlin, build debug/release, APK : pas de kotlinc/Gradle/SDK, pas de wrapper Gradle dans le projet.
- Tous les selftests tools/*.sh : ils exigent kotlinc.
- Test des boutons, écrans, persistance, redémarrage, permissions, performances, compatibilité écrans : exigent un appareil ou un émulateur.
- Didacticiel modifié : jamais exécuté ni compilé.
- Liaison entre deux téléphones à 1 km ou séparés par une mer : exige deux appareils et une infrastructure Internet.

## Candidats au nettoyage (non supprimés, faute de compilation pour vérifier)
- NexusAppSdk.kt et NexusUsbNxlTransport.kt : aucune référence dans le code de l'application (seulement des tests).

## Ajouts (autorisations et Uptodown)
- Écran "Autorisations" au premier lancement (après connexion et conditions) : chaque autorisation est expliquée avant la fenêtre système ; refuser ne ferme pas l'app. La confirmation VPN d'Android est aussi demandée là, sans démarrer de VPN.
- Erreur de compilation probable corrigée : 36 appels label(texte, taille, gras, couleur) dans MainActivity alors que seule la version à 3 paramètres existait ; surcharge ajoutée. Non recompilé (BLOCKED).
- Non testé : affichage de l'écran, enchaînement des fenêtres système, comportement en cas de refus (BLOCKED : pas d'appareil).

## Didacticiel : refonte visuelle
- Mascotte : emblème NEXUS fourni par l'utilisateur, recadré en 192x192 (res/drawable-nodpi/nexus_mascot.png), affiché en tuile arrondie.
- Carte sombre (bleu nuit), rôle en petites capitales, titre blanc, texte gris clair, barre de progression segmentée, "Étape X sur N", bouton Suivant plein bleu, Passer discret ; halo et pulsation en bleu clair.
- Non compilé ni exécuté (BLOCKED) : rendu réel sur appareil non vérifié.

## Didacticiel : cohérence (2e passe)
- Carte claire alignée sur l'application (blanc, texte 111827, bleu 2563EB) au lieu d'une carte sombre étrangère à l'interface.
- Zone éclairée adaptée à la cible : cercle pour une cible compacte (onglet, "+"), rectangle arrondi pour une cible large (bouton pleine largeur, carte). Avant : un cercle de la largeur de l'écran sur les cartes larges. Transition animée de la forme et du rayon.
- Toucher la zone éclairée n'exécute plus l'action réelle par défaut (Step.runAction = false) : avant, un appui sur "Connecter automatiquement" pendant le guide lançait la connexion et la demande VPN. Seuls les onglets Réseau et Ressources naviguent réellement.
- 5 étapes : Connexion automatique, Adresse, Réseau, Ressources, Menu. Textes en tutoiement, 2 phrases maximum.
- Non compilé ni exécuté (BLOCKED).
