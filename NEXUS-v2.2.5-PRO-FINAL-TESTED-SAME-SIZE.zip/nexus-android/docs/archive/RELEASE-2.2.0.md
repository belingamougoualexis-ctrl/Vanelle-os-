# NEXUS Android 2.2.0 — production-readiness update

## Fonctionnalités ajoutées / renforcées

1. Adresse NEXUS IPv6 stable dérivée de l'identité cryptographique.
2. Demande de connexion signée par adresse, conservée jusqu'à acceptation/refus.
3. Boîte aux lettres distribuée par DHT persistante pour les demandes hors ligne.
4. Carnet d'adresses local persistant avec alias, ajout, mise à jour et suppression.
5. Sortie Internet distante possible sans que l'utilisateur active le transit entrant sur son propre appareil.
6. Routage overlay élargi à 64 sauts avec alternatives et évitement des boucles.
7. Diagnostic longue distance basé uniquement sur les interfaces, pairs, STUN et points d'entrée réellement observés.
8. Codage de résilience 2+1 accessible sur un fichier réellement sélectionné par l'utilisateur ; les données de démonstration de l'ancienne UI ont été supprimées.
9. Cache edge, synchronisation universelle, transfert de contenu, DTN et auto-réparation restent branchés sur leurs opérations réelles existantes.
10. Aucun emoji/sticker dans l'interface et suppression des marqueurs de démonstration du parcours utilisateur.
11. Adresse directe : entrée d'une IP publique réelle, authentification NXP, dérivation de l'identité NEXUS distante puis demande de connexion signée.
12. Lien `nexus://contact` pour partager une adresse sans QR code ni service tiers.
13. Trace réelle d'une destination avec endpoints signés, identité authentifiée, latence/perte mesurées et chemin annoncé lorsqu'il est disponible.
14. Boîte hors ligne persistante et nettoyage des demandes expirées/corrompues.
15. Nom `.mesh` publié dans le DHT signé par l'identité locale, comparable à un DNS distribué mais sans registre central.


## Modèle longue distance

L'adresse `fd00:4e58:5553:...` est un identifiant overlay NEXUS stable, pas une IPv6 publique attribuée par un opérateur. Pour un trajet réellement longue distance, NEXUS utilise une IPv6 globale si Android en expose une ou un relais / point d'entrée NEXUS réellement joignable. Un relais n'est jamais inventé localement.

L'utilisateur peut donc être à plusieurs centaines ou milliers de kilomètres, ou sur un autre continent, tant qu'un chemin IP réel permet aux nœuds de se joindre. Une séparation par la mer n'est pas un problème logiciel en soi.

## Validation environnementale

PASS est réservé aux tests effectivement exécutés.
BLOCKED est utilisé lorsque l'environnement ne possède pas le matériel ou les SDK nécessaires.
Aucun APK signé de production n'est déclaré ici sans compilation et signature réellement exécutées.
