# NEXUS Android 2.2.1 — audit final

## Interface
- barre supérieure réduite : NEXUS + « Réseau de réseaux » en petit
- bouton de menu réduit au seul signe « + »
- suppression du point « ● » et de la barre d'accent verte dans la carte d'état principale
- textes principaux simplifiés en français
- menu principal limité aux actions utiles
- didacticiel interactif conservé avec spotlight, halo, mascotte, progression, bouton Suivant/Passer et mémorisation locale

## Fonctionnement réseau
- l'application n'annonce pas Internet comme disponible uniquement parce que son code réseau existe : l'état principal dépend de la validation Android
- une route NEXUS détectée n'est pas présentée comme une connexion de bout en bout tant qu'elle n'est pas réellement vérifiée
- un téléphone ne devient pas relais à l'insu de son propriétaire : le transit doit être activé explicitement
- un appareil sans NEXUS n'est pas transformé en relais par cette application

## Portée / résilience
La portée physique radio du téléphone ne peut pas être augmentée par un simple changement logiciel. La version 2.2.1 augmente la portée utile du réseau au niveau logiciel :
- découverte Wi‑Fi Direct périodique
- jusqu'à 6 candidats de relais par tentative
- plusieurs chemins possibles et basculement
- TTL par défaut de 32 sauts pour les relais TCP/UDP
- prise en compte de plusieurs backhauls réels

Ces changements améliorent la recherche et la conservation d'un chemin réel, sans prétendre augmenter la puissance ou la portée radio.

## Tests exécutés dans cet environnement
- Static QA : OK
- userspace core : OK
- route core : OK
- adressage / identité / requêtes : OK
- connexion NXP : OK
- share link : OK
- NAT UDP : OK
- protocole : OK
- E2E TCP + UDP : OK
- DTN / QoS : OK
- persistance locale : OK
- cœur distribué : OK
- USB NXL1 : OK
- découverte/backhaul Android : déjà validé avant cette dernière passe

Une exécution combinée de tests plus large et une nouvelle exécution du test de backhaul physique ont été interrompues par la limite de temps de l'environnement. Ils ne sont donc pas comptés comme nouvellement validés dans cette dernière passe.

## Ce qui n'est pas validé ici
- compilation réelle de l'APK : le projet fourni ne contient pas de Gradle Wrapper et le SDK Android complet n'est pas disponible ici
- exécution sur téléphone Android physique
- test réel entre plusieurs téléphones sur longue distance
- portée radio réelle : elle dépend du matériel, des obstacles, des bandes et de l'environnement

## IP
L'adresse NEXUS de chaque installation est dérivée de son identité cryptographique et conçue pour éviter les collisions pratiques. Une IP publique identique peut toutefois être partagée par plusieurs utilisateurs derrière le NAT/CGNAT d'un opérateur ; l'application ne peut pas garantir une IP publique unique par personne.
