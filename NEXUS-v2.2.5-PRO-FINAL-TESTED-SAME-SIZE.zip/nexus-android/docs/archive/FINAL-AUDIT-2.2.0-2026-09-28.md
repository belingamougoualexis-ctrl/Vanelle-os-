# NEXUS Android 2.2.0 — Final Audit 2026-09-28

## 1. Problèmes trouvés

1. Le mode Transit local bloquait à tort la consommation d'une passerelle Internet NEXUS distante. Corrigé dans le routage sortant.
2. Une passerelle Internet valide n'était pas toujours annoncée comme relais utilisable si le transit entrant local était désactivé. Corrigé dans le cycle d'annonce.
3. Le mot de passe SOCKS local historique `NEXUS-LOCAL` était codé en dur. Supprimé : identifiant généré par installation et conservé dans le stockage sécurisé.
4. Il manquait un adressage utilisateur stable permettant une demande de connexion par adresse. Ajout d'une adresse NEXUS IPv6 overlay dérivée de l'identité cryptographique.
5. Il manquait une voie utilisateur directe par IP publique. Ajout d'une authentification NXP de l'endpoint, dérivation de l'identité NEXUS distante et création d'une demande signée.
6. La boîte de demandes n'avait pas de nettoyage explicite des entrées expirées/corrompues. Ajout du nettoyage avant synchronisation.
7. Le flux de partage d'adresse n'avait pas de lien applicatif. Ajout d'un lien `nexus://contact` avec ouverture directe de l'écran de demande.
8. Une ancienne UI d'erasure coding utilisait des données d'exemple. Remplacée par un sélecteur de fichier réel et une vérification de récupération réelle.
9. Des boutons/options réseau manquaient d'outils de diagnostic utilisateur. Ajout de trace de destination, vérification d'IP, nom `.mesh`, boîte hors ligne et récupération automatique du chemin.

## 2. Corrections effectuées

- Adresse NEXUS stable dérivée de la clé publique.
- Répertoire d'adresses signé dans le DHT.
- Demandes de connexion signées, persistantes, avec acceptation/refus.
- Boîte DHT distribuée pour conservation hors ligne.
- Carnet d'adresses local persistant.
- Contact direct par IP publique réelle après handshake authentifié.
- Lien `nexus://contact` + intent-filter Android.
- Nom `.mesh` publié dans le DHT avec signature de l'identité.
- Trace réelle d'une destination : endpoints signés, identité, latence/perte mesurées et chemin annoncé lorsque disponible.
- Nettoyage des demandes expirées/corrompues.
- Routage sortant vers passerelle distante indépendant du Transit entrant local.
- MAX_HOPS overlay porté à 64 ; MAX_ADVERTISED_PATH à 32.
- UI nettoyée : aucun emoji/sticker détecté dans les boutons, aucun texte de démonstration/factice dans le parcours utilisateur.
- Workflow CI renforcé avec tests v2.2 d'adressage, NXP direct et deep-link.

## 3. Cinq fonctionnalités supplémentaires ajoutées

1. **NEXUS `.mesh`** : nom décentralisé signé, comparable à une résolution de noms distribuée.
2. **Trace réseau réelle** : visibilité sur l'identité, les endpoints, les mesures et le chemin réellement annoncé.
3. **Vérification d'IP publique** : une IP saisie est authentifiée avant qu'une demande de contact puisse être déclarée envoyée.
4. **Boîte hors ligne** : demandes persistées localement et via DHT pour les nœuds indisponibles temporairement.
5. **Lien de contact `nexus://`** : partage d'une adresse sans QR code ni service tiers et ouverture directe de NEXUS.

## 4. Modèle de communication longue distance

La distance géographique n'est plus limitée par un seuil logiciel de 1 km. Le chemin est sélectionné parmi les liaisons réellement disponibles : IP directe, relais, multi-sauts, DTN/store-and-forward et passerelle Internet. NEXUS peut donc fonctionner entre des zones très éloignées, y compris séparées par la mer, lorsque chaque partie dispose d'un chemin IP réel vers le réseau NEXUS.

La portée radio n'est pas artificiellement augmentée par le logiciel. Une liaison radio/fibre/satellite/Internet ou un relais intermédiaire réel reste nécessaire.

## 5. Tests réalisés

| Fonctionnalité | Test effectué | Résultat |
|---|---|---|
| Static QA | `tools/nexus-v1_2-static-qa.sh` | PASS | 
| Services v2, deux nœuds | `tools/nexus-v2-services-selftest.sh` | PASS |
| Services v2.1 | `tools/nexus-v2_1-services-selftest.sh` | PASS |
| Identité / adresse / demandes / contacts | `tools/nexus-v2_2-addressing-selftest.sh` | PASS |
| NXP direct + handshake + CONNECT-REQUEST | `tools/nexus-v2_2-nxp-selftest.sh` | PASS |
| Lien `nexus://contact` | `tools/nexus-sharelink-selftest.sh` | PASS |
| Backhaul physique / multipath | `tools/nexus-v1_2-physical-core-selftest.sh` | PASS |
| Backhaul Android / satellite / USB | `tools/nexus-v1_2-android-backhaul-selftest.sh` | PASS |
| USB NXL1 | `tools/nexus-v1_2-usb-selftest.sh` | PASS |
| ICMPv6 / ND / MLD | `tools/nexus-v1_2-icmpv6-selftest.sh` | PASS |
| Persistance / contenu / crédits / naming | `tools/nexus-v1_2-persistence-selftest.sh` | PASS |
| NAT UDP punch | `tools/nexus-v1_2-nat-selftest.sh` | PASS |
| Distributed core | `tools/nexus-v1_2-distributed-selftest.sh` | PASS |
| DTN / QoS | `tools/nexus-v1_2-dtn-qos-selftest.sh` | PASS |
| TCP/UDP E2E | `tools/nexus-v1_2-e2e-selftest.sh` | PASS |
| Mesh routing / failover | `tools/nexus-v1_2-route-selftest.sh` | PASS |
| Secure protocol | `tools/run-protocol-selftest.sh` | PASS |
| Userspace IP core | `tools/userspace-core-selftest.sh` | PASS |
| CI YAML | parsing YAML de `.github/workflows/android-build.yml` | PASS |
| Vérification anti-emoji UI | `ButtonCoverageTest` ajouté dans instrumentation | BLOCKED : SDK/émulateur absents localement |
| UI/navigation sur appareil | instrumentation Android API 35/36 prévue dans CI | BLOCKED localement |
| Installation appareil physique | test réel | BLOCKED : aucun appareil/ADB disponible |
| Test réel intercontinental / séparation par mer | deux appareils + backhaul réel | BLOCKED : matériel/environnement indisponible |

## 6. Fonctionnalités réellement opérationnelles dans les tests disponibles

- PASS : identité cryptographique par installation.
- PASS : adresse NEXUS stable dérivée de l'identité.
- PASS : validation des adresses NEXUS.
- PASS : demandes signées et persistées.
- PASS : acceptation avec écriture réelle du message dans la base locale.
- PASS : persistance après redémarrage dans les tests cœur.
- PASS : carnet d'adresses persistant.
- PASS : handshake NXP et transfert CONNECT-REQUEST par TCP réel de test.
- PASS : voie directe par IP publique authentifiée dans le test NXP.
- PASS : DHT/DTN/NAT/QoS/routage/IPv6/services/tests de persistance.
- PASS : absence de données fictives détectées par Static QA.

## 7. Fonctionnalités bloquées

### Build APK Android
**BLOCKED.** Cet environnement ne contient ni Android SDK ni Gradle wrapper exécutable. Le projet ne possède pas de `gradlew` dans cette archive. La CI GitHub Actions est configurée pour installer JDK 17, Android API 37, Build Tools 36.0.0 et Gradle 9.5.0, puis construire Debug et Release et exécuter les tests instrumentés API 35/36.

### Tests physiques longue distance
**BLOCKED.** Aucun second téléphone Android, aucun ADB et aucun lien Internet/relay public contrôlé n'est disponible dans cet environnement. Aucun test physique à 1 km, 10 km, 1000 km ou entre deux rives n'est donc déclaré PASS.

### Signature de production
**BLOCKED.** Aucun keystore de signature de production n'a été fourni. Le workflow produit un `app-release-unsigned.apk` tant qu'un secret de signature n'est pas configuré côté CI.

## 8. Erreurs restantes

Aucune erreur de Static QA ou de cœur de protocole n'est actuellement connue dans les tests exécutés.

Il reste trois validations d'environnement, non des corrections de code :
- compilation APK Android réelle ;
- instrumentation UI sur émulateur/appareil ;
- test physique longue distance avec backhaul réel.

Les scripts historiques v0.x ne sont plus utilisés comme porte de validation CI et ne sont pas comptés comme tests produit ; certaines de leurs listes de sources sont obsolètes vis-à-vis de l'architecture actuelle. Un essai de `tools/nexus-v0_5-real-selftest.sh` a retourné **BLOCKED** car son faisceau de compilation historique ne fournit plus les dépendances/stubs nécessaires à l'architecture actuelle (erreurs de compilation de harnais, pas une erreur d'exécution produit). La porte de validation actuelle utilise les scripts v2/v2.1/v2.2 et les suites v1.2 individualisées listées ci-dessus.

## 9. Résultat du build de production

**BLOCKED localement** : aucun APK ne peut être honnêtement déclaré construit ici.

La chaîne de production CI est configurée mais n'a pas été exécutée depuis cet environnement.

## 10. Artefact final

Archive source finale corrigée : `/mnt/data/NEXUS-Android-v2.2.0-final-production-2026-09-28.zip`

Cette archive contient le projet Android corrigé, le workflow CI, les tests de régression ajoutés et ce rapport final. Elle ne contient pas un APK que l'environnement n'a pas pu compiler.
