# NEXUS Android 2.1.0 — Final audit factuel

## Modifications effectuées

1. Ajout d'un mécanisme réel d'invitation de réseau privé :
   - partage d'un code `NEXUS-PRIVATE-1:<clé>` via le sélecteur Android de partage ;
   - import du code sur un second appareil ;
   - stockage de la clé dans le stockage sécurisé Android ;
   - reprobe des pairs après changement de clé.
2. Le routage longue distance conserve l'utilisation d'une vraie passerelle NEXUS distante et ne dépend plus du bouton Transit local pour annoncer une sortie Internet valide.
3. Le secret SOCKS local est généré par installation et stocké dans le stockage sécurisé ; aucune valeur `NEXUS-LOCAL` n'est conservée dans le code source.
4. Les scripts shell de tests référencés par le workflow CI sont exécutables.
5. Le workflow Android reste configuré avec AGP 9.3.x / Gradle 9.5 / API 37, cohérent avec la matrice de compatibilité Android/Kotlin utilisée par le projet.

## Tests exécutés dans cet environnement

| Test | Résultat |
|---|---|
| Static QA | PASS |
| NEXUS v2 services two-node | PASS |
| NEXUS v2.1 services | PASS |
| Physical backhaul / multipath | PASS |
| Android physical backhaul / satellite / USB / multi-backhaul | PASS |
| USB NXL1 | PASS |
| ICMPv6 / ND / MLD | PASS |
| Distributed core | PASS |
| Local persistence / content / credits / naming | PASS |
| NAT UDP punch | PASS |
| DTN / QoS | PASS |
| E2E TCP + UDP | PASS |
| Mesh route | PASS |
| Secure protocol | PASS |
| Userspace IP core | PASS |
| Scan emojis/stickers dans le code UI | PASS — 0 occurrence détectée |
| Scan de l'ancien secret `NEXUS-LOCAL` | PASS — 0 occurrence détectée |

## Vérifications de build

Le projet contient une configuration Android complète et un workflow CI qui installe JDK 17, Android API 37, Build Tools 36.0.0 et Gradle 9.5.0 avant de lancer `assembleDebug`, `assembleRelease` et les tests instrumentés API 35/36.

Le build Android n'a PAS été exécuté dans cet environnement, car le SDK Android/Gradle nécessaire n'était pas installé et le téléchargement de la distribution Gradle n'était pas disponible. Il est donc classé BLOCKED et non PASS.

La signature de production n'est pas inventée : aucun keystore de production n'a été fourni. L'artefact release généré par le workflow actuel est donc non signé tant qu'une clé de signature n'est pas configurée.

## Test longue distance : 1 km ou mer

Le problème de proximité physique est traité architecturalement : NEXUS ne limite plus la communication à la proximité radio. Deux appareils peuvent être sur des réseaux différents et utiliser une passerelle NEXUS réellement accessible via IP.

Procédure réelle :
1. Appareil A crée/possède le réseau privé.
2. A partage le code d'invitation NEXUS.
3. B rejoint ce réseau avec ce code.
4. Si A et B ne sont pas sur le même LAN, un point d'entrée NEXUS réellement accessible doit être configuré dans « Réseau avancé → Ajouter un point d'entrée distant ».
5. Les deux appareils doivent disposer d'un chemin IP réel : Wi-Fi, réseau mobile, relais ou autre backhaul compatible.

Une distance de 1 km ou une séparation par la mer n'est donc pas une limitation logicielle en soi. Sans Internet, relais ou autre liaison IP réelle, aucune application Android ne peut créer physiquement ce chemin.

## Limites non transformées en PASS

- APK réellement compilé dans cet environnement : BLOCKED.
- Installation et test sur téléphone physique : BLOCKED.
- Test réel entre deux téléphones séparés de 1 km : BLOCKED.
- Test réel entre deux téléphones séparés par une mer : BLOCKED.
- Signature production : BLOCKED jusqu'à fourniture/configuration d'un keystore.

Aucun de ces éléments n'est présenté comme testé alors qu'il ne l'a pas été.
