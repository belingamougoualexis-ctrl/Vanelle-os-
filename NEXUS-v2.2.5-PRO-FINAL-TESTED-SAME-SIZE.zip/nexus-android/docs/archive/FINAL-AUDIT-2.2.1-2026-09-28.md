# NEXUS Android 2.2.1 — patch audit 2026-09-28

## Corrections made

1. `GatewayTester` now receives the Android `Context` correctly; the previous undefined `context` reference is removed.
2. Main navigation was simplified around four user goals: connect, see network state, use services, manage identity. Technical diagnostics remain available under advanced controls.
3. Relay/transit remains opt-in and disabled by default. A NEXUS device does not silently turn into a relay for third-party traffic.
4. User-facing legal/help text now explicitly states that devices not running NEXUS are not automatically relayed through another user's phone.
5. Overlay address derivation now uses the fixed ULA /48 prefix plus 80 cryptographic bits derived from the installation public key.
6. Release version bumped to 2.2.1 / versionCode 23 and CI artifact naming updated.

## Verification run in this environment

- Static QA: PASS — 77 Kotlin files and 6 XML files checked.
- NEXUS v2 service two-node self-test: PASS.
- NEXUS v2.1 service self-test: PASS.
- NEXUS v2.2 address / identity / request self-test: PASS, including deterministic address format and 1,000 derived-address collision check.
- NEXUS v2.2 NXP TCP connection-request self-test: PASS.
- NEXUS share-link self-test: PASS.

## Not verified here

- Real Android APK compilation in this container: not executed because the Android SDK/Gradle installation is not present locally.
- Instrumentation on API 35/36: configured in GitHub Actions, not executed in this container.
- Physical two-phone / long-distance Internet test: requires actual Android devices and a real network path.

## IP-address requirement

A NEXUS overlay address can be made practically collision-resistant per installation, but an application cannot guarantee a globally unique public IPv4/IPv6 address for every user. Mobile carriers and ISPs can use NAT/CGNAT and share a public IP among several subscribers. A unique public egress address per user requires distinct public network egress resources.
