# NEXUS 2.1.0 Production Audit — 2026-09-28

## Status
This audit is evidence-based. No physical Android device, Android SDK/Gradle installation, or two-phone radio test was available in the audit environment.

## PASS
- Static QA: PASS — `tools/nexus-v1_2-static-qa.sh` completed successfully.
- Source archive integrity: PASS — source extracted successfully from the supplied ZIP.
- UI source emoji scan: PASS — no emoji code points found in Android main UI/source resources.
- TODO/FIXME scan: PASS — none found in Android main source/resources.
- Long-range routing code audit: FIXED — remote gateway routing was previously coupled to the local inbound-transit preference.
- Gateway advertisement: FIXED — an enabled, validated Internet gateway now advertises relay capability so remote nodes can select it.
- Local SOCKS credential: FIXED — removed the hard-coded `NEXUS-LOCAL` password from production configuration; a per-installation credential is generated and stored in the secure store.

## BLOCKED
- Android Gradle build: BLOCKED — the audit environment has no Android SDK/Gradle installation.
- Instrumentation tests: BLOCKED — no Android emulator/ADB environment was available.
- Physical Wi-Fi Direct/Bluetooth test: BLOCKED — no two physical Android devices were attached.
- Real 1 km / sea-separated test: BLOCKED — requires two real devices with a real IP backhaul and a reachable gateway/relay.
- Full host-side Kotlin self-test suite: BLOCKED — `kotlinc` is not installed in the audit environment.
- Several shell wrappers also lack executable permission after ZIP extraction; direct `bash script.sh` works where Kotlin is available.

## Important network limitation
Distance itself is not a software transport. Wi-Fi Direct/Bluetooth are local links. For devices separated by 1 km, a sea, or any other physical barrier, NEXUS needs a real long-range IP path such as cellular, Wi-Fi/Internet, Ethernet, satellite, or another reachable backhaul. If both devices are behind NAT and neither has a reachable relay/gateway or compatible direct path, software cannot create that missing physical/network path.

The supplied application already contains a real relay/gateway architecture. The audit patch makes outbound routed traffic independent from the local inbound-transit toggle and makes an enabled Internet gateway selectable by remote NEXUS nodes. A real public bootstrap/gateway endpoint is still required for arbitrary users who are not on the same local network.

## Build result
No APK is claimed as built in this environment.

The repository's reproducible Android build path remains `.github/workflows/android-build.yml`, which builds debug/release APKs and runs API 35/36 instrumentation smoke tests when executed in GitHub Actions with the Android SDK.

## Artifact
This audit deliverable is the patched source archive, not a signed APK.
