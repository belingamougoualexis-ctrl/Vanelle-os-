# NEXUS 2.2.1 — Guided Tour

## Included
- First-run interactive onboarding with a 70% black dim layer.
- Circular spotlight with clear cut-out and pulsing halo.
- Smooth target movement/resizing between steps.
- Explanatory popover with NEXUS mascot slot, title, short message, progress indicator, Next and Skip.
- Direct tap on the highlighted target advances the tour.
- Completion and skip are persisted locally with SharedPreferences.
- Reusable `GuidedTour` component taking a list of real Android `View` targets.
- Replay available from **Plus → Rejouer le didacticiel**.

## Current real NEXUS targets
1. Connecter automatiquement
2. Mon adresse NEXUS
3. Réseau
4. Plus

No fake controls or simulated network state are introduced by the onboarding.

## Validation note
The source package was checked for Kotlin syntax and project integration. A full Android Gradle build could not be executed in this environment because the archive does not contain a Gradle wrapper and the environment does not provide the Android SDK/Gradle toolchain. The `kotlinc` check therefore reports expected Android API unresolved references, but no Kotlin parser/syntax errors were reported.
