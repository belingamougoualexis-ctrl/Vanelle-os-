package com.nexus.network

fun main() {
    val address = "fd00:4e58:5553:1:1111:2222:3333:4444"
    val link = NexusShareLink.forAddress(address)
    check(link == "nexus://contact?address=fd00%3A4e58%3A5553%3A1%3A1111%3A2222%3A3333%3A4444") { link }
    check(NexusShareLink.addressFrom(android.net.UriTest.parse(link)) == address)
    check(NexusShareLink.addressFrom(android.net.UriTest.parse("https://example.com/?address=$address")) == null)
    check(runCatching { NexusShareLink.forAddress("2001:db8::1") }.isFailure)
    println("NEXUS SHARE LINK SELF-TEST: OK")
}
