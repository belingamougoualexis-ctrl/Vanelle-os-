#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/tools/.v2_2-addressing-selftest.jar"
trap 'rm -f "$OUT"' EXIT
kotlinc \
  "$ROOT/tools/test-stubs/v2_2/android/content/Context.kt" \
  "$ROOT/tools/test-stubs/v2_2/com/nexus/network/NexusSecureStore.kt" \
  "$ROOT/tools/test-stubs/v2_2/com/nexus/network/NexusConfig.kt" \
  "$ROOT/tools/test-stubs/v2_2/com/nexus/network/NexusDatabase.kt" \
  "$ROOT/tools/test-stubs/v2_2/com/nexus/network/NexusDht.kt" \
  "$ROOT/tools/test-stubs/v2_2/com/nexus/network/NsdController.kt" \
  "$ROOT/tools/test-stubs/v2_2/com/nexus/network/NxpProtocol.kt" \
  "$ROOT/tools/test-stubs/v2_2/com/nexus/network/NexusTrustStore.kt" \
  "$ROOT/tools/test-stubs/v2_2/com/nexus/network/NetworkKeyManager.kt" \
  "$ROOT/tools/test-stubs/v2_2/org/json/JSONObject.kt" \
  "$ROOT/tools/test-stubs/v2_2/org/json/JSONArray.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusIdentity.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusAddress.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusAddressBook.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusContacts.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusPeerRequests.kt" \
  "$ROOT/tools/nexus-v2_2-addressing-selftest.kt" \
  -include-runtime -d "$OUT"
java -jar "$OUT"
