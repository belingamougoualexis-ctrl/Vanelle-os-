import com.nexus.network.MeshRouter
import com.nexus.network.NexusConfig
import com.nexus.network.RelayProtocol
import com.nexus.network.RelayServer
import java.net.ServerSocket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

fun main() {
    val key = "nexus-failover-selftest"
    val target = ServerSocket(0)
    val ready = CountDownLatch(1)
    Thread {
        runCatching {
            ready.countDown()
            target.accept().use { socket ->
                val input = socket.getInputStream()
                val output = socket.getOutputStream()
                val buf = ByteArray(8)
                input.readFully(buf)
                output.write(buf.reversedArray())
                output.flush()
            }
        }
    }.apply { isDaemon = true; start() }

    val fallbackPort = ServerSocket(0).use { it.localPort }
    val gatewayPort = ServerSocket(0).use { it.localPort }

    // The first gateway deliberately has no direct Internet route. Its only
    // path is another reachable NEXUS gateway, so the test exercises recovery
    // after a direct path failure without requiring any simulated success.
    val secondGateway = RelayServer(
        port = fallbackPort,
        nodeIdProvider = { "SECOND" },
        secretProvider = { listOf(key) },
        directInternetAvailable = { true },
        nextHopSelector = { null },
        protectSocket = { true }
    )
    val peers = listOf(
        com.nexus.network.NsdController.Peer(
            name = "SECOND", host = "127.0.0.1", port = fallbackPort,
            gateway = true, relay = true, gatewayDistance = 0,
            gatewayPath = listOf("SECOND"), latencyMs = 1.0, lastSeenAt = System.currentTimeMillis()
        )
    )
    val router = MeshRouter("FIRST") { peers }
    val firstGateway = RelayServer(
        port = gatewayPort,
        nodeIdProvider = { "FIRST" },
        secretProvider = { listOf(key) },
        directInternetAvailable = { false },
        nextHopSelector = { visited -> router.chooseNextHop(visited, router.gatewayDistance(false, true)) },
        nextHopCandidatesSelector = { visited -> router.candidates(visited, router.gatewayDistance(false, true), 4) },
        protectSocket = { true }
    )

    check(ready.await(2, TimeUnit.SECONDS))
    secondGateway.start()
    firstGateway.start()
    Thread.sleep(250)

    val payload = "FAILSAFE".toByteArray(Charsets.US_ASCII)
    RelayProtocol.openRelay(
        host = "127.0.0.1", port = gatewayPort, targetHost = "127.0.0.1", targetPort = target.localPort,
        secret = key, fromNode = "CLIENT", visited = listOf("CLIENT"), ttl = NexusConfig.DEFAULT_ROUTE_TTL,
        timeoutMs = 3_000
    ).use { channel ->
        channel.output.write(payload)
        channel.output.flush()
        val response = ByteArray(payload.size)
        channel.input.readFully(response)
        check(response.contentEquals(payload.reversedArray())) { "Le fallback n'a pas rétabli le tunnel" }
    }

    firstGateway.stop()
    secondGateway.stop()
    target.close()
    println("NEXUS v2.2.3 NAT/FIREWALL FAILOVER SELF-TEST: OK")
}
