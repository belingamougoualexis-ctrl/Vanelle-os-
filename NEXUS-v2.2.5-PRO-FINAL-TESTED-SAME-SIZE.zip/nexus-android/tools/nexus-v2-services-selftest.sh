#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/tools/.v2-services-selftest.jar"
trap 'rm -f "$OUT"' EXIT
kotlinc \
  "$ROOT/tools/test-stubs/v2/android/content/Context.kt" \
  "$ROOT/tools/test-stubs/v2/com/nexus/network/NexusIdentity.kt" \
  "$ROOT/tools/test-stubs/v2/com/nexus/network/NexusConfig.kt" \
  "$ROOT/tools/test-stubs/v2/com/nexus/network/NetworkKeyManager.kt" \
  "$ROOT/tools/test-stubs/v2/com/nexus/network/NexusVpnRegistry.kt" \
  "$ROOT/tools/test-stubs/v2/com/nexus/network/NexusTrustStore.kt" \
  "$ROOT/tools/test-stubs/v2/org/json/JSONObject.kt" \
  "$ROOT/tools/test-stubs/v2/org/json/JSONArray.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusDatabase.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusCompute.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusMessageOutbox.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusServiceProtocol.kt" \
  "$ROOT/tools/nexus_v2_services_selftest.kt" \
  -include-runtime -d "$OUT"
java -jar "$OUT"
