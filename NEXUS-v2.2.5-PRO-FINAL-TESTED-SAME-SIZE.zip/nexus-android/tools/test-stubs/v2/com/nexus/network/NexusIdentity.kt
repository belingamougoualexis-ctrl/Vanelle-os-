package com.nexus.network
import android.content.Context

object NexusIdentity {
    private const val KEY = "NODE_NETWORK_KEY_FOR_TEST"
    fun nodeId(context: Context): String = context.getSharedPreferences("identity", Context.MODE_PRIVATE).getString("node", "NODE-A")!!
    fun setNodeId(context: Context, node: String) { context.getSharedPreferences("identity", Context.MODE_PRIVATE).edit().putString("node", node).apply() }
    fun networkKey(context: Context): String = KEY
    fun sign(context: Context, canonical: String): ByteArray = NexusCrypto.sha256Hex(canonical).toByteArray(Charsets.UTF_8)
    fun verify(publicKey: String, canonical: String, signature: String): Boolean = true
}
