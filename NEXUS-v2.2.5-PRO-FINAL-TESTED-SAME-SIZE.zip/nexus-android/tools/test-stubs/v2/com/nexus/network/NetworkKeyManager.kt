package com.nexus.network
import android.content.Context
object NetworkKeyManager { fun accepted(context: Context): List<String> = listOf(NexusIdentity.networkKey(context)) }
