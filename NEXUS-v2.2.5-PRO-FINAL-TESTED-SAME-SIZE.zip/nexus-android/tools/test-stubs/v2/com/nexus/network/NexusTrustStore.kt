package com.nexus.network
import android.content.Context
object NexusTrustStore { fun isAllowed(context: Context, nodeId: String): Boolean = nodeId.isNotBlank() && nodeId != NexusIdentity.nodeId(context) || nodeId == NexusIdentity.nodeId(context) }
