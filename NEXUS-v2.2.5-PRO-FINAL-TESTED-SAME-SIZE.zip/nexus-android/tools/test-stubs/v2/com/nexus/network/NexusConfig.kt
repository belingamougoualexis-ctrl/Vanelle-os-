package com.nexus.network
object NexusConfig { const val SERVICE_PORT: Int = 45460; const val DTN_BUNDLE_MAX_BYTES: Int = 8 * 1024 * 1024; const val MAX_HOPS: Int = 16 }
