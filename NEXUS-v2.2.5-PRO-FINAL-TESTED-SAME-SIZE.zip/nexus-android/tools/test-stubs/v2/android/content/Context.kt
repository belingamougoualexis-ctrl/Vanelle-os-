package android.content
import java.io.File
import kotlin.io.path.createTempDirectory

open class Context {
    open val filesDir: File = createTempDirectory("nexus-v2-node-").toFile().apply { mkdirs() }
    open val cacheDir: File = File(filesDir, "cache").apply { mkdirs() }
    private val prefs = mutableMapOf<String, SharedPreferences>()
    fun getSharedPreferences(name: String, mode: Int): SharedPreferences = prefs.getOrPut(name) { SharedPreferences() }
    companion object { const val MODE_PRIVATE: Int = 0 }
}

class SharedPreferences {
    private val values = mutableMapOf<String, Any?>()
    fun getString(key: String, def: String?): String? = values[key] as? String ?: def
    fun getLong(key: String, def: Long): Long = (values[key] as? Number)?.toLong() ?: def
    fun edit(): Editor = Editor(values)
    class Editor(private val values: MutableMap<String, Any?>) {
        fun putString(key: String, value: String?): Editor { values[key] = value; return this }
        fun putLong(key: String, value: Long): Editor { values[key] = value; return this }
        fun apply() = Unit
        fun commit(): Boolean = true
    }
}
