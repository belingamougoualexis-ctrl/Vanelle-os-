package com.nexus.network
import java.io.File
import java.security.MessageDigest
object NexusContentStore { fun sha256(file: File): String = MessageDigest.getInstance("SHA-256").digest(file.readBytes()).joinToString("") { "%02x".format(it.toInt() and 0xff) } }
