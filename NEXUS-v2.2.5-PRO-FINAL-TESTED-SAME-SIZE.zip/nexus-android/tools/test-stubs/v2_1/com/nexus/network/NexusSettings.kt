package com.nexus.network
import android.content.Context
object NexusSettings { fun edgeCacheQuotaBytes(context: Context): Long = 16L * 1024L * 1024L }
