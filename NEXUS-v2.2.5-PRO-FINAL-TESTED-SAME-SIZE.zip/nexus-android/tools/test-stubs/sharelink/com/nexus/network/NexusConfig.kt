package com.nexus.network
object NexusConfig { const val NODE_PORT=45454 }
