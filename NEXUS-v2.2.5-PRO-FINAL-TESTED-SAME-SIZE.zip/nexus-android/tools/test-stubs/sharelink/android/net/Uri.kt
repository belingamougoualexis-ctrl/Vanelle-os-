package android.net

import java.net.URLDecoder
import java.net.URLEncoder

class Uri constructor(private val raw: String) {
    val scheme: String? get() = raw.substringBefore(":", "").takeIf { it.isNotBlank() }
    val host: String? get() = raw.substringAfter("://", "").substringBefore("?").substringBefore("/").takeIf { it.isNotBlank() }
    fun getQueryParameter(key: String): String? = raw.substringAfter("?", "").split('&').firstOrNull { it.substringBefore('=') == key }?.substringAfter('=', "")?.let { URLDecoder.decode(it, "UTF-8") }
    override fun toString(): String = raw

    class Builder {
        private var scheme: String = ""
        private var authority: String = ""
        private val params = linkedMapOf<String, String>()
        fun scheme(value: String) = apply { scheme = value }
        fun authority(value: String) = apply { authority = value }
        fun appendQueryParameter(key: String, value: String) = apply { params[key] = value }
        fun build(): Uri {
            val q = params.entries.joinToString("&") { "${it.key}=${URLEncoder.encode(it.value, "UTF-8")}" }
            return Uri("$scheme://$authority?$q")
        }
    }
}

object UriTest { fun parse(value: String): Uri = Uri(value) }
