package com.nexus.network
import android.content.Context
object NexusIdentity {
    fun publicKeyBase64(context: Context): String = "TEST-PUBLIC-KEY"
    fun sign(context: Context, canonical: String): ByteArray = canonical.toByteArray()
    fun verify(publicKey: String, canonical: String, signature: String): Boolean = true
    fun nodeId(context: Context): String = "NODE-LOCAL"
    fun networkKey(context: Context): String = NetworkKeyManager.KEY
    fun generateKey(): String = NetworkKeyManager.KEY
    fun isPlausibleKey(value: String): Boolean = value.isNotBlank()
}
