package com.nexus.network
object NexusConfig {
    const val NODE_PORT=45454; const val RELAY_PORT=45456; const val DTN_BUNDLE_MAX_BYTES=8*1024*1024; const val MAX_HOPS=64; const val MAX_ADVERTISED_PATH=32
}
