package com.nexus.network
import android.content.Context
object NexusAddress { fun overlayIpv6(context:Context)=NexusAddressTest.currentTarget; fun overlayIpv6FromPublicKey(publicKeyBase64:String)="fd00:4e58:5553:1:9999:aaaa:bbbb:cccc" }
object NexusAddressTest { var currentTarget="fd00:4e58:5553:1:1111:2222:3333:4444" }
