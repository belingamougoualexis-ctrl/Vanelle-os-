package com.nexus.network
object NexusPresence { fun verifyDhtRecord(record: NexusDht.Record): Boolean = false }
