package com.nexus.network
import android.content.Context
import org.json.JSONObject
object NexusPeerRequests {
 data class Request(val id:String,val targetAddress:String,val senderNodeId:String,val senderAddress:String,val senderPublicKey:String,val senderName:String,val body:String,val createdAt:Long,val expiresAt:Long,val signature:String)
 fun create(context:Context,targetAddress:String,body:String,senderName:String)=Request("created-12345678",targetAddress,NexusIdentity.nodeId(context),NexusAddress.overlayIpv6(context),NexusIdentity.publicKeyBase64(context),senderName,body,System.currentTimeMillis(),System.currentTimeMillis()+60_000,"SIG")
 fun decodeWire(wire:String):Request?=runCatching{val j=JSONObject(NexusCrypto.decode(wire));Request(j.getString("id"),j.getString("targetAddress"),j.getString("senderNodeId"),j.getString("senderAddress"),j.getString("senderPublicKey"),j.getString("senderName"),j.getString("body"),j.getLong("createdAt"),j.getLong("expiresAt"),j.getString("signature"))}.getOrNull()
 fun verify(request:Request)=request.signature.isNotBlank()
 fun save(context:Context,request:Request){ }
 fun verifyDhtRecord(record:NexusDht.Record)=false
}
