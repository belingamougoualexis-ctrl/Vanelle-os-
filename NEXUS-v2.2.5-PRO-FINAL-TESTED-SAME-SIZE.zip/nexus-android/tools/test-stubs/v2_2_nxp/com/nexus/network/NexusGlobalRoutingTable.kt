package com.nexus.network
import java.security.MessageDigest
object NexusGlobalRoutingTable {
    fun domainFor(nodeId:String):String { val h=MessageDigest.getInstance("SHA-256").digest(nodeId.toByteArray()); return "NXD-"+h.copyOfRange(0,6).joinToString(""){ "%02x".format(it.toInt() and 255) } }
    fun domainPrefix(domainId:String)= "nexus:$domainId"
}
