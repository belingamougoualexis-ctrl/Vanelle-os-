package com.nexus.network
class NexusDht(private val id:String){
 data class Record(val key:String,val value:String,val publisher:String,val createdAt:Long,val expiresAt:Long,val signature:String)
 fun get(key:String):Record?=null
 fun fromWire(wire:String):Record?=null
 fun wire(record:Record)=record.value
 fun verify(record:Record,publicKey:String)=true
 fun put(record:Record)=true
 fun recordsSnapshot():List<Record> = emptyList()
}
