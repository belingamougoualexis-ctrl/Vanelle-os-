package com.nexus.network
object NexusAdmission {
    data class Stamp(val nodeId:String,val publicKey:String,val nonce:Long,val difficultyBits:Int,val digestHex:String)
    fun stamp(nodeId:String,publicKey:String)=Stamp(nodeId,publicKey,1,4,NexusCrypto.sha256Hex("v=1|node=$nodeId|pub=$publicKey|nonce=1"))
    fun verify(stamp:Stamp)=stamp.nodeId.isNotBlank() && stamp.publicKey.isNotBlank()
}
