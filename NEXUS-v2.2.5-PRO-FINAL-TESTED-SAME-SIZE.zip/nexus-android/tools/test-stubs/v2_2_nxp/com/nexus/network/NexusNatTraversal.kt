package com.nexus.network
object NexusNatTraversal { data class Candidate(val address:String,val port:Int,val source:String) }
