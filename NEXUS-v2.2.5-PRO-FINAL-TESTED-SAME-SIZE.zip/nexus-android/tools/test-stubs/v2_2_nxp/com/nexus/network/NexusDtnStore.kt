package com.nexus.network
import java.io.File
class NexusDtnStore {
    fun enqueue(destination:String,payload:ByteArray,ttlMs:Long,priority:Int,origin:String,visited:List<String>,id:String):String=id
    data class Bundle(val id:String,val origin:String,val destination:String,val payloadFile:File,val createdAt:Long,val expiresAt:Long,val attempts:Int,val priority:Int,val visited:List<String>) }
