package com.nexus.network
import android.content.Context
object NexusNaming {
 data class Record(val name:String,val nodeId:String,val publicKey:String)
 fun resolve(context:Context,name:String):Record?=null
 fun wire(record:Record)=record.name
 fun fromWire(wire:String):Record?=Record(wire,"TEST-NODE","TEST-PUBLIC")
}
