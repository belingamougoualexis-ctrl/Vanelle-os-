package com.nexus.network
import android.content.Context
object NetworkKeyManager {
    fun accepted(context: Context): List<String> = listOf(NexusIdentity.networkKey(context))
    fun generateKey(): String = "NXK-TEST-${System.nanoTime()}"
    fun isPlausibleKey(value: String): Boolean = value.trim().length >= 8
}
