package com.nexus.network
import android.content.Context
object NexusTrustStore {
    fun isAllowed(context:Context,name:String)=true
    fun reputation(context:Context,name:String)=1.0
}
