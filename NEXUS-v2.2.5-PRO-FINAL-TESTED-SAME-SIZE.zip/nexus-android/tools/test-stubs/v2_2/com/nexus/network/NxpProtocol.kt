package com.nexus.network
import android.content.Context
object NxpProtocol {
    fun queryDhtRecord(context:Context,host:String,port:Int,key:String):NexusDht.Record?=null
    fun sendConnectionRequest(context:Context,host:String,port:Int,request:NexusPeerRequests.Request):Boolean=false
    fun pushDhtRecord(host:String,port:Int,record:NexusDht.Record,secretProvider:()->List<String>):Boolean=false
}
