package com.nexus.network
import android.content.Context
import java.util.WeakHashMap
object NexusSecureStore {
    private val values = WeakHashMap<Context, MutableMap<String,String>>()
    private fun store(context: Context) = synchronized(values) { values.getOrPut(context) { mutableMapOf() } }
    fun get(context: Context,key:String):String? = store(context)[key]
    fun put(context: Context,key:String,value:String){ store(context)[key]=value }
}
