package com.nexus.network
import android.content.Context
object NexusDatabase {
    data class Record(val database:String,val key:String,val value:String,val version:Long,val nodeId:String,val hash:String)
    private val values=mutableMapOf<String,Record>()
    fun put(context:Context,db:String,key:String,value:String):Record{
        val r=Record(db,key,value,System.currentTimeMillis(),NexusIdentity.nodeId(context),NexusCrypto.sha256Hex(value))
        values["$db/$key"]=r; return r
    }
    fun get(context:Context,db:String,key:String):Record? = values["$db/$key"]
}
