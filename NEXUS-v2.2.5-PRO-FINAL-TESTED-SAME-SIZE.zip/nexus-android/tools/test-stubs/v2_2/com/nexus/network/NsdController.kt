package com.nexus.network
class NsdController {
    data class Peer(val name:String,val host:String,val port:Int,val gateway:Boolean=false,val relay:Boolean=false,val gatewayDistance:Int=Int.MAX_VALUE,val gatewayPath:List<String> = emptyList(),val latencyMs:Double=Double.POSITIVE_INFINITY,val packetLossPct:Double=100.0,val bandwidthMbps:Double=0.0,val p2p:Boolean=false,val identityPublicKey:String="",val gatewayPublicKey:String="",val authenticatedIdentity:Boolean=false,val lastSeenAt:Long=System.currentTimeMillis(),val consecutiveFailures:Int=0)
}
