package com.nexus.network
import android.content.Context
class NexusDht(private val localNodeId:String){
    data class Record(val key:String,val value:String,val publisher:String,val createdAt:Long,val expiresAt:Long,val signature:String)
    fun signed(context:Context,key:String,value:String,ttlMs:Long=30L*24*60*60*1000):Record{
        val created=System.currentTimeMillis(); val expires=created+ttlMs
        val canonical="v1|$key|$value|${NexusIdentity.nodeId(context)}|$created|$expires"
        return Record(key,value,NexusIdentity.nodeId(context),created,expires,NexusCrypto.encodeBytes(NexusIdentity.sign(context,canonical)))
    }
}
