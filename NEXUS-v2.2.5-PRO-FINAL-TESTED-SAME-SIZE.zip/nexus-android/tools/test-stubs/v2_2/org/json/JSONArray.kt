package org.json

class JSONArray() {
    private val values = mutableListOf<Any?>()

    constructor(text: String) : this() {
        val obj = JSONObject("{\"v\":$text}")
        values.addAll(obj.getJSONArray("v").toList())
    }

    internal constructor(list: List<Any?>) : this() {
        values.addAll(list)
    }

    constructor(items: Collection<*>) : this() {
        values.addAll(items)
    }

    fun put(value: Any?): JSONArray {
        values.add(value)
        return this
    }

    fun length(): Int = values.size

    fun getString(index: Int): String = values[index] as? String ?: error("Missing string")
    fun getJSONObject(index: Int): JSONObject = values[index] as? JSONObject ?: error("Missing object")

    fun remove(index: Int): Any? = if (index in values.indices) values.removeAt(index) else null

    internal fun toList(): List<Any?> = values.toList()

    override fun toString(): String = values.joinToString(prefix = "[", postfix = "]") { encode(it) }

    private fun encode(value: Any?): String = when (value) {
        null -> "null"
        is String -> "\"${escape(value)}\""
        is Number, is Boolean -> value.toString()
        is JSONObject -> value.toString()
        is JSONArray -> value.toString()
        is Map<*, *> -> value.entries.joinToString(prefix = "{", postfix = "}") { (k, v) ->
            "\"${escape(k.toString())}\":${encode(v)}"
        }
        is Collection<*> -> value.joinToString(prefix = "[", postfix = "]") { encode(it) }
        else -> "\"${escape(value.toString())}\""
    }

    private fun escape(value: String): String = buildString {
        for (c in value) {
            append(
                when (c) {
                    '\\' -> "\\\\"
                    '"' -> "\\\""
                    '\n' -> "\\n"
                    '\r' -> "\\r"
                    '\t' -> "\\t"
                    else -> c
                }
            )
        }
    }
}
