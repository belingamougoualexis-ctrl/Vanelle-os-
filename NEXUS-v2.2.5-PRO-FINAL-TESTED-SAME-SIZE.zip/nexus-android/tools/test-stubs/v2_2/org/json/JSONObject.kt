package org.json

class JSONObject() {
    private val map = LinkedHashMap<String, Any?>()
    constructor(text: String) : this() {
        val parser = Parser(text)
        val value = parser.parseValue()
        require(value is Map<*, *>) { "JSON object expected" }
        value.forEach { (k, v) -> map[k as String] = v }
    }

    fun put(key: String, value: Any?): JSONObject { map[key] = value; return this }
    fun getString(key: String): String = (map[key] as? String) ?: error("Missing string: $key")
    fun getLong(key: String): Long = when (val v = map[key]) { is Number -> v.toLong(); is String -> v.toLong(); else -> error("Missing long: $key") }
    fun getInt(key: String): Int = when (val v = map[key]) { is Number -> v.toInt(); is String -> v.toInt(); else -> error("Missing int: $key") }
    fun getJSONArray(key: String): JSONArray = (map[key] as? List<*>)?.let { JSONArray(it.toList()) } ?: error("Missing array: $key")
    fun optJSONArray(key: String): JSONArray? = (map[key] as? List<*>)?.let { JSONArray(it.toList()) }
    fun optBoolean(key: String, fallback: Boolean = false): Boolean = map[key] as? Boolean ?: fallback
    fun optString(key: String, fallback: String = ""): String = map[key] as? String ?: fallback
    override fun toString(): String = Writer.write(map)

    private class Parser(private val s: String) {
        private var i = 0
        fun parseValue(): Any? {
            ws()
            return when (peek()) {
                '{' -> parseObject()
                '[' -> parseArray()
                '"' -> parseString()
                't' -> { expect("true"); true }
                'f' -> { expect("false"); false }
                'n' -> { expect("null"); null }
                else -> parseNumber()
            }
        }
        private fun parseObject(): Map<String, Any?> {
            take('{'); ws(); val out = LinkedHashMap<String, Any?>()
            if (peek() == '}') { take('}'); return out }
            while (true) {
                ws(); val key = parseString(); ws(); take(':'); out[key] = parseValue(); ws()
                if (peek() == '}') { take('}'); return out }
                take(',')
            }
        }
        private fun parseArray(): List<Any?> {
            take('['); ws(); val out = ArrayList<Any?>()
            if (peek() == ']') { take(']'); return out }
            while (true) { out += parseValue(); ws(); if (peek() == ']') { take(']'); return out }; take(',') }
        }
        private fun parseString(): String {
            take('"'); val out = StringBuilder()
            while (true) {
                val c = next()
                when {
                    c == '"' -> return out.toString()
                    c == '\\' -> when (val e = next()) {
                        '"','\\','/' -> out.append(e)
                        'b' -> out.append('\b'); 'f' -> out.append('\u000c'); 'n' -> out.append('\n'); 'r' -> out.append('\r'); 't' -> out.append('\t')
                        'u' -> out.append(next().toString()+next()+next()+next()).also { /* replaced below */ }
                        else -> error("Bad escape")
                    }
                    else -> out.append(c)
                }
            }
        }
        private fun parseNumber(): Number {
            val start = i
            while (i < s.length && s[i] !in " \t\r\n,]}") i++
            val raw = s.substring(start, i)
            return raw.toLongOrNull() ?: raw.toDoubleOrNull() ?: error("Bad number")
        }
        private fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        private fun peek(): Char = s.getOrNull(i) ?: error("Unexpected end")
        private fun next(): Char = s.getOrNull(i++) ?: error("Unexpected end")
        private fun take(c: Char) { require(next() == c) { "Expected $c" } }
        private fun expect(word: String) { require(s.startsWith(word, i)); i += word.length }
    }

    private object Writer {
        fun write(v: Any?): String = when (v) {
            null -> "null"
            is String -> "\"${escape(v)}\""
            is Number, is Boolean -> v.toString()
            is JSONObject -> v.toString()
            is JSONArray -> v.toString()
            is Collection<*> -> v.joinToString(prefix = "[", postfix = "]") { write(it) }
            is Map<*, *> -> v.entries.joinToString(prefix = "{", postfix = "}") { "\"${escape(it.key as String)}\":${write(it.value)}" }
            else -> "\"${escape(v.toString())}\""
        }
        private fun escape(s: String): String = buildString { for (c in s) append(when(c) { '\\' -> "\\\\"; '"' -> "\\\""; '\n' -> "\\n"; '\r' -> "\\r"; '\t' -> "\\t"; else -> c }) }
    }
}
