package android.content
import java.io.File
import kotlin.io.path.createTempDirectory
open class Context {
    open val filesDir: File = createTempDirectory("nexus-v2_2-").toFile().apply { mkdirs() }
    private val prefs = mutableMapOf<String, SharedPreferences>()
    fun getSharedPreferences(name: String, mode: Int): SharedPreferences = prefs.getOrPut(name) { SharedPreferences() }
    companion object { const val MODE_PRIVATE: Int = 0 }
}
class SharedPreferences {
    private val values = mutableMapOf<String, Any?>()
    fun getString(key:String, def:String?):String? = values[key] as? String ?: def
    fun getBoolean(key:String, def:Boolean):Boolean = values[key] as? Boolean ?: def
    fun edit() = Editor(values)
    class Editor(private val values:MutableMap<String,Any?>){
        fun putString(k:String,v:String?):Editor{values[k]=v;return this}
        fun putBoolean(k:String,v:Boolean):Editor{values[k]=v;return this}
        fun remove(k:String):Editor{values.remove(k);return this}
        fun apply()=Unit
        fun commit()=true
    }
}
