#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/tools/.v2_1-services-selftest.jar"
trap 'rm -f "$OUT"' EXIT
kotlinc \
  "$ROOT/tools/test-stubs/v2_1/android/content/Context.kt" \
  "$ROOT/tools/test-stubs/v2_1/com/nexus/network/NexusSettings.kt" \
  "$ROOT/tools/test-stubs/v2_1/com/nexus/network/NexusContentStore.kt" \
  "$ROOT/tools/test-stubs/v2_1/com/nexus/network/NexusIdentity.kt" \
  "$ROOT/tools/test-stubs/v2_1/com/nexus/network/NexusConfig.kt" \
  "$ROOT/tools/test-stubs/v2_1/org/json/JSONObject.kt" \
  "$ROOT/tools/test-stubs/v2_1/org/json/JSONArray.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusEdgeCache.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusErasureCoding.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusCapabilities.kt" \
  "$ROOT/tools/nexus_v2_1_services_selftest.kt" \
  -include-runtime -d "$OUT"
java -jar "$OUT"
