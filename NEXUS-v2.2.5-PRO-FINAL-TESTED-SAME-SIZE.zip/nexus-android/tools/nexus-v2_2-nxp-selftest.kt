package com.nexus.network

import android.content.Context
import java.net.ServerSocket
import java.net.Socket
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import kotlin.concurrent.thread

private fun readLine(socket: Socket): String = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.US_ASCII)).readLine()
private fun sendLine(socket: Socket, line: String) = PrintWriter(socket.getOutputStream(), true).println(line)

fun main() {
    val serverContext = Context()
    val clientContext = Context()
    NexusAddressTest.currentTarget = "fd00:4e58:5553:1:1111:2222:3333:4444"
    val now = System.currentTimeMillis()
    val request = NexusPeerRequests.Request(
        id = "req-test-12345678", targetAddress = NexusAddressTest.currentTarget,
        senderNodeId = "NX-CLIENT", senderAddress = "fd00:4e58:5553:1:aaaa:bbbb:cccc:dddd",
        senderPublicKey = "PUB", senderName = "Client", body = "Bonjour", createdAt = now,
        expiresAt = now + 60_000L, signature = "SIG"
    )

    // 1) Real server handler: authenticated handshake + real CONNECT-REQUEST branch.
    val handlerServer = ServerSocket(0)
    val handlerThread = thread(start = true) {
        handlerServer.use { ss ->
            ss.accept().use { socket ->
                NxpProtocol.serverHandshake(
                    socket, "NX-SERVER", gateway = false, relay = false, gatewayDistance = Int.MAX_VALUE,
                    identityContext = serverContext, secretProvider = { listOf(NetworkKeyManager.KEY) }
                )
            }
        }
    }
    Socket("127.0.0.1", handlerServer.localPort).use { socket ->
        val nonce = NexusCrypto.nonce(24)
        val auth = NexusCrypto.hmacHex(NetworkKeyManager.KEY, "v=4&kind=hello&node=probe&nonce=$nonce")
        sendLine(socket, "NEXUS/1 HELLO v=4 node=probe nonce=$nonce auth=$auth")
        val hello = readLine(socket)
        check(hello.startsWith("NEXUS/1 HELLO-OK")) { "server handshake failed: $hello" }
        val wire = NexusCrypto.encode(org.json.JSONObject().apply {
            put("id", request.id); put("targetAddress", request.targetAddress); put("senderNodeId", request.senderNodeId); put("senderAddress", request.senderAddress)
            put("senderPublicKey", request.senderPublicKey); put("senderName", request.senderName); put("body", request.body); put("createdAt", request.createdAt); put("expiresAt", request.expiresAt); put("signature", request.signature)
        }.toString())
        sendLine(socket, "CONNECT-REQUEST $wire")
        check(readLine(socket) == "CONNECT-REQUEST-OK") { "CONNECT-REQUEST branch rejected a valid request" }
    }
    handlerThread.join(5_000)

    // 2) Real client helper: authenticated connect + request transmission over a real TCP socket.
    val clientServer = ServerSocket(0)
    val clientThread = thread(start = true) {
        clientServer.use { ss ->
            ss.accept().use { socket ->
                val hello = readLine(socket)
                val fields = hello.split(' ').drop(2).mapNotNull { token ->
                    val i = token.indexOf('='); if (i <= 0) null else token.substring(0, i) to token.substring(i + 1)
                }.toMap()
                val nonce = fields["nonce"] ?: error("client hello missing nonce")
                val context = "gateway=false&relay=false&distance=${Int.MAX_VALUE}&path=${NexusCrypto.encode("")}&gatewayKey=${NexusCrypto.encode("")}&identityKey=${NexusCrypto.encode("")}&nat=${NexusCrypto.encode("")}&domain=${NexusGlobalRoutingTable.domainFor("NX-MOCK")}&prefix=${NexusCrypto.encode("")}"
                val auth = NexusCrypto.hmacHex(NetworkKeyManager.KEY, "v=4&kind=hello-ok&node=NX-MOCK&nonce=$nonce&$context")
                sendLine(socket, "NEXUS/1 HELLO-OK v=6 node=${NexusCrypto.encode("NX-MOCK")} gateway=false relay=false distance=${Int.MAX_VALUE} path=${NexusCrypto.encode("")} gatewayKey=${NexusCrypto.encode("")} identityKey=${NexusCrypto.encode("")} identitySig=${NexusCrypto.encode("")} admissionNonce=-1 admissionBits=0 admissionDigest= nat=${NexusCrypto.encode("")} domain=${NexusGlobalRoutingTable.domainFor("NX-MOCK")} prefix=${NexusCrypto.encode("")} nonce=$nonce auth=$auth")
                val line = readLine(socket)
                check(line.startsWith("CONNECT-REQUEST ")) { "client helper did not send CONNECT-REQUEST" }
                sendLine(socket, "CONNECT-REQUEST-OK")
            }
        }
    }
    check(NxpProtocol.sendConnectionRequest(clientContext, "127.0.0.1", clientServer.localPort, request)) { "client CONNECT-REQUEST helper failed" }
    clientThread.join(5_000)

    // 3) Direct public-IP flow: authenticate a real NXP endpoint, derive its stable NEXUS address, then send the request.
    val endpointServer = ServerSocket(0)
    val remoteContext = Context()
    val endpointThread = thread(start = true) {
        endpointServer.use { ss ->
            // Probe connection.
            ss.accept().use { socket ->
                val hello = readLine(socket)
                val fields = hello.split(' ').drop(2).mapNotNull { token ->
                    val i = token.indexOf('='); if (i <= 0) null else token.substring(0, i) to token.substring(i + 1)
                }.toMap()
                val nonce = fields["nonce"] ?: error("probe hello missing nonce")
                val identityKey = NexusIdentity.publicKeyBase64(remoteContext)
                val path = NexusCrypto.encode("")
                val gatewayKey = NexusCrypto.encode("")
                val nat = NexusCrypto.encode("")
                val domain = NexusGlobalRoutingTable.domainFor("NX-REMOTE")
                val prefix = NexusCrypto.encode("")
                val canonical = "node=NX-REMOTE&nonce=$nonce&gateway=false&relay=false&distance=${Int.MAX_VALUE}&path=$path&gatewayKey=$gatewayKey&identityKey=${NexusCrypto.encode(identityKey)}&nat=$nat&domain=$domain&prefix=$prefix"
                val signature = NexusCrypto.encodeBytes(NexusIdentity.sign(remoteContext, canonical))
                val admission = NexusAdmission.stamp("NX-REMOTE", identityKey)
                val capsContext = "gateway=false&relay=false&distance=${Int.MAX_VALUE}&path=$path&gatewayKey=$gatewayKey&identityKey=${NexusCrypto.encode(identityKey)}&nat=$nat&domain=$domain&prefix=$prefix"
                val auth = NexusCrypto.hmacHex(NetworkKeyManager.KEY, "v=4&kind=hello-ok&node=NX-REMOTE&nonce=$nonce&$capsContext")
                sendLine(socket, "NEXUS/1 HELLO-OK v=6 node=${NexusCrypto.encode("NX-REMOTE")} gateway=false relay=false distance=${Int.MAX_VALUE} path=$path gatewayKey=$gatewayKey identityKey=${NexusCrypto.encode(identityKey)} identitySig=${NexusCrypto.encode(signature)} admissionNonce=${admission.nonce} admissionBits=${admission.difficultyBits} admissionDigest=${admission.digestHex} nat=$nat domain=$domain prefix=$prefix nonce=$nonce auth=$auth")
                repeat(4) {
                    val ping = readLine(socket)
                    check(ping.startsWith("PING ")) { "probe ping missing" }
                    sendLine(socket, "PONG ${ping.removePrefix("PING ")}")
                }
            }
            // Request connection.
            ss.accept().use { socket ->
                val hello = readLine(socket)
                val fields = hello.split(' ').drop(2).mapNotNull { token ->
                    val i = token.indexOf('='); if (i <= 0) null else token.substring(0, i) to token.substring(i + 1)
                }.toMap()
                val nonce = fields["nonce"] ?: error("request hello missing nonce")
                val ctx = "gateway=false&relay=false&distance=${Int.MAX_VALUE}&path=${NexusCrypto.encode("")}&gatewayKey=${NexusCrypto.encode("")}&identityKey=${NexusCrypto.encode("")}&nat=${NexusCrypto.encode("")}&domain=${NexusGlobalRoutingTable.domainFor("NX-REMOTE")}&prefix=${NexusCrypto.encode("")}"
                val auth = NexusCrypto.hmacHex(NetworkKeyManager.KEY, "v=4&kind=hello-ok&node=NX-REMOTE&nonce=$nonce&$ctx")
                sendLine(socket, "NEXUS/1 HELLO-OK v=6 node=${NexusCrypto.encode("NX-REMOTE")} gateway=false relay=false distance=${Int.MAX_VALUE} path=${NexusCrypto.encode("")} gatewayKey=${NexusCrypto.encode("")} identityKey=${NexusCrypto.encode("")} identitySig=${NexusCrypto.encode("")} admissionNonce=-1 admissionBits=0 admissionDigest= nat=${NexusCrypto.encode("")} domain=${NexusGlobalRoutingTable.domainFor("NX-REMOTE")} prefix=${NexusCrypto.encode("")} nonce=$nonce auth=$auth")
                val line = readLine(socket)
                check(line.startsWith("CONNECT-REQUEST ")) { "direct endpoint did not receive request" }
                sendLine(socket, "CONNECT-REQUEST-OK")
            }
        }
    }
    check(NxpProtocol.sendConnectionRequestByEndpoint(clientContext, "127.0.0.1", endpointServer.localPort, "Direct endpoint test", "Client")) { "direct endpoint flow failed" }
    endpointThread.join(5_000)

    println("NEXUS v2.2 NXP CONNECTION-REQUEST TCP SELF-TEST: OK")
}
