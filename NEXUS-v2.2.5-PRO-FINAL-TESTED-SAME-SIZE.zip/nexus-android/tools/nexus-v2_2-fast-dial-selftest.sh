#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
kotlinc \
  "$ROOT/tools/test-stubs/android/content/Context.kt" \
  "$ROOT/tools/test-stubs/android/net/ConnectivityManager.kt" \
  "$ROOT/tools/test-stubs/android/net/Network.kt" \
  "$ROOT/tools/test-stubs/android/net/NetworkCapabilities.kt" \
  "$ROOT/tools/test-stubs/android/net/LinkProperties.kt" \
  "$ROOT/tools/test-stubs/android/content/pm/PackageManager.kt" \
  "$ROOT/tools/test-stubs/android/os/Build.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusMultipathPlanner.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusPhysicalBackhaul.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusExternalLinkProtocol.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusTransportManager.kt" \
  "$ROOT/tools/nexus-v2_2-fast-dial-selftest.kt" \
  -include-runtime -d "$OUT/test.jar"
java -jar "$OUT/test.jar"
