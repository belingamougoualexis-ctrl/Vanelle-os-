#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/tools/.longhaul-selftest.jar"
trap 'rm -f "$OUT"' EXIT
kotlinc "$ROOT/app/src/main/java/com/nexus/network/NexusLongHaul.kt" "$ROOT/tools/nexus-v2_2_1-longhaul-selftest.kt" -include-runtime -d "$OUT"
java -jar "$OUT"
