#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/tools/.nexus-sharelink-selftest.jar"
trap 'rm -f "$OUT"' EXIT
kotlinc \
  "$ROOT/tools/test-stubs/sharelink/android/content/Context.kt" \
  "$ROOT/tools/test-stubs/sharelink/android/net/Uri.kt" \
  "$ROOT/tools/test-stubs/sharelink/com/nexus/network/NexusIdentity.kt" \
  "$ROOT/tools/test-stubs/sharelink/com/nexus/network/NexusConfig.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusAddress.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusShareLink.kt" \
  "$ROOT/tools/nexus-sharelink-selftest.kt" \
  -include-runtime -d "$OUT"
java -jar "$OUT"
