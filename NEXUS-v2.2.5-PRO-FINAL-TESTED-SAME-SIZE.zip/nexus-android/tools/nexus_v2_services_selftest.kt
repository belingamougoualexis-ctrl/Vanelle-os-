import android.content.Context
import com.nexus.network.NexusCompute
import com.nexus.network.NexusDatabase
import com.nexus.network.NexusIdentity
import com.nexus.network.NexusMessageOutbox
import com.nexus.network.NexusServiceProtocol
import com.nexus.network.NexusServiceServer

fun check(v: Boolean, msg: String) { if (!v) error(msg) }

fun main() {
    val a = Context(); val b = Context()
    NexusIdentity.setNodeId(a, "NODE-A")
    NexusIdentity.setNodeId(b, "NODE-B")

    val serverA = NexusServiceServer(a, 45460)
    val serverB = NexusServiceServer(b, 45461)
    serverA.start(); serverB.start()
    Thread.sleep(300)
    try {
        val record = NexusDatabase.put(a, "app", "hello", "nexus-v2")
        check(NexusServiceProtocol.putRemote(a, "127.0.0.1", record, 45461).isSuccess, "DB_PUT failed")
        val remote = NexusServiceProtocol.getRemote(a, "127.0.0.1", "app", "hello", 45461).getOrNull()
        check(remote?.value == "nexus-v2", "DB_GET value mismatch")

        check(NexusServiceProtocol.sendMessage(a, "127.0.0.1", NexusIdentity.nodeId(b), "message-deux-noeuds", 45461).isSuccess, "MSG_SEND failed")
        val messages = NexusServiceProtocol.pullMessages(b, "127.0.0.1", 45461)
        check(messages.isSuccess && messages.getOrThrow().any { it.body == "message-deux-noeuds" && it.sender == "NODE-A" }, "MSG_PULL failed")

        val task = NexusCompute.Task("task-v2-node", "SHA-256", "abc".toByteArray())
        val computed = NexusServiceProtocol.compute(a, "127.0.0.1", task, 45461).getOrThrow()
        check(computed.provider == "NODE-B", "remote compute provider mismatch")
        val expected = java.security.MessageDigest.getInstance("SHA-256").digest("abc".toByteArray()).joinToString("") { "%02x".format(it.toInt() and 255) }
        check(computed.output.joinToString("") { "%02x".format(it.toInt() and 255) } == expected, "remote compute output mismatch")

        val list = NexusServiceProtocol.listRemote(a, "127.0.0.1", "app", 45461).getOrThrow()
        check(list.any { it.key == "hello" && it.value == "nexus-v2" }, "DB_LIST missing record")

        val outbox = NexusMessageOutbox(a)
        val queued = outbox.enqueue("NODE-B", "offline-message", "offline-task")
        check(outbox.pending().any { it.id == queued && it.recipient == "NODE-B" })
        outbox.defer(queued)
        check(outbox.pending().single { it.id == queued }.attempts == 1)
        outbox.ack(queued)
        check(outbox.pending().none { it.id == queued })
        println("NEXUS v2 SERVICES TWO-NODE SELFTEST: OK")
    } finally {
        serverA.stop(); serverB.stop()
    }
}
