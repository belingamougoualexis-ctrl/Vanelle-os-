#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/nexus-v0_6-real-selftest-$$"
mkdir -p "$OUT"
trap 'rm -rf "$OUT"' EXIT

kotlinc \
  "$ROOT/tools/test-stubs/android/net/VpnService.kt" \
  "$ROOT/tools/test-stubs/com/nexus/network/NsdController.kt" \
  "$ROOT/tools/test-stubs/com/nexus/network/NexusP2PDirectory.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusSecureFraming.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusStreamChannel.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/IpPacket.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/TcpOptions.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/Ipv6Packet.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/Ipv6FragmentReassembler.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/Icmpv6.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/Ipv6ControlPlane.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusVpnRegistry.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusUdpChannels.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusConfig.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NxpProtocol.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusLongHaul.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/RelayProtocol.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/DatagramRelayProtocol.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/RelayServer.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/MeshRouter.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/Socks5Server.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/UserSpaceIpStack.kt" \
  "$ROOT/tools/nexus_v0_6_real_selftest.kt" \
  -include-runtime -d "$OUT/test.jar"
java -jar "$OUT/test.jar"
