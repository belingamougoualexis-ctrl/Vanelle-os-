package com.nexus.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import java.net.Socket
import java.net.SocketAddress
import java.net.SocketException
import javax.net.SocketFactory
import kotlin.system.exitProcess

private class FakeSocket(
    private val delayMs: Long,
    private val succeed: Boolean
) : Socket() {
    @Volatile private var closedFlag = false
    override fun connect(endpoint: SocketAddress?, timeout: Int) {
        Thread.sleep(minOf(delayMs, timeout.toLong().coerceAtLeast(1L)))
        if (closedFlag) throw SocketException("closed")
        if (!succeed) throw SocketException("unreachable")
    }
    override fun close() { closedFlag = true }
}

private class FakeFactory(
    private val delayMs: Long,
    private val succeed: Boolean
) : SocketFactory() {
    override fun createSocket(): Socket = FakeSocket(delayMs, succeed)
    override fun createSocket(host: String, port: Int): Socket = createSocket()
    override fun createSocket(host: String, port: Int, localAddress: java.net.InetAddress, localPort: Int): Socket = createSocket()
    override fun createSocket(address: java.net.InetAddress, port: Int): Socket = createSocket()
    override fun createSocket(address: java.net.InetAddress, port: Int, localAddress: java.net.InetAddress, localPort: Int): Socket = createSocket()
}

private class FakeNetwork(
    override val networkHandle: Long,
    factory: SocketFactory
) : Network() {
    override val socketFactory: SocketFactory = factory
}

private class FakeCaps(
    private val validated: Boolean,
    override val linkDownstreamBandwidthKbps: Int,
    override val linkUpstreamBandwidthKbps: Int
) : NetworkCapabilities() {
    override fun hasTransport(transport: Int): Boolean = transport == NetworkCapabilities.TRANSPORT_WIFI
    override fun hasCapability(capability: Int): Boolean = when (capability) {
        NetworkCapabilities.NET_CAPABILITY_VALIDATED -> validated
        NetworkCapabilities.NET_CAPABILITY_NOT_METERED -> true
        else -> false
    }
}

private class FakeConnectivity(
    private val networks: Array<Network>,
    private val caps: Map<Network, NetworkCapabilities>
) : ConnectivityManager() {
    override val allNetworks: Array<Network> get() = networks
    override fun getNetworkCapabilities(network: Network): NetworkCapabilities? = caps[network]
}

private class FakeContext(private val cm: ConnectivityManager) : Context() {
    override fun <T> getSystemService(serviceClass: Class<T>): T? =
        if (serviceClass == ConnectivityManager::class.java) cm as T else super.getSystemService(serviceClass)
}

fun main() {
    val slow1 = FakeNetwork(1, FakeFactory(3_500, false))
    val fast = FakeNetwork(2, FakeFactory(120, true))
    val slow2 = FakeNetwork(3, FakeFactory(3_500, false))
    val slow3 = FakeNetwork(4, FakeFactory(3_500, false))
    val networks: Array<Network> = arrayOf(slow1, fast, slow2, slow3)
    val cm = FakeConnectivity(
        networks,
        networks.associateWith { FakeCaps(validated = true, linkDownstreamBandwidthKbps = 50_000, linkUpstreamBandwidthKbps = 20_000) }
    )
    val manager = NexusTransportManager(FakeContext(cm))
    val started = System.nanoTime()
    val (socket, transport) = manager.openTcpWithFailover("198.51.100.10", 443, timeoutMs = 4_000)
    val elapsedMs = (System.nanoTime() - started) / 1_000_000
    socket.close()
    check(transport.network.networkHandle == 2L) { "Le chemin rapide n'a pas gagné" }
    check(elapsedMs < 1_000L) { "Le dial parallèle est trop lent: ${elapsedMs}ms" }
    println("NEXUS FAST DIAL SELF-TEST: OK (${elapsedMs}ms, chemin 2 gagnant)")
    exitProcess(0)
}
