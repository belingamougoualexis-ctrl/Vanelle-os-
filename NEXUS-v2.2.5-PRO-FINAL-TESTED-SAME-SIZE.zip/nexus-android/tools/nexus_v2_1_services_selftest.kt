import com.nexus.network.NexusCapabilities
import com.nexus.network.NexusEdgeCache
import com.nexus.network.NexusErasureCoding
import java.io.File

fun main() {
    val data = "NEXUS-2.1-erasure-test-abcdefghijklmnopqrstuvwxyz".repeat(17).toByteArray()
    val stripe = NexusErasureCoding.encode(data)
    check(data.contentEquals(NexusErasureCoding.recover(stripe, null, stripe.dataB, stripe.parity)))
    check(data.contentEquals(NexusErasureCoding.recover(stripe, stripe.dataA, null, stripe.parity)))
    check(data.contentEquals(NexusErasureCoding.recover(stripe, stripe.dataA, stripe.dataB, null)))

    val context = android.content.Context()
    val subject = com.nexus.network.NexusIdentity.nodeId(context)
    val token = NexusCapabilities.issue(context, subject, "storage.read", "content/*", 60_000L)
    val roundTrip = NexusCapabilities.decode(NexusCapabilities.encode(token))
    check(NexusCapabilities.verify(roundTrip, subject, "storage.read", "content/*"))
    check(!NexusCapabilities.verify(roundTrip, subject, "storage.write", "content/*"))

    val source = File(context.filesDir, "edge-source.bin").apply { writeText("edge-cache") }
    val hash = com.nexus.network.NexusEdgeCache.javaClass // ensure object loads
    val digest = java.security.MessageDigest.getInstance("SHA-256").digest(source.readBytes()).joinToString("") { "%02x".format(it.toInt() and 0xff) }
    check(NexusEdgeCache.putFile(context, digest, source, 60_000L))
    val restored = File(context.filesDir, "restored.bin")
    check(NexusEdgeCache.restore(context, digest, restored))
    check(restored.readText() == "edge-cache")
    val stats = NexusEdgeCache.stats(context)
    check(stats.entries == 1)
    println("NEXUS v2.1 services self-test: OK")
}
