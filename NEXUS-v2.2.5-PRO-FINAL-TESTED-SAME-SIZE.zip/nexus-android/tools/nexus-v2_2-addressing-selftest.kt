package com.nexus.network

import android.content.Context

fun main() {
    val a = Context()
    val b = Context()

    val addrA1 = NexusAddress.overlayIpv6(a)
    val addrA2 = NexusAddress.overlayIpv6(a)
    val addrB = NexusAddress.overlayIpv6(b)
    check(addrA1 == addrA2) { "identity address changed" }
    check(addrA1 != addrB) { "distinct identities collided" }
    check(NexusAddress.isValidOverlay(addrA1)) { "overlay address not accepted" }
    check(addrA1.split(":").size == 8) { "overlay address must be a full IPv6 address" }
    check(addrA1.startsWith("fd00:4e58:5553:")) { "unexpected NEXUS ULA prefix" }
    check(NexusAddress.canonicalize(addrA1.uppercase()) == addrA1) { "IPv6 canonicalization failed" }

    val generated = (0 until 1000).map { i -> NexusAddress.overlayIpv6FromPublicKey("PUBLIC-KEY-$i") }
    check(generated.toSet().size == generated.size) { "collision detected in 1000 derived overlay addresses" }
    check(!NexusAddress.isValidOverlay("2001:db8::1")) { "non-NEXUS IPv6 accepted" }
    check(!NexusAddress.isValidOverlay("127.0.0.1")) { "IPv4 accepted as overlay" }

    val record = NexusAddressBook.own(a)
    check(NexusAddressBook.verify(record)) { "address record signature/derivation invalid" }
    check(NexusAddressBook.key(record.address).startsWith("nexus/address/")) { "bad address DHT key" }

    val request = NexusPeerRequests.create(a, addrB, "Demande NEXUS réelle", "Alice")
    check(NexusPeerRequests.verify(request)) { "request signature invalid" }
    check(NexusPeerRequests.pending(a).any { it.id == request.id }) { "request not persisted/pending" }
    check(NexusPeerRequests.accept(a, request.id) != null) { "request accept failed" }
    check(NexusPeerRequests.accepted(a).any { it.id == request.id }) { "request acceptance not persisted" }
    check(NexusDatabase.get(a, "messages", "${NexusIdentity.nodeId(a)}/${request.id}")?.value?.contains("Demande NEXUS réelle") == true) { "accepted message not stored" }
    val restarted = object : Context() { override val filesDir = a.filesDir }
    check(NexusPeerRequests.localInbox(restarted).any { it.id == request.id }) { "request not recoverable after restart" }

    println("NEXUS v2.2 ADDRESS / IDENTITY / REQUEST SELF-TEST: OK")
}
