package com.nexus.network

import android.content.Context
import android.location.Location
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Real directory lookup over authenticated NEXUS DHT peers. */
object NexusPresenceDirectory {
    data class Result(val records: List<NexusPresence.Record>, val sources: Int)

    fun search(context: Context, discovery: NsdController, scope: NexusPresence.Scope): Result {
        val peers = discovery.peersSnapshot()
            .filter { it.host.isNotBlank() && NexusTrustStore.isAllowed(context, it.name) }
            .sortedByDescending { NexusTrustStore.reputation(context, it.name) }
            .take(4)
        if (peers.isEmpty()) return Result(emptyList(), 0)

        val location = NexusPresence.currentLocation(context)
        val country = NexusPresence.deviceCountryCode(context)
        val prefixes = NexusPresence.relevantPrefixes(scope, location, country)
        if (scope != NexusPresence.Scope.NEARBY && prefixes.isEmpty()) return Result(emptyList(), peers.size)

        val executor = Executors.newFixedThreadPool(6) { r -> Thread(r, "nexus-presence-query").apply { isDaemon = true } }
        val futures = ArrayList<java.util.concurrent.Future<List<NexusDht.Record>>>()
        try {
            if (scope == NexusPresence.Scope.WORLD || scope == NexusPresence.Scope.COUNTRY) {
                peers.forEach { peer ->
                    futures += executor.submit(Callable {
                        NxpProtocol.queryDhtPrefixes(context, peer.host, peer.port, prefixes, 96)
                    })
                }
            } else {
                prefixes.chunked(18).forEach { batch ->
                    peers.take(2).forEach { peer ->
                        futures += executor.submit(Callable {
                            NxpProtocol.queryDhtPrefixes(context, peer.host, peer.port, batch, 24)
                        })
                    }
                }
            }
            val records = futures.flatMap { runCatching { it.get(9, TimeUnit.SECONDS) }.getOrDefault(emptyList()) }
                .mapNotNull { record ->
                    NexusPresence.fromWire(record.value)?.takeIf {
                        record.publisher == it.nodeId && NexusPresence.verify(it)
                    }
                }
                .distinctBy { it.nodeId }
            return Result(NexusPresence.filter(records, scope, location, country), peers.size)
        } finally {
            executor.shutdownNow()
        }
    }

    fun localNearby(context: Context, peers: Collection<NsdController.Peer>): List<NexusPresence.Record> =
        peers.filter { it.host.isNotBlank() }
            .map { peer ->
                NexusPresence.Record(
                    address = "",
                    nodeId = peer.name,
                    publicKey = peer.identityPublicKey,
                    displayName = peer.name,
                    countryCode = "",
                    fineCell = "",
                    regionCell = "",
                    endpoints = listOf(formatEndpoint(peer.host, peer.port)),
                    createdAt = peer.lastSeenAt,
                    expiresAt = System.currentTimeMillis() + 60_000,
                    signature = ""
                )
            }

    private fun formatEndpoint(host: String, port: Int): String = if (host.contains(':')) "[$host]:$port" else "$host:$port"
}
