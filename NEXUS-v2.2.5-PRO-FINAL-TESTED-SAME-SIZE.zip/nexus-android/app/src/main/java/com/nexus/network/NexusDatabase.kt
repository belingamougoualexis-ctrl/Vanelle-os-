package com.nexus.network

import android.content.Context
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Persistent, content-verifiable key/value database used by NEXUS services.
 *  Records use a Lamport-style logical version plus node id for deterministic conflict resolution.
 */
object NexusDatabase {
    data class Record(
        val database: String,
        val key: String,
        val value: String,
        val version: Long,
        val nodeId: String,
        val updatedAt: Long,
        val hash: String
    )

    private const val ROOT = "nexus-db"
    private const val CLOCK = "logical_clock"
    private val locks = ConcurrentHashMap<String, Any>()

    fun put(context: Context, database: String, key: String, value: String): Record {
        validate(database, key, value)
        val clock = tick(context)
        val now = System.currentTimeMillis()
        val node = NexusIdentity.nodeId(context)
        val hash = hash(canonical(database, key, value, clock, node, now))
        val record = Record(database, key, value, clock, node, now, hash)
        write(context, record)
        return record
    }

    fun merge(context: Context, record: Record): Boolean {
        validate(record.database, record.key, record.value)
        if (hash(canonical(record.database, record.key, record.value, record.version, record.nodeId, record.updatedAt)) != record.hash) return false
        synchronized(lockFor(record.database, record.key)) {
            val current = get(context, record.database, record.key)
            if (current != null && compare(current, record) >= 0) return false
            write(context, record)
            advanceClock(context, record.version)
            return true
        }
    }

    fun get(context: Context, database: String, key: String): Record? {
        validateName(database, key)
        val file = recordFile(context, database, key)
        if (!file.isFile) return null
        return runCatching {
            val j = org.json.JSONObject(file.readText())
            Record(j.getString("database"), j.getString("key"), j.getString("value"), j.getLong("version"), j.getString("nodeId"), j.getLong("updatedAt"), j.getString("hash"))
        }.getOrNull()?.takeIf { r ->
            hash(canonical(r.database, r.key, r.value, r.version, r.nodeId, r.updatedAt)) == r.hash
        }
    }

    fun list(context: Context, database: String, limit: Int = 256): List<Record> {
        require(database.isNotBlank() && database.length <= 96)
        val dir = File(File(context.filesDir, ROOT), safe(database))
        return dir.listFiles().orEmpty().filter { it.extension == "json" }.mapNotNull { get(context, database, decodeName(it.nameWithoutExtension)) }
            .sortedWith(compareByDescending<Record> { it.version }.thenBy { it.key })
            .take(limit.coerceIn(1, 1024))
    }

    fun count(context: Context, database: String): Int = list(context, database, 1024).size

    fun databases(context: Context): List<String> = File(context.filesDir, ROOT).listFiles().orEmpty().filter { it.isDirectory }.mapNotNull { unsafed(it.name) }.sorted()

    fun clear(context: Context, database: String) {
        File(File(context.filesDir, ROOT), safe(database)).deleteRecursively()
    }

    private fun write(context: Context, record: Record) {
        synchronized(lockFor(record.database, record.key)) {
            val dir = File(File(context.filesDir, ROOT), safe(record.database)).apply { mkdirs() }
            val tmp = File(dir, ".${safe(record.key)}.${System.nanoTime()}.tmp")
            tmp.writeText(org.json.JSONObject().apply {
                put("database", record.database); put("key", record.key); put("value", record.value)
                put("version", record.version); put("nodeId", record.nodeId); put("updatedAt", record.updatedAt); put("hash", record.hash)
            }.toString(), Charsets.UTF_8)
            require(tmp.renameTo(recordFile(context, record.database, record.key)))
        }
    }

    private fun tick(context: Context): Long {
        synchronized(context) {
            val prefs = context.getSharedPreferences("nexus_db_clock", Context.MODE_PRIVATE)
            val next = prefs.getLong(CLOCK, 0L) + 1L
            prefs.edit().putLong(CLOCK, next).commit()
            return next
        }
    }

    private fun advanceClock(context: Context, observed: Long) {
        synchronized(context) {
            val prefs = context.getSharedPreferences("nexus_db_clock", Context.MODE_PRIVATE)
            val current = prefs.getLong(CLOCK, 0L)
            if (observed > current) prefs.edit().putLong(CLOCK, observed).commit()
        }
    }

    private fun compare(a: Record, b: Record): Int = compareValuesBy(a, b, { it.version }, { it.nodeId }, { it.updatedAt })

    private fun lockFor(database: String, key: String) = locks.computeIfAbsent("$database\u0000$key") { Any() }

    private fun validate(database: String, key: String, value: String) {
        validateName(database, key); require(value.length <= 16 * 1024) { "Valeur trop grande (16 KiB max)" }
    }

    private fun validateName(database: String, key: String) {
        require(database.matches(Regex("[A-Za-z0-9._-]{1,96}"))) { "Nom de base invalide" }
        require(key.isNotBlank() && key.length <= 256) { "Clé invalide" }
    }

    private fun recordFile(context: Context, database: String, key: String): File =
        File(File(File(context.filesDir, ROOT), safe(database)), safe(key) + ".json")

    private fun canonical(database: String, key: String, value: String, version: Long, nodeId: String, updatedAt: Long): String =
        "v=1|db=$database|key=${NexusCrypto.encode(key)}|value=${NexusCrypto.encode(value)}|version=$version|node=$nodeId|updated=$updatedAt"

    private fun hash(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it.toInt() and 0xff) }

    private fun safe(value: String): String = NexusCrypto.encode(value).replace('/', '_')
    private fun unsafed(value: String): String? = runCatching { NexusCrypto.decode(value) }.getOrNull()
    private fun decodeName(value: String): String = NexusCrypto.decode(value)
}
