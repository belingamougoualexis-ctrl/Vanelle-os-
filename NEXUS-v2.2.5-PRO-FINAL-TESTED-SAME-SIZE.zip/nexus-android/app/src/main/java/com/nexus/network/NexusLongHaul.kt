package com.nexus.network

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Politique « longue distance » (pays, continent, intercontinental).
 * Fichier pur Kotlin, sans dépendance Android : il n'altère aucun comportement existant
 * tant qu'il n'est pas appelé. Il ne remplace pas l'infrastructure physique : un trajet
 * France–Cameroun passe forcément par des passerelles disposant d'un vrai accès Internet.
 */
object NexusLongHaul {
    private const val HOUR = 3_600_000L
    private const val DAY = 24 * HOUR

    enum class Scope(
        val maxHops: Int,
        val minTimeoutMs: Long,
        val routeTtlMs: Long,
        val dtnTtlMs: Long,
        val retries: Int
    ) {
        LOCAL(8, 3_000L, 40_000L, DAY, 3),
        COUNTRY(16, 8_000L, 120_000L, 3 * DAY, 5),
        CONTINENT(24, 15_000L, 300_000L, 5 * DAY, 6),
        INTERCONTINENTAL(32, 30_000L, 600_000L, 7 * DAY, 8)
    }

    /** Choisit la portée d'après le RTT mesuré ; sans mesure, prudence : COUNTRY. */
    fun scopeForRtt(rttMs: Double?): Scope = when {
        rttMs == null || !rttMs.isFinite() || rttMs <= 0.0 -> Scope.COUNTRY
        rttMs < 30.0 -> Scope.LOCAL
        rttMs < 80.0 -> Scope.COUNTRY
        rttMs < 150.0 -> Scope.CONTINENT
        else -> Scope.INTERCONTINENTAL
    }

    fun scopeForPathLength(pathLength: Int): Scope = when {
        pathLength <= 3 -> Scope.LOCAL
        pathLength <= 8 -> Scope.COUNTRY
        pathLength <= 16 -> Scope.CONTINENT
        else -> Scope.INTERCONTINENTAL
    }

    fun routeTtlMs(pathLength: Int): Long = scopeForPathLength(pathLength).routeTtlMs

    /** Vrai pour localhost, réseaux privés, lien-local et adresses overlay ; faux pour une IP publique ou un nom. Aucun DNS. */
    fun isLocalHost(host: String): Boolean {
        val h = host.trim().removePrefix("[").removeSuffix("]").lowercase()
        if (h.isEmpty() || h == "localhost" || h.endsWith(".local")) return true
        if (h.contains(':')) return h == "::1" || h.startsWith("fe80:") || h.startsWith("fd") || h.startsWith("fc")
        val p = h.split('.')
        if (p.size != 4) return false
        val n = p.map { it.toIntOrNull() }
        if (n.any { it == null || it !in 0..255 }) return false
        val a = n[0]!!; val b = n[1]!!
        return a == 10 || a == 127 || (a == 172 && b in 16..31) || (a == 192 && b == 168) || (a == 169 && b == 254)
    }

    /** Connexion vers un hôte Internet : au moins 12 s (SYN perdu + RTT intercontinental) ; local inchangé. */
    fun connectTimeoutMs(host: String, baseMs: Int): Int = if (isLocalHost(host)) baseMs else max(baseMs, 12_000)

    fun readTimeoutMs(host: String, baseMs: Int): Int = if (isLocalHost(host)) baseMs else max(baseMs, 8_000)

    /** Nombre de sauts autorisé : chemin connu + marge, borné par la portée. */
    fun hopBudget(scope: Scope, knownPathLength: Int?): Int =
        if (knownPathLength == null || knownPathLength < 0) scope.maxHops
        else (knownPathLength + 4).coerceIn(2, scope.maxHops)

    /** Délai avant nouvelle tentative : exponentiel plafonné, avec gigue (random dans 0..1). */
    fun backoffMs(attempt: Int, scope: Scope, random: Double): Long {
        val exp = (scope.minTimeoutMs / 2) * (1L shl attempt.coerceIn(0, 6))
        val jitter = 0.5 + 0.5 * random.coerceIn(0.0, 1.0)
        return (min(exp, 120_000L) * jitter).toLong().coerceAtLeast(500L)
    }

    /** Fenêtre d'envoi = produit bande passante × délai, pour ne pas brider les liens à forte latence. */
    fun windowBytes(bandwidthKbps: Int, rttMs: Double): Int {
        if (bandwidthKbps <= 0 || !rttMs.isFinite() || rttMs <= 0.0) return 64 * 1024
        val bdp = bandwidthKbps * 1000.0 / 8.0 * (rttMs / 1000.0)
        return bdp.coerceIn(64.0 * 1024, 4.0 * 1024 * 1024).toInt()
    }

    /** Estimateur RTT (SRTT/RTTVAR, style RFC 6298) pour des délais adaptatifs. */
    class RttEstimator {
        private var srtt: Double? = null
        private var rttvar = 0.0

        @Synchronized
        fun sample(rttMs: Double) {
            if (!rttMs.isFinite() || rttMs <= 0.0) return
            val s = srtt
            if (s == null) {
                srtt = rttMs
                rttvar = rttMs / 2.0
            } else {
                rttvar = 0.75 * rttvar + 0.25 * abs(s - rttMs)
                srtt = 0.875 * s + 0.125 * rttMs
            }
        }

        @Synchronized
        fun smoothedMs(): Double? = srtt

        @Synchronized
        fun timeoutMs(scope: Scope): Long {
            val s = srtt ?: return scope.minTimeoutMs
            val rto = s + max(4.0 * rttvar, 50.0)
            return rto.toLong().coerceIn(scope.minTimeoutMs, 60_000L)
        }
    }
}
