package com.nexus.network

import android.content.Context
import java.security.MessageDigest
import java.util.zip.CRC32

/** Safe distributed compute surface: only built-in, deterministic operations are executable remotely. */
object NexusCompute {
    data class Task(val id: String, val operation: String, val input: ByteArray)
    data class Result(val taskId: String, val operation: String, val output: ByteArray, val provider: String)

    private const val MAX_INPUT = 4 * 1024 * 1024
    val operations = listOf("SHA-256", "CRC32", "UTF8-LENGTH")

    fun execute(context: Context, task: Task): Result {
        require(task.id.matches(Regex("[A-Za-z0-9._:-]{8,96}")))
        require(task.input.size <= MAX_INPUT) { "Tâche trop grande" }
        val output = when (task.operation) {
            "SHA-256" -> MessageDigest.getInstance("SHA-256").digest(task.input)
            "CRC32" -> ByteArray(4).also { value ->
                val crc=CRC32(); crc.update(task.input); val v=crc.value
                for (i in 0 until 4) value[3-i]=(v ushr (i*8)).toByte()
            }
            "UTF8-LENGTH" -> task.input.size.toString().toByteArray(Charsets.UTF_8)
            else -> error("Opération de calcul non autorisée")
        }
        return Result(task.id, task.operation, output, NexusIdentity.nodeId(context))
    }
}
