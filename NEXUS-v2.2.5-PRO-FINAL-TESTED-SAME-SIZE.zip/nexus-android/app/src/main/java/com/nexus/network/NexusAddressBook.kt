package com.nexus.network

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.Inet6Address
import java.net.InetAddress

/** Signed address directory for long-distance NEXUS routing. */
object NexusAddressBook {
    private const val PREFIX = "nexus/address/"
    private const val TTL_MS = 30L * 24 * 60 * 60 * 1000

    data class Record(
        val address: String,
        val nodeId: String,
        val publicKey: String,
        val endpoints: List<String>,
        val createdAt: Long,
        val expiresAt: Long,
        val signature: String
    )

    fun own(context: Context): Record {
        val created = System.currentTimeMillis()
        val expires = created + TTL_MS
        val address = NexusAddress.overlayIpv6(context)
        val publicKey = NexusIdentity.publicKeyBase64(context)
        val endpoints = NexusAddress.realGlobalAddresses().filter { it.contains(':') }.take(4).map { "[$it]:${NexusConfig.NODE_PORT}" }
        val canonical = canonical(address, NexusIdentity.nodeId(context), publicKey, endpoints, created, expires)
        return Record(address, NexusIdentity.nodeId(context), publicKey, endpoints, created, expires, NexusCrypto.encodeBytes(NexusIdentity.sign(context, canonical)))
    }

    fun wire(record: Record): String = NexusCrypto.encode(toJson(record).toString())

    fun fromWire(wire: String): Record? = runCatching { parse(JSONObject(NexusCrypto.decode(wire))) }.getOrNull()?.takeIf(::verify)

    fun verify(record: Record): Boolean = runCatching {
        require(NexusAddress.isValidOverlay(record.address))
        require(record.nodeId.isNotBlank())
        require(record.expiresAt > System.currentTimeMillis())
        require(record.expiresAt - record.createdAt in 60_000L..TTL_MS)
        require(record.endpoints.size <= 8)
        require(record.endpoints.all { it.length <= 128 && isValidEndpoint(it) })
        require(NexusAddress.overlayIpv6FromPublicKey(record.publicKey) == record.address)
        NexusIdentity.verify(record.publicKey, canonical(record.address, record.nodeId, record.publicKey, record.endpoints, record.createdAt, record.expiresAt), record.signature)
    }.getOrDefault(false)

    fun dhtRecord(context: Context): NexusDht.Record {
        val own = own(context)
        return NexusDht(NexusIdentity.nodeId(context)).signed(context, key(own.address), wire(own), TTL_MS)
    }

    fun verifyDhtRecord(record: NexusDht.Record): Boolean {
        if (!record.key.startsWith(PREFIX)) return false
        val address = record.key.removePrefix(PREFIX)
        val value = fromWire(record.value) ?: return false
        return value.address == address && value.nodeId == record.publisher && verify(value)
    }

    fun resolve(context: Context, address: String, peers: Collection<NsdController.Peer>): Record? {
        val normalized = address.trim().lowercase()
        if (!NexusAddress.isValidOverlay(normalized)) return null
        peers.asSequence().filter { it.host.isNotBlank() && NexusTrustStore.isAllowed(context, it.name) }
            .sortedByDescending { NexusTrustStore.reputation(context, it.name) }
            .take(12)
            .forEach { peer ->
                val record = NxpProtocol.queryDhtRecord(context, peer.host, peer.port, key(normalized))
                if (record != null && verifyDhtRecord(record)) {
                    val value = fromWire(record.value)
                    if (value?.address == normalized) return value
                }
            }
        return null
    }

    fun directIpv6(record: Record): List<Inet6Address> = record.endpoints.mapNotNull { endpoint ->
        runCatching {
            val host = endpoint.substringAfter('[').substringBefore(']')
            val ip = InetAddress.getByName(host)
            ip as? Inet6Address
        }.getOrNull()
    }

    fun key(address: String): String = PREFIX + address.trim().lowercase()

    private fun canonical(address: String, nodeId: String, publicKey: String, endpoints: List<String>, created: Long, expires: Long): String =
        "v=1&address=$address&node=$nodeId&publicKey=${NexusCrypto.encode(publicKey)}&endpoints=${NexusCrypto.encode(endpoints.sorted().joinToString(","))}&created=$created&expires=$expires"

    private fun isValidEndpoint(endpoint: String): Boolean = runCatching {
        require(endpoint.startsWith("[") && endpoint.contains("]:"))
        val host = endpoint.substringAfter('[').substringBefore(']')
        val port = endpoint.substringAfter("]:").toInt()
        require(port in 1..65535)
        require(host.isNotBlank() && host.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' || it == ':' || it == '.' })
        val ip = InetAddress.getByName(host)
        ip is Inet6Address && !ip.isLinkLocalAddress && !ip.isSiteLocalAddress && !ip.isLoopbackAddress
    }.getOrDefault(false)

    private fun toJson(record: Record) = JSONObject().apply {
        put("address", record.address); put("nodeId", record.nodeId); put("publicKey", record.publicKey)
        put("endpoints", JSONArray(record.endpoints)); put("createdAt", record.createdAt); put("expiresAt", record.expiresAt); put("signature", record.signature)
    }

    private fun parse(j: JSONObject): Record {
        val array = j.optJSONArray("endpoints") ?: JSONArray()
        val endpoints = buildList { for (i in 0 until array.length()) add(array.getString(i)) }
        return Record(j.getString("address"), j.getString("nodeId"), j.getString("publicKey"), endpoints, j.getLong("createdAt"), j.getLong("expiresAt"), j.getString("signature"))
    }
}
