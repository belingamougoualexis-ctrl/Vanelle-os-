package com.nexus.network

import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Hierarchical overlay routing state. It models domains/prefixes without pretending
 * to replace the Internet's physical AS/BGP infrastructure.
 */
class NexusGlobalRoutingTable(private val localNodeId: String) {
    data class Announcement(
        val originNode: String,
        val domainId: String,
        val prefix: String,
        val nextHop: String,
        val metric: Int,
        val path: List<String>,
        val sequence: Long,
        val expiresAt: Long
    )

    data class BestRoute(val announcement: Announcement, val totalCost: Long)

    private val routes = ConcurrentHashMap<String, MutableList<Announcement>>()

    fun localDomainId(): String = domainFor(localNodeId)

    fun install(announcement: Announcement, nowMs: Long = System.currentTimeMillis()): Boolean {
        if (announcement.originNode.isBlank() || announcement.nextHop.isBlank()) return false
        if (announcement.metric !in 0..1_000_000) return false
        if (announcement.path.isEmpty() || announcement.path.size > NexusConfig.MAX_HOPS) return false
        if (announcement.path.distinct().size != announcement.path.size) return false
        if (localNodeId in announcement.path) return false
        if (announcement.expiresAt <= nowMs) return false
        if (announcement.path.firstOrNull() != announcement.originNode) return false
        val list = routes.computeIfAbsent(announcement.prefix) { mutableListOf() }
        synchronized(list) {
            list.removeIf { it.expiresAt <= nowMs || it.originNode == announcement.originNode && it.sequence < announcement.sequence }
            val duplicate = list.any { sameRoute(it, announcement) }
            if (!duplicate) list += announcement
        }
        return true
    }

    fun best(prefix: String, nowMs: Long = System.currentTimeMillis()): BestRoute? {
        val list = routes[prefix] ?: return null
        synchronized(list) {
            list.removeIf { it.expiresAt <= nowMs }
            return list.asSequence()
                .filter { it.expiresAt > nowMs && localNodeId !in it.path }
                .map { route ->
                    val hopPenalty = (route.path.size.coerceAtLeast(1) * 100L)
                    BestRoute(route, route.metric.toLong() + hopPenalty)
                }
                .minByOrNull { it.totalCost }
        }
    }

    fun snapshot(nowMs: Long = System.currentTimeMillis()): List<Announcement> = routes.values.flatMap { list ->
        synchronized(list) {
            list.removeIf { it.expiresAt <= nowMs }
            list.toList()
        }
    }

    fun reconcile(peers: Collection<NsdController.Peer>, nowMs: Long = System.currentTimeMillis()) {
        peers.forEach { peer ->
            val path = peer.gatewayPath.filter { it.isNotBlank() }.distinct()
            if (path.isEmpty() || path.size > NexusConfig.MAX_ADVERTISED_PATH) return@forEach
            val origin = path.first()
            if (origin == localNodeId || localNodeId in path) return@forEach
            install(
                Announcement(
                    originNode = origin,
                    domainId = domainFor(origin),
                    prefix = domainPrefix(domainFor(origin)),
                    nextHop = peer.name,
                    metric = peer.gatewayDistance.coerceAtMost(1_000_000),
                    path = path,
                    sequence = peer.lastSeenAt,
                    expiresAt = nowMs + NexusLongHaul.routeTtlMs(path.size)
                ), nowMs
            )
        }
    }

    fun domainSummary(): String {
        val domains = snapshot().map { it.domainId }.distinct().sorted()
        return if (domains.isEmpty()) "Domaine ${localDomainId()} • aucun domaine distant appris" else
            "Domaine ${localDomainId()} • ${domains.size} domaine(s) distant(s) appris"
    }

    companion object {
        fun domainFor(nodeId: String): String {
            val h = MessageDigest.getInstance("SHA-256").digest(nodeId.toByteArray(Charsets.UTF_8))
            return "NXD-" + h.copyOfRange(0, 6).joinToString("") { "%02x".format(it.toInt() and 0xff) }
        }

        fun domainPrefix(domainId: String): String = "nexus:$domainId"

        private fun sameRoute(a: Announcement, b: Announcement): Boolean =
            a.originNode == b.originNode && a.nextHop == b.nextHop && a.sequence == b.sequence && a.prefix == b.prefix
    }
}
