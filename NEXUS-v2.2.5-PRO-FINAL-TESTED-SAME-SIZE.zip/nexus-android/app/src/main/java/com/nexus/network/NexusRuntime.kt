package com.nexus.network

import android.content.Context
import java.net.URI

/** Stable public runtime facade for NEXUS-native applications and services. */
object NexusRuntime {
    data class Endpoint(val node: String?, val service: String, val path: String)

    fun parse(uri: String): Endpoint {
        require(uri.startsWith("nexus://")) { "URI NEXUS invalide" }
        val u = URI(uri)
        val host=u.host
        val segments=u.path.trim('/').split('/').filter { it.isNotBlank() }
        require(segments.isNotEmpty()) { "Service NEXUS manquant" }
        val service=segments.first()
        val path=segments.drop(1).joinToString("/")
        return Endpoint(host,service,path)
    }

    fun localHealth(context: Context): Map<String, String> = linkedMapOf(
        "node" to NexusIdentity.nodeId(context),
        "name" to NexusNaming.own(context, emptyList()).name,
        "databases" to NexusDatabase.databases(context).size.toString(),
        "pinned" to NexusContentStore.allPinned(context).size.toString(),
        "credits" to NexusCredits.balance(context).toString()
    )
}
