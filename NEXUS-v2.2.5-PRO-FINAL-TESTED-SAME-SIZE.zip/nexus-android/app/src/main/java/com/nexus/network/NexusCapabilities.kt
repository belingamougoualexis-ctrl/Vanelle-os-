package com.nexus.network

import android.content.Context
import org.json.JSONObject

/** Capability token primitive for NEXUS-native apps. Tokens are signed, scoped and expiring. */
object NexusCapabilities {
    data class Token(
        val issuerNode: String,
        val issuerPublicKey: String,
        val subjectNode: String,
        val capability: String,
        val resource: String,
        val issuedAt: Long,
        val expiresAt: Long,
        val signature: String
    )

    fun issue(context: Context, subjectNode: String, capability: String, resource: String, ttlMs: Long = 24L * 60 * 60 * 1000): Token {
        require(subjectNode.isNotBlank())
        require(capability.matches(Regex("[A-Za-z0-9._:-]{1,80}")))
        require(resource.length <= 512)
        val now = System.currentTimeMillis()
        val issuer = NexusIdentity.nodeId(context)
        val publicKey = NexusIdentity.publicKeyBase64(context)
        val expires = now + ttlMs.coerceIn(1_000L, 30L * 24 * 60 * 60 * 1000)
        val canonical = canonical(issuer, publicKey, subjectNode, capability, resource, now, expires)
        return Token(issuer, publicKey, subjectNode, capability, resource, now, expires, NexusCrypto.encodeBytes(NexusIdentity.sign(context, canonical)))
    }

    fun verify(token: Token, subjectNode: String, capability: String, resource: String, now: Long = System.currentTimeMillis()): Boolean {
        if (token.subjectNode != subjectNode || token.capability != capability || token.resource != resource) return false
        if (token.expiresAt <= now || token.issuedAt > now + 60_000L) return false
        return NexusIdentity.verify(token.issuerPublicKey, canonical(token.issuerNode, token.issuerPublicKey, token.subjectNode, token.capability, token.resource, token.issuedAt, token.expiresAt), token.signature)
    }

    fun encode(token: Token): String = NexusCrypto.encode(JSONObject().apply {
        put("issuerNode", token.issuerNode); put("issuerPublicKey", token.issuerPublicKey); put("subjectNode", token.subjectNode)
        put("capability", token.capability); put("resource", token.resource); put("issuedAt", token.issuedAt); put("expiresAt", token.expiresAt); put("signature", token.signature)
    }.toString())

    fun decode(encoded: String): Token = JSONObject(NexusCrypto.decode(encoded)).let {
        Token(it.getString("issuerNode"), it.getString("issuerPublicKey"), it.getString("subjectNode"), it.getString("capability"), it.getString("resource"), it.getLong("issuedAt"), it.getLong("expiresAt"), it.getString("signature"))
    }

    private fun canonical(issuer: String, publicKey: String, subject: String, capability: String, resource: String, issued: Long, expires: Long) =
        "v=1|issuer=$issuer|public=$publicKey|subject=$subject|capability=$capability|resource=${NexusCrypto.encode(resource)}|issued=$issued|expires=$expires"
}
