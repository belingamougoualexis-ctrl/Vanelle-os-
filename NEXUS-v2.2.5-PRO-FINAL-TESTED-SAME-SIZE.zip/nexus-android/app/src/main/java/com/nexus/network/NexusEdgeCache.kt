package com.nexus.network

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Local edge cache for content-addressed objects. The OS may evict cacheDir at any time. */
object NexusEdgeCache {
    data class Stats(val entries: Int, val bytes: Long, val quotaBytes: Long)

    private const val ROOT = "nexus-edge-cache"
    private const val DEFAULT_TTL_MS = 24L * 60L * 60L * 1000L

    fun putFile(context: Context, hash: String, source: File, ttlMs: Long = DEFAULT_TTL_MS): Boolean {
        require(hash.matches(Regex("[0-9a-f]{64}")))
        if (!source.isFile || NexusContentStore.sha256(source) != hash) return false
        val root = root(context).apply { mkdirs() }
        val data = File(root, "$hash.data")
        val meta = File(root, "$hash.json")
        runCatching {
            source.copyTo(data, overwrite = true)
            meta.writeText(JSONObject().apply {
                put("hash", hash)
                put("size", data.length())
                put("expiresAt", System.currentTimeMillis() + ttlMs.coerceAtLeast(1_000L))
            }.toString())
            evictToQuota(context)
        }.onFailure {
            data.delete(); meta.delete()
        }
        return meta.isFile && data.isFile
    }

    fun restore(context: Context, hash: String, destination: File): Boolean {
        if (!hash.matches(Regex("[0-9a-f]{64}"))) return false
        val root = root(context)
        val data = File(root, "$hash.data")
        val meta = File(root, "$hash.json")
        val expires = runCatching { JSONObject(meta.readText()).optLong("expiresAt", 0L) }.getOrDefault(0L)
        if (!data.isFile || !meta.isFile || expires <= System.currentTimeMillis()) {
            data.delete(); meta.delete(); return false
        }
        if (NexusContentStore.sha256(data) != hash) {
            data.delete(); meta.delete(); return false
        }
        return runCatching {
            destination.parentFile?.mkdirs()
            data.copyTo(destination, overwrite = true)
            data.setLastModified(System.currentTimeMillis())
            true
        }.getOrDefault(false)
    }

    fun clear(context: Context) { root(context).deleteRecursively() }

    fun stats(context: Context): Stats {
        evictExpired(context)
        val entries = root(context).listFiles().orEmpty().count { it.name.endsWith(".data") }
        val bytes = root(context).listFiles().orEmpty().filter { it.name.endsWith(".data") }.sumOf { it.length() }
        return Stats(entries, bytes, NexusSettings.edgeCacheQuotaBytes(context))
    }

    fun evictToQuota(context: Context) {
        val root = root(context).apply { mkdirs() }
        evictExpired(context)
        var bytes = root.listFiles().orEmpty().filter { it.name.endsWith(".data") }.sumOf { it.length() }
        val quota = NexusSettings.edgeCacheQuotaBytes(context)
        if (bytes <= quota) return
        val candidates = root.listFiles().orEmpty().filter { it.name.endsWith(".data") }.sortedBy { it.lastModified() }
        for (data in candidates) {
            if (bytes <= quota) break
            val size = data.length()
            data.delete()
            File(root, data.name.removeSuffix(".data") + ".json").delete()
            bytes -= size
        }
    }

    private fun evictExpired(context: Context) {
        val root = root(context)
        val now = System.currentTimeMillis()
        root.listFiles().orEmpty().filter { it.name.endsWith(".json") }.forEach { meta ->
            val expires = runCatching { JSONObject(meta.readText()).optLong("expiresAt", 0L) }.getOrDefault(0L)
            if (expires <= now) {
                val hash = meta.name.removeSuffix(".json")
                meta.delete(); File(root, "$hash.data").delete()
            }
        }
    }

    private fun root(context: Context) = File(context.cacheDir, ROOT)
}
