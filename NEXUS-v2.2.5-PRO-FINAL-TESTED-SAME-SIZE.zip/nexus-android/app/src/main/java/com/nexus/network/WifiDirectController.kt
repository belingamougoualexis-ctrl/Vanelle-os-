package com.nexus.network

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pDeviceList
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceInfo
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceRequest
import android.net.wifi.p2p.nsd.WifiP2pServiceInfo
import android.os.Build
import android.os.Looper
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * Real Wi-Fi Direct control plane. It advertises NEXUS over P2P DNS-SD and
 * discovers peers/services without requiring a conventional LAN.
 */
class WifiDirectController(private val context: Context) {
    private val manager = context.getSystemService(WifiP2pManager::class.java)
    private var channel: WifiP2pManager.Channel? = null
    private var receiver: BroadcastReceiver? = null
    private var started = false
    private var refreshExecutor: ScheduledExecutorService? = null
    private val devices = linkedMapOf<String, WifiP2pDevice>()
    private var localService: WifiP2pServiceInfo? = null
    private var serviceRequest: WifiP2pDnsSdServiceRequest? = null

    var onDevicesChanged: ((List<WifiP2pDevice>) -> Unit)? = null
    var onStatus: ((String) -> Unit)? = null

    fun start() {
        if (started || manager == null || !permissionsGranted()) return
        channel = manager.initialize(context, Looper.getMainLooper()) {
            onStatus?.invoke("Canal Wi‑Fi Direct interrompu")
        }
        setupDnsSd()
        receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                when (intent.action) {
                    WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                        val enabled = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1) == WifiP2pManager.WIFI_P2P_STATE_ENABLED
                        onStatus?.invoke(if (enabled) "Wi‑Fi Direct activé" else "Wi‑Fi Direct désactivé")
                        if (enabled) {
                            discover()
                            discoverServices()
                        }
                    }
                    WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> requestPeers()
                    WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> requestConnectionInfo()
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            context.registerReceiver(receiver, filter)
        }
        started = true
        registerLocalService()
        discover()
        discoverServices()
        refreshExecutor = Executors.newSingleThreadScheduledExecutor { r ->
            Thread(r, "nexus-wifi-direct-refresh").apply { isDaemon = true }
        }
        refreshExecutor?.scheduleWithFixedDelay({
            if (started) {
                runCatching { discover() }
                runCatching { discoverServices() }
            }
        }, 15, 15, TimeUnit.SECONDS)
    }

    private fun setupDnsSd() {
        val ch = channel ?: return
        manager?.setDnsSdResponseListeners(
            ch,
            { instanceName, _, device ->
                devices[device.deviceAddress] = device
                onStatus?.invoke("Service NEXUS P2P trouvé : ${device.deviceName.ifBlank { instanceName }}")
                onDevicesChanged?.invoke(devices.values.sortedBy { it.deviceName.lowercase() })
            },
            { _, record: Map<String, String>, device ->
                devices[device.deviceAddress] = device
                val port = record["listenport"]?.toIntOrNull() ?: NexusConfig.NODE_PORT
                val node = record["node"]?.takeIf { it.isNotBlank() } ?: "P2P-${device.deviceAddress}"
                if (device.deviceAddress.isNotBlank()) {
                    NexusP2PDirectory.upsert(
                        NexusP2PDirectory.Endpoint(
                            id = node,
                            displayName = record["name"] ?: device.deviceName,
                            deviceAddress = device.deviceAddress,
                            host = "",
                            port = port
                        )
                    )
                }
            }
        )
    }

    private fun registerLocalService() {
        val ch = channel ?: return
        val record = mapOf(
            "node" to NexusIdentity.nodeId(context),
            "name" to "NEXUS-${NexusIdentity.nodeId(context)}",
            "listenport" to NexusConfig.NODE_PORT.toString(),
            "version" to NexusConfig.VERSION,
            "relayport" to NexusConfig.RELAY_PORT.toString()
        )
        val info = WifiP2pDnsSdServiceInfo.newInstance(
            "NEXUS-${NexusIdentity.nodeId(context)}",
            "_nexus._tcp",
            record
        )
        localService = info
        manager?.addLocalService(ch, info, action("Annonce NEXUS P2P publiée"))
    }

    private fun discoverServices() {
        val ch = channel ?: return
        serviceRequest?.let { req -> manager?.removeServiceRequest(ch, req, action(null)) }
        val req = WifiP2pDnsSdServiceRequest.newInstance()
        serviceRequest = req
        manager?.addServiceRequest(ch, req, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                manager?.discoverServices(ch, action("Découverte des services NEXUS P2P lancée"))
            }
            override fun onFailure(reason: Int) {
                onStatus?.invoke("Découverte services P2P refusée : ${reasonText(reason)}")
            }
        })
    }

    fun discover() {
        val ch = channel ?: return
        if (!permissionsGranted()) return
        manager?.discoverPeers(ch, action("Recherche Wi‑Fi Direct lancée"))
    }

    fun connect(device: WifiP2pDevice) {
        val ch = channel ?: return
        if (!permissionsGranted()) return
        val config = WifiP2pConfig().apply { deviceAddress = device.deviceAddress }
        manager?.connect(ch, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { onStatus?.invoke("Connexion P2P demandée à ${device.deviceName}") }
            override fun onFailure(reason: Int) { onStatus?.invoke("Connexion P2P refusée : ${reasonText(reason)}") }
        })
    }

    fun stop() {
        if (!started) return
        val ch = channel
        serviceRequest?.let { request -> if (ch != null) manager?.removeServiceRequest(ch, request, action(null)) }
        if (ch != null) manager?.clearLocalServices(ch, action(null))
        receiver?.let { runCatching { context.unregisterReceiver(it) } }
        receiver = null
        started = false
        devices.clear()
        localService = null
        serviceRequest = null
        NexusP2PDirectory.clear()
        refreshExecutor?.shutdownNow()
        refreshExecutor = null
    }

    fun snapshot(): List<WifiP2pDevice> = devices.values.toList()

    private fun requestPeers() {
        val ch = channel ?: return
        if (!permissionsGranted()) return
        manager?.requestPeers(ch) { list: WifiP2pDeviceList ->
            list.deviceList.forEach { devices[it.deviceAddress] = it }
            onDevicesChanged?.invoke(devices.values.sortedBy { it.deviceName.lowercase() })
        }
    }

    private fun requestConnectionInfo() {
        val ch = channel ?: return
        if (!permissionsGranted()) return
        manager?.requestConnectionInfo(ch) { info: WifiP2pInfo ->
            if (!info.groupFormed) return@requestConnectionInfo
            val host = info.groupOwnerAddress?.hostAddress ?: return@requestConnectionInfo
            // A P2P client can always reach the group owner. The owner itself
            // accepts connections from P2P clients on its advertised port.
            if (!info.isGroupOwner) {
                val owner = NexusP2PDirectory.snapshot().firstOrNull { it.host.isBlank() }
                val id = owner?.id ?: "P2P-GROUP-OWNER"
                val display = owner?.displayName ?: "Groupe NEXUS"
                val port = owner?.port ?: NexusConfig.NODE_PORT
                NexusP2PDirectory.upsert(
                    NexusP2PDirectory.Endpoint(
                        id = id,
                        displayName = display,
                        deviceAddress = owner?.deviceAddress ?: id,
                        host = host,
                        port = port,
                        gateway = owner?.gateway == true,
                        relay = owner?.relay == true,
                        gatewayDistance = owner?.gatewayDistance ?: Int.MAX_VALUE,
                        latencyMs = owner?.latencyMs ?: Double.POSITIVE_INFINITY
                    )
                )
                onStatus?.invoke("Lien P2P actif vers $host")
                Thread {
                    runCatching {
                        val caps = NxpProtocol.probeCapabilities(host, NexusConfig.NODE_PORT) { NetworkKeyManager.accepted(context) }
                        NexusP2PDirectory.snapshot().firstOrNull { it.host == host }?.apply {
                            gateway = caps.gateway
                            relay = caps.relay
                            gatewayDistance = caps.gatewayDistance
                            gatewayPath = caps.gatewayPath
                            latencyMs = caps.latencyMs
                        }
                    }
                }.start()
            } else {
                onStatus?.invoke("Groupe P2P NEXUS actif : cet appareil est propriétaire du groupe")
            }
        }
    }

    private fun action(successMessage: String?): WifiP2pManager.ActionListener = object : WifiP2pManager.ActionListener {
        override fun onSuccess() { successMessage?.let { onStatus?.invoke(it) } }
        override fun onFailure(reason: Int) { onStatus?.invoke("Wi‑Fi Direct : ${reasonText(reason)}") }
    }

    private fun permissionsGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            context.checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED
        } else {
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun reasonText(reason: Int): String = when (reason) {
        WifiP2pManager.BUSY -> "busy"
        WifiP2pManager.ERROR -> "error"
        WifiP2pManager.P2P_UNSUPPORTED -> "unsupported"
        WifiP2pManager.NO_SERVICE_REQUESTS -> "no service requests"
        WifiP2pManager.NO_PERMISSION -> "permission refusée"
        else -> reason.toString()
    }
}
