package com.nexus.network

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persists the last known authenticated NEXUS endpoints so recovery can keep
 * searching after NSD, Wi-Fi roaming or a temporary loss of the default route.
 * Entries are only hints: the normal NXP handshake still authenticates peers.
 */
object NexusPeerCache {
    private const val PREFS = "nexus_peer_cache"
    private const val KEY = "entries"
    private const val MAX = 128
    private const val MAX_AGE_MS = 30L * 24 * 60 * 60 * 1000

    data class Entry(
        val nodeId: String,
        val host: String,
        val port: Int,
        val seenAt: Long
    )

    fun load(context: Context): List<Entry> = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return emptyList()
        val now = System.currentTimeMillis()
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val node = obj.optString("node").trim()
                val host = obj.optString("host").trim()
                val port = obj.optInt("port", 0)
                val seen = obj.optLong("seen", 0L)
                if (node.isNotBlank() && host.isNotBlank() && port in 1..65535 && now - seen <= MAX_AGE_MS) {
                    add(Entry(node, host, port, seen))
                }
            }
        }.distinctBy { it.nodeId + "|" + it.host + "|" + it.port }
            .sortedByDescending { it.seenAt }
            .take(MAX)
    }.getOrDefault(emptyList())

    fun save(context: Context, peers: Collection<NsdController.Peer>) {
        val current = load(context).associateBy { it.nodeId }.toMutableMap()
        peers.filter { it.name.isNotBlank() && it.host.isNotBlank() && it.port in 1..65535 }
            .forEach { peer -> current[peer.name] = Entry(peer.name, peer.host, peer.port, System.currentTimeMillis()) }
        val array = JSONArray()
        current.values.sortedByDescending { it.seenAt }.take(MAX).forEach { entry ->
            array.put(JSONObject().apply {
                put("node", entry.nodeId)
                put("host", entry.host)
                put("port", entry.port)
                put("seen", entry.seenAt)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, array.toString()).apply()
    }
}
