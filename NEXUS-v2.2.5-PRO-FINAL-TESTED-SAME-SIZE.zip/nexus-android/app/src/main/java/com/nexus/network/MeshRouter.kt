package com.nexus.network

import java.util.concurrent.ConcurrentHashMap

/**
 * Self-organising NEXUS route engine.
 *
 * Routes are learned from authenticated neighbour advertisements and refined
 * with real link measurements. The engine rejects loops/stale peers, keeps a
 * circuit-breaker per next hop, and provides ordered failover candidates.
 */
class MeshRouter(
    private val nodeId: String,
    private val peersProvider: () -> List<NsdController.Peer>,
    private val trustProvider: (NsdController.Peer) -> Double = { 1.0 }
) {
    constructor(nodeId: String, peersProvider: () -> List<NsdController.Peer>) : this(nodeId, peersProvider, { 1.0 })
    data class NextHop(
        val nodeId: String,
        val host: String,
        val port: Int,
        val advertisedDistance: Int,
        val score: Double,
        val p2p: Boolean,
        val gatewayPath: List<String> = emptyList(),
        val gatewayPublicKey: String = "",
        val trust: Double = 1.0
    )

    data class RouteStatus(
        val path: List<String>,
        val distance: Int,
        val healthy: Boolean,
        val candidates: Int
    )

    private data class RouteAdvertisement(
        val peerName: String,
        val path: List<String>,
        val distance: Int,
        val exactPath: Boolean,
        val gatewayPublicKey: String
    )

    private data class Health(
        var failures: Int = 0,
        var lastFailureAt: Long = 0L,
        var lastSuccessAt: Long = 0L,
        var suppressedUntil: Long = 0L
    )

    private val health = ConcurrentHashMap<String, Health>()

    fun gatewayPath(gatewayEnabled: Boolean, transitEnabled: Boolean): List<String> {
        if (gatewayEnabled) return listOf(nodeId)
        if (!transitEnabled) return emptyList()
        val now = System.currentTimeMillis()
        val best = peerRecords().asSequence()
            .filter { it.relay && it.host.isNotBlank() && it.gatewayDistance < Int.MAX_VALUE && fresh(it.lastSeenAt, now) }
            .mapNotNull { peer ->
                val advert = advertisement(peer)
                if (advert.distance >= Int.MAX_VALUE) return@mapNotNull null
                if (advert.path.contains(nodeId) || advert.path.distinct().size != advert.path.size) return@mapNotNull null
                val state = health[peer.name]
                if (state != null && state.suppressedUntil > now) return@mapNotNull null
                val score = routeScore(peer, advert.distance, state)
                score to advert
            }
            .sortedBy { it.first }
            .firstOrNull()?.second
            ?: return emptyList()
        return if (best.exactPath) listOf(nodeId) + best.path else listOf(nodeId, best.peerName)
    }

    fun gatewayPublicKey(gatewayEnabled: Boolean, transitEnabled: Boolean): String {
        if (gatewayEnabled) return ""
        if (!transitEnabled) return ""
        val now = System.currentTimeMillis()
        return peerRecords().asSequence()
            .filter { it.relay && it.host.isNotBlank() && it.gatewayDistance < Int.MAX_VALUE && fresh(it.lastSeenAt, now) }
            .mapNotNull { peer ->
                val advert = advertisement(peer)
                if (advert.distance >= Int.MAX_VALUE || advert.gatewayPublicKey.isBlank()) return@mapNotNull null
                if (advert.path.contains(nodeId) || advert.path.distinct().size != advert.path.size) return@mapNotNull null
                val state = health[peer.name]
                if (state != null && state.suppressedUntil > now) return@mapNotNull null
                routeScore(peer, advert.distance, state) to advert.gatewayPublicKey
            }
            .sortedBy { it.first }
            .firstOrNull()?.second.orEmpty()
    }

    fun gatewayDistance(gatewayEnabled: Boolean, transitEnabled: Boolean): Int {
        if (gatewayEnabled) return 0
        if (!transitEnabled) return Int.MAX_VALUE
        val now = System.currentTimeMillis()
        return peerRecords().asSequence()
            .filter { it.relay && it.host.isNotBlank() && it.gatewayDistance < Int.MAX_VALUE && fresh(it.lastSeenAt, now) }
            .mapNotNull { peer ->
                val state = health[peer.name]
                if (state != null && state.suppressedUntil > now) return@mapNotNull null
                val advert = advertisement(peer)
                if (advert.path.contains(nodeId) || advert.path.distinct().size != advert.path.size) null
                else advert.distance + 1
            }
            .minOrNull() ?: Int.MAX_VALUE
    }


    /**
     * Outbound-only gateway selection. This never depends on whether this device
     * allows inbound transit; users can consume a remote Internet gateway without
     * volunteering their own device as a relay.
     */
    fun outboundGatewayDistance(): Int = peerRecords().asSequence()
        .filter { it.relay && it.host.isNotBlank() && it.gatewayDistance < Int.MAX_VALUE && fresh(it.lastSeenAt, System.currentTimeMillis()) }
        .mapNotNull { peer ->
            val advert = advertisement(peer)
            if (advert.path.contains(nodeId) || advert.path.distinct().size != advert.path.size) null
            else advert.distance + 1
        }
        .minOrNull() ?: Int.MAX_VALUE

    fun outboundGatewayPublicKey(): String = peerRecords().asSequence()
        .filter { it.relay && it.host.isNotBlank() && it.gatewayDistance < Int.MAX_VALUE && fresh(it.lastSeenAt, System.currentTimeMillis()) }
        .mapNotNull { peer ->
            val advert = advertisement(peer)
            if (advert.distance >= Int.MAX_VALUE || advert.gatewayPublicKey.isBlank()) return@mapNotNull null
            if (advert.path.contains(nodeId) || advert.path.distinct().size != advert.path.size) return@mapNotNull null
            routeScore(peer, advert.distance, health[peer.name]) to advert.gatewayPublicKey
        }
        .minByOrNull { it.first }?.second.orEmpty()

    fun outboundCandidates(visited: Set<String>, currentDistance: Int = Int.MAX_VALUE, limit: Int = 4): List<NextHop> =
        allCandidates(visited, currentDistance).take(limit.coerceIn(1, 8))

    fun chooseNextHop(visited: Set<String>, currentDistance: Int = Int.MAX_VALUE): NextHop? =
        candidates(visited, currentDistance, 1).firstOrNull()

    fun candidates(visited: Set<String>, currentDistance: Int = Int.MAX_VALUE, limit: Int = 4): List<NextHop> =
        allCandidates(visited, currentDistance).take(limit.coerceIn(1, 8))

    fun reportFailure(nodeId: String) {
        val now = System.currentTimeMillis()
        val state = health.computeIfAbsent(nodeId) { Health() }
        synchronized(state) {
            state.failures = (state.failures + 1).coerceAtMost(10)
            state.lastFailureAt = now
            val backoff = (2_000L shl (state.failures - 1).coerceAtMost(5)).coerceAtMost(60_000L)
            state.suppressedUntil = now + backoff
        }
    }

    fun reportSuccess(nodeId: String) {
        health[nodeId]?.let { state ->
            synchronized(state) {
                state.failures = 0
                state.lastSuccessAt = System.currentTimeMillis()
                state.suppressedUntil = 0L
            }
        }
    }

    fun routeStatus(gatewayEnabled: Boolean, transitEnabled: Boolean): RouteStatus {
        val path = gatewayPath(gatewayEnabled, transitEnabled)
        val distance = gatewayDistance(gatewayEnabled, transitEnabled)
        val candidates = allCandidates(setOf(nodeId), distance).size
        return RouteStatus(path, distance, distance < Int.MAX_VALUE, candidates)
    }

    fun summary(gatewayEnabled: Boolean, transitEnabled: Boolean): String {
        val status = routeStatus(gatewayEnabled, transitEnabled)
        if (!status.healthy) return "Aucune route vers une passerelle"
        val pathText = status.path.joinToString(" → ")
        return "Chemin NEXUS détecté : $pathText • ${status.distance} saut(s) • ${status.candidates} autre(s) chemin(s)"
    }

    private fun allCandidates(visited: Set<String>, currentDistance: Int): List<NextHop> {
        val now = System.currentTimeMillis()
        return peerRecords()
            .asSequence()
            .filter { peer -> peer.name != nodeId && peer.name !in visited && peer.relay && peer.host.isNotBlank() }
            .filter { peer -> fresh(peer.lastSeenAt, now) }
            .mapNotNull { peer ->
                val advert = advertisement(peer)
                if (advert.distance >= Int.MAX_VALUE) return@mapNotNull null
                if (currentDistance != Int.MAX_VALUE && advert.distance >= currentDistance) return@mapNotNull null
                if (advert.path.any { it in visited } || advert.path.contains(nodeId)) return@mapNotNull null
                val state = health[peer.name]
                if (state != null && state.suppressedUntil > now) return@mapNotNull null
                val score = routeScore(peer, advert.distance, state)
                NextHop(
                    nodeId = peer.name,
                    host = peer.host,
                    port = peer.port.takeIf { it > 0 } ?: NexusConfig.RELAY_PORT,
                    advertisedDistance = advert.distance,
                    score = score,
                    p2p = peer.p2p,
                    gatewayPath = advert.path,
                    gatewayPublicKey = advert.gatewayPublicKey,
                    trust = trustProvider(peer).coerceIn(0.0, 1.0)
                )
            }
            .sortedBy { it.score }
            .toList()
    }

    private fun advertisement(peer: NsdController.Peer): RouteAdvertisement {
        val clean = peer.gatewayPath.filter { it.isNotBlank() }.distinct()
        val gatewayKey = peer.gatewayPublicKey
        return if (clean.isNotEmpty() && clean.first() == peer.name && clean.size <= NexusConfig.MAX_ADVERTISED_PATH) {
            RouteAdvertisement(peer.name, clean, (clean.size - 1).coerceAtLeast(0), true, gatewayKey)
        } else {
            RouteAdvertisement(peer.name, listOf(peer.name), peer.gatewayDistance, false, gatewayKey)
        }
    }

    private fun peerRecords(): List<NsdController.Peer> {
        val p2p = NexusP2PDirectory.snapshot().map { endpoint ->
            NsdController.Peer(
                name = endpoint.id,
                host = endpoint.host,
                port = endpoint.port,
                gateway = endpoint.gateway,
                relay = endpoint.relay,
                gatewayDistance = endpoint.gatewayDistance,
                gatewayPath = endpoint.gatewayPath,
                latencyMs = endpoint.latencyMs,
                packetLossPct = endpoint.packetLossPct,
                bandwidthMbps = endpoint.bandwidthMbps,
                p2p = true,
                identityPublicKey = endpoint.identityPublicKey,
                gatewayPublicKey = endpoint.gatewayPublicKey,
                authenticatedIdentity = endpoint.authenticatedIdentity,
                lastSeenAt = System.currentTimeMillis()
            )
        }
        return (peersProvider() + p2p)
            .filter { it.name != nodeId }
            .groupBy { it.name }
            .mapNotNull { (_, rows) ->
                rows.filter { it.host.isNotBlank() || it.gatewayDistance < Int.MAX_VALUE }
                    .minByOrNull { routeScore(it, it.gatewayDistance.coerceAtLeast(0), null) }
            }
    }

    private fun routeScore(peer: NsdController.Peer, distance: Int, state: Health?): Double {
        val latency = peer.latencyMs.takeIf { it.isFinite() } ?: 5000.0
        val loss = peer.packetLossPct.coerceIn(0.0, 100.0)
        val bandwidth = peer.bandwidthMbps.coerceIn(0.0, 1000.0)
        val failures = maxOf(state?.failures ?: 0, peer.consecutiveFailures)
        val trust = trustProvider(peer).coerceIn(0.0, 1.0)
        return distance * 10_000.0 +
            latency * 2.0 +
            loss * 250.0 +
            failures * 5_000.0 -
            bandwidth * 2.0 +
            (1.0 - trust) * 12_000.0 +
            if (peer.authenticatedIdentity) 0.0 else 2_500.0 +
            if (peer.p2p) 5.0 else 0.0
    }

    private fun fresh(lastSeenAt: Long, now: Long): Boolean = now - lastSeenAt <= 35_000
}
