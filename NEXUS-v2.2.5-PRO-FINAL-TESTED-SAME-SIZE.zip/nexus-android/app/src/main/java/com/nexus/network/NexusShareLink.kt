package com.nexus.network

import android.net.Uri

/** Securely transportable NEXUS contact link. The address itself is public; authorization still occurs in-app. */
object NexusShareLink {
    fun forAddress(address: String): String {
        require(NexusAddress.isValidOverlay(address)) { "Adresse NEXUS invalide" }
        return Uri.Builder().scheme("nexus").authority("contact").appendQueryParameter("address", NexusAddress.canonicalize(address)).build().toString()
    }

    fun addressFrom(uri: Uri?): String? {
        if (uri?.scheme != "nexus" || uri.host != "contact") return null
        val address = uri.getQueryParameter("address") ?: return null
        return runCatching { NexusAddress.canonicalize(address) }.getOrNull()?.takeIf { NexusAddress.isValidOverlay(it) }
    }
}
