package com.nexus.network

import android.content.Context
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Optional replication of user-selected databases to explicitly trusted peers. */
class NexusDatabaseReplicator(private val context: Context, private val peersProvider: () -> List<NsdController.Peer>) {
    private val pool=Executors.newSingleThreadScheduledExecutor { r -> Thread(r,"nexus-db-replicator").apply{isDaemon=true} }
    @Volatile private var running=false

    fun start(){ if(running)return; running=true; pool.scheduleWithFixedDelay({replicateOnce()},30,90,TimeUnit.SECONDS) }
    fun stop(){running=false;pool.shutdownNow()}
    fun replicateOnce(){
        if(!running || !NexusSettings.databaseReplicationEnabled(context)) return
        val databases=NexusDatabase.databases(context).filter { it != "messages" }.take(8)
        val peers=peersProvider().filter{it.host.isNotBlank() && NexusTrustStore.isAllowed(context,it.name)}.take(4)
        if(peers.isEmpty())return
        for(db in databases){
            val records=NexusDatabase.list(context,db,256)
            for(peer in peers){
                records.forEach { record -> runCatching { NexusServiceProtocol.putRemote(context,peer.host,record) } }
            }
        }
    }
}
