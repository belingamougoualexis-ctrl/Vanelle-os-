package com.nexus.network

import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sqrt

/**
 * Opt-in presence directory for discovering NEXUS nodes beyond the local link.
 * Only coarse geographic cells are published; exact coordinates are never stored.
 */
object NexusPresence {
    private const val PREFIX = "nexus/presence/"
    private const val TTL_MS = 3L * 60 * 1000
    private const val FINE_STEP = 0.05
    private const val REGION_STEP = 0.25
    private const val MAX_ENDPOINTS = 8

    enum class Scope(val label: String, val radiusKm: Int) {
        NEARBY("À proximité", 0),
        TEN_KM("Jusqu’à 10 km", 10),
        HUNDRED_KM("Jusqu’à 100 km", 100),
        COUNTRY("Mon pays", -1),
        WORLD("Monde", -2)
    }

    data class GeoCell(val latIndex: Long, val lonIndex: Long, val step: Double) {
        fun key(): String = "${latIndex}_${lonIndex}"
        fun center(): Pair<Double, Double> =
            ((latIndex + 0.5) * step - 90.0) to ((lonIndex + 0.5) * step - 180.0)
    }

    data class Record(
        val address: String,
        val nodeId: String,
        val publicKey: String,
        val displayName: String,
        val countryCode: String,
        val fineCell: String,
        val regionCell: String,
        val endpoints: List<String>,
        val createdAt: Long,
        val expiresAt: Long,
        val signature: String
    )

    fun own(context: Context): Record? {
        if (!NexusSettings.presenceSharingEnabled(context)) return null
        val location = currentLocation(context)
        val country = deviceCountryCode(context)
        val fine = location?.let { cellFor(it.latitude, it.longitude, FINE_STEP).key() }.orEmpty()
        val region = location?.let { cellFor(it.latitude, it.longitude, REGION_STEP).key() }.orEmpty()
        val created = System.currentTimeMillis()
        val expires = created + TTL_MS
        val publicKey = NexusIdentity.publicKeyBase64(context)
        val address = NexusAddress.overlayIpv6FromPublicKey(publicKey)
        val name = NexusNaming.own(context, NexusAddress.advertisedAddresses(context)).name
        val endpoints = NexusAddress.realGlobalAddresses()
            .mapNotNull { endpointFor(it, NexusConfig.NODE_PORT) }
            .distinct()
            .take(MAX_ENDPOINTS)
        val canonical = canonical(address, NexusIdentity.nodeId(context), publicKey, name, country, fine, region, endpoints, created, expires)
        return Record(
            address = address,
            nodeId = NexusIdentity.nodeId(context),
            publicKey = publicKey,
            displayName = name,
            countryCode = country,
            fineCell = fine,
            regionCell = region,
            endpoints = endpoints,
            createdAt = created,
            expiresAt = expires,
            signature = NexusCrypto.encodeBytes(NexusIdentity.sign(context, canonical))
        )
    }

    fun records(context: Context): List<Pair<String, Record>> {
        val own = own(context) ?: return emptyList()
        val result = mutableListOf<Pair<String, Record>>()
        result += "world/" to own
        if (own.countryCode.isNotBlank()) result += "country/${own.countryCode}" to own
        if (own.regionCell.isNotBlank()) result += "region/${own.regionCell}" to own
        if (own.fineCell.isNotBlank()) result += "fine/${own.fineCell}" to own
        return result
    }

    fun wire(record: Record): String = NexusCrypto.encode(JSONObject().apply {
        put("address", record.address)
        put("nodeId", record.nodeId)
        put("publicKey", record.publicKey)
        put("displayName", record.displayName)
        put("countryCode", record.countryCode)
        put("fineCell", record.fineCell)
        put("regionCell", record.regionCell)
        put("endpoints", JSONArray(record.endpoints))
        put("createdAt", record.createdAt)
        put("expiresAt", record.expiresAt)
        put("signature", record.signature)
    }.toString())

    fun fromWire(wire: String): Record? = runCatching {
        val j = JSONObject(NexusCrypto.decode(wire))
        val endpointsArray = j.optJSONArray("endpoints") ?: JSONArray()
        val endpoints = buildList {
            for (i in 0 until endpointsArray.length()) add(endpointsArray.getString(i))
        }
        Record(
            address = j.getString("address"),
            nodeId = j.getString("nodeId"),
            publicKey = j.getString("publicKey"),
            displayName = j.optString("displayName", "NEXUS"),
            countryCode = j.optString("countryCode", "").uppercase(Locale.US).take(2),
            fineCell = j.optString("fineCell", ""),
            regionCell = j.optString("regionCell", ""),
            endpoints = endpoints.take(MAX_ENDPOINTS),
            createdAt = j.getLong("createdAt"),
            expiresAt = j.getLong("expiresAt"),
            signature = j.getString("signature")
        )
    }.getOrNull()?.takeIf(::verify)

    fun verify(record: Record): Boolean = runCatching {
        require(NexusAddress.isValidOverlay(record.address))
        require(record.nodeId.isNotBlank() && record.nodeId.length <= 160)
        require(record.publicKey.isNotBlank())
        require(record.displayName.length <= 200)
        require(record.countryCode.length <= 2)
        require(record.fineCell.length <= 64 && record.regionCell.length <= 64)
        require(record.endpoints.size <= MAX_ENDPOINTS)
        require(record.endpoints.all { isValidEndpoint(it) })
        require(record.expiresAt > System.currentTimeMillis())
        require(record.expiresAt - record.createdAt in 60_000L..24L * 60 * 60 * 1000)
        require(NexusAddress.overlayIpv6FromPublicKey(record.publicKey) == record.address)
        NexusIdentity.verify(
            record.publicKey,
            canonical(record.address, record.nodeId, record.publicKey, record.displayName, record.countryCode, record.fineCell, record.regionCell, record.endpoints, record.createdAt, record.expiresAt),
            record.signature
        )
    }.getOrDefault(false)

    fun dhtRecord(context: Context, keySuffix: String, record: Record): NexusDht.Record {
        require(keySuffix.startsWith("world/") || keySuffix.startsWith("country/") || keySuffix.startsWith("region/") || keySuffix.startsWith("fine/"))
        val key = key(keySuffix, record.nodeId)
        return NexusDht(NexusIdentity.nodeId(context)).signed(context, key, wire(record), TTL_MS)
    }

    fun verifyDhtRecord(record: NexusDht.Record): Boolean {
        if (!record.key.startsWith(PREFIX)) return false
        val suffix = record.key.removePrefix(PREFIX)
        if (!(suffix.startsWith("world/") || suffix.startsWith("country/") || suffix.startsWith("region/") || suffix.startsWith("fine/"))) return false
        val presence = fromWire(record.value) ?: return false
        val expected = suffix.substringAfterLast('/')
        return presence.nodeId == record.publisher && presence.nodeId == expected && verify(presence)
    }

    fun filter(records: Collection<Record>, scope: Scope, ownLocation: Location?, ownCountry: String): List<Record> {
        return records
            .filter { it.nodeId.isNotBlank() }
            .distinctBy { it.nodeId }
            .filter { record ->
                when (scope) {
                    Scope.NEARBY -> false
                    Scope.TEN_KM, Scope.HUNDRED_KM -> {
                        val origin = ownLocation ?: return@filter false
                        val cell = parseCell(if (scope == Scope.TEN_KM) record.fineCell else record.regionCell, if (scope == Scope.TEN_KM) FINE_STEP else REGION_STEP)
                            ?: return@filter false
                        distanceKm(origin.latitude, origin.longitude, cell.center().first, cell.center().second) <= scope.radiusKm + (if (scope == Scope.TEN_KM) 4.5 else 20.0)
                    }
                    Scope.COUNTRY -> ownCountry.isNotBlank() && record.countryCode.equals(ownCountry, true)
                    Scope.WORLD -> true
                }
            }
            .sortedWith(compareBy<Record> { it.countryCode }.thenBy { it.displayName.lowercase(Locale.US) })
    }

    fun relevantPrefixes(scope: Scope, ownLocation: Location?, ownCountry: String): List<String> {
        return when (scope) {
            Scope.NEARBY -> emptyList()
            Scope.TEN_KM -> ownLocation?.let { cellPrefixes(it.latitude, it.longitude, FINE_STEP, 10.0) }.orEmpty()
            Scope.HUNDRED_KM -> ownLocation?.let { cellPrefixes(it.latitude, it.longitude, REGION_STEP, 100.0) }.orEmpty()
            Scope.COUNTRY -> if (ownCountry.isNotBlank()) listOf(PREFIX + "country/${ownCountry.lowercase(Locale.US)}/") else emptyList()
            Scope.WORLD -> listOf(PREFIX + "world/")
        }
    }

    fun cellFor(latitude: Double, longitude: Double, step: Double): GeoCell {
        val latIndex = floor(((latitude.coerceIn(-90.0, 89.999999) + 90.0) / step)).toLong()
        val lonIndex = floor(((longitude.coerceIn(-180.0, 179.999999) + 180.0) / step)).toLong()
        return GeoCell(latIndex, lonIndex, step)
    }

    fun parseCell(value: String, step: Double): GeoCell? = runCatching {
        val p = value.split('_')
        require(p.size == 2)
        GeoCell(p[0].toLong(), p[1].toLong(), step)
    }.getOrNull()

    fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earthKm = 6371.0088
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = kotlin.math.sin(dLat / 2) * kotlin.math.sin(dLat / 2) +
            kotlin.math.cos(Math.toRadians(lat1)) * kotlin.math.cos(Math.toRadians(lat2)) *
            kotlin.math.sin(dLon / 2) * kotlin.math.sin(dLon / 2)
        return 2 * earthKm * kotlin.math.atan2(sqrt(a), sqrt(1 - a))
    }

    fun currentLocation(context: Context): Location? {
        val manager = context.getSystemService(LocationManager::class.java) ?: return null
        if (!hasLocationPermission(context)) return null
        val providers = manager.getProviders(true).orEmpty()
        val cached = providers.mapNotNull { provider ->
            runCatching { manager.getLastKnownLocation(provider) }.getOrNull()
        }.maxByOrNull { it.time }

        // Do not fabricate a position when Android has no cached fix. Request a real
        // one briefly on Android 11+; on older releases the cached provider result is
        // the only synchronous source available here. This method is called from the
        // presence-search worker, never from the UI thread.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return cached

        val bestCached = cached?.takeIf { System.currentTimeMillis() - it.time <= 5 * 60_000L }
        if (bestCached != null) return bestCached

        val providersToQuery = providers.filter {
            it == LocationManager.GPS_PROVIDER || it == LocationManager.NETWORK_PROVIDER || it == LocationManager.PASSIVE_PROVIDER
        }.distinct()
        for (provider in providersToQuery) {
            val fresh = requestCurrentLocation(manager, provider)
            if (fresh != null) return fresh
        }
        return cached
    }

    private fun requestCurrentLocation(manager: LocationManager, provider: String): Location? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        val latch = CountDownLatch(1)
        var result: Location? = null
        val cancellation = CancellationSignal()
        runCatching {
            manager.getCurrentLocation(provider, cancellation, { runnable -> runnable.run() }, { location ->
                result = location
                latch.countDown()
            })
            latch.await(1800, TimeUnit.MILLISECONDS)
        }.onFailure { latch.countDown() }
        cancellation.cancel()
        return result
    }

    fun hasLocationPermission(context: Context): Boolean =
        context.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED

    fun deviceCountryCode(context: Context): String {
        val network = runCatching {
            if (Build.VERSION.SDK_INT >= 24) context.getSystemService(android.telephony.TelephonyManager::class.java)?.networkCountryIso else null
        }.getOrNull().orEmpty()
        return (network.takeIf { it.length == 2 } ?: Locale.getDefault().country).uppercase(Locale.US).take(2)
    }

    private fun key(suffix: String, nodeId: String): String = PREFIX + suffix.trim('/').lowercase(Locale.US) + "/" + nodeId

    private fun endpointFor(address: String, port: Int): String? = runCatching {
        val host = address.removeSuffix("%0").trim()
        val parsed = java.net.InetAddress.getByName(host)
        require(!parsed.isLoopbackAddress && !parsed.isLinkLocalAddress && !parsed.isSiteLocalAddress && !parsed.isAnyLocalAddress && !parsed.isMulticastAddress)
        if (parsed is java.net.Inet6Address) "[${parsed.hostAddress.substringBefore('%')}]" + ":$port" else "${parsed.hostAddress}:$port"
    }.getOrNull()

    private fun isValidEndpoint(endpoint: String): Boolean = runCatching {
        val trimmed = endpoint.replace(" ", "")
        val host: String
        val portText: String
        if (trimmed.startsWith("[")) {
            host = trimmed.substringAfter('[').substringBefore(']')
            portText = trimmed.substringAfter("]:")
        } else {
            host = trimmed.substringBeforeLast(':')
            portText = trimmed.substringAfterLast(':')
        }
        val port = portText.toInt()
        require(port in 1..65535)
        val address = java.net.InetAddress.getByName(host)
        !address.isLoopbackAddress && !address.isLinkLocalAddress && !address.isSiteLocalAddress && !address.isAnyLocalAddress && !address.isMulticastAddress
    }.getOrDefault(false)

    private fun cellPrefixes(latitude: Double, longitude: Double, step: Double, radiusKm: Double): List<String> {
        val origin = cellFor(latitude, longitude, step)
        val latKm = step * 111.2
        val lonKm = step * 111.2 * maxOf(0.2, cos(Math.toRadians(latitude)))
        val latSpan = kotlin.math.ceil(radiusKm / latKm).toInt().coerceAtMost(12)
        val lonSpan = kotlin.math.ceil(radiusKm / lonKm).toInt().coerceAtMost(12)
        val result = ArrayList<String>()
        for (di in -latSpan..latSpan) {
            for (dj in -lonSpan..lonSpan) {
                val cell = GeoCell(origin.latIndex + di, origin.lonIndex + dj, step)
                val center = cell.center()
                if (distanceKm(latitude, longitude, center.first, center.second) <= radiusKm + latKm * 0.8) {
                    result += PREFIX + (if (step == FINE_STEP) "fine/" else "region/") + cell.key() + "/"
                }
            }
        }
        return result.distinct().take(96)
    }

    private fun canonical(
        address: String,
        nodeId: String,
        publicKey: String,
        displayName: String,
        countryCode: String,
        fineCell: String,
        regionCell: String,
        endpoints: List<String>,
        created: Long,
        expires: Long
    ): String = "v=1&address=$address&node=$nodeId&publicKey=${NexusCrypto.encode(publicKey)}&name=${NexusCrypto.encode(displayName)}&country=$countryCode&fine=$fineCell&region=$regionCell&endpoints=${NexusCrypto.encode(endpoints.sorted().joinToString(","))}&created=$created&expires=$expires"
}
