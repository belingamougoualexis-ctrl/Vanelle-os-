package com.nexus.network

object NexusConfig {
    const val TRANSPORT_VPN = 4
    const val VERSION = "2.2.5"
    const val SERVICE_TYPE = "_nexus._tcp"
    const val NODE_PORT = 45454
    const val SOCKS_PORT = 45455
    const val RELAY_PORT = 45456
    const val CONTENT_PORT = 45457
    const val APP_SHARE_PORT = 45458
    const val SERVICE_PORT = 45460
    const val DTN_BUNDLE_MAX_BYTES = 8 * 1024 * 1024
    const val DHT_K = 20
    const val NAT_STUN_TIMEOUT_MS = 2500
    // Keep direct Internet attempts bounded, then let the routed relay path recover
    // transparently when NAT/CGNAT/firewall rules prevent a direct socket.
    const val DIRECT_CONNECT_TIMEOUT_MS = 10_000
    const val RELAY_CONNECT_TIMEOUT_MS = 12_000
    const val MAX_HOPS = 64
    const val MAX_ADVERTISED_PATH = 32
    // Nombre de sauts utilisés par défaut pour les connexions longue distance.
    // Il reste inférieur ou égal à la limite globale et correspond à la longueur
    // maximale annoncée par le routage.
    const val DEFAULT_ROUTE_TTL = 32
    // Recovery never gives up because of a temporary missing path. Discovery is
    // repeated in the background and outgoing flows briefly wait for new paths.
    const val ROUTE_RECOVERY_INTERVAL_SECONDS = 8L
    const val ROUTE_RECOVERY_MIN_GAP_MS = 1_500L
    const val ROUTE_RECOVERY_WAIT_MS = 12_000L
    const val ROUTE_RECOVERY_PROBE_TIMEOUT_MS = 350
    const val ROUTE_RECOVERY_MAX_LOCAL_HOSTS = 254
    const val ROUTE_RECOVERY_MAX_ATTEMPTS = 3
    const val CONTENT_REPLICATION_DEFAULT = 3
    const val ACTION_AUTO_CONNECT = "com.nexus.network.ACTION_AUTO_CONNECT"
    const val ACTION_GATEWAY = "com.nexus.network.ACTION_GATEWAY"
    const val ACTION_TRANSIT = "com.nexus.network.ACTION_TRANSIT"
    const val ACTION_VPN = "com.nexus.network.ACTION_VPN"
    const val ACTION_VPN_STOP = "com.nexus.network.ACTION_VPN_STOP"
    const val ACTION_ROTATE_KEY = "com.nexus.network.ACTION_ROTATE_KEY"
    const val ACTION_STOP = "com.nexus.network.ACTION_STOP"
    const val EXTRA_ENABLED = "enabled"
    const val SOCKS_USERNAME = "nexus"
}
