package com.nexus.network

import android.content.Context
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.NetworkInterface

/** Stable NEXUS overlay IPv6 identity plus real locally routable IP candidates. */
object NexusAddress {
    private const val ULA_PREFIX = "fd00:4e58:5553"

    fun overlayIpv6(context: Context): String = overlayIpv6FromPublicKey(NexusIdentity.publicKeyBase64(context))

    fun overlayIpv6FromPublicKey(publicKeyBase64: String): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256").digest(publicKeyBase64.toByteArray(Charsets.UTF_8))
        // 48-bit ULA prefix + 80 bits derived from the installation public key.
        // This gives a practically collision-resistant NEXUS overlay address while
        // keeping the address stable for the same cryptographic identity.
        val groups = (0 until 5).map { i ->
            val off = i * 2
            ((digest[off].toInt() and 0xff) shl 8 or (digest[off + 1].toInt() and 0xff)).toString(16).padStart(4, '0')
        }
        val raw = "$ULA_PREFIX:${groups.joinToString(":")}"
        return canonicalize(raw)
    }

    fun canonicalize(value: String): String = runCatching {
        val address = InetAddress.getByName(value.trim())
        require(address is Inet6Address)
        address.hostAddress.substringBefore('%').lowercase()
    }.getOrElse { value.trim().lowercase().substringBefore('%') }

    fun isValidOverlay(value: String): Boolean = runCatching {
        val normalized = value.trim()
        require(normalized.contains(":"))
        val address = InetAddress.getByName(normalized)
        address is Inet6Address && canonicalize(address.hostAddress).startsWith("fd00:4e58:5553:")
    }.getOrDefault(false)

    /** Real global IP addresses exposed by the current Android interfaces. */
    fun realGlobalAddresses(): List<String> = NetworkInterface.getNetworkInterfaces()?.asSequence()?.toList().orEmpty()
        .flatMap { it.inetAddresses?.asSequence()?.toList().orEmpty() }
        .filterNot { it.isLoopbackAddress || it.isLinkLocalAddress || it.isAnyLocalAddress || it.isMulticastAddress }
        .filter { address ->
            when (address) {
                is Inet6Address -> !address.isSiteLocalAddress
                is Inet4Address -> !address.isSiteLocalAddress
                else -> false
            }
        }
        .map { it.hostAddress.substringBefore('%') }
        .distinct()
        .sortedWith(compareBy<String> { if (it.contains(':')) 0 else 1 }.thenBy { it })

    fun advertisedAddresses(context: Context): List<String> =
        (realGlobalAddresses() + listOf(overlayIpv6(context))).distinct().take(8)

    fun endpointText(context: Context, port: Int = NexusConfig.NODE_PORT): String =
        advertisedAddresses(context).joinToString(",") { addr ->
            if (addr.contains(':') && !addr.startsWith("fd00:4e58:5553:")) "[$addr]:$port" else if (addr.contains(':')) addr else "$addr:$port"
        }
}
