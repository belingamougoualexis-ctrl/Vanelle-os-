package com.nexus.network

import android.content.Context
import java.io.File

/** Small stable SDK facade intended for future NEXUS-native applications. */
class NexusAppSdk(private val context: Context) {
    fun identity(): String = NexusIdentity.nodeId(context)
    fun localName(): String = NexusNaming.own(context, emptyList()).name
    fun put(database: String, key: String, value: String): NexusDatabase.Record = NexusDatabase.put(context, database, key, value)
    fun get(database: String, key: String): NexusDatabase.Record? = NexusDatabase.get(context, database, key)
    fun store(file: File, name: String = file.name, mime: String = "application/octet-stream", pin: Boolean = true): NexusContentStore.Manifest =
        NexusContentStore.putFile(context, file, name, mime, pin)
    fun compute(operation: String, input: ByteArray): NexusCompute.Result =
        NexusCompute.execute(context, NexusCompute.Task("sdk-${System.nanoTime()}", operation, input))
    fun issueCapability(subjectNode: String, capability: String, resource: String, ttlMs: Long = 24L * 60 * 60 * 1000) =
        NexusCapabilities.issue(context, subjectNode, capability, resource, ttlMs)
    fun cacheStats(): NexusEdgeCache.Stats = NexusEdgeCache.stats(context)
}
