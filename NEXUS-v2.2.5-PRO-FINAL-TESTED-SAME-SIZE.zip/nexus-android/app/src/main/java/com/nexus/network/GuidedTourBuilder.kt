package com.nexus.network

import android.app.Activity
import android.view.View
import android.view.ViewGroup

/** Déclaration concise d'un parcours : activity.guidedTour(host) { step(vue, "Titre", "Message") }.start() */
class GuidedTourBuilder {
    internal val steps = mutableListOf<GuidedTour.Step>()
    /** Vue de mascotte optionnelle (ex. animation Lottie). Par défaut : le logo NEXUS. */
    var mascot: ((android.content.Context) -> View)? = null

    fun step(target: View, title: String, message: String, mascotName: String = "Conseil NEXUS", runAction: Boolean = false) {
        steps += GuidedTour.Step(target, title, message, mascotName, runAction)
    }
}

fun Activity.guidedTour(host: ViewGroup, block: GuidedTourBuilder.() -> Unit): GuidedTour =
    GuidedTourBuilder().apply(block).let { GuidedTour(this, host, it.steps.toList(), it.mascot) }
