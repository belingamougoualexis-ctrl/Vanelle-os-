package com.nexus.network

import android.content.Context
import java.io.File
import java.util.concurrent.TimeUnit

/** Real local health monitor: verifies persisted content and tries recovery from known peers. */
class NexusAutoRepair(private val context: Context, private val peersProvider: () -> List<NsdController.Peer>) {
    data class Report(val checked: Int, val repaired: Int, val failed: Int)

    fun runOnce(): Report {
        val pinned = NexusContentStore.allPinned(context)
        var repaired=0; var failed=0
        for (m in pinned) {
            if (NexusContentStore.verifyComplete(context,m.hash)) continue
            val providers=peersProvider().filter { it.host.isNotBlank() && NexusTrustStore.isAllowed(context,it.name) }.sortedByDescending { NexusTrustStore.reputation(context,it.name) }
            val dest=File(context.cacheDir,"repair-${m.hash}.bin")
            val ok=providers.asSequence().map { peer -> NexusContentClient.fetch(peer.host,context,m.hash,dest).getOrNull() }.firstOrNull { it != null } != null
            if (ok && NexusContentStore.verifyComplete(context,m.hash)) repaired++ else failed++
            dest.delete()
        }
        return Report(pinned.size,repaired,failed)
    }
}
