package com.nexus.network

/** True XOR erasure coding for a 2-data-shard + 1-parity-shard stripe. It tolerates loss of any one shard. */
object NexusErasureCoding {
    data class Stripe(val originalSize: Int, val shardSize: Int, val dataA: ByteArray, val dataB: ByteArray, val parity: ByteArray)

    fun encode(input: ByteArray): Stripe {
        require(input.isNotEmpty()) { "Donnée vide" }
        val shardSize = (input.size + 1) / 2
        val a = ByteArray(shardSize)
        val b = ByteArray(shardSize)
        System.arraycopy(input, 0, a, 0, minOf(shardSize, input.size))
        val second = input.copyOfRange(minOf(shardSize, input.size), input.size)
        System.arraycopy(second, 0, b, 0, second.size)
        val parity = ByteArray(shardSize) { i -> (a[i].toInt() xor b[i].toInt()).toByte() }
        return Stripe(input.size, shardSize, a, b, parity)
    }

    fun recover(stripe: Stripe, dataA: ByteArray?, dataB: ByteArray?, parity: ByteArray?): ByteArray {
        val present = listOf(dataA, dataB, parity).count { it != null }
        require(present >= 2) { "Deux fragments minimum sont nécessaires" }
        val a = dataA ?: xor(requireNotNull(dataB), requireNotNull(parity))
        val b = dataB ?: xor(requireNotNull(dataA), requireNotNull(parity))
        val output = ByteArray(stripe.originalSize)
        val copiedA = minOf(a.size, output.size)
        System.arraycopy(a, 0, output, 0, copiedA)
        if (output.size > stripe.shardSize) System.arraycopy(b, 0, output, stripe.shardSize, output.size - stripe.shardSize)
        return output
    }

    private fun xor(a: ByteArray, b: ByteArray): ByteArray {
        require(a.size == b.size) { "Fragments incompatibles" }
        return ByteArray(a.size) { i -> (a[i].toInt() xor b[i].toInt()).toByte() }
    }
}
