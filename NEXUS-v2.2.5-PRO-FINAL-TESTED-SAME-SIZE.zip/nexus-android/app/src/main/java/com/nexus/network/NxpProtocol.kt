package com.nexus.network

import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom

/** Authenticated NEXUS node control protocol and real link measurements. */
object NxpProtocol {
    private const val MAX_LINE = 8192
    private const val PING_SAMPLES = 4
    private const val PING_TIMEOUT_MS = 2500
    private const val MAX_BANDWIDTH_BYTES = 1024 * 1024
    private const val BANDWIDTH_CHUNK = 16 * 1024
    private val random = SecureRandom()

    data class Capabilities(
        val gateway: Boolean,
        val relay: Boolean,
        val nodeId: String,
        val gatewayDistance: Int,
        val gatewayPath: List<String> = emptyList(),
        val latencyMs: Double = Double.POSITIVE_INFINITY,
        val packetLossPct: Double = 100.0,
        val bandwidthMbps: Double = 0.0,
        val identityPublicKey: String = "",
        val gatewayPublicKey: String = "",
        val authenticatedIdentity: Boolean = false,
        val admissionValid: Boolean = false,
        val natCandidate: NexusNatTraversal.Candidate? = null,
        val domainId: String = "",
        val routePrefix: String = ""
    )

    data class CheckResult(
        val latencyMs: Double,
        val packetLossPct: Double,
        val hello: String,
        val pong: String
    )

    data class BandwidthResult(
        val downloadMbps: Double,
        val uploadMbps: Double,
        val bytesTested: Int
    )

    fun serverHandshake(
        socket: Socket,
        nodeId: String,
        gateway: Boolean,
        relay: Boolean,
        gatewayDistance: Int,
        gatewayPath: List<String> = emptyList(),
        gatewayPublicKey: String = "",
        identityContext: android.content.Context? = null,
        dhtProvider: NexusDht? = null,
        dtnProvider: NexusDtnStore? = null,
        natCandidateProvider: () -> NexusNatTraversal.Candidate? = { null },
        secretProvider: () -> List<String>
    ) {
        val input = socket.getInputStream()
        val output = socket.getOutputStream()
        val first = readAsciiLineRaw(input, MAX_LINE) ?: return
        val fields = parseFields(first)
        if (!first.startsWith("NEXUS/1 HELLO")) return
        val nonce = fields["nonce"] ?: return
        val clientNode = decodeNode(fields["node"] ?: return)
        val key = secretProvider().firstOrNull { key ->
            NexusCrypto.constantTimeEquals(
                NexusCrypto.hmacHex(key, authCanonical("hello", clientNode, nonce)),
                fields["auth"] ?: ""
            )
        } ?: return
        val identityPublicKey = identityContext?.let { NexusIdentity.publicKeyBase64(it) }.orEmpty()
        val effectiveGatewayKey = gatewayPublicKey.ifBlank { if (gateway) identityPublicKey else "" }
        val natCandidate = natCandidateProvider()?.let { "${it.address}|${it.port}|${it.source}" }.orEmpty()
        val natWire = NexusCrypto.encode(natCandidate)
        val domainId = NexusGlobalRoutingTable.domainFor(nodeId)
        val routePrefix = NexusGlobalRoutingTable.domainPrefix(domainId)
        val identityCanonical = "node=$nodeId&nonce=$nonce&gateway=$gateway&relay=$relay&distance=$gatewayDistance&path=${NexusCrypto.encode(gatewayPath.joinToString(","))}&gatewayKey=${NexusCrypto.encode(effectiveGatewayKey)}&identityKey=${NexusCrypto.encode(identityPublicKey)}&nat=$natWire&domain=$domainId&prefix=${NexusCrypto.encode(routePrefix)}"
        val identitySignature = identityContext?.let { NexusCrypto.encodeBytes(NexusIdentity.sign(it, identityCanonical)) }.orEmpty()
        val capabilitiesContext = "gateway=$gateway&relay=$relay&distance=$gatewayDistance&path=${NexusCrypto.encode(gatewayPath.joinToString(","))}&gatewayKey=${NexusCrypto.encode(effectiveGatewayKey)}&identityKey=${NexusCrypto.encode(identityPublicKey)}&nat=$natWire&domain=$domainId&prefix=${NexusCrypto.encode(routePrefix)}"
        val responseAuth = NexusCrypto.hmacHex(key, authCanonical("hello-ok", nodeId, nonce, capabilitiesContext))
        val admission = if (identityPublicKey.isNotBlank()) NexusAdmission.stamp(nodeId, identityPublicKey) else null
        writeAsciiLine(
            output,
            "NEXUS/1 HELLO-OK v=6 node=${NexusCrypto.encode(nodeId)} gateway=$gateway relay=$relay " +
                "distance=$gatewayDistance path=${NexusCrypto.encode(gatewayPath.joinToString(","))} " +
                "gatewayKey=${NexusCrypto.encode(effectiveGatewayKey)} identityKey=${NexusCrypto.encode(identityPublicKey)} " +
                "identitySig=${NexusCrypto.encode(identitySignature)} " +
                "admissionNonce=${admission?.nonce ?: -1} admissionBits=${admission?.difficultyBits ?: 0} admissionDigest=${admission?.digestHex.orEmpty()} " +
                "nat=$natWire domain=$domainId prefix=${NexusCrypto.encode(routePrefix)} " +
                "nonce=$nonce auth=$responseAuth"
        )

        while (true) {
            val line = readAsciiLineRaw(input, MAX_LINE) ?: break
            when {
                line == "PING" -> writeAsciiLine(output, "PONG")
                line.startsWith("PING ") -> writeAsciiLine(output, "PONG ${line.removePrefix("PING ").take(128)}")
                line == "INFO" -> writeAsciiLine(
                    output,
                    "NEXUS/1 NODE ${NexusCrypto.encode(nodeId)} gateway=$gateway relay=$relay distance=$gatewayDistance path=${NexusCrypto.encode(gatewayPath.joinToString(","))}"
                )
                line.startsWith("CONNECT-REQUEST ") -> {
                    val wire = line.removePrefix("CONNECT-REQUEST ").trim()
                    val context = identityContext
                    val request = runCatching { NexusPeerRequests.decodeWire(wire) }.getOrNull()
                    val accepted = context != null && request != null &&
                        request.targetAddress == NexusAddress.overlayIpv6(context) &&
                        request.senderNodeId != nodeId && NexusPeerRequests.verify(request)
                    if (accepted && context != null && request != null) {
                        NexusPeerRequests.save(context, request)
                        writeAsciiLine(output, "CONNECT-REQUEST-OK")
                    } else writeAsciiLine(output, "CONNECT-REQUEST-REJECT")
                }
                line.startsWith("NAME ") -> {
                    val name = runCatching { NexusCrypto.decode(line.removePrefix("NAME ").trim()) }.getOrNull()
                    val record = if (identityContext != null && !name.isNullOrBlank()) NexusNaming.resolve(identityContext, name) else null
                    if (record != null) writeAsciiLine(output, "NAME-OK ${NexusNaming.wire(record)}")
                    else writeAsciiLine(output, "NAME-NOT-FOUND")
                }
                line.startsWith("BANDWIDTH-DOWN ") -> {
                    val bytes = line.removePrefix("BANDWIDTH-DOWN ").toIntOrNull()?.coerceIn(1, MAX_BANDWIDTH_BYTES) ?: break
                    writeAsciiLine(output, "BANDWIDTH-DOWN-OK $bytes")
                    streamTestBytes(output, bytes)
                }
                line.startsWith("BANDWIDTH-UP ") -> {
                    val bytes = line.removePrefix("BANDWIDTH-UP ").toIntOrNull()?.coerceIn(1, MAX_BANDWIDTH_BYTES) ?: break
                    readExactly(input, bytes)
                    writeAsciiLine(output, "BANDWIDTH-UP-OK $bytes")
                }
                line.startsWith("DHT-GET ") -> {
                    val keyName = runCatching { NexusCrypto.decode(line.removePrefix("DHT-GET ").trim()) }.getOrNull()
                    val record = keyName?.let { dhtProvider?.get(it) }
                    if (record != null) writeAsciiLine(output, "DHT-OK ${dhtProvider?.wire(record)}") else writeAsciiLine(output, "DHT-NOT-FOUND")
                }
                line.startsWith("DHT-LIST-PREFIX ") -> {
                    val parts = line.removePrefix("DHT-LIST-PREFIX ").trim().split(' ')
                    val prefix = runCatching { NexusCrypto.decode(parts.firstOrNull().orEmpty()) }.getOrNull()
                    val limit = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(1, 96) ?: 32
                    if (dhtProvider != null && prefix != null && prefix.startsWith("nexus/presence/")) {
                        val matches = dhtProvider.recordsSnapshot()
                            .asSequence()
                            .filter { it.key.startsWith(prefix) }
                            .take(limit)
                            .toList()
                        matches.forEach { writeAsciiLine(output, "DHT-ITEM ${dhtProvider.wire(it)}") }
                        writeAsciiLine(output, "DHT-END ${matches.size}")
                    } else {
                        writeAsciiLine(output, "DHT-END 0")
                    }
                }
                line.startsWith("DHT-PUT ") -> {
                    val wire = line.removePrefix("DHT-PUT ").trim()
                    val record = dhtProvider?.fromWire(wire)
                    val acceptedNaming = record?.let { r ->
                        NexusNaming.fromWire(r.value)?.let { named ->
                            named.name.trim().lowercase() == r.key.trim().lowercase() &&
                                named.nodeId == r.publisher &&
                                dhtProvider.verify(r, named.publicKey)
                        } ?: false
                    } == true
                    val acceptedAddressMailbox = record?.let { NexusPeerRequests.verifyDhtRecord(it) } == true
                    val acceptedAddressBook = record?.let { NexusAddressBook.verifyDhtRecord(it) } == true
                    val acceptedPresence = record?.let { NexusPresence.verifyDhtRecord(it) } == true
                    val accepted = record != null && (acceptedNaming || acceptedAddressMailbox || acceptedAddressBook || acceptedPresence) && dhtProvider.put(record)
                    writeAsciiLine(output, if (accepted) "DHT-PUT-OK" else "DHT-PUT-REJECT")
                }
                line.startsWith("DTN-PUT ") -> {
                    val parts = line.split(' ')
                    val id = runCatching { NexusCrypto.decode(parts.getOrNull(1).orEmpty()) }.getOrDefault("")
                    val origin = runCatching { NexusCrypto.decode(parts.getOrNull(2).orEmpty()) }.getOrDefault("")
                    val destination = runCatching { NexusCrypto.decode(parts.getOrNull(3).orEmpty()) }.getOrDefault("")
                    val priority = parts.getOrNull(4)?.toIntOrNull()?.coerceIn(0, 10) ?: 5
                    val expiresAt = parts.getOrNull(5)?.toLongOrNull() ?: 0L
                    val visited = runCatching { NexusCrypto.decode(parts.getOrNull(6).orEmpty()).split(',').filter { it.isNotBlank() } }.getOrDefault(emptyList())
                    val size = parts.getOrNull(7)?.toIntOrNull() ?: -1
                    val valid = dtnProvider != null && id.matches(Regex("[A-Za-z0-9._:-]{8,96}")) && origin.isNotBlank() && destination.isNotBlank() && expiresAt > System.currentTimeMillis() && size in 1..NexusConfig.DTN_BUNDLE_MAX_BYTES && visited.distinct().size == visited.size && visited.size <= NexusConfig.MAX_HOPS && !visited.contains(nodeId)
                    if (!valid) {
                        writeAsciiLine(output, "DTN-PUT-REJECT")
                    } else {
                        val payload = readExactlyBytes(input, size)
                        val stored = dtnProvider!!.enqueue(destination, payload, ttlMs = (expiresAt - System.currentTimeMillis()).coerceAtLeast(1_000L), priority = priority, origin = origin, visited = visited + nodeId, id = id)
                        writeAsciiLine(output, "DTN-PUT-OK $stored")
                    }
                }
                line == "BYE" -> break
            }
        }
    }

    fun measurePeer(host: String, port: Int, secretProvider: () -> List<String>): Result<CheckResult> =
        runCatching {
            openAuthenticatedSocket(host, port, secretProvider).use { connection ->
                val (_, input, output, _, hello) = connection
                val samples = mutableListOf<Double>()
                var success = 0
                repeat(PING_SAMPLES) {
                    val nonce = NexusCrypto.nonce(12)
                    val started = System.nanoTime()
                    writeAsciiLine(output, "PING $nonce")
                    val pong = runCatching { readAsciiLineTimeout(input) }.getOrNull()
                    if (pong == "PONG $nonce") {
                        success++
                        samples += (System.nanoTime() - started) / 1_000_000.0
                    }
                }
                val loss = (PING_SAMPLES - success) * 100.0 / PING_SAMPLES
                CheckResult(
                    latencyMs = samples.averageOrInfinity(),
                    packetLossPct = loss,
                    hello = hello,
                    pong = if (success > 0) "PONG $success/$PING_SAMPLES" else "PONG absent"
                )
            }
        }

    fun probeCapabilities(host: String, port: Int, secretProvider: () -> List<String>): Capabilities {
        var last: Exception? = null
        for (key in secretProvider().distinct()) {
            try {
                openAuthenticatedSocket(host, port, { listOf(key) }).use { connection ->
                    val (_, input, output, _, hello) = connection
                    val fields = parseFields(hello)
                    val handshakeNonce = fields["nonce"].orEmpty()
                    val samples = mutableListOf<Double>()
                    var successes = 0
                    repeat(PING_SAMPLES) {
                        val pingNonce = NexusCrypto.nonce(12)
                        val started = System.nanoTime()
                        writeAsciiLine(output, "PING $pingNonce")
                        val pong = runCatching { readAsciiLineTimeout(input) }.getOrNull()
                        if (pong == "PONG $pingNonce") {
                            successes++
                            samples += (System.nanoTime() - started) / 1_000_000.0
                        }
                    }
                    val loss = (PING_SAMPLES - successes) * 100.0 / PING_SAMPLES
                    val advertisedDistance = fields["distance"]?.toIntOrNull()?.takeIf { it >= 0 } ?: Int.MAX_VALUE
                    val advertisedNode = decodeNode(fields["node"] ?: "unknown")
                    val advertisedPath = fields["path"]?.let { NexusCrypto.decode(it).split(",").filter { part -> part.isNotBlank() } } ?: emptyList()
                    check(advertisedPath.size <= NexusConfig.MAX_ADVERTISED_PATH && advertisedPath.distinct().size == advertisedPath.size) { "Chemin NXP invalide" }
                    if (advertisedPath.isNotEmpty()) check(advertisedPath.first() == advertisedNode) { "Chemin NXP incohérent" }
                    val identityKey = fields["identityKey"]?.let { NexusCrypto.decode(it) }.orEmpty()
                    val gatewayKey = fields["gatewayKey"]?.let { NexusCrypto.decode(it) }.orEmpty()
                    val advertisedGateway = fields["gateway"] == "true"
                    val advertisedRelay = fields["relay"] == "true"
                    val admission = NexusAdmission.Stamp(
                        advertisedNode, identityKey, fields["admissionNonce"]?.toLongOrNull() ?: -1L,
                        fields["admissionBits"]?.toIntOrNull() ?: 0, fields["admissionDigest"].orEmpty()
                    )
                    val admissionValid = NexusAdmission.verify(admission)
                    val natCandidate = runCatching {
                        val rawNat = NexusCrypto.decode(fields["nat"].orEmpty())
                        val partsNat = rawNat.split('|')
                        if (partsNat.size == 3) NexusNatTraversal.Candidate(partsNat[0], partsNat[1].toInt(), partsNat[2]) else null
                    }.getOrNull()
                    val domainId = fields["domain"].orEmpty()
                    val routePrefix = fields["prefix"]?.let { runCatching { NexusCrypto.decode(it) }.getOrDefault("") }.orEmpty()
                    val identityCanonical = "node=$advertisedNode&nonce=$handshakeNonce&gateway=$advertisedGateway&relay=$advertisedRelay&distance=$advertisedDistance&path=${fields["path"] ?: NexusCrypto.encode("")}&gatewayKey=${NexusCrypto.encode(gatewayKey)}&identityKey=${NexusCrypto.encode(identityKey)}&nat=${fields["nat"].orEmpty()}&domain=$domainId&prefix=${fields["prefix"].orEmpty()}"
                    val authenticatedIdentity = if (identityKey.isNotBlank() && fields["identitySig"].orEmpty().isNotBlank())
                        NexusIdentity.verify(identityKey, identityCanonical, NexusCrypto.decode(fields["identitySig"].orEmpty()))
                    else false
                    return Capabilities(
                        gateway = fields["gateway"] == "true",
                        relay = fields["relay"] == "true",
                        nodeId = advertisedNode,
                        gatewayDistance = advertisedDistance,
                        gatewayPath = advertisedPath,
                        latencyMs = samples.averageOrInfinity(),
                        packetLossPct = loss,
                        bandwidthMbps = 0.0,
                        identityPublicKey = identityKey,
                        gatewayPublicKey = gatewayKey,
                        authenticatedIdentity = authenticatedIdentity && admissionValid,
                        admissionValid = admissionValid,
                        natCandidate = natCandidate,
                        domainId = domainId,
                        routePrefix = routePrefix
                    )
                }
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IllegalStateException("Clé réseau absente")
    }

    fun pushDhtRecord(host: String, port: Int, record: NexusDht.Record, secretProvider: () -> List<String>): Boolean {
        for (key in secretProvider().distinct()) {
            runCatching {
                openAuthenticatedSocket(host, port, { listOf(key) }, 8_000).use { connection ->
                    val (_, input, output, _, _) = connection
                    writeAsciiLine(output, "DHT-PUT ${NexusDht("NXP-DHT-CLIENT").wire(record)}")
                    return@use readAsciiLineTimeout(input) == "DHT-PUT-OK"
                }
            }.getOrNull()?.let { ok -> if (ok) return true }
        }
        return false
    }

    fun forwardDtn(
        host: String,
        port: Int,
        bundle: NexusDtnStore.Bundle,
        localSender: String,
        secretProvider: () -> List<String>
    ): Boolean {
        val payload = runCatching { bundle.payloadFile.readBytes() }.getOrNull() ?: return false
        if (payload.isEmpty() || payload.size > NexusConfig.DTN_BUNDLE_MAX_BYTES) return false
        for (key in secretProvider().distinct()) {
            runCatching {
                openAuthenticatedSocket(host, port, { listOf(key) }, 8_000).use { connection ->
                    val (_, input, output, _, _) = connection
                    val visited = (bundle.visited + localSender).distinct().take(NexusConfig.MAX_HOPS)
                    writeAsciiLine(
                        output,
                        "DTN-PUT ${NexusCrypto.encode(bundle.id)} ${NexusCrypto.encode(bundle.origin)} ${NexusCrypto.encode(bundle.destination)} ${bundle.priority} ${bundle.expiresAt} ${NexusCrypto.encode(visited.joinToString(","))} ${payload.size}"
                    )
                    output.write(payload); output.flush()
                    val response = readAsciiLineTimeout(input) ?: return@use false
                    response.startsWith("DTN-PUT-OK ")
                }
            }.getOrNull()?.let { ok -> if (ok) return true }
        }
        return false
    }

    fun queryDhtName(host: String, port: Int, name: String, secretProvider: () -> List<String>): NexusNaming.Record? {
        for (key in secretProvider().distinct()) {
            runCatching {
                openAuthenticatedSocket(host, port, { listOf(key) }, 8_000).use { connection ->
                    val (_, input, output, _, _) = connection
                    writeAsciiLine(output, "DHT-GET ${NexusCrypto.encode(name.lowercase().removeSuffix("."))}")
                    val response = readAsciiLineTimeout(input) ?: return@use null
                    if (!response.startsWith("DHT-OK ")) return@use null
                    val wire = response.removePrefix("DHT-OK ").trim()
                    val dhtRecord = NexusDht("NXP-DHT-CLIENT").fromWire(wire) ?: return@use null
                    return@use NexusNaming.fromWire(dhtRecord.value)
                }
            }.getOrNull()?.let { return it }
        }
        return null
    }

    /** Sends a signed connection request to a real IP endpoint after authenticating and deriving the peer NEXUS address. */
    fun sendConnectionRequestByEndpoint(
        context: android.content.Context,
        host: String,
        port: Int,
        body: String,
        senderName: String
    ): Boolean {
        require(body.isNotBlank() && body.length <= 2_000) { "Message invalide ou trop long" }
        val secrets = NetworkKeyManager.accepted(context).distinct()
        if (secrets.isEmpty()) return false
        for (key in secrets) {
            val sent = runCatching {
                val capabilities = probeCapabilities(host, port) { listOf(key) }
                check(capabilities.authenticatedIdentity) { "Identité NEXUS distante non authentifiée" }
                val targetAddress = NexusAddress.overlayIpv6FromPublicKey(capabilities.identityPublicKey)
                val request = NexusPeerRequests.create(context, targetAddress, body, senderName)
                check(sendConnectionRequest(context, host, port, request)) { "Demande refusée par le nœud distant" }
                true
            }.getOrDefault(false)
            if (sent) return true
        }
        return false
    }

    /** Explicit real throughput test: transfers actual bytes over the authenticated NXP connection. */
    fun sendConnectionRequest(context: android.content.Context, host: String, port: Int, request: NexusPeerRequests.Request): Boolean {
        for (key in NetworkKeyManager.accepted(context).distinct()) {
            runCatching {
                openAuthenticatedSocket(host, port, { listOf(key) }, 8_000).use { connection ->
                    val (_, input, output, _, _) = connection
                    writeAsciiLine(output, "CONNECT-REQUEST ${NexusCrypto.encode(org.json.JSONObject().apply {
                        put("id", request.id); put("targetAddress", request.targetAddress); put("senderNodeId", request.senderNodeId); put("senderAddress", request.senderAddress);
                        put("senderPublicKey", request.senderPublicKey); put("senderName", request.senderName); put("body", request.body); put("createdAt", request.createdAt); put("expiresAt", request.expiresAt); put("signature", request.signature)
                    }.toString())}")
                    return@use readAsciiLineTimeout(input) == "CONNECT-REQUEST-OK"
                }
            }.getOrNull()?.let { return it }
        }
        return false
    }

    fun queryDhtPrefixes(
        context: android.content.Context,
        host: String,
        port: Int,
        prefixes: Collection<String>,
        limitPerPrefix: Int = 32
    ): List<NexusDht.Record> {
        if (prefixes.isEmpty()) return emptyList()
        for (secret in NetworkKeyManager.accepted(context).distinct()) {
            val result = runCatching {
                openAuthenticatedSocket(host, port, { listOf(secret) }, 8_000).use { connection ->
                    val (_, input, output, _, _) = connection
                    val collected = mutableListOf<NexusDht.Record>()
                    prefixes.distinct().take(96).forEach { prefix ->
                        if (!prefix.startsWith("nexus/presence/")) return@forEach
                        writeAsciiLine(output, "DHT-LIST-PREFIX ${NexusCrypto.encode(prefix)} ${limitPerPrefix.coerceIn(1, 96)}")
                        var guard = 0
                        while (guard++ < 97) {
                            val line = readAsciiLineTimeout(input) ?: break
                            when {
                                line.startsWith("DHT-ITEM ") -> {
                                    val wire = line.removePrefix("DHT-ITEM ").trim()
                                    NexusDht("NXP-DHT-CLIENT").fromWire(wire)?.let { collected += it }
                                }
                                line.startsWith("DHT-END") -> break
                            }
                        }
                    }
                    collected.distinctBy { it.key }
                }
            }.getOrNull()
            if (result != null) return result
        }
        return emptyList()
    }

    fun queryDhtRecord(context: android.content.Context, host: String, port: Int, key: String): NexusDht.Record? {
        for (secret in NetworkKeyManager.accepted(context).distinct()) {
            runCatching {
                openAuthenticatedSocket(host, port, { listOf(secret) }, 8_000).use { connection ->
                    val (_, input, output, _, _) = connection
                    writeAsciiLine(output, "DHT-GET ${NexusCrypto.encode(key.trim())}")
                    val response = readAsciiLineTimeout(input) ?: return@use null
                    if (!response.startsWith("DHT-OK ")) return@use null
                    return@use connectionDhtFromWire(response.removePrefix("DHT-OK ").trim())
                }
            }.getOrNull()?.let { return it }
        }
        return null
    }

    private fun connectionDhtFromWire(wire: String): NexusDht.Record? =
        runCatching { NexusDht("probe").fromWire(wire) }.getOrNull()

    fun queryName(host: String, port: Int, name: String, secretProvider: () -> List<String>): NexusNaming.Record? {
        for (key in secretProvider().distinct()) {
            runCatching {
                openAuthenticatedSocket(host, port, { listOf(key) }, 8_000).use { connection ->
                    val (_, input, output, _, _) = connection
                    writeAsciiLine(output, "NAME ${NexusCrypto.encode(name.lowercase().removeSuffix("."))}")
                    val response = readAsciiLineTimeout(input) ?: return@use null
                    if (!response.startsWith("NAME-OK ")) return@use null
                    return@use NexusNaming.fromWire(response.removePrefix("NAME-OK ").trim())
                }
            }.getOrNull()?.let { return it }
        }
        return null
    }

    fun measureBandwidth(
        host: String,
        port: Int,
        secretProvider: () -> List<String>,
        bytes: Int = 256 * 1024
    ): Result<BandwidthResult> = runCatching {
        require(bytes in 1..MAX_BANDWIDTH_BYTES)
        var last: Exception? = null
        for (key in secretProvider().distinct()) {
            try {
                openAuthenticatedSocket(host, port, { listOf(key) }, 10_000).use { connection ->
                    connection.socket.soTimeout = 15_000
                    val (_, input, output, _, _) = connection
                    writeAsciiLine(output, "BANDWIDTH-DOWN $bytes")
                    val downAck = readAsciiLineTimeout(input)
                    require(downAck == "BANDWIDTH-DOWN-OK $bytes") { "Test download refusé" }
                    val buffer = ByteArray(32 * 1024)
                    var received = 0
                    val startDown = System.nanoTime()
                    while (received < bytes) {
                        val n = input.read(buffer, 0, minOf(buffer.size, bytes - received))
                        if (n < 0) error("Test download interrompu")
                        received += n
                    }
                    val downSeconds = (System.nanoTime() - startDown) / 1_000_000_000.0
                    val downMbps = if (downSeconds > 0) received * 8.0 / downSeconds / 1_000_000.0 else 0.0

                    val uploadPayload = ByteArray(minOf(32 * 1024, bytes)).also(random::nextBytes)
                    writeAsciiLine(output, "BANDWIDTH-UP $bytes")
                    var sent = 0
                    val startUp = System.nanoTime()
                    while (sent < bytes) {
                        val n = minOf(uploadPayload.size, bytes - sent)
                        output.write(uploadPayload, 0, n)
                        sent += n
                    }
                    output.flush()
                    val upAck = readAsciiLineTimeout(input)
                    require(upAck == "BANDWIDTH-UP-OK $bytes") { "Test upload refusé" }
                    val upSeconds = (System.nanoTime() - startUp) / 1_000_000_000.0
                    val upMbps = if (upSeconds > 0) sent * 8.0 / upSeconds / 1_000_000.0 else 0.0
                    val result = BandwidthResult(downMbps, upMbps, bytes)
                    return@use result
                }.also { measured -> return@runCatching measured }
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IllegalStateException("Clé réseau absente")
    }

    private fun openAuthenticatedSocket(
        host: String,
        port: Int,
        secretProvider: () -> List<String>,
        timeoutMs: Int = 4000
    ): AuthenticatedConnection {
        var last: Exception? = null
        for (key in secretProvider().distinct()) {
            try {
                val connectMs = NexusLongHaul.connectTimeoutMs(host, timeoutMs)
                val socket = Socket()
                check(NexusVpnRegistry.protect(socket)) { "Socket NXP non protégé" }
                socket.connect(InetSocketAddress(host, port), connectMs)
                socket.soTimeout = maxOf(connectMs, 2500)
                val input = socket.getInputStream()
                val output = socket.getOutputStream()
                val nonce = NexusCrypto.nonce(24)
                val auth = NexusCrypto.hmacHex(key, authCanonical("hello", "probe", nonce))
                writeAsciiLine(output, "NEXUS/1 HELLO v=4 node=probe nonce=$nonce auth=$auth")
                val hello = readAsciiLineTimeout(input) ?: error("Réponse vide")
                val fields = parseFields(hello)
                check(fields["nonce"] == nonce) { "Nonce NXP invalide" }
                val peerNode = decodeNode(fields["node"] ?: "")
                val gatewayKey = fields["gatewayKey"]?.let { NexusCrypto.decode(it) }.orEmpty()
                val identityKey = fields["identityKey"]?.let { NexusCrypto.decode(it) }.orEmpty()
                val capabilitiesContext = "gateway=${fields["gateway"] == "true"}&relay=${fields["relay"] == "true"}" +
                    "&distance=${fields["distance"] ?: Int.MAX_VALUE}&path=${fields["path"] ?: NexusCrypto.encode("")}" +
                    "&gatewayKey=${NexusCrypto.encode(gatewayKey)}&identityKey=${NexusCrypto.encode(identityKey)}&nat=${fields["nat"].orEmpty()}&domain=${fields["domain"].orEmpty()}&prefix=${fields["prefix"].orEmpty()}"
                check(
                    NexusCrypto.constantTimeEquals(
                        NexusCrypto.hmacHex(key, authCanonical("hello-ok", peerNode, nonce, capabilitiesContext)),
                        fields["auth"] ?: ""
                    )
                ) { "Authentification NXP refusée" }
                socket.soTimeout = NexusLongHaul.readTimeoutMs(host, PING_TIMEOUT_MS)
                return AuthenticatedConnection(socket, input, output, key, hello)
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IllegalStateException("Connexion NXP impossible")
    }

    private fun streamTestBytes(output: OutputStream, bytes: Int) {
        val chunk = ByteArray(BANDWIDTH_CHUNK).also(random::nextBytes)
        var sent = 0
        while (sent < bytes) {
            val n = minOf(chunk.size, bytes - sent)
            output.write(chunk, 0, n)
            sent += n
        }
        output.flush()
    }

    private fun writeAsciiLine(output: OutputStream, line: String) {
        output.write(line.toByteArray(Charsets.US_ASCII))
        output.write('\n'.code)
        output.flush()
    }

    private fun readAsciiLineTimeout(input: InputStream): String? {
        return try {
            readAsciiLineRaw(input, MAX_LINE)
        } catch (_: java.net.SocketTimeoutException) {
            null
        }
    }

    private fun readAsciiLineRaw(input: InputStream, maxBytes: Int): String? {
        val buffer = ByteArray(maxBytes)
        var count = 0
        while (count < maxBytes) {
            val b = input.read()
            if (b < 0) return if (count == 0) null else String(buffer, 0, count, Charsets.US_ASCII)
            if (b == '\n'.code) return String(buffer, 0, count, Charsets.US_ASCII)
            if (b != '\r'.code) buffer[count++] = b.toByte()
        }
        error("Ligne NXP trop longue")
    }

    private fun readExactly(input: InputStream, length: Int) {
        readExactlyBytes(input, length)
    }

    private fun readExactlyBytes(input: InputStream, length: Int): ByteArray {
        val buffer = ByteArray(length)
        var read = 0
        while (read < length) {
            val n = input.read(buffer, read, length - read)
            if (n < 0) error("Flux NXP interrompu")
            read += n
        }
        return buffer
    }

    private fun parseFields(line: String): Map<String, String> =
        line.split(' ').drop(2).mapNotNull { token ->
            val i = token.indexOf('=')
            if (i <= 0) null else token.substring(0, i) to token.substring(i + 1)
        }.toMap()

    private fun decodeNode(value: String): String = runCatching { NexusCrypto.decode(value) }.getOrDefault(value)

    private fun authCanonical(kind: String, nodeId: String, nonce: String, context: String = ""): String =
        "v=4&kind=$kind&node=$nodeId&nonce=$nonce" + context.takeIf { it.isNotEmpty() }?.let { "&$it" }.orEmpty()

    private fun List<Double>.averageOrInfinity(): Double = if (isEmpty()) Double.POSITIVE_INFINITY else average()

    private data class AuthenticatedConnection(
        val socket: Socket,
        val input: InputStream,
        val output: OutputStream,
        val key: String,
        val hello: String
    ) : AutoCloseable {
        override fun close() { runCatching { socket.close() } }
    }
}
