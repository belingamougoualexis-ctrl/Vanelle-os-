package com.nexus.network

import android.content.Context
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

/** Authenticated service plane for database, messaging and allowlisted distributed compute. */
object NexusServiceProtocol {
    private const val MAX_LINE = 256 * 1024

    data class Message(val id: String, val sender: String, val recipient: String, val body: String, val createdAt: Long)

    fun client(context: Context, host: String, request: String, port: Int = NexusConfig.SERVICE_PORT): Result<String> = runCatching {
        val socket = Socket()
        check(NexusVpnRegistry.protect(socket))
        socket.connect(InetSocketAddress(host, port), 8_000)
        socket.use { s ->
            s.soTimeout = 15_000
            val input = BufferedInputStream(s.getInputStream())
            val output = BufferedOutputStream(s.getOutputStream())
            val nonce = NexusCrypto.nonce()
            val node = NexusIdentity.nodeId(context)
            val auth = NexusCrypto.hmacHex(NexusIdentity.networkKey(context), "v=1|type=service|node=$node|nonce=$nonce")
            line(output, "NEXUS-SERVICE/1 HELLO v=1 node=${NexusCrypto.encode(node)} nonce=$nonce auth=$auth")
            val ok = readLine(input) ?: error("Service distant injoignable")
            check(ok.startsWith("NEXUS-SERVICE/1 OK")) { "Service distant refusé" }
            val session = NexusServiceCipher.derive(NexusIdentity.networkKey(context), nonce)
            line(output, "DATA ${NexusServiceCipher.encrypt(session, request)}")
            val data = readLine(input) ?: error("Réponse service absente")
            check(data.startsWith("DATA ")) { "Réponse service invalide" }
            NexusServiceCipher.decrypt(session, data.removePrefix("DATA "))
        }
    }

    fun putRemote(context: Context, host: String, record: NexusDatabase.Record, port: Int = NexusConfig.SERVICE_PORT): Result<String> = client(context, host, "DB_PUT record=${NexusCrypto.encode(org.json.JSONObject().apply { put("database",record.database);put("key",record.key);put("value",record.value);put("version",record.version);put("nodeId",record.nodeId);put("updatedAt",record.updatedAt);put("hash",record.hash) }.toString())}", port)

    fun getRemote(context: Context, host: String, database: String, key: String, port: Int = NexusConfig.SERVICE_PORT): Result<NexusDatabase.Record?> = runCatching {
        val response=client(context,host,"DB_GET db=${NexusCrypto.encode(database)} key=${NexusCrypto.encode(key)}", port).getOrThrow()
        if(response=="DB-MISS") return@runCatching null
        check(response.startsWith("DB-OK"))
        val f=response.split(' ').drop(1).mapNotNull{t->val i=t.indexOf('=');if(i>0)t.substring(0,i) to t.substring(i+1) else null}.toMap()
        NexusDatabase.Record(NexusCrypto.decode(f["db"]!!),NexusCrypto.decode(f["key"]!!),NexusCrypto.decode(f["value"]!!),f["version"]!!.toLong(),NexusCrypto.decode(f["node"]!!),f["updated"]!!.toLong(),f["hash"]!!)
    }

    fun listRemote(context: Context, host: String, database: String, port: Int = NexusConfig.SERVICE_PORT): Result<List<NexusDatabase.Record>> = runCatching {
        val response=client(context,host,"DB_LIST db=${NexusCrypto.encode(database)}", port).getOrThrow(); check(response.startsWith("DB-LIST"))
        val token=response.split(' ').firstOrNull{it.startsWith("data=")} ?: return@runCatching emptyList()
        val arr=org.json.JSONArray(NexusCrypto.decode(token.removePrefix("data=")))
        buildList { for(i in 0 until arr.length()){ val j=org.json.JSONObject(arr.getString(i)); add(NexusDatabase.Record(j.getString("database"),j.getString("key"),j.getString("value"),j.getLong("version"),j.getString("nodeId"),j.getLong("updatedAt"),j.getString("hash"))) } }
    }

    fun sendMessage(context: Context, host: String, recipient: String, body: String, port: Int = NexusConfig.SERVICE_PORT, queueOnFailure: Boolean = true): Result<String> {
        require(body.isNotBlank() && body.length <= 16 * 1024)
        val id = NexusCrypto.sha256Hex("${NexusIdentity.nodeId(context)}|$recipient|$body|${System.currentTimeMillis()}" ).take(40)
        val request = "MSG_SEND id=$id sender=${NexusCrypto.encode(NexusIdentity.nodeId(context))} recipient=${NexusCrypto.encode(recipient)} ts=${System.currentTimeMillis()} body=${NexusCrypto.encode(body)}"
        val direct = client(context, host, request, port)
        if (direct.isSuccess || !queueOnFailure) return direct
        val queued = NexusMessageOutbox(context).enqueue(recipient, body, id)
        return Result.success("MSG-QUEUED id=$queued")
    }

    fun pullMessages(context: Context, host: String, port: Int = NexusConfig.SERVICE_PORT, recipient: String = NexusIdentity.nodeId(context)): Result<List<Message>> = runCatching {
        val response=client(context,host,"MSG_PULL recipient=${NexusCrypto.encode(recipient)}", port).getOrThrow()
        if(!response.startsWith("MESSAGES")) return@runCatching emptyList()
        val token=response.split(' ').firstOrNull{it.startsWith("data=")} ?: return@runCatching emptyList()
        val arr=org.json.JSONArray(NexusCrypto.decode(token.removePrefix("data=")))
        buildList { for(i in 0 until arr.length()){ val j=org.json.JSONObject(arr.getString(i)); add(Message(j.getString("id"),j.getString("sender"),j.getString("recipient"),j.getString("body"),j.getLong("createdAt"))) } }
    }

    fun compute(context: Context, host: String, task: NexusCompute.Task, port: Int = NexusConfig.SERVICE_PORT): Result<NexusCompute.Result> = runCatching {
        val request = "COMPUTE id=${NexusCrypto.encode(task.id)} op=${NexusCrypto.encode(task.operation)} input=${NexusCrypto.encodeBytes(task.input)}"
        val response = client(context, host, request, port).getOrThrow()
        parseCompute(response)
    }

    private fun parseCompute(response: String): NexusCompute.Result {
        val fields = response.split(' ').drop(1).mapNotNull { token ->
            val i = token.indexOf('='); if (i > 0) token.substring(0, i) to token.substring(i + 1) else null
        }.toMap()
        check(response.startsWith("COMPUTE-OK")) { NexusCrypto.decode(fields["error"] ?: NexusCrypto.encode("Calcul refusé")) }
        return NexusCompute.Result(
            taskId = NexusCrypto.decode(fields["id"] ?: error("id")),
            operation = NexusCrypto.decode(fields["op"] ?: error("op")),
            output = NexusCrypto.decodeBytes(fields["output"] ?: error("output")),
            provider = NexusCrypto.decode(fields["provider"] ?: error("provider"))
        )
    }

    fun server(context: Context, socket: Socket, requestHandler: (String, String) -> String): Boolean {
        socket.use { s ->
            s.soTimeout = 15_000
            val input = BufferedInputStream(s.getInputStream())
            val output = BufferedOutputStream(s.getOutputStream())
            val hello = readLine(input) ?: return false
            if (!hello.startsWith("NEXUS-SERVICE/1 HELLO")) return false
            val fields = fields(hello)
            val nonce = fields["nonce"] ?: return false
            val peer = NexusCrypto.decode(fields["node"] ?: return false)
            val auth = fields["auth"] ?: return false
            val validKey = NetworkKeyManager.accepted(context).firstOrNull { key ->
                NexusCrypto.constantTimeEquals(auth, NexusCrypto.hmacHex(key, "v=1|type=service|node=$peer|nonce=$nonce"))
            } ?: return false
            if (!NexusTrustStore.isAllowed(context, peer)) return false
            line(output, "NEXUS-SERVICE/1 OK v=1 node=${NexusCrypto.encode(NexusIdentity.nodeId(context))} nonce=$nonce")
            val session = NexusServiceCipher.derive(validKey, nonce)
            val data = readLine(input) ?: return false
            if (!data.startsWith("DATA ")) return false
            val request = NexusServiceCipher.decrypt(session, data.removePrefix("DATA "))
            line(output, "DATA ${NexusServiceCipher.encrypt(session, requestHandler(request, peer))}")
            return true
        }
    }


    private fun fields(line: String): Map<String, String> = line.split(' ').drop(2).mapNotNull { token ->
        val i = token.indexOf('='); if (i > 0) token.substring(0, i) to token.substring(i + 1) else null
    }.toMap()

    private fun line(out: BufferedOutputStream, value: String) { out.write(value.toByteArray(Charsets.US_ASCII)); out.write('\n'.code); out.flush() }
    private fun readLine(input: BufferedInputStream): String? {
        val b = ByteArray(MAX_LINE); var n = 0
        while (n < b.size) { val x = input.read(); if (x < 0) return if (n == 0) null else String(b, 0, n, Charsets.US_ASCII); if (x == '\n'.code) return String(b, 0, n, Charsets.US_ASCII); if (x != '\r'.code) b[n++] = x.toByte() }
        error("Requête service trop longue")
    }
}

private object NexusServiceCipher {
    private const val IV_BYTES = 12
    private const val TAG_BITS = 128
    private val random = java.security.SecureRandom()

    fun derive(networkKey: String, sessionNonce: String): javax.crypto.spec.SecretKeySpec {
        val digest=java.security.MessageDigest.getInstance("SHA-256").digest("nexus-service-v2|$sessionNonce|$networkKey".toByteArray(Charsets.UTF_8))
        return javax.crypto.spec.SecretKeySpec(digest,"AES")
    }

    fun encrypt(key: javax.crypto.spec.SecretKeySpec, plaintext: String): String {
        val iv=ByteArray(IV_BYTES).also(random::nextBytes)
        val cipher=javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE,key,javax.crypto.spec.GCMParameterSpec(TAG_BITS,iv))
        val ciphertext=cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        val frame=ByteArray(IV_BYTES+ciphertext.size)
        System.arraycopy(iv,0,frame,0,IV_BYTES);System.arraycopy(ciphertext,0,frame,IV_BYTES,ciphertext.size)
        return NexusCrypto.encodeBytes(frame)
    }

    fun decrypt(key: javax.crypto.spec.SecretKeySpec, encoded: String): String {
        val frame=NexusCrypto.decodeBytes(encoded);require(frame.size>IV_BYTES+TAG_BITS/8)
        val iv=frame.copyOfRange(0,IV_BYTES);val ciphertext=frame.copyOfRange(IV_BYTES,frame.size)
        val cipher=javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(javax.crypto.Cipher.DECRYPT_MODE,key,javax.crypto.spec.GCMParameterSpec(TAG_BITS,iv))
        return String(cipher.doFinal(ciphertext),Charsets.UTF_8)
    }
}

class NexusServiceServer(private val context: Context, private val port: Int = NexusConfig.SERVICE_PORT) {
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "nexus-service-${System.nanoTime()}").apply { isDaemon = true } }
    @Volatile private var running = false
    private var server: ServerSocket? = null

    fun start() {
        if (running) return
        running = true
        pool.execute {
            runCatching {
                ServerSocket().use { s ->
                    s.reuseAddress = true
                    s.bind(InetSocketAddress("0.0.0.0", port))
                    server = s
                    while (running) {
                        val socket = runCatching { s.accept() }.getOrNull() ?: break
                        if (running) pool.execute { handle(socket) } else runCatching { socket.close() }
                    }
                }
            }
        }
    }

    fun stop() {
        running = false
        runCatching { server?.close() }
        server = null
        pool.shutdownNow()
    }

    private fun handle(socket: Socket) {
        NexusServiceProtocol.server(context, socket) { request, peer ->
            runCatching { dispatch(request, peer) }.getOrElse { e -> "ERR error=${NexusCrypto.encode(e.message ?: "service error")}" }
        }
    }

    private fun dispatch(request: String, authenticatedPeer: String): String {
        val fields = request.split(' ').drop(1).mapNotNull { token ->
            val i = token.indexOf('='); if (i > 0) token.substring(0, i) to token.substring(i + 1) else null
        }.toMap()
        return when {
            request.startsWith("DB_GET ") -> {
                val db = NexusCrypto.decode(fields["db"] ?: error("db")); val key = NexusCrypto.decode(fields["key"] ?: error("key"))
                val r = NexusDatabase.get(context, db, key) ?: return "DB-MISS"
                "DB-OK db=${NexusCrypto.encode(r.database)} key=${NexusCrypto.encode(r.key)} value=${NexusCrypto.encode(r.value)} version=${r.version} node=${NexusCrypto.encode(r.nodeId)} updated=${r.updatedAt} hash=${r.hash}"
            }
            request.startsWith("DB_PUT ") -> {
                val encoded = fields["record"] ?: error("record")
                val r = decodeRecord(NexusCrypto.decode(encoded)); require(r.nodeId == authenticatedPeer) { "Identité DB invalide" }; val merged = NexusDatabase.merge(context, r)
                if (merged) "DB-WRITTEN hash=${r.hash}" else "DB-UNCHANGED hash=${r.hash}"
            }
            request.startsWith("DB_LIST ") -> {
                val db = NexusCrypto.decode(fields["db"] ?: error("db")); val records = NexusDatabase.list(context, db, 64)
                "DB-LIST count=${records.size} data=${NexusCrypto.encode(org.json.JSONArray(records.map { encodeRecord(it) }).toString())}"
            }
            request.startsWith("MSG_SEND ") -> {
                val id=fields["id"] ?: error("id"); val sender=NexusCrypto.decode(fields["sender"] ?: error("sender")); require(sender == authenticatedPeer) { "Identité message invalide" }; val recipient=NexusCrypto.decode(fields["recipient"] ?: error("recipient")); val body=NexusCrypto.decode(fields["body"] ?: error("body")); val ts=fields["ts"]?.toLongOrNull() ?: System.currentTimeMillis()
                val value=org.json.JSONObject().apply { put("id",id); put("sender",sender); put("recipient",recipient); put("body",body); put("createdAt",ts) }.toString()
                val stored=NexusDatabase.put(context,"messages","$recipient/$id",value)
                "MSG-OK id=${NexusCrypto.encode(id)} hash=${stored.hash}"
            }
            request.startsWith("MSG_PULL ") -> {
                val recipient=NexusCrypto.decode(fields["recipient"] ?: error("recipient")); val items=NexusDatabase.list(context,"messages",256).filter { it.key.startsWith("$recipient/") }
                "MESSAGES ${items.size} data=${NexusCrypto.encode(org.json.JSONArray(items.map { it.value }).toString())}"
            }
            request.startsWith("COMPUTE ") -> {
                val task=NexusCompute.Task(NexusCrypto.decode(fields["id"] ?: error("id")), NexusCrypto.decode(fields["op"] ?: error("op")), NexusCrypto.decodeBytes(fields["input"] ?: error("input")))
                val result=NexusCompute.execute(context, task)
                "COMPUTE-OK id=${NexusCrypto.encode(result.taskId)} op=${NexusCrypto.encode(result.operation)} provider=${NexusCrypto.encode(result.provider)} output=${NexusCrypto.encodeBytes(result.output)}"
            }
            request == "PING" -> "PONG"
            else -> error("Commande service inconnue")
        }
    }

    private fun encodeRecord(r: NexusDatabase.Record): String = org.json.JSONObject().apply {
        put("database",r.database);put("key",r.key);put("value",r.value);put("version",r.version);put("nodeId",r.nodeId);put("updatedAt",r.updatedAt);put("hash",r.hash)
    }.toString()
    private fun decodeRecord(raw: String): NexusDatabase.Record { val j=org.json.JSONObject(raw); return NexusDatabase.Record(j.getString("database"),j.getString("key"),j.getString("value"),j.getLong("version"),j.getString("nodeId"),j.getLong("updatedAt"),j.getString("hash")) }



}
