package com.nexus.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkAddress
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Persistent route-discovery/recovery engine.
 *
 * It never treats "no route right now" as a terminal state. It keeps looking
 * through authenticated NEXUS discovery, cached endpoints, configured bootstrap
 * peers, Wi-Fi/P2P discovery and small private IPv4 subnet probes. It only uses
 * networks Android exposes; it cannot manufacture a physical path that does not
 * exist.
 */
class NexusRouteRecovery(
    private val context: Context,
    private val discovery: NsdController,
    private val router: MeshRouter,
    private val bootstrap: NexusBootstrapManager
) {
    private val transportManager = NexusTransportManager(context)
    private val subnetLastScanAt = ConcurrentHashMap<String, Long>()
    @Volatile private var searchPool: ScheduledExecutorService? = null
    @Volatile private var probePool: ExecutorService? = null
    @Volatile private var started = false
    @Volatile private var lastSearchAt = 0L

    @Synchronized
    fun start() {
        if (started) return
        started = true
        searchPool = Executors.newSingleThreadScheduledExecutor { r ->
            Thread(r, "nexus-route-recovery").apply { isDaemon = true }
        }
        probePool = Executors.newFixedThreadPool(16) { r ->
            Thread(r, "nexus-local-path-probe").apply { isDaemon = true }
        }
        restoreCachedPeers()
        runSearch()
        searchPool?.scheduleWithFixedDelay({ runSearch() }, 5, NexusConfig.ROUTE_RECOVERY_INTERVAL_SECONDS, TimeUnit.SECONDS)
    }

    fun requestSearch() {
        if (!started) start()
        searchPool?.execute { runSearch(force = true) }
    }

    /** Wait briefly while the recovery engine actively searches for a route. */
    fun searchAndWait(hasRoute: () -> Boolean, timeoutMs: Long = NexusConfig.ROUTE_RECOVERY_WAIT_MS): Boolean {
        if (hasRoute()) return true
        requestSearch()
        val deadline = System.currentTimeMillis() + timeoutMs.coerceAtLeast(1_000L)
        while (System.currentTimeMillis() < deadline) {
            if (hasRoute()) return true
            val remaining = (deadline - System.currentTimeMillis()).coerceAtLeast(20L)
            // React quickly when discovery finds a route; keep the polling interval
            // short so a recovered path is usable on the next check without adding
            // a full second of avoidable latency.
            Thread.sleep(minOf(remaining, 100L))
            if (hasRoute()) return true
        }
        return hasRoute()
    }

    private fun runSearch(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && now - lastSearchAt < NexusConfig.ROUTE_RECOVERY_MIN_GAP_MS) return
        lastSearchAt = now

        // 1) Rehydrate endpoints that worked recently.
        restoreCachedPeers()

        // 2) Keep global discovery alive; failures here must never stop the loop.
        runCatching { bootstrap.refresh() }
        runCatching { discovery.startDiscovery() }
        runCatching { discovery.refreshP2pEndpoints() }
        runCatching { discovery.probeAll() }

        // 3) When the overlay has no usable gateway path, search local IP networks
        // that Android exposes even if they are not marked "validated". This is
        // useful behind captive portals, split routes and temporary Internet loss.
        val noOverlayRoute = router.outboundGatewayDistance() == Int.MAX_VALUE
        if (noOverlayRoute || discovery.peersSnapshot().isEmpty()) {
            runCatching { scanSmallPrivateSubnets() }
        }

        // 4) Remember any endpoint learned during this pass so a future loss of
        // NSD/default routing does not erase the last known path.
        runCatching { NexusPeerCache.save(context, discovery.peersSnapshot()) }
    }

    private fun restoreCachedPeers() {
        NexusPeerCache.load(context).forEach { entry ->
            discovery.addRemotePeer(entry.host, entry.port, entry.nodeId)
        }
    }

    private fun scanSmallPrivateSubnets() {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return
        transportManager.transports()
            .filter { transport ->
                transport.labels.any { label -> label.startsWith("Wi‑Fi") || label.startsWith("Ethernet") || label.startsWith("USB") || label.startsWith("Bluetooth") || label.startsWith("LoWPAN") || label.startsWith("Thread") }
            }
            .forEach { transport ->
            val links = cm.getLinkProperties(transport.network) ?: return@forEach
            links.linkAddresses.asSequence()
                .mapNotNull { it.takeIf { address -> address.address is Inet4Address } }
                .forEach { link -> probeIpv4Subnet(transport.network, link) }
        }
    }

    private fun probeIpv4Subnet(network: android.net.Network, link: LinkAddress) {
        val address = link.address as? Inet4Address ?: return
        val scanKey = "${network.networkHandle}/${link.prefixLength}/${address.hostAddress}"
        val now = System.currentTimeMillis()
        val last = subnetLastScanAt[scanKey] ?: 0L
        if (now - last < 20_000L) return
        subnetLastScanAt[scanKey] = now
        val raw = address.address
        val prefix = link.prefixLength.coerceIn(24, 30)
        val mask = (-1 shl (32 - prefix))
        val localInt = ((raw[0].toInt() and 255) shl 24) or
            ((raw[1].toInt() and 255) shl 16) or
            ((raw[2].toInt() and 255) shl 8) or
            (raw[3].toInt() and 255)
        val networkInt = localInt and mask
        val hostCount = (1 shl (32 - prefix)) - 2
        if (hostCount <= 0 || hostCount > NexusConfig.ROUTE_RECOVERY_MAX_LOCAL_HOSTS) return

        for (hostOffset in 1..hostCount) {
            val candidateInt = networkInt + hostOffset
            if (candidateInt == localInt) continue
            val host = InetAddress.getByAddress(byteArrayOf(
                (candidateInt ushr 24).toByte(),
                (candidateInt ushr 16).toByte(),
                (candidateInt ushr 8).toByte(),
                candidateInt.toByte()
            )).hostAddress ?: continue
            probePool?.execute {
                runCatching {
                    transportManager.openTcp(network, host, NexusConfig.NODE_PORT, NexusConfig.ROUTE_RECOVERY_PROBE_TIMEOUT_MS).use { }
                    discovery.addRemotePeer(host, NexusConfig.NODE_PORT, "LAN-$host")
                }
            }
        }
    }

    @Synchronized
    fun stop() {
        if (!started) return
        started = false
        searchPool?.shutdownNow()
        probePool?.shutdownNow()
        searchPool = null
        probePool = null
    }
}
