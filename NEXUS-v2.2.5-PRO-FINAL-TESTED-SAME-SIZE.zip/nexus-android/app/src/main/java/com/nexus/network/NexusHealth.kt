package com.nexus.network

import android.content.Context
import android.os.StatFs

/** Explainable local diagnostics. Every check is derived from actual local state. */
object NexusHealth {
    data class Check(val name: String, val ok: Boolean, val detail: String)
    data class Report(val checks: List<Check>) {
        val healthyCount: Int get() = checks.count { it.ok }
        val criticalCount: Int get() = checks.count { !it.ok }
        fun text(): String = checks.joinToString("\n") { "${if (it.ok) "OK" else "!!"} ${it.name} — ${it.detail}" }
    }

    fun run(context: Context): Report {
        val checks = mutableListOf<Check>()
        val network = NetworkInspector.snapshot(context)
        checks += Check("Connectivité Android", network.connected, if (network.connected) "réseau actif" else "aucun réseau actif")
        checks += Check("Validation Internet", !network.connected || network.validated, if (network.validated) "validée" else "non validée / non disponible")
        val quota = NexusSettings.storageQuotaBytes(context)
        val used = NexusContentStore.usedBytes(context)
        checks += Check("Quota stockage", used <= quota, "${used / (1024 * 1024)} MiB utilisés / ${quota / (1024 * 1024)} MiB autorisés")
        val pinnedBad = NexusContentStore.allPinned(context).count { !NexusContentStore.verifyComplete(context, it.hash) }
        checks += Check("Intégrité contenus épinglés", pinnedBad == 0, if (pinnedBad == 0) "tous vérifiés" else "$pinnedBad contenu(s) à réparer")
        val dbs = NexusDatabase.databases(context)
        val dbBad = dbs.sumOf { db -> NexusDatabase.list(context, db, 1024).count { record -> NexusDatabase.get(context, db, record.key)?.hash != record.hash } }
        checks += Check("Intégrité base locale", dbBad == 0, if (dbBad == 0) "enregistrements cohérents" else "$dbBad enregistrement(s) incohérent(s)")
        val cache = NexusEdgeCache.stats(context)
        checks += Check("Cache edge", cache.bytes <= cache.quotaBytes, "${cache.entries} entrée(s), ${cache.bytes / (1024 * 1024)} MiB")
        checks += Check("Identité NEXUS", NexusIdentity.nodeId(context).startsWith("NX-"), "nœud ${NexusIdentity.nodeId(context)}")
        val battery = batteryPercent(context)
        val minBattery = NexusSettings.minRelayBattery(context)
        checks += Check(
            "Batterie",
            battery < 0 || battery >= minBattery,
            if (battery < 0) "niveau non disponible" else "$battery % (seuil relais $minBattery %)"
        )
        val netKey = runCatching { NexusIdentity.networkKey(context) }.getOrNull()
        checks += Check("Clé réseau", !netKey.isNullOrBlank() && netKey.length >= 8, if (netKey.isNullOrBlank()) "absente" else "empreinte ${NetworkKeyManager.fingerprint(netKey)}")
        if (NexusSettings.storageRelayEnabled(context) && used > quota) {
            checks += Check("Politique stockage", false, "stockage local au-dessus du quota configuré")
        }
        return Report(checks)
    }

    fun diskFreeMb(context: Context): Long = runCatching { StatFs(context.filesDir.absolutePath).availableBytes / 1024 / 1024 }.getOrDefault(0L)

    private fun batteryPercent(context: Context): Int = runCatching {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
        bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
    }.getOrDefault(-1)
}
