package com.nexus.network

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Address-based connection requests. Requests are signed, persisted, and can travel through DHT mailboxes. */
object NexusPeerRequests {
    private const val ROOT = "nexus-peer-requests"
    private const val MAX_BODY = 2_000
    private const val MAX_INDEX_ENTRIES = 12
    private const val TTL_MS = 7L * 24 * 60 * 60 * 1000
    private const val PREFIX = "nexus/inbox/"

    data class Request(
        val id: String,
        val targetAddress: String,
        val senderNodeId: String,
        val senderAddress: String,
        val senderPublicKey: String,
        val senderName: String,
        val body: String,
        val createdAt: Long,
        val expiresAt: Long,
        val signature: String
    )

    data class Result(val request: Request, val publishedTo: Int)

    fun create(context: Context, targetAddress: String, body: String, senderName: String): Request {
        require(NexusAddress.isValidOverlay(targetAddress)) { "Adresse NEXUS IPv6 invalide" }
        require(body.isNotBlank() && body.length <= MAX_BODY) { "Message invalide ou trop long" }
        val normalized = canonicalAddress(targetAddress)
        val created = System.currentTimeMillis()
        val expires = created + TTL_MS
        val id = UUID.randomUUID().toString().replace("-", "").take(32)
        val node = NexusIdentity.nodeId(context)
        val pub = NexusIdentity.publicKeyBase64(context)
        val canonical = canonical(id, normalized, node, NexusAddress.overlayIpv6(context), pub, senderName, body, created, expires)
        return Request(
            id = id,
            targetAddress = normalized,
            senderNodeId = node,
            senderAddress = NexusAddress.overlayIpv6(context),
            senderPublicKey = pub,
            senderName = senderName.trim().take(64),
            body = body,
            createdAt = created,
            expiresAt = expires,
            signature = NexusCrypto.encodeBytes(NexusIdentity.sign(context, canonical))
        ).also { save(context, it) }
    }

    fun save(context: Context, request: Request) {
        require(verify(request))
        val dir = File(context.filesDir, ROOT).apply { mkdirs() }
        File(dir, "req-${request.id}.json").writeText(toJson(request).toString(), Charsets.UTF_8)
    }

    fun cleanup(context: Context) {
        val now = System.currentTimeMillis()
        files(context).forEach { file ->
            val request = read(file)
            if (request == null || request.expiresAt <= now) runCatching { file.delete() }
        }
    }

    fun localInbox(context: Context): List<Request> = files(context).mapNotNull { read(it) }
        .filter { it.expiresAt > System.currentTimeMillis() }
        .sortedByDescending { it.createdAt }

    fun accepted(context: Context): List<Request> = localInbox(context).filter { isAccepted(context, it.id) }

    fun pending(context: Context): List<Request> = localInbox(context).filter { !isAccepted(context, it.id) && !isDeclined(context, it.id) }

    fun decline(context: Context, requestId: String) = flag(context, "declined", requestId)

    fun accept(context: Context, requestId: String): Request? {
        val request = localInbox(context).firstOrNull { it.id == requestId } ?: return null
        flag(context, "accepted", requestId)
        saveAcceptedMessage(context, request)
        return request
    }

    /** Push the signed inbox index through real reachable NEXUS peers. */
    fun publish(context: Context, request: Request, peers: Collection<NsdController.Peer>): Result {
        val target = canonicalAddress(request.targetAddress)
        var published = 0
        val resolved = NexusAddressBook.resolve(context, target, peers)
        resolved?.endpoints.orEmpty().forEach { endpoint ->
            val host = endpoint.substringAfter('[').substringBefore(']')
            val port = endpoint.substringAfter("]:").toIntOrNull() ?: NexusConfig.NODE_PORT
            if (NxpProtocol.sendConnectionRequest(context, host, port, request)) published++
        }
        val existing = mutableListOf<Request>()
        // Read one current index through reachable peers, then append the request.
        peers.asSequence().filter { it.host.isNotBlank() && NexusTrustStore.isAllowed(context, it.name) }.take(8).forEach { peer ->
            val record = NxpProtocol.queryDhtRecord(context, peer.host, peer.port, inboxKey(target)) ?: return@forEach
            existing += decodeIndex(record.value).filter { it.id != request.id }
            if (existing.size >= MAX_INDEX_ENTRIES) return@forEach
        }
        existing.add(request)
        val compact = existing.distinctBy { it.id }.sortedByDescending { it.createdAt }.take(MAX_INDEX_ENTRIES)
        val record = buildIndexRecord(context, target, compact)
        var pushed = 0
        peers.asSequence().filter { it.host.isNotBlank() && NexusTrustStore.isAllowed(context, it.name) }
            .sortedByDescending { NexusTrustStore.reputation(context, it.name) }
            .take(8).forEach { peer ->
                if (NxpProtocol.pushDhtRecord(peer.host, peer.port, record, { NetworkKeyManager.accepted(context) })) pushed++
            }
        return Result(request, published + pushed)
    }

    /** Pulls and verifies address-based requests from real DHT rendezvous peers. */
    fun pull(context: Context, peers: Collection<NsdController.Peer>): List<Request> {
        val own = NexusAddress.overlayIpv6(context)
        val imported = linkedMapOf<String, Request>()
        peers.asSequence().filter { it.host.isNotBlank() && NexusTrustStore.isAllowed(context, it.name) }.take(12).forEach { peer ->
            val record = NxpProtocol.queryDhtRecord(context, peer.host, peer.port, inboxKey(own)) ?: return@forEach
            decodeIndex(record.value).filter { it.targetAddress == own && verify(it) }.forEach { request ->
                imported[request.id] = request
                save(context, request)
            }
        }
        return imported.values.sortedByDescending { it.createdAt }
    }

    fun dhtRecordKeyForAddress(address: String): String = inboxKey(canonicalAddress(address))

    /** Verifier used by the DHT server before accepting inbox records. */
    fun verifyDhtRecord(record: NexusDht.Record): Boolean {
        if (!record.key.startsWith(PREFIX)) return false
        val target = record.key.removePrefix(PREFIX)
        if (!NexusAddress.isValidOverlay(target)) return false
        val records = decodeIndex(record.value)
        if (records.isEmpty() || records.size > MAX_INDEX_ENTRIES) return false
        return records.all { it.targetAddress == target && verify(it) }
    }

    fun decodeWire(wire: String): Request? = runCatching { parse(JSONObject(NexusCrypto.decode(wire))) }.getOrNull()?.takeIf(::verify)

    fun decodeIndex(value: String): List<Request> = runCatching {
        val arr = JSONArray(NexusCrypto.decode(value))
        buildList { for (i in 0 until arr.length()) parse(arr.getJSONObject(i))?.let(::add) }
    }.getOrDefault(emptyList())

    private fun buildIndexRecord(context: Context, target: String, requests: List<Request>): NexusDht.Record {
        val payload = NexusCrypto.encode(JSONArray(requests.map { toJson(it) }).toString())
        return NexusDht(NexusIdentity.nodeId(context)).signed(context, inboxKey(target), payload, TTL_MS)
    }

    private fun inboxKey(address: String): String = PREFIX + canonicalAddress(address)

    private fun canonicalAddress(address: String): String = NexusAddress.canonicalize(address)

    private fun canonical(id: String, target: String, senderNode: String, senderAddress: String, pub: String, senderName: String, body: String, created: Long, expires: Long): String =
        "v=1&id=$id&target=$target&sender=$senderNode&senderAddress=$senderAddress&pub=${NexusCrypto.encode(pub)}&senderName=${NexusCrypto.encode(senderName)}&body=${NexusCrypto.encode(body)}&created=$created&expires=$expires"

    fun verify(request: Request): Boolean = runCatching {
        require(NexusAddress.isValidOverlay(request.targetAddress))
        require(NexusAddress.isValidOverlay(request.senderAddress))
        require(request.senderNodeId.isNotBlank() && request.senderPublicKey.isNotBlank())
        require(canonicalAddress(request.senderAddress) == NexusAddress.overlayIpv6FromPublicKey(request.senderPublicKey))
        require(request.body.isNotBlank() && request.body.length <= MAX_BODY)
        require(request.expiresAt > System.currentTimeMillis() && request.expiresAt - request.createdAt in 60_000L..TTL_MS)
        NexusIdentity.verify(
            request.senderPublicKey,
            canonical(request.id, canonicalAddress(request.targetAddress), request.senderNodeId, canonicalAddress(request.senderAddress), request.senderPublicKey, request.senderName, request.body, request.createdAt, request.expiresAt),
            request.signature
        )
    }.getOrDefault(false)

    private fun saveAcceptedMessage(context: Context, request: Request) {
        val value = JSONObject().apply {
            put("id", request.id)
            put("sender", request.senderNodeId)
            put("recipient", NexusIdentity.nodeId(context))
            put("body", request.body)
            put("createdAt", request.createdAt)
            put("source", "address-request")
        }.toString()
        NexusDatabase.put(context, "messages", "${NexusIdentity.nodeId(context)}/${request.id}", value)
    }

    private fun flag(context: Context, type: String, id: String) {
        context.getSharedPreferences("nexus_peer_requests", Context.MODE_PRIVATE).edit().putBoolean("$type:$id", true).apply()
    }

    private fun isAccepted(context: Context, id: String) = context.getSharedPreferences("nexus_peer_requests", Context.MODE_PRIVATE).getBoolean("accepted:$id", false)
    private fun isDeclined(context: Context, id: String) = context.getSharedPreferences("nexus_peer_requests", Context.MODE_PRIVATE).getBoolean("declined:$id", false)

    private fun files(context: Context): List<File> = File(context.filesDir, ROOT).listFiles().orEmpty().filter { it.name.startsWith("req-") && it.extension == "json" }

    private fun read(file: File): Request? = runCatching { parse(JSONObject(file.readText(Charsets.UTF_8)))?.takeIf(::verify) }.getOrNull()

    private fun parse(j: JSONObject): Request? = runCatching {
        Request(
            j.getString("id"), j.getString("targetAddress"), j.getString("senderNodeId"), j.getString("senderAddress"),
            j.getString("senderPublicKey"), j.getString("senderName"), j.getString("body"), j.getLong("createdAt"), j.getLong("expiresAt"), j.getString("signature")
        )
    }.getOrNull()

    private fun toJson(r: Request): JSONObject = JSONObject().apply {
        put("id", r.id); put("targetAddress", r.targetAddress); put("senderNodeId", r.senderNodeId); put("senderAddress", r.senderAddress)
        put("senderPublicKey", r.senderPublicKey); put("senderName", r.senderName); put("body", r.body); put("createdAt", r.createdAt); put("expiresAt", r.expiresAt); put("signature", r.signature)
    }
}
