package com.nexus.network

import android.content.Context
import java.io.File
import java.util.concurrent.atomic.AtomicLong

/** Persistent local outbox for deferred NEXUS messages. */
class NexusMessageOutbox(context: Context) {
    data class Pending(val id: String, val recipient: String, val body: String, val createdAt: Long, val attempts: Int)

    private val root = File(context.filesDir, "nexus-message-outbox").apply { mkdirs() }
    private val sequence = AtomicLong(0)

    @Synchronized
    fun enqueue(recipient: String, body: String, id: String? = null, createdAt: Long = System.currentTimeMillis()): String {
        require(recipient.isNotBlank() && recipient.length <= 256)
        require(body.isNotBlank() && body.length <= 16 * 1024)
        val safeId = id?.takeIf { it.matches(Regex("[A-Za-z0-9._:-]{8,96}")) }
            ?: NexusCrypto.sha256Hex("$recipient|$body|$createdAt|${sequence.incrementAndGet()}").take(40)
        val file = File(root, "$safeId.msg")
        if (!file.exists()) write(file, Pending(safeId, recipient, body, createdAt, 0))
        return safeId
    }

    fun pending(limit: Int = 32): List<Pending> = root.listFiles().orEmpty()
        .filter { it.extension == "msg" }
        .mapNotNull { read(it) }
        .filter { it.attempts < 16 }
        .sortedBy { it.createdAt }
        .take(limit.coerceIn(1, 128))

    @Synchronized fun ack(id: String) { File(root, "$id.msg").delete() }

    @Synchronized
    fun defer(id: String) {
        val file = File(root, "$id.msg")
        val p = read(file) ?: return
        write(file, p.copy(attempts = p.attempts + 1))
    }

    private fun read(file: File): Pending? = runCatching {
        val f = file.readLines(Charsets.UTF_8).mapNotNull { line ->
            val i = line.indexOf('=')
            if (i > 0) line.substring(0, i) to NexusCrypto.decode(line.substring(i + 1)) else null
        }.toMap()
        Pending(
            id = f["id"] ?: return@runCatching null,
            recipient = f["recipient"] ?: return@runCatching null,
            body = f["body"] ?: return@runCatching null,
            createdAt = f["createdAt"]?.toLongOrNull() ?: return@runCatching null,
            attempts = f["attempts"]?.toIntOrNull()?.coerceAtLeast(0) ?: 0
        )
    }.getOrNull()

    private fun write(file: File, p: Pending) {
        file.writeText(
            listOf(
                "id=${NexusCrypto.encode(p.id)}",
                "recipient=${NexusCrypto.encode(p.recipient)}",
                "body=${NexusCrypto.encode(p.body)}",
                "createdAt=${NexusCrypto.encode(p.createdAt.toString())}",
                "attempts=${NexusCrypto.encode(p.attempts.toString())}"
            ).joinToString("\n"),
            Charsets.UTF_8
        )
    }
}
