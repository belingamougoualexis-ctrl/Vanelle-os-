package com.nexus.network

import android.net.VpnService
import java.net.DatagramSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicReference

object NexusVpnRegistry {
    private val active = AtomicReference<VpnService?>(null)

    fun register(service: VpnService) { active.set(service) }
    fun isActive(): Boolean = active.get() != null
    fun unregister(service: VpnService) { active.compareAndSet(service, null) }

    fun protect(socket: Socket): Boolean = active.get()?.protect(socket) ?: true
    fun protect(socket: DatagramSocket): Boolean = active.get()?.protect(socket) ?: true
}
