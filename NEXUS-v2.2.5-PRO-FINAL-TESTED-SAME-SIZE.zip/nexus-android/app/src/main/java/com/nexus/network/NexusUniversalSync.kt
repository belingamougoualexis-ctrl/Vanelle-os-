package com.nexus.network

import android.content.Context
import java.security.MessageDigest

/** Deterministic database synchronizer. Local writes are pushed; remote records are merged with the DB resolver. */
object NexusUniversalSync {
    data class Report(
        val database: String,
        val remoteNode: String,
        val localBefore: Int,
        val remoteBefore: Int,
        val merged: Int,
        val pushed: Int,
        val digestBefore: String,
        val digestAfter: String
    )

    fun sync(context: Context, host: String, remoteNode: String, database: String): Result<Report> = runCatching {
        val before = NexusDatabase.list(context, database, 1024)
        val remote = NexusServiceProtocol.listRemote(context, host, database).getOrThrow()
        var merged = 0
        remote.forEach { if (NexusDatabase.merge(context, it)) merged++ }

        val localToPush = NexusDatabase.list(context, database, 1024).filter { it.nodeId == NexusIdentity.nodeId(context) }
        var pushed = 0
        localToPush.forEach { record ->
            if (NexusServiceProtocol.putRemote(context, host, record).isSuccess) pushed++
        }
        val after = NexusDatabase.list(context, database, 1024)
        val digestBefore = digest(before)
        val digestAfter = digest(after)
        Report(database, remoteNode, before.size, remote.size, merged, pushed, digestBefore, digestAfter)
    }

    fun digest(records: List<NexusDatabase.Record>): String {
        val canonical = records.sortedWith(compareBy<NexusDatabase.Record> { it.key }.thenBy { it.version }.thenBy { it.nodeId })
            .joinToString("\n") { "${it.database}|${it.key}|${it.value}|${it.version}|${it.nodeId}|${it.updatedAt}|${it.hash}" }
        return MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }
}
