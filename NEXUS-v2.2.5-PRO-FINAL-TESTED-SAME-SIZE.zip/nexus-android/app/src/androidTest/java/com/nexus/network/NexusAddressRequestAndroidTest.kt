package com.nexus.network

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class NexusAddressRequestAndroidTest {
    @Test
    fun addressIsStableForTheSameIdentity() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val first = NexusAddress.overlayIpv6(context)
        val second = NexusAddress.overlayIpv6(context)
        assertEquals(first, second)
        assertTrue(NexusAddress.isValidOverlay(first))
    }

    @Test
    fun requestAcceptancePersistsTheMessageAndContact() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val target = NexusAddress.overlayIpv6(context)
        val targetRequest = NexusPeerRequests.create(context, target, "Android instrumentation request", "Instrumentation")
        assertTrue(NexusPeerRequests.pending(context).any { it.id == targetRequest.id })
        assertTrue(NexusPeerRequests.accept(context, targetRequest.id) != null)
        assertTrue(NexusPeerRequests.accepted(context).any { it.id == targetRequest.id })
        val message = NexusDatabase.get(context, "messages", "${NexusIdentity.nodeId(context)}/${targetRequest.id}")
        assertTrue(message?.value?.contains("Android instrumentation request") == true)

        val address = NexusAddress.overlayIpv6(context)
        val contact = NexusContacts.add(context, "Instrumentation", address)
        assertEquals(contact.address, address)
        assertTrue(NexusContacts.list(context).any { it.id == contact.id })
        assertTrue(NexusContacts.remove(context, contact.id))
    }

    @Test
    fun contactShareLinkRoundTrip() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val address = NexusAddress.overlayIpv6(context)
        val link = NexusShareLink.forAddress(address)
        assertEquals(address, NexusShareLink.addressFrom(android.net.Uri.parse(link)))
    }

    @Test
    fun overlayAddressRejectsNonNexusValues() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val own = NexusAddress.overlayIpv6(context)
        assertNotEquals("127.0.0.1", own)
        assertTrue(!NexusAddress.isValidOverlay("2001:db8::1"))
        assertTrue(!NexusAddress.isValidOverlay("127.0.0.1"))
    }
}
