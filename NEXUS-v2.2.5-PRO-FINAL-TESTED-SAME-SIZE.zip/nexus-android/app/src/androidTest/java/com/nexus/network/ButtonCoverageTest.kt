package com.nexus.network

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ButtonCoverageTest {
    @Test
    fun navigationAndVisibleButtonsHaveActions() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        context.getSharedPreferences("nexus_account", Activity.MODE_PRIVATE).edit()
            .putBoolean("account_created", true)
            .putBoolean("signed_out", false)
            .putBoolean("participation_consent", true)
            .putString("username", "TestUser")
            .putString("email", "test@example.invalid")
            .putString("password_hash", "test")
            .commit()
        context.getSharedPreferences("nexus_onboarding", Activity.MODE_PRIVATE).edit()
            .putBoolean("guided_tour_completed", true)
            .putBoolean("guided_tour_skipped", false)
            .commit()

        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            scenario.onActivity { activity ->
                assertFalse(activity.isFinishing)
                assertTrue(collectButtons(activity.window.decorView).isNotEmpty())
                collectButtons(activity.window.decorView).forEach { button ->
                    assertTrue("Emoji détecté dans le bouton: ${button.text}", !containsEmoji(button.text.toString()))
                }
                collectButtons(activity.window.decorView).forEach { button ->
                    assertTrue("Button without OnClickListener: ${button.text}", button.hasOnClickListeners())
                }
            }

            val tabLabels = listOf("Accueil", "Réseau", "Ressources", "Services", "Profil")
            for (label in tabLabels) {
                scenario.onActivity { activity ->
                    val button = collectButtons(activity.window.decorView).firstOrNull { it.text.toString() == label }
                    assertTrue("Navigation tab missing: $label", button != null)
                    assertTrue(button!!.performClick())
                }
                InstrumentationRegistry.getInstrumentation().waitForIdleSync()
                scenario.onActivity { activity ->
                    assertFalse(activity.isFinishing)
                    collectButtons(activity.window.decorView).forEach { button ->
                        assertTrue("Button without OnClickListener after $label: ${button.text}", button.hasOnClickListeners())
                        assertTrue("Emoji détecté dans le bouton: ${button.text}", !containsEmoji(button.text.toString()))
                    }
                }
            }
        }
    }

    private fun containsEmoji(value: String): Boolean = value.any {
        val code = it.code
        code in 0x1F000..0x1FAFF || code in 0x2600..0x27BF || code in 0xFE00..0xFE0F
    }

    private fun collectButtons(root: View): List<Button> {
        val out = mutableListOf<Button>()
        fun walk(v: View) {
            if (v is Button) out += v
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) walk(v.getChildAt(i))
            }
        }
        walk(root)
        return out
    }
}
