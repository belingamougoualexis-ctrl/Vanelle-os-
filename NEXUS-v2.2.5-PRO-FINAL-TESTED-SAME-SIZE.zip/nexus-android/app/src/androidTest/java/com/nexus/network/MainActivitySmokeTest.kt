package com.nexus.network

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivitySmokeTest {
    @Test
    fun launchAndRenderEntryFlow() {
        val scenario = ActivityScenario.launch(MainActivity::class.java)
        scenario.onActivity { activity ->
            check(!activity.isFinishing)
            check(!activity.isDestroyed)
            check(activity.window.decorView != null)
        }
        scenario.close()
    }
    @Test
    fun contactDeepLinkLaunches() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        context.getSharedPreferences("nexus_account", Activity.MODE_PRIVATE).edit()
            .putBoolean("account_created", true)
            .putBoolean("signed_out", false)
            .putBoolean("participation_consent", true)
            .putString("username", "Smoke")
            .putString("email", "smoke@example.invalid")
            .putString("password_hash", "test")
            .commit()
        context.getSharedPreferences("nexus_onboarding", Activity.MODE_PRIVATE).edit()
            .putBoolean("guided_tour_completed", true)
            .putBoolean("guided_tour_skipped", false)
            .commit()
        val address = "fd00:4e58:5553:1:1111:2222:3333:4444"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(NexusShareLink.forAddress(address))).setClass(context, MainActivity::class.java)
        ActivityScenario.launch<MainActivity>(intent).use { scenario ->
            scenario.onActivity { activity -> check(!activity.isFinishing && !activity.isDestroyed) }
        }
    }

}
