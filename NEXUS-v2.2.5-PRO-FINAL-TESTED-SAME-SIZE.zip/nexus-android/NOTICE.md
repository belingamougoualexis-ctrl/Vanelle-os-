# NEXUS — Informations de distribution

- Application : NEXUS
- Version : 2.0.0
- Application ID : com.nexus.network
- Min SDK : 26
- Target SDK : 37
- Publicité : aucune intégrée
- Installation de paquets : aucune permission REQUEST_INSTALL_PACKAGES
- Accès réseau : utilisé pour les fonctions réseau NEXUS
- Partage de ressources : opt-in
- Le paquet doit être signé avec la clé de publication du propriétaire avant distribution de production.

Avant publication, le distributeur doit fournir les informations et droits de publication requis par la plateforme cible.
