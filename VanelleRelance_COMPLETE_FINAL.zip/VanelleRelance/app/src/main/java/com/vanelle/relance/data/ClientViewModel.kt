package com.vanelle.relance.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vanelle.relance.utils.AutomationHelper
import com.vanelle.relance.utils.HistoriqueHelper
import com.vanelle.relance.utils.MessageHelper
import com.vanelle.relance.utils.SmsHelper
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class ClientViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getInstance(application).clientDao()

    val tousLesClients = dao.getTous()
    val clientsEnRetard = dao.getEnRetard()
    val totalDu = dao.getTotalDu()
    val totalRecupere = dao.getTotalRecupere()

    fun clientsOublies() = dao.getOublies(
        System.currentTimeMillis() - TimeUnit.DAYS.toMillis(21)
    )

    fun ajouter(client: Client) = viewModelScope.launch {
        dao.inserer(client)
    }


    /** Ajoute le client puis tente la première relance immédiatement.
     *  Aucun paiement ou envoi n'est considéré comme réussi sans retour positif du canal.
     */
    fun ajouterEtRelancerImmediatement(client: Client) = viewModelScope.launch {
        val id = dao.inserer(client)
        val saved = dao.getParId(id) ?: return@launch
        val context = getApplication<Application>()
        val message = MessageHelper.genererMessageRelance(context, saved, saved.nombreRelances)
        val sent = when (saved.canalRelance) {
            CanalRelance.SMS -> SmsHelper.envoyerTexte(context, saved, message)
            CanalRelance.WHATSAPP -> AutomationHelper.serviceActive(context) &&
                AutomationHelper.startWhatsApp(context, saved, message)
            CanalRelance.GMAIL -> AutomationHelper.serviceActive(context) &&
                AutomationHelper.startEmail(context, saved, saved.objetEmail, message)
        }
        if (sent) {
            dao.mettreAJour(saved.copy(nombreRelances = 1, dernierContact = System.currentTimeMillis()))
            HistoriqueHelper.enregistrer(context, "PREMIERE_RELANCE", saved.nom, "Première relance automatique")
        }
    }

    fun mettreAJour(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client)
    }

    fun supprimer(client: Client) = viewModelScope.launch {
        dao.supprimer(client)
    }

    fun marquerPaye(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client.copy(statut = StatutDette.PAYEE))
    }

    /** Remet une dette payée en « En cours » */
    fun marquerEnCours(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client.copy(statut = StatutDette.EN_COURS))
    }


    /** Les relances sont immédiates/automatiques : aucun délai minimum n'est appliqué. */
    fun peutRelancer(client: Client, maintenant: Long = System.currentTimeMillis()): Boolean = true

    /** Enregistre toute relance sans blocage temporel. */
    fun enregistrerRelanceSiAutorisee(client: Client) = viewModelScope.launch {
        val actuel = dao.getParId(client.id) ?: return@launch
        dao.mettreAJour(
            actuel.copy(
                nombreRelances = actuel.nombreRelances + 1,
                dernierContact = System.currentTimeMillis()
            )
        )
    }

    fun enregistrerRelance(client: Client) = viewModelScope.launch {
        dao.mettreAJour(
            client.copy(
                nombreRelances = client.nombreRelances + 1,
                dernierContact = System.currentTimeMillis()
            )
        )
    }
}
