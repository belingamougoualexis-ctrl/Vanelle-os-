# VanelleOS

Assistant vocal Android : reconnaissance vocale native (mot d'activation "Cassandra"), ouverture d'applications, appel de contacts, recherche web, YouTube, traduction, memoire personnelle chiffree, alarme telephone perdu, appel d'urgence.

## Structure

```
Vanelle/
├── app/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── .github/workflows/android-build.yml
```

Le wrapper Gradle (`gradlew`, `gradlew.bat`, `gradle/wrapper/`) n'est pas commité. Le workflow CI installe directement Gradle 8.11.1 avec `gradle/actions/setup-gradle`, puis lance la compilation.

## Build local

1. Ouvrir le dossier dans Android Studio (File > Open). Android Studio detecte et telecharge automatiquement le wrapper Gradle manquant au premier sync.
   - En ligne de commande, la meme etape se fait avec : `gradle wrapper --gradle-version 8.11.1` (necessite Gradle installe une fois), puis `./gradlew assembleDebug`.
2. Après synchronisation, `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk` (signe automatiquement avec le keystore de debug genere par Android Studio, installable directement sur un telephone)

Pour un APK de release (signe pour publication), il faut d'abord configurer un keystore et un signingConfig dans `app/build.gradle.kts` -- non inclus ici car cela necessite un keystore personnel que l'utilisateur doit generer lui-meme.

## Build automatique (CI)

Le workflow `.github/workflows/android-build.yml` installe Gradle 8.11.1 puis compile et lint l'APK a chaque push sur `main`. L'APK signe en debug est disponible dans l'onglet Actions > artefacts.

## Permissions demandees

| Permission | Utilisation |
|---|---|
| RECORD_AUDIO | Ecoute du mot d'activation "Cassandra" |
| READ_CONTACTS | Retrouver un contact par son nom |
| CALL_PHONE | Préparer l’appel après confirmation de l’utilisateur |
| SEND_SMS | Préparer l’envoi après confirmation de l’utilisateur |
| POST_NOTIFICATIONS | Notification du service d'ecoute (Android 13+) |
| RECEIVE_BOOT_COMPLETED | Relance l'ecoute apres redemarrage si activee |
| VIBRATE | Alarme "telephone perdu" |
| CAMERA | Ouvrir l'appareil photo sur demande vocale |
| SCHEDULE_EXACT_ALARM / USE_EXACT_ALARM | Relances et routines declenchees a l'heure precise |
| SYSTEM_ALERT_WINDOW | Afficher la mascotte par-dessus les autres applications |
| INTERNET | Recherche web/traduction, reponses courtes (Wikipedia/DuckDuckGo) |

Toutes les permissions sont demandees a l'utilisateur au premier lancement (sauf SCHEDULE_EXACT_ALARM et SYSTEM_ALERT_WINDOW, geres depuis l'onglet Configuration).

**Note distribution** : CALL_PHONE et SEND_SMS sont des "permissions restreintes" sur le Google Play Store — leur usage y est limite aux applications qui remplacent l'app Telephone/Messages par defaut du systeme. Une publication Play Store avec ces permissions declenchera une verification stricte, voire un refus. Pour un usage prive (installation directe/sideload), aucune restriction.

## Service d'accessibilite (optionnel)

Pour les actions systeme (retour, accueil, notifications, recents), l'utilisateur doit activer VanelleOS manuellement dans Parametres > Accessibilite. L'application propose ce reglage au premier lancement.
