package com.vanelle.os
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import java.io.File
import java.io.RandomAccessFile
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

object LlamaModelManager {
    const val URL_MODEL =
        "https://huggingface.co/hugging-quants/Llama-3.2-1B-Instruct-Q4_K_M-GGUF/resolve/main/llama-3.2-1b-instruct-q4_k_m.gguf"
    private const val FILE_NAME = "llama-3.2-1b-instruct-q4_k_m.gguf"
    const val EXPECTED_MIN_BYTES = 700_000_000L

    fun modelFile(c: Context) = File(c.filesDir, FILE_NAME)
    fun partFile(c: Context) = File(c.filesDir, "$FILE_NAME.part")
    fun isReady(c: Context): Boolean {
        val f = modelFile(c)
        return f.exists() && f.length() > EXPECTED_MIN_BYTES && hasGgufHeader(f)
    }

    private fun hasGgufHeader(file: File): Boolean {
        return try {
            FileInputStream(file).use { input ->
                val h = ByteArray(4)
                input.read(h) == 4 &&
                    h[0] == 'G'.code.toByte() &&
                    h[1] == 'G'.code.toByte() &&
                    h[2] == 'U'.code.toByte() &&
                    h[3] == 'F'.code.toByte()
            }
        } catch (_: Exception) {
            false
        }
    }

    fun partialBytes(c: Context): Long {
        val p = partFile(c)
        return if (p.exists()) p.length() else 0L
    }

    fun isOnWifi(c: Context): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    fun isNetworkAvailable(c: Context): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /**
     * Téléchargement avec reprise (HTTP Range).
     * onProgress(percent 0-100, downloadedBytes, totalBytes)
     * Retourne un code: "DONE", "NO_WIFI", "NO_NETWORK", "ERROR:...", "CANCELLED"
     */
    suspend fun downloadResumable(
        c: Context,
        wifiOnly: Boolean = true,
        isCancelled: () -> Boolean = { false },
        onProgress: (percent: Int, downloaded: Long, total: Long) -> Unit = { _, _, _ -> }
    ): String = withContext(Dispatchers.IO) {
        if (isReady(c)) {
            onProgress(100, EXPECTED_MIN_BYTES, EXPECTED_MIN_BYTES)
            return@withContext "DONE"
        }
        if (wifiOnly && !isOnWifi(c)) return@withContext "NO_WIFI"
        if (!isNetworkAvailable(c)) return@withContext "NO_NETWORK"

        val dest = modelFile(c)
        val tmp = partFile(c)
        var existing = if (tmp.exists()) tmp.length() else 0L

        try {
            // HEAD pour connaître la taille totale si possible
            var totalKnown = -1L
            try {
                val head = (URL(URL_MODEL).openConnection() as HttpURLConnection).apply {
                    requestMethod = "HEAD"
                    instanceFollowRedirects = true
                    connectTimeout = 15_000
                    readTimeout = 15_000
                    setRequestProperty("User-Agent", "VanelleOS/1.0")
                }
                if (head.responseCode in 200..299) {
                    totalKnown = head.contentLengthLong
                }
                head.disconnect()
            } catch (_: Exception) {}

            val conn = (URL(URL_MODEL).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = true
                connectTimeout = 20_000
                readTimeout = 60_000
                setRequestProperty("User-Agent", "VanelleOS/1.0")
                if (existing > 0) {
                    setRequestProperty("Range", "bytes=$existing-")
                }
            }

            val code = conn.responseCode
            if (code == 416) {
                // Range not satisfiable → fichier partiel déjà complet ?
                if (existing > EXPECTED_MIN_BYTES && hasGgufHeader(tmp)) {
                    if (dest.exists()) dest.delete()
                    tmp.renameTo(dest)
                    onProgress(100, existing, existing)
                    return@withContext "DONE"
                }
                tmp.delete()
                existing = 0L
                return@withContext downloadResumable(c, wifiOnly, isCancelled, onProgress)
            }
            if (code !in 200..299 && code != 206) {
                return@withContext "ERROR:HTTP $code"
            }

            // 206 = reprise ; 200 = serveur ignore Range → on repart à 0
            val append = (code == 206)
            if (!append && existing > 0) {
                tmp.delete()
                existing = 0L
            }

            val bodyLen = conn.contentLengthLong
            val total = when {
                totalKnown > 0 -> totalKnown
                append && bodyLen > 0 -> existing + bodyLen
                bodyLen > 0 -> bodyLen
                else -> max(EXPECTED_MIN_BYTES, existing + 1)
            }

            val raf = RandomAccessFile(tmp, "rw")
            if (append) raf.seek(existing) else raf.setLength(0)

            var downloaded = existing
            var lastPct = -1
            val buffer = ByteArray(256 * 1024)
            try {
                conn.inputStream.use { input ->
                    while (true) {
                        if (isCancelled()) {
                            raf.close()
                            conn.disconnect()
                            return@withContext "CANCELLED"
                        }
                        if (wifiOnly && !isOnWifi(c)) {
                            raf.close()
                            conn.disconnect()
                            return@withContext "NO_WIFI"
                        }
                        if (!isNetworkAvailable(c)) {
                            raf.close()
                            conn.disconnect()
                            return@withContext "NO_NETWORK"
                        }
                        val read = input.read(buffer)
                        if (read == -1) break
                        raf.write(buffer, 0, read)
                        downloaded += read
                        val pct = if (total > 0) ((downloaded * 100) / total).toInt().coerceIn(0, 99) else 0
                        if (pct != lastPct) {
                            lastPct = pct
                            withContext(Dispatchers.Main) {
                                onProgress(pct, downloaded, total)
                            }
                        }
                    }
                }
            } finally {
                try { raf.close() } catch (_: Exception) {}
                try { conn.disconnect() } catch (_: Exception) {}
            }

            if (downloaded < EXPECTED_MIN_BYTES) {
                return@withContext "ERROR:incomplet ($downloaded)"
            }
            if (!hasGgufHeader(tmp)) {
                try { tmp.delete() } catch (_: Exception) {}
                return@withContext "ERROR:fichier GGUF invalide"
            }
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) {
                tmp.copyTo(dest, overwrite = true)
                tmp.delete()
            }
            withContext(Dispatchers.Main) { onProgress(100, downloaded, total) }
            "DONE"
        } catch (e: Exception) {
            "ERROR:${e.message ?: "réseau"}"
        }
    }
}
