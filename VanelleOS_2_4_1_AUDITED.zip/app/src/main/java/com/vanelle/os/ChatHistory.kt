package com.vanelle.os

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Historique organisé type Claude/ChatGPT :
 * conversations, dossiers, tags, recherche.
 * Les tours mascotte + chat texte partagent la conversation active.
 */
object ChatHistory {
    private const val PREFS = "vanelle_chat_org"
    private const val KEY_THREADS = "threads"
    private const val KEY_ACTIVE = "active_id"
    private const val KEY_FOLDERS = "folders"
    private const val MAX_THREADS = 80
    private const val MAX_MSG = 120

    data class Msg(val role: String, val text: String, val ts: Long)

    data class Thread(
        val id: String,
        val title: String,
        val folder: String,
        val tags: List<String>,
        val updatedAt: Long,
        val messages: List<Msg>
    )

    private fun p(c: Context) = c.getSharedPreferences(PREFS, 0)

    private fun newId(): String = "t_${System.currentTimeMillis()}_${(1000..9999).random()}"

    fun folders(c: Context): List<String> {
        val defaults = listOf("Général", "Travail", "Perso", "Projets")
        return try {
            val arr = JSONArray(p(c).getString(KEY_FOLDERS, "[]"))
            val custom = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val s = arr.optString(i).trim()
                if (s.isNotBlank()) custom += s
            }
            (defaults + custom).distinct()
        } catch (_: Exception) {
            defaults
        }
    }

    fun addFolder(c: Context, name: String) {
        val n = name.trim().take(40)
        if (n.isBlank()) return
        try {
            val arr = JSONArray(p(c).getString(KEY_FOLDERS, "[]"))
            for (i in 0 until arr.length()) if (arr.optString(i).equals(n, true)) return
            arr.put(n)
            p(c).edit().putString(KEY_FOLDERS, arr.toString()).apply()
        } catch (_: Exception) {}
    }

    fun activeId(c: Context): String {
        var id = p(c).getString(KEY_ACTIVE, null)
        if (id.isNullOrBlank() || thread(c, id) == null) {
            id = ensureActive(c)
        }
        return id!!
    }

    fun setActive(c: Context, id: String) {
        if (thread(c, id) != null) p(c).edit().putString(KEY_ACTIVE, id).apply()
    }

    private fun ensureActive(c: Context): String {
        val all = allThreads(c)
        if (all.isNotEmpty()) {
            val id = all.maxByOrNull { it.updatedAt }!!.id
            p(c).edit().putString(KEY_ACTIVE, id).apply()
            return id
        }
        return newThread(c, title = "Nouvelle conversation", folder = "Général")
    }

    fun newThread(c: Context, title: String = "Nouvelle conversation", folder: String = "Général"): String {
        val id = newId()
        val o = JSONObject()
            .put("id", id)
            .put("title", title.take(80))
            .put("folder", folder.take(40).ifBlank { "Général" })
            .put("tags", JSONArray())
            .put("updatedAt", System.currentTimeMillis())
            .put("messages", JSONArray())
        val arr = loadArray(c)
        arr.put(o)
        saveArray(c, arr)
        p(c).edit().putString(KEY_ACTIVE, id).apply()
        return id
    }

    fun allThreads(c: Context): List<Thread> {
        return try {
            val arr = loadArray(c)
            val out = mutableListOf<Thread>()
            for (i in 0 until arr.length()) {
                parseThread(arr.getJSONObject(i))?.let { out += it }
            }
            out.sortedByDescending { it.updatedAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun thread(c: Context, id: String): Thread? =
        allThreads(c).firstOrNull { it.id == id }

    fun messages(c: Context, threadId: String = activeId(c)): List<Msg> =
        thread(c, threadId)?.messages ?: emptyList()

    fun all(c: Context): List<Msg> = messages(c)

    fun add(c: Context, role: String, text: String, alsoRelational: Boolean = true) {
        val clean = text.trim()
        if (clean.isBlank()) return
        val id = activeId(c)
        try {
            val arr = loadArray(c)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("id") != id) continue
                val msgs = o.optJSONArray("messages") ?: JSONArray()
                msgs.put(
                    JSONObject()
                        .put("r", role.take(12))
                        .put("t", clean.take(2000))
                        .put("ts", System.currentTimeMillis())
                )
                val trimmed = JSONArray()
                val start = (msgs.length() - MAX_MSG).coerceAtLeast(0)
                for (j in start until msgs.length()) trimmed.put(msgs.get(j))
                o.put("messages", trimmed)
                o.put("updatedAt", System.currentTimeMillis())
                if (role.equals("user", true) && o.optString("title") in listOf("", "Nouvelle conversation")) {
                    o.put("title", clean.take(48))
                }
                break
            }
            saveArray(c, arr)
        } catch (_: Exception) {}
        if (alsoRelational) {
            try { RelationalMemory(c).addTurn(role, clean) } catch (_: Exception) {}
        }
    }

    fun setFolder(c: Context, threadId: String, folder: String) {
        mutate(c, threadId) { it.put("folder", folder.take(40).ifBlank { "Général" }) }
    }

    fun setTags(c: Context, threadId: String, tags: List<String>) {
        mutate(c, threadId) {
            val a = JSONArray()
            tags.map { t -> t.trim().take(24) }.filter { it.isNotBlank() }.distinct().take(8)
                .forEach { a.put(it) }
            it.put("tags", a)
        }
    }

    fun setTitle(c: Context, threadId: String, title: String) {
        mutate(c, threadId) { it.put("title", title.trim().take(80).ifBlank { "Sans titre" }) }
    }

    fun deleteThread(c: Context, threadId: String) {
        try {
            val arr = loadArray(c)
            val next = JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("id") != threadId) next.put(o)
            }
            saveArray(c, next)
            if (p(c).getString(KEY_ACTIVE, "") == threadId) ensureActive(c)
        } catch (_: Exception) {}
    }

    /** Supprime la dernière réponse assistant du fil actif, utile pour Régénérer. */
    fun removeLastAssistant(c: Context): Boolean {
        var removed = false
        val id = activeId(c)
        mutate(c, id) { o ->
            val msgs = o.optJSONArray("messages") ?: return@mutate
            val out = JSONArray()
            var removedOne = false
            for (i in 0 until msgs.length()) {
                val m = msgs.optJSONObject(i) ?: continue
                val isAssistant = m.optString("r").equals("assistant", true)
                if (!removedOne && isAssistant && i == msgs.length() - 1) {
                    removedOne = true
                    removed = true
                } else out.put(m)
            }
            if (removedOne) o.put("messages", out)
        }
        return removed
    }

    fun clear(c: Context) {
        val id = activeId(c)
        mutate(c, id) {
            it.put("messages", JSONArray())
            it.put("updatedAt", System.currentTimeMillis())
        }
    }

    fun clearAll(c: Context) {
        p(c).edit().remove(KEY_THREADS).remove(KEY_ACTIVE).apply()
    }

    fun search(c: Context, query: String): List<Thread> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return allThreads(c)
        return allThreads(c).filter { th ->
            th.title.lowercase().contains(q) ||
                th.folder.lowercase().contains(q) ||
                th.tags.any { it.lowercase().contains(q) } ||
                th.messages.any { it.text.lowercase().contains(q) }
        }
    }

    fun byFolder(c: Context, folder: String): List<Thread> =
        allThreads(c).filter { it.folder.equals(folder, true) }

    private fun mutate(c: Context, threadId: String, block: (JSONObject) -> Unit) {
        try {
            val arr = loadArray(c)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("id") == threadId) {
                    block(o)
                    o.put("updatedAt", System.currentTimeMillis())
                    break
                }
            }
            saveArray(c, arr)
        } catch (_: Exception) {}
    }

    private fun loadArray(c: Context): JSONArray {
        val raw = p(c).getString(KEY_THREADS, null)
        if (raw.isNullOrBlank()) {
            val legacy = c.getSharedPreferences("vanelle_chat_history", 0).getString("messages", null)
            if (!legacy.isNullOrBlank()) {
                val msgs = JSONArray(legacy)
                val o = JSONObject()
                    .put("id", newId())
                    .put("title", "Conversation importée")
                    .put("folder", "Général")
                    .put("tags", JSONArray())
                    .put("updatedAt", System.currentTimeMillis())
                    .put("messages", msgs)
                val arr = JSONArray().put(o)
                saveArray(c, arr)
                p(c).edit().putString(KEY_ACTIVE, o.getString("id")).apply()
                return arr
            }
            return JSONArray()
        }
        return JSONArray(raw)
    }

    private fun saveArray(c: Context, arr: JSONArray) {
        val trimmed = JSONArray()
        val start = (arr.length() - MAX_THREADS).coerceAtLeast(0)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        p(c).edit().putString(KEY_THREADS, trimmed.toString()).apply()
    }

    private fun parseThread(o: JSONObject): Thread? {
        return try {
            val msgsArr = o.optJSONArray("messages") ?: JSONArray()
            val msgs = mutableListOf<Msg>()
            for (i in 0 until msgsArr.length()) {
                val m = msgsArr.getJSONObject(i)
                msgs += Msg(m.optString("r"), m.optString("t"), m.optLong("ts"))
            }
            val tagsArr = o.optJSONArray("tags") ?: JSONArray()
            val tags = mutableListOf<String>()
            for (i in 0 until tagsArr.length()) tags += tagsArr.optString(i)
            Thread(
                id = o.optString("id"),
                title = o.optString("title", "Sans titre"),
                folder = o.optString("folder", "Général"),
                tags = tags,
                updatedAt = o.optLong("updatedAt"),
                messages = msgs
            )
        } catch (_: Exception) {
            null
        }
    }
}
