package com.vanelle.os

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.yield
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min

/**
 * Wrapper optimisé autour de llamacpp-kotlin (réflexion).
 *
 * Optimisations :
 * - Instance unique process-wide (un seul chargement du modèle)
 * - n_ctx adaptatif (512–4096) selon RAM disponible, RAM totale et thermique
 * - Prompt système compact (moins de tokens de préfill)
 * - Contexte utilisateur tronqué
 * - Timeout adaptatif selon la taille de la requête
 * - warmUp() au démarrage de l'app
 * - Mutex pour sérialiser les inférences (un seul contexte natif)
 * - Succès de charge détecté via callback (Long) ET événement Loaded du SharedFlow
 * - Pas de boucle de 10+ tentatives : 2 essais max (ctx optimal puis repli)
 */
class LocalLlamaHelper private constructor(private val appContext: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    // Petit buffer, DROP_OLDEST : évite d'accumuler des tokens/événements si l'UI est occupée.
    private val events = MutableSharedFlow<Any>(
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
        replay = 0
    )

    @Volatile private var loaded = false
    @Volatile private var loading = false
    @Volatile private var loadFailedPermanently = false
    @Volatile private var helper: Any? = null
    @Volatile private var resolvedClass: Class<*>? = null
    private val answerMutex = Mutex()
    private val loadMutex = Mutex()

    private fun resolveLlamaClass(): Class<*>? {
        resolvedClass?.let { return it }
        val candidates = listOf(
            "org.nehuatl.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacppkotlin.LlamaHelper",
            "com.ljcamargo.llamacpp.LlamaHelper"
        )
        for (name in candidates) {
            try {
                val c = Class.forName(name)
                resolvedClass = c
                android.util.Log.i("VanelleLlama", "LlamaHelper résolu: $name")
                return c
            } catch (_: ClassNotFoundException) {}
        }
        android.util.Log.e("VanelleLlama", "Aucune classe LlamaHelper trouvée parmi: $candidates")
        return null
    }

    /** Contexte adaptatif : privilégie la qualité sans sacrifier les appareils faibles. */
    private fun optimalContextLength(): Int = AIConfiguration.profile(appContext).nCtx

    @Volatile private var lastLoadError: String? = null

    fun lastError(): String? = lastLoadError

    private suspend fun ensureLoaded(): Boolean {
        if (loaded && helper != null) return true
        if (loadFailedPermanently) return false
        if (!LlamaModelManager.isReady(appContext)) {
            lastLoadError = "Modèle non téléchargé."
            return false
        }
        return loadMutex.withLock {
            if (loaded && helper != null) return@withLock true
            if (loadFailedPermanently) return@withLock false
            if (loading) {
                // Attendre un chargement concurrent déjà en cours (max 120 s)
                repeat(120) {
                    kotlinx.coroutines.delay(1000)
                    if (loaded && helper != null) return@withLock true
                    if (!loading) return@withLock (loaded && helper != null)
                }
                return@withLock (loaded && helper != null)
            }
            loading = true
            try {
                // Llama est toujours tenté en priorité. Plusieurs contextes
                // permettent de réduire la mémoire KV/cache sur les appareils faibles.
                val optimal = optimalContextLength()
                // Un seul repli raisonnable : plusieurs chargements successifs peuvent coûter
                // beaucoup de temps et fragmenter la mémoire.
                val contexts = listOf(optimal, (optimal / 2).coerceAtLeast(768))
                    .distinct()
                    .filter { it <= optimal }
                var ok = false
                for ((attempt, nCtx) in contexts.withIndex()) {
                    if (attempt > 0) {
                        try { System.gc() } catch (_: Exception) {}
                        kotlinx.coroutines.delay(1500)
                    }
                    ok = tryLoadOnce(nCtx, timeoutMs = 120_000L)
                    if (ok) {
                        lastLoadError = null
                        android.util.Log.i("VanelleLlama", "Modèle chargé (n_ctx=$nCtx, tentative=${attempt + 1})")
                        AiLoadDiagnostics.logSuccess(appContext, "chargé avec n_ctx=$nCtx (tentative ${attempt + 1}/${contexts.size})")
                        return@withLock true
                    }
                }
                loadFailedPermanently = true
                if (lastLoadError == null) {
                    lastLoadError = LlamaModelManager.memoryWarning(appContext)
                        ?: "Impossible de charger l'IA en mémoire. Ferme d'autres apps, libère de la RAM, puis rouvre VanelleOS."
                }
                android.util.Log.e("VanelleLlama", "Échec du chargement unique: $lastLoadError")
                AiLoadDiagnostics.logFailure(
                    appContext,
                    (lastLoadError ?: "cause inconnue") +
                        " — Si le GGUF était Q4_0_4_4, re-télécharge le modèle Q4_K_M compatible.",
                    attempt = contexts.size
                )
                false
            } catch (e: Exception) {
                android.util.Log.e("VanelleLlama", "ensureLoaded exception", e)
                loadFailedPermanently = true
                lastLoadError = "Erreur de chargement : ${e.message ?: "inconnue"}"
                AiLoadDiagnostics.logFailure(appContext, lastLoadError ?: "exception inconnue")
                false
            } finally {
                loading = false
            }
        }
    }

    private suspend fun tryLoadOnce(nCtx: Int, timeoutMs: Long): Boolean {
        return try {
            val klass = resolveLlamaClass()
            if (klass == null) {
                lastLoadError = "Bibliothèque IA locale absente (variante modern / 64 bits requise)."
                return false
            }
            val ctor = try {
                klass.getConstructor(
                    android.content.ContentResolver::class.java,
                    CoroutineScope::class.java,
                    MutableSharedFlow::class.java
                )
            } catch (e: Exception) {
                android.util.Log.e("VanelleLlama", "Constructeur LlamaHelper introuvable", e)
                lastLoadError = "API LlamaHelper incompatible."
                null
            } ?: return false

            val modelFile = LlamaModelManager.modelFile(appContext)
            if (!modelFile.exists() || modelFile.length() != LlamaModelManager.EXPECTED_MIN_BYTES ||
                !LlamaModelManager.verifyModelIntegrity(appContext)) {
                lastLoadError = "Fichier modèle manquant, tronqué ou corrompu. Le téléchargement sera vérifié avant un nouvel essai."
                android.util.Log.e("VanelleLlama", "Intégrité GGUF invalide: ${modelFile.length()} octets")
                return false
            }

            // URI stable : FileProvider si possible, sinon file://
            val modelUri = try {
                androidx.core.content.FileProvider.getUriForFile(
                    appContext,
                    "${appContext.packageName}.fileprovider",
                    modelFile
                ).toString()
            } catch (_: Exception) {
                Uri.fromFile(modelFile).toString()
            }

            // Libère un peu de heap avant le gros mmap/load natif
            try { System.gc() } catch (_: Exception) {}

            val h = ctor.newInstance(appContext.contentResolver, scope, events)

            // Signature officielle v0.4.0 :
            // load(path, contextLength, mmprojPath?, loaded: (Long) -> Unit)
            val loadMethod = try {
                klass.getMethod(
                    "load",
                    String::class.java,
                    Int::class.javaPrimitiveType,
                    String::class.java,
                    kotlin.jvm.functions.Function1::class.java
                )
            } catch (_: Exception) {
                klass.methods.firstOrNull { m -> m.name == "load" && m.parameterTypes.size >= 2 }
            }
            if (loadMethod == null) {
                lastLoadError = "Méthode load() introuvable dans la bibliothèque IA."
                return false
            }

            val ok = withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    val done = java.util.concurrent.atomic.AtomicBoolean(false)
                    fun complete(success: Boolean) {
                        if (done.compareAndSet(false, true) && cont.isActive) {
                            cont.resume(success)
                        }
                    }

                    val watchJob = scope.launch {
                        try {
                            events.takeWhile { event ->
                                when (event.javaClass.simpleName) {
                                    "Loaded" -> {
                                        complete(true)
                                        false
                                    }
                                    "Error" -> {
                                        android.util.Log.w("VanelleLlama", "LLMEvent.Error: $event")
                                        lastLoadError = "Erreur native au chargement (GGUF incompatible ou RAM insuffisante). Réessaie ou re-télécharge le modèle."
                                        complete(false)
                                        false
                                    }
                                    else -> true
                                }
                            }.collect { }
                        } catch (_: Exception) {}
                    }

                    try {
                        val callback = object : kotlin.jvm.functions.Function1<Long, Unit> {
                            override fun invoke(id: Long) {
                                android.util.Log.i("VanelleLlama", "Callback load OK, contextId=$id")
                                complete(true)
                            }
                        }
                        when (loadMethod.parameterTypes.size) {
                            4 -> loadMethod.invoke(h, modelUri, nCtx, null, callback)
                            3 -> {
                                try {
                                    loadMethod.invoke(h, modelUri, nCtx, callback)
                                } catch (_: Exception) {
                                    loadMethod.invoke(h, modelUri, nCtx, null)
                                }
                            }
                            2 -> loadMethod.invoke(h, modelUri, nCtx)
                            else -> loadMethod.invoke(h, modelUri)
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("VanelleLlama", "invoke load failed", e)
                        lastLoadError = "Échec chargement : ${e.message ?: e.javaClass.simpleName}"
                        complete(false)
                    }

                    cont.invokeOnCancellation { watchJob.cancel() }
                }
            } ?: run {
                lastLoadError = "Délai dépassé lors du chargement en mémoire."
                false
            }

            if (ok) {
                helper = h
                try { NativePerf.tryTuneHelper(h, appContext) } catch (_: Exception) {}
                loaded = true
                loadFailedPermanently = false
                lastLoadError = null
            } else {
                android.util.Log.w("VanelleLlama", "tryLoadOnce(nCtx=$nCtx): échec — $lastLoadError")
            }
            ok
        } catch (e: Exception) {
            android.util.Log.e("VanelleLlama", "tryLoadOnce(nCtx=$nCtx) exception", e)
            lastLoadError = "Erreur : ${e.message ?: "inconnue"}"
            false
        }
    }

    /**
     * Précharge le modèle. ensureLoaded() gère déjà son propre réessai interne
     * (contexte optimal puis repli) — pas besoin de reboucler par-dessus ici.
     */
    suspend fun warmUp(): Boolean = withContext(Dispatchers.IO) {
        if (!LlamaModelManager.isReady(appContext)) return@withContext false
        if (loaded && helper != null) return@withContext true
        if (loadFailedPermanently) return@withContext false
        ensureLoaded()
    }

    fun isLoaded(): Boolean = loaded && helper != null

    fun isLoading(): Boolean = loading

    /** Arrêt utilisateur : interrompt la génération native sans tuer le processus. */
    fun stopGeneration() {
        val h = helper ?: return
        try {
            h.javaClass.getMethod("stopPrediction").invoke(h)
        } catch (e: Exception) {
            android.util.Log.w("VanelleLlama", "stopGeneration: ${e.message}")
        }
    }

    /** Réinitialise le flag d'échec permanent (ex. après redémarrage app ou nouvel essai manuel). */
    fun resetLoadFailure() {
        loadFailedPermanently = false
        lastLoadError = null
    }

    /**
     * @param maxTokensHint limite soft : on demande l'arrêt natif, mais on attend toujours Done
     *                      pour récupérer le texte complet (évite les phrases coupées).
     * @param fastMode prompt encore plus court + timeout réduit (commandes simples)
     */

    // --- Sampling Vanelle (llama.cpp via launchCompletion) ---
    // temperature 0.8, top_p 0.9, top_k 40, min_p 0.05,
    // penalty_repeat 1.12, penalty_last_n 64, n_predict 150-200
    private object Sampling {
        const val TEMPERATURE = 0.80
        const val TOP_P = 0.90
        const val TOP_K = 40
        const val MIN_P = 0.05
        const val PENALTY_REPEAT = 1.12
        const val PENALTY_LAST_N = 64
        val STOP = listOf(
            "\nUtilisateur:",
            "\nUser:",
            "\nUser :",
            "\nHuman:",
            "<|im_end|>",
            "<|im_start|>user",
            "<|eot_id|>"
        )
    }

    /**
     * Compatibilité historique. Le chemin de génération principal utilise désormais
     * uniquement l'API publique predict() de la bibliothèque.
     */
    private fun invokeCompletionWithSampling(
        h: Any,
        klass: Class<*>,
        prompt: String,
        nPredict: Int
    ): String? {
        return try {
            val ctxField = klass.declaredFields.firstOrNull { it.name == "currentContext" }
                ?: return null
            ctxField.isAccessible = true
            val ctxId = ctxField.get(h) as? Int ?: return null

            val llamaField = klass.declaredFields.firstOrNull { it.name == "llama" }
                ?: return null
            llamaField.isAccessible = true
            val llama = llamaField.get(h) ?: return null

            val params = hashMapOf<String, Any>(
                "prompt" to prompt,
                "emit_partial_completion" to true,
                "temperature" to Sampling.TEMPERATURE,
                "top_p" to Sampling.TOP_P,
                "top_k" to Sampling.TOP_K,
                "min_p" to Sampling.MIN_P,
                "penalty_repeat" to Sampling.PENALTY_REPEAT,
                "penalty_last_n" to Sampling.PENALTY_LAST_N,
                "n_predict" to nPredict.coerceIn(64, AIConfiguration.profile(appContext).maxOutputTokens),
                "stop" to Sampling.STOP
            )

            // Prefere launchCompletion (API publique LlamaAndroid)
            val launch = llama.javaClass.methods.firstOrNull { m ->
                m.name == "launchCompletion" && m.parameterTypes.size == 2
            }
            if (launch != null) {
                android.util.Log.i(
                    "VanelleLlama",
                    "sampling: temp=${Sampling.TEMPERATURE} top_p=${Sampling.TOP_P} " +
                        "top_k=${Sampling.TOP_K} min_p=${Sampling.MIN_P} " +
                        "rep=${Sampling.PENALTY_REPEAT} n_predict=$nPredict"
                )
                val result = launch.invoke(llama, ctxId, params)
                extractCompletionText(result)
            } else {
                // Fallback : completion directe sur le contexte
                val getCtx = llama.javaClass.methods.firstOrNull { it.name.contains("context", true) }
                null
            }
        } catch (e: Exception) {
            android.util.Log.w("VanelleLlama", "invokeCompletionWithSampling failed: ${e.message}")
            null
        }
    }

    private fun extractCompletionText(result: Any?): String? {
        if (result == null) return null
        if (result is String && result.isNotBlank()) return result.trim()
        if (result is Map<*, *>) {
            val keys = listOf("text", "content", "generation", "result", "fullText", "response")
            for (k in keys) {
                val v = result[k]
                if (v is String && v.isNotBlank()) return v.trim()
            }
            // Parfois la map est imbriquee
            for ((_, v) in result) {
                if (v is String && v.length > 2) return v.trim()
            }
        }
        // toString last resort si structure inconnue
        val s = result.toString()
        return if (s.length > 8) s.trim() else null
    }

    suspend fun answer(
        userPrompt: String,
        extraContext: String = "",
        fastMode: Boolean = false,
        maxTokensHint: Int = -1
    ): String = answerMutex.withLock {
        if (!ensureLoaded()) return@withLock NOT_READY
        val h = helper ?: return@withLock NOT_READY
        val klass = h.javaClass

        val profile = AIConfiguration.profile(appContext)
        val requestedMax = if (maxTokensHint > 0) maxTokensHint else adaptiveOutputBudget(userPrompt, fastMode)
        val effectiveMaxTokens = requestedMax.coerceIn(64, profile.maxOutputTokens)
        val formatted = buildPrompt(userPrompt, extraContext, fastMode)
        val timeoutMs = adaptiveTimeoutMs(formatted.length, fastMode, effectiveMaxTokens)

        return@withLock try {
            // Signature officielle (kotlinllamacpp / org.nehuatl.llamacpp.LlamaHelper) :
            //   fun predict(prompt: String, imagePath: String? = null, partialCompletion: Boolean = true)
            // JVM : predict(String, String, boolean) — le 3e argument est un boolean primitif.
            // predict() ne retourne rien : la réponse arrive via le SharedFlow<LLMEvent>
            // (Started / Ongoing(word,tokenCount) / Done / Error).
            // Priorité : signature à 3 args (la vraie), puis 2 args, puis fallback générique.
            val method3Args = try {
                klass.getMethod(
                    "predict",
                    String::class.java,
                    String::class.java,
                    Boolean::class.javaPrimitiveType
                )
            } catch (_: Exception) {
                try {
                    // Certaines builds exposent Boolean boxed au lieu de boolean primitif
                    klass.getMethod(
                        "predict",
                        String::class.java,
                        String::class.java,
                        Boolean::class.java
                    )
                } catch (_: Exception) { null }
            }
            val method2Args = try {
                klass.getMethod("predict", String::class.java, String::class.java)
            } catch (_: Exception) { null }
            val method1Arg = try {
                klass.getMethod("predict", String::class.java)
            } catch (_: Exception) { null }

            val predictMethod = method3Args ?: method2Args ?: method1Arg
                ?: listOf("predict", "generate", "complete", "chat", "ask")
                    .asSequence()
                    .flatMap { name -> klass.methods.asSequence().filter { it.name == name } }
                    .filter { it.parameterTypes.isNotEmpty() && String::class.java.isAssignableFrom(it.parameterTypes[0]) }
                    .sortedByDescending { it.parameterTypes.size } // préférer la version complète
                    .firstOrNull()
                ?: run {
                    val allNames = klass.methods.map { it.name }.distinct().sorted()
                    AiLoadDiagnostics.logFailure(
                        appContext,
                        "Réponse : aucune méthode de génération trouvée sur la bibliothèque IA " +
                            "(predict/generate/complete/chat/ask absentes). Méthodes disponibles : $allNames"
                    )
                    return@withLock NOT_READY
                }

            // Construction robuste des arguments :
            // - arg0 = prompt (String)
            // - imagePath (String?) = null → texte seul
            // - partialCompletion (boolean/Boolean) = true (défaut bibliothèque)
            // Ne jamais passer null à un paramètre primitif (boolean/int/long) → crash « got null ».
            fun buildArgs(method: java.lang.reflect.Method, prompt: String): Array<Any?> {
                val types = method.parameterTypes
                return Array(types.size) { idx ->
                    val type = types[idx]
                    when {
                        idx == 0 -> prompt
                        type == Boolean::class.javaPrimitiveType || type == Boolean::class.java -> true
                        type == Int::class.javaPrimitiveType || type == Integer::class.java -> 0
                        type == Long::class.javaPrimitiveType || type == java.lang.Long::class.java -> 0L
                        type == Float::class.javaPrimitiveType || type == java.lang.Float::class.java -> 0f
                        type == Double::class.javaPrimitiveType || type == java.lang.Double::class.java -> 0.0
                        CharSequence::class.java.isAssignableFrom(type) || type == String::class.java -> null // imagePath
                        else -> null
                    }
                }
            }

            // Best-effort, aligné sur le cycle de vie officiel de la démo (stopPrediction() est
            // appelé après Done/Error) : évite de laisser le moteur natif "en génération" et de
            // casser l'appel suivant.
            fun stopPredictionQuietly() {
                try { klass.getMethod("stopPrediction").invoke(h) } catch (_: Exception) {}
            }

            // Important : le SharedFlow a un buffer. Sans drain, les événements d'une
            // génération précédente (souvent une intro générique) sont rejoués à l'infini.
            drainEventsBuffer()

            withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<String> { cont ->
                    val job = scope.launch {
                        try {
                            val sb = StringBuilder((effectiveMaxTokens * 6).coerceAtMost(4096))
                            var tokenApprox = 0
                            var doneFullText: String? = null
                            var generationStarted = false
                            var stopRequested = false

                            val collector = launch {
                                try {
                                    // On s'arrête UNIQUEMENT sur Done / Error — jamais au milieu d'un Ongoing
                                    // (sinon phrases coupées comme « Mais pour commen »).
                                    events.takeWhile { event ->
                                        val name = event.javaClass.simpleName
                                        when {
                                            name == "Started" -> {
                                                generationStarted = true
                                                true
                                            }
                                            !generationStarted -> true
                                            name == "Ongoing" -> {
                                                val word = extractToken(event)
                                                if (word.isNotEmpty()) {
                                                    sb.append(word)
                                                    tokenApprox++
                                                }
                                                // Limite atteinte → demande l'arrêt natif, mais continue jusqu'à Done
                                                if (!stopRequested &&
                                                    (tokenApprox >= effectiveMaxTokens || sb.length >= effectiveMaxTokens * 4)
                                                ) {
                                                    stopRequested = true
                                                    stopPredictionQuietly()
                                                }
                                                true
                                            }
                                            name == "Done" -> {
                                                doneFullText = extractFullText(event)
                                                false
                                            }
                                            name == "Error" -> {
                                                val msg = extractToken(event).ifEmpty {
                                                    try {
                                                        event.javaClass.getMethod("getMessage").invoke(event)?.toString()
                                                    } catch (_: Exception) { null } ?: "erreur inconnue"
                                                }
                                                AiLoadDiagnostics.logFailure(appContext, "Réponse : événement Error du modèle — $msg")
                                                false
                                            }
                                            else -> {
                                                val word = extractToken(event)
                                                if (word.isNotEmpty()) {
                                                    sb.append(word)
                                                    tokenApprox++
                                                }
                                                true
                                            }
                                        }
                                    }.collect { }
                                } catch (_: Exception) {}
                            }

                            yield()
                            val args = buildArgs(predictMethod, formatted)
                            // Utilise l'API publique predict() de llamacpp-kotlin.
                            // Elle est explicitement documentée pour le streaming Ongoing/Done
                            // et évite de dépendre de champs privés du moteur natif.
                            android.util.Log.i(
                                "VanelleLlama",
                                "predict via ${predictMethod.name}(${predictMethod.parameterTypes.joinToString { it.simpleName }}) " +
                                    "promptLen=${formatted.length} (fallback sans sampling map)"
                            )
                            predictMethod.invoke(h, *args)
                            withTimeoutOrNull(timeoutMs) { collector.join() }
                            collector.cancel()
                            stopPredictionQuietly()

                            // Préférer le texte complet de Done (allText bibliothèque) s'il est plus long
                            val fromStream = sb.toString().trim()
                            val fromDone = doneFullText?.trim().orEmpty()
                            var text = when {
                                fromDone.length >= fromStream.length && fromDone.isNotBlank() -> fromDone
                                fromStream.isNotBlank() -> fromStream
                                else -> fromDone
                            }
                                .removePrefix("assistant")
                                .trim()

                            // Nettoie une coupure en fin de mot si stop anticipé
                            text = finalizeAnswer(text)

                            // Filet anti-intro générique côté moteur
                            if (text.isNotBlank() && looksLikeGenericIntro(text)) {
                                AiLoadDiagnostics.logFailure(
                                    appContext,
                                    "Réponse : intro générique rejetée (« ${text.take(60)}… »)."
                                )
                                text = ""
                            }

                            if (text.isBlank()) {
                                AiLoadDiagnostics.logFailure(
                                    appContext,
                                    "Réponse : aucune sortie exploitable reçue de predict() " +
                                        "(méthode=${predictMethod.name}, args=${predictMethod.parameterCount}, " +
                                        "started=$generationStarted, tokens≈$tokenApprox)."
                                )
                            } else {
                                try {
                                    UsageStats.recordLocalReply(appContext, text.length, 0L)
                                } catch (_: Exception) {}
                                AiLoadDiagnostics.logSuccess(
                                    appContext,
                                    "génération OK (${text.length} car., ~$tokenApprox jetons) : ${text.take(80)}"
                                )
                            }
                            if (cont.isActive) {
                                cont.resume(text.ifBlank { NOT_READY })
                            }
                        } catch (e: Exception) {
                            stopPredictionQuietly()
                            val detail = when (e) {
                                is IllegalArgumentException ->
                                    "appel predict() — ${e.message ?: "argument invalide (souvent null passé à un boolean primitif)"}"
                                is java.lang.reflect.InvocationTargetException ->
                                    "predict() a levé : ${e.cause?.message ?: e.message ?: e.javaClass.simpleName}"
                                else ->
                                    "exception pendant la génération — ${e.message ?: e.javaClass.simpleName}"
                            }
                            AiLoadDiagnostics.logFailure(appContext, "Réponse : $detail")
                            if (cont.isActive) cont.resume(NOT_READY)
                        }
                    }
                    cont.invokeOnCancellation { job.cancel(); stopPredictionQuietly() }
                }
            } ?: run {
                stopPredictionQuietly()
                AiLoadDiagnostics.logFailure(appContext, "Réponse : délai dépassé (${timeoutMs}ms) sans réponse du modèle.")
                NOT_READY
            }
        } catch (e: Exception) {
            AiLoadDiagnostics.logFailure(appContext, "Réponse : exception — ${e.message ?: e.javaClass.simpleName}")
            NOT_READY
        }
    }

    /**
     * Best-effort : essaye d'avaler d'éventuels événements résiduels sans bloquer.
     * La vraie protection reste le flag generationStarted (ignore tout jusqu'au prochain Started).
     */
    private suspend fun drainEventsBuffer() {
        // no-op volontairement léger — le gate generationStarted suffit.
        // (un collect infini sur SharedFlow bloquerait ou ajouterait de la latence)
    }

    /**
     * Finalise une réponse éventuellement coupée :
     * - retire un dernier mot tronqué (ex. « commen »)
     * - assure une ponctuation de fin si la phrase était presque complète
     */


    private fun finalizeAnswer(raw: String): String {
        var t = raw.trim()
        if (t.isEmpty()) return t
        t = t.removePrefix("assistant").removePrefix("Assistant")
            .removePrefix("Assistant:").removePrefix("assistant:")
            .trim()
        t = sanitizeNaturalText(t)
        t = trimIncompleteSentence(t)
        if (t.isEmpty()) return t
        if (t.first().isLowerCase()) {
            t = t.replaceFirstChar { it.uppercaseChar() }
        }
        if (t.length > 20 && t.last() !in listOf('.', '!', '?', '…', '»', '"', '\'')) {
            if (' ' in t) t = t.trimEnd(',', ';', ':', ' ') + "."
        }
        return t
    }

    /** Texte naturel : aucune suite de symboles $ # * etc. */
    private fun sanitizeNaturalText(s: String): String {
        var t = s
        // Tokens speciaux modeles
        t = Regex("""<\|[^|>]+\|>""").replace(t, " ")
        t = Regex("""</?s>""").replace(t, " ")
        t = Regex("""\[/?INST\]""").replace(t, " ")
        t = Regex("""\[/?SYS\]""").replace(t, " ")
        // Balises HTML / markdown
        t = Regex("""</?[a-zA-Z][^>]*>""").replace(t, " ")
        t = Regex("""\*\*([^*]+)\*\*""").replace(t, "$1")
        t = Regex("""\*([^*]+)\*""").replace(t, "$1")
        t = Regex("""__([^_]+)__""").replace(t, "$1")
        t = Regex("""`{1,3}[^`]*`{1,3}""").replace(t, " ")
        t = Regex("""#{1,6}\s*""").replace(t, "")
        // Suites de symboles parasites ($#***, ===, ---, etc.)
        t = Regex("""[$#*%_=~^|\\\\/]{2,}""").replace(t, " ")
        t = Regex("""[{}\[\]]{2,}""").replace(t, " ")
        // Symboles isoles parasites en debut/fin de mot
        t = Regex("""(^|\s)[$#*%_=]{1,}(\s|$)""").replace(t, " ")
        // Lignes type "BROUILLON:" / "RÉPONSE:" residuelles
        t = Regex("""(?im)^\s*(BROUILLON|RÉPONSE|REPONSE|FAITS|DÉDUCTIONS|DEDUCTIONS)\s*:\s*""").replace(t, "")
        t = Regex("""[ \t]{2,}""").replace(t, " ")
        t = Regex("""\n{3,}""").replace(t, "\n\n")
        return t.trim().trimStart('.', ',', ';', ':', '-', ' ')
    }

    private fun trimIncompleteSentence(s: String): String {
        var t = s.trim()
        if (t.length < 12) return t
        if (t.last() in listOf('.', '!', '?', '…', '»', '"', '\'')) return t
        val lastSpace = t.lastIndexOf(' ')
        if (lastSpace > t.length * 2 / 3) {
            val lastWord = t.substring(lastSpace + 1)
            // Mot coupe (tres court et sans voyelle = souvent token tronque)
            if (lastWord.length <= 2) {
                val cut = t.substring(0, lastSpace).trimEnd(',', ';', ':', ' ')
                if (cut.length >= 8) return cut + "."
            }
        }
        return t
    }


    private fun looksLikeGenericIntro(text: String): Boolean {
        val t = text.trim()
        if (t.length > 400) return false
        val lower = t.lowercase()
        val markers = listOf(
            "je suis vanelle",
            "votre assistante personnelle",
            "assistante personnelle, chaleureuse",
            "chaleureuse et précise",
            "qu'est-ce que vous souhaitez accomplir",
            "que souhaitez-vous accomplir",
            "conseils personnalisés",
            "trouver des solutions et à résoudre",
            "comment puis-je vous aider aujourd"
        )
        val hits = markers.count { lower.contains(it) }
        return hits >= 2 || (hits >= 1 && t.length < 260)
    }

    private fun extractToken(event: Any): String {
        for (method in listOf("getWord", "getToken", "getText", "getContent", "getMessage")) {
            try {
                val v = event.javaClass.getMethod(method).invoke(event)
                if (v is String && v.isNotEmpty()) return v
            } catch (_: Exception) {}
        }
        try {
            for (f in event.javaClass.declaredFields) {
                f.isAccessible = true
                val v = f.get(event)
                if (v is String && v.isNotEmpty() && v.length < 200) return v
            }
        } catch (_: Exception) {}
        // Kotlin data class properties sometimes only exposed as componentN / fields without getter
        try {
            val comp1 = event.javaClass.getMethod("component1").invoke(event)
            if (comp1 is String && comp1.isNotEmpty()) return comp1
        } catch (_: Exception) {}
        return ""
    }

    /** Pour LLMEvent.Done(fullText, tokenCount, duration) — récupère le texte complet. */
    private fun extractFullText(event: Any): String? {
        for (method in listOf("getFullText", "getText", "getContent", "getMessage", "component1")) {
            try {
                val v = event.javaClass.getMethod(method).invoke(event)
                if (v is String && v.isNotEmpty()) return v
            } catch (_: Exception) {}
        }
        try {
            for (f in event.javaClass.declaredFields) {
                f.isAccessible = true
                val v = f.get(event)
                if (v is String && v.isNotEmpty()) return v
            }
        } catch (_: Exception) {}
        return null
    }

    /** Langue de reponse = langue du message utilisateur (heuristique legere). */
    private fun detectReplyLanguage(text: String): String {
        val s = text.lowercase()
        val scores = linkedMapOf(
            "francais" to listOf(" le ", " la ", " les ", " un ", " une ", " des ", " je ", " tu ", " est ", " quoi", " quel", " pour", " avec", " dans", " c'est", " pas "),
            "english" to listOf(" the ", " is ", " are ", " what", " how", " why", " please", " can ", " you ", " this ", " that "),
            "espanol" to listOf(" el ", " la ", " los ", " las ", " que ", " como", " por ", " para ", " esta", " hola"),
            "arabic" to listOf(" في ", " من ", " على ", " ما ", " هل ", " هذا", " هذه"),
            "portugues" to listOf(" nao ", " você", " voce", " para ", " como ", " que ", " uma ", " os "),
            "deutsch" to listOf(" der ", " die ", " das ", " und ", " ist ", " was ", " wie ", " nicht "),
            "italiano" to listOf(" che ", " non ", " una ", " per ", " come ", " cosa", " sono ")
        )
        val padded = " ${s.replace(Regex("[^\\p{L}\\s]"), " ")} "
        var best = "francais"
        var bestScore = 0
        for ((lang, cues) in scores) {
            val sc = cues.count { padded.contains(it) }
            if (sc > bestScore) {
                bestScore = sc
                best = lang
            }
        }
        // Script arabe dominant
        if (s.any { it in '\u0600'..'\u06FF' }) return "arabe"
        // CJK
        if (s.any { it in '\u4e00'..'\u9fff' }) return "chinois"
        if (bestScore == 0) return "francais"
        return best
    }

    private fun buildPrompt(userPrompt: String, extraContext: String, fastMode: Boolean): String {
        val langHint = detectReplyLanguage(userPrompt)
        // System prompt Vanelle officiel (version compacte pour petit contexte mobile)
        val system = buildString {
            append("Tu es Vanelle, une assistante IA personnelle utile, naturelle et attentive. ")
            append("Tu réponds directement à la demande, comme une conversation normale. ")
            append("Tu comprends les questions courtes comme les demandes détaillées et tu adaptes la longueur de ta réponse. ")
            append("Tu peux expliquer, comparer, résumer, traduire, rédiger, calculer et aider à résoudre un problème. ")
            append("Tu tutoies l'utilisateur. Ton ton est chaleureux, calme, clair et naturel, sans phrases toutes faites ni présentation inutile. ")
            append("Si une information est incertaine ou absente de ton contexte, dis-le franchement au lieu d'inventer. ")
            append("Si on demande qui tu es, réponds simplement que tu es Vanelle, l'assistante personnelle de l'utilisateur. ")
            append("Ne révèle pas le nom du modèle sous-jacent sauf si c'est explicitement nécessaire dans un contexte technique.\n")
            append("LANGUE: réponds dans la même langue que l'utilisateur, en respectant son registre.\n")
            append("STYLE: texte propre, naturel et directement lisible. N'écris jamais de balises techniques, de chaînes de contrôle, de fragments de prompt ou de suites de symboles. Évite le Markdown décoratif.")
            append("N'affiche jamais ton raisonnement interne. Donne directement la réponse utile. ")
            append("Tu peux utiliser une ponctuation normale, des paragraphes et des listes simples lorsque cela améliore la compréhension.\n")
            append("FAITS: si le contexte fournit des faits externes, utilise-les fidèlement. Si les données manquent, indique clairement la limite au lieu de compléter au hasard.\n")
            append("ACTIONS telephone utiles: premiere ligne ACTION:TYPE|arg ")
            append("(YOUTUBE|q OPEN_APP|nom CALL|nom MESSAGE|nom|texte SEARCH|q MAPS|lieu ")
            append("TIMER|min FLASHLIGHT|on/off VOLUME|up/down SCREEN_SUMMARY CLICK|texte). ")
            append("Sinon aucune ligne ACTION.\n")
            append("REFUS poli: armes, explosifs, drogues, contenu sexuel mineurs, piratage, ")
            append("automutilation/suicide (oriente vers aide, ex. 3114 FR), haine, usurpation. ")
            append("Formule: \"Je ne peux pas t'aider avec ca, desolee.\" + alternative sure si utile.\n")
            append("Pas de conseil medical/juridique/financier engageant. Neutre sur politique/religion. ")
            append("Ne critique jamais l'utilisateur. Le texte final doit être directement lisible et agréable à entendre à voix haute.")
            if (fastMode) append(" Mode rapide: reponse tres courte.")
        }
        val profile = AIConfiguration.profile(appContext)
        val totalChars = profile.maxPromptChars
        val ctxBudget = (totalChars * 0.62).toInt().coerceAtLeast(300)
        val userBudget = (totalChars - ctxBudget).coerceIn(450, 2800)
        val ctx = extraContext.trim().take(ctxBudget)
        val user = userPrompt.trim().take(userBudget)

        return buildString {
            append("<|im_start|>system\n")
            append(system)
            if (ctx.isNotBlank()) {
                append("\n\nContexte:\n")
                append(ctx)
            }
            append("<|im_end|>\n")
            append("<|im_start|>user\n")
            append(user)
            append("<|im_end|>\n")
            append("<|im_start|>assistant\n")
        }
    }

    /** Budget de sortie dynamique : une question simple ne doit pas payer le coût d'une longue génération. */
    private fun adaptiveOutputBudget(text: String, fastMode: Boolean): Int {
        val t = text.trim()
        if (fastMode) return 96
        if (t.length <= 70 && !ReasoningHelper.isComplex(t)) return 128
        if (t.length <= 180 && !ReasoningHelper.isComplex(t)) return 192
        if (t.length <= 400) return 256
        return 320
    }

    private fun adaptiveTimeoutMs(promptChars: Int, fastMode: Boolean, maxTokens: Int): Long {
        val p = AIConfiguration.profile(appContext)
        val base = if (fastMode) 7_000L else 10_000L
        // Le préfill dépend du prompt ; la génération dépend surtout du nombre de tokens demandé.
        val extra = (promptChars / 20).toLong() * 15L
        val generation = (maxTokens * 45L).coerceAtMost(14_000L)
        return min(45_000L, max(base, base + extra + generation))
    }

    companion object {
        const val NOT_READY = "__LLAMA_NOT_READY__"

        @Volatile private var instance: LocalLlamaHelper? = null

        fun get(context: Context): LocalLlamaHelper {
            instance?.let { return it }
            synchronized(this) {
                instance?.let { return it }
                val created = LocalLlamaHelper(context.applicationContext)
                instance = created
                return created
            }
        }
    }
}
