import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vanelle.os"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vanelle.os"
        // minSdk 24 requis par la dépendance io.github.ljcamargo:llamacpp-kotlin:0.4.0
        // (déclarée sans flavor "legacy" séparé dans ce build unique — un minSdk < 24
        // provoque un échec de fusion de manifeste : "uses-sdk:minSdkVersion 23 cannot be
        // smaller than version 24 declared in library [io.github.ljcamargo:llamacpp-kotlin]").
        minSdk = 24
        targetSdk = 35
        versionCode = 61
        versionName = "2.4.1"
    }


    buildFeatures {
        // Le modèle GGUF reste toujours externe à l'APK.
        buildConfig = false
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
            // Le modèle GGUF est externe à l'APK. Une mise à jour de l'APK par-dessus
            // l'installation existante conserve le fichier du modèle et évite un nouveau téléchargement.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/*.kotlin_module"
            )
        }
    }

    androidResources {
        noCompress += listOf("tflite", "gguf")
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        // llamacpp-kotlin 0.4.0 est compilé avec metadata Kotlin 2.3 ;
        // on autorise la lecture pour éviter l'échec CI (stdlib + module natif).
        freeCompilerArgs.add("-Xskip-metadata-version-check")
    }
}

configurations.all {
    resolutionStrategy {
        // Aligner la stdlib sur le compilateur du projet (évite le pull 2.3.20 non géré)
        force(
            "org.jetbrains.kotlin:kotlin-stdlib:2.1.10",
            "org.jetbrains.kotlin:kotlin-stdlib-jdk7:2.1.10",
            "org.jetbrains.kotlin:kotlin-stdlib-jdk8:2.1.10",
            "org.jetbrains.kotlin:kotlin-stdlib-common:2.1.10",
            "androidx.core:core:1.15.0",
            "androidx.core:core-ktx:1.15.0"
        )
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.2.0")
    // Le moteur local est unique : pas de variante de test ni de moteur simulé.
    implementation("io.github.ljcamargo:llamacpp-kotlin:0.4.0")
}
