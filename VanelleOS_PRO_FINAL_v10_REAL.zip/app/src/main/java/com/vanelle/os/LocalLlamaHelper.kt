package com.vanelle.os
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.jvm.functions.Function1

/**
 * Wrapper autour de io.github.ljcamargo:llamacpp-kotlin.
 *
 * IMPORTANT — pourquoi la réflexion plutôt qu'un import direct :
 * Le nom exact du package Kotlin exposé par cette bibliothèque (compilée en natif,
 * classes.jar dans un .aar) n'est documenté nulle part officiellement — seule
 * l'utilisation "LlamaHelper" sans import qualifié apparaît dans le README.
 * Un import direct (ex: "org.nehuatl.llamacpp.LlamaHelper") ferait planter TOUTE
 * la compilation ("unresolved reference") si le nom réel diffère, sur un simple
 * détail qu'on ne peut pas vérifier sans build réel.
 * En passant par la réflexion, la compilation réussit dans tous les cas : si le
 * nom de classe est correct, l'IA locale fonctionne normalement ; sinon,
 * ensureLoaded() échoue proprement et l'appelant bascule automatiquement sur
 * FreeAIHelper (voir CommandInterpreter, qui teste déjà NOT_READY).
 *
 * Autres corrections conservées :
 * - Plus de collect infini → plus de hang
 * - Timeout de sécurité
 * - Prompt formaté pour Llama-3.2-Instruct (meilleures réponses)
 * - Chargement unique thread-safe
 */
class LocalLlamaHelper(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val events = MutableSharedFlow<Any>(extraBufferCapacity = 256)

    @Volatile private var loaded = false
    @Volatile private var loading = false
    @Volatile private var helper: Any? = null
    private val answerMutex = Mutex()

    /** Résout dynamiquement le premier nom de classe candidat qui existe réellement sur le classpath. */
    private fun resolveLlamaClass(): Class<*>? {
        val candidates = listOf(
            "org.nehuatl.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacppkotlin.LlamaHelper",
            "com.ljcamargo.llamacpp.LlamaHelper"
        )
        for (name in candidates) {
            try {
                return Class.forName(name)
            } catch (_: ClassNotFoundException) {
                // essaie le suivant
            }
        }
        return null
    }

    private suspend fun ensureLoaded(): Boolean {
        if (loaded && helper != null) return true
        if (!LlamaModelManager.isReady(context)) return false
        if (loading) {
            repeat(50) {
                kotlinx.coroutines.delay(200)
                if (loaded && helper != null) return true
            }
            return false
        }
        loading = true
        return try {
            val klass = resolveLlamaClass() ?: return false
            val ctor = klass.getConstructor(
                android.content.ContentResolver::class.java,
                CoroutineScope::class.java,
                MutableSharedFlow::class.java
            )
            val h = ctor.newInstance(context.contentResolver, scope, events)
            val modelUri = Uri.fromFile(LlamaModelManager.modelFile(context)).toString()

            val loadMethod = klass.getMethod(
                "load",
                String::class.java,
                Int::class.javaPrimitiveType,
                String::class.java,
                Function1::class.java
            )

            val ok = withTimeoutOrNull(180_000L) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    try {
                        val callback = object : Function1<Any?, Unit> {
                            override fun invoke(p1: Any?) {
                                if (cont.isActive) cont.resume(true)
                            }
                        }
                        loadMethod.invoke(h, modelUri, 2048, null, callback)
                    } catch (_: Exception) {
                        if (cont.isActive) cont.resume(false)
                    }
                }
            } ?: false
            if (ok) {
                helper = h
                loaded = true
            }
            ok
        } catch (_: Exception) {
            false
        } finally {
            loading = false
        }
    }

    suspend fun warmUp(): Boolean = answerMutex.withLock {
        withContext(Dispatchers.IO) { ensureLoaded() }
    }

    suspend fun answer(userPrompt: String, extraContext: String = ""): String = answerMutex.withLock {
        if (!ensureLoaded()) return@withLock NOT_READY
        val h = helper ?: return@withLock NOT_READY
        val klass = h.javaClass

        // Template chat Llama-3.2-Instruct → réponses naturelles en français
        val formatted = buildString {
            append("<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n")
            append("Tu es Vanelle, l'assistante personnelle de VanelleOS. Tu parles exactement comme un humain intelligent, pas comme un robot.\n")
            append("Tu comprends les intentions, les émotions, les idées implicites et le contexte. Tu anticipes ce que la personne veut vraiment.\n")
            append("Quand on te pose une question : réponds clairement, avec l'essentiel d'abord, comme un pro bienveillant.\n")
            append("Quand on te demande d'agir : confirme en une phrase naturelle ce que tu fais (ex: « D'accord, j'ouvre Maps. »).\n")
            append("Ton : chaleureux, concis (1 à 4 phrases), français courant et correct. Jamais de « En tant qu'IA » ni de listes robotiques.\n")
            append("Si tu ne sais pas : dis-le simplement et propose une piste utile.\n")
            append(PersonalityPrefs.systemTone(context) + "\n")
            if (extraContext.isNotBlank()) {
                append("Contexte utilisateur (à utiliser discrètement) :\n")
                append(extraContext.take(800) + "\n")
            }

            append("<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n")
            append(userPrompt.trim())
            append("\n<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n")
        }

        return@withLock try {
            val predictMethod = try {
                klass.getMethod("predict", String::class.java, String::class.java)
            } catch (_: NoSuchMethodException) {
                null
            }
            if (predictMethod == null) return@withLock NOT_READY

            withTimeoutOrNull(90_000L) {
                suspendCancellableCoroutine<String> { cont ->
                    val job = scope.launch {
                        try {
                            val sb = StringBuilder()

                            // IMPORTANT : s'abonner AVANT predict(). MutableSharedFlow n'a pas de replay,
                            // donc l'ancien ordre pouvait perdre tous les tokens et donner l'impression
                            // que l'IA était absente ou bloquée.
                            val collector = launch {
                                events.takeWhile { event ->
                                    when (event.javaClass.simpleName) {
                                        "Ongoing" -> {
                                            val word = try {
                                                (event.javaClass.getMethod("getWord").invoke(event) as? String).orEmpty()
                                            } catch (_: Exception) { "" }
                                            sb.append(word)
                                            true
                                        }
                                        "Done", "Error" -> false
                                        else -> true
                                    }
                                }.collect { }
                            }

                            // Laisse le collecteur s'enregistrer avant de déclencher l'inférence native.
                            kotlinx.coroutines.yield()
                            predictMethod.invoke(h, formatted, null)
                            collector.join()

                            if (cont.isActive) {
                                cont.resume(sb.toString().trim().ifBlank { NOT_READY })
                            }
                        } catch (_: Exception) {
                            if (cont.isActive) cont.resume(NOT_READY)
                        }
                    }
                    cont.invokeOnCancellation { job.cancel() }
                }
            } ?: NOT_READY
        } catch (_: Exception) {
            NOT_READY
        }
    }

    companion object {
        const val NOT_READY = "__LLAMA_NOT_READY__"
    }
}
