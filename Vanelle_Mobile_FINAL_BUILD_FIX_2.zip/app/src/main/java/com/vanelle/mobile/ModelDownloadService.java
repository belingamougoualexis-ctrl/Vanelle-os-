package com.vanelle.mobile;
import android.app.*;import android.content.*;import android.os.*;
public class ModelDownloadService extends Service {
  public static final String ACTION_MODEL="MODEL"; private EngineManager em;
  @Override public void onCreate(){super.onCreate();em=new EngineManager(this);if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("vanelle_download","Vanelle",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(ch);}}
  @Override public int onStartCommand(Intent i,int flags,int id){startForeground(42,notification("Préparation du téléchargement…")); if(i!=null && "runtime".equals(i.getStringExtra("what")))em.downloadRuntime(new P(id));else em.downloadModel(new P(id));return START_NOT_STICKY;}
  private Notification notification(String s){Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"vanelle_download"):new Notification.Builder(this);return b.setContentTitle("Vanelle").setContentText(s).setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true).build();}
  private class P implements EngineManager.Progress{int id;P(int i){id=i;}public void onUpdate(String p,long d,long t){String s=t>0?p+" — "+(d*100/t)+" %":"Installation du moteur…";((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(42,notification(s));}public void onError(Exception e){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(42,notification("Échec : "+e.getMessage()));stopForeground(STOP_FOREGROUND_DETACH);stopSelf(id);}public void onDone(){stopForeground(STOP_FOREGROUND_REMOVE);stopSelf(id);}}
  public android.os.IBinder onBind(Intent i){return null;}
}
