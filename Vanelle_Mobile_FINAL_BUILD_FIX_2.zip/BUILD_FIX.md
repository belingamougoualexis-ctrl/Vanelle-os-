# Vanelle Mobile — build fix

## Errors fixed from GitHub Actions run #33614639429

1. `reference to Process is ambiguous`
   - `MainActivity` now uses `java.lang.Process` explicitly.
   - This avoids the collision with `android.os.Process` imported through `android.os.*`.

2. `cannot find symbol CountDownLatch`
   - Added `java.util.concurrent.CountDownLatch` import.

3. Model size metadata corrected
   - SmolLM2 360M Q4_K_M GGUF is 270,590,528 bytes according to the upstream Hugging Face file metadata.

4. Runtime checksum retained and verified against the official llama.cpp b10516 Android arm64 release.

The build log shows that Gradle reached Java compilation successfully; the failure is limited to these Java compile errors, not Android resource processing.
