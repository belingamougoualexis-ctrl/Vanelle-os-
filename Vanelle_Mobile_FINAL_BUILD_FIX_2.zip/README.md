# Vanelle Mobile 1.0.0

Conversion native Android du projet Vanelle.

## Architecture
- Android natif Java, sans WebGPU/WebView pour l'inférence locale.
- llama.cpp Android ARM64 téléchargé à la première installation.
- SmolLM2-360M-Instruct Q4_K_M GGUF (~271 MB) téléchargé séparément.
- Téléchargements reprenables avec fichier `.part`, HTTP Range, 6 tentatives et contrôle SHA-256.
- Contrôle d'espace disque avant téléchargement.
- Runtime et modèle ne sont utilisés qu'après validation du hash.
- llama-server est lancé sur `127.0.0.1:8080` et le chat utilise l'API OpenAI-compatible locale.
- Onglet « Moteur » permet installation, rechargement et suppression.

## Compilation
1. Ouvrir ce dossier dans Android Studio récent.
2. Laisser Gradle installer le plugin Android et les composants SDK.
3. Compiler `app:assembleDebug`.
4. APK : `app/build/outputs/apk/debug/app-debug.apk`.

## Compatibilité
- Android 8.0+ (API 26+).
- ARM64-v8a recommandé/nécessaire pour le runtime llama.cpp fourni.
- Prévoir au moins ~800 MB libres pour téléchargement, extraction, modèle et fichiers temporaires.

## Sources des artefacts
Runtime : llama.cpp Android ARM64 release b10516.
Modèle : mfuntowicz/SmolLM2-360M-Instruct-Q4_K_M-GGUF.

Important : l'application refuse un fichier modèle/runtime dont la somme SHA-256 ne correspond pas à la version attendue. Cela évite de lancer un téléchargement partiellement ou incorrectement reçu.
