import { create } from "zustand";
import {
  ensureLocalEngine,
  getLocalProgress,
  isLocalReady,
  reloadLocalEngine,
  subscribeLocalProgress,
  type LocalProgress,
} from "./local-engine";

type EngineState = {
  vanelleReady: boolean;
  probed: boolean;
  detail: string;
  probing: boolean;
  progress: number;
  status: LocalProgress["status"];
  /** Lance / relance le téléchargement + chargement en mémoire */
  probe: () => Promise<void>;
  /** Alias explicite */
  loadLocal: () => Promise<void>;
};

function mapDetail(p: LocalProgress): string {
  switch (p.status) {
    case "ready":
      return "Vanelle locale prête — modèle chargé en mémoire de travail.";
    case "downloading":
      return p.text
        ? `Téléchargement du modèle… ${Math.round(p.progress * 100)} % — ${p.text}`
        : `Téléchargement du modèle… ${Math.round(p.progress * 100)} %`;
    case "loading":
      return p.text
        ? `Chargement en mémoire… ${Math.round(p.progress * 100)} % — ${p.text}`
        : `Chargement en mémoire GPU… ${Math.round(p.progress * 100)} %`;
    case "checking":
      return "Préparation du moteur Vanelle local…";
    case "unsupported":
      return (
        p.text ||
        "WebGPU non disponible. Ajoutez un moteur externe (Ollama local, Groq, OpenAI…)."
      );
    case "error":
      return p.error || p.text || "Échec du chargement du moteur local.";
    default:
      return "Vérification du moteur Vanelle…";
  }
}

export const useEngineStore = create<EngineState>((set, get) => {
  // Sync progress from local-engine
  if (typeof window !== "undefined") {
    subscribeLocalProgress((p) => {
      set({
        vanelleReady: p.status === "ready",
        probed: p.status !== "idle" && p.status !== "checking",
        detail: mapDetail(p),
        probing: p.status === "downloading" || p.status === "loading" || p.status === "checking",
        progress: p.progress,
        status: p.status,
      });
    });
  }

  return {
    vanelleReady: isLocalReady(),
    probed: false,
    detail: "Vérification du moteur Vanelle…",
    probing: false,
    progress: 0,
    status: "idle",

    probe: async () => {
      if (get().probing && get().status !== "error") return;
      set({ probing: true });
      try {
        await ensureLocalEngine();
        const p = getLocalProgress();
        set({
          vanelleReady: p.status === "ready",
          probed: true,
          detail: mapDetail(p),
          probing: false,
          progress: p.progress,
          status: p.status,
        });
      } catch (e) {
        const msg = e instanceof Error ? e.message : "Impossible de charger le moteur local.";
        set({
          vanelleReady: false,
          probed: true,
          detail: msg,
          probing: false,
          progress: 0,
          status: "error",
        });
      }
    },

    loadLocal: async () => {
      await get().probe();
    },
  };
});

/** Appelé une fois au montage de l'UI pour démarrer le téléchargement auto */
export function startLocalEngineOnBoot() {
  if (typeof window === "undefined") return;
  void useEngineStore.getState().probe();
}

export async function forceReloadLocalEngine() {
  try {
    await reloadLocalEngine();
    const p = getLocalProgress();
    useEngineStore.setState({
      vanelleReady: p.status === "ready",
      probed: true,
      detail: mapDetail(p),
      probing: false,
      progress: p.progress,
      status: p.status,
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Rechargement échoué";
    useEngineStore.setState({
      vanelleReady: false,
      probed: true,
      detail: msg,
      probing: false,
      status: "error",
    });
  }
}
