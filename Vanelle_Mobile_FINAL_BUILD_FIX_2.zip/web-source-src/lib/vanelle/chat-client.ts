import { uid } from "@/lib/utils";
import { vanelleChat, type ApiTool, type EngineSpec } from "./server-chat";
import { localChat, isLocalReady } from "./local-engine";
import { retrieveKnowledge } from "./rag";
import { buildSystemPrompt } from "./prompt";
import { Secrets } from "./secrets";
import type { ChatAttachment, ChatMessage, Profile, VanelleAI } from "./types";
import { VANELLE_ENGINE_ID } from "./types";
import { useEngineStore } from "./engine-store";

function resolveEngine(ai: VanelleAI, profile: Profile, vanelleReady: boolean): EngineSpec {
  const wanted = ai.engineId || profile.activeEngineId || VANELLE_ENGINE_ID;
  if (wanted === VANELLE_ENGINE_ID) {
    if (vanelleReady) return { kind: "vanelle" };
    const fallback = profile.engines[0];
    if (fallback) {
      return {
        kind: "openai",
        endpoint: fallback.endpoint,
        model: fallback.model,
        apiKey: Secrets.get(fallback.id),
      };
    }
    return { kind: "vanelle" };
  }
  const eng = profile.engines.find((e) => e.id === wanted);
  if (!eng) {
    return vanelleReady ? { kind: "vanelle" } : { kind: "vanelle" };
  }
  return {
    kind: "openai",
    endpoint: eng.endpoint,
    model: eng.model,
    apiKey: Secrets.get(eng.id),
  };
}

function humanError(raw: string): string {
  const map: Record<string, string> = {
    "vanelle-indisponible":
      "Aucun moteur IA n'est prêt. Attendez la fin du téléchargement Vanelle (barre à gauche), ou ouvrez ⋮ → Moteurs IA pour ajouter un moteur externe.",
    "reponse-vide": "Le moteur a renvoyé une réponse vide. Réessayez ou changez de modèle.",
    "https-requis": "L'endpoint du moteur doit commencer par https:// (http autorisé seulement pour localhost / Ollama).",
    "modele-requis": "Indiquez l'identifiant du modèle pour ce moteur.",
    "endpoint-invalide": "Endpoint du moteur invalide.",
    "webgpu-indisponible":
      "WebGPU n'est pas disponible sur ce navigateur. Utilisez Chrome ou Edge récents, ou ajoutez un moteur externe (Ollama, Groq…).",
    "hote-prive-interdit": "Les hôtes privés distants sont interdits pour des raisons de sécurité.",
    "url-invalide": "URL du moteur invalide.",
    "protocole-interdit": "Protocole non autorisé (utilisez https ou http://localhost).",
    "origine-non-autorisee": "Origine non autorisée pour cet appel API.",
  };
  if (map[raw]) return map[raw];

  // Messages HTTP bruts → message lisible
  const httpMatch = raw.match(/^HTTP\s+(\d+)\s*(.*)$/i);
  if (httpMatch) {
    const code = httpMatch[1];
    const rest = (httpMatch[2] || "").trim();
    if (code === "401" || code === "403") {
      return rest
        ? `Accès refusé (${code}) : ${rest}. Vérifiez votre clé API et les droits du modèle.`
        : `Accès refusé (${code}). Vérifiez votre clé API et les droits du modèle.`;
    }
    if (code === "404") {
      return rest
        ? `Ressource introuvable (404) : ${rest}. Vérifiez l'endpoint et le nom du modèle.`
        : "Endpoint ou modèle introuvable (404). Vérifiez l'URL et l'identifiant du modèle.";
    }
    if (code === "429") {
      return "Trop de requêtes (429). Attendez un moment ou utilisez un autre moteur.";
    }
    if (code === "500" || code === "502" || code === "503") {
      return `Le service du moteur est momentanément indisponible (${code}). Réessayez plus tard.`;
    }
    return rest ? `Erreur réseau (${code}) : ${rest}` : `Erreur réseau (${code}).`;
  }

  // Si c'est déjà un message lisible, le renvoyer tel quel
  if (raw.length > 12 && !/^[a-z0-9_-]+$/i.test(raw)) return raw;
  return `Le moteur n'a pas répondu : ${raw}`;
}

export async function generateReply(opts: {
  ai: VanelleAI;
  profile: Profile;
  history: ChatMessage[];
  userText: string;
  attachments: ChatAttachment[];
  vanelleReady: boolean;
}): Promise<{ text: string; usedKnowledge: { source: string; score: number }[]; usedApis: string[] }> {
  const { ai, profile, history, userText, attachments, vanelleReady } = opts;
  const knowledge = retrieveKnowledge(ai, userText, 8);
  const system = buildSystemPrompt(ai, knowledge);

  const textAttachments = attachments.filter((a) => a.kind === "text" && a.content);
  const imageAttachments = attachments.filter((a) => a.kind === "image" && a.dataUrl);

  const attachedBlock = textAttachments.map((a) => `[Fichier joint : ${a.name}]\n${a.content}`).join("\n\n");
  const userTextRemote =
    [userText, attachedBlock].filter(Boolean).join("\n\n") ||
    (imageAttachments.length ? "Décris cette image." : "");

  // Pour le moteur local (texte uniquement pour le moment)
  const prior = history
    .filter((m) => m.text && m.text !== "…")
    .slice(-6)
    .map((m) => ({
      role: (m.who === "user" ? "user" : "assistant") as "user" | "assistant",
      content: m.text,
    }));

  const engine = resolveEngine(ai, profile, vanelleReady);

  // ——— Vanelle = local uniquement (WebLLM) ———
  if (engine.kind === "vanelle") {
    if (!vanelleReady || !isLocalReady()) {
      const st = useEngineStore.getState();
      if (st.probing || st.status === "downloading" || st.status === "loading") {
        throw new Error(
          `Le moteur Vanelle est encore en cours de chargement (${Math.round(st.progress * 100)} %). Attendez la fin du téléchargement, ou ouvrez ⋮ → Moteurs IA pour ajouter un moteur externe.`,
        );
      }
      throw new Error(humanError("vanelle-indisponible"));
    }

    let userContent = userTextRemote;
    if (imageAttachments.length) {
      userContent =
        (userTextRemote || "") +
        "\n\n[Note : des images ont été jointes mais le moteur local ultra-léger ne les analyse pas encore.]";
    }

    try {
      const text = await localChat(
        [
          { role: "system", content: system },
          ...prior,
          { role: "user", content: userContent },
        ],
        { maxTokens: ai.maxTokens ?? 512, temperature: ai.temperature ?? 0.4 },
      );
      return {
        text,
        usedKnowledge: knowledge.slice(0, 6).map((k) => ({ source: k.source, score: k.score })),
        usedApis: [],
      };
    } catch (e) {
      const msg = e instanceof Error ? e.message : "erreur-locale";
      throw new Error(humanError(msg));
    }
  }

  // ——— Chemin externe (OpenAI-compatible via serveur) ———
  const userContent =
    imageAttachments.length > 0
      ? [
          { type: "text" as const, text: userTextRemote },
          ...imageAttachments.map((a) => ({
            type: "image_url" as const,
            image_url: { url: a.dataUrl! },
          })),
        ]
      : userTextRemote;

  const apis: ApiTool[] = (ai.apis || []).map((a) => ({
    id: a.id,
    nom: a.nom,
    endpoint: a.endpoint,
    method: a.method || "AUTO",
    description: a.description,
    apiKey: Secrets.get(a.id),
  }));

  const result = await vanelleChat({
    data: {
      messages: [{ role: "system", content: system }, ...prior, { role: "user", content: userContent }],
      engine,
      apis,
      maxTokens: ai.maxTokens ?? 800,
      temperature: ai.temperature ?? 0.4,
    },
  });

  if (!result.ok) {
    throw new Error(humanError(result.error || "erreur-inconnue"));
  }

  return {
    text: result.text,
    usedKnowledge: knowledge.slice(0, 6).map((k) => ({ source: k.source, score: k.score })),
    usedApis: result.usedApis || [],
  };
}

export function newMsg(partial: Omit<ChatMessage, "id" | "ts"> & { id?: string; ts?: number }): ChatMessage {
  return {
    id: partial.id || uid(),
    ts: partial.ts || Date.now(),
    who: partial.who,
    text: partial.text,
    attachments: partial.attachments,
    usedKnowledge: partial.usedKnowledge,
    usedApis: partial.usedApis,
  };
}
