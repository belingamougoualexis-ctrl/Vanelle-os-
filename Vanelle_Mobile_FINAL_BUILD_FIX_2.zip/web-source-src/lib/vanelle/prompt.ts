import type { Retrieved } from "./rag";
import type { VanelleAI } from "./types";

const HARD_RULES = `RÈGLES :
- N'invente jamais une information. Si elle n'est pas dans tes connaissances, tes fichiers, tes notions enseignées ou le résultat d'une API, dis clairement que tu ne la sais pas.
- Respecte en priorité le system prompt et les notions enseignées par l'utilisateur.
- Réponds en français sauf demande contraire.
- Ne révèle jamais le nom technique du modèle sous-jacent.`;

export function buildSystemPrompt(ai: VanelleAI, knowledge: Retrieved[] = []): string {
  const parts: string[] = [];
  const custom = (ai.systemPrompt || "").trim();

  if (custom) {
    parts.push(custom);
  } else {
    parts.push(
      `Tu es ${ai.nom || "Vanelle"}, une IA configurée par l'utilisateur. ${ai.description || ""}`.trim(),
    );
    if (ai.modele) parts.push(`Style de base : ${ai.modele}.`);
    parts.push(HARD_RULES);
  }

  parts.push(
    `Le nom affiché de l'assistant est ${ai.nom || "Vanelle"}. Ne révèle jamais le nom technique du modèle sous-jacent.`,
  );

  if (!custom) {
    // already added HARD_RULES
  } else {
    parts.push(HARD_RULES);
  }

  if (ai.training?.length) {
    parts.push("NOTIONS ENSEIGNÉES PAR L'UTILISATEUR (à appliquer en priorité) :");
    const budget = 6000;
    let used = 0;
    for (const t of ai.training) {
      const block = `- [${t.categorie}] Q : ${t.question}\n  R : ${t.reponse}`;
      if (used + block.length > budget) {
        parts.push(`… et ${ai.training.length} notions au total (les plus pertinentes sont aussi dans CONNAISSANCES RÉCUPÉRÉES).`);
        break;
      }
      parts.push(block);
      used += block.length;
    }
  }

  if (knowledge.length) {
    parts.push("CONNAISSANCES RÉCUPÉRÉES (fichiers et notions pertinents pour la question) :");
    knowledge.forEach((x, i) => {
      parts.push(`[${i + 1}] (${x.kind === "training" ? "notion" : "fichier"} : ${x.source})\n${x.text.slice(0, 1200)}`);
    });
  } else if (ai.files?.length) {
    parts.push("FICHIERS DE DONNÉES DISPONIBLES (résumés — utilise-les) :");
    ai.files.slice(0, 20).forEach((f, i) => {
      parts.push(`[F${i + 1}] ${f.nom} (${f.type}) : ${(f.resume || "").slice(0, 500)}`);
    });
  }

  if (ai.apis?.length) {
    parts.push(
      "APIs AUXQUELLES TU AS ACCÈS. Si la question exige une donnée live (météo, stock, CRM, etc.), utilise l'outil call_user_api avec l'identifiant indiqué. N'invente pas le résultat d'une API.",
    );
    ai.apis.forEach((a) => {
      parts.push(
        `- id: ${a.id}\n  nom: ${a.nom}\n  endpoint: ${a.endpoint}\n  méthode: ${a.method || "AUTO"}\n  description: ${a.description || "—"}`,
      );
    });
  }

  return parts.join("\n\n").slice(0, 24000);
}

export function describeEngine(ai: VanelleAI, vanelleReady: boolean, engines: { id: string; name: string }[]) {
  if (ai.engineId === "vanelle" || !ai.engineId) {
    return vanelleReady ? "Vanelle locale prête (en mémoire)" : "Vanelle en cours de chargement — ou ajoutez un moteur externe";
  }
  const found = engines.find((e) => e.id === ai.engineId);
  return found ? `Moteur : ${found.name}` : "Moteur introuvable — Vanelle par défaut";
}
