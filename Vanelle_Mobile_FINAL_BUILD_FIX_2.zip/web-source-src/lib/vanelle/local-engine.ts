/**
 * Moteur Vanelle local — WebLLM (navigateur uniquement).
 *
 * Chargement unique et direct :
 * - CreateMLCEngine (API officielle, chemin le plus stable)
 * - Cache navigateur → 2e ouverture instantanée
 * - Modèle officiel prebuilt : SmolLM2-360M-Instruct-q4f16_1-MLC
 * - Tokens / température = config utilisateur de l'IA
 */

import {
  CreateMLCEngine,
  prebuiltAppConfig,
  type MLCEngineInterface,
  type InitProgressReport,
  type AppConfig,
} from "@mlc-ai/web-llm";

/** ID exact dans la liste officielle WebLLM — ne pas changer */
export const VANELLE_LOCAL_MODEL_ID = "SmolLM2-360M-Instruct-q4f16_1-MLC";

const CONTEXT_WINDOW = 2048;

const appConfig: AppConfig = {
  ...prebuiltAppConfig,
  cacheBackend: "cache",
};

export type LocalEngineStatus =
  | "idle"
  | "checking"
  | "downloading"
  | "loading"
  | "ready"
  | "error"
  | "unsupported";

export type LocalProgress = {
  status: LocalEngineStatus;
  progress: number;
  text: string;
  error?: string;
};

type ProgressListener = (p: LocalProgress) => void;

let engine: MLCEngineInterface | null = null;
let loadPromise: Promise<MLCEngineInterface> | null = null;
let lastProgress: LocalProgress = {
  status: "idle",
  progress: 0,
  text: "Moteur local en attente…",
};
const listeners = new Set<ProgressListener>();

function emit(p: LocalProgress) {
  lastProgress = p;
  listeners.forEach((fn) => {
    try {
      fn(p);
    } catch {
      /* ignore */
    }
  });
}

export function subscribeLocalProgress(fn: ProgressListener): () => void {
  listeners.add(fn);
  fn(lastProgress);
  return () => listeners.delete(fn);
}

export function getLocalProgress(): LocalProgress {
  return lastProgress;
}

export function isLocalReady(): boolean {
  return lastProgress.status === "ready" && engine !== null;
}

export function getLocalEngine(): MLCEngineInterface | null {
  return engine;
}

function hasWebGPU(): boolean {
  return typeof navigator !== "undefined" && !!(navigator as Navigator & { gpu?: unknown }).gpu;
}

function onInitProgress(report: InitProgressReport) {
  const p = Math.min(1, Math.max(0, report.progress ?? 0));
  const text = report.text || "Chargement…";
  const lower = text.toLowerCase();
  const downloading =
    lower.includes("fetch") ||
    lower.includes("download") ||
    lower.includes("cache") ||
    lower.includes("load model from") ||
    lower.includes("loading model") ||
    p < 0.85;
  emit({
    status: downloading ? "downloading" : "loading",
    progress: p,
    text:
      p >= 0.99
        ? "Chargement en mémoire GPU…"
        : text.replace(/^\[.*?\]\s*/, "") || text,
  });
}

/**
 * Un seul chemin de chargement : API officielle CreateMLCEngine.
 * Idempotent (singleton) — jamais de double téléchargement.
 */
export async function ensureLocalEngine(
  modelId: string = VANELLE_LOCAL_MODEL_ID,
): Promise<MLCEngineInterface> {
  if (engine) return engine;
  if (loadPromise) return loadPromise;

  if (!hasWebGPU()) {
    emit({
      status: "unsupported",
      progress: 0,
      text: "WebGPU requis. Ouvrez l’app dans Chrome ou Edge, ou ajoutez un moteur externe.",
      error: "webgpu-indisponible",
    });
    throw new Error("webgpu-indisponible");
  }

  loadPromise = (async () => {
    emit({
      status: "checking",
      progress: 0.02,
      text: "Préparation du moteur Vanelle…",
    });

    const eng = await CreateMLCEngine(
      modelId,
      {
        appConfig,
        initProgressCallback: onInitProgress,
        logLevel: "warn",
      },
      {
        context_window_size: CONTEXT_WINDOW,
        temperature: 0.4,
        top_p: 0.9,
        repetition_penalty: 1.05,
      },
    );

    engine = eng;
    emit({
      status: "ready",
      progress: 1,
      text: "Vanelle prête — modèle en mémoire.",
    });
    return eng;
  })();

  // Si une erreur remonte, on libère la promesse pour permettre un nouvel appel manuel
  loadPromise = loadPromise.catch((e) => {
    const msg = e instanceof Error ? e.message : "Chargement interrompu";
    engine = null;
    loadPromise = null;
    emit({ status: "error", progress: 0, text: msg, error: msg });
    throw e;
  });

  return loadPromise;
}

export async function reloadLocalEngine(
  modelId: string = VANELLE_LOCAL_MODEL_ID,
): Promise<MLCEngineInterface> {
  try {
    if (engine) {
      await (engine as { unload?: () => Promise<void> }).unload?.();
    }
  } catch {
    /* ignore */
  }
  engine = null;
  loadPromise = null;
  emit({ status: "idle", progress: 0, text: "Chargement du moteur…" });
  return ensureLocalEngine(modelId);
}

export type LocalChatMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

function trimMessages(messages: LocalChatMessage[], maxChars = 6000): LocalChatMessage[] {
  if (messages.length <= 2) return messages;
  const system = messages[0]?.role === "system" ? [messages[0]] : [];
  const rest = system.length ? messages.slice(1) : messages.slice();
  let total = system.reduce((n, m) => n + m.content.length, 0);
  const kept: LocalChatMessage[] = [];
  for (let i = rest.length - 1; i >= 0; i--) {
    const m = rest[i];
    if (total + m.content.length > maxChars && kept.length >= 2) break;
    kept.unshift(m);
    total += m.content.length;
  }
  return [...system, ...kept];
}

/** Inférence locale — maxTokens / temperature = config de l'IA utilisateur */
export async function localChat(
  messages: LocalChatMessage[],
  opts?: { maxTokens?: number; temperature?: number },
): Promise<string> {
  const eng = await ensureLocalEngine();
  if (!eng) throw new Error("Moteur local non disponible");

  const maxTokens = Math.min(Math.max(opts?.maxTokens ?? 512, 32), 1024);
  const temperature = Math.min(Math.max(opts?.temperature ?? 0.4, 0), 1.5);
  const trimmed = trimMessages(messages);

  const reply = await eng.chat.completions.create({
    messages: trimmed,
    temperature,
    max_tokens: maxTokens,
    stream: false,
  });

  const choice = (reply as { choices?: { message?: { content?: string | null } }[] })?.choices?.[0];
  const text = (choice?.message?.content || "").trim();
  if (!text) throw new Error("Réponse vide du moteur.");
  return text;
}
