import { createServerFn } from "@tanstack/react-start";

type ContentPart =
  | { type: "text"; text: string }
  | { type: "image_url"; image_url: { url: string } };

type ToolCall = {
  id: string;
  type?: string;
  function: { name: string; arguments: string };
};

type ChatMsg = {
  role: "system" | "user" | "assistant" | "tool";
  content: string | ContentPart[] | null;
  tool_call_id?: string;
  name?: string;
  tool_calls?: ToolCall[];
};

export type ApiTool = {
  id: string;
  nom: string;
  endpoint: string;
  method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE" | "AUTO";
  description: string;
  apiKey?: string;
};

export type EngineSpec =
  | { kind: "vanelle" }
  | { kind: "openai"; endpoint: string; model: string; apiKey: string };

export type ChatRequest = {
  messages: ChatMsg[];
  engine: EngineSpec;
  apis?: ApiTool[];
  maxTokens?: number;
  temperature?: number;
};

function isPrivateHost(host: string) {
  const h = host.toLowerCase();
  if (h === "localhost" || h.endsWith(".localhost") || h === "0.0.0.0") return true;
  if (h === "::1" || h.startsWith("[::1]")) return true;
  if (/^127\./.test(h)) return true;
  if (/^10\./.test(h)) return true;
  if (/^192\.168\./.test(h)) return true;
  if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(h)) return true;
  if (/^169\.254\./.test(h)) return true;
  if (h === "metadata.google.internal") return true;
  return false;
}

function assertSafeUrl(raw: string, allowedOrigin?: string) {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new Error("url-invalide");
  }
  const isLocal = url.hostname === "localhost" || url.hostname === "127.0.0.1";
  if (url.protocol === "http:") {
    if (!isLocal) throw new Error("https-requis");
  } else if (url.protocol !== "https:") {
    throw new Error("protocole-interdit");
  }
  if (!isLocal && isPrivateHost(url.hostname)) throw new Error("hote-prive-interdit");
  if (allowedOrigin) {
    const allowed = new URL(allowedOrigin);
    if (url.origin !== allowed.origin) throw new Error("origine-non-autorisee");
  }
  return url;
}

function joinUrl(endpoint: string, path?: string) {
  if (!path) return endpoint;
  try {
    return new URL(path, endpoint.endsWith("/") ? endpoint : endpoint + "/").toString();
  } catch {
    return endpoint;
  }
}

async function callUserApi(
  api: ApiTool,
  args: { method?: string; path?: string; query?: Record<string, string>; body?: unknown },
) {
  const target = joinUrl(api.endpoint, args.path);
  const url = assertSafeUrl(target, api.endpoint);
  if (args.query) {
    for (const [k, v] of Object.entries(args.query)) url.searchParams.set(k, v);
  }
  const method = (args.method || (api.method !== "AUTO" ? api.method : "GET")).toUpperCase();
  const headers: Record<string, string> = { Accept: "application/json, text/plain, */*" };
  if (api.apiKey) headers.Authorization = `Bearer ${api.apiKey}`;
  const init: RequestInit = { method, headers };
  if (method !== "GET" && method !== "HEAD" && args.body != null) {
    headers["Content-Type"] = "application/json";
    init.body = typeof args.body === "string" ? args.body : JSON.stringify(args.body);
  }
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 20000);
  try {
    const res = await fetch(url.toString(), { ...init, signal: ctrl.signal });
    const text = await res.text();
    return JSON.stringify({
      status: res.status,
      ok: res.ok,
      body: text.slice(0, 8000),
    });
  } finally {
    clearTimeout(t);
  }
}

function chatCompletionsUrl(endpoint: string) {
  const base = endpoint.trim().replace(/\/+$/, "");
  if (base.endsWith("/chat/completions")) return base;
  if (base.endsWith("/v1")) return base + "/chat/completions";
  return base + "/chat/completions";
}

async function complete(opts: {
  url: string;
  apiKey: string;
  model: string;
  messages: ChatMsg[];
  tools?: unknown[];
  maxTokens: number;
  temperature?: number;
}) {
  const body: Record<string, unknown> = {
    model: opts.model,
    messages: opts.messages,
    temperature: opts.temperature ?? 0.4,
    max_tokens: opts.maxTokens,
  };
  if (opts.tools?.length) {
    body.tools = opts.tools;
    body.tool_choice = "auto";
  }
  const res = await fetch(opts.url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${opts.apiKey}`,
    },
    body: JSON.stringify(body),
  });
  const json = (await res.json().catch(() => null)) as {
    error?: { message?: string };
    choices?: {
      message?: {
        content?: string | null;
        tool_calls?: ToolCall[];
      };
    }[];
  } | null;
  if (!res.ok) {
    const msg = json?.error?.message || `HTTP ${res.status}`;
    throw new Error(msg);
  }
  return json?.choices?.[0]?.message || { content: "" };
}

export const probeVanelleEngine = createServerFn({ method: "GET" }).handler(async () => {
  // Vanelle = moteur local WebLLM côté navigateur uniquement (pas de cloud).
  return {
    ready: false,
    name: "Vanelle",
    model: "local-webllm",
    detail: "Moteur local côté navigateur (WebLLM). Le statut réel est géré dans le client.",
  };
});

export const vanelleChat = createServerFn({ method: "POST" })
  .validator((input: ChatRequest) => input)
  .handler(async ({ data }) => {
    const maxTokens = Math.min(Math.max(data.maxTokens ?? 700, 64), 1600);
    const temperature = Math.min(Math.max(data.temperature ?? 0.4, 0), 1.5);
    const apis = data.apis || [];

    let url: string;
    let apiKey: string;
    let model: string;

    if (data.engine.kind === "vanelle") {
      // Pas de cloud : l'inférence Vanelle se fait uniquement en local (WebLLM) côté client.
      return { ok: false as const, error: "vanelle-indisponible", text: "", usedApis: [] as string[] };
    } else {
      try {
        assertSafeUrl(data.engine.endpoint);
      } catch (e) {
        return {
          ok: false as const,
          error: e instanceof Error ? e.message : "endpoint-invalide",
          text: "",
          usedApis: [] as string[] ,
        };
      }
      if (!data.engine.model?.trim()) {
        return { ok: false as const, error: "modele-requis", text: "", usedApis: [] as string[] };
      }
      url = chatCompletionsUrl(data.engine.endpoint);
      apiKey = data.engine.apiKey || "";
      model = data.engine.model.trim();
    }

    const tools = apis.length
      ? [
          {
            type: "function",
            function: {
              name: "call_user_api",
              description:
                "Appelle une API configurée par l'utilisateur. Utilise l'id d'API fourni dans le system prompt.",
              parameters: {
                type: "object",
                properties: {
                  api_id: { type: "string", description: "Identifiant de l'API" },
                  method: { type: "string", enum: ["GET", "POST", "PUT", "PATCH", "DELETE"] },
                  path: { type: "string", description: "Chemin relatif optionnel" },
                  query: { type: "object", additionalProperties: { type: "string" } },
                  body: { description: "Corps JSON optionnel" },
                },
                required: ["api_id"],
              },
            },
          },
        ]
      : undefined;

    const messages: ChatMsg[] = data.messages.map((m) => ({ ...m }));
    const usedApis: string[] = [];

    try {
      for (let hop = 0; hop < 4; hop++) {
        const msg = await complete({ url, apiKey, model, messages, tools, maxTokens, temperature });
        const calls = msg.tool_calls || [];
        if (!calls.length) {
          const text = (msg.content || "").trim();
          if (!text) return { ok: false as const, error: "reponse-vide", text: "", usedApis };
          return { ok: true as const, text, usedApis };
        }
        messages.push({
          role: "assistant",
          content: msg.content || "",
          tool_calls: calls,
        });
        for (const call of calls) {
          let args: {
            api_id?: string;
            method?: string;
            path?: string;
            query?: Record<string, string>;
            body?: unknown;
          } = {};
          try {
            args = JSON.parse(call.function.arguments || "{}");
          } catch {
            args = {};
          }
          const api = apis.find((a) => a.id === args.api_id) || apis.find((a) => a.nom === args.api_id);
          let result: string;
          if (!api) {
            result = JSON.stringify({ error: "api-inconnue", api_id: args.api_id });
          } else {
            usedApis.push(api.nom);
            try {
              result = await callUserApi(api, args);
            } catch (e) {
              result = JSON.stringify({
                error: e instanceof Error ? e.message : "api-echec",
              });
            }
          }
          messages.push({
            role: "tool",
            tool_call_id: call.id,
            name: "call_user_api",
            content: result,
          });
        }
      }
      return { ok: false as const, error: "trop-d-appels-api", text: "", usedApis };
    } catch (e) {
      return {
        ok: false as const,
        error: e instanceof Error ? e.message : "inference-echec",
        text: "",
        usedApis,
      };
    }
  });
