import type { VanelleAI } from "./types";

const STOP = new Set([
  "les", "des", "une", "un", "le", "la", "de", "du", "et", "ou", "en", "au", "aux",
  "pour", "par", "pas", "que", "qui", "dans", "sur", "avec", "sans", "est", "sont",
  "the", "and", "for", "you", "your", "are", "this", "that", "with", "from",
]);

function tokens(text: string): string[] {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .split(/[^a-z0-9àâäéèêëïîôöùûüç]+/i)
    .map((w) => w.trim())
    .filter((w) => w.length > 2 && !STOP.has(w));
}

export type Retrieved = {
  sourceId: string;
  source: string;
  text: string;
  kind: "training" | "file";
  score: number;
};

export function retrieveKnowledge(ai: VanelleAI, query: string, k = 8): Retrieved[] {
  const qTokens = tokens(query);
  if (!qTokens.length && !query.trim()) return [];

  const docs: Omit<Retrieved, "score">[] = [];
  for (const t of ai.training || []) {
    docs.push({
      sourceId: t.id,
      source: t.question,
      text: `${t.question}\n${t.reponse}`,
      kind: "training",
    });
  }
  for (const f of ai.files || []) {
    const chunks = f.chunks?.length ? f.chunks : [{ id: f.id, text: f.resume || "" }];
    for (const c of chunks) {
      if (!c.text) continue;
      docs.push({
        sourceId: f.id,
        source: f.nom,
        text: c.text,
        kind: "file",
      });
    }
  }
  if (!docs.length) return [];

  const qSet = new Set(qTokens);
  const scored = docs.map((d) => {
    const dTokens = tokens(d.text);
    if (!dTokens.length) return { ...d, score: 0 };
    let overlap = 0;
    for (const w of dTokens) if (qSet.has(w)) overlap++;
    const uniqueHit = dTokens.filter((w) => qSet.has(w)).length;
    const phrase = query.trim().length > 4 && d.text.toLowerCase().includes(query.trim().toLowerCase()) ? 2 : 0;
    const trainingBoost = d.kind === "training" ? 0.4 : 0;
    const score = overlap / Math.sqrt(dTokens.length) + uniqueHit * 0.15 + phrase + trainingBoost;
    return { ...d, score };
  });

  const filtered = scored.filter((x) => x.score > 0.15).sort((a, b) => b.score - a.score);
  const top = (filtered.length ? filtered : scored.sort((a, b) => b.score - a.score)).slice(0, k);

  // Always include training items even if score is low — they are explicit teaching.
  const have = new Set(top.map((t) => t.sourceId));
  for (const t of ai.training || []) {
    if (have.has(t.id)) continue;
    top.push({
      sourceId: t.id,
      source: t.question,
      text: `${t.question}\n${t.reponse}`,
      kind: "training",
      score: 0.5,
    });
  }
  return top.slice(0, Math.max(k, (ai.training || []).length + 4));
}
