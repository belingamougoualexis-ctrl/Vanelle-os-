import { useState } from "react";
import { toast } from "sonner";
import { uid } from "@/lib/utils";
import { Secrets } from "@/lib/vanelle/secrets";
import type { Profile, UserEngine, VanelleAI } from "@/lib/vanelle/types";
import { VANELLE_ENGINE_ID } from "@/lib/vanelle/types";
import { Button, Input, Label } from "./ui";

export function EngineList({
  profile,
  onChange,
  ai,
  onPickEngine,
}: {
  profile: Profile;
  onChange: (p: Profile) => void | Promise<void>;
  ai?: VanelleAI;
  onPickEngine?: (engineId: string) => void | Promise<void>;
}) {
  const [name, setName] = useState("");
  const [endpoint, setEndpoint] = useState("");
  const [model, setModel] = useState("");
  const [key, setKey] = useState("");
  const selected = ai?.engineId || profile.activeEngineId || VANELLE_ENGINE_ID;

  async function add() {
    const ep = endpoint.trim().replace(/\/+$/, "");
    const md = model.trim();
    const nm = name.trim() || md || "Moteur externe";
    if (!ep || !md) {
      toast.error("Indiquez un endpoint et un modèle.");
      return;
    }
    if (!/^https:\/\//i.test(ep) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?/i.test(ep)) {
      toast.error("HTTPS obligatoire (http seulement pour localhost / Ollama).");
      return;
    }
    const eng: UserEngine = { id: uid(), name: nm, kind: "openai", endpoint: ep, model: md, ts: Date.now() };
    Secrets.set(eng.id, key);
    const next: Profile = {
      ...profile,
      engines: [...profile.engines, eng],
      activeEngineId: profile.activeEngineId || eng.id,
    };
    await onChange(next);
    if (onPickEngine) await onPickEngine(eng.id);
    setName("");
    setEndpoint("");
    setModel("");
    setKey("");
    toast.success(`${nm} ajouté.`);
  }

  async function remove(id: string) {
    Secrets.remove(id);
    const engines = profile.engines.filter((e) => e.id !== id);
    await onChange({
      ...profile,
      engines,
      activeEngineId: profile.activeEngineId === id ? VANELLE_ENGINE_ID : profile.activeEngineId,
    });
    if (ai?.engineId === id && onPickEngine) await onPickEngine(VANELLE_ENGINE_ID);
  }

  return (
    <div>
      {onPickEngine ? (
        <div className="mb-3">
          <Label>Moteur utilisé par cette IA</Label>
          <div className="flex flex-col gap-1.5">
            <label className="flex min-h-11 items-center gap-2 rounded-md border border-line px-3 text-sm">
              <input
                type="radio"
                name="engine"
                checked={selected === VANELLE_ENGINE_ID}
                onChange={() => void onPickEngine(VANELLE_ENGINE_ID)}
              />
              Vanelle locale (navigateur, en mémoire)
            </label>
            {profile.engines.map((e) => (
              <label key={e.id} className="flex min-h-11 items-center gap-2 rounded-md border border-line px-3 text-sm">
                <input type="radio" name="engine" checked={selected === e.id} onChange={() => void onPickEngine(e.id)} />
                <span className="flex-1">
                  {e.name} <span className="text-ink-soft">· {e.model}</span>
                </span>
              </label>
            ))}
          </div>
        </div>
      ) : null}

      {profile.engines.length === 0 && !onPickEngine ? (
        <p className="text-[12.5px] text-ink-soft">Aucun moteur externe pour l'instant.</p>
      ) : null}

      {profile.engines.map((e) => (
        <div key={e.id} className="flex items-center justify-between border-b border-line py-2.5 last:border-0">
          <div>
            <strong className="text-sm">{e.name}</strong>
            <div className="text-[11.5px] text-ink-soft">
              {e.endpoint} · {e.model}
              {Secrets.get(e.id) ? " · clé enregistrée" : ""}
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={() => void remove(e.id)}>
            Retirer
          </Button>
        </div>
      ))}

      <div className="mt-4 rounded-lg bg-mist p-3.5">
        <div className="text-[12.5px] font-semibold">Ajouter un moteur / une API LLM</div>
        <Label>Nom</Label>
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex. Groq, OpenAI, Ollama" />
        <Label>Endpoint</Label>
        <Input
          value={endpoint}
          onChange={(e) => setEndpoint(e.target.value)}
          placeholder="https://api.groq.com/openai/v1"
        />
        <Label>Modèle</Label>
        <Input value={model} onChange={(e) => setModel(e.target.value)} placeholder="llama-3.1-8b-instant" />
        <Label>Clé API (stockée uniquement sur cet appareil)</Label>
        <Input type="password" value={key} onChange={(e) => setKey(e.target.value)} placeholder="sk-…" />
        <Button className="mt-3" block onClick={() => void add()}>
          Ajouter ce moteur
        </Button>
      </div>
    </div>
  );
}

export function ApiForm({
  onAdd,
}: {
  onAdd: (api: { nom: string; endpoint: string; cle: string; description: string; method: "GET" | "POST" | "AUTO" }) => void | Promise<void>;
}) {
  const [nom, setNom] = useState("");
  const [endpoint, setEndpoint] = useState("");
  const [cle, setCle] = useState("");
  const [description, setDescription] = useState("");
  const [method, setMethod] = useState<"GET" | "POST" | "AUTO">("AUTO");

  async function submit() {
    if (!nom.trim() || !endpoint.trim()) {
      toast.error("Indiquez au moins un nom et un endpoint.");
      return;
    }
    await onAdd({
      nom: nom.trim(),
      endpoint: endpoint.trim(),
      cle: cle.trim(),
      description: description.trim(),
      method,
    });
    setNom("");
    setEndpoint("");
    setCle("");
    setDescription("");
    setMethod("AUTO");
  }

  return (
    <div>
      <Label>Nom de l'API</Label>
      <Input value={nom} onChange={(e) => setNom(e.target.value)} placeholder="Ex. Météo, CRM, Stocks" />
      <Label>Endpoint URL</Label>
      <Input type="url" value={endpoint} onChange={(e) => setEndpoint(e.target.value)} placeholder="https://api.exemple.com/v1" />
      <Label>Méthode</Label>
      <select className="v-input" value={method} onChange={(e) => setMethod(e.target.value as "GET" | "POST" | "AUTO")}>
        <option value="AUTO">Auto</option>
        <option value="GET">GET</option>
        <option value="POST">POST</option>
      </select>
      <Label>Clé d'authentification (optionnel)</Label>
      <Input type="password" value={cle} onChange={(e) => setCle(e.target.value)} placeholder="Bearer token" />
      <Label>Description — à quoi sert cette API, quels paramètres</Label>
      <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Renvoie la météo pour une ville" />
      <Button variant="ghost" className="mt-2.5" block onClick={() => void submit()}>
        Ajouter l'API
      </Button>
    </div>
  );
}
