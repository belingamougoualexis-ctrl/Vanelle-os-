import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Card, PageHead } from "@/components/vanelle/ui";
import { Store } from "@/lib/vanelle/store";
import type { VanelleAI } from "@/lib/vanelle/types";

export const Route = createFileRoute("/_app/dashboard")({
  component: DashboardPage,
});

function DashboardPage() {
  const [ais, setAis] = useState<VanelleAI[]>([]);
  useEffect(() => {
    void Store.getAllAIs().then(setAis);
  }, []);
  const totalTraining = ais.reduce((s, a) => s + a.training.length, 0);
  const totalFiles = ais.reduce((s, a) => s + a.files.length, 0);
  const totalApis = ais.reduce((s, a) => s + a.apis.length, 0);
  const deployed = ais.filter((a) => a.deployed).length;

  const stats = [
    { num: ais.length, lbl: "IA créées" },
    { num: deployed, lbl: "déployées" },
    { num: totalTraining, lbl: "notions enseignées" },
    { num: totalFiles, lbl: "fichiers analysés" },
    { num: totalApis, lbl: "API connectées" },
  ];

  return (
    <>
      <PageHead eyebrow="Vue d'ensemble" title="Tableau de bord">
        L'état de tout ce que vous construisez ici.
      </PageHead>
      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {stats.map((s) => (
          <div key={s.lbl} className="v-card">
            <div className="font-sans text-[30px] font-extrabold tabular-nums text-accent">{s.num}</div>
            <div className="mt-0.5 text-[11.5px] font-semibold text-ink-soft">{s.lbl}</div>
          </div>
        ))}
      </div>
      <Card>
        <h2 className="mt-0 text-base font-bold">Progression par IA</h2>
        {ais.length === 0 ? (
          <p className="text-[13px] text-ink-soft">Rien à afficher pour l'instant.</p>
        ) : (
          ais.map((ai) => (
            <div key={ai.id} className="flex items-center justify-between border-b border-line py-2.5 last:border-0">
              <div>
                <Link to="/ia/$id" params={{ id: ai.id }} search={{ tab: "vue" }} className="font-semibold text-ink no-underline">
                  {ai.nom}
                </Link>
                <div className="text-[11.5px] text-ink-soft">
                  {ai.training.length} notions · {ai.files.length} fichiers · {ai.apis.length} API
                </div>
              </div>
            </div>
          ))
        )}
      </Card>
    </>
  );
}
