import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button, Card, Input, Label, PageHead, Tag } from "@/components/vanelle/ui";
import { EngineList } from "@/components/vanelle/engine-list";
import { useEngineStore } from "@/lib/vanelle/engine-store";
import { Store } from "@/lib/vanelle/store";
import type { Profile } from "@/lib/vanelle/types";
import { blankProfile } from "@/lib/vanelle/types";

export const Route = createFileRoute("/_app/compte")({
  component: ComptePage,
});

function ComptePage() {
  const [profile, setProfile] = useState<Profile>(blankProfile());
  const { vanelleReady, detail, probe } = useEngineStore();

  useEffect(() => {
    void Store.getProfile().then(setProfile);
  }, []);

  async function saveProfile() {
    await Store.saveProfile(profile);
    toast.success("Profil enregistré.");
  }

  async function exportAll() {
    const ais = await Store.getAllAIs();
    const blob = new Blob([JSON.stringify({ profile, ais }, null, 2)], { type: "application/json" });
    downloadBlob(blob, "vanelle-sauvegarde.json");
    toast.success("Sauvegarde téléchargée.");
  }

  async function importAll(file: File) {
    try {
      const data = JSON.parse(await file.text()) as { profile?: Profile; ais?: unknown[] };
      if (data.profile) {
        const next = { ...blankProfile(), ...data.profile, engines: data.profile.engines || profile.engines };
        await Store.saveProfile(next);
        setProfile(next);
      }
      if (Array.isArray(data.ais)) {
        for (const ai of data.ais) await Store.saveAI(ai as never);
      }
      toast.success("Sauvegarde importée.");
    } catch {
      toast.error("Ce fichier n'a pas pu être lu.");
    }
  }

  return (
    <>
      <PageHead eyebrow="Compte" title="Compte & moteurs">
        Vos IA restent dans ce navigateur. Le moteur Vanelle est un vrai modèle de langage, prêt immédiatement — pas un téléchargement fantôme. Vous pouvez aussi brancher une ou plusieurs API compatibles OpenAI.
      </PageHead>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <h2 className="mt-0 text-base font-bold">Profil</h2>
          <Label>Votre nom ou pseudo</Label>
          <Input
            value={profile.pseudo}
            onChange={(e) => setProfile({ ...profile, pseudo: e.target.value })}
            placeholder="Ex. Camille"
          />
          <Button className="mt-3.5" onClick={() => void saveProfile()}>
            Enregistrer
          </Button>
        </Card>
        <Card>
          <h2 className="mt-0 text-base font-bold">Sauvegarde</h2>
          <p className="text-[12.5px] text-ink-soft">
            Exportez toutes vos IA (config, apprentissage, fichiers analysés) ou récupérez une sauvegarde. Les clés API restent sur cet appareil.
          </p>
          <Button variant="ghost" size="sm" className="mt-3" onClick={() => void exportAll()}>
            Exporter toutes mes données
          </Button>
          <Label>Importer une sauvegarde (.json)</Label>
          <Input
            type="file"
            accept=".json"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void importAll(f);
            }}
          />
        </Card>
      </div>

      <Card className="mt-4">
        <h2 className="mt-0 flex items-center gap-2 text-base font-bold">
          Moteur Vanelle
          <Tag on={vanelleReady}>{vanelleReady ? "prêt" : "indisponible"}</Tag>
        </h2>
        <p className="text-[12.5px] leading-relaxed text-ink-soft">
          Vanelle n'attend plus un téléchargement local de 420 Mo. Le moteur est chargé côté serveur et répond dès le premier message. Chaque requête reçoit réellement : le system prompt, les notions enseignées, les extraits de vos fichiers (jusqu'à 3 Go à l'import), et les API que vous avez branchées.
        </p>
        <div className="mt-2 divide-y divide-line text-sm">
          <div className="flex justify-between py-2.5">
            <span>Moteur</span>
            <strong>Vanelle (Grok)</strong>
          </div>
          <div className="flex justify-between py-2.5">
            <span>Chargement</span>
            <strong>{vanelleReady ? "en mémoire de travail, prêt" : "non disponible"}</strong>
          </div>
          <div className="flex justify-between py-2.5">
            <span>Contexte</span>
            <strong>system prompt + fichiers + notions + API</strong>
          </div>
        </div>
        <p className="mt-2 font-display text-[11.5px] text-ink-soft">{detail}</p>
        <Button variant="ghost" size="sm" className="mt-3" onClick={() => void probe()}>
          Revérifier le moteur
        </Button>
      </Card>

      <Card className="mt-4">
        <h2 className="mt-0 text-base font-bold">Moteurs externes (plusieurs API)</h2>
        <p className="mb-3 text-[12.5px] text-ink-soft">
          Ajoutez autant d'endpoints compatibles OpenAI que vous voulez (OpenAI, Groq, Together, Ollama en local, vLLM…). Chaque IA peut en choisir un. Les mêmes moteurs sont aussi ajoutables depuis le chat (menu ⋮).
        </p>
        <EngineList
          profile={profile}
          onChange={async (next) => {
            setProfile(next);
            await Store.saveProfile(next);
          }}
        />
      </Card>
    </>
  );
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
