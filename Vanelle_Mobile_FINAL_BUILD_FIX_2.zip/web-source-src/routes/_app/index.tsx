import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Button, Card, Input, Label, PageHead, Select, Textarea } from "@/components/vanelle/ui";
import { Store } from "@/lib/vanelle/store";
import { blankAI } from "@/lib/vanelle/types";

export const Route = createFileRoute("/_app/")({
  component: CreerPage,
});

function CreerPage() {
  const navigate = useNavigate();
  const [nom, setNom] = useState("");
  const [description, setDescription] = useState("");
  const [modele, setModele] = useState("Généraliste");
  const [busy, setBusy] = useState(false);

  async function submit() {
    if (!nom.trim()) {
      toast.error("Donnez un nom à votre IA avant de continuer.");
      return;
    }
    setBusy(true);
    try {
      const ai = blankAI({ nom: nom.trim(), description: description.trim(), modele });
      await Store.saveAI(ai);
      toast.success(`${ai.nom} est créée. Enseignez-lui ce qu'elle doit savoir.`);
      await navigate({ to: "/ia/$id", params: { id: ai.id }, search: { tab: "vue" } });
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <PageHead eyebrow="Étape 0" title="Créer une nouvelle IA">
        Donnez-lui un nom et un point de départ. Tout le reste — ce qu'elle sait, les fichiers, les API — c'est vous qui le lui apprenez ensuite. Le moteur Vanelle est déjà prêt : chaque message utilisera vraiment votre system prompt, vos notions et vos documents.
      </PageHead>
      <Card className="max-w-[520px]">
        <Label>Nom de l'IA</Label>
        <Input value={nom} onChange={(e) => setNom(e.target.value)} placeholder="Ex. Solutions Pro" />
        <Label>Description</Label>
        <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="En une phrase, à quoi sert cette IA ?" />
        <Label>Style de base</Label>
        <Select value={modele} onChange={(e) => setModele(e.target.value)}>
          <option>Généraliste</option>
          <option>Expert technique</option>
          <option>Conseil & vente</option>
          <option>Support client</option>
          <option>Créatif</option>
        </Select>
        <Button className="mt-4.5" block disabled={busy} onClick={() => void submit()}>
          Commencer l'apprentissage
        </Button>
      </Card>
    </>
  );
}
