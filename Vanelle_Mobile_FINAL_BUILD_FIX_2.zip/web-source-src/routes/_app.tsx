import { createFileRoute, Outlet, useRouterState } from "@tanstack/react-router";
import { useEffect } from "react";
import { Sidebar } from "@/components/vanelle/sidebar";
import { useEngineStore } from "@/lib/vanelle/engine-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_app")({
  component: AppLayout,
});

function AppLayout() {
  const probe = useEngineStore((s) => s.probe);
  useEffect(() => {
    void probe();
  }, [probe]);

  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const search = useRouterState({ select: (s) => s.location.search });
  const tab = typeof search === "object" && search && "tab" in search ? String((search as { tab?: string }).tab || "") : "";
  const chatMode = pathname.startsWith("/ia/") && tab === "tester";

  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <Sidebar />
      <main
        className={cn(
          "min-w-0 flex-1",
          chatMode ? "flex h-auto min-h-screen flex-col p-2 md:h-screen md:p-3" : "mx-auto w-full max-w-[1180px] px-4 py-6 md:px-9 md:py-8",
        )}
      >
        <Outlet />
      </main>
    </div>
  );
}
