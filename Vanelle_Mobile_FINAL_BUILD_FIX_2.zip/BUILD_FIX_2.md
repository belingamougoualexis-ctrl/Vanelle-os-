# Vanelle Mobile — BUILD FIX 2

Fixed GitHub Actions Java compilation error in `EngineManager.java`:

`unreported exception Exception; must be caught or declared to be thrown`

Cause: `sha256(File)` declares `throws Exception`, while `modelReady()` did not handle it.

Fix: `modelReady()` now performs the file checks first and catches any SHA-256 exception, returning `false` rather than allowing the app to crash or the Java compiler to fail.

This is the correct behavior for a readiness check: an unreadable/corrupt/unverifiable model is simply considered not ready.
