import { Platform, StyleSheet } from 'react-native';

export const colors = {
  background: '#F2F5FF',
  backgroundDeep: '#EAF0FF',
  surface: '#FFFFFF',
  surfaceSoft: '#F7F9FF',
  surfaceTint: '#F1F4FF',
  text: '#091329',
  textSecondary: '#34415C',
  muted: '#6C7892',
  mutedLight: '#9AA5BC',
  line: '#DDE4F2',
  lineStrong: '#C6D0E4',
  primary: '#5068F5',
  primaryPressed: '#3E53D5',
  primarySoft: '#E8ECFF',
  accent: '#21C9C3',
  accentSoft: '#DDF9F7',
  violet: '#8A67F6',
  violetSoft: '#EEE8FF',
  pink: '#EE68A7',
  success: '#159B72',
  warning: '#B87816',
  danger: '#D6466A',
  onPrimary: '#FFFFFF',
  inkOnDark: '#F6F8FF',
  darkPanel: '#101A34',
  darkPanel2: '#172245',
} as const;

export const radii = {
  xs: 10,
  sm: 14,
  md: 18,
  lg: 24,
  xl: 30,
  pill: 999,
} as const;

export const spacing = {
  xs: 6,
  sm: 10,
  md: 14,
  lg: 18,
  xl: 24,
  xxl: 32,
} as const;

export const typography = StyleSheet.create({
  body: {
    fontSize: 14,
    lineHeight: 21,
    color: colors.textSecondary,
    fontFamily: Platform.select({
      ios: 'System',
      android: 'sans-serif',
      windows: 'Segoe UI',
      default: undefined,
    }),
  },
  title: {
    fontSize: 31,
    lineHeight: 36,
    fontWeight: '800',
    letterSpacing: -0.7,
    color: colors.text,
    fontFamily: Platform.select({ ios: 'System', android: 'sans-serif', windows: 'Segoe UI', default: undefined }),
  },
  subtitle: {
    fontSize: 14,
    lineHeight: 21,
    color: colors.muted,
    fontFamily: Platform.select({ ios: 'System', android: 'sans-serif', windows: 'Segoe UI', default: undefined }),
  },
  section: {
    fontSize: 16,
    lineHeight: 21,
    fontWeight: '700',
    letterSpacing: -0.15,
    color: colors.text,
    fontFamily: Platform.select({ ios: 'System', android: 'sans-serif', windows: 'Segoe UI', default: undefined }),
  },
});
