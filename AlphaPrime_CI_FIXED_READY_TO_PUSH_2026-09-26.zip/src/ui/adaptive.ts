import { useWindowDimensions } from 'react-native';

export type WindowClass = 'compact' | 'medium' | 'expanded' | 'large' | 'xlarge';
export type HeightClass = 'compact' | 'medium' | 'expanded';

// Breakpoints follow the current Android adaptive-window guidance and are based
// on the actual app window, not a phone/tablet device flag.
export function classifyWindow(width: number): WindowClass {
  if (width < 600) return 'compact';
  if (width < 840) return 'medium';
  if (width < 1200) return 'expanded';
  if (width < 1600) return 'large';
  return 'xlarge';
}

export function classifyHeight(height: number): HeightClass {
  if (height < 480) return 'compact';
  if (height < 900) return 'medium';
  return 'expanded';
}

export function useAdaptiveLayout() {
  const { width, height } = useWindowDimensions();
  const windowClass = classifyWindow(width);
  const heightClass = classifyHeight(height);
  return {
    width,
    height,
    windowClass,
    heightClass,
    isCompact: windowClass === 'compact',
    isMedium: windowClass === 'medium',
    isExpanded: windowClass === 'expanded',
    isLarge: windowClass === 'large',
    isXLarge: windowClass === 'xlarge',
    isShortHeight: heightClass === 'compact',
    horizontalPadding: width < 600 ? 16 : width < 840 ? 24 : width < 1200 ? 32 : 40,
    contentMaxWidth: width >= 1600 ? 1480 : width >= 1200 ? 1280 : width >= 840 ? 1080 : 920,
  };
}
