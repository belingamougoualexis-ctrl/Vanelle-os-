export type Project = {
  id: string;
  name: string;
  description: string;
  createdAt: string;
  updatedAt: string;
};

export type DatasetProfile = {
  id: string;
  projectId: string;
  name: string;
  sourcePath: string;
  format: 'csv' | 'json';
  rows: number;
  columns: number;
  missingCells: number;
  duplicateRows: number;
  malformedRows: number;
  piiHits: number;
  schemaHash: string;
  importedAt: string;
};

export type EvaluationCase = {
  id: string;
  input: string;
  expected: string;
};

export type EvaluationSuite = {
  id: string;
  projectId: string;
  name: string;
  cases: EvaluationCase[];
  updatedAt: string;
};

export type Run = {
  id: string;
  projectId: string;
  kind: 'profile' | 'evaluation' | 'drift' | 'training';
  startedAt: string;
  endedAt: string;
  status: 'passed' | 'failed';
  metrics: Record<string, number>;
  notes: string[];
};

export type DeviceProfile = {
  brand: string;
  model: string;
  os: string;
  totalMemoryMB: number | null;
  isTablet: boolean;
  recommendedModelClass: 'tiny' | 'small' | 'medium' | 'unsupported';
  gpuStrategy: 'auto' | 'cpu-only';
};

export type LocalModel = {
  path: string;
  name: string;
  sizeBytes: number;
  format: 'gguf';
  importedAt: string;
};

export type BackendInfo = {
  backend: string;
  deviceName: string;
  type: string;
  maxMemorySize: number;
};

export type AppState = {
  projects: Project[];
  datasets: DatasetProfile[];
  suites: EvaluationSuite[];
  runs: Run[];
  localModel: LocalModel | null;
  onboardingComplete: boolean;
};
