import fs from 'fs';
import path from 'path';

const root = path.resolve(__dirname, '..');
const blocked = /\b(simulator|emulator|demo|fake|fictif|fictive)\b/i;

function productionFiles(dir: string): string[] {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) return entry.name === '__tests__' ? [] : productionFiles(full);
    return /\.(ts|tsx)$/.test(entry.name) ? [full] : [];
  });
}

describe('production UI language', () => {
  test('does not expose development/simulation wording', () => {
    for (const file of productionFiles(root)) {
      const source = fs.readFileSync(file, 'utf8');
      const visibleOnly = source.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
      expect(visibleOnly).not.toMatch(blocked);
    }

    const desktop = path.resolve(__dirname, '..', '..', 'desktop_engine', 'frontend', 'dashboard.html');
    const desktopSource = fs.readFileSync(desktop, 'utf8');
    expect(desktopSource).not.toMatch(blocked);
  });
});
