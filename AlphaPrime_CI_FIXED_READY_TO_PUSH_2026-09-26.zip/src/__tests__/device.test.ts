import { classifyMemory } from '../services/device';

describe('device model sizing', () => {
  test('uses conservative model classes', () => {
    expect(classifyMemory(16000)).toBe('medium');
    expect(classifyMemory(8000)).toBe('small');
    expect(classifyMemory(5000)).toBe('tiny');
    expect(classifyMemory(1999)).toBe('unsupported');
    expect(classifyMemory(2000)).toBe('tiny');
    expect(classifyMemory(null)).toBe('tiny');
  });
});
