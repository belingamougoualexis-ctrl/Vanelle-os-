const memory = new Map<string, string>();

jest.mock('@react-native-async-storage/async-storage', () => ({
  getItem: jest.fn(async (key: string) => memory.get(key) ?? null),
  setItem: jest.fn(async (key: string, value: string) => { memory.set(key, value); }),
  removeItem: jest.fn(async (key: string) => { memory.delete(key); }),
}));

describe('mobile storage recovery', () => {
  beforeEach(() => memory.clear());

  test('quarantines corrupt local state and starts from an empty state', async () => {
    const { loadState, EMPTY_STATE } = await import('../storage/store');
    memory.set('@alphaprime/state/v3', '{ this is not json');

    const state = await loadState();

    expect(state).toEqual(EMPTY_STATE);
    expect([...memory.keys()].some((key) => key.startsWith('@alphaprime/quarantine/'))).toBe(true);
  });
});
