import { profileCsv, profileJson } from '../services/dataEngine';

jest.mock('expo-crypto', () => ({
  CryptoDigestAlgorithm: { SHA256: 'SHA-256' },
  digestStringAsync: jest.fn(async (_algo: string, input: string) => `sha:${input.length}`),
}));

describe('data engine', () => {
  test('profiles quoted CSV, missing cells, duplicates and PII candidates', async () => {
    const csv = 'name,email,note\n"A, Inc",alice@example.com,"ok"\n"A, Inc",alice@example.com,"ok"\nBob,,"phone 12345678901"\n';
    const result = await profileCsv(csv);
    expect(result.rows).toBe(3);
    expect(result.columns).toBe(3);
    expect(result.duplicateRows).toBe(1);
    expect(result.missingCells).toBe(1);
    expect(result.piiHits).toBe(2);
    expect(result.malformedRows).toBe(0);
  });

  test('profiles JSON arrays of objects', async () => {
    const result = await profileJson(JSON.stringify([
      { name: 'A', email: 'a@example.com' },
      { name: 'A', email: 'a@example.com' },
      { name: 'B' },
    ]));
    expect(result.rows).toBe(3);
    expect(result.columns).toBe(2);
    expect(result.duplicateRows).toBe(1);
    expect(result.missingCells).toBe(1);
    expect(result.piiHits).toBe(2);
  });
});
