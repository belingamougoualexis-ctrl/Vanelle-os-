import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, radii } from '../ui/theme';

export function PrimaryButton({ title, onPress, disabled = false, secondary = false }: { title: string; onPress: () => void; disabled?: boolean; secondary?: boolean }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled }}
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.button,
        secondary ? styles.secondary : styles.primary,
        disabled && styles.disabled,
        pressed && !disabled && styles.pressed,
      ]}
    >
      <View style={[styles.dot, secondary ? styles.dotSecondary : styles.dotPrimary]} />
      <Text style={[styles.text, secondary ? styles.textSecondary : styles.textPrimary]}>{title}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    minHeight: 50,
    borderRadius: radii.md,
    paddingVertical: 13,
    paddingHorizontal: 17,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 9,
    borderWidth: 1,
  },
  primary: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
    shadowColor: '#3345C7',
    shadowOpacity: 0.20,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 7 },
    elevation: 4,
  },
  secondary: {
    backgroundColor: colors.surface,
    borderColor: colors.lineStrong,
  },
  dot: { width: 7, height: 7, borderRadius: 4 },
  dotPrimary: { backgroundColor: colors.accent },
  dotSecondary: { backgroundColor: colors.primary },
  text: { fontSize: 13, fontWeight: '700', letterSpacing: -0.1 },
  textPrimary: { color: colors.onPrimary },
  textSecondary: { color: colors.text },
  disabled: { opacity: 0.45 },
  pressed: { transform: [{ scale: 0.985 }] },
});
