import React, { PropsWithChildren } from 'react';
import { StyleSheet, View } from 'react-native';
import { colors } from '../ui/theme';

export function AmbientBackground({ children }: PropsWithChildren) {
  return (
    <View style={styles.root}>
      <View pointerEvents="none" style={[styles.orb, styles.orbBlue]} />
      <View pointerEvents="none" style={[styles.orb, styles.orbAqua]} />
      <View pointerEvents="none" style={[styles.orb, styles.orbViolet]} />
      <View pointerEvents="none" style={styles.grid} />
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background, overflow: 'hidden' },
  orb: { position: 'absolute', borderRadius: 999 },
  orbBlue: { width: 300, height: 300, top: -175, right: -105, backgroundColor: 'rgba(80,104,245,0.13)' },
  orbAqua: { width: 230, height: 230, top: 150, left: -175, backgroundColor: 'rgba(33,201,195,0.08)' },
  orbViolet: { width: 250, height: 250, bottom: -190, right: -105, backgroundColor: 'rgba(138,103,246,0.08)' },
  grid: {
    position: 'absolute',
    top: 96,
    right: -30,
    width: 190,
    height: 190,
    borderWidth: 1,
    borderColor: 'rgba(80,104,245,0.055)',
    borderRadius: 95,
    transform: [{ rotate: '18deg' }],
  },
});
