import React from 'react';
import { StyleSheet, View, ViewProps } from 'react-native';
import { colors, radii } from '../ui/theme';

export function AdaptiveCard({ style, children, ...props }: ViewProps) {
  return (
    <View {...props} style={[styles.card, style]}>
      <View pointerEvents="none" style={styles.highlight} />
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    position: 'relative',
    overflow: 'hidden',
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: radii.lg,
    padding: 17,
    shadowColor: '#13204A',
    shadowOpacity: 0.07,
    shadowRadius: 24,
    shadowOffset: { width: 0, height: 10 },
    elevation: 3,
  },
  highlight: {
    position: 'absolute',
    top: -38,
    right: -24,
    width: 150,
    height: 110,
    borderRadius: 80,
    backgroundColor: 'rgba(80,104,245,0.07)',
    transform: [{ rotate: '-12deg' }],
  },
});
