import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, radii } from '../ui/theme';

export function MetricCard({ label, value, hint, accent = 'primary' }: { label: string; value: string | number; hint?: string; accent?: 'primary' | 'accent' | 'violet' }) {
  const accentColor = accent === 'accent' ? colors.accent : accent === 'violet' ? colors.violet : colors.primary;
  return (
    <View style={styles.card}>
      <View style={styles.top}>
        <Text style={styles.label}>{label}</Text>
        <View style={[styles.marker, { backgroundColor: accentColor }]} />
      </View>
      <Text style={styles.value}>{value}</Text>
      {hint ? <Text style={styles.hint}>{hint}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flexGrow: 1,
    flexBasis: 150,
    minWidth: 144,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: radii.lg,
    padding: 16,
    shadowColor: '#15214B',
    shadowOpacity: 0.055,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 8 },
    elevation: 2,
  },
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  label: { color: colors.muted, fontSize: 11, fontWeight: '700', letterSpacing: 0.1 },
  marker: { width: 7, height: 7, borderRadius: 4 },
  value: { color: colors.text, fontSize: 28, lineHeight: 32, fontWeight: '800', marginTop: 10, letterSpacing: -0.8 },
  hint: { color: colors.mutedLight, fontSize: 10, marginTop: 4, lineHeight: 15 },
});
