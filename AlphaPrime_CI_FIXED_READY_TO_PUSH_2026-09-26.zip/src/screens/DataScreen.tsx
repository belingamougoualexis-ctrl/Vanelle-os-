import React, { useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { AppState, DatasetProfile } from '../core/types';
import { profileCsv, profileJson } from '../services/dataEngine';
import { PrimaryButton } from '../components/PrimaryButton';
import { AdaptiveCard } from '../components/AdaptiveCard';
import { ScreenIntro } from '../components/ScreenIntro';
import { colors, radii } from '../ui/theme';

export function DataScreen({ state, setState }: { state: AppState; setState: (s: AppState) => void }) {
  const [busy, setBusy] = useState(false);

  const importDataset = async () => {
    if (busy) return;
    const result = await DocumentPicker.getDocumentAsync({ type: ['text/csv', 'application/json', '*/*'], copyToCacheDirectory: true });
    if (result.canceled || !result.assets[0]) return;
    const asset = result.assets[0];
    const ext = (asset.name.split('.').pop() || '').toLowerCase();
    if (ext !== 'csv' && ext !== 'json') {
      Alert.alert('Format non pris en charge', 'Le mobile accepte actuellement CSV et JSON. Les autres formats restent pris en charge par le moteur desktop lorsqu’ils sont disponibles.');
      return;
    }
    setBusy(true);
    try {
      const text = await FileSystem.readAsStringAsync(asset.uri);
      const profile = ext === 'csv' ? await profileCsv(text) : await profileJson(text);
      const datasetsDir = `${FileSystem.documentDirectory}datasets/`;
      await FileSystem.makeDirectoryAsync(datasetsDir, { intermediates: true });
      const destination = `${datasetsDir}${Date.now()}_${asset.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
      await FileSystem.copyAsync({ from: asset.uri, to: destination });
      const now = new Date().toISOString();
      const projectId = state.projects[0]?.id ?? 'unassigned';
      const dataset: DatasetProfile = { id: `d_${Date.now()}`, projectId, name: asset.name, sourcePath: destination, format: ext, ...profile, importedAt: now };
      const run = { id: `r_${Date.now() + 1}`, projectId, kind: 'profile' as const, startedAt: now, endedAt: new Date().toISOString(), status: profile.malformedRows === 0 ? 'passed' as const : 'failed' as const, metrics: { rows: profile.rows, columns: profile.columns, missingCells: profile.missingCells, duplicateRows: profile.duplicateRows, malformedRows: profile.malformedRows, piiHits: profile.piiHits }, notes: ['Profilage exécuté localement. Les PII sont des candidats détectés par règles, pas une classification juridique.'] };
      setState({ ...state, datasets: [...state.datasets, dataset], runs: [...state.runs, run] });
      Alert.alert('Analyse terminée', `${profile.rows} lignes · ${profile.columns} colonnes · ${profile.piiHits} candidat(s) PII.`);
    } catch (e) {
      Alert.alert('Import impossible', e instanceof Error ? e.message : 'Erreur locale inconnue.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.wrap} showsVerticalScrollIndicator={false}>
      <ScreenIntro eyebrow="DATA ENGINE" title="Données" subtitle="Importe des fichiers et vérifie leur structure localement avant toute utilisation." />
      <AdaptiveCard style={styles.actionCard}>
        <View style={styles.actionIcon}><Text style={styles.actionIconText}>D</Text></View>
        <View style={{ flex: 1 }}><Text style={styles.actionTitle}>Importer une source</Text><Text style={styles.actionText}>CSV et JSON sur mobile. Le fichier est copié dans le stockage privé avant analyse.</Text></View>
        <PrimaryButton title={busy ? 'Analyse…' : 'Choisir'} onPress={importDataset} disabled={busy} />
      </AdaptiveCard>
      {state.datasets.length === 0 ? <AdaptiveCard style={styles.empty}><Text style={styles.emptyTitle}>Aucun dataset local</Text><Text style={styles.emptyText}>Les indicateurs apparaîtront uniquement après une véritable importation.</Text></AdaptiveCard> : null}
      {state.datasets.map((d) => (
        <AdaptiveCard key={d.id}>
          <View style={styles.cardHeader}><View style={styles.formatBadge}><Text style={styles.formatText}>{d.format.toUpperCase()}</Text></View><Text style={styles.name} numberOfLines={1}>{d.name}</Text></View>
          <View style={styles.statRow}><MiniStat label="Lignes" value={d.rows.toString()} /><MiniStat label="Colonnes" value={d.columns.toString()} /><MiniStat label="Manquants" value={d.missingCells.toString()} /><MiniStat label="Doublons" value={d.duplicateRows.toString()} /></View>
          <Text style={styles.line}>Mal formées : {d.malformedRows} · candidats PII : {d.piiHits}</Text>
          <Text style={styles.hash}>Schéma SHA-256 : {d.schemaHash}</Text>
        </AdaptiveCard>
      ))}
    </ScrollView>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return <View style={styles.mini}><Text style={styles.miniLabel}>{label}</Text><Text style={styles.miniValue}>{value}</Text></View>;
}

const styles = StyleSheet.create({
  wrap: { paddingTop: 8, paddingBottom: 120, gap: 14 },
  actionCard: { gap: 12 },
  actionIcon: { width: 44, height: 44, borderRadius: 15, backgroundColor: colors.accentSoft, alignItems: 'center', justifyContent: 'center' },
  actionIconText: { color: '#079A94', fontSize: 16, fontWeight: '800' },
  actionTitle: { color: colors.text, fontSize: 14, fontWeight: '800' },
  actionText: { color: colors.muted, fontSize: 11, lineHeight: 17, marginTop: 3 },
  empty: { alignItems: 'center' },
  emptyTitle: { color: colors.text, fontSize: 14, fontWeight: '800' },
  emptyText: { color: colors.muted, fontSize: 11, lineHeight: 17, textAlign: 'center', marginTop: 4 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, minWidth: 0 },
  formatBadge: { paddingHorizontal: 8, paddingVertical: 5, borderRadius: radii.pill, backgroundColor: colors.primarySoft, borderWidth: 1, borderColor: colors.line },
  formatText: { color: colors.primary, fontSize: 8, fontWeight: '800', letterSpacing: 0.5 },
  name: { color: colors.text, fontSize: 14, fontWeight: '800', flex: 1 },
  statRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 14 },
  mini: { flexGrow: 1, minWidth: 92, backgroundColor: colors.surfaceSoft, borderRadius: radii.sm, borderWidth: 1, borderColor: colors.line, padding: 9 },
  miniLabel: { color: colors.mutedLight, fontSize: 8, fontWeight: '800', letterSpacing: 0.5 },
  miniValue: { color: colors.text, fontSize: 16, fontWeight: '800', marginTop: 3 },
  line: { color: colors.textSecondary, fontSize: 11, lineHeight: 17, marginTop: 12 },
  hash: { color: colors.mutedLight, fontSize: 9, lineHeight: 14, marginTop: 4 },
});
