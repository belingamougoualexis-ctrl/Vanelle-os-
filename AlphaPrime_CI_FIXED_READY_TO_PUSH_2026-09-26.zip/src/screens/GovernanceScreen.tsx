import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { AdaptiveCard } from '../components/AdaptiveCard';
import { ScreenIntro } from '../components/ScreenIntro';
import { AppState } from '../core/types';
import { colors, radii } from '../ui/theme';

export function GovernanceScreen({ state }: { state: AppState }) {
  const pii = state.datasets.reduce((s, d) => s + d.piiHits, 0);
  const missing = state.datasets.reduce((s, d) => s + d.missingCells, 0);
  const tracked = state.datasets.length + state.runs.length;
  return (
    <ScrollView contentContainerStyle={styles.wrap} showsVerticalScrollIndicator={false}>
      <ScreenIntro eyebrow="TRUST & GOVERNANCE" title="Gouvernance" subtitle="Une vue factuelle des opérations et des données réellement présentes dans l’espace local." />
      <View style={styles.grid}>
        <Metric label="Candidats PII" value={pii.toString()} accent="violet" />
        <Metric label="Cellules manquantes" value={missing.toString()} accent="accent" />
        <Metric label="Éléments suivis" value={tracked.toString()} accent="primary" />
        <Metric label="Runs exécutés" value={state.runs.length.toString()} accent="primary" />
      </View>
      <AdaptiveCard>
        <Text style={styles.panelTitle}>Principes actifs</Text>
        <Rule text="Les données, fichiers importés et journaux restent dans l’espace local." />
        <Rule text="Aucune métrique n’est créée avant une opération réelle." />
        <Rule text="Une évaluation exige un modèle GGUF installé et vérifiable localement." />
        <Rule text="Les PII affichées sont des candidats détectés par règles, pas une qualification juridique." />
        <Rule text="Les entraînements lourds ne sont proposés que lorsque le moteur correspondant a confirmé ses capacités localement." />
      </AdaptiveCard>
    </ScrollView>
  );
}

function Metric({ label, value, accent }: { label: string; value: string; accent: 'primary' | 'accent' | 'violet' }) {
  const color = accent === 'accent' ? colors.accent : accent === 'violet' ? colors.violet : colors.primary;
  return <View style={styles.metric}><View style={[styles.metricDot, { backgroundColor: color }]} /><Text style={styles.metricLabel}>{label}</Text><Text style={styles.metricValue}>{value}</Text></View>;
}
function Rule({ text }: { text: string }) {
  return <View style={styles.rule}><View style={styles.check}><Text style={styles.checkText}>✓</Text></View><Text style={styles.ruleText}>{text}</Text></View>;
}
const styles = StyleSheet.create({
  wrap: { paddingTop: 8, paddingBottom: 120, gap: 14 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  metric: { flexGrow: 1, minWidth: 145, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line, borderRadius: radii.lg, padding: 15 },
  metricDot: { width: 7, height: 7, borderRadius: 4, marginBottom: 9 },
  metricLabel: { color: colors.muted, fontSize: 10, fontWeight: '700' },
  metricValue: { color: colors.text, fontSize: 24, fontWeight: '800', marginTop: 5, letterSpacing: -0.5 },
  panelTitle: { color: colors.text, fontSize: 16, fontWeight: '800', marginBottom: 7 },
  rule: { flexDirection: 'row', gap: 9, alignItems: 'flex-start', paddingVertical: 9, borderTopWidth: 1, borderTopColor: colors.line },
  check: { width: 22, height: 22, borderRadius: 8, backgroundColor: colors.surfaceTint, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.line },
  checkText: { color: colors.primary, fontSize: 11, fontWeight: '900' },
  ruleText: { flex: 1, color: colors.textSecondary, fontSize: 11, lineHeight: 17 },
});
