import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { MetricCard } from '../components/MetricCard';
import { AdaptiveCard } from '../components/AdaptiveCard';
import { AppState } from '../core/types';
import { colors, radii } from '../ui/theme';

export function DashboardScreen({ state, device }: { state: AppState; device: { model: string; recommendedModelClass: string } | null }) {
  const runs = state.runs.slice(-5).reverse();
  const accents: Array<'primary' | 'accent' | 'violet'> = ['primary', 'accent', 'violet', 'primary'];
  return (
    <ScrollView contentContainerStyle={styles.wrap} showsVerticalScrollIndicator={false}>
      <View style={styles.hero}>
        <View pointerEvents="none" style={styles.heroOrbOne} />
        <View pointerEvents="none" style={styles.heroOrbTwo} />
        <View style={styles.heroContent}>
          <View style={styles.heroTextBlock}>
            <View style={styles.eyebrowRow}><View style={styles.eyebrowDot} /><Text style={styles.eyebrow}>LOCAL AI CONTROL CENTER</Text></View>
            <Text style={styles.heroTitle}>Construire. Vérifier. Évaluer.</Text>
            <Text style={styles.heroSubtitle}>Un espace de travail local qui préfère une preuve réelle à une affirmation.</Text>
          </View>
          <View style={styles.heroBadge}>
            <Text style={styles.heroBadgeTop}>CORE</Text>
            <Text style={styles.heroBadgeBottom}>LOCAL</Text>
          </View>
        </View>
      </View>

      <View style={styles.metricGrid}>
        <MetricCard label="Projets" value={state.projects.length} accent={accents[0]} />
        <MetricCard label="Datasets" value={state.datasets.length} accent={accents[1]} />
        <MetricCard label="Suites" value={state.suites.length} accent={accents[2]} />
        <MetricCard label="Runs" value={state.runs.length} accent={accents[3]} />
      </View>

      <AdaptiveCard>
        <View style={styles.cardHeader}><Text style={styles.cardTitle}>Profil de la machine</Text><View style={styles.microPill}><View style={styles.microDot} /><Text style={styles.microText}>LOCAL</Text></View></View>
        <Text style={styles.deviceName}>{device?.model ?? 'Profil en cours d’analyse'}</Text>
        <Text style={styles.body}>Profil calculé à partir des informations réellement exposées par l’appareil.</Text>
        <View style={styles.profileRow}>
          <View style={styles.profileChip}><Text style={styles.profileChipLabel}>CAPACITÉ MODÈLE</Text><Text style={styles.profileChipValue}>{device?.recommendedModelClass ?? '—'}</Text></View>
          <View style={styles.profileChip}><Text style={styles.profileChipLabel}>DONNÉES</Text><Text style={styles.profileChipValue}>{state.datasets.length} local{state.datasets.length > 1 ? 'es' : ''}</Text></View>
        </View>
      </AdaptiveCard>

      <AdaptiveCard>
        <View style={styles.cardHeader}><View><Text style={styles.cardTitle}>Journal des opérations</Text><Text style={styles.body}>Uniquement les opérations réellement enregistrées.</Text></View><Text style={styles.count}>{runs.length}</Text></View>
        {runs.length === 0 ? (
          <View style={styles.emptyState}><View style={styles.emptyIcon}><Text style={styles.emptyIconText}>+</Text></View><Text style={styles.emptyTitle}>Aucune opération</Text><Text style={styles.emptyText}>Les indicateurs restent vides jusqu’à une action réelle.</Text></View>
        ) : runs.map((run) => (
          <View style={styles.run} key={run.id}>
            <View style={[styles.runDot, run.status === 'passed' ? styles.runOk : styles.runBad]} />
            <View style={{ flex: 1 }}><Text style={styles.runTitle}>{run.kind.toUpperCase()}</Text><Text style={styles.small}>{run.status.toUpperCase()} · {new Date(run.endedAt).toLocaleString()}</Text></View>
          </View>
        ))}
      </AdaptiveCard>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { paddingTop: 8, paddingBottom: 120, gap: 16 },
  hero: { position: 'relative', overflow: 'hidden', minHeight: 220, borderRadius: radii.xl, backgroundColor: colors.darkPanel, padding: 22, shadowColor: '#172245', shadowOpacity: 0.24, shadowRadius: 34, shadowOffset: { width: 0, height: 14 }, elevation: 6 },
  heroOrbOne: { position: 'absolute', width: 250, height: 250, borderRadius: 125, right: -85, top: -95, backgroundColor: 'rgba(80,104,245,0.34)' },
  heroOrbTwo: { position: 'absolute', width: 210, height: 210, borderRadius: 105, right: 80, bottom: -130, backgroundColor: 'rgba(33,201,195,0.20)' },
  heroContent: { flex: 1, justifyContent: 'space-between', flexDirection: 'row', gap: 18 },
  heroTextBlock: { flex: 1, justifyContent: 'center' },
  eyebrowRow: { flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 10 },
  eyebrowDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.accent },
  eyebrow: { color: '#BFCBFF', fontSize: 9, fontWeight: '800', letterSpacing: 1.2 },
  heroTitle: { color: '#F8FAFF', fontSize: 30, lineHeight: 34, fontWeight: '800', letterSpacing: -0.85, maxWidth: 600 },
  heroSubtitle: { color: '#B8C2DB', fontSize: 13, lineHeight: 20, marginTop: 9, maxWidth: 560 },
  heroBadge: { width: 74, height: 74, borderRadius: 24, borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)', backgroundColor: 'rgba(255,255,255,0.08)', alignItems: 'center', justifyContent: 'center', alignSelf: 'flex-start' },
  heroBadgeTop: { color: colors.accent, fontSize: 9, fontWeight: '800', letterSpacing: 1 },
  heroBadgeBottom: { color: '#F8FAFF', fontSize: 11, fontWeight: '800', marginTop: 3 },
  metricGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10, marginBottom: 6 },
  cardTitle: { color: colors.text, fontSize: 16, fontWeight: '800', letterSpacing: -0.2 },
  microPill: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 8, paddingVertical: 5, backgroundColor: colors.surfaceTint, borderRadius: radii.pill, borderWidth: 1, borderColor: colors.line },
  microDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: colors.success },
  microText: { color: colors.muted, fontSize: 8, fontWeight: '800', letterSpacing: 0.7 },
  deviceName: { color: colors.text, fontSize: 15, fontWeight: '700', marginTop: 8 },
  body: { color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: 3 },
  profileRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 14 },
  profileChip: { flexGrow: 1, minWidth: 140, backgroundColor: colors.surfaceSoft, borderRadius: radii.md, borderWidth: 1, borderColor: colors.line, padding: 11 },
  profileChipLabel: { color: colors.mutedLight, fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  profileChipValue: { color: colors.text, fontSize: 12, fontWeight: '800', marginTop: 4 },
  count: { color: colors.primary, fontSize: 12, fontWeight: '800' },
  emptyState: { borderWidth: 1, borderColor: colors.line, borderStyle: 'dashed', borderRadius: radii.md, padding: 20, alignItems: 'center', marginTop: 10 },
  emptyIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' },
  emptyIconText: { color: colors.primary, fontSize: 21, fontWeight: '400' },
  emptyTitle: { color: colors.text, fontSize: 13, fontWeight: '800', marginTop: 9 },
  emptyText: { color: colors.muted, fontSize: 11, textAlign: 'center', lineHeight: 17, marginTop: 4 },
  run: { flexDirection: 'row', alignItems: 'center', gap: 11, paddingVertical: 11, borderTopWidth: 1, borderTopColor: colors.line },
  runDot: { width: 8, height: 8, borderRadius: 4 },
  runOk: { backgroundColor: colors.success },
  runBad: { backgroundColor: colors.danger },
  runTitle: { color: colors.textSecondary, fontSize: 10, fontWeight: '800', letterSpacing: 0.4 },
  small: { color: colors.muted, fontSize: 10, lineHeight: 15, marginTop: 2 },
});
