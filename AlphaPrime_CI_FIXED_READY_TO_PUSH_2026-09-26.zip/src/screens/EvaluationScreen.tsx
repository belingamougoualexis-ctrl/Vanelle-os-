import React, { useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { PrimaryButton } from '../components/PrimaryButton';
import { AdaptiveCard } from '../components/AdaptiveCard';
import { ScreenIntro } from '../components/ScreenIntro';
import { AppState, DeviceProfile, EvaluationCase, EvaluationSuite } from '../core/types';
import { chatLocal } from '../services/llm';
import { colors, radii } from '../ui/theme';

export function EvaluationScreen({ state, setState, device }: { state: AppState; setState: (s: AppState) => void; device: DeviceProfile | null }) {
  const [input, setInput] = useState('');
  const [expected, setExpected] = useState('');
  const [busy, setBusy] = useState(false);

  const addCase = () => {
    if (!state.projects[0]) return Alert.alert('Projet requis', 'Crée d’abord un projet local.');
    if (!input.trim() || !expected.trim()) return Alert.alert('Cas incomplet', 'Renseigne l’entrée et la sortie attendue.');
    const existing = state.suites[0];
    const item: EvaluationCase = { id: `c_${Date.now()}`, input: input.trim(), expected: expected.trim() };
    const suite: EvaluationSuite = existing ? { ...existing, cases: [...existing.cases, item], updatedAt: new Date().toISOString() } : { id: `s_${Date.now()}`, projectId: state.projects[0].id, name: 'Jeu d’évaluation local', cases: [item], updatedAt: new Date().toISOString() };
    setState({ ...state, suites: existing ? state.suites.map((s) => s.id === existing.id ? suite : s) : [suite, ...state.suites] });
    setInput(''); setExpected('');
  };

  const run = async () => {
    const model = state.localModel;
    const suite = state.suites[0];
    if (!model) return Alert.alert('Modèle local requis', 'Importe et vérifie un modèle GGUF présent sur cet appareil.');
    if (!suite || suite.cases.length === 0) return Alert.alert('Suite vide', 'Ajoute au moins un cas d’évaluation.');
    if (busy) return;
    setBusy(true);
    const started = new Date().toISOString();
    try {
      let pass = 0;
      for (const c of suite.cases) {
        const answer = await chatLocal(model, [{ role: 'user', content: c.input }], device?.totalMemoryMB ?? null);
        if (answer.trim().toLowerCase() === c.expected.trim().toLowerCase()) pass += 1;
      }
      const score = pass / suite.cases.length;
      const ended = new Date().toISOString();
      const runRecord = { id: `r_${Date.now()}`, projectId: suite.projectId, kind: 'evaluation' as const, startedAt: started, endedAt: ended, status: score >= 0.8 ? 'passed' as const : 'failed' as const, metrics: { exact_match: score, passed: pass, total: suite.cases.length }, notes: ['Inférence GGUF réellement exécutée localement. Métrique : exact match, sans interprétation sémantique.'] };
      setState({ ...state, runs: [...state.runs, runRecord] });
      Alert.alert('Évaluation terminée', `Exact match : ${(score * 100).toFixed(1)} %`);
    } catch (e) {
      Alert.alert('Évaluation échouée', e instanceof Error ? e.message : 'Erreur locale');
    } finally {
      setBusy(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.wrap} showsVerticalScrollIndicator={false}>
      <ScreenIntro eyebrow="EVALUATION ENGINE" title="Évaluations" subtitle="Les scores sont calculés uniquement après exécution du modèle réel sur tes propres cas." />
      <AdaptiveCard>
        <View style={styles.sectionHead}><Text style={styles.section}>Composer un cas</Text><View style={styles.caseBadge}><Text style={styles.caseBadgeText}>LOCAL</Text></View></View>
        <TextInput style={styles.input} value={input} onChangeText={setInput} placeholder="Entrée" placeholderTextColor={colors.mutedLight} multiline />
        <TextInput style={styles.input} value={expected} onChangeText={setExpected} placeholder="Sortie attendue" placeholderTextColor={colors.mutedLight} multiline />
        <View style={styles.actions}><View style={{ flex: 1 }}><PrimaryButton title="Ajouter le cas" onPress={addCase} disabled={busy} secondary /></View><View style={{ flex: 1 }}><PrimaryButton title={busy ? 'Évaluation…' : 'Évaluer'} onPress={run} disabled={!state.localModel || busy} /></View></View>
      </AdaptiveCard>

      {state.suites[0] ? (
        <AdaptiveCard>
          <View style={styles.sectionHead}><View><Text style={styles.name}>{state.suites[0].name}</Text><Text style={styles.line}>{state.suites[0].cases.length} cas enregistré{state.suites[0].cases.length > 1 ? 's' : ''}</Text></View><View style={styles.counter}><Text style={styles.counterText}>{state.suites[0].cases.length}</Text></View></View>
        </AdaptiveCard>
      ) : <AdaptiveCard style={styles.empty}><Text style={styles.emptyTitle}>Aucun jeu d’évaluation</Text><Text style={styles.emptyText}>Aucun score n’existe tant qu’aucun cas réel n’a été créé puis exécuté.</Text></AdaptiveCard>}

      {state.runs.filter((r) => r.kind === 'evaluation').slice(-5).reverse().map((r) => (
        <AdaptiveCard key={r.id} style={styles.resultCard}>
          <View style={[styles.resultMark, r.status === 'passed' ? styles.resultOk : styles.resultBad]}><Text style={styles.resultMarkText}>{r.status === 'passed' ? '✓' : '!'}</Text></View>
          <View style={{ flex: 1 }}><Text style={styles.name}>{r.status === 'passed' ? 'Évaluation réussie' : 'Évaluation échouée'}</Text><Text style={styles.line}>Exact match : {((r.metrics.exact_match ?? 0) * 100).toFixed(1)} % · {r.metrics.passed ?? 0}/{r.metrics.total ?? 0}</Text></View>
        </AdaptiveCard>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { paddingTop: 8, paddingBottom: 120, gap: 14 },
  sectionHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  section: { color: colors.text, fontSize: 15, fontWeight: '800' },
  caseBadge: { paddingHorizontal: 8, paddingVertical: 5, borderRadius: radii.pill, backgroundColor: colors.violetSoft, borderWidth: 1, borderColor: '#DED4FF' },
  caseBadgeText: { color: colors.violet, fontSize: 8, fontWeight: '800', letterSpacing: 0.6 },
  input: { minHeight: 62, maxHeight: 170, backgroundColor: colors.surfaceSoft, borderWidth: 1, borderColor: colors.line, borderRadius: radii.md, paddingHorizontal: 13, paddingVertical: 11, color: colors.text, fontSize: 13, lineHeight: 19, textAlignVertical: 'top', marginTop: 4 },
  actions: { flexDirection: 'row', gap: 9, marginTop: 7 },
  name: { color: colors.text, fontSize: 14, fontWeight: '800' },
  line: { color: colors.muted, fontSize: 11, lineHeight: 17, marginTop: 3 },
  counter: { width: 38, height: 38, borderRadius: 14, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' },
  counterText: { color: colors.primary, fontSize: 13, fontWeight: '800' },
  empty: { alignItems: 'center' },
  emptyTitle: { color: colors.text, fontSize: 14, fontWeight: '800' },
  emptyText: { color: colors.muted, fontSize: 11, lineHeight: 17, textAlign: 'center', maxWidth: 500, marginTop: 4 },
  resultCard: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  resultMark: { width: 39, height: 39, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  resultOk: { backgroundColor: colors.accentSoft },
  resultBad: { backgroundColor: '#FFE8EE' },
  resultMarkText: { color: colors.text, fontSize: 15, fontWeight: '800' },
});
