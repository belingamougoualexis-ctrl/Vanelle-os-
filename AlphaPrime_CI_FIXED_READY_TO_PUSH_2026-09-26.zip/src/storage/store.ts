import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppState } from '../core/types';

const KEY = '@alphaprime/state/v3';
const LEGACY_KEYS = ['@alphaprime/state/v2'];
const QUARANTINE_PREFIX = '@alphaprime/quarantine/';

export const EMPTY_STATE: AppState = {
  projects: [],
  datasets: [],
  suites: [],
  runs: [],
  localModel: null,
  onboardingComplete: false,
};

function normalizeState(value: unknown): AppState {
  if (!value || typeof value !== 'object') return EMPTY_STATE;
  const obj = value as Partial<AppState>;
  return {
    projects: Array.isArray(obj.projects) ? obj.projects : [],
    datasets: Array.isArray(obj.datasets) ? obj.datasets : [],
    suites: Array.isArray(obj.suites) ? obj.suites : [],
    runs: Array.isArray(obj.runs) ? obj.runs : [],
    localModel: obj.localModel && typeof obj.localModel === 'object' ? obj.localModel : null,
    onboardingComplete: obj.onboardingComplete === true,
  } as AppState;
}

export async function loadState(): Promise<AppState> {
  for (const key of [KEY, ...LEGACY_KEYS]) {
    try {
      const raw = await AsyncStorage.getItem(key);
      if (!raw) continue;
      const state = normalizeState(JSON.parse(raw));
      if (key !== KEY) await AsyncStorage.setItem(KEY, JSON.stringify(state));
      return state;
    } catch {
      // Never overwrite potentially useful evidence. Preserve the corrupt payload
      // locally, then continue with the next compatible state source.
      try {
        const raw = await AsyncStorage.getItem(key);
        if (raw) {
          const quarantineKey = `${QUARANTINE_PREFIX}${Date.now()}`;
          await AsyncStorage.setItem(quarantineKey, JSON.stringify({ key, raw }));
        }
      } catch {
        // Quarantine is best-effort; startup must remain recoverable.
      }
    }
  }
  return EMPTY_STATE;
}

export async function saveState(state: AppState): Promise<void> {
  await AsyncStorage.setItem(KEY, JSON.stringify(normalizeState(state)));
}

export async function clearState(): Promise<void> {
  await AsyncStorage.removeItem(KEY);
}
