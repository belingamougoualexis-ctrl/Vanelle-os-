import { getBackendDevicesInfo, initLlama, loadLlamaModelInfo, LlamaContext } from 'llama.rn';
import * as FileSystem from 'expo-file-system/legacy';
import { Platform } from 'react-native';
import { BackendInfo, LocalModel } from '../core/types';

export type ChatMessage = { role: 'system' | 'user' | 'assistant'; content: string };

let ctx: LlamaContext | null = null;
let loadedPath: string | null = null;
let loadedBackend = 'CPU';
let loadedEvidence: { gpu: boolean; deviceName?: string; reason?: string } = { gpu: false };

export async function inspectBackends(): Promise<BackendInfo[]> {
  const backends = await getBackendDevicesInfo();
  return backends.map((b) => ({
    backend: b.backend,
    deviceName: b.deviceName,
    type: b.type,
    maxMemorySize: b.maxMemorySize,
  }));
}

export async function importModelFromUri(uri: string, name: string): Promise<LocalModel> {
  const modelsDir = `${FileSystem.documentDirectory}models/`;
  await FileSystem.makeDirectoryAsync(modelsDir, { intermediates: true });
  const safeName = name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const destination = `${modelsDir}${Date.now()}_${safeName}`;
  await FileSystem.copyAsync({ from: uri, to: destination });
  const info = await FileSystem.getInfoAsync(destination);
  if (!info.exists || !('size' in info) || !info.size) {
    throw new Error('Le modèle n’a pas pu être copié localement.');
  }
  try {
    await loadLlamaModelInfo(destination);
  } catch (error) {
    await FileSystem.deleteAsync(destination, { idempotent: true });
    throw new Error(`Le fichier n’est pas un GGUF lisible par llama.cpp : ${error instanceof Error ? error.message : 'format invalide'}`);
  }
  return { path: destination, name, sizeBytes: info.size, format: 'gguf', importedAt: new Date().toISOString() };
}

function memoryConfig(totalMemoryMB: number | null): { n_ctx: number; n_batch: number } {
  if (totalMemoryMB != null && totalMemoryMB >= 12000) return { n_ctx: 4096, n_batch: 256 };
  if (totalMemoryMB != null && totalMemoryMB >= 7000) return { n_ctx: 3072, n_batch: 192 };
  if (totalMemoryMB != null && totalMemoryMB >= 3500) return { n_ctx: 2048, n_batch: 128 };
  return { n_ctx: 1536, n_batch: 96 };
}

function findPreferredBackend(backends: BackendInfo[]): BackendInfo | null {
  if (Platform.OS === 'ios') {
    return backends.find((b) => b.type === 'gpu' && b.backend.toUpperCase() === 'MTL') ?? null;
  }
  if (Platform.OS === 'android') {
    return backends.find((b) => b.type === 'gpu' && b.backend.toUpperCase() === 'OPENCL') ?? null;
  }
  return null;
}

export async function loadLocalModel(model: LocalModel, totalMemoryMB: number | null): Promise<void> {
  if (loadedPath === model.path && ctx) return;
  const ramBytes = totalMemoryMB != null ? totalMemoryMB * 1024 * 1024 : null;
  if (ramBytes != null && model.sizeBytes > ramBytes * 0.75) {
    throw new Error('Ce modèle est trop gros pour la mémoire disponible sur cet appareil. Choisis une quantification plus légère.');
  }
  if (ctx) {
    await ctx.release();
    ctx = null;
  }
  loadedPath = null;
  loadedBackend = 'CPU';
  loadedEvidence = { gpu: false };
  let backends: BackendInfo[] = [];
  try {
    backends = await inspectBackends();
  } catch {
    backends = [];
  }
  const preferred = findPreferredBackend(backends);
  const memory = memoryConfig(totalMemoryMB);
  const threads = totalMemoryMB != null && totalMemoryMB < 4000 ? 2 : 4;

  const baseConfig = {
    model: model.path,
    ...memory,
    use_mlock: false,
    n_threads: threads,
    n_threads_batch: threads,
  } as const;

  const tryInit = async (gpu: boolean) => initLlama({
    ...baseConfig,
    n_gpu_layers: gpu ? 99 : 0,
    ...(gpu && preferred ? { devices: [preferred.deviceName] } : {}),
  });

  const probeContext = async (candidate: LlamaContext) => {
    const native = candidate as unknown as { gpu?: boolean; devices?: string[]; reasonNoGPU?: string };
    const probe = await candidate.completion({
      messages: [{ role: 'user', content: 'Réponds uniquement par OK.' }],
      n_predict: 2,
      temperature: 0,
      top_k: 1,
      top_p: 1,
    });
    const text = String(probe.text ?? '').trim();
    if (!text) throw new Error('Le modèle n’a produit aucun résultat lors du contrôle du runtime.');
    return {
      gpu: native.gpu === true,
      deviceName: native.devices?.[0],
      reason: native.reasonNoGPU,
      output: text,
    };
  };

  try {
    ctx = await tryInit(Boolean(preferred));
    const evidence = await probeContext(ctx);
    if (preferred && evidence.gpu) {
      loadedBackend = preferred.backend;
      loadedEvidence = { gpu: true, deviceName: evidence.deviceName, reason: evidence.reason };
    } else {
      if (preferred && !evidence.gpu) {
        await ctx.release();
        ctx = null;
        throw new Error(evidence.reason || 'L’accélération matérielle n’a pas été confirmée par le runtime natif.');
      }
      loadedBackend = 'CPU';
      loadedEvidence = { gpu: false, deviceName: evidence.deviceName, reason: evidence.reason };
    }
  } catch (gpuError) {
    if (!preferred) throw gpuError;
    try {
      ctx = await tryInit(false);
      const evidence = await probeContext(ctx);
      loadedBackend = 'CPU';
      loadedEvidence = { gpu: false, deviceName: evidence.deviceName, reason: evidence.reason };
    } catch (cpuError) {
      throw new Error(`Le modèle ne peut pas être chargé sur cet appareil. Accélérateur : ${gpuError instanceof Error ? gpuError.message : 'échec'}. CPU : ${cpuError instanceof Error ? cpuError.message : 'échec'}.`);
    }
  }
  if (!ctx) throw new Error('Moteur local non initialisé.');
  loadedPath = model.path;
}

export function getLoadedBackend(): string {
  return loadedBackend;
}

export function getLoadedRuntimeEvidence(): { gpu: boolean; deviceName?: string; reason?: string } {
  return { ...loadedEvidence };
}

export async function unloadLocalModel(): Promise<void> {
  if (ctx) await ctx.release();
  ctx = null;
  loadedPath = null;
  loadedBackend = 'CPU';
  loadedEvidence = { gpu: false };
}

export async function chatLocal(model: LocalModel, messages: ChatMessage[], totalMemoryMB: number | null): Promise<string> {
  await loadLocalModel(model, totalMemoryMB);
  if (!ctx) throw new Error('Moteur local non initialisé.');
  const result = await ctx.completion({
    messages,
    n_predict: 256,
    temperature: 0.2,
    top_p: 0.9,
    stop: ['</s>', '<|eot_id|>', '<|end_of_text|>'],
  });
  const text = result.text.trim();
  if (!text) throw new Error('Le modèle local n’a produit aucun texte.');
  return text;
}
