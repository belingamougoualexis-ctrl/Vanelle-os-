import { sha256 } from './hash';

const MAX_MOBILE_DATASET_BYTES = 25 * 1024 * 1024;

const piiRegexes = [
  /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i,
  /\b(?:\+?\d[\d .()\-]{7,}\d)\b/,
  /\b\d{11}\b/,
];

export type ProfileResult = {
  rows: number;
  columns: number;
  missingCells: number;
  duplicateRows: number;
  malformedRows: number;
  piiHits: number;
  schemaHash: string;
};

function byteLength(text: string): number {
  return encodeURIComponent(text).replace(/%[0-9A-F]{2}/gi, 'x').length;
}

function stableRowKey(row: string[]): string {
  return JSON.stringify(row.map((v) => v.trim()));
}

function inspectCells(row: string[], columns: number): { missing: number; pii: number } {
  let missing = 0;
  let pii = 0;
  for (let i = 0; i < columns; i += 1) {
    const value = (row[i] ?? '').trim();
    if (!value) missing += 1;
    if (value && piiRegexes.some((regex) => regex.test(value))) pii += 1;
  }
  return { missing, pii };
}

function parseCsv(text: string): { header: string[]; rows: string[][]; malformedRows: number } {
  const input = text.replace(/^\uFEFF/, '');
  const records: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  let malformedRows = 0;

  const pushRow = () => {
    if (row.length === 1 && row[0]?.trim() === '') {
      row = [];
      return;
    }
    row.push(cell);
    cell = '';
    records.push(row);
    row = [];
  };

  for (let i = 0; i < input.length; i += 1) {
    const c = input[i];
    if (quoted) {
      if (c === '"') {
        if (input[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else {
          quoted = false;
        }
      } else {
        cell += c;
      }
      continue;
    }
    if (c === '"' && cell.length === 0) {
      quoted = true;
    } else if (c === ',') {
      row.push(cell);
      cell = '';
    } else if (c === '\n') {
      pushRow();
    } else if (c === '\r') {
      if (input[i + 1] === '\n') i += 1;
      pushRow();
    } else {
      cell += c;
    }
  }

  if (quoted) malformedRows += 1;
  if (row.length > 0 || cell.length > 0) pushRow();

  if (records.length === 0) return { header: [], rows: [], malformedRows };
  const firstRecord = records[0];
  if (!firstRecord) return { header: [], rows: [], malformedRows };
  const header = firstRecord.map((v) => v.trim());
  const rows = records.slice(1);
  const expected = header.length;
  const cleanRows: string[][] = [];
  for (const current of rows) {
    if (current.length !== expected) malformedRows += 1;
    cleanRows.push(current);
  }
  return { header, rows: cleanRows, malformedRows };
}

function stableValue(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(stableValue);
  if (value && typeof value === 'object') {
    const obj = value as Record<string, unknown>;
    return Object.keys(obj).sort().reduce<Record<string, unknown>>((acc, key) => {
      acc[key] = stableValue(obj[key]);
      return acc;
    }, {});
  }
  return value;
}

function stableJson(value: Record<string, unknown>): string {
  return JSON.stringify(stableValue(value));
}

export async function profileCsv(text: string): Promise<ProfileResult> {
  if (byteLength(text) > MAX_MOBILE_DATASET_BYTES) {
    throw new Error('Dataset trop volumineux pour une analyse mobile sûre (limite 25 Mo). Utilise le moteur desktop pour les gros datasets.');
  }
  const parsed = parseCsv(text);
  if (parsed.header.length === 0) {
    return { rows: 0, columns: 0, missingCells: 0, duplicateRows: 0, malformedRows: parsed.malformedRows, piiHits: 0, schemaHash: await sha256('') };
  }
  const seen = new Set<string>();
  let missingCells = 0;
  let duplicateRows = 0;
  let piiHits = 0;
  for (const current of parsed.rows) {
    const key = stableRowKey(current);
    if (seen.has(key)) duplicateRows += 1;
    seen.add(key);
    const inspected = inspectCells(current, parsed.header.length);
    missingCells += inspected.missing;
    piiHits += inspected.pii;
  }
  return {
    rows: parsed.rows.length,
    columns: parsed.header.length,
    missingCells,
    duplicateRows,
    malformedRows: parsed.malformedRows,
    piiHits,
    schemaHash: await sha256(parsed.header.map((v) => v.trim()).join('|')),
  };
}

export async function profileJson(text: string): Promise<ProfileResult> {
  if (byteLength(text) > MAX_MOBILE_DATASET_BYTES) {
    throw new Error('Dataset trop volumineux pour une analyse mobile sûre (limite 25 Mo). Utilise le moteur desktop pour les gros datasets.');
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error('JSON invalide.');
  }
  if (!Array.isArray(parsed) || parsed.some((item) => item === null || typeof item !== 'object' || Array.isArray(item))) {
    throw new Error('Le JSON mobile doit être un tableau d’objets.');
  }
  const rows = parsed as Record<string, unknown>[];
  const keys = [...new Set(rows.flatMap((row) => Object.keys(row)))].sort();
  const seen = new Set<string>();
  let missingCells = 0;
  let duplicateRows = 0;
  let piiHits = 0;
  for (const row of rows) {
    const key = stableJson(row);
    if (seen.has(key)) duplicateRows += 1;
    seen.add(key);
    for (const keyName of keys) {
      const value = row[keyName];
      const textValue = value == null ? '' : typeof value === 'string' ? value : JSON.stringify(value);
      if (!textValue.trim()) missingCells += 1;
      if (textValue && piiRegexes.some((regex) => regex.test(textValue))) piiHits += 1;
    }
  }
  return {
    rows: rows.length,
    columns: keys.length,
    missingCells,
    duplicateRows,
    malformedRows: 0,
    piiHits,
    schemaHash: await sha256(keys.join('|')),
  };
}
