import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { DeviceProfile } from '../core/types';

export function classifyMemory(totalMemoryMB: number | null): DeviceProfile['recommendedModelClass'] {
  if (totalMemoryMB == null) return 'tiny';
  if (totalMemoryMB >= 12000) return 'medium';
  if (totalMemoryMB >= 7000) return 'small';
  if (totalMemoryMB >= 2000) return 'tiny';
  return 'unsupported';
}

export async function detectDevice(): Promise<DeviceProfile> {
  const totalMemoryMB = Device.totalMemory ? Math.round(Device.totalMemory / (1024 * 1024)) : null;
  const isTablet = Device.deviceType === Device.DeviceType.TABLET;
  const platformName = Platform.OS === 'ios' ? 'iOS' : Platform.OS === 'android' ? 'Android' : Platform.OS;
  const os = `${platformName} ${Device.osVersion ?? 'unknown'}`;
  return {
    brand: Device.brand ?? 'Unknown',
    model: Device.modelName ?? 'Unknown device',
    os,
    totalMemoryMB,
    isTablet,
    recommendedModelClass: classifyMemory(totalMemoryMB),
    gpuStrategy: 'auto',
  };
}
