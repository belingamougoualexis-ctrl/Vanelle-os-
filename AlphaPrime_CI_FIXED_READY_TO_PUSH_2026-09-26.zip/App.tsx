import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as Haptics from 'expo-haptics';
import { SafeAreaProvider, SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { DashboardScreen } from './src/screens/DashboardScreen';
import { ProjectsScreen } from './src/screens/ProjectsScreen';
import { DataScreen } from './src/screens/DataScreen';
import { EvaluationScreen } from './src/screens/EvaluationScreen';
import { GovernanceScreen } from './src/screens/GovernanceScreen';
import { ModelScreen } from './src/screens/ModelScreen';
import { AppState } from './src/core/types';
import { EMPTY_STATE, loadState, saveState } from './src/storage/store';
import { detectDevice } from './src/services/device';
import { colors, radii } from './src/ui/theme';
import { useAdaptiveLayout } from './src/ui/adaptive';
import { AmbientBackground } from './src/components/AmbientBackground';

const tabs = [
  ['Accueil', '⌂'], ['Projets', 'P'], ['Données', 'D'], ['Modèle', 'M'], ['Évals', 'E'], ['Gouv.', 'G'],
] as const;
type Tab = typeof tabs[number][0];

type DeviceInfo = Awaited<ReturnType<typeof detectDevice>>;

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <View style={compact ? styles.brandCompact : styles.brandBlock}>
      <View style={styles.brandMark}>
        <View style={styles.brandRingOuter}>
          <View style={styles.brandRingInner} />
        </View>
        <Text style={styles.brandLetter}>A</Text>
      </View>
      {!compact ? (
        <View style={styles.brandCopy}>
          <Text style={styles.brandName}>Alpha Prime</Text>
          <Text style={styles.brandTag}>Local AI Engineering</Text>
        </View>
      ) : null}
    </View>
  );
}

function NavIcon({ icon, active }: { icon: string; active: boolean }) {
  return (
    <View style={[styles.iconBox, active && styles.iconBoxActive]}>
      <Text style={[styles.iconText, active && styles.iconTextActive]}>{icon}</Text>
    </View>
  );
}

function Navigation({ tab, setTab }: { tab: Tab; setTab: (tab: Tab) => void }) {
  const insets = useSafeAreaInsets();
  const { isCompact, isMedium, isShortHeight } = useAdaptiveLayout();
  const side = !isCompact;
  const rail = isMedium;

  const item = (label: Tab, icon: string) => {
    const active = label === tab;
    return (
      <Pressable
        key={label}
        accessibilityRole="tab"
        accessibilityState={{ selected: active }}
        accessibilityLabel={label}
        onPress={() => {
          void Haptics.selectionAsync().catch(() => undefined);
          setTab(label);
        }}
        style={({ pressed }) => [
          side ? (rail ? styles.railItem : styles.sideItem) : styles.navItem,
          active && styles.activeItem,
          pressed && styles.pressed,
        ]}
      >
        <NavIcon icon={icon} active={active} />
        <Text numberOfLines={1} style={[styles.navLabel, active && styles.activeText]}>{label}</Text>
      </Pressable>
    );
  };

  if (side) {
    return (
      <View style={[styles.sidebar, rail && styles.sidebarRail]}>
        <Brand compact={rail} />
        {!rail ? (
          <View style={styles.localSignal}>
            <View style={styles.signalDot} />
            <Text style={styles.signalText}>Local core</Text>
          </View>
        ) : null}
        <View style={rail ? styles.railNav : styles.sideNav}>{tabs.map(([label, icon]) => item(label, icon))}</View>
        {!rail ? (
          <View style={styles.sideFooter}>
            <View style={styles.localCard}>
              <View style={styles.localRow}><View style={styles.signalDot} /><Text style={styles.localCardTitle}>Calcul local</Text></View>
              <Text style={styles.footerNote}>Les données et résultats restent dans l’espace de travail local.</Text>
            </View>
          </View>
        ) : null}
      </View>
    );
  }

  return (
    <View style={[styles.nav, { bottom: Math.max(insets.bottom, 10), height: isShortHeight ? 64 : 72 }]}>
      {tabs.map(([label, icon]) => item(label, icon))}
    </View>
  );
}

function AlphaPrimeApp() {
  const insets = useSafeAreaInsets();
  const { isCompact, horizontalPadding, contentMaxWidth } = useAdaptiveLayout();
  const [tab, setTab] = useState<Tab>('Accueil');
  const [state, setStateRaw] = useState<AppState>(EMPTY_STATE);
  const [device, setDevice] = useState<DeviceInfo | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let alive = true;
    void (async () => {
      try {
        const [loaded, deviceInfo] = await Promise.all([loadState(), detectDevice()]);
        if (!alive) return;
        setStateRaw(loaded);
        setDevice(deviceInfo);
      } finally {
        if (alive) setReady(true);
      }
    })();
    return () => { alive = false; };
  }, []);

  const setState = (next: AppState) => {
    setStateRaw(next);
    void saveState(next).catch(() => undefined);
  };

  const content = useMemo(() => {
    if (!ready) return null;
    switch (tab) {
      case 'Accueil': return <DashboardScreen state={state} device={device ? { model: device.model, recommendedModelClass: device.recommendedModelClass } : null} />;
      case 'Projets': return <ProjectsScreen state={state} setState={setState} />;
      case 'Données': return <DataScreen state={state} setState={setState} />;
      case 'Modèle': return <ModelScreen state={state} setState={setState} device={device} />;
      case 'Évals': return <EvaluationScreen state={state} setState={setState} device={device} />;
      case 'Gouv.': return <GovernanceScreen state={state} />;
    }
  }, [device, ready, state, tab]);

  if (!ready) {
    return (
      <SafeAreaView style={styles.loading}>
        <Brand compact />
        <ActivityIndicator size="small" color={colors.primary} />
        <Text style={styles.loadingText}>Initialisation de l’espace local…</Text>
      </SafeAreaView>
    );
  }

  const side = !isCompact;

  return (
    <AmbientBackground>
      <StatusBar style="dark" />
      <View style={styles.desktopShell}>
        {side ? <Navigation tab={tab} setTab={setTab} /> : null}
        <View style={styles.main}>
          <SafeAreaView edges={['top']}>
            <View style={[styles.header, { paddingHorizontal: horizontalPadding, paddingTop: 8, paddingBottom: 10, marginTop: Math.max(insets.top > 0 ? 0 : 2, 0) }]}>
              <Brand />
              <View style={styles.headerStatus}>
                <View style={styles.signalDot} />
                <Text style={styles.headerStatusText}>Local</Text>
              </View>
            </View>
          </SafeAreaView>
          <View style={[styles.content, { maxWidth: contentMaxWidth, paddingHorizontal: horizontalPadding }]}>{content}</View>
          {!side ? <Navigation tab={tab} setTab={setTab} /> : null}
        </View>
      </View>
    </AmbientBackground>
  );
}

export default function App() {
  return <SafeAreaProvider><AlphaPrimeApp /></SafeAreaProvider>;
}

const styles = StyleSheet.create({
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background, gap: 16 },
  loadingText: { color: colors.muted, fontSize: 13, paddingHorizontal: 24, textAlign: 'center' },
  desktopShell: { flex: 1, flexDirection: 'row' },
  main: { flex: 1, minWidth: 0 },
  sidebar: { width: 238, borderRightWidth: 1, borderRightColor: 'rgba(198,208,228,0.65)', backgroundColor: 'rgba(255,255,255,0.72)', paddingHorizontal: 12, paddingTop: 20, paddingBottom: 16 },
  sidebarRail: { width: 88, alignItems: 'center', paddingHorizontal: 8 },
  brandBlock: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  brandCompact: { alignItems: 'center', justifyContent: 'center' },
  brandMark: { width: 42, height: 42, borderRadius: 15, backgroundColor: colors.darkPanel, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  brandRingOuter: { position: 'absolute', width: 28, height: 28, borderRadius: 14, borderWidth: 1.6, borderColor: colors.accent, transform: [{ rotate: '24deg' }] },
  brandRingInner: { position: 'absolute', width: 13, height: 13, borderRadius: 7, borderWidth: 1.2, borderColor: colors.violet },
  brandLetter: { color: colors.inkOnDark, fontSize: 18, fontWeight: '800', zIndex: 2 },
  brandCopy: { gap: 2 },
  brandName: { color: colors.text, fontSize: 15, fontWeight: '800', letterSpacing: -0.35 },
  brandTag: { color: colors.muted, fontSize: 9, fontWeight: '600', letterSpacing: 0.25 },
  localSignal: { marginTop: 14, marginBottom: 14, marginHorizontal: 5, flexDirection: 'row', alignItems: 'center', gap: 7 },
  signalDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: colors.success, shadowColor: colors.success, shadowOpacity: 0.35, shadowRadius: 7, shadowOffset: { width: 0, height: 0 } },
  signalText: { color: colors.muted, fontSize: 10, fontWeight: '700' },
  sideNav: { gap: 6 },
  railNav: { gap: 8, width: '100%', marginTop: 26 },
  sideItem: { minHeight: 47, borderRadius: radii.md, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 11 },
  railItem: { minHeight: 62, borderRadius: radii.md, alignItems: 'center', justifyContent: 'center', gap: 5, width: '100%' },
  nav: { position: 'absolute', left: 10, right: 10, borderWidth: 1, borderColor: 'rgba(198,208,228,0.85)', borderRadius: 24, backgroundColor: 'rgba(255,255,255,0.94)', flexDirection: 'row', paddingHorizontal: 5, shadowColor: '#13204A', shadowOpacity: 0.13, shadowRadius: 28, shadowOffset: { width: 0, height: 10 }, elevation: 7 },
  navItem: { flex: 1, minWidth: 0, alignItems: 'center', justifyContent: 'center', gap: 3, borderRadius: 18 },
  iconBox: { width: 30, height: 30, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: 'transparent' },
  iconBoxActive: { backgroundColor: colors.primarySoft },
  iconText: { color: colors.mutedLight, fontSize: 13, fontWeight: '800' },
  iconTextActive: { color: colors.primary },
  navLabel: { color: colors.muted, fontSize: 9, fontWeight: '700', letterSpacing: -0.05 },
  activeItem: { backgroundColor: 'rgba(232,236,255,0.88)' },
  activeText: { color: colors.primary },
  pressed: { opacity: 0.75, transform: [{ scale: 0.985 }] },
  sideFooter: { marginTop: 'auto', paddingHorizontal: 4 },
  localCard: { padding: 12, borderWidth: 1, borderColor: colors.line, backgroundColor: 'rgba(255,255,255,0.68)', borderRadius: radii.md },
  localRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  localCardTitle: { color: colors.text, fontSize: 10, fontWeight: '800' },
  footerNote: { color: colors.muted, fontSize: 9, lineHeight: 14, marginTop: 7 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: 'rgba(221,228,242,0.62)', backgroundColor: 'rgba(242,245,255,0.58)' },
  headerStatus: { flexDirection: 'row', gap: 7, alignItems: 'center', paddingHorizontal: 10, paddingVertical: 7, borderRadius: radii.pill, borderWidth: 1, borderColor: colors.line, backgroundColor: 'rgba(255,255,255,0.62)' },
  headerStatusText: { color: colors.textSecondary, fontSize: 10, fontWeight: '800' },
  content: { width: '100%', flex: 1, alignSelf: 'center' },
});
