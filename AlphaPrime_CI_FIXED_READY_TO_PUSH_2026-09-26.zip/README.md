# Alpha Prime 2.1 — Local AI Training OS

Alpha Prime est l'interface mobile Android/iOS du projet AI Training OS existant. Le moteur desktop local reste la voie complète pour les entraînements lourds, la gouvernance et le packaging Windows.

## Principes de fiabilité

Une détection n'est jamais une preuve d'exécution. Les capacités critiques suivent la chaîne `DETECT → VERIFY → TEST → VALIDATE → MONITOR`.

Les états `VERIFIED`, `DEGRADED`, `NOT VERIFIED`, `FAILED`, `RECOVERING` et `TESTING` sont utilisés pour éviter de transformer une hypothèse, une configuration ou une détection matérielle en succès.

Aucune métrique, réponse, checkpoint, modèle ou performance n'est préremplie comme résultat réel. Lorsqu'une preuve manque, l'interface l'indique.

## Interface adaptative

L'interface mobile utilise des classes de fenêtre basées sur l'espace réellement disponible : `compact`, `medium`, `expanded`, `large`, avec prise en compte de la hauteur courte pour les téléphones en paysage. Le même système pilote la navigation : barre inférieure sur les fenêtres compactes/moyennes et navigation latérale sur les fenêtres larges.

Les contenus restent centrés avec une largeur maximale, les marges s'ajustent aux fenêtres, les zones sûres iOS/Android sont respectées et les tailles de texte utilisent les polices système afin de rester natives et lisibles sur chaque plateforme.

## Design system

La palette part d'un fond blanc froid, de surfaces nettes, d'un bleu principal cobalt, d'un accent aqua/vert, d'un texte bleu nuit et de bordures très légères. Les rayons, espacements, boutons, cartes et états partagent les mêmes tokens pour éviter les incohérences entre écrans.

L'icône Alpha Prime utilise le même langage visuel sombre/cobalt/aqua que l'interface.

## Fonctionnement local mobile

- état et projets : stockage local ;
- datasets CSV/JSON : traitement local ;
- modèles : import GGUF local avec inspection réelle llama.cpp ;
- runtime : llama.rn / llama.cpp ;
- avant d'afficher une inférence comme testée, l'application effectue un chargement réel puis une inférence réelle ;
- si l'état local est corrompu, le payload est placé en quarantaine puis l'application redémarre sur un état vide valide plutôt que d'écraser silencieusement les données.

## Modèles et matériel

L'application détecte la mémoire et les backends disponibles puis choisit une configuration mémoire prudente. Un GPU n'est pas déclaré opérationnel parce qu'il est seulement détecté : l'initialisation du backend doit réussir. Si le backend GPU échoue pendant le chargement, le moteur tente le CPU et expose ce fallback.

## Workflow GitHub Actions

Le workflow principal est `.github/workflows/build-all-platforms.yml`. Il comporte trois gates de plateforme :

- **Windows** : tests réels du moteur local, syntaxe Python/JS, build PyInstaller, vérification de `AlphaPrime.exe`.
- **Android** : `expo prebuild`, APK release, installation et démarrage sur émulateur Android.
- **iOS** : `expo prebuild`, CocoaPods, build IPA Release iOS et validation sur appareil iOS physique connecté au runner.

La publication des artefacts dépend du succès des vérifications correspondantes.

Le workflow n'utilise pas `npm ci` car aucun `package-lock.json` n'est actuellement commis. Il utilise donc `npm install` jusqu'à ce qu'un lockfile reproductible soit ajouté.

## Limites honnêtes

Le CI vérifie réellement les environnements disponibles sur ses runners, mais cela ne prouve pas tous les appareils physiques. Les téléphones Android, GPU mobiles, Apple Silicon physiques, Windows ARM64 physiques et autres combinaisons non exécutés restent `NOT VERIFIED — ENVIRONMENT UNAVAILABLE`.

Une compilation iOS ne constitue pas à elle seule une preuve d'exécution sur un appareil iOS physique.


## Physical-device release policy

Alpha Prime distingue strictement BUILD VERIFIED et DEVICE VERIFIED. Les APK/IPA signés sont produits avant la validation physique, puis les runners auto-hébergés connectés à de vrais appareils peuvent effectuer l’installation et le lancement réels.
