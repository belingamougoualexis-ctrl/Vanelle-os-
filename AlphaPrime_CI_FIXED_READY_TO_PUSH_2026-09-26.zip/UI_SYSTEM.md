# Alpha Prime — UI System

The product UI uses one visual language across the mobile app and desktop dashboard.

- Primary: indigo for core actions and verified navigation state.
- Secondary accents: cyan and violet for controlled emphasis.
- Surfaces: light neutral/white with deep indigo panels for command areas.
- Typography: platform system fonts for readability and accessibility.
- Layout: window-space driven, not device-name driven.
- Mobile: compact bottom navigation; medium rail; expanded/large sidebar.
- Desktop: responsive grid and max content width.
- No seeded metrics/results in production UI.
- Critical status badges must originate from backend evidence.
