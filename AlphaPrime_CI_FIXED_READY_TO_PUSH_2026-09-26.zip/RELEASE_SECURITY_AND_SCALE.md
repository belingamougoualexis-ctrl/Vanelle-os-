# Alpha Prime — Release Security & Scale

## Principes

- Aucun état de fonctionnement n’est déclaré sans exécution réelle.
- Le GPU est déclaré utilisable uniquement après chargement et contrôle d’inférence du runtime natif.
- Les chemins, paramètres internes et détails d’infrastructure ne sont pas affichés dans l’interface normale.
- Les champs de saisie restent copiables/collables lorsque cela est nécessaire à la tâche.
- Le serveur desktop écoute uniquement sur `127.0.0.1` par défaut.
- Les archives de modèles et ressources téléchargées sont vérifiées par empreinte avant activation lorsqu’une empreinte officielle est disponible.
- Les builds Android de production activent R8 et la suppression des ressources inutilisées.

## Anti-piratage

Une application locale ne peut pas être rendue inviolable : son code et ses ressources nécessaires à l’exécution sont présents sur l’appareil. Alpha Prime applique donc une défense en profondeur : minification, réduction des ressources, absence de secrets intégrés, validation d’intégrité des modèles, et séparation stricte des éléments de développement et de production.

## Échelle

Le cœur de calcul étant local et sans session serveur obligatoire, le traitement ne consomme pas une ressource centrale par utilisateur. Une audience mondiale peut ainsi être servie sans transformer chaque inférence en requête vers un backend central. Cela ne constitue pas une preuve qu’un milliard d’utilisateurs ont été testés simultanément : une telle capacité doit être validée par une campagne de charge réelle sur l’infrastructure de distribution et, le cas échéant, les services optionnels.
