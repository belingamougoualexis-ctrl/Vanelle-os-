from __future__ import annotations
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def fail(msg: str) -> None:
    raise SystemExit(f"RELEASE GATE FAILED: {msg}")

pkg = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))
app = json.loads((ROOT / "app.json").read_text(encoding="utf-8"))["expo"]

name = str(app.get("name", ""))
if not name or len(name) > 30:
    fail("Nom d'application absent ou trop long pour la publication mobile.")
if re.search(r"[\u200b-\u200f\u202a-\u202e\u2060-\u206f]", name):
    fail("Caractère Unicode de contrôle dans le nom.")
if app.get("android", {}).get("package") != "com.alphaprime.local":
    fail("Identifiant Android inattendu.")
if app.get("ios", {}).get("bundleIdentifier") != "com.alphaprime.local":
    fail("Bundle identifier iOS inattendu.")

icon = ROOT / app["icon"].replace("./", "")
if not icon.is_file():
    fail(f"Icône absente: {icon}")
# Read PNG dimensions without requiring Pillow in the release environment.
if icon.suffix.lower() == ".png":
    raw = icon.read_bytes()
    if raw[:8] != b"\x89PNG\r\n\x1a\n" or len(raw) < 24:
        fail("Icône PNG invalide.")
    width = int.from_bytes(raw[16:20], "big")
    height = int.from_bytes(raw[20:24], "big")
    if width != height or width < 256:
        fail("Icône non carrée ou trop petite.")

# No developer-only runtime endpoints in the mobile package configuration.
if app.get("extra", {}).get("llmRuntimeVerification") != "required":
    fail("La vérification réelle du runtime LLM n'est pas obligatoire.")
if app.get("extra", {}).get("aiRuntime") != "llama.cpp":
    fail("Le runtime mobile attendu n'est pas llama.cpp.")
if app.get("extra", {}).get("mobileModelFormat") != "GGUF":
    fail("Le format mobile attendu n'est pas GGUF.")

# Avoid shipping generated caches and secrets in the source artifact.
for rel in ("node_modules", ".expo", "android", "ios", "dist"):
    if (ROOT / rel).exists():
        fail(f"Répertoire généré trouvé dans le paquet source: {rel}")

for pattern in ("*.pem", "*.p12", "*.pfx", "*.key"):
    if list(ROOT.rglob(pattern)):
        fail(f"Matériel de clé trouvé dans le projet: {pattern}")

print("RELEASE GATE: PASS")
print(f"name={name}")
print(f"version={pkg.get('version')}")
print("llm_runtime=llama.cpp")
print("llm_verification=required")
print("secrets_in_source=none_detected")
