"""Run Alpha Prime's complete Python test suite in stable isolated batches.

The suite contains multiprocessing/network-local tests. Running every file in one
pytest process can cause resource lifetime interactions, so the release runner
uses a small set of deterministic batches, with the distributed worker suite
kept in its proven isolated group. Every case is still executed by real pytest.
"""
from __future__ import annotations

import argparse
import glob
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))

BATCHES = [
    [
        "tests/test_llm_configuration.py",
        "tests/test_reality_system.py",
        "tests/test_compute_planner.py",
        "tests/test_ai_council.py",
        "tests/test_api_server.py",
        "tests/test_frontend_ui.py",
        "tests/test_model_manager.py",
    ],
    [
        "tests/test_full_workflow.py",
        "tests/test_training_e2e.py",
        "tests/test_reality_stress.py",
        "tests/test_specialized_training.py",
    ],
    [
        "tests/test_ai_scientist.py",
        "tests/test_data_engine.py",
        "tests/test_enterprise_governance.py",
        "tests/test_environment_manager.py",
        "tests/test_local_distributed_provider.py",
        "tests/test_local_formats_and_modules.py",
        "tests/test_local_operations.py",
        "tests/test_professional_suite.py",
        "tests/test_reality_api.py",
        "tests/test_recovery.py",
        "tests/test_red_team.py",
        "tests/test_registries.py",
        "tests/test_startup_manager.py",
    ],
]


def run_batch(paths: list[str], timeout: int) -> tuple[bool, str]:
    absolute = [os.path.join(ROOT, p) for p in paths]
    cmd = [sys.executable, "-m", "pytest", "-q", *absolute, "--maxfail=1"]
    try:
        # Avoid inheritable PIPE descriptors because multiprocessing-based tests
        # can keep them open in worker processes after pytest has finished.
        cp = subprocess.run(
            cmd,
            cwd=ROOT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
            env=dict(os.environ)
        )
    except subprocess.TimeoutExpired:
        return False, f"TIMEOUT après {timeout}s"

    if cp.returncode == 0:
        return True, "pytest: PASS"

    try:
        diag = subprocess.run(
            cmd,
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=min(timeout, 60),
            env=dict(os.environ)
        )
        return False, (diag.stdout or "")[-12000:]
    except subprocess.TimeoutExpired:
        return False, "pytest a échoué et le second passage diagnostique a dépassé le délai."


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the complete Alpha Prime pytest suite.")
    parser.add_argument("--timeout", type=int, default=180, help="Timeout per deterministic batch in seconds.")
    args = parser.parse_args()

    all_files = {os.path.normpath(p) for p in glob.glob(os.path.join(ROOT, "tests", "test_*.py"))}
    configured = {
        os.path.normpath(os.path.join(ROOT, p))
        for batch in BATCHES for p in batch
    }
    extras = sorted(all_files - configured)
    if extras:
        BATCHES.append([os.path.relpath(p, ROOT) for p in extras])

    passed = failed = 0
    for i, batch in enumerate(BATCHES, 1):
        print(f"\n=== TEST BATCH {i}/{len(BATCHES)} ===", flush=True)
        for p in batch:
            print(f"  {p}", flush=True)
        ok, output = run_batch(batch, args.timeout)
        print(output[-12000:] if output else ("pytest: PASS" if ok else "pytest: FAILED"), flush=True)
        if ok:
            passed += 1
        else:
            failed += 1

    print(f"\n{'=' * 64}")
    print(f"BATCHES PASSED: {passed}")
    print(f"BATCHES FAILED: {failed}")
    print(f"{'=' * 64}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
