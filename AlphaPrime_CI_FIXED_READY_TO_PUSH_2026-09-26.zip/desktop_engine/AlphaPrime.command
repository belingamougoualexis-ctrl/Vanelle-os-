#!/bin/bash
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 n'est pas installé. Installez-le depuis https://www.python.org/downloads/ puis relancez ce fichier."
  read -p "Appuyez sur Entrée pour fermer..."
  exit 1
fi
python3 alpha_prime_launch.py
read -p "Appuyez sur Entrée pour fermer..."
