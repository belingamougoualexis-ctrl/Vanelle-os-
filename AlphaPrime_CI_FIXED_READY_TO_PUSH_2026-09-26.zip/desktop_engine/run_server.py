#!/usr/bin/env python3
import argparse
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
from ai_training_os.api_server import serve_forever

parser = argparse.ArgumentParser(description="AI Training OS local server")
parser.add_argument("--workspace", default=os.path.join(ROOT, "workspace"))
parser.add_argument("--host", default="127.0.0.1")
parser.add_argument("--port", type=int, default=8787)
args = parser.parse_args()
serve_forever(args.workspace, args.host, args.port)
