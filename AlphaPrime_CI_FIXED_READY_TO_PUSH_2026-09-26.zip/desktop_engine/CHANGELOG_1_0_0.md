# Alpha Prime 1.0.0 — Enterprise Local

## Ajouts fonctionnels
- Data Quality & PII : profilage local et détection PII sans restitution des valeurs détectées.
- Data Contracts : contrats de schéma et seuils de qualité validables.
- Dataset Drift : comparaison réelle de versions locales.
- Lineage : traçabilité locale des datasets, expériences et versions de modèles.
- Model Cards : génération locale, hashée et exportable.
- Golden Evaluation Suites : réévaluation locale d’artefacts pickle compatibles.
- Human Approval : approbation nominative après les contrôles automatiques du Safety Gate.
- SBOM : inventaire local des composants inclus dans les packages de livraison.
- Export/import : conservation des artefacts de gouvernance dans les exports de projet.
- UI : suppression de la dépendance Google Fonts/CDN pour conserver une interface 100 % locale côté rendu.

## Vérité opérationnelle
Aucune nouvelle fonction ne fabrique un dataset, une métrique, un matériel, un modèle ou un état distant. Les contrôles utilisent uniquement les fichiers et enregistrements présents dans le workspace local.
