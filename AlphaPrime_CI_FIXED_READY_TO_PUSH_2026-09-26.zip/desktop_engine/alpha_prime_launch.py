"""
alpha_prime_launch.py — point d'entrée unique et automatique.

Objectif : l'utilisateur ne doit RIEN deviner ni taper de commande pip/venv.
Ce script, lancé une seule fois (ou via AlphaPrime.bat / AlphaPrime.command),
fait tout lui-même et rapporte honnêtement chaque étape :

  1. Vérifie la version de Python.
  2. Crée un environnement virtuel local (./.venv) s'il n'existe pas.
  3. Installe automatiquement les dépendances requises (requirements.txt).
  4. Détecte le matériel réel (CPU/GPU) et tente, uniquement si un GPU est
     détecté, l'installation automatique du support GPU (torch). Best-effort :
     si l'installation échoue (pas de réseau, pas de GPU compatible), le
     module concerné reste marqué UNAVAILABLE — jamais fabriqué comme REAL.
  5. Démarre le serveur local et ouvre automatiquement le navigateur.

Rien n'est envoyé hors de la machine. Les installations pip utilisées sont
les mêmes que celles documentées dans requirements.txt / requirements-*.txt.
"""
from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
import time
import venv
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV_DIR = ROOT / ".venv"
LOG_PREFIX = "[AlphaPrime setup]"


def log(msg: str) -> None:
    print(f"{LOG_PREFIX} {msg}", flush=True)


def venv_python() -> Path:
    if platform.system() == "Windows":
        return VENV_DIR / "Scripts" / "python.exe"
    return VENV_DIR / "bin" / "python"


def ensure_venv() -> Path:
    py = venv_python()
    if py.exists():
        log(f"Environnement virtuel déjà présent : {VENV_DIR} (REAL, réutilisé)")
        return py
    log(f"Création de l'environnement virtuel local : {VENV_DIR}")
    venv.EnvBuilder(with_pip=True).create(str(VENV_DIR))
    if not py.exists():
        raise RuntimeError(
            "Échec réel de la création du venv : interpréteur introuvable après création."
        )
    log("Environnement virtuel créé (REAL).")
    return py


def pip_install(py: Path, args: list[str], label: str) -> bool:
    """Best-effort pip install. Returns True on real success, False on real
    failure (reported honestly, never silently assumed to have worked)."""
    cmd = [str(py), "-m", "pip", "install", "--quiet", "--disable-pip-version-check", *args]
    log(f"Installation : {label} ...")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    except Exception as exc:  # network absent, timeout, etc.
        log(f"ÉCHEC RÉEL ({label}) : {exc}")
        return False
    if result.returncode != 0:
        tail = (result.stderr or result.stdout or "").strip().splitlines()[-1:] or [""]
        log(f"ÉCHEC RÉEL ({label}) : {tail[0]}")
        return False
    log(f"OK (REAL) : {label}")
    return True


def detect_gpu() -> bool:
    """Real, honest GPU detection — never assumed present."""
    if shutil.which("nvidia-smi"):
        try:
            r = subprocess.run(["nvidia-smi", "-L"], capture_output=True, text=True, timeout=10)
            if r.returncode == 0 and r.stdout.strip():
                log(f"GPU NVIDIA détecté (REAL) : {r.stdout.strip().splitlines()[0]}")
                return True
        except Exception:
            pass
    if platform.system() == "Darwin" and platform.machine() == "arm64":
        log("Apple Silicon détecté (REAL) — support MPS possible via torch.")
        return True
    log("Aucun GPU détecté (REAL) — le mode CPU sera utilisé.")
    return False


def main() -> None:
    if sys.version_info < (3, 9):
        log(f"ÉCHEC : Python {platform.python_version()} détecté, 3.9+ requis. "
            "Installez une version récente de Python puis relancez ce script.")
        sys.exit(1)

    py = ensure_venv()

    req = ROOT / "requirements.txt"
    core_ok = pip_install(py, ["-r", str(req)], "dépendances de base (requirements.txt)")
    if not core_ok:
        log("Les dépendances de base n'ont pas pu être installées automatiquement "
            "(pas de réseau ?). Le serveur va quand même être tenté : certaines "
            "fonctionnalités resteront UNAVAILABLE tant que ceci n'est pas résolu.")

    has_gpu = detect_gpu()
    if has_gpu:
        gpu_ok = pip_install(py, ["torch"], "support GPU (torch)")
        if not gpu_ok:
            log("Support GPU non installé automatiquement — le mode CPU reste "
                "pleinement fonctionnel ; le GPU restera UNAVAILABLE jusqu'à "
                "une installation manuelle ou une connexion réseau disponible.")

    # LLM/fine-tuning stack is a required application capability. These four
    # packages are installed automatically on the target machine; failure is
    # reported and the corresponding features remain explicitly UNAVAILABLE.
    llm_req = ROOT / "requirements-local-llm.txt"
    if llm_req.exists():
        llm_ok = pip_install(py, ["-r", str(llm_req)], "LLM + fine-tuning (transformers/peft/datasets/accelerate)")
        # Hard verification: never claim success from pip's exit code alone.
        verify = subprocess.run([str(py), "-c", "import transformers,peft,datasets,accelerate; print('LLM_STACK_OK')"], capture_output=True, text=True)
        if verify.returncode != 0:
            llm_ok = False
            log("VÉRIFICATION ÉCHEC : transformers/peft/datasets/accelerate ne sont pas tous importables dans le venv local.")
        else:
            log("VÉRIFICATION REAL : transformers/peft/datasets/accelerate importables dans le venv local.")
        if not llm_ok:
            log("ATTENTION : le stack LLM n'est pas encore installé. Le serveur démarrera, mais aucun entraînement LLM ne sera déclaré READY tant que l'installation réelle n'aura pas réussi.")

    # bitsandbytes is deliberately conditional: QLoRA needs a supported CUDA
    # environment; installing it blindly on CPU machines causes false failures.
    if has_gpu and (ROOT / "requirements-qlora.txt").exists():
        pip_install(py, ["-r", str(ROOT / "requirements-qlora.txt")], "accélération QLoRA (bitsandbytes)")

    desktop_req = ROOT / "requirements-desktop.txt"
    desktop_ok = False
    if desktop_req.exists():
        desktop_ok = pip_install(py, ["-r", str(desktop_req)], "fenêtre native (pywebview)")

    if desktop_ok:
        log("Lancement en fenêtre native (Alpha Prime en tant qu'application desktop).")
        subprocess.run([str(py), str(ROOT / "desktop_app.py")], cwd=str(ROOT))
        return

    log("Fenêtre native indisponible (pywebview non installé) — "
        "ouverture dans le navigateur par défaut à la place.")
    workspace = ROOT / "workspace"
    port = 8787
    log(f"Démarrage du serveur local sur http://127.0.0.1:{port}/ "
        f"(workspace: {workspace})")

    server = subprocess.Popen(
        [str(py), str(ROOT / "run_server.py"), "--workspace", str(workspace), "--port", str(port)],
        cwd=str(ROOT),
    )
    time.sleep(2)
    try:
        webbrowser.open(f"http://127.0.0.1:{port}/")
    except Exception:
        log(f"Impossible d'ouvrir le navigateur automatiquement — ouvrez "
            f"manuellement http://127.0.0.1:{port}/")

    log("Alpha Prime tourne. Fermez cette fenêtre pour arrêter le serveur.")
    try:
        server.wait()
    except KeyboardInterrupt:
        server.terminate()


if __name__ == "__main__":
    main()
