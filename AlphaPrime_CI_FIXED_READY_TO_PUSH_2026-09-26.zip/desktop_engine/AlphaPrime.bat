@echo off
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python n'est pas installe ou pas dans le PATH.
  echo Installez Python 3.9+ depuis https://www.python.org/downloads/ puis relancez ce fichier.
  pause
  exit /b 1
)
python alpha_prime_launch.py
pause
