"""Launch the AlphaPrime server compute agent."""
from ai_training_os.environment.server_agent import serve
import argparse
p=argparse.ArgumentParser()
p.add_argument('--host', default='127.0.0.1', help='Interface locale par défaut; utilisez explicitement une adresse LAN si nécessaire.')
p.add_argument('--port', type=int, default=8765)
a=p.parse_args(); serve(a.host,a.port)
