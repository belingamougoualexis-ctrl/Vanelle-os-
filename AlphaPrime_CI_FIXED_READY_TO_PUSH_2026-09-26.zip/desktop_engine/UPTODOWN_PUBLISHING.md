# Publication Alpha Prime sur Uptodown

## Cible

Uptodown documente actuellement la publication d’applications Android, Windows et Mac. L’IPA iOS doit donc être distribué par un canal iOS adapté ; il ne faut pas présenter l’IPA comme un livrable Uptodown.

## Préparation Alpha Prime

- Nom : **Alpha Prime**.
- Identifiant Android : `com.alphaprime.local`.
- Version : `2.1.0`.
- L’APK/AAB et l’exécutable Windows sont produits par les workflows de release.
- Les binaires doivent être testés sur leurs appareils ou systèmes cibles avant soumission.
- L’icône est carrée et dimensionnée bien au-dessus du minimum technique indiqué par Uptodown.
- La description, les captures d’écran et la politique de confidentialité doivent décrire le fonctionnement réel de l’application.

## Règles à contrôler avant l’envoi

- L’application doit fonctionner correctement et avoir une fonction clairement identifiable.
- Aucun malware, comportement nuisible ou mécanisme trompeur.
- Pas d’écran constitué uniquement d’un WebView pauvre ou d’un modèle non personnalisé.
- Pas de contenu promotionnel trompeur dans le titre, l’icône ou la fiche.
- Les droits de publication et les éléments de marque utilisés doivent être autorisés.
- Une politique de confidentialité publique doit être fournie lorsque nécessaire.

## Sécurité

Alpha Prime ne peut pas être rendu « inviolable » sur une machine contrôlée par l’utilisateur. La protection repose sur une défense en profondeur : absence de secrets embarqués, contrôle d’intégrité, durcissement du build, réduction/minification des ressources et validation des artefacts.

## Limite importante

Une validation CI réussie prouve la réussite des tests exécutés par la CI ; elle ne prouve pas la compatibilité de tous les PC, téléphones et versions d’OS existants. Les appareils physiques restent le niveau de preuve nécessaire pour les validations matérielles.
