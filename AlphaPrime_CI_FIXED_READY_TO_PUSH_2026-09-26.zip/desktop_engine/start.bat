@echo off
set "WORKSPACE=%AITOS_WORKSPACE%"
if "%WORKSPACE%"=="" set "WORKSPACE=./workspace"
set "PORT=%AITOS_PORT%"
if "%PORT%"=="" set "PORT=8787"
python run_server.py --workspace "%WORKSPACE%" --port "%PORT%"
