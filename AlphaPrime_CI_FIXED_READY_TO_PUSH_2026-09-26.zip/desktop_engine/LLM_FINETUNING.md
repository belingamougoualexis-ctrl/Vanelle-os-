Alpha Prime 1.0.0

# Alpha Prime — LLM LoRA / QLoRA

Alpha Prime now has a real local causal-LM fine-tuning path.

## Pipeline
1. The packaged app automatically bootstraps the local llama.cpp runtime, local Council GGUF, embeddings model, and a trainable Qwen2.5-0.5B-Instruct Transformers base.
2. The base model and files are SHA-256 verified before being reported READY.
3. The user selects a local dataset and either LoRA or QLoRA.
4. The engine tokenizes real records, creates a train/test split, trains a real PEFT adapter, evaluates before/after, and runs a post-training generation smoke test.
5. Only after the smoke test passes is a delivery ZIP produced.

## LoRA / QLoRA
- LoRA uses PEFT adapters and freezes the base model.
- QLoRA uses 4-bit bitsandbytes quantization and requires a compatible CUDA environment.
- No simulated success is emitted. Missing dependencies or incompatible hardware return UNAVAILABLE with cause and solution.

## Delivery
The generated ZIP contains the adapter, tokenizer/configuration files, training metadata, SHA-256 and INSTALL.md. The exact base model used is recorded so the adapter can be reproduced and loaded correctly.

## 0.9.0 — configuration LLM réelle et fine-tuning

Alpha Prime crée automatiquement `llm_models/llm_config.json`. Les profils `council`, `scientist`, `verification` et `general` définissent température, top-p, top-k, répétition, contexte et longueur maximale. Ces paramètres sont transmis au backend local utilisé; ils ne sont pas de simples valeurs d'interface.

Le lanceur installe automatiquement `transformers`, `peft`, `datasets` et `accelerate`. `bitsandbytes` est installé uniquement lorsqu'un GPU CUDA compatible est réellement détecté, car il est nécessaire au chemin QLoRA.

Le script `scripts/verify_llm_stack.py` ne déclare `READY` que si les dépendances sont réellement importables. Une inférence réelle nécessite en plus un modèle local valide et est vérifiée par `LocalLLMProvider.verify_model()`.
