"""Local configuration persisted as JSON; no secrets are stored here by default."""
import os, json
class ConfigStore:
    def __init__(self,path): self.path=path; os.makedirs(os.path.dirname(os.path.abspath(path)),exist_ok=True)
    def defaults(self): return {"version":1,"workspace":os.path.dirname(self.path),"server":{"host":"127.0.0.1","port":8787},"mode":"expert","secrets_backend":"environment-only"}
    def load(self):
        if not os.path.isfile(self.path): return self.defaults()
        with open(self.path,encoding="utf-8") as f:return json.load(f)
    def save(self,data):
        with open(self.path,"w",encoding="utf-8") as f: json.dump(data,f,ensure_ascii=False,indent=2)
        return {"status":"REAL","path":self.path}
