"""Local model strategy planner and capability matrix."""


class ModelEngine:
    SUPPORTED = {
        "classification": [
            "logistic_regression", "random_forest", "sgd_incremental", "mlp_sklearn", "mlp_torch",
            "text_tfidf", "pdf_tfidf", "image_pixel_logreg", "audio_spectral_logreg", "video_frame_stats_logreg"
        ],
        "regression": ["linear_regression", "random_forest_regressor", "sgd_regressor"],
        "clustering": ["kmeans"],
    }

    GPU_MODELS = {"mlp_torch"}
    SPECIALIZED = {"text_tfidf", "pdf_tfidf", "image_pixel_logreg", "audio_spectral_logreg", "video_frame_stats_logreg"}

    def plan(self, problem_type, data_stats, compute_plan, requested_model_type=None):
        candidates = self.SUPPORTED.get(problem_type, [])
        if not candidates:
            return {"status": "UNAVAILABLE", "reason": "Aucun moteur local intégré pour ce type de problème.", "candidates": []}
        requested = requested_model_type if requested_model_type not in (None, "", "auto") else None
        if requested and requested not in candidates:
            return {"status": "UNAVAILABLE", "reason": f"Modèle local '{requested}' non supporté pour {problem_type}.", "candidates": candidates}

        selected_provider = compute_plan.get("selected_provider")
        gpu_ready = selected_provider in ("LOCAL_GPU_PROVIDER", "LOCAL_MULTI_GPU_PROVIDER")
        torch_ready = bool(data_stats.get("torch_available"))
        modality = data_stats.get("modality")

        if requested == "mlp_torch" and not torch_ready:
            return {"status": "UNAVAILABLE", "reason": "mlp_torch nécessite PyTorch localement.", "candidates": candidates}
        if requested in {"mlp_torch", "mlp_sklearn"} and modality not in (None, "tabular"):
            return {"status": "UNAVAILABLE", "reason": f"{requested} attend actuellement des features tabulaires numériques; modalité détectée: {modality}.", "candidates": candidates}

        if requested and requested in self.SPECIALIZED:
            required_modality = {
                "text_tfidf": "text", "pdf_tfidf": "pdf",
                "image_pixel_logreg": "image", "audio_spectral_logreg": "audio",
                "video_frame_stats_logreg": "video",
            }[requested]
            if modality != required_modality:
                return {"status": "UNAVAILABLE", "reason": f"{requested} nécessite des données {required_modality}; données détectées: {modality or 'inconnues'}.", "candidates": candidates}

        n = int(data_stats.get("n_rows", 0))
        if requested:
            selected = requested
        elif modality == "text":
            selected = "text_tfidf"
        elif modality == "pdf":
            selected = "pdf_tfidf"
        elif modality == "image":
            selected = "image_pixel_logreg"
        elif modality == "audio":
            selected = "audio_spectral_logreg"
        elif modality == "video":
            selected = "video_frame_stats_logreg"
        elif problem_type == "classification" and gpu_ready:
            selected = "mlp_torch"
        elif problem_type == "classification" and n > 10000:
            selected = "sgd_incremental"
        else:
            selected = candidates[0]

        provider = selected_provider if selected in self.GPU_MODELS and gpu_ready else "LOCAL_CPU_PROVIDER"
        return {
            "status": "REAL", "problem_type": problem_type, "modality": modality,
            "candidates": candidates, "selected": selected, "strategy": "from_scratch",
            "compute_tier": compute_plan.get("selected_tier"), "selected_provider": provider,
            "gpu_available": gpu_ready, "torch_available": torch_ready,
        }
