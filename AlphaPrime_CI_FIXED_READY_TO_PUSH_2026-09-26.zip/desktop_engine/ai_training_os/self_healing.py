"""Safe self-healing for a small allowlist of reversible local operations."""
from __future__ import annotations

import json
import os
import shutil
import threading
import time
from pathlib import Path
from typing import Any, Callable

from . import utils


class SafeSelfHealing:
    SAFE_ACTIONS = {"ensure_directory", "cleanup_temp_file", "restore_file_backup", "replace_json_config"}

    def __init__(self, workspace: str, audit=None, conn=None):
        self.workspace = Path(workspace).resolve()
        self.audit = audit
        self.conn = conn
        self.root = self.workspace / ".recovery" / "healing"
        self._lock = threading.Lock()
        self.root.mkdir(parents=True, exist_ok=True)

    def _confined(self, path: str | Path) -> Path:
        target = Path(path).resolve()
        if os.path.commonpath([str(self.workspace), str(target)]) != str(self.workspace):
            raise ValueError("Opération hors workspace refusée")
        return target

    def _backup(self, path: Path) -> Path | None:
        if not path.exists():
            return None
        stamp = f"{time.strftime('%Y%m%d-%H%M%S')}-{time.time_ns() % 1_000_000_000:09d}"
        backup_root = self.root / stamp
        backup_root.mkdir(parents=True, exist_ok=True)
        backup = backup_root / path.name
        if path.is_file():
            shutil.copy2(path, backup)
        elif path.is_dir():
            shutil.copytree(path, backup)
        else:
            raise ValueError("Type de fichier non supporté pour sauvegarde")
        return backup

    def run(self, action: str, target: str, verify: Callable[[], bool], **kwargs: Any) -> dict[str, Any]:
        if action not in self.SAFE_ACTIONS:
            raise ValueError(f"Action de réparation non autorisée: {action}")

        with self._lock:
            path = self._confined(target)
            backup = self._backup(path)
            details = {"action": action, "target": str(path), "backup": str(backup) if backup else None}
            tmp: Path | None = None
            try:
                if action == "ensure_directory":
                    path.mkdir(parents=True, exist_ok=True)
                elif action == "cleanup_temp_file":
                    if path.exists() and path.is_file():
                        stamp = f"{time.strftime('%Y%m%d-%H%M%S')}-{time.time_ns() % 1_000_000_000:09d}"
                        moved = self.root / stamp / path.name
                        moved.parent.mkdir(parents=True, exist_ok=True)
                        shutil.move(str(path), str(moved))
                        details["moved_to_backup"] = str(moved)
                elif action == "restore_file_backup":
                    backup_path = self._confined(kwargs["backup_path"])
                    if not backup_path.is_file():
                        raise ValueError("Backup introuvable")
                    path.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(backup_path, path)
                elif action == "replace_json_config":
                    new_value = kwargs.get("value")
                    if not isinstance(new_value, dict):
                        raise ValueError("La nouvelle configuration doit être un objet JSON")
                    path.parent.mkdir(parents=True, exist_ok=True)
                    tmp = path.with_suffix(path.suffix + ".tmp")
                    tmp.write_text(json.dumps(new_value, ensure_ascii=False, indent=2), encoding="utf-8")
                    os.replace(tmp, path)
                    tmp = None

                if not bool(verify()):
                    raise RuntimeError("TEST_POST_REPAIR_FAILED")

                result = {"status": "VERIFIED", "operation_status": "COMMITTED", **details}
                if self.conn:
                    self.conn.execute(
                        "INSERT INTO repair_runs (id,action,status,backup_path,details_json,created_at) VALUES (?,?,?,?,?,?)",
                        (utils.new_id("repair"), action, result["status"], details.get("backup"), utils.dumps(result), utils.now_iso()),
                    )
                    self.conn.commit()
                if self.audit:
                    self.audit.log("system", "SAFE_HEAL_COMMITTED", "repair", None, result)
                return result
            except Exception as exc:
                if tmp is not None:
                    try:
                        tmp.unlink(missing_ok=True)
                    except OSError:
                        pass
                rollback_error = None
                try:
                    if backup and backup.exists():
                        if path.is_dir() and backup.is_dir():
                            shutil.rmtree(path, ignore_errors=True)
                            shutil.copytree(backup, path)
                        elif backup.is_file():
                            path.parent.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(backup, path)
                    elif action == "ensure_directory" and not backup and path.exists():
                        shutil.rmtree(path, ignore_errors=True)
                    elif action == "replace_json_config" and not backup and path.exists():
                        path.unlink(missing_ok=True)
                except Exception as rb_exc:
                    rollback_error = f"{type(rb_exc).__name__}: {rb_exc}"
                result = {
                    "status": "FAILED" if rollback_error is None else "RECOVERING",
                    "operation_status": "ROLLED_BACK" if rollback_error is None else "ROLLBACK_FAILED",
                    **details,
                    "cause": f"{type(exc).__name__}: {exc}",
                    "rollback_error": rollback_error,
                }
                if self.conn:
                    self.conn.execute(
                        "INSERT INTO repair_runs (id,action,status,backup_path,details_json,created_at) VALUES (?,?,?,?,?,?)",
                        (utils.new_id("repair"), action, result["status"], details.get("backup"), utils.dumps(result), utils.now_iso()),
                    )
                    self.conn.commit()
                if self.audit:
                    self.audit.log("system", "SAFE_HEAL_ROLLBACK", "repair", None, result)
                return result
