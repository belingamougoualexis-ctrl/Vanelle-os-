"""Fact-based model comparison; never auto-replaces the champion."""
from . import utils
class ChampionChallenger:
    def __init__(self, conn, audit=None): self.conn=conn; self.audit=audit
    def compare(self, champion_model_version_id, challenger_model_version_id, evaluation_ids):
        evs=[]
        for eid in evaluation_ids:
            r=self.conn.execute("SELECT * FROM evaluations WHERE id=?",(eid,)).fetchone()
            if r: evs.append(dict(r))
        relevant=[]
        for e in evs:
            if e["model_version_id"] in (champion_model_version_id,challenger_model_version_id): relevant.append(e)
        return {"status":"REAL","champion_model_version_id":champion_model_version_id,"challenger_model_version_id":challenger_model_version_id,"evaluations":relevant,"automatic_replacement":False,"note":"Comparaison factuelle uniquement; aucune promotion automatique."}
    def set_champion(self, project_id, model_version_id):
        row=self.conn.execute("SELECT mv.id FROM model_versions mv JOIN models m ON mv.model_id=m.id WHERE mv.id=? AND m.project_id=?",(model_version_id,project_id)).fetchone()
        if not row:
            return {"status":"FAILED","project_id":project_id,"champion_model_version_id":model_version_id,"reason":"La version de modèle n’appartient pas à ce projet ou n’existe pas."}
        now=utils.now_iso(); self.conn.execute("INSERT INTO champion_challenger (id,project_id,champion_model_version_id,updated_at) VALUES (?,?,?,?) ON CONFLICT(project_id) DO UPDATE SET champion_model_version_id=excluded.champion_model_version_id,updated_at=excluded.updated_at",(utils.new_id("cc"),project_id,model_version_id,now)); self.conn.commit();
        if self.audit:self.audit.log("user","SET_CHAMPION","project",project_id,{"model_version_id":model_version_id})
        return {"status":"REAL","project_id":project_id,"champion_model_version_id":model_version_id,"updated_at":now}
    def get_champion(self, project_id):
        r=self.conn.execute("SELECT * FROM champion_challenger WHERE project_id=?",(project_id,)).fetchone(); return dict(r) if r else None
