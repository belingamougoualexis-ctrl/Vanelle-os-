from . import utils, data_engine


class DatasetRegistry:
    def __init__(self, conn, storage_dir: str, audit=None):
        self.conn = conn
        self.storage_dir = storage_dir
        self.audit = audit

    def create_dataset(self, project_id: str, name: str, origin_path: str, license_name: str = None) -> str:
        ds_id = utils.new_id("ds")
        self.conn.execute(
            "INSERT INTO datasets (id, project_id, name, origin_path, license, created_at) VALUES (?,?,?,?,?,?)",
            (ds_id, project_id, name, origin_path, license_name, utils.now_iso()),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "CREATE_DATASET", "dataset", ds_id, {"name": name})
        return ds_id

    def import_version(self, dataset_id: str, source_path: str):
        """Exécute réellement le Data Engine et enregistre la version produite."""
        cur = self.conn.execute(
            "SELECT COALESCE(MAX(version_number),0)+1 FROM dataset_versions WHERE dataset_id=?",
            (dataset_id,),
        )
        version_number = cur.fetchone()[0]

        result = data_engine.run_pipeline(
            source_path=source_path,
            storage_dir=f"{self.storage_dir}/datasets/{dataset_id}",
            dataset_id=dataset_id,
            version_number=version_number,
        )

        dv_id = utils.new_id("dsv")
        status = "VALIDATED" if result["n_rows"] > 0 else "FAILED"
        self.conn.execute(
            """INSERT INTO dataset_versions
            (id, dataset_id, version_number, file_path, sha256, n_rows, n_cols,
             n_duplicates_removed, n_missing_values, n_corrupted_rows,
             class_balance_json, transformations_json, split_json, status, metadata_json, provenance_json, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                dv_id, dataset_id, version_number, result["version_path"], result["sha256"],
                result["n_rows"], result["n_cols"], result["n_duplicates_removed"],
                result["n_missing_values"], result["n_corrupted_rows"],
                utils.dumps(result["class_balance"]), utils.dumps(result["transformations"]),
                utils.dumps(result["split"]), status, utils.dumps(result.get("metadata", {})), utils.dumps({"source_path": source_path, "source_sha256": result.get("source_sha256")}), utils.now_iso(),
            ),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "IMPORT_DATASET_VERSION", "dataset_version", dv_id, result)
        return dv_id, result

    def get_version(self, dataset_version_id: str):
        row = self.conn.execute(
            "SELECT * FROM dataset_versions WHERE id=?", (dataset_version_id,)
        ).fetchone()
        return dict(row) if row else None

    def verify_integrity(self, dataset_version_id: str) -> bool:
        """Recalcule réellement le hash du fichier et le compare à celui enregistré."""
        v = self.get_version(dataset_version_id)
        if not v:
            return False
        actual_hash = utils.sha256_file(v["file_path"])
        return actual_hash == v["sha256"]

    def list_datasets(self, project_id: str):
        rows = self.conn.execute(
            "SELECT * FROM datasets WHERE project_id=? ORDER BY created_at DESC", (project_id,)
        ).fetchall()
        return [dict(r) for r in rows]
