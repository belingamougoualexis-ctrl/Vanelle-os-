"""Universal Data Engine with local adapters and truthful capability reporting."""
import os, shutil, csv, json, hashlib, statistics, pathlib
from . import utils

class DataValidationError(Exception): pass

def _capabilities():
    caps={"csv":True,"json":True,"jsonl":True,"txt":True,"parquet":False,"xlsx":False,"pdf":False,"png":False,"jpg":False,"jpeg":False,"webp":False,"bmp":False,"wav":False,"flac":False,"ogg":False,"aiff":False,"aif":False,"mp3":False,"mp4":False,"mkv":False,"mov":False,"avi":False,"webm":False}
    try:
        import pandas  # noqa: F401
        try:
            import pyarrow  # noqa: F401
            caps["parquet"]=True
        except ImportError:
            try:
                import fastparquet  # noqa: F401
                caps["parquet"]=True
            except ImportError:
                pass
        try:
            import openpyxl  # noqa: F401
            caps["xlsx"]=True
        except ImportError:
            pass
    except ImportError:
        pass
    try:
        import pypdf  # noqa: F401
        caps["pdf"]=True
    except ImportError: pass
    try:
        import PIL  # noqa: F401
        caps.update({"png":True,"jpg":True,"jpeg":True,"webp":True,"bmp":True})
    except ImportError: pass
    try:
        import soundfile  # noqa: F401
        # These formats are not all guaranteed by every libsndfile build.
        caps.update({"wav":True,"flac":True,"ogg":True,"aiff":True,"aif":True})
    except ImportError: pass
    try:
        import cv2  # noqa: F401
        caps.update({"mp4":True,"mkv":True,"mov":True,"avi":True,"webm":True})
    except ImportError: pass
    return caps


SUPPORTED_EXTENSIONS={".csv",".json",".jsonl",".txt",".md",".parquet",".xlsx",".pdf",".png",".jpg",".jpeg",".webp",".bmp",".wav",".flac",".ogg",".aiff",".aif",".mp3",".mp4",".mkv",".mov",".avi",".webm"}

def capabilities():
    return {"status":"REAL","adapters":_capabilities(),"extensions":sorted(SUPPORTED_EXTENSIONS)}

def _load_tabular(path):
    ext=os.path.splitext(path)[1].lower(); records=[]; corrupted=0; encoding_issue=False
    if ext==".csv":
        try:
            with open(path,"r",encoding="utf-8",newline="") as f: text=f.read()
        except UnicodeDecodeError:
            encoding_issue=True
            with open(path,"r",encoding="cp1252",errors="replace",newline="") as f:text=f.read()
        sample=text[:4096]
        try: has_header=csv.Sniffer().has_header(sample) if sample.strip() else True
        except csv.Error: has_header=True
        reader=csv.reader(text.splitlines()); header=None
        for i,row in enumerate(reader):
            if i==0 and has_header: header=row; continue
            if header and len(row)!=len(header): corrupted+=1; continue
            records.append(row)
        if header is None and records: header=[f"col_{i}" for i in range(len(records[0]))]
        records=[dict(zip(header,r)) for r in records] if header else []
    elif ext==".jsonl":
        with open(path,"r",encoding="utf-8",errors="replace") as f:
            for line in f:
                if not line.strip(): continue
                try:
                    value=json.loads(line); records.append(value if isinstance(value,dict) else {"value":value})
                except json.JSONDecodeError: corrupted+=1
    elif ext==".json":
        with open(path,"r",encoding="utf-8") as f:
            try:data=json.load(f)
            except json.JSONDecodeError as e: raise DataValidationError(f"JSON invalide : {e}")
        records=data if isinstance(data,list) else [data]
        records=[r if isinstance(r,dict) else {"value":r} for r in records]
    elif ext==".txt":
        with open(path,"r",encoding="utf-8",errors="replace") as f: records=[{"text":line.rstrip("\n")} for line in f if line.strip()]
    elif ext==".parquet":
        try:
            import pandas as pd
            records=pd.read_parquet(path).to_dict(orient="records")
        except Exception as e: raise DataValidationError(f"Parquet indisponible/invalide: {e}")
    elif ext==".xlsx":
        try:
            import pandas as pd
            records=pd.read_excel(path).to_dict(orient="records")
        except Exception as e: raise DataValidationError(f"Excel indisponible/invalide: {e}")
    return records,corrupted,{"encoding_issue":encoding_issue}

def _asset_record(path, ext):
    base={"asset_path":os.path.abspath(path),"file_size_bytes":os.path.getsize(path),"extension":ext,"sha256":utils.sha256_file(path)}
    try:
        if ext==".pdf":
            import pypdf
            reader=pypdf.PdfReader(path); pages=[]
            for i,page in enumerate(reader.pages): pages.append({**base,"page":i+1,"pages_total":len(reader.pages),"text":page.extract_text() or ""})
            return pages,{"adapter":"pypdf","pages":len(pages)}
        if ext in {".png",".jpg",".jpeg",".webp",".bmp"}:
            from PIL import Image
            im=Image.open(path); return [{**base,"width":im.width,"height":im.height,"mode":im.mode}],{"adapter":"PIL","width":im.width,"height":im.height}
        if ext in {".wav",".flac",".ogg",".aiff",".aif",".mp3"}:
            import soundfile as sf
            info=sf.info(path); return [{**base,"duration_seconds":float(info.duration),"sample_rate":int(info.samplerate),"channels":int(info.channels),"format":info.format}],{"adapter":"soundfile","duration_seconds":float(info.duration)}
        if ext in {".mp4",".mkv",".mov",".avi",".webm"}:
            import cv2
            cap=cv2.VideoCapture(path); frames=float(cap.get(cv2.CAP_PROP_FRAME_COUNT)); fps=float(cap.get(cv2.CAP_PROP_FPS)); w=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)); h=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)); cap.release(); dur=frames/fps if fps else None
            return [{**base,"frames":int(frames),"fps":fps,"duration_seconds":dur,"width":w,"height":h}],{"adapter":"OpenCV","duration_seconds":dur}
    except Exception as e: raise DataValidationError(f"Analyse {ext} impossible avec les dépendances disponibles: {e}")
    raise DataValidationError(f"Aucun adaptateur local pour {ext}")

def build_labeled_asset_manifest(source_dir, storage_dir, dataset_id, version_number):
    """Create a reproducible supervised asset dataset from source_dir/<label>/*."""
    source_dir=os.path.abspath(source_dir)
    if not os.path.isdir(source_dir):
        raise DataValidationError(f"Dossier source introuvable : {source_dir}")
    allowed=set(SUPPORTED_EXTENSIONS)-{".csv",".json",".jsonl",".parquet",".xlsx"}
    version_root=os.path.join(storage_dir,"asset_versions",f"{dataset_id}_v{version_number}")
    originals_root=os.path.join(storage_dir,"originals",f"{dataset_id}_v{version_number}")
    os.makedirs(version_root,exist_ok=True); os.makedirs(originals_root,exist_ok=True)
    rows=[]; skipped=[]
    root=pathlib.Path(source_dir)
    for label_dir in sorted((p for p in root.iterdir() if p.is_dir()), key=lambda p:p.name):
        label=label_dir.name
        for src in sorted((p for p in label_dir.rglob("*") if p.is_file()), key=lambda p:str(p)):
            ext=src.suffix.lower()
            if ext not in allowed:
                skipped.append(str(src)); continue
            rel=src.relative_to(label_dir)
            dest=os.path.join(originals_root,label,str(rel))
            os.makedirs(os.path.dirname(dest),exist_ok=True)
            shutil.copy2(src,dest)
            rows.append({"label":label,"asset_relpath":os.path.relpath(dest,version_root).replace(os.sep,"/"),"source_relative_path":src.relative_to(root).as_posix(),"extension":ext,"sha256":utils.sha256_file(dest),"file_size_bytes":os.path.getsize(dest)})
    if not rows:
        raise DataValidationError("Aucun fichier multimédia exploitable dans les sous-dossiers de classes.")
    version_path=os.path.join(version_root,"manifest.jsonl")
    with open(version_path,"w",encoding="utf-8") as f:
        for r in rows: f.write(json.dumps(r,ensure_ascii=False)+"\n")
    counts={}
    for r in rows: counts[r["label"]]=counts.get(r["label"],0)+1
    splits=split(rows,seed=42,stratify_key="label")
    h=utils.sha256_file(version_path)
    return {"original_path":originals_root,"version_path":version_path,"sha256":h,"source_sha256":None,"n_rows":len(rows),"n_cols":len(rows[0]),"n_duplicates_removed":0,"n_missing_values":0,"n_corrupted_rows":0,"class_balance":counts,"transformations":[{"step":"IMPORT","status":"REAL","source_type":"class_folder"},{"step":"SCAN","status":"REAL","records":len(rows)},{"step":"VALIDATE","status":"REAL","skipped_unsupported":len(skipped)},{"step":"SPLIT","status":"REAL","sizes":{k:len(v) for k,v in splits.items() if k!="seed"}},{"step":"VERSION","status":"REAL","sha256":h}],"split":splits,"metadata":{"adapter":"class_folder_assets","source_dir":source_dir,"skipped_unsupported":skipped}}

def load_tabular(path):
    ext=os.path.splitext(path)[1].lower()
    if ext not in {".csv",".json",".jsonl",".txt",".md",".parquet",".xlsx"}: raise DataValidationError(f"Extension '{ext}' non tabulaire")
    return _load_tabular(path)[:2]

def analyze(records):
    n_rows=len(records); n_cols=max((len(r) for r in records),default=0); missing=0; seen=set(); duplicates=0; label_col=None
    for r in records:
        for v in r.values():
            if v is None or (isinstance(v,str) and not v.strip()): missing+=1
        key=json.dumps(r,sort_keys=True,default=str)
        if key in seen: duplicates+=1
        seen.add(key)
    for candidate in ("label","class","target","category"):
        if records and candidate in records[0]: label_col=candidate; break
    balance=None
    if label_col:
        balance={}
        for r in records: balance[str(r.get(label_col))]=balance.get(str(r.get(label_col)),0)+1
    numeric_anomalies=[]; numeric_cols=[]
    if records:
        for c in records[0].keys():
            vals=[]
            for r in records:
                try: vals.append(float(r.get(c)))
                except (TypeError,ValueError): pass
            if vals and len(vals)>=max(3,int(.8*len(records))):
                numeric_cols.append(c)
                q1,q3=statistics.quantiles(vals,n=4,method="inclusive")[0],statistics.quantiles(vals,n=4,method="inclusive")[2]; iqr=q3-q1; lo=q1-1.5*iqr; hi=q3+1.5*iqr; n=sum(v<lo or v>hi for v in vals)
                if n: numeric_anomalies.append({"column":c,"outliers_iqr":n,"lower":lo,"upper":hi})
    return {"n_rows":n_rows,"n_cols":n_cols,"n_missing_values":missing,"n_duplicates":duplicates,"class_balance":balance,"numeric_columns":numeric_cols,"numeric_anomalies":numeric_anomalies,"duplicate_ratio":(duplicates/n_rows if n_rows else 0)}

def deduplicate(records):
    seen=set(); out=[]; removed=0
    for r in records:
        key=json.dumps(r,sort_keys=True,default=str)
        if key in seen: removed+=1; continue
        seen.add(key); out.append(r)
    return out,removed

def split(records,train=.8,val=.1,test=.1,seed=42,stratify_key=None):
    import random
    if abs(train+val+test-1.0)>=1e-6: raise ValueError("Les proportions doivent sommer à 1")
    rng=random.Random(seed)
    if not stratify_key:
        idx=list(range(len(records))); rng.shuffle(idx); n=len(idx); a=int(n*train); b=int(n*val); return {"train":idx[:a],"val":idx[a:a+b],"test":idx[a+b:],"seed":seed}
    buckets={}
    for i,r in enumerate(records): buckets.setdefault(str(r.get(stratify_key)),[]).append(i)
    out={"train":[],"val":[],"test":[]}
    for key,idxs in sorted(buckets.items()):
        rng.shuffle(idxs); n=len(idxs)
        a=int(round(n*train)); b=int(round(n*val))
        if n>=2 and a<1: a=1
        if n>=3 and b<1: b=1
        if a+b>n-1 and n>=2:
            b=max(0,n-a-1)
        c=n-a-b
        if c<0:
            c=0; b=max(0,n-a)
        out["train"].extend(idxs[:a]); out["val"].extend(idxs[a:a+b]); out["test"].extend(idxs[a+b:a+b+c])
    for v in out.values(): rng.shuffle(v)
    out["seed"]=seed
    return out

def run_pipeline(source_path,storage_dir,dataset_id,version_number):
    os.makedirs(storage_dir,exist_ok=True); originals=os.path.join(storage_dir,"originals"); versions=os.path.join(storage_dir,"versions"); os.makedirs(originals,exist_ok=True); os.makedirs(versions,exist_ok=True)
    if os.path.isdir(source_path):
        return build_labeled_asset_manifest(source_path, storage_dir, dataset_id, version_number)
    if not os.path.isfile(source_path): raise DataValidationError(f"Fichier source introuvable : {source_path}")
    ext=os.path.splitext(source_path)[1].lower()
    original_copy=os.path.join(originals,f"{dataset_id}_v{version_number}_original{ext}"); shutil.copy2(source_path,original_copy); source_hash=utils.sha256_file(original_copy)
    metadata={"source_format":ext,"source_sha256":source_hash,"capabilities":capabilities()}
    if ext in {".csv",".json",".jsonl",".txt",".parquet",".xlsx"}:
        records,corrupted,extra=_load_tabular(original_copy); metadata.update(extra); adapter="tabular"
    elif ext in {".pdf",".png",".jpg",".jpeg",".webp",".wav",".flac",".mp3",".mp4",".mkv",".mov"}:
        records,asset_meta=_asset_record(original_copy,ext); corrupted=0; metadata.update(asset_meta); adapter=asset_meta.get("adapter")
    else: raise DataValidationError(f"Extension '{ext}' non supportée par les adaptateurs locaux.")
    if not records: raise DataValidationError("Aucun enregistrement exploitable après validation.")
    before=analyze(records); cleaned,n_dup=deduplicate(records); normalized=[{k:(v.strip() if isinstance(v,str) else v) for k,v in r.items()} for r in cleaned]; label_for_split=next((c for c in ("label","class","target","category") if normalized and c in normalized[0]), None); splits=split(normalized,stratify_key=label_for_split)
    version_path=os.path.join(versions,f"{dataset_id}_v{version_number}.jsonl")
    with open(version_path,"w",encoding="utf-8") as f:
        for r in normalized:f.write(json.dumps(r,ensure_ascii=False,default=str)+"\n")
    after=analyze(normalized); h=utils.sha256_file(version_path)
    transformations=[{"step":"IMPORT","status":"REAL"},{"step":"SCAN","status":"REAL","records":len(records)},{"step":"VALIDATE","status":"REAL","corrupted_rows":corrupted},{"step":"CLEAN","status":"REAL"},{"step":"DEDUPLICATE","status":"REAL","removed":n_dup},{"step":"NORMALIZE","status":"REAL"},{"step":"SPLIT","status":"REAL","sizes":{k:len(v) for k,v in splits.items() if k!="seed"}},{"step":"VERSION","status":"REAL","sha256":h}]
    metadata.update({"adapter":adapter,"stats_before":before,"stats_after":after})
    return {"original_path":original_copy,"version_path":version_path,"sha256":h,"source_sha256":source_hash,"n_rows":after["n_rows"],"n_cols":after["n_cols"],"n_duplicates_removed":n_dup,"n_missing_values":after["n_missing_values"],"n_corrupted_rows":corrupted,"class_balance":after["class_balance"],"transformations":transformations,"split":splits,"metadata":metadata}

class UniversalDataEngine:
    """Public facade for all locally installed data adapters."""
    def capabilities(self): return capabilities()
    def import_dataset(self, source_path, storage_dir, dataset_id, version_number): return run_pipeline(source_path,storage_dir,dataset_id,version_number)
    def load_tabular(self, path): return load_tabular(path)
