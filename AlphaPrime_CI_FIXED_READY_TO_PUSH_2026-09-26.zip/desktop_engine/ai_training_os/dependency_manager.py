
"""Local dependency bootstrap and verification for Alpha Prime."""
from __future__ import annotations
import importlib.util
import platform
import subprocess
import sys
from pathlib import Path

CORE = {
    "torch": "torch>=2.2",
    "transformers": "transformers>=4.45",
    "peft": "peft>=0.19.1",
    "datasets": "datasets>=2.20",
    "accelerate": "accelerate>=0.33",
    "safetensors": "safetensors>=0.4",
    "sentencepiece": "sentencepiece>=0.2",
}
OPTIONAL = {"bitsandbytes": "bitsandbytes>=0.43"}

def installed(package: str) -> bool:
    return importlib.util.find_spec(package) is not None

def matrix() -> dict:
    items = {}
    for name, spec in {**CORE, **OPTIONAL}.items():
        items[name] = {"available": installed(name), "required": name in CORE, "spec": spec}
    return {"status": "REAL", "python": sys.version.split()[0], "platform": platform.platform(), "packages": items}

def ensure(packages=None, timeout=1800) -> dict:
    specs = list(packages or CORE.values())
    before = matrix()
    missing = [spec for spec in specs if not installed(spec.split(">=")[0])]
    # QLoRA acceleration is conditional on a real CUDA-capable PyTorch runtime.
    # Do not install bitsandbytes blindly on CPU-only machines.
    if packages is None:
        try:
            import torch
            if bool(torch.cuda.is_available()) and not installed("bitsandbytes"):
                missing.append(OPTIONAL["bitsandbytes"])
        except Exception:
            pass
    if not missing:
        return {"status":"REAL","changed":False,"packages":matrix()["packages"],"message":"Stack local déjà installé et vérifié."}
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", *missing]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except Exception as exc:
        return {"status":"FAILED","changed":False,"cause":f"{type(exc).__name__}: {exc}","solution":"Vérifiez la connexion réseau et les permissions du Python/venv local, puis relancez l'installation."}
    after = matrix()
    unresolved = [name for name in [s.split(">=")[0] for s in missing] if not after["packages"].get(name,{}).get("available")]
    if p.returncode != 0 or unresolved:
        return {"status":"FAILED","changed":False,"cause":(p.stderr or p.stdout or "pip a échoué").splitlines()[-1],"solution":"Relancez l'installation dans le venv Alpha Prime; sur GPU, gardez bitsandbytes conditionnel à CUDA.","command":cmd,"packages":after["packages"]}
    return {"status":"REAL","changed":True,"command":cmd,"packages":after["packages"],"previous":before["packages"]}

