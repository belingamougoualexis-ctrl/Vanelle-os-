"""Measured-only local observability."""
from . import compute
from . import utils

class Observability:
    def __init__(self, conn=None, audit=None): self.conn=conn; self.audit=audit
    def snapshot(self, workspace=None):
        report=compute.full_report(workspace or ".")
        jobs=[]
        if self.conn:
            jobs=[dict(r) for r in self.conn.execute("SELECT id,kind,provider,status,progress,last_epoch,created_at,updated_at FROM jobs ORDER BY updated_at DESC LIMIT 100").fetchall()]
        result={"status":"REAL","timestamp":utils.now_iso(),"compute":report,"jobs":jobs}
        if self.audit: self.audit.log("system","OBSERVABILITY_SNAPSHOT","workspace",None,{"jobs":len(jobs)})
        return result
