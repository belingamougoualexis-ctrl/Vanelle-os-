"""Local feature extraction for text, PDF, image, audio and video datasets.

All features are computed from the actual local assets. No pretrained remote
model is required. The output is deliberately deterministic so a dataset
version can be rebuilt and compared by hash.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable

import numpy as np


TEXT_EXTENSIONS = {".txt", ".md", ".json", ".jsonl", ".csv"}
PDF_EXTENSIONS = {".pdf"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
AUDIO_EXTENSIONS = {".wav", ".flac", ".ogg", ".aiff", ".aif", ".mp3"}
VIDEO_EXTENSIONS = {".mp4", ".mkv", ".mov", ".avi", ".webm"}


def modality_for_path(path: str) -> str:
    ext = Path(path).suffix.lower()
    if ext in TEXT_EXTENSIONS:
        return "text"
    if ext in PDF_EXTENSIONS:
        return "pdf"
    if ext in IMAGE_EXTENSIONS:
        return "image"
    if ext in AUDIO_EXTENSIONS:
        return "audio"
    if ext in VIDEO_EXTENSIONS:
        return "video"
    return "unknown"


def read_text(path: str) -> str:
    ext = Path(path).suffix.lower()
    if ext == ".pdf":
        import pypdf
        reader = pypdf.PdfReader(path)
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def image_features(path: str, size=(24, 24)) -> np.ndarray:
    from PIL import Image
    with Image.open(path) as im:
        im = im.convert("RGB").resize(size)
        arr = np.asarray(im, dtype=np.float32) / 255.0
    # Pixel vector + channel statistics. It is intentionally simple and
    # completely local; the model can be a real linear classifier on top.
    stats = np.concatenate([
        arr.reshape(-1),
        arr.mean(axis=(0, 1)), arr.std(axis=(0, 1)),
        arr.min(axis=(0, 1)), arr.max(axis=(0, 1)),
    ])
    return stats.astype(np.float32)


def audio_features(path: str, max_seconds: float = 12.0) -> np.ndarray:
    import soundfile as sf
    info = sf.info(path)
    frames = min(int(info.frames), int(max_seconds * info.samplerate))
    if frames <= 0:
        raise ValueError(f"Audio vide: {path}")
    data = sf.read(path, frames=frames, dtype="float32", always_2d=True)[0]
    mono = data.mean(axis=1)
    if mono.size == 0:
        raise ValueError(f"Audio vide: {path}")
    rms = float(np.sqrt(np.mean(mono ** 2)))
    zcr = float(np.mean(np.signbit(mono[1:]) != np.signbit(mono[:-1]))) if mono.size > 1 else 0.0
    spectrum = np.abs(np.fft.rfft(mono[: min(mono.size, 131072)]))
    freqs = np.fft.rfftfreq(mono[: min(mono.size, 131072)].size, d=1.0 / info.samplerate)
    if spectrum.size > 1 and float(spectrum.sum()) > 0:
        centroid = float((freqs * spectrum).sum() / spectrum.sum())
        dominant = float(freqs[int(np.argmax(spectrum))])
        bandwidth = float(np.sqrt(((freqs - centroid) ** 2 * spectrum).sum() / spectrum.sum()))
        spectral_energy = float(np.mean(spectrum ** 2))
    else:
        centroid = dominant = bandwidth = spectral_energy = 0.0
    percentiles = np.percentile(mono, [1, 5, 25, 50, 75, 95, 99]).astype(np.float32)
    feats = np.array([
        float(info.samplerate), float(info.channels), float(info.duration),
        float(np.mean(mono)), float(np.std(mono)), float(np.min(mono)), float(np.max(mono)),
        rms, zcr, centroid, dominant, bandwidth, spectral_energy,
        *percentiles.tolist(),
    ], dtype=np.float32)
    return feats


def video_features(path: str, n_samples: int = 8, size=(16, 16)) -> np.ndarray:
    import cv2
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise ValueError(f"Vidéo illisible: {path}")
    n_frames = max(0, int(cap.get(cv2.CAP_PROP_FRAME_COUNT)))
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    positions = np.linspace(0, max(0, n_frames - 1), num=min(n_samples, max(1, n_frames)), dtype=int)
    samples = []
    for pos in positions:
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(pos))
        ok, frame = cap.read()
        if not ok:
            continue
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame = cv2.resize(frame, size, interpolation=cv2.INTER_AREA).astype(np.float32) / 255.0
        gray = cv2.cvtColor((frame * 255).astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32) / 255.0
        edges = cv2.Canny((gray * 255).astype(np.uint8), 60, 120)
        samples.append(np.concatenate([
            frame.mean(axis=(0, 1)), frame.std(axis=(0, 1)),
            np.array([gray.mean(), gray.std(), edges.mean() / 255.0], dtype=np.float32),
        ]))
    cap.release()
    if not samples:
        raise ValueError(f"Aucune frame exploitable: {path}")
    vec = np.stack(samples).mean(axis=0)
    duration = n_frames / fps if fps > 0 else 0.0
    return np.concatenate([vec, np.array([n_frames, fps, duration], dtype=np.float32)]).astype(np.float32)


def features_for_paths(paths: Iterable[str], modality: str):
    fn = {
        "image": image_features,
        "audio": audio_features,
        "video": video_features,
    }.get(modality)
    if fn is None:
        if modality in {"text", "pdf"}:
            return [read_text(p) for p in paths]
        raise ValueError(f"Modality non prise en charge: {modality}")
    return [fn(p) for p in paths]
