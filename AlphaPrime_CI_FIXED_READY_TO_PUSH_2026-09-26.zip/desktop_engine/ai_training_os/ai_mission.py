"""
ai_mission.py — AI Mission / Training Plan.

IMPORTANT — HONNÊTETÉ : une analyse de langage naturel "façon LLM" de
haute qualité nécessiterait un accès à un modèle de langage externe
(API réseau), qui est UNAVAILABLE dans cet environnement (pas de réseau
sortant). Ce module implémente donc un analyseur RÉEL par règles/mots-clés
(déterministe, exécuté ici, pas de texte inventé), suffisant pour produire
un Training Plan structuré exploitable par le reste du système.

Statut affiché honnêtement : AVAILABLE (rule-based). Un vrai raisonnement
LLM multi-agents (AI Council conversationnel) reste marqué UNAVAILABLE
tant qu'un provider LLM (local ou distant) n'est pas connecté.
"""
import re
from . import utils
from .compute_planner import SmartComputePlanner

PROBLEM_TYPE_KEYWORDS = {
    "classification": ["classif", "catégor", "détect", "reconna", "trier", "spam", "sentiment"],
    "regression": ["prédire un nombre", "régression", "prévision", "prix", "valeur numérique"],
    "clustering": ["regroup", "cluster", "segmenter"],
    "generation_texte": ["génér", "rédiger", "écrire", "résum"],
    "analyse_documents": ["document", "pdf", "analyse de mes documents", "extraire"],
}

DATA_TYPE_KEYWORDS = {
    "texte": ["texte", "document", "pdf", "email", "message"],
    "image": ["image", "photo", "visuel"],
    "audio": ["audio", "son", "voix"],
    "tabulaire": ["csv", "tableau", "excel", "tabulaire"],
}


def _match(text: str, keyword_map: dict, default: str) -> str:
    text_low = text.lower()
    for label, keywords in keyword_map.items():
        for kw in keywords:
            if kw in text_low:
                return label
    return default


class AIMissionEngine:
    def __init__(self, conn, audit=None):
        self.conn = conn
        self.audit = audit

    def analyze(self, project_id: str, raw_request: str) -> dict:
        problem_type = _match(raw_request, PROBLEM_TYPE_KEYWORDS, default="classification")
        data_type = _match(raw_request, DATA_TYPE_KEYWORDS, default="texte")

        if problem_type == "classification":
            if data_type == "texte":
                model_strategy = "LOCAL_CPU_PROVIDER: TF-IDF + LogisticRegression sur le texte réel; aucun poids pré-entraîné requis"
            elif data_type == "image":
                model_strategy = "LOCAL_CPU_PROVIDER: extraction de caractéristiques pixels réelles + LogisticRegression; pas de backbone pré-entraîné requis"
            elif data_type == "audio":
                model_strategy = "LOCAL_CPU_PROVIDER: extraction spectrale réelle + LogisticRegression; pas de modèle audio pré-entraîné requis"
            elif data_type == "vidéo":
                model_strategy = "LOCAL_CPU_PROVIDER: statistiques réelles d'images échantillonnées + LogisticRegression; pas de modèle vidéo pré-entraîné requis"
            else:
                model_strategy = "LOCAL_CPU_PROVIDER: LogisticRegression/RandomForest/SGD ou MLP selon les dimensions et ressources réellement détectées"
            metrics = ["accuracy", "precision_macro", "recall_macro", "f1_macro"]
        elif problem_type == "regression":
            model_strategy = "régression (scikit-learn) — from scratch, données tabulaires suffisantes en local"
            metrics = ["mae", "rmse", "r2"]
        elif problem_type == "clustering":
            model_strategy = "clustering non supervisé (k-means/HDBSCAN) — LOCAL_CPU_PROVIDER"
            metrics = ["silhouette_score"]
        else:
            model_strategy = "nécessite un LLM pré-entraîné volumineux — UNAVAILABLE sans réseau pour le téléchargement initial ; utilisable seulement si un modèle est déjà présent localement via Model Manager"
            metrics = ["qualité jugée manuellement (pas de métrique automatique fiable en local)"]

        # Interroge le Smart Compute Planner : le tier dépend du matériel
        # RÉELLEMENT détecté sur la machine qui exécute cette mission, pas
        # d'une hypothèse figée. Sur une machine CPU-only ceci retombe sur
        # LOCAL_CPU_PROVIDER ; sur une machine avec GPU, sur LOCAL_GPU_PROVIDER
        # ou LOCAL_MULTI_GPU_PROVIDER automatiquement.
        compute_plan = SmartComputePlanner().plan()
        training_strategy = f"from_scratch, tier {compute_plan['selected_tier']} ({compute_plan['selected_provider']})" \
            if problem_type in ("classification", "regression", "clustering") \
            else "fine-tuning (nécessite modèle pré-entraîné local)"

        risks = []
        if data_type == "pdf":
            risks.append("La classification PDF dépend de l'extraction de texte réellement disponible via pypdf; les PDF scannés sans couche texte restent à traiter par OCR externe/local dédié.")
        if data_type in ("image", "audio", "vidéo") and problem_type in ("classification", "regression"):
            risks.append("Le pipeline local actuel utilise des caractéristiques déterministes et non un backbone pré-entraîné multimodal; les performances avancées nécessitent un modèle spécialisé réellement installé.")
        if compute_plan["selected_tier"] == "CPU_ONLY":
            risks.append("Aucun GPU détecté sur cette machine : entraînement limité à des datasets de taille modeste dans un temps raisonnable.")
        risks.append("Pas de réseau : tout modèle nécessitant un LLM pré-entraîné externe reste UNAVAILABLE tant qu'il n'est pas fourni localement.")

        # Sans dataset attaché, aucune durée/taille concrète ne peut être mesurée.
        # Elles restent donc explicitement ESTIMATED/UNKNOWN et seront recalculées
        # lorsque les dimensions réelles du dataset seront connues.
        plan = {
            "status": "REAL",
            "objective": raw_request.strip(),
            "problem_type": problem_type,
            "data_type": data_type,
            "model_strategy": model_strategy,
            "training_strategy": training_strategy,
            "metrics": metrics,
            "evaluation_method": "hold-out train/val/test (80/10/10) + Evaluation Engine",
            "resources_required": {
                "compute_tier": compute_plan["selected_tier"],
                "compute_provider": compute_plan["selected_provider"],
                "recommended_model_size": compute_plan.get("recommended_model_size"),
                "network": "UNAVAILABLE (nécessaire seulement pour des ressources externes optionnelles)",
            },
            "estimates": {
                "status": "ESTIMATED",
                "duration_seconds": None,
                "storage_bytes": None,
                "reason": "Aucun dataset réel n'est encore attaché à la mission."
            },
            "constraints": [f"{t['tier']}: {'disponible' if t['available'] else 'indisponible — ' + t['reason']}" for t in compute_plan["all_tiers_evaluated"]],
            "risks": risks,
            "success_criteria": [f"{m} mesuré réellement sur le jeu de validation" for m in metrics],
        }

        mission_id = utils.new_id("mission")
        self.conn.execute(
            """INSERT INTO ai_missions
            (id, project_id, raw_request, objective, problem_type, data_type, model_strategy,
             training_strategy, metrics_json, risks_json, success_criteria_json, training_plan_json, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (mission_id, project_id, raw_request, plan["objective"], problem_type, data_type,
             model_strategy, training_strategy, utils.dumps(metrics), utils.dumps(risks),
             utils.dumps(plan["success_criteria"]), utils.dumps(plan), utils.now_iso()),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("user", "CREATE_AI_MISSION", "ai_mission", mission_id, {"problem_type": problem_type})

        return {"mission_id": mission_id, "plan": plan}

    def get(self, mission_id: str):
        row = self.conn.execute("SELECT * FROM ai_missions WHERE id=?", (mission_id,)).fetchone()
        return dict(row) if row else None
