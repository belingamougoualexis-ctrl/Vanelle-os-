from .core import AITrainingOS
