"""Deterministic local LLM runtime configuration for Alpha Prime."""
from __future__ import annotations
import json
from pathlib import Path

DEFAULT_CONFIG = {
    "version": 1,
    "runtime": {
        "context_size": 4096,
        "temperature": 0.2,
        "top_p": 0.9,
        "top_k": 40,
        "repeat_penalty": 1.1,
        "max_tokens": 700,
        "timeout_seconds": 300,
    },
    "profiles": {
        "council": {
            "temperature": 0.15,
            "top_p": 0.9,
            "top_k": 40,
            "repeat_penalty": 1.12,
            "max_tokens": 450,
            "system_suffix": "Ne fabrique jamais de données, de résultats ou de métriques. Si une information manque, indique-la explicitement comme inconnue."
        },
        "scientist": {
            "temperature": 0.2,
            "top_p": 0.9,
            "top_k": 40,
            "repeat_penalty": 1.1,
            "max_tokens": 750,
            "system_suffix": "Sépare toujours observations, hypothèses et conclusions. Ne présente pas une hypothèse comme un résultat mesuré."
        },
        "verification": {
            "temperature": 0.0,
            "top_p": 1.0,
            "top_k": 1,
            "repeat_penalty": 1.0,
            "max_tokens": 8,
            "system_suffix": "Réponds uniquement avec le résultat demandé."
        },
        "general": {
            "temperature": 0.2,
            "top_p": 0.9,
            "top_k": 40,
            "repeat_penalty": 1.1,
            "max_tokens": 700,
            "system_suffix": "Ne fabrique jamais de faits."
        }
    }
}


def load_or_create(path: str | Path) -> dict:
    p = Path(path)
    if not p.exists():
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(DEFAULT_CONFIG, ensure_ascii=False, indent=2), encoding="utf-8")
        return json.loads(json.dumps(DEFAULT_CONFIG))
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        data = {}
    merged = json.loads(json.dumps(DEFAULT_CONFIG))
    if isinstance(data, dict):
        merged["version"] = data.get("version", merged["version"])
        merged["runtime"].update(data.get("runtime", {}) if isinstance(data.get("runtime"), dict) else {})
        for name, cfg in data.get("profiles", {}).items() if isinstance(data.get("profiles"), dict) else []:
            if name in merged["profiles"] and isinstance(cfg, dict):
                merged["profiles"][name].update(cfg)
    p.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")
    return merged


def profile(config: dict, name: str) -> dict:
    out = dict(config.get("runtime", {}))
    out.update(config.get("profiles", {}).get(name, config.get("profiles", {}).get("general", {})))
    return out
