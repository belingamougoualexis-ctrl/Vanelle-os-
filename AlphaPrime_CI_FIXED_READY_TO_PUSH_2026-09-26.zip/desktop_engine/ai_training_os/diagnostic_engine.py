"""Evidence-first diagnostics. Hypotheses never become confirmed causes by wording."""
from __future__ import annotations

import re
from typing import Any

from .hardware_reality import scan
from .truth import evidence


class DiagnosticEngine:
    def __init__(self, workspace: str):
        self.workspace = workspace

    def diagnose(self, error: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        error_text = str(error or "").strip()
        context = context or {}
        profile = scan(self.workspace)
        hypotheses: list[dict[str, Any]] = []
        text = error_text.lower()
        if "out of memory" in text or "cuda out of memory" in text or "oom" in text:
            hypotheses.append({"cause": "MEMORY_PRESSURE", "confidence": 0.90, "severity": "HIGH", "safe_actions": ["reduce_batch_size", "reduce_context_length", "use_cpu_fallback"], "evidence": evidence("TESTING", "LOCAL_TEST", "Error text contains an out-of-memory signature")})
        if "no space left" in text or "disk full" in text:
            hypotheses.append({"cause": "DISK_SPACE", "confidence": 0.95, "severity": "HIGH", "safe_actions": ["cleanup_temp", "choose_workspace_with_more_free_space"], "evidence": evidence("TESTING", "LOCAL_TEST", "Error text contains a disk-capacity signature")})
        if "modulenotfounderror" in text or "no module named" in text:
            hypotheses.append({"cause": "DEPENDENCY_MISSING", "confidence": 0.94, "severity": "MEDIUM", "safe_actions": ["verify_dependency", "install_application_dependency"], "evidence": evidence("TESTING", "LOCAL_TEST", "Import error signature detected")})
        if "permission denied" in text or "access is denied" in text:
            hypotheses.append({"cause": "PERMISSION", "confidence": 0.92, "severity": "MEDIUM", "safe_actions": ["choose_writable_workspace", "repair_local_permissions"], "evidence": evidence("TESTING", "LOCAL_TEST", "Permission error signature detected")})
        if "cuda" in text and profile.get("training_runtime", {}).get("backend") != "CUDA":
            hypotheses.append({"cause": "CUDA_NOT_VERIFIED", "confidence": 0.87, "severity": "HIGH", "safe_actions": ["run_gpu_reality_test", "use_cpu_fallback"], "evidence": evidence("NOT VERIFIED", "LOCAL_TEST", "Current machine profile does not verify CUDA")})
        if not hypotheses:
            hypotheses.append({"cause": "UNKNOWN", "confidence": 0.20, "severity": "UNKNOWN", "safe_actions": ["collect_more_evidence"], "evidence": evidence("NOT VERIFIED", "AI_HYPOTHESIS", "No deterministic diagnostic rule matched the observed error")})

        contradictions = []
        if context.get("claimed_gpu") and profile.get("training_runtime", {}).get("backend") == "CPU":
            contradictions.append({"claim": "GPU usable", "local_fact": "CPU", "message": "Informations contradictoires — vérification nécessaire."})
        status = "TESTING" if hypotheses else "NOT VERIFIED"
        return {
            "status": status,
            "truth_status": "LOCAL_EVIDENCE_PLUS_HYPOTHESIS",
            "error": error_text,
            "local_profile": profile,
            "hypotheses": hypotheses,
            "contradictions": contradictions,
            "rule": "Une cause reste PROBABLE tant qu'un test local spécifique ne l'a pas confirmée.",
        }
