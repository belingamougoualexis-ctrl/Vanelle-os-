"""LOCAL_LLM_PROVIDER with managed llama.cpp runtime support."""
from __future__ import annotations
import glob
import json
import os
import socket
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path
from .llm_config import load_or_create, profile


class LLMBackend:
    name = "BASE"
    def detect(self) -> dict: raise NotImplementedError
    def complete(self, system: str, prompt: str, max_tokens: int = 512, model: str = None, generation: dict | None = None) -> dict: raise NotImplementedError


class OllamaBackend(LLMBackend):
    name = "OLLAMA_LOCAL"
    HOST = "127.0.0.1"; PORT = 11434
    def _reachable(self):
        try:
            with socket.create_connection((self.HOST,self.PORT),timeout=.5): return True
        except OSError: return False
    def detect(self):
        if not self._reachable(): return {"available":False,"reason":f"Aucun démon Ollama local détecté sur {self.HOST}:{self.PORT}.","models":[]}
        try:
            req=urllib.request.Request(f"http://{self.HOST}:{self.PORT}/api/tags")
            with urllib.request.urlopen(req,timeout=1.5) as resp: data=json.loads(resp.read().decode())
            models=[m.get("name") for m in data.get("models",[]) if m.get("name")]
            return {"available":bool(models),"reason":"Ollama local actif." if models else "Ollama actif sans modèle.","models":models}
        except Exception as e: return {"available":False,"reason":f"Ollama local injoignable : {e}","models":[]}
    def complete(self,system,prompt,max_tokens=512,model=None,generation=None):
        self._generation=generation or {}
        info=self.detect()
        if not info["available"]: raise RuntimeError(f"LLM REQUIRED — {info['reason']}")
        model=model or info["models"][0]
        g=generation or {}
        body=json.dumps({"model":model,"prompt":prompt,"system":system,"stream":False,
                         "options":{"temperature":g.get("temperature",0.2),"top_p":g.get("top_p",0.9),"top_k":g.get("top_k",40),"repeat_penalty":g.get("repeat_penalty",1.1),"num_ctx":g.get("context_size",4096),"num_predict":max_tokens}}).encode()
        req=urllib.request.Request(f"http://{self.HOST}:{self.PORT}/api/generate",data=body,headers={"Content-Type":"application/json"},method="POST")
        with urllib.request.urlopen(req,timeout=300) as resp: data=json.loads(resp.read().decode())
        return {"text":data.get("response",""),"model":model,"backend":self.name,"tokens":data.get("eval_count")}


class ManagedLlamaServerBackend(LLMBackend):
    name = "MANAGED_LLAMA_CPP_LOCAL"
    HOST = "127.0.0.1"; PORT = 18178
    def __init__(self, models_dir, startup_manager):
        self.models_dir=models_dir; self.startup_manager=startup_manager; self._process=None; self._model=None
    def _model_files(self):
        return sorted(glob.glob(os.path.join(self.models_dir,"*.gguf")))
    def _healthy(self):
        try:
            req=urllib.request.Request(f"http://{self.HOST}:{self.PORT}/health")
            with urllib.request.urlopen(req,timeout=.8) as r: return r.status == 200
        except Exception: return False
    def detect(self):
        binary=self.startup_manager.runtime_binary(); models=self._model_files()
        valid=[]
        for f in models:
            try:
                with open(f,"rb") as h:
                    if h.read(4)==b"GGUF": valid.append(os.path.basename(f))
            except OSError: pass
        if not binary: return {"available":False,"reason":"Runtime llama.cpp local non installé. Ouvrir Installation locale pour le télécharger.","models":[]}
        if not valid: return {"available":False,"reason":"Runtime llama.cpp installé mais aucun GGUF local vérifié.","models":[]}
        return {"available":True,"reason":"Runtime llama.cpp et modèle GGUF locaux détectés.","models":valid,"binary":binary}
    def _start(self, model):
        if self._healthy() and self._model==model: return
        if self._process and self._process.poll() is None and self._model != model:
            self._process.terminate()
            try: self._process.wait(timeout=5)
            except subprocess.TimeoutExpired: self._process.kill()
        binary=self.startup_manager.runtime_binary()
        path=os.path.join(self.models_dir,model)
        if not binary or not os.path.isfile(path): raise RuntimeError("Runtime ou modèle local indisponible.")
        ngl="0"
        try:
            import torch
            if torch.cuda.is_available(): ngl="999"
        except Exception:
            pass
        cmd=[binary,"-m",path,"--host",self.HOST,"--port",str(self.PORT),"-c",str(self._generation.get("context_size",4096) if hasattr(self,"_generation") else 4096),"-ngl",ngl]
        self._process=subprocess.Popen(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        self._model=model
        deadline=time.time()+120
        while time.time()<deadline:
            if self._healthy(): return
            if self._process.poll() is not None: raise RuntimeError(f"llama-server s'est arrêté avec le code {self._process.returncode}.")
            time.sleep(.5)
        raise RuntimeError("llama-server n'est pas devenu prêt après 120 secondes.")
    def complete(self,system,prompt,max_tokens=512,model=None,generation=None):
        self._generation=generation or {}
        info=self.detect()
        if not info["available"]: raise RuntimeError(f"LLM REQUIRED — {info['reason']}")
        model=model or info["models"][0]
        if model not in info["models"]: raise RuntimeError(f"Modèle GGUF local indisponible: {model}")
        self._start(model)
        g=generation or {}
        body=json.dumps({"model":model,"messages":[{"role":"system","content":system},{"role":"user","content":prompt}],
                         "max_tokens":max_tokens,"temperature":g.get("temperature",0.2),"top_p":g.get("top_p",0.9),
                         "top_k":g.get("top_k",40),"repeat_penalty":g.get("repeat_penalty",1.1),"stream":False}).encode()
        req=urllib.request.Request(f"http://{self.HOST}:{self.PORT}/v1/chat/completions",data=body,headers={"Content-Type":"application/json"},method="POST")
        with urllib.request.urlopen(req,timeout=300) as resp: data=json.loads(resp.read().decode())
        text=data["choices"][0]["message"]["content"]
        return {"text":text,"model":model,"backend":self.name,"tokens":data.get("usage",{}).get("total_tokens")}


class LlamaCppBackend(LLMBackend):
    name="LLAMA_CPP_GGUF"
    def __init__(self,models_dir): self.models_dir=models_dir
    def _gguf_files(self): os.makedirs(self.models_dir,exist_ok=True); return sorted(glob.glob(os.path.join(self.models_dir,"*.gguf")))
    def detect(self):
        os.makedirs(self.models_dir, exist_ok=True)
        try: import llama_cpp
        except ImportError: return {"available":False,"reason":"Le paquet llama-cpp-python n'est pas installé.","models":[]}
        models=[]
        for f in self._gguf_files():
            try:
                with open(f,"rb") as h:
                    if h.read(4)==b"GGUF": models.append(os.path.basename(f))
            except OSError: pass
        return {"available":bool(models),"reason":"GGUF local détecté via llama-cpp-python.","models":models}
    def complete(self,system,prompt,max_tokens=512,model=None,generation=None):
        info=self.detect()
        if not info["available"]: raise RuntimeError(f"LLM REQUIRED — {info['reason']}")
        from llama_cpp import Llama
        selected=model or info["models"][0]
        llm=Llama(model_path=os.path.join(self.models_dir,selected),n_ctx=2048,verbose=False)
        g=generation or {}
        out=llm.create_chat_completion(messages=[{"role":"system","content":system},{"role":"user","content":prompt}],max_tokens=max_tokens,
                                       temperature=g.get("temperature",0.2),top_p=g.get("top_p",0.9),
                                       top_k=g.get("top_k",40),repeat_penalty=g.get("repeat_penalty",1.1))
        return {"text":out["choices"][0]["message"]["content"],"model":selected,"backend":self.name,"tokens":out.get("usage",{}).get("total_tokens")}


class TransformersLocalBackend(LLMBackend):
    name="TRANSFORMERS_LOCAL_DIR"
    def __init__(self,models_dir): self.models_dir=models_dir
    def _dirs(self):
        os.makedirs(self.models_dir,exist_ok=True)
        return sorted([e.path for e in os.scandir(self.models_dir) if e.is_dir() and os.path.exists(os.path.join(e.path,"config.json"))])
    def detect(self):
        try: import transformers
        except ImportError: return {"available":False,"reason":"Le paquet transformers n'est pas installé.","models":[]}
        dirs=[]
        for d in self._dirs():
            names={e.name for e in os.scandir(d)}
            if names.intersection({"model.safetensors","pytorch_model.bin","model.safetensors.index.json"}): dirs.append(os.path.basename(d))
        return {"available":bool(dirs),"reason":"Modèle Transformers local détecté.","models":dirs}
    def complete(self,system,prompt,max_tokens=512,model=None,generation=None):
        info=self.detect()
        if not info["available"]: raise RuntimeError(f"LLM REQUIRED — {info['reason']}")
        from transformers import pipeline
        selected=model or info["models"][0]; path=os.path.join(self.models_dir,selected)
        pipe=pipeline("text-generation",model=path,tokenizer=path,local_files_only=True)
        g=generation or {}
        out=pipe(f"{system}\n\n{prompt}",max_new_tokens=max_tokens,do_sample=(g.get("temperature",0.2)>0),
                 temperature=max(g.get("temperature",0.2),0.01),top_p=g.get("top_p",0.9),repetition_penalty=g.get("repeat_penalty",1.1))
        return {"text":out[0]["generated_text"],"model":selected,"backend":self.name,"tokens":None}


class LocalLLMProvider:
    def __init__(self,base_dir:str,startup_manager=None):
        self.models_dir=os.path.join(base_dir,"llm_models"); os.makedirs(self.models_dir,exist_ok=True)
        self.selection_path=os.path.join(self.models_dir,".selected_model.json")
        self.config_path=os.path.join(self.models_dir,"llm_config.json")
        self.config=load_or_create(self.config_path)
        self.selected_model=None; self.selected_backend=None; self._verified_identity=None
        self.startup_manager=startup_manager
        self._load_selection()
        self.backends=[]
        if startup_manager: self.backends.append(ManagedLlamaServerBackend(self.models_dir,startup_manager))
        self.backends += [OllamaBackend(),LlamaCppBackend(self.models_dir),TransformersLocalBackend(self.models_dir)]
    def _load_selection(self):
        try:
            d=json.loads(Path(self.selection_path).read_text()); self.selected_model=d.get("model"); self.selected_backend=d.get("backend")
        except (OSError,json.JSONDecodeError): self.selected_model=None; self.selected_backend=None
    def _save_selection(self):
        tmp=self.selection_path+".tmp"; Path(tmp).write_text(json.dumps({"model":self.selected_model,"backend":self.selected_backend},ensure_ascii=False,indent=2)); os.replace(tmp,self.selection_path)
    def _verification_identity(self, backend_name, model):
        # Verification is process-local; it must be repeated after restart.
        fingerprint = None
        path = os.path.join(self.models_dir, str(model or ""))
        if backend_name in {"MANAGED_LLAMA_CPP_LOCAL", "LLAMA_CPP_GGUF"} and os.path.isfile(path):
            st = os.stat(path)
            fingerprint = (st.st_size, st.st_mtime_ns)
        return (backend_name, model, fingerprint)

    def status(self, require_verified=True):
        checks={b.name:b.detect() for b in self.backends}; active=next((n for n,i in checks.items() if i["available"]),None)
        if self.selected_model and not (self.selected_backend in checks and self.selected_model in checks[self.selected_backend].get("models",[])):
            self.selected_model=None; self.selected_backend=None; self._verified_identity=None; self._save_selection()

        # Auto-selection is configuration, not proof. A real inference probe is
        # still mandatory before the provider can be used by critical tasks.
        if active and not self.selected_model:
            candidates = checks[active].get("models", [])
            if candidates:
                self.selected_model = candidates[0]
                self.selected_backend = active
                self._save_selection()

        if not active:
            return {
                "status": "LLM REQUIRED",
                "active_backend": None,
                "selected_backend": self.selected_backend,
                "selected_model": self.selected_model,
                "selection_persisted": os.path.isfile(self.selection_path),
                "backends": checks,
                "message": "Aucun modèle de langage local compatible n'est actuellement disponible.",
                "cause": "Aucun backend local compatible (ou aucun modèle local valide) n'est disponible sur cette machine.",
                "solution": "Préparez le moteur local ou importez un modèle compatible, puis lancez la vérification réelle.",
                "generation_config": self.config,
            }

        identity = self._verification_identity(self.selected_backend, self.selected_model) if self.selected_model and self.selected_backend else None
        verified = identity is not None and identity == self._verified_identity
        if require_verified and not verified:
            return {
                "status": "NOT VERIFIED",
                "active_backend": active,
                "selected_backend": self.selected_backend,
                "selected_model": self.selected_model,
                "selection_persisted": os.path.isfile(self.selection_path),
                "backends": checks,
                "message": "Le moteur local est disponible, mais son inférence réelle n'a pas encore été validée pour cette session.",
                "cause": "Aucune preuve d'exécution réussie n'est encore associée au modèle sélectionné.",
                "solution": "Lancez la vérification réelle du LLM avant toute utilisation critique.",
                "generation_config": self.config,
            }

        return {
            "status": "READY",
            "active_backend": active,
            "selected_backend": self.selected_backend,
            "selected_model": self.selected_model,
            "selection_persisted": os.path.isfile(self.selection_path),
            "backends": checks,
            "message": "LLM local vérifié par inférence réelle.",
            "cause": None,
            "solution": None,
            "generation_config": self.config,
        }
    def available_models(self):
        st=self.status(); return [{"backend":n,"model":m,"selected":n==st.get("selected_backend") and m==st.get("selected_model")} for n,i in st["backends"].items() for m in i.get("models",[])]
    def _find_backend(self,model,backend_name=None):
        for b in self.backends:
            if backend_name and b.name!=backend_name: continue
            i=b.detect()
            if i["available"] and model in i.get("models",[]): return b,i
        return None,None
    def verify_model(self,model,backend=None):
        b,info=self._find_backend(model,backend)
        if not b:
            return {"status":"UNAVAILABLE","model":model,"backend":backend,"reason":"Modèle local introuvable ou backend indisponible."}
        try:
            r=b.complete(
                "Tu es le processus de vérification local Alpha Prime. Réponds exactement OK.",
                "Réponds exactement OK.",
                max_tokens=8, model=model, generation=self.generation_profile("verification")
            )
            text=str(r.get("text","")).strip()
            verified="OK" in text.upper()
            if verified:
                self._verified_identity=self._verification_identity(b.name, model)
            return {"status":"REAL" if verified else "FAILED","verified":verified,"model":model,"backend":b.name,"probe":text,
                    "test":"REAL_INFERENCE" if verified else "REAL_INFERENCE_MARKER_MISSING"}
        except Exception as exc:
            return {"status":"FAILED","verified":False,"model":model,"backend":b.name,"reason":str(exc),"test":"REAL_INFERENCE_FAILED"}
    def set_model(self,model,backend=None):
        self._verified_identity=None
        v=self.verify_model(model,backend)
        if v["status"]!="REAL": return v
        self.selected_model=model; self.selected_backend=v["backend"]; self._save_selection(); return {"status":"REAL","selected_model":model,"selected_backend":self.selected_backend,"verified":True}
    def is_available(self): return self.status()["status"]=="READY"
    def generation_profile(self, task="general"):
        return profile(self.config, task)

    def complete(self,system,prompt,max_tokens=None,model=None,generation=None,task="general"):
        st=self.status()
        if st["status"]!="READY": raise RuntimeError(f"LLM REQUIRED — {st['message']}")
        g=self.generation_profile(task)
        if generation: g.update(generation)
        if max_tokens is not None: g["max_tokens"]=int(max_tokens)
        system=f"{system}\n\n{g.get('system_suffix','')}".strip()
        chosen=model or st.get("selected_model"); backend,_=self._find_backend(chosen,st.get("selected_backend")) if chosen else (None,None)
        if backend is None:
            backend=next(b for b in self.backends if b.name==st["active_backend"]); chosen=None
        return backend.complete(system,prompt,int(g.get("max_tokens",700)),chosen,generation=g)
