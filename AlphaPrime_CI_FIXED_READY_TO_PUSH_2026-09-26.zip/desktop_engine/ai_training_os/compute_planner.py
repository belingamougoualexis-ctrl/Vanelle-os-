"""
compute_planner.py — Smart Compute Planner.

Choisit automatiquement, selon le matériel RÉELLEMENT détecté sur la
machine qui exécute AI Training OS (pas une machine centrale), le
provider et la taille de modèle adaptés :

  pas de GPU              -> LOCAL_CPU_PROVIDER, petit modèle
  1 GPU utilisable         -> LOCAL_GPU_PROVIDER, modèle plus grand
  >=2 GPU CUDA utilisables -> LOCAL_MULTI_GPU_PROVIDER, entraînement
                              distribué localement, modèle encore plus grand

Chaque niveau reste honnêtement optionnel : rien n'est débloqué tant que
le matériel correspondant n'est pas réellement détecté sur la machine.
"""
from . import compute
from .providers import get_provider


TIERS = [
    {
        "tier": "MULTI_GPU",
        "provider": "LOCAL_MULTI_GPU_PROVIDER",
        "model_size": "large (hidden_size=64+)",
        "requires": "≥2 GPU CUDA locaux",
    },
    {
        "tier": "SINGLE_GPU",
        "provider": "LOCAL_GPU_PROVIDER",
        "model_size": "medium (hidden_size=16-32)",
        "requires": "1 GPU (CUDA ou Apple MPS) + PyTorch",
    },
    {
        "tier": "CPU_ONLY",
        "provider": "LOCAL_CPU_PROVIDER",
        "model_size": "small (logistic regression / random forest / SGD)",
        "requires": "toujours disponible",
    },
]


class SmartComputePlanner:
    def plan(self, n_rows: int = None, n_features: int = None) -> dict:
        """
        Retourne le tier réellement utilisable sur CETTE machine, en
        testant chaque provider dans l'ordre décroissant de puissance
        via is_available() — jamais une supposition sur le matériel.
        """
        hardware = compute.full_report()

        for tier_def in TIERS:
            provider = get_provider(tier_def["provider"])
            availability = provider.is_available()
            if availability["available"]:
                return {
                    "selected_tier": tier_def["tier"],
                    "selected_provider": tier_def["provider"],
                    "recommended_model_size": tier_def["model_size"],
                    "reason": availability["reason"],
                    "hardware_detected": hardware,
                    "all_tiers_evaluated": self._evaluate_all(),
                }

        # Ne devrait jamais arriver (LOCAL_CPU_PROVIDER toujours disponible si scikit-learn l'est),
        # mais reste honnête si même le CPU n'est pas utilisable (dépendance manquante).
        return {
            "selected_tier": "NONE",
            "selected_provider": None,
            "reason": "Aucun provider local utilisable — vérifier l'installation de scikit-learn.",
            "hardware_detected": hardware,
            "all_tiers_evaluated": self._evaluate_all(),
        }

    def _evaluate_all(self):
        out = []
        for tier_def in TIERS:
            provider = get_provider(tier_def["provider"])
            avail = provider.is_available()
            out.append({
                "tier": tier_def["tier"],
                "provider": tier_def["provider"],
                "available": avail["available"],
                "reason": avail["reason"],
            })
        return out
