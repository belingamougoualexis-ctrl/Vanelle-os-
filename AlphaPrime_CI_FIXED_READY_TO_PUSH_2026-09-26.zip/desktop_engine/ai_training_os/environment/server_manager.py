"""Server environment management.

Servers are treated as first-class compute nodes. AlphaPrime can inspect a node
through an installed agent or SSH. It never pretends a remote GPU is available
until the remote machine performs a real verification test.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import json, shlex, shutil, subprocess

@dataclass
class ServerSpec:
    id: str
    host: str
    port: int = 22
    user: str = ""
    agent_url: str | None = None
    enabled: bool = True

class ServerManager:
    def __init__(self): self.nodes = {}
    def register(self, spec: ServerSpec): self.nodes[spec.id] = spec; return asdict(spec)
    def remove(self, server_id): return self.nodes.pop(server_id, None) is not None
    def list(self): return [asdict(x) for x in self.nodes.values()]

    def inspect_ssh(self, spec: ServerSpec, timeout=12):
        if not shutil.which("ssh"):
            return {"status":"UNAVAILABLE","server_id":spec.id,"reason":"Client SSH non disponible sur la machine contrôleur."}
        target = f"{spec.user}@{spec.host}" if spec.user else spec.host
        cmd=["ssh","-o","BatchMode=yes","-o","ConnectTimeout=8","-p",str(spec.port),target,
             "python3 - <<'PY'\nimport json,platform,shutil,subprocess,os\nr={'platform':platform.platform(),'python':platform.python_version(),'cpu':os.cpu_count() or 1}\np=shutil.which('nvidia-smi')\nif p:\n q=subprocess.run([p,'--query-gpu=index,name,memory.total,driver_version','--format=csv,noheader,nounits'],capture_output=True,text=True); r['nvidia_smi']=q.stdout.strip(); r['nvidia_smi_rc']=q.returncode\ntry:\n import torch; r['torch']={'version':torch.__version__,'cuda_available':bool(torch.cuda.is_available()),'cuda_version':torch.version.cuda,'device_count':torch.cuda.device_count(),'devices':[torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]}\nexcept Exception as e:r['torch']={'installed':False,'error':str(e)}\nprint(json.dumps(r))\nPY"]
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
        if p.returncode!=0: return {"status":"FAILED","server_id":spec.id,"reason":p.stderr.strip() or p.stdout.strip()}
        line=next((x for x in reversed(p.stdout.splitlines()) if x.strip().startswith("{")),None)
        if not line: return {"status":"FAILED","server_id":spec.id,"reason":"Réponse distante non JSON."}
        return {"status":"REAL","server_id":spec.id,"transport":"SSH","remote":json.loads(line)}

    def deployment_plan(self, inspection):
        r=inspection.get("remote",{}); torch=r.get("torch",{}); gpu=bool(r.get("nvidia_smi"))
        actions=[]
        if gpu and not torch.get("cuda_available"):
            actions.append({"id":"REMOTE_PYTORCH_CUDA","automatic":"INSTALL_IN_SERVER_ENV","reason":"GPU NVIDIA présent mais PyTorch CUDA indisponible."})
        if not gpu and not torch.get("cuda_available"):
            actions.append({"id":"REMOTE_CPU_OR_OTHER_ACCELERATOR","automatic":"DETECT_AND_SELECT","reason":"Aucun GPU NVIDIA CUDA utilisable confirmé."})
        return {"status":"REAL","ready":bool(torch.get("cuda_available")),"actions":actions}
