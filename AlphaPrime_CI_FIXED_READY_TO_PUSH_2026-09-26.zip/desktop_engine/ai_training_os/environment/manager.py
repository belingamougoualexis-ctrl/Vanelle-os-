"""Automatic local environment preparation and verification."""
from __future__ import annotations
import json
import os
import subprocess
import sys
from .scanner import scan, plan

class EnvironmentManager:
    def __init__(self, workspace="."):
        self.workspace = os.path.abspath(workspace)

    def inspect(self):
        s = scan(); p = plan(s)
        return {"status": "REAL", "scan": s, "plan": p}

    def verify(self):
        data = self.inspect()
        s = data["scan"]
        if s["training_runtime"]["backend"] == "CUDA":
            try:
                import torch
                x = torch.ones((2, 2), device="cuda")
                y = (x @ x).detach().cpu().tolist()
                data["verification"] = {"status": "PASSED", "backend": "CUDA", "matmul": y, "device_count": torch.cuda.device_count()}
            except Exception as e:
                data["verification"] = {"status": "FAILED", "backend": "CUDA", "reason": str(e)}
        elif s["training_runtime"]["backend"] == "MPS":
            try:
                import torch
                x = torch.ones((2, 2), device="mps"); y = (x @ x).detach().cpu().tolist()
                data["verification"] = {"status": "PASSED", "backend": "MPS", "matmul": y}
            except Exception as e:
                data["verification"] = {"status": "FAILED", "backend": "MPS", "reason": str(e)}
        else:
            data["verification"] = {"status": "NOT_READY", "backend": s["training_runtime"]["backend"]}
        return data

    def install_application_runtime(self, extra_packages=None):
        """Install only application-level packages in the current Python environment.
        System GPU drivers are never silently replaced."""
        packages = [str(x) for x in (extra_packages or [])]
        if not packages:
            return {"status": "REAL", "changed": False, "reason": "Aucun package application manquant identifié."}
        cmd = [sys.executable, "-m", "pip", "install", *packages]
        p = subprocess.run(cmd, capture_output=True, text=True)
        return {"status": "REAL" if p.returncode == 0 else "FAILED", "changed": p.returncode == 0, "command": cmd, "stdout": p.stdout[-4000:], "stderr": p.stderr[-4000:]}

    def prepare(self, install_llm_stack=True):
        from ..hardware_manager import HardwareManager
        return HardwareManager(self.workspace).prepare(install_llm_stack=install_llm_stack)
