"""Real environment scanner and dependency planner.

The scanner distinguishes physical hardware detection from a usable training
runtime. It never reports READY merely because a GPU is visible.
"""
from __future__ import annotations
import importlib.util
import os
import platform
import shutil
import subprocess
import sys
from typing import Any


def _run(cmd, timeout=8):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return {"returncode": p.returncode, "stdout": p.stdout.strip(), "stderr": p.stderr.strip()}
    except Exception as e:
        return {"returncode": -1, "stdout": "", "stderr": str(e)}


def _version(module):
    try:
        m = __import__(module)
        return getattr(m, "__version__", "unknown")
    except Exception:
        return None


def scan() -> dict[str, Any]:
    result = {
        "status": "REAL",
        "platform": {"system": platform.system(), "release": platform.release(), "machine": platform.machine(), "python": platform.python_version()},
        "cpu": {"logical_cores": os.cpu_count() or 1, "processor": platform.processor() or "unknown"},
        "memory": {}, "disk": {}, "gpu": {"devices": []}, "drivers": {}, "runtimes": {}, "frameworks": {},
    }
    try:
        import psutil
        vm = psutil.virtual_memory(); du = psutil.disk_usage(os.getcwd())
        result["memory"] = {"total_mb": round(vm.total/2**20, 1), "available_mb": round(vm.available/2**20, 1)}
        result["disk"] = {"free_gb": round(du.free/2**30, 2), "total_gb": round(du.total/2**30, 2)}
    except Exception:
        pass

    nvsmi = shutil.which("nvidia-smi")
    if nvsmi:
        q = _run([nvsmi, "--query-gpu=index,name,memory.total,driver_version", "--format=csv,noheader,nounits"])
        if q["returncode"] == 0:
            for line in q["stdout"].splitlines():
                p = [x.strip() for x in line.split(",")]
                if len(p) >= 4:
                    result["gpu"]["devices"].append({"index": int(p[0]), "name": p[1], "vram_mb": float(p[2]), "vendor": "NVIDIA", "driver": p[3]})
            result["drivers"]["nvidia"] = {"installed": True, "version": result["gpu"]["devices"][0].get("driver") if result["gpu"]["devices"] else None}
            cv = _run([nvsmi, "--query-gpu=compute_cap", "--format=csv,noheader"])
            if cv["returncode"] == 0:
                result["gpu"]["compute_capability"] = [x.strip() for x in cv["stdout"].splitlines() if x.strip()]
        else:
            result["drivers"]["nvidia"] = {"installed": False, "reason": q["stderr"] or "nvidia-smi failed"}

    amd = shutil.which("rocminfo")
    if amd:
        result["drivers"]["rocm"] = {"installed": True, "version": _version("torch")}
    elif platform.system() == "Linux":
        result["drivers"].setdefault("rocm", {"installed": False})

    result["runtimes"]["cuda"] = {"installed": bool(shutil.which("nvcc")), "version": None}
    if result["runtimes"]["cuda"]["installed"]:
        v = _run(["nvcc", "--version"])
        result["runtimes"]["cuda"]["version"] = v["stdout"][-200:] if v["returncode"] == 0 else None
    result["runtimes"]["python"] = {"executable": sys.executable, "version": platform.python_version()}

    torch_installed = importlib.util.find_spec("torch") is not None
    result["frameworks"]["torch"] = {"installed": torch_installed, "version": _version("torch") if torch_installed else None}
    if torch_installed:
        try:
            import torch
            result["frameworks"]["torch"].update({
                "cuda_available": bool(torch.cuda.is_available()),
                "cuda_version": getattr(torch.version, "cuda", None),
                "cuda_device_count": int(torch.cuda.device_count()),
                "mps_available": bool(getattr(torch.backends, "mps", None) and torch.backends.mps.is_available()),
            })
        except Exception as e:
            result["frameworks"]["torch"]["probe_error"] = str(e)

    gpu_devices = result["gpu"]["devices"]
    torch_cuda = bool(result["frameworks"]["torch"].get("cuda_available"))
    torch_mps = bool(result["frameworks"]["torch"].get("mps_available"))
    if gpu_devices and torch_cuda:
        backend = "CUDA"
    elif torch_mps:
        backend = "MPS"
    elif gpu_devices:
        backend = "GPU_DRIVER_ONLY"
    else:
        backend = "CPU"
    result["training_runtime"] = {"backend": backend, "ready": (backend in ("CUDA", "MPS"))}
    return result


def plan(scan_result: dict[str, Any]) -> dict[str, Any]:
    missing = []
    actions = []
    gpu = scan_result.get("gpu", {}).get("devices", [])
    drivers = scan_result.get("drivers", {})
    torch = scan_result.get("frameworks", {}).get("torch", {})
    runtime = scan_result.get("training_runtime", {})
    if gpu and any(d.get("vendor") == "NVIDIA" for d in gpu) and not drivers.get("nvidia", {}).get("installed"):
        missing.append("NVIDIA_DRIVER")
        actions.append({"id": "NVIDIA_DRIVER", "kind": "SYSTEM_COMPONENT", "reason": "GPU NVIDIA détecté sans pilote utilisable.", "automatic": "GUIDED_SYSTEM_INSTALL"})
    if gpu and any(d.get("vendor") == "NVIDIA" for d in gpu) and not torch.get("cuda_available"):
        missing.append("PYTORCH_CUDA_RUNTIME")
        actions.append({"id": "PYTORCH_CUDA_RUNTIME", "kind": "APPLICATION_RUNTIME", "reason": "GPU NVIDIA détecté mais PyTorch CUDA n'est pas utilisable.", "automatic": "INSTALL_IN_ISOLATED_ENV"})
    if runtime.get("backend") == "GPU_DRIVER_ONLY":
        actions.append({"id": "GPU_RUNTIME_VERIFICATION", "kind": "VERIFICATION", "reason": "Le GPU est visible mais le framework ne peut pas encore l'utiliser.", "automatic": "REQUIRED"})
    if not gpu and runtime.get("backend") == "CPU":
        actions.append({"id": "CPU_RUNTIME", "kind": "NONE", "reason": "Aucun GPU utilisable détecté; entraînement CPU disponible.", "automatic": "NONE"})
    return {"status": "REAL", "missing": missing, "actions": actions, "ready": bool(runtime.get("ready")) and not missing}
