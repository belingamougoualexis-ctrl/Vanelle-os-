"""Real local LoRA/QLoRA fine-tuning engine for causal LMs.

No simulated training: if the local training stack, model, dataset or hardware is
not available, the operation returns UNAVAILABLE/FAILED with cause + solution.
"""
from __future__ import annotations
import json, math, os, shutil, subprocess, sys, zipfile
from pathlib import Path
from . import utils

class LLMFineTuneEngine:
    def __init__(self, base_dir, startup, audit=None):
        self.base_dir = Path(base_dir)
        self.startup = startup
        self.audit = audit
        self.root = self.base_dir / "llm_finetuning"
        self.root.mkdir(parents=True, exist_ok=True)
        self.jobs = self.root / "jobs"
        self.jobs.mkdir(exist_ok=True)

    def status(self):
        deps = {}
        for name in ("torch", "transformers", "peft", "datasets", "accelerate", "bitsandbytes"):
            try:
                mod = __import__(name)
                deps[name] = {"available": True, "version": getattr(mod, "__version__", "unknown")}
            except Exception as e:
                deps[name] = {"available": False, "reason": str(e)}
        resources = self.startup.resources()
        base = resources.get("qwen_train_base", {})
        return {"status":"REAL", "dependencies":deps, "base_model":base,
                "base_models":self.available_base_models(),
                "lora_ready": all(deps[x]["available"] for x in ("torch","transformers","peft","datasets","accelerate")) and bool(self.available_base_models()),
                "qlora_ready": all(deps[x]["available"] for x in ("torch","transformers","peft","datasets","accelerate","bitsandbytes")) and bool(self.available_base_models())}

    def _dataset_records(self, path, text_column=None, prompt_column=None, response_column=None):
        import pandas as pd
        p=Path(path)
        if not p.is_file():
            raise FileNotFoundError(f"Dataset introuvable: {path}")
        rows=[]
        if p.suffix.lower()==".jsonl":
            with p.open(encoding="utf-8") as f:
                rows=[json.loads(line) for line in f if line.strip()]
        elif p.suffix.lower()==".json":
            data=json.loads(p.read_text(encoding="utf-8")); rows=data if isinstance(data,list) else data.get("data",[])
        else:
            sep="\t" if p.suffix.lower()==".tsv" else ","
            rows=pd.read_csv(p,sep=sep).fillna("").to_dict(orient="records")
        if not rows: raise ValueError("Le dataset ne contient aucune ligne exploitable.")
        texts=[]
        for r in rows:
            if not isinstance(r,dict): raise ValueError("Le dataset LLM doit contenir des objets/colonnes.")
            if text_column:
                if text_column not in r: raise ValueError(f"Colonne texte absente: {text_column}")
                text=str(r[text_column])
            elif prompt_column and response_column:
                if prompt_column not in r or response_column not in r: raise ValueError("Colonnes prompt/réponse absentes.")
                text=f"### Instruction:\n{r[prompt_column]}\n### Response:\n{r[response_column]}"
            elif "text" in r:
                text=str(r["text"])
            elif "messages" in r:
                text=json.dumps(r["messages"],ensure_ascii=False)
            elif "instruction" in r and ("output" in r or "response" in r):
                text=f"### Instruction:\n{r['instruction']}\n### Response:\n{r.get('output',r.get('response',''))}"
            else:
                raise ValueError("Aucune structure LLM reconnue. Choisissez une colonne texte ou prompt/réponse.")
            text=text.strip()
            if text: texts.append(text)
        if len(texts)<2: raise ValueError("Au moins 2 exemples sont nécessaires pour séparer entraînement et test.")
        return texts

    def available_base_models(self):
        out=[]
        root=self.base_dir/"llm_models"
        if root.exists():
            for p in sorted(root.iterdir()):
                if p.is_dir() and (p/"config.json").is_file() and any((p/x).exists() for x in ("model.safetensors","pytorch_model.bin","model.safetensors.index.json")):
                    out.append({"name":p.name,"path":str(p),"source":"LOCAL_TRANSFORMERS","verified":True})
        default=self.startup.resources().get("qwen_train_base",{})
        if default.get("path") and Path(default["path"]).exists() and not any(x["path"]==default["path"] for x in out):
            out.append({"name":"Qwen2.5-0.5B-Instruct","path":default["path"],"source":"BOOTSTRAP","verified":default.get("status")=="READY"})
        return out

    def _local_model_path(self, selected=None):
        if selected:
            p=Path(selected)
            if p.is_dir() and (p/"config.json").is_file() and any((p/x).exists() for x in ("model.safetensors","pytorch_model.bin","model.safetensors.index.json")):
                return p
            raise RuntimeError(f"Modèle Transformers local non vérifié: {selected}")
        default=self.startup.resources().get("qwen_train_base",{})
        p=default.get("path")
        if not p or not Path(p).exists():
            raise RuntimeError("Aucun modèle Transformers local vérifié n'est disponible.")
        return Path(p)

    def _install_hint(self, qlora):
        return ("Installez le stack local de fine-tuning: torch, transformers, peft, datasets et accelerate. "
                + ("Pour QLoRA, ajoutez bitsandbytes et utilisez un GPU CUDA compatible." if qlora else "Pour LoRA CPU, un GPU n'est pas obligatoire mais l'entraînement peut être beaucoup plus lent."))

    def run(self, dataset_path, output_name="alpha-prime-adapter", method="lora", epochs=1,
            text_column=None, prompt_column=None, response_column=None, learning_rate=2e-4,
            batch_size=1, max_length=512, test_ratio=0.1, base_model=None, lora_r=16,
            lora_alpha=32, lora_dropout=0.05):
        method=str(method).lower(); qlora=method=="qlora"
        if method not in ("lora","qlora"): raise ValueError("Méthode de fine-tuning inconnue: utilisez lora ou qlora.")
        st=self.status()
        required=("torch","transformers","peft","datasets","accelerate") + (("bitsandbytes",) if qlora else ())
        missing=[x for x in required if not st["dependencies"].get(x,{}).get("available")]
        if missing:
            return {"status":"UNAVAILABLE","truth_status":"UNAVAILABLE","cause":f"Dépendances manquantes: {', '.join(missing)}","solution":self._install_hint(qlora)}
        try: base=self._local_model_path(base_model)
        except Exception as e: return {"status":"UNAVAILABLE","truth_status":"UNAVAILABLE","cause":str(e),"solution":"Attendez la fin du téléchargement automatique du modèle de base puis réessayez."}
        try:
            texts=self._dataset_records(dataset_path,text_column,prompt_column,response_column)
            from datasets import Dataset
            from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments, Trainer, DataCollatorForLanguageModeling
            from peft import LoraConfig, TaskType, get_peft_model
            import torch
            if qlora and not torch.cuda.is_available():
                return {"status":"UNAVAILABLE","truth_status":"UNAVAILABLE","cause":"QLoRA nécessite actuellement un environnement CUDA local compatible avec bitsandbytes.","solution":"Sélectionnez LoRA pour un entraînement CPU/local, ou utilisez une machine avec GPU NVIDIA/CUDA + bitsandbytes fonctionnel."}
            split=max(1,int(len(texts)*float(test_ratio))) if len(texts)>=10 else 1
            train_texts=texts[:-split]; test_texts=texts[-split:]
            tokenizer=AutoTokenizer.from_pretrained(str(base),local_files_only=True,use_fast=True)
            if tokenizer.pad_token is None: tokenizer.pad_token=tokenizer.eos_token
            def tok(batch):
                return tokenizer(batch["text"],truncation=True,max_length=int(max_length),padding=False)
            train_ds=Dataset.from_dict({"text":train_texts}).map(tok,batched=True,remove_columns=["text"])
            eval_ds=Dataset.from_dict({"text":test_texts}).map(tok,batched=True,remove_columns=["text"])
            dtype=torch.float16 if torch.cuda.is_available() else torch.float32
            kwargs={"local_files_only":True}
            if qlora:
                from transformers import BitsAndBytesConfig
                kwargs["quantization_config"]=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_compute_dtype=torch.float16,bnb_4bit_quant_type="nf4",bnb_4bit_use_double_quant=True)
                kwargs["device_map"]="auto"
            else:
                kwargs["torch_dtype"]=dtype
                if torch.cuda.is_available(): kwargs["device_map"]="auto"
            model=AutoModelForCausalLM.from_pretrained(str(base),**kwargs)
            if qlora:
                from peft import prepare_model_for_kbit_training
                model=prepare_model_for_kbit_training(model)
            cfg=LoraConfig(task_type=TaskType.CAUSAL_LM,inference_mode=False,r=int(lora_r),lora_alpha=int(lora_alpha),lora_dropout=float(lora_dropout),target_modules="all-linear" if qlora else ["q_proj","v_proj"])
            model=get_peft_model(model,cfg)
            trainable=sum(p.numel() for p in model.parameters() if p.requires_grad)
            total=sum(p.numel() for p in model.parameters())
            job_id=utils.new_id("ft")
            out=self.jobs/job_id
            out.mkdir(parents=True,exist_ok=True)
            args=TrainingArguments(output_dir=str(out/"checkpoints"),num_train_epochs=float(epochs),per_device_train_batch_size=int(batch_size),per_device_eval_batch_size=1,learning_rate=float(learning_rate),logging_steps=1,evaluation_strategy="epoch",save_strategy="epoch",report_to=[],remove_unused_columns=False,fp16=bool(torch.cuda.is_available() and not qlora),bf16=False)
            collator=DataCollatorForLanguageModeling(tokenizer=tokenizer,mlm=False)
            trainer=Trainer(model=model,args=args,train_dataset=train_ds,eval_dataset=eval_ds,data_collator=collator)
            before=trainer.evaluate()
            trainer.train()
            after=trainer.evaluate()
            adapter_dir=out/"adapter"; model.save_pretrained(str(adapter_dir)); tokenizer.save_pretrained(str(adapter_dir))
            # Real post-training smoke test with the trained adapter.
            prompt=test_texts[0][: min(len(test_texts[0]),500)]
            inputs=tokenizer(prompt,return_tensors="pt")
            if hasattr(model,"device"): inputs={k:v.to(model.device) for k,v in inputs.items()}
            with torch.no_grad(): generated=model.generate(**inputs,max_new_tokens=32,do_sample=False)
            generated_text=tokenizer.decode(generated[0],skip_special_tokens=True)
            if not generated_text.strip(): raise RuntimeError("Le test post-entraînement n'a produit aucune sortie.")
            meta={"status":"REAL","truth_status":"REAL","job_id":job_id,"method":method,"base_model":str(base),"dataset":os.path.abspath(dataset_path),"train_examples":len(train_texts),"test_examples":len(test_texts),"before_eval":before,"after_eval":after,"trainable_parameters":trainable,"total_parameters":total,"trainable_percent":100*trainable/max(total,1),"lora_config":{"r":int(lora_r),"alpha":int(lora_alpha),"dropout":float(lora_dropout)},"smoke_test":"PASSED","smoke_output":generated_text[:1000],"created_at":utils.now_iso()}
            (adapter_dir/"alpha_prime_training.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding="utf-8")
            delivery=self._package_delivery(job_id,adapter_dir,meta)
            meta["delivery_zip"]=delivery
            (out/"result.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding="utf-8")
            if self.audit:self.audit.log("system","LLM_FINETUNE_COMPLETED","llm_finetune",job_id,meta)
            return meta
        except Exception as e:
            cause=f"{type(e).__name__}: {e}"
            solution="Vérifiez le dataset, la mémoire disponible, la compatibilité PyTorch/Transformers et les paramètres LoRA/QLoRA; aucune réussite n'est déclarée tant que le test post-entraînement n'est pas passé."
            if self.audit:self.audit.log("system","LLM_FINETUNE_FAILED","llm_finetune",dataset_path,{"error":cause})
            return {"status":"FAILED","truth_status":"FAILED","cause":cause,"solution":solution}

    def _package_delivery(self,job_id,adapter_dir,meta):
        zip_path=self.jobs/job_id/f"{job_id}_ALPHA_PRIME_LLM_ADAPTER.zip"
        with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED) as z:
            for p in adapter_dir.rglob("*"):
                if p.is_file(): z.write(p,p.relative_to(adapter_dir))
            z.writestr("INSTALL.md",f"# Alpha Prime LLM adapter\n\nJob: {job_id}\nMethod: {meta['method']}\nBase model: {meta['base_model']}\n\nLoad this PEFT adapter on the exact base model recorded in alpha_prime_training.json.\n")
        return {"path":str(zip_path),"sha256":utils.sha256_file(zip_path),"size_bytes":zip_path.stat().st_size}
