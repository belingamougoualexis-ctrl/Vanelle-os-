"""ai_scientist.py — analyseur scientifique local des expériences réelles.

Le moteur produit d'abord des observations calculées sur la base SQLite.
Une génération LLM est optionnelle: lorsqu'aucun LLM local n'existe, les
observations restent REAL et les hypothèses génératives sont explicitement
UNAVAILABLE plutôt que remplacées par du texte fictif.
"""
import json
import statistics
from . import utils


class AIScientist:
    def __init__(self, conn, llm_provider=None, audit=None):
        self.conn = conn
        self.llm = llm_provider
        self.audit = audit

    def status(self):
        llm_status = self.llm.status() if self.llm else {"status": "UNAVAILABLE"}
        return {
            "status": "READY",
            "analysis_engine": "REAL — SQLite experiment history",
            "local_llm": llm_status,
            "generative_hypotheses": "READY" if llm_status.get("status") == "READY" else "UNAVAILABLE",
        }

    def analyze(self, project_id: str):
        rows = self.conn.execute(
            "SELECT * FROM experiments WHERE project_id=? ORDER BY created_at", (project_id,)
        ).fetchall()
        experiments = [dict(r) for r in rows]
        completed = [e for e in experiments if e.get("status") == "COMPLETED" and e.get("metrics_json")]
        observations = []
        hypotheses = []

        if not completed:
            observations.append({
                "status": "REAL",
                "type": "coverage",
                "finding": "Aucune expérience terminée avec métriques mesurées dans ce projet.",
            })
        else:
            for metric in self._metric_names(completed):
                values = [self._metric_value(e, metric) for e in completed]
                values = [v for v in values if isinstance(v, (int, float))]
                if values:
                    observations.append({
                        "status": "REAL",
                        "type": "metric_distribution",
                        "metric": metric,
                        "n": len(values),
                        "min": min(values),
                        "max": max(values),
                        "mean": statistics.mean(values),
                        "latest": values[-1],
                    })

            if len(completed) >= 2:
                latest = completed[-1]
                previous = completed[-2]
                shared = set(json.loads(latest["metrics_json"] or "{}")) & set(json.loads(previous["metrics_json"] or "{}"))
                for metric in sorted(shared):
                    a = self._metric_value(previous, metric)
                    b = self._metric_value(latest, metric)
                    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and a != b:
                        observations.append({
                            "status": "REAL",
                            "type": "regression_check",
                            "metric": metric,
                            "previous": a,
                            "latest": b,
                            "delta": b - a,
                        })

            providers = sorted({e.get("provider") for e in completed})
            if len(providers) > 1:
                observations.append({
                    "status": "REAL",
                    "type": "provider_diversity",
                    "providers": providers,
                })

            # Hypothèses déterministes basées uniquement sur des faits observés.
            last_metrics = json.loads(completed[-1]["metrics_json"] or "{}")
            if "accuracy" in last_metrics and float(last_metrics["accuracy"]) < 1.0:
                hypotheses.append({
                    "status": "PROPOSED",
                    "origin": "rule_based_scientific_analysis",
                    "hypothesis": "Les erreurs restantes doivent être analysées par Error Mining et par une validation ciblée des exemples difficiles avant toute modification de modèle.",
                    "evidence": {"latest_accuracy": float(last_metrics["accuracy"])},
                })
            if len(completed) >= 2:
                hypotheses.append({
                    "status": "PROPOSED",
                    "origin": "rule_based_scientific_analysis",
                    "hypothesis": "Une expérience contrôlée sur un seul hyperparamètre à la fois permettrait d'attribuer plus proprement les variations observées entre les dernières runs.",
                    "evidence": {"completed_experiments": len(completed)},
                })

        # Cherche les clusters d'erreurs reliés aux évaluations du projet.
        error_counts = self.conn.execute(
            """SELECT ec.cluster_label, SUM(ec.n_examples) AS n_examples
               FROM error_clusters ec
               JOIN evaluations ev ON ec.evaluation_id = ev.id
               JOIN model_versions mv ON ev.model_version_id = mv.id
               JOIN models m ON mv.model_id = m.id
               WHERE m.project_id=?
               GROUP BY ec.cluster_label ORDER BY n_examples DESC""",
            (project_id,),
        ).fetchall()
        if error_counts:
            observations.append({
                "status": "REAL",
                "type": "error_mining",
                "clusters": [dict(r) for r in error_counts],
            })
            hypotheses.append({
                "status": "PROPOSED",
                "origin": "error_mining",
                "hypothesis": "Prioriser un nouvel essai qui cible les groupes d'erreurs les plus fréquents plutôt qu'une optimisation générale non ciblée.",
                "evidence": {"top_clusters": [dict(r) for r in error_counts[:3]]},
            })

        llm_generation = None
        if self.llm:
            st = self.llm.status()
            if st.get("status") == "READY":
                prompt = (
                    "Analyse scientifique du projet à partir exclusivement des observations JSON ci-dessous. "
                    "Propose au maximum trois hypothèses testables. Ne présente aucune hypothèse comme validée. "
                    "Réponds en français et conserve les identifiants/données.\n\n" +
                    utils.dumps({"observations": observations, "hypotheses": hypotheses})
                )
                try:
                    llm_generation = self.llm.complete(
                        "Tu es un scientifique ML local. Tu ne dois utiliser que les preuves fournies.",
                        prompt,
                        max_tokens=700,
                        task="scientist",
                    )
                except Exception as exc:
                    llm_generation = {"status": "FAILED", "error": str(exc)}
            else:
                llm_generation = {
                    "status": "UNAVAILABLE",
                    "reason": st.get("message", "LLM local non disponible."),
                }

        report = {
            "status": "REAL",
            "project_id": project_id,
            "experiments_analyzed": len(experiments),
            "completed_experiments": len(completed),
            "observations": observations,
            "hypotheses": hypotheses,
            "llm_generation": llm_generation,
        }
        run_id = utils.new_id("scientist")
        self.conn.execute(
            """INSERT INTO scientist_reports
            (id, project_id, status, experiments_analyzed, report_json, created_at)
            VALUES (?,?,?,?,?,?)""",
            (run_id, project_id, "COMPLETED", len(experiments), utils.dumps(report), utils.now_iso()),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "AI_SCIENTIST_ANALYSIS", "scientist_report", run_id,
                            {"project_id": project_id, "completed_experiments": len(completed)})
        report["id"] = run_id
        return report

    def list_reports(self, project_id=None, limit=20):
        if project_id:
            rows = self.conn.execute(
                "SELECT * FROM scientist_reports WHERE project_id=? ORDER BY created_at DESC LIMIT ?",
                (project_id, int(limit)),
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM scientist_reports ORDER BY created_at DESC LIMIT ?", (int(limit),)
            ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["report"] = json.loads(d.pop("report_json"))
            out.append(d)
        return out

    @staticmethod
    def _metric_names(experiments):
        names = set()
        for e in experiments:
            try:
                names.update(json.loads(e["metrics_json"] or "{}").keys())
            except json.JSONDecodeError:
                continue
        return sorted(names)

    @staticmethod
    def _metric_value(experiment, metric):
        try:
            return json.loads(experiment["metrics_json"] or "{}").get(metric)
        except json.JSONDecodeError:
            return None
