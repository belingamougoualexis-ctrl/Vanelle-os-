"""Measured hardware profile and real capability tests.

This module is intentionally independent of the UI and avoids claiming that a
physical accelerator is usable until a framework-level operation succeeds.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

from .truth import evidence, state_from_checks


def _run(cmd: list[str], timeout: int = 8) -> dict[str, Any]:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return {
            "returncode": p.returncode,
            "stdout": p.stdout.strip(),
            "stderr": p.stderr.strip(),
        }
    except Exception as exc:
        return {"returncode": -1, "stdout": "", "stderr": f"{type(exc).__name__}: {exc}"}


def _read_first(path: str, prefixes: tuple[str, ...]) -> str | None:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                for prefix in prefixes:
                    if line.lower().startswith(prefix.lower()):
                        return line.split(":", 1)[1].strip()
    except OSError:
        return None
    return None


def _cpu_model() -> str:
    direct = platform.processor().strip()
    if direct and direct.lower() != "unknown":
        return direct
    system = platform.system()
    if system == "Linux":
        # Prefer the actual CPU model field; `processor: 0` is only an index.
        return (
            _read_first("/proc/cpuinfo", ("model name", "hardware"))
            or _read_first("/proc/cpuinfo", ("processor",))
            or "unknown"
        )
    if system == "Darwin":
        r = _run(["sysctl", "-n", "machdep.cpu.brand_string"])
        if r["returncode"] == 0 and r["stdout"]:
            return r["stdout"]
    if system == "Windows":
        r = _run(["powershell", "-NoProfile", "-Command", "(Get-CimInstance Win32_Processor | Select-Object -First 1 -ExpandProperty Name)"], timeout=5)
        if r["returncode"] == 0 and r["stdout"]:
            return r["stdout"]
    return "unknown"


def _physical_cores() -> int | None:
    try:
        import psutil
        value = psutil.cpu_count(logical=False)
        if value:
            return int(value)
    except Exception:
        pass
    system = platform.system()
    if system == "Darwin":
        r = _run(["sysctl", "-n", "hw.physicalcpu"], timeout=4)
        try:
            return int(r["stdout"])
        except (TypeError, ValueError):
            return None
    return None


def _memory_disk(path: str) -> tuple[dict[str, Any], dict[str, Any]]:
    memory = {}
    try:
        import psutil
        vm = psutil.virtual_memory()
        memory = {
            "total_mb": round(vm.total / 2**20, 1),
            "available_mb": round(vm.available / 2**20, 1),
            "used_mb": round(vm.used / 2**20, 1),
            "percent": float(vm.percent),
        }
    except Exception:
        if platform.system() == "Linux":
            total = _read_first("/proc/meminfo", ("MemTotal",))
            available = _read_first("/proc/meminfo", ("MemAvailable",))
            try:
                memory = {
                    "total_mb": round(int(total.split()[0]) / 1024, 1),
                    "available_mb": round(int(available.split()[0]) / 1024, 1),
                }
            except Exception:
                pass
    try:
        total, used, free = shutil.disk_usage(path)
        disk = {
            "path": os.path.abspath(path),
            "total_gb": round(total / 2**30, 2),
            "used_gb": round(used / 2**30, 2),
            "free_gb": round(free / 2**30, 2),
        }
    except OSError as exc:
        disk = {"status": "FAILED", "reason": str(exc)}
    return memory, disk


def _detect_gpu_devices() -> tuple[list[dict[str, Any]], dict[str, Any]]:
    devices: list[dict[str, Any]] = []
    drivers: dict[str, Any] = {}
    nvsmi = shutil.which("nvidia-smi")
    if nvsmi:
        q = _run([nvsmi, "--query-gpu=index,name,memory.total,driver_version", "--format=csv,noheader,nounits"])
        if q["returncode"] == 0:
            for line in q["stdout"].splitlines():
                parts = [x.strip() for x in line.split(",")]
                if len(parts) >= 4:
                    try:
                        devices.append({
                            "index": int(parts[0]),
                            "name": parts[1],
                            "vram_mb": float(parts[2]),
                            "vendor": "NVIDIA",
                            "driver": parts[3],
                        })
                    except ValueError:
                        continue
            drivers["nvidia"] = {"installed": bool(devices), "version": devices[0].get("driver") if devices else None}
        else:
            drivers["nvidia"] = {"installed": False, "reason": q["stderr"] or "nvidia-smi failed"}

    rocminfo = shutil.which("rocminfo")
    if rocminfo:
        r = _run([rocminfo], timeout=10)
        drivers["rocm"] = {"installed": r["returncode"] == 0, "probe": r["stdout"][:4000]}
        if r["returncode"] == 0 and not devices and platform.system() == "Linux":
            names = re.findall(r"^\s*Name:\s*(gfx[^\s]+)", r["stdout"], flags=re.IGNORECASE | re.MULTILINE)
            for idx, name in enumerate(dict.fromkeys(names)):
                devices.append({"index": idx, "name": name, "vram_mb": None, "vendor": "AMD", "driver": "ROCm"})
    elif platform.system() == "Linux":
        drivers.setdefault("rocm", {"installed": False})

    if platform.system() == "Darwin" and platform.machine().lower() == "arm64":
        sp = shutil.which("system_profiler")
        if sp:
            r = _run([sp, "SPDisplaysDataType", "-json"], timeout=8)
            text = r["stdout"]
            if r["returncode"] == 0 and "Apple" in text and not devices:
                devices.append({"index": 0, "name": "Apple Silicon GPU", "vram_mb": None, "vendor": "Apple", "driver": "Metal/MPS"})
        else:
            devices.append({"index": 0, "name": "Apple Silicon GPU", "vram_mb": None, "vendor": "Apple", "driver": "Metal/MPS"})
        drivers["apple"] = {"installed": True, "backend": "MPS"}
    return devices, drivers


def scan(workspace: str = ".") -> dict[str, Any]:
    memory, disk = _memory_disk(workspace)
    logical = os.cpu_count() or 1
    physical = _physical_cores()
    devices, drivers = _detect_gpu_devices()
    torch_info: dict[str, Any] = {"installed": False}
    try:
        import torch
        torch_info = {
            "installed": True,
            "version": getattr(torch, "__version__", "unknown"),
            "cuda_available": bool(torch.cuda.is_available()),
            "cuda_version": getattr(torch.version, "cuda", None),
            "cuda_device_count": int(torch.cuda.device_count()),
            "mps_available": bool(getattr(torch.backends, "mps", None) and torch.backends.mps.is_available()),
            "backends": {
                "cuda": bool(torch.cuda.is_available()),
                "mps": bool(getattr(torch.backends, "mps", None) and torch.backends.mps.is_available()),
            },
        }
    except Exception as exc:
        torch_info["probe_error"] = f"{type(exc).__name__}: {exc}"

    if devices and torch_info.get("cuda_available"):
        backend = "CUDA"
    elif torch_info.get("mps_available"):
        backend = "MPS"
    elif devices:
        backend = "GPU_DETECTED_NOT_USABLE"
    else:
        backend = "CPU"

    result = {
        "status": "REAL",
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "architecture": platform.architecture()[0],
            "python": platform.python_version(),
            "python_executable": sys.executable,
        },
        "cpu": {
            "model": _cpu_model(),
            "logical_cores": logical,
            "physical_cores": physical,
            "threads": logical,
        },
        "memory": memory,
        "disk": disk,
        "gpu": {"devices": devices, "count": len(devices)},
        "drivers": drivers,
        "frameworks": {"torch": torch_info},
        "training_runtime": {
            "backend": backend,
            "framework_ready": bool(torch_info.get("installed", False)) and backend in {"CPU", "CUDA", "MPS"},
        },
        "workspace": os.path.abspath(workspace),
        "scanned_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    serialized = json.dumps(result, sort_keys=True, ensure_ascii=False).encode("utf-8")
    result["fingerprint"] = hashlib.sha256(serialized).hexdigest()
    return result


def _cpu_smoke() -> dict[str, Any]:
    try:
        import numpy as np
        a = np.arange(16, dtype=np.float32).reshape(4, 4)
        b = np.flipud(np.arange(16, dtype=np.float32).reshape(4, 4))
        result = a @ b
        expected = np.array([[16, 22, 28, 34], [112, 134, 156, 178], [208, 246, 284, 322], [304, 358, 412, 466]], dtype=np.float32)
        ok = bool(np.allclose(result, expected))
        return {"status": "VERIFIED" if ok else "FAILED", "operation": "numpy_matmul", "result_checksum": hashlib.sha256(result.tobytes()).hexdigest(), "verified": ok}
    except Exception as exc:
        return {"status": "FAILED", "operation": "numpy_matmul", "reason": f"{type(exc).__name__}: {exc}"}


def _torch_device_smoke(device: str) -> dict[str, Any]:
    try:
        import torch
        import torch.nn as nn
        class TinyNet(nn.Module):
            def __init__(self):
                super().__init__()
                self.net = nn.Sequential(nn.Linear(4, 8), nn.ReLU(), nn.Linear(8, 2))
            def forward(self, x):
                return self.net(x)

        model = TinyNet().to(device)
        x = torch.tensor([[1.0, 2.0, 3.0, 4.0], [0.5, 1.5, 2.5, 3.5]], device=device)
        y = torch.tensor([0, 1], dtype=torch.long, device=device)
        out = model(x)
        loss = torch.nn.functional.cross_entropy(out, y)
        optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
        optimizer.zero_grad()
        loss.backward()
        has_grad = any(p.grad is not None and bool(torch.isfinite(p.grad).all().item()) for p in model.parameters())
        optimizer.step()
        output_cpu = model(x).detach().cpu()
        pred_ok = bool(output_cpu.shape == (2, 2) and torch.isfinite(output_cpu).all().item())
        with tempfile.TemporaryDirectory(prefix="aitos_gpu_verify_") as td:
            path = Path(td) / "checkpoint.pt"
            torch.save({"state_dict": model.state_dict()}, path)
            fresh = TinyNet().to(device)
            fresh.load_state_dict(torch.load(path, map_location=device, weights_only=True))
            reloaded = fresh(x).detach().cpu()
            reload_ok = bool(reloaded.shape == (2, 2) and torch.isfinite(reloaded).all().item())
        param_device = str(next(model.parameters()).device)
        if device == "cuda":
            torch.cuda.synchronize()
        return {
            "status": "VERIFIED" if has_grad and pred_ok and reload_ok else "FAILED",
            "device": param_device,
            "forward": pred_ok,
            "backward": has_grad,
            "optimizer": True,
            "checkpoint": reload_ok,
            "reload_inference": reload_ok,
        }
    except Exception as exc:
        return {"status": "FAILED", "device": device, "reason": f"{type(exc).__name__}: {exc}"}


def verify(workspace: str = ".") -> dict[str, Any]:
    s = scan(workspace)
    checks: list[dict[str, Any]] = []
    cpu = _cpu_smoke()
    checks.append({"name": "cpu_real_compute", **cpu, "evidence": evidence(cpu["status"], "LOCAL_TEST", "CPU arithmetic and result verification" )})

    memory_disk = s.get("memory", {})
    disk_free = float(s.get("disk", {}).get("free_gb", 0) or 0)
    tmp_ok = False
    try:
        with tempfile.TemporaryDirectory(prefix="aitos_reality_") as td:
            p = Path(td) / "utf8.bin"
            payload = ("Alpha Prime ✓ données locales — sécurité — GPU/CPU\\n" * 10000).encode("utf-8")
            p.write_bytes(payload)
            tmp_ok = p.read_bytes() == payload and p.stat().st_size == len(payload)
    except Exception as exc:
        checks.append({"name": "filesystem_utf8_temp", "status": "FAILED", "reason": str(exc)})
    if not any(c["name"] == "filesystem_utf8_temp" for c in checks):
        checks.append({"name": "filesystem_utf8_temp", "status": "VERIFIED" if tmp_ok else "FAILED", "bytes": len(payload), "free_gb": disk_free})

    backend = s["training_runtime"]["backend"]
    if backend == "CUDA":
        gpu = _torch_device_smoke("cuda")
        checks.append({"name": "gpu_cuda_reality", **gpu, "evidence": evidence(gpu["status"], "LOCAL_TEST", "CUDA allocation, tensor compute, backward, optimizer, checkpoint and reload")})
    elif backend == "MPS":
        gpu = _torch_device_smoke("mps")
        checks.append({"name": "gpu_mps_reality", **gpu, "evidence": evidence(gpu["status"], "LOCAL_TEST", "MPS allocation, tensor compute, backward, optimizer, checkpoint and reload")})
    elif s["gpu"]["count"] > 0:
        checks.append({
            "name": "gpu_runtime",
            "status": "NOT VERIFIED",
            "reason": "Un GPU physique a été détecté mais aucun backend torch exploitable n'a permis un test de calcul réel.",
            "evidence": evidence("NOT VERIFIED", "LOCAL_TEST", "Physical GPU is not enough to prove usability"),
        })
    else:
        checks.append({
            "name": "gpu_runtime",
            "status": "NOT VERIFIED",
            "reason": "Aucun GPU local détecté; le chemin GPU ne peut pas être validé sur cette machine.",
            "evidence": evidence("NOT VERIFIED", "LOCAL_TEST", "No physical GPU available for execution"),
        })

    # CPU fallback is always explicitly exercised when no verified accelerator exists.
    if backend not in {"CUDA", "MPS"}:
        fallback = {"status": "NOT VERIFIED"}
        try:
            from sklearn.datasets import make_classification
            from sklearn.linear_model import LogisticRegression
            X, y = make_classification(n_samples=32, n_features=4, n_informative=3, n_redundant=0, random_state=7)
            model = LogisticRegression(max_iter=200).fit(X, y)
            pred = model.predict(X[:4])
            fallback = {"status": "VERIFIED" if len(pred) == 4 else "FAILED", "prediction_count": int(len(pred)), "scope": "REAL_LOCAL_TEST"}
        except Exception as exc:
            fallback = {"status": "FAILED", "reason": f"{type(exc).__name__}: {exc}"}
        checks.append({"name": "cpu_fallback_real_inference", **fallback, "evidence": evidence(fallback["status"], "LOCAL_TEST", "Local CPU inference smoke test", {"scope": fallback.get("scope", "REAL")})})

    state = state_from_checks([{"status": c.get("status")} for c in checks])
    return {
        "status": state,
        "truth_status": "LOCAL_TEST",
        "profile": s,
        "checks": checks,
        "limitations": [
            "Un environnement absent ne peut pas être déclaré validé.",
            "Les tests GPU/LLM nécessitent le matériel et les dépendances présents localement.",
        ],
    }
