"""Truth and evidence primitives used by the local verification system."""
from __future__ import annotations

from typing import Any

OFFICIAL_STATES = {
    "VERIFIED",
    "DEGRADED",
    "NOT VERIFIED",
    "FAILED",
    "RECOVERING",
    "TESTING",
}

EVIDENCE_LEVELS = {
    "LOCAL_TEST": 1,
    "OFFICIAL_DOC": 2,
    "TRUSTED_TECHNICAL": 3,
    "COMMUNITY": 4,
    "AI_HYPOTHESIS": 5,
}


def state_from_checks(checks: list[dict[str, Any]]) -> str:
    """Derive an official state without treating missing proof as success."""
    if not checks:
        return "NOT VERIFIED"
    statuses = [str(c.get("status", "NOT VERIFIED")).upper() for c in checks]
    if any(s == "FAILED" for s in statuses):
        return "FAILED"
    if any(s in {"NOT VERIFIED", "UNKNOWN"} for s in statuses):
        return "DEGRADED" if any(s == "VERIFIED" for s in statuses) else "NOT VERIFIED"
    if any(s == "RECOVERING" for s in statuses):
        return "RECOVERING"
    if any(s == "TESTING" for s in statuses):
        return "TESTING"
    if all(s == "VERIFIED" for s in statuses):
        return "VERIFIED"
    return "DEGRADED"


def evidence(
    status: str,
    source_type: str,
    claim: str,
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    status = str(status).upper()
    if status not in OFFICIAL_STATES:
        status = "NOT VERIFIED"
    source_type = str(source_type).upper()
    return {
        "status": status,
        "source_type": source_type,
        "source_priority": EVIDENCE_LEVELS.get(source_type, 99),
        "claim": claim,
        "details": details or {},
    }
