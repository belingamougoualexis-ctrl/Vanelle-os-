"""
job_engine.py — Job Engine réel.

Les jobs longue durée ne peuvent pas rester actifs entre deux appels
séparés dans cet environnement (pas de processus démon persistant),
mais toute la mécanique (états, queue, checkpoints, reprise, échec,
annulation) est réellement implémentée et testée avec des jobs CPU
courts qui s'exécutent réellement du début à la fin.
"""
from . import utils

VALID_STATES = {
    "QUEUED", "RUNNING", "PAUSED", "FAILED", "COMPLETED",
    "VALIDATING", "VALIDATED", "CANCELLED",
}


class JobEngine:
    def __init__(self, conn, audit=None):
        self.conn = conn
        self.audit = audit

    def create_job(self, experiment_id: str, kind: str, provider: str, config: dict) -> str:
        job_id = utils.new_id("job")
        now = utils.now_iso()
        self.conn.execute(
            """INSERT INTO jobs (id, experiment_id, kind, provider, status, progress,
               config_json, checkpoint_path, last_epoch, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (job_id, experiment_id, kind, provider, "QUEUED", 0.0,
             utils.dumps(config), None, 0, now, now),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "CREATE_JOB", "job", job_id, {"kind": kind, "provider": provider})
        return job_id

    def set_status(self, job_id: str, status: str, **fields):
        if status not in VALID_STATES:
            raise ValueError(f"État de job invalide: {status}")
        sets = ["status=?", "updated_at=?"]
        vals = [status, utils.now_iso()]
        for k, v in fields.items():
            sets.append(f"{k}=?")
            vals.append(v)
        vals.append(job_id)
        self.conn.execute(f"UPDATE jobs SET {', '.join(sets)} WHERE id=?", vals)
        self.conn.commit()
        if self.audit:
            self.audit.log("system", f"JOB_{status}", "job", job_id, fields)

    def record_checkpoint(self, job_id: str, epoch: int, file_path: str, metrics: dict):
        ckpt_id = utils.new_id("ckpt")
        ckpt_hash = utils.sha256_file(file_path)
        self.conn.execute(
            """INSERT INTO checkpoints (id, job_id, epoch, file_path, sha256, metrics_json, is_valid, created_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (ckpt_id, job_id, epoch, file_path, ckpt_hash, utils.dumps(metrics), 1, utils.now_iso()),
        )
        self.conn.execute(
            "UPDATE jobs SET checkpoint_path=?, last_epoch=?, updated_at=? WHERE id=?",
            (file_path, epoch, utils.now_iso(), job_id),
        )
        self.conn.commit()
        return ckpt_id

    def get_last_valid_checkpoint(self, job_id: str):
        """Reprise: retrouve le dernier checkpoint valide en vérifiant réellement le hash."""
        rows = self.conn.execute(
            "SELECT * FROM checkpoints WHERE job_id=? ORDER BY epoch DESC", (job_id,)
        ).fetchall()
        for row in rows:
            r = dict(row)
            try:
                actual_hash = utils.sha256_file(r["file_path"])
            except FileNotFoundError:
                continue
            if actual_hash == r["sha256"]:
                return r
            else:
                # checkpoint corrompu détecté réellement -> marqué invalide
                self.conn.execute("UPDATE checkpoints SET is_valid=0 WHERE id=?", (r["id"],))
                self.conn.commit()
        return None

    def get(self, job_id: str):
        row = self.conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return dict(row) if row else None

    def list_jobs(self):
        rows = self.conn.execute("SELECT * FROM jobs ORDER BY created_at DESC").fetchall()
        return [dict(r) for r in rows]

    def cancel(self, job_id: str):
        self.set_status(job_id, "CANCELLED")
