"""red_team.py — tests adversariaux réels pour les modèles locaux.

Le laboratoire ne prétend exécuter que ce qu'il peut charger et mesurer.
Pour les modèles scikit-learn sérialisés localement et datasets JSONL internes,
il applique des perturbations déterministes aux features numériques et mesure
les changements de prédiction et de performance.
"""
import json
import os
import pickle
import statistics
from . import utils


class RedTeamLab:
    def __init__(self, conn, audit=None):
        self.conn = conn
        self.audit = audit

    def status(self):
        try:
            import sklearn  # noqa: F401
            available = True
            reason = "scikit-learn présent: tests tabulaires locaux disponibles."
        except ImportError:
            available = False
            reason = "scikit-learn absent: laboratoire tabulaire local indisponible."
        return {
            "status": "READY" if available else "UNAVAILABLE",
            "capabilities": [
                "tabular_numeric_feature_masking",
                "prediction_flip_rate",
                "adversarial_accuracy",
                "model_artifact_integrity",
            ] if available else [],
            "reason": reason,
            "note": "Les familles de modèles sans backend spécialisé restent UNAVAILABLE.",
        }

    def list_runs(self, project_id=None, limit=50):
        if project_id:
            rows = self.conn.execute(
                "SELECT * FROM red_team_runs WHERE project_id=? ORDER BY created_at DESC LIMIT ?",
                (project_id, int(limit)),
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM red_team_runs ORDER BY created_at DESC LIMIT ?", (int(limit),)
            ).fetchall()
        return [self._row_dict(r) for r in rows]

    def get_run(self, run_id):
        row = self.conn.execute("SELECT * FROM red_team_runs WHERE id=?", (run_id,)).fetchone()
        if not row:
            return None
        result = self._row_dict(row)
        tests = self.conn.execute(
            "SELECT * FROM red_team_tests WHERE run_id=? ORDER BY created_at", (run_id,)
        ).fetchall()
        result["tests"] = [self._row_dict(r) for r in tests]
        return result

    @staticmethod
    def _row_dict(row):
        d = dict(row)
        for key in ("summary_json", "details_json"):
            if key in d and d[key]:
                try:
                    d[key[:-5]] = json.loads(d.pop(key))
                except Exception:
                    pass
        return d

    def run_for_evaluation(self, evaluation_id: str, project_id: str = None):
        evaluation = self.conn.execute(
            "SELECT * FROM evaluations WHERE id=?", (evaluation_id,)
        ).fetchone()
        if not evaluation:
            raise ValueError(f"Evaluation introuvable: {evaluation_id}")
        evaluation = dict(evaluation)
        mv = self.conn.execute(
            "SELECT * FROM model_versions WHERE id=?", (evaluation["model_version_id"],)
        ).fetchone()
        if not mv:
            raise ValueError("Version de modèle introuvable pour cette évaluation.")
        mv = dict(mv)
        if project_id is None:
            project_row = self.conn.execute(
                "SELECT project_id FROM models WHERE id=?", (mv["model_id"],)
            ).fetchone()
            project_id = project_row[0] if project_row else None
        model_path = mv.get("file_path")
        if not model_path or not os.path.isfile(model_path):
            return self._record_unavailable(
                project_id, mv["id"], evaluation_id,
                "UNAVAILABLE — le fichier de modèle local n'est pas enregistré ou est introuvable."
            )
        try:
            actual_hash = utils.sha256_file(model_path)
        except OSError as exc:
            return self._record_failed(project_id, mv["id"], evaluation_id, str(exc))
        if mv.get("sha256") and actual_hash != mv["sha256"]:
            return self._record_unavailable(
                project_id, mv["id"], evaluation_id,
                "UNAVAILABLE — intégrité du modèle non vérifiée: SHA-256 différent de celui du registry."
            )

        dv = self.conn.execute(
            "SELECT * FROM dataset_versions WHERE id=?", (evaluation["dataset_version_id"],)
        ).fetchone()
        if not dv:
            raise ValueError("Version de dataset introuvable pour cette évaluation.")
        dv = dict(dv)
        split = json.loads(dv.get("split_json") or "{}")
        records = self._read_jsonl(dv["file_path"])
        label_col = self._find_label_col(records)
        if not label_col:
            return self._record_unavailable(
                project_id, mv["id"], evaluation_id,
                "UNAVAILABLE — aucune colonne label/class/target/category détectée pour construire un test adversarial supervisé."
            )
        feature_cols = self._numeric_feature_cols(records, label_col)
        if not feature_cols:
            return self._record_unavailable(
                project_id, mv["id"], evaluation_id,
                "UNAVAILABLE — aucune feature numérique exploitable pour la perturbation réelle."
            )
        test_indices = split.get("test") or split.get("val") or []
        samples = []
        for idx in test_indices:
            if idx < len(records):
                row = records[idx]
                try:
                    y = row[label_col]
                    x = [float(row[c]) for c in feature_cols]
                    samples.append((idx, row, x, y))
                except (KeyError, TypeError, ValueError):
                    continue
            if len(samples) >= 40:
                break
        if not samples:
            return self._record_unavailable(
                project_id, mv["id"], evaluation_id,
                "UNAVAILABLE — aucun exemple de test numérique exploitable dans le split réel."
            )

        try:
            with open(model_path, "rb") as f:
                model = pickle.load(f)
            clean_x = [x for _, _, x, _ in samples]
            clean_y = [y for _, _, _, y in samples]
            clean_pred = model.predict(clean_x).tolist()
            medians = [statistics.median([float(r[c]) for r in records if self._is_number(r.get(c))]) for c in feature_cols]
        except Exception as exc:
            return self._record_failed(project_id, mv["id"], evaluation_id, f"Chargement/exécution modèle impossible: {exc}")

        run_id = utils.new_id("redteam")
        now = utils.now_iso()
        self.conn.execute(
            """INSERT INTO red_team_runs
            (id, project_id, model_version_id, evaluation_id, status, summary_json, created_at)
            VALUES (?,?,?,?,?,?,?)""",
            (run_id, project_id, mv["id"], evaluation_id, "RUNNING", utils.dumps({}), now),
        )
        self.conn.commit()

        attack_results = []
        for sample_no, ((idx, _row, x, y), clean) in enumerate(zip(samples, clean_pred)):
            attacked = list(x)
            # Attaque déterministe: masquer la feature ayant la plus grande
            # amplitude relative sur cet exemple en la remplaçant par sa médiane.
            spans = []
            for j, val in enumerate(x):
                base = abs(medians[j]) if abs(medians[j]) > 1e-12 else 1.0
                spans.append(abs(val - medians[j]) / base)
            j = max(range(len(attacked)), key=lambda k: spans[k])
            attacked[j] = medians[j]
            try:
                attack_pred = model.predict([attacked]).tolist()[0]
                passed = bool(self._same_label(attack_pred, y))
            except Exception as exc:
                passed = False
                attack_pred = f"EXECUTION_ERROR: {exc}"
            test_id = utils.new_id("rttest")
            details = {
                "feature": feature_cols[j],
                "original_value": x[j],
                "replacement_value": medians[j],
                "clean_prediction": clean,
                "attack_prediction": attack_pred,
                "expected_label": y,
                "prediction_flipped": not self._same_label(attack_pred, clean),
            }
            self.conn.execute(
                """INSERT INTO red_team_tests
                (id, run_id, test_type, input_index, expected, clean_prediction,
                 attack_prediction, passed, details_json, created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (test_id, run_id, "numeric_feature_masking", idx, str(y), str(clean),
                 str(attack_pred), int(passed), utils.dumps(details), utils.now_iso()),
            )
            attack_results.append({"passed": passed, **details})
            if sample_no >= 39:
                break

        clean_acc = sum(int(self._same_label(p, y)) for p, y in zip(clean_pred[:len(attack_results)], clean_y[:len(attack_results)])) / max(1, len(attack_results))
        attack_acc = sum(int(r["passed"]) for r in attack_results) / max(1, len(attack_results))
        flip_rate = sum(int(r["prediction_flipped"]) for r in attack_results) / max(1, len(attack_results))
        summary = {
            "label": "REAL",
            "n_tests": len(attack_results),
            "clean_accuracy": clean_acc,
            "adversarial_accuracy": attack_acc,
            "prediction_flip_rate": flip_rate,
            "attack": "numeric_feature_masking",
            "model_sha256_verified": True,
            "dataset_version_id": dv["id"],
            "model_version_id": mv["id"],
        }
        self.conn.execute(
            "UPDATE red_team_runs SET status=?, summary_json=? WHERE id=?",
            ("COMPLETED", utils.dumps(summary), run_id),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "RED_TEAM_COMPLETED", "red_team_run", run_id, summary)
        return {"id": run_id, "status": "COMPLETED", "summary": summary}

    def _record_unavailable(self, project_id, model_version_id, evaluation_id, reason):
        run_id = utils.new_id("redteam")
        summary = {"label": "UNAVAILABLE", "reason": reason}
        self.conn.execute(
            """INSERT INTO red_team_runs
            (id, project_id, model_version_id, evaluation_id, status, summary_json, created_at)
            VALUES (?,?,?,?,?,?,?)""",
            (run_id, project_id, model_version_id, evaluation_id, "UNAVAILABLE", utils.dumps(summary), utils.now_iso()),
        )
        self.conn.commit()
        return {"id": run_id, "status": "UNAVAILABLE", "summary": summary}

    def _record_failed(self, project_id, model_version_id, evaluation_id, reason):
        run_id = utils.new_id("redteam")
        summary = {"label": "FAILED", "reason": reason}
        self.conn.execute(
            """INSERT INTO red_team_runs
            (id, project_id, model_version_id, evaluation_id, status, summary_json, created_at)
            VALUES (?,?,?,?,?,?,?)""",
            (run_id, project_id, model_version_id, evaluation_id, "FAILED", utils.dumps(summary), utils.now_iso()),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "RED_TEAM_FAILED", "red_team_run", run_id, summary)
        return {"id": run_id, "status": "FAILED", "summary": summary}

    @staticmethod
    def _read_jsonl(path):
        with open(path, "r", encoding="utf-8") as f:
            return [json.loads(line) for line in f if line.strip()]

    @staticmethod
    def _find_label_col(records):
        if not records:
            return None
        for candidate in ("label", "class", "target", "category"):
            if candidate in records[0]:
                return candidate
        return None

    @staticmethod
    def _same_label(a, b):
        if a == b: return True
        try: return float(a) == float(b)
        except (TypeError, ValueError): return str(a) == str(b)

    @staticmethod
    def _is_number(value):
        try:
            float(value)
            return value is not None and value != ""
        except (TypeError, ValueError):
            return False

    @classmethod
    def _numeric_feature_cols(cls, records, label_col):
        if not records:
            return []
        cols = [c for c in records[0].keys() if c != label_col]
        out = []
        # Tolère des valeurs manquantes: on exige au moins 80 % de valeurs
        # numériques pour éviter de transformer une vraie colonne catégorielle
        # en feature par accident. Les exemples non exploitables sont ensuite
        # exclus du test réel.
        for c in cols:
            present = [r.get(c) for r in records if c in r]
            numeric = [v for v in present if cls._is_number(v)]
            if present and len(numeric) / len(present) >= 0.8:
                out.append(c)
        return out
