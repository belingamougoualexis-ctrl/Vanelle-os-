"""Local hardware/runtime preparation plan with truth-first status."""
from __future__ import annotations
from .environment import EnvironmentManager
from .dependency_manager import matrix, ensure

class HardwareManager:
    def __init__(self, workspace: str):
        self.workspace = workspace
        self.env = EnvironmentManager(workspace)

    def status(self) -> dict:
        data = self.env.inspect()
        deps = matrix()
        return {
            "status": "REAL",
            "scan": data["scan"],
            "plan": data["plan"],
            "dependencies": deps,
            "recommended_training": self._recommend(data["scan"], deps),
        }

    def prepare(self, install_llm_stack: bool = True) -> dict:
        before = self.status()
        dep = ensure() if install_llm_stack else {"status":"PROPOSED","changed":False,"reason":"Installation des dépendances désactivée pour cette opération."}
        verified = self.env.verify()
        after = self.status()
        return {
            "status": "REAL" if dep.get("status") in ("REAL", "PROPOSED") and verified.get("verification",{}).get("status") not in ("FAILED",) else "FAILED",
            "truth_status": "REAL",
            "before": before,
            "dependency_install": dep,
            "hardware_verification": verified.get("verification"),
            "after": after,
            "message": "Préparation terminée; l'état final est mesuré, pas supposé.",
        }

    @staticmethod
    def _recommend(scan, deps):
        runtime = scan.get("training_runtime", {}).get("backend")
        packages = deps.get("packages", {})
        if runtime == "CUDA" and packages.get("bitsandbytes",{}).get("available"):
            return {"mode":"CUDA","fine_tuning":"QLoRA/LoRA","notes":"CUDA réel + bitsandbytes disponible."}
        if runtime in ("CUDA","MPS"):
            return {"mode":runtime,"fine_tuning":"LoRA","notes":"Accélérateur réel détecté; QLoRA reste conditionnel à bitsandbytes/CUDA."}
        return {"mode":"CPU","fine_tuning":"LoRA","notes":"Aucun accélérateur utilisable détecté; chemin CPU local."}
