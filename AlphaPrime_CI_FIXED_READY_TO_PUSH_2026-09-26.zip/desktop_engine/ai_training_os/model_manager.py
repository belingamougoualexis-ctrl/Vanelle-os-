"""
model_manager.py — Mega Model Manager.

Découpe réellement un fichier modèle en shards, calcule un vrai checksum
par shard, écrit un manifest réel, valide réellement chaque shard, et
sait reprendre un téléchargement HTTP réellement interrompu via des requêtes Range.
Le NetworkModelProvider est utilisé uniquement lorsqu'un téléchargement externe
est explicitement demandé. Il ne prétend jamais avoir téléchargé sans transfert réel.
"""
import os
import json
import shutil
from . import utils

SHARD_SIZE = 4 * 1024 * 1024  # 4 MB


class ModelManager:
    def __init__(self, storage_dir: str, audit=None):
        self.storage_dir = storage_dir
        self.audit = audit
        os.makedirs(storage_dir, exist_ok=True)

    def package(self, model_id: str, source_file: str) -> dict:
        """Découpe réellement un fichier en shards et écrit un manifest réel."""
        model_dir = os.path.join(self.storage_dir, model_id)
        shards_dir = os.path.join(model_dir, "shards")
        os.makedirs(shards_dir, exist_ok=True)

        shards = []
        total_size = os.path.getsize(source_file)
        with open(source_file, "rb") as f:
            idx = 0
            while True:
                chunk = f.read(SHARD_SIZE)
                if not chunk:
                    break
                shard_path = os.path.join(shards_dir, f"shard_{idx:05d}.bin")
                with open(shard_path, "wb") as sf:
                    sf.write(chunk)
                shard_hash = utils.sha256_bytes(chunk)
                shards.append({"index": idx, "path": shard_path, "sha256": shard_hash, "size_bytes": len(chunk)})
                idx += 1

        manifest = {
            "model_id": model_id,
            "source_file": source_file,
            "total_size_bytes": total_size,
            "n_shards": len(shards),
            "shard_size_bytes": SHARD_SIZE,
            "shards": shards,
            "full_sha256": utils.sha256_file(source_file),
            "created_at": utils.now_iso(),
            "status": "PACKAGED",
            "truth_status": "REAL",
        }
        manifest_path = os.path.join(model_dir, "manifest.json")
        with open(manifest_path, "w") as f:
            json.dump(manifest, f, indent=2)

        if self.audit:
            self.audit.log("system", "MODEL_PACKAGED", "model", model_id, {"n_shards": len(shards)})
        return manifest

    def load_manifest(self, model_id: str) -> dict:
        manifest_path = os.path.join(self.storage_dir, model_id, "manifest.json")
        if not os.path.exists(manifest_path):
            raise FileNotFoundError(f"Manifest introuvable pour {model_id}")
        with open(manifest_path) as f:
            return json.load(f)

    def validate(self, model_id: str) -> dict:
        """
        Validation RÉELLE : relit chaque shard depuis le disque, recalcule
        son hash, compare au manifest. Détecte les shards manquants/corrompus.
        """
        manifest = self.load_manifest(model_id)
        missing = []
        corrupted = []
        valid = []
        for shard in manifest["shards"]:
            if not os.path.exists(shard["path"]):
                missing.append(shard["index"])
                continue
            with open(shard["path"], "rb") as f:
                data = f.read()
            actual_hash = utils.sha256_bytes(data)
            if actual_hash != shard["sha256"]:
                corrupted.append(shard["index"])
            else:
                valid.append(shard["index"])

        is_ready = len(missing) == 0 and len(corrupted) == 0
        result = {
            "model_id": model_id,
            "status": "READY" if is_ready else "INCOMPLETE",
            "truth_status": "REAL" if is_ready else "FAILED",
            "valid_shards": valid,
            "missing_shards": missing,
            "corrupted_shards": corrupted,
            "n_shards_total": manifest["n_shards"],
        }
        if self.audit:
            self.audit.log("system", "MODEL_VALIDATED", "model", model_id, result)
        return result

    def repair_shard(self, model_id: str, shard_index: int, source_file: str) -> dict:
        """Restore a shard from the original source and verify against the manifest's full source hash."""
        manifest=self.load_manifest(model_id)
        if shard_index < 0 or shard_index >= len(manifest["shards"]): raise IndexError("shard index hors limites")
        shard_size=manifest["shard_size_bytes"]; offset=shard_index*shard_size
        with open(source_file,"rb") as f: f.seek(offset); chunk=f.read(shard_size)
        expected_size=manifest["shards"][shard_index]["size_bytes"]
        if len(chunk)!=expected_size: raise RuntimeError(f"Source trop courte pour le shard {shard_index}: {len(chunk)} != {expected_size}")
        expected_hash=manifest["shards"][shard_index]["sha256"]
        actual_hash=utils.sha256_bytes(chunk)
        if actual_hash!=expected_hash: return {"status":"FAILED","truth_status":"FAILED","shard_index":shard_index,"reason":"Le fragment source ne correspond pas au checksum attendu du manifest."}
        shard_path=manifest["shards"][shard_index]["path"]
        with open(shard_path,"wb") as sf: sf.write(chunk)
        validation=self.validate(model_id)
        return {"status":"REAL" if validation["status"]=="READY" else "FAILED","truth_status":"REAL" if validation["status"]=="READY" else "FAILED","shard_index":shard_index,"repaired":True,"sha256":actual_hash,"validation":validation}

    def import_file(self, model_id: str, source_file: str) -> dict:
        """Import a local model file without pretending it was downloaded."""
        if not os.path.isfile(source_file): raise FileNotFoundError(source_file)
        return self.package(model_id,source_file)

    def validate_source_format(self, source_file: str) -> dict:
        ext=os.path.splitext(source_file)[1].lower()
        if ext==".gguf":
            with open(source_file,"rb") as f: magic=f.read(4)
            return {"status":"REAL" if magic==b"GGUF" else "FAILED","format":"GGUF","magic":magic.decode("latin1",errors="replace")}
        return {"status":"REAL","format":ext or "unknown","note":"Validation structurelle de format non-spécifique; checksum reste la preuve d'intégrité."}

    def download(self, model_id: str, url: str, expected_sha256: str = None, chunk_size=1024*1024, max_bytes: int = None) -> dict:
        """Real resumable HTTP download using a .part file and Range requests."""
        import urllib.request, urllib.error
        os.makedirs(os.path.join(self.storage_dir,model_id),exist_ok=True)
        final=os.path.join(self.storage_dir,model_id,"model.bin"); part=final+".part"; manifest_path=os.path.join(self.storage_dir,model_id,"download.json")
        size=os.path.getsize(part) if os.path.exists(part) else 0
        req=urllib.request.Request(url,headers={"Range":f"bytes={size}-"} if size else {})
        try:
            with urllib.request.urlopen(req,timeout=20) as resp:
                code=getattr(resp,"status",None) or resp.getcode();
                if size and code!=206:
                    size=0
                    if os.path.exists(part): os.remove(part)
                    req=urllib.request.Request(url)
                    with urllib.request.urlopen(req,timeout=20) as resp2:
                        with open(part,"wb") as out:
                            downloaded=0
                            while True:
                                chunk=resp2.read(chunk_size)
                                if not chunk: break
                                if max_bytes is not None and downloaded+len(chunk)>max_bytes: chunk=chunk[:max_bytes-downloaded]
                                if not chunk: break
                                out.write(chunk); downloaded += len(chunk)
                                if max_bytes is not None and downloaded>=max_bytes:
                                    info={"status":"PAUSED","truth_status":"REAL","url":url,"partial_path":part,"bytes_downloaded":os.path.getsize(part)}
                                    with open(manifest_path,"w",encoding="utf-8") as f: json.dump(info,f,indent=2)
                                    return info
                else:
                    with open(part,"ab" if size else "wb") as out:
                        downloaded=0
                        while True:
                            chunk=resp.read(chunk_size)
                            if not chunk: break
                            if max_bytes is not None and downloaded+len(chunk)>max_bytes: chunk=chunk[:max_bytes-downloaded]
                            if not chunk: break
                            out.write(chunk); downloaded += len(chunk)
                            if max_bytes is not None and downloaded>=max_bytes:
                                info={"status":"PAUSED","truth_status":"REAL","url":url,"partial_path":part,"bytes_downloaded":os.path.getsize(part)}
                                with open(manifest_path,"w",encoding="utf-8") as f: json.dump(info,f,indent=2)
                                return info
        except Exception as exc:
            info={"status":"FAILED","url":url,"partial_path":part if os.path.exists(part) else None,"bytes_downloaded":os.path.getsize(part) if os.path.exists(part) else 0,"error":str(exc)}
            with open(manifest_path,"w",encoding="utf-8") as f: json.dump(info,f,indent=2)
            return info
        actual=utils.sha256_file(part)
        if expected_sha256 and actual.lower()!=expected_sha256.lower():
            return {"status":"FAILED","reason":"SHA-256 du fichier téléchargé différent du checksum attendu.","actual_sha256":actual,"expected_sha256":expected_sha256,"partial_path":part}
        os.replace(part,final)
        result={"status":"REAL","truth_status":"REAL","path":final,"sha256":actual,"size_bytes":os.path.getsize(final),"url":url}
        with open(manifest_path,"w",encoding="utf-8") as f: json.dump(result,f,indent=2)
        if self.audit:self.audit.log("system","MODEL_DOWNLOADED","model",model_id,{"size_bytes":result["size_bytes"],"sha256":actual})
        return result

    def inspect_model_file(self, path):
        if not os.path.isfile(path): return {"status":"UNAVAILABLE","reason":"Fichier absent"}
        size=os.path.getsize(path); ext=os.path.splitext(path)[1].lower(); result={"status":"REAL","path":os.path.abspath(path),"size_bytes":size,"sha256":utils.sha256_file(path),"format":ext or "unknown"}
        if ext==".gguf":
            with open(path,"rb") as f: result["valid_magic"]=f.read(4)==b"GGUF"
            result["estimated_ram_bytes"]=int(size*1.2); result["estimate_status"]="ESTIMATED"
        return result

    def cleanup_temp(self, model_id: str):
        root=os.path.join(self.storage_dir,model_id); removed=[]
        for name in os.listdir(root) if os.path.isdir(root) else []:
            if name.endswith(".part") or name.endswith(".tmp"):
                path=os.path.join(root,name); os.remove(path); removed.append(path)
        return {"status":"REAL","removed":removed}

    def progress(self, model_id: str) -> dict:
        root=os.path.join(self.storage_dir,model_id); p=os.path.join(root,"download.json");
        if not os.path.isfile(p): return {"status":"UNAVAILABLE","reason":"Aucun téléchargement enregistré."}
        with open(p,encoding="utf-8") as f:return json.load(f)

    def reassemble(self, model_id: str, output_path: str) -> dict:
        manifest=self.load_manifest(model_id); validation=self.validate(model_id)
        if validation["status"]!="READY": raise RuntimeError(f"Impossible de réassembler : shards manquants/corrompus {validation}")
        with open(output_path,"wb") as out:
            for shard in sorted(manifest["shards"],key=lambda s:s["index"]):
                with open(shard["path"],"rb") as f: shutil.copyfileobj(f,out,1024*1024)
        final_hash=utils.sha256_file(output_path)
        return {"status":"REAL" if final_hash==manifest["full_sha256"] else "FAILED","output_path":output_path,"sha256":final_hash,"matches_manifest":final_hash==manifest["full_sha256"]}


class NetworkModelProvider:
    """Provider réseau optionnel.

    Le cœur reste local : ce provider n'est utilisé que lorsqu'une fonction
    de téléchargement externe est explicitement demandée et que la connexion
    réseau est réellement disponible.
    """
    def is_available(self) -> dict:
        from . import compute
        net = compute.detect_network()
        return {"available": net["status"] == "REAL", "reason": net.get("reason", "OK"), "status": net["status"]}

    def download(self, url: str, dest: str, expected_sha256: str = None, chunk_size=1024*1024) -> dict:
        import urllib.request
        os.makedirs(os.path.dirname(os.path.abspath(dest)), exist_ok=True)
        part = dest + ".part"
        existing = os.path.getsize(part) if os.path.isfile(part) else 0
        headers = {"Range": f"bytes={existing}-"} if existing else {}
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=30) as resp:
                status = getattr(resp, "status", None) or resp.getcode()
                if existing and status != 206:
                    existing = 0
                    if os.path.isfile(part): os.remove(part)
                    req = urllib.request.Request(url)
                    resp.close()
                    resp = urllib.request.urlopen(req, timeout=30)
                mode = "ab" if existing else "wb"
                with open(part, mode) as out:
                    while True:
                        chunk = resp.read(chunk_size)
                        if not chunk: break
                        out.write(chunk)
            actual = utils.sha256_file(part)
            if expected_sha256 and actual.lower() != expected_sha256.lower():
                return {"status":"FAILED","reason":"Checksum SHA-256 différent du checksum attendu.","actual_sha256":actual,"expected_sha256":expected_sha256,"partial_path":part}
            os.replace(part, dest)
            return {"status":"REAL","path":os.path.abspath(dest),"sha256":actual,"size_bytes":os.path.getsize(dest),"url":url,"resumed":bool(existing)}
        except Exception as exc:
            return {"status":"FAILED","url":url,"partial_path":part if os.path.isfile(part) else None,"bytes_downloaded":os.path.getsize(part) if os.path.isfile(part) else 0,"error":str(exc)}
