"""Local artifact storage with content hashes and provenance manifests."""
import os, json, shutil
from . import utils

class ArtifactStorage:
    def __init__(self, root, audit=None, conn=None):
        self.root=os.path.abspath(root); self.audit=audit; self.conn=conn; os.makedirs(self.root,exist_ok=True)
    def put_file(self, source_path, kind="artifact", metadata=None):
        if not os.path.isfile(source_path): raise FileNotFoundError(source_path)
        aid=utils.new_id("artifact")
        sub=os.path.join(self.root, kind, aid); os.makedirs(sub,exist_ok=True)
        dest=os.path.join(sub,os.path.basename(source_path)); shutil.copy2(source_path,dest)
        manifest={"id":aid,"kind":kind,"source":os.path.abspath(source_path),"path":dest,"sha256":utils.sha256_file(dest),"size_bytes":os.path.getsize(dest),"status":"REAL","metadata":metadata or {},"created_at":utils.now_iso()}
        with open(os.path.join(sub,"manifest.json"),"w",encoding="utf-8") as f: json.dump(manifest,f,ensure_ascii=False,indent=2)
        project_id=(metadata or {}).get("project_id")
        if hasattr(self,"conn") and self.conn:
            self.conn.execute("INSERT INTO artifacts (id,project_id,kind,path,sha256,size_bytes,metadata_json,status,created_at) VALUES (?,?,?,?,?,?,?,?,?)",(aid,project_id,kind,dest,manifest["sha256"],manifest["size_bytes"],utils.dumps(manifest["metadata"]),"REAL",manifest["created_at"])); self.conn.commit()
        if self.audit: self.audit.log("system","ARTIFACT_STORED","artifact",aid,{"kind":kind,"sha256":manifest["sha256"]})
        return manifest
    def verify(self, manifest_or_path):
        path=manifest_or_path
        if os.path.isdir(path): path=os.path.join(path,"manifest.json")
        with open(path,encoding="utf-8") as f: m=json.load(f)
        exists=os.path.isfile(m["path"])
        actual=utils.sha256_file(m["path"]) if exists else None
        ok=exists and actual==m["sha256"]
        return {"status":"REAL","integrity":"OK" if ok else "FAILED","path":m["path"],"expected_sha256":m["sha256"],"actual_sha256":actual}
