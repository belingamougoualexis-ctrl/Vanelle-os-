"""Safe local technical research.

Internet is treated as an information source only. This engine never executes
commands received from webpages and stores provenance for fetched sources.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from . import utils


class InternetResearchEngine:
    MAX_BYTES = 2_000_000
    ALLOWED_SCHEMES = {"http", "https"}

    def __init__(self, workspace: str, audit=None, conn=None):
        self.workspace = Path(workspace).resolve()
        self.audit = audit
        self.conn = conn
        self.root = self.workspace / "research"
        self.root.mkdir(parents=True, exist_ok=True)

    def fetch(self, url: str, timeout: int = 10) -> dict[str, Any]:
        parsed = urllib.parse.urlparse(str(url))
        if parsed.scheme not in self.ALLOWED_SCHEMES or not parsed.netloc:
            return {"status": "FAILED", "reason": "URL refusée: seul HTTP(S) est autorisé."}
        request = urllib.request.Request(str(url), headers={"User-Agent": "AlphaPrime-Research/1.0"}, method="GET")
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                chunks = []
                total = 0
                while total < self.MAX_BYTES:
                    chunk = response.read(min(65536, self.MAX_BYTES - total))
                    if not chunk:
                        break
                    chunks.append(chunk)
                    total += len(chunk)
                body = b"".join(chunks)
                content_type = response.headers.get("Content-Type", "")
            digest = hashlib.sha256(body).hexdigest()
            source_id = utils.new_id("src")
            meta = {
                "status": "PROPOSED",
                "source_id": source_id,
                "url": str(url),
                "content_type": content_type,
                "bytes": len(body),
                "sha256": digest,
                "fetched_at": utils.now_iso(),
                "note": "Internet fournit une information; compatibilité locale à tester séparément.",
            }
            (self.root / f"{source_id}.meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
            if "text" in content_type or "html" in content_type or not content_type:
                text = body.decode("utf-8", errors="replace")
                meta["text_preview"] = re.sub(r"\s+", " ", text)[:3000]
            if self.conn:
                self.conn.execute(
                    "INSERT INTO research_sources (id,url,title,source_type,version,content_sha256,status,metadata_json,created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                    (source_id, str(url), None, "INTERNET_FETCH", None, digest, "NOT VERIFIED", json.dumps(meta, ensure_ascii=False), utils.now_iso()),
                )
                self.conn.commit()
            if self.audit:
                self.audit.log("system", "RESEARCH_SOURCE_FETCHED", "research_source", source_id, meta)
            return meta
        except Exception as exc:
            return {"status": "FAILED", "reason": f"{type(exc).__name__}: {exc}", "url": str(url)}

    def record_source(self, url: str, title: str, source_type: str = "OFFICIAL_DOC", version: str | None = None, note: str = "") -> dict[str, Any]:
        parsed = urllib.parse.urlparse(str(url))
        if parsed.scheme not in self.ALLOWED_SCHEMES or not parsed.netloc:
            return {"status": "FAILED", "reason": "URL HTTP(S) requise."}
        source_id = utils.new_id("src")
        payload = {"id": source_id, "url": url, "title": title, "source_type": source_type, "version": version, "note": note, "recorded_at": utils.now_iso()}
        (self.root / f"{source_id}.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        if self.conn:
            self.conn.execute(
                "INSERT INTO research_sources (id,url,title,source_type,version,content_sha256,status,metadata_json,created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                (source_id, url, title, source_type, version, None, "NOT VERIFIED", json.dumps(payload, ensure_ascii=False), utils.now_iso()),
            )
            self.conn.commit()
        if self.audit:
            self.audit.log("system", "RESEARCH_SOURCE_RECORDED", "research_source", source_id, payload)
        return {"status": "REAL", **payload}
