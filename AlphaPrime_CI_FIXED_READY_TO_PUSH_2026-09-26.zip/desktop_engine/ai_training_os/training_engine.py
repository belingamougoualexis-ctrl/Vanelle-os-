"""Training orchestration with real checkpoints, monitoring and post-run proof."""
from __future__ import annotations

import json
import os
import time
from typing import Any

from . import compute, utils
from .providers import get_provider
from .providers.local_cpu import TrainingInterrupted


class TrainingEngine:
    def __init__(self, conn, job_engine, experiment_registry, checkpoint_root, audit=None, reality=None, health_monitor=None, diagnostics=None):
        self.conn = conn
        self.job_engine = job_engine
        self.experiments = experiment_registry
        self.checkpoint_root = checkpoint_root
        self.audit = audit
        self.reality = reality
        self.health_monitor = health_monitor
        self.diagnostics = diagnostics
        os.makedirs(checkpoint_root, exist_ok=True)

    def _append_log(self, path: str, event: dict[str, Any]) -> None:
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"timestamp": utils.now_iso(), **event}, ensure_ascii=False, default=str) + "\n")

    def _fail(self, job_id, experiment_id, model_version_id, log_path, error, diagnostics=None):
        self.job_engine.set_status(job_id, "FAILED")
        self.experiments.fail(experiment_id, str(error))
        if model_version_id:
            self.conn.execute("UPDATE model_versions SET status='FAILED' WHERE id=?", (model_version_id,))
            self.conn.commit()
        payload = {"job_id": job_id, "status": "FAILED", "truth_status": "FAILED", "error": str(error)}
        if diagnostics:
            payload["diagnostic"] = diagnostics
        self._append_log(log_path, {"event": "failed", "error": str(error), "diagnostic": diagnostics or {}})
        return payload

    def _checkpoint_proof(self, job_id: str) -> dict[str, Any]:
        ckpt = self.job_engine.get_last_valid_checkpoint(job_id)
        if not ckpt:
            return {"status": "FAILED", "reason": "Aucun checkpoint valide n'a été enregistré."}
        path = ckpt.get("file_path")
        exists = bool(path and os.path.isfile(path))
        sha_ok = False
        if exists and ckpt.get("sha256"):
            sha_ok = utils.sha256_file(path) == ckpt["sha256"]
        elif exists:
            sha_ok = True
        return {
            "status": "VERIFIED" if exists and sha_ok else "FAILED",
            "checkpoint": ckpt,
            "exists": exists,
            "sha256_verified": sha_ok,
        }

    def run(self, experiment_id, provider_name, config):
        provider = get_provider(provider_name)
        av = provider.is_available()
        job_id = self.job_engine.create_job(experiment_id, "TRAINING", provider_name, config)
        if not av["available"]:
            self.job_engine.set_status(job_id, "FAILED")
            self.experiments.fail(experiment_id, f"UNAVAILABLE — DEPENDENCY REQUIRED: {av['reason']}")
            return {"job_id": job_id, "status": "UNAVAILABLE", "truth_status": "UNAVAILABLE", "reason": av["reason"]}

        work = dict(config)
        work["checkpoint_dir"] = os.path.join(self.checkpoint_root, job_id)
        os.makedirs(work["checkpoint_dir"], exist_ok=True)
        log_path = os.path.join(work["checkpoint_dir"], "training.jsonl")
        health_dir = work["checkpoint_dir"]
        monitor_started = False
        monitor_log = None
        operation_monitor = None

        self.job_engine.set_status(job_id, "RUNNING")
        self.experiments.start(experiment_id)
        exp_row0 = self.conn.execute("SELECT model_version_id FROM experiments WHERE id=?", (experiment_id,)).fetchone()
        model_version_id = exp_row0[0] if exp_row0 else None
        if model_version_id:
            self.conn.execute("UPDATE model_versions SET status='TRAINING' WHERE id=?", (model_version_id,))
            self.conn.commit()

        def log(event):
            self._append_log(log_path, event)

        def on_checkpoint(epoch, state):
            p = state.get("path")
            if p:
                self.job_engine.record_checkpoint(job_id, epoch, p, state.get("metrics", {}))
            self.job_engine.set_status(job_id, "RUNNING", progress=float(state.get("progress", 0.0)), last_epoch=epoch)
            log({"event": "checkpoint", "epoch": epoch, "metrics": state.get("metrics", {})})

        try:
            if self.health_monitor:
                from .health_monitor import ContinuousHealthMonitor
                operation_monitor = ContinuousHealthMonitor(self.checkpoint_root, interval_seconds=2.0, conn=self.conn)
                monitor_log = operation_monitor.start(health_dir, operation_id=job_id)
                monitor_started = True
                log({"event": "health_monitor_started", "path": monitor_log})

            t0 = time.time()
            result = provider.train(work, checkpoint_cb=on_checkpoint)
            duration = time.time() - t0

            checkpoint_proof = self._checkpoint_proof(job_id)
            final_path = result.get("final_model_path")
            final_exists = bool(final_path and os.path.isfile(final_path))
            final_sha_ok = bool(final_exists and (not result.get("final_model_sha256") or utils.sha256_file(final_path) == result.get("final_model_sha256")))
            artifact_proof = {
                "status": "VERIFIED" if final_exists and final_sha_ok else "FAILED",
                "path": final_path,
                "exists": final_exists,
                "sha256_verified": final_sha_ok,
            }
            if checkpoint_proof["status"] != "VERIFIED" or artifact_proof["status"] != "VERIFIED":
                return self._fail(job_id, experiment_id, model_version_id, log_path, "Entraînement terminé sans preuve valide du checkpoint ou du modèle final.", {"checkpoint": checkpoint_proof, "artifact": artifact_proof})

            if model_version_id and final_path:
                cfg_row = self.conn.execute("SELECT configuration_json FROM model_versions WHERE id=?", (model_version_id,)).fetchone()
                artifact_config = utils.loads(cfg_row[0] if cfg_row else "{}") or {}
                artifact_config["artifact_origin"] = "LOCAL_TRAINING"
                artifact_config["artifact_sha256"] = result.get("final_model_sha256")
                self.conn.execute(
                    "UPDATE model_versions SET file_path=?,sha256=?,metrics_json=?,status=?,configuration_json=? WHERE id=?",
                    (final_path, result.get("final_model_sha256"), utils.dumps(result["metrics"]), "EVALUATING", utils.dumps(artifact_config), model_version_id),
                )
                self.conn.commit()

            post_validation = None
            if self.reality and model_version_id:
                post_validation = self.reality.validate_model_version(model_version_id, run_inference=True)
                if post_validation.get("status") not in {"VERIFIED", "DEGRADED"}:
                    return self._fail(job_id, experiment_id, model_version_id, log_path, "Validation post-entraînement échouée: le modèle final n'a pas pu être rechargé/inféré avec preuve réelle.", post_validation)

            self.job_engine.set_status(job_id, "COMPLETED", progress=1.0)
            self.experiments.complete(experiment_id, result["metrics"], duration, log_path)
            log({
                "event": "completed",
                "metrics": result["metrics"],
                "duration_seconds": duration,
                "hardware": compute.full_report(self.checkpoint_root),
                "checkpoint_proof": checkpoint_proof,
                "artifact_proof": artifact_proof,
                "post_validation": post_validation,
            })
            return {
                "job_id": job_id,
                "status": "COMPLETED",
                "truth_status": "REAL",
                "metrics": result["metrics"],
                "duration_seconds": duration,
                "final_model_path": final_path,
                "final_model_sha256": result.get("final_model_sha256"),
                "predictions": result.get("predictions"),
                "y_val": result.get("y_val"),
                "logs_path": log_path,
                "health_log_path": monitor_log,
                "model_format": result.get("model_format"),
                "modality": result.get("modality"),
                "checkpoint_proof": checkpoint_proof,
                "artifact_proof": artifact_proof,
                "post_validation": post_validation,
            }
        except TrainingInterrupted as exc:
            self.job_engine.set_status(job_id, "PAUSED")
            self.experiments.pause(experiment_id, f"PAUSED — {exc}")
            log({"event": "interrupted", "reason": str(exc)})
            return {"job_id": job_id, "status": "PAUSED", "truth_status": "REAL", "reason": str(exc), "last_checkpoint": self.job_engine.get_last_valid_checkpoint(job_id), "health_log_path": monitor_log}
        except Exception as exc:
            diagnostic = None
            if self.diagnostics:
                try:
                    diagnostic = self.diagnostics.diagnose(
                        str(exc),
                        {"provider": provider_name, "job_id": job_id, "config": {k: v for k, v in work.items() if k not in {"X_train", "X_val", "y_train", "y_val"}}},
                    )
                except Exception:
                    diagnostic = None
            return self._fail(job_id, experiment_id, model_version_id, log_path, exc, diagnostic)
        finally:
            if operation_monitor and monitor_started:
                try:
                    operation_monitor.stop()
                    log({"event": "health_monitor_stopped"})
                except Exception:
                    pass

    def resume(self, job_id):
        ckpt = self.job_engine.get_last_valid_checkpoint(job_id)
        job = self.job_engine.get(job_id)
        if not job:
            return {"status": "FAILED", "reason": "Job introuvable."}
        if not ckpt:
            return {"status": "FAILED", "reason": "Aucun checkpoint valide trouvé pour la reprise."}
        config = json.loads(job.get("config_json") or "{}")
        provider_name = job["provider"]
        supported_resume = {
            ("LOCAL_CPU_PROVIDER", "sgd_incremental"),
            ("LOCAL_CPU_PROVIDER", "sgd_regressor"),
            ("LOCAL_CPU_PROVIDER", "mlp_sklearn"),
            ("LOCAL_CPU_PROVIDER", "mlp_torch"),
            ("LOCAL_GPU_PROVIDER", "mlp_torch"),
            ("LOCAL_MULTI_GPU_PROVIDER", "mlp_torch"),
        }
        if (provider_name, config.get("model_type")) not in supported_resume:
            return {"status": "UNAVAILABLE", "reason": "Le provider/modèle courant ne supporte pas une reprise epoch par epoch locale."}
        config["resume_from"] = ckpt["file_path"]
        config["start_epoch"] = int(ckpt["epoch"])
        config.pop("stop_after_epoch", None)
        if not job.get("experiment_id"):
            return {"status": "FAILED", "reason": "Job sans experiment lié."}
        config["resumed_from_job_id"] = job_id
        actual = self.run(job["experiment_id"], provider_name, config)
        if actual.get("status") == "COMPLETED":
            return {"status": "REAL", "operation": "RESUMED", "from_epoch": int(ckpt["epoch"]), "source_checkpoint": ckpt["file_path"], "result": actual}
        return {"status": actual.get("status", "FAILED"), "operation": "RESUME_ATTEMPT", "from_epoch": int(ckpt["epoch"]), "source_checkpoint": ckpt["file_path"], "result": actual}
