"""Real controlled experiment loop.

Auto Lab never manufactures an experiment: the caller must provide a callback
that launches an actual experiment/training operation. Stop conditions are
checked against measured callback results and local wall-clock time.
"""
import time
from . import utils


class AutoLab:
    def __init__(self, conn, audit=None):
        self.conn = conn
        self.audit = audit

    def run(self, project_id, plan, run_experiment, is_success=None, score_fn=None):
        run_id = utils.new_id("autolab")
        self.conn.execute(
            "INSERT INTO autolab_runs (id,project_id,status,config_json,started_at) VALUES (?,?,?,?,?)",
            (run_id, project_id, "RUNNING", utils.dumps(plan), utils.now_iso()),
        )
        self.conn.commit()
        results = []
        max_exp = max(1, int(plan.get("max_experiments", 3)))
        max_seconds = plan.get("max_time_seconds")
        max_artifact_bytes = plan.get("max_artifact_storage_bytes")
        patience = plan.get("no_improvement_patience")
        min_improvement = float(plan.get("min_improvement", 0.0) or 0.0)
        started = time.time()
        best_score = None
        stale = 0
        stop_reason = "MAX_EXPERIMENTS"
        run_status = "COMPLETED"

        try:
            for i in range(max_exp):
                if max_seconds is not None and time.time() - started >= float(max_seconds):
                    stop_reason = "TIME_LIMIT_REACHED"
                    break
                result = run_experiment(i, plan)
                results.append(result)
                if is_success and is_success(result):
                    stop_reason = "OBJECTIVE_REACHED"
                    break

                if score_fn:
                    try:
                        score = score_fn(result)
                    except Exception:
                        score = None
                    if score is not None:
                        score = float(score)
                        if best_score is None or score > best_score + min_improvement:
                            best_score = score
                            stale = 0
                        else:
                            stale += 1
                        if patience is not None and stale >= int(patience):
                            stop_reason = "NO_SIGNIFICANT_IMPROVEMENT"
                            break

                if max_artifact_bytes is not None:
                    measured = sum(float(result.get(k) or 0) for k in ("artifact_storage_bytes", "artifact_storage"))
                    nested = result.get("training") or {}
                    measured += float(nested.get("artifact_storage_bytes") or 0)
                    if measured > float(max_artifact_bytes):
                        stop_reason = "ARTIFACT_BUDGET_REACHED"
                        break

            # A callback can fail truthfully without fabricating success.
            if any(r.get("status") in {"FAILED", "UNAVAILABLE"} or (r.get("training") or {}).get("status") in {"FAILED", "UNAVAILABLE"} for r in results):
                run_status = "COMPLETED_WITH_FAILURES"
        except Exception as exc:
            run_status = "FAILED"
            stop_reason = "CALLBACK_EXCEPTION"
            results.append({"status": "FAILED", "error": f"{type(exc).__name__}: {exc}"})

        details = {"results": results, "stop_reason": stop_reason,
                   "elapsed_seconds": time.time() - started, "best_score": best_score}
        self.conn.execute(
            "UPDATE autolab_runs SET status=?,finished_at=?,details_json=? WHERE id=?",
            (run_status, utils.now_iso(), utils.dumps(details), run_id),
        )
        self.conn.commit()
        truth = "REAL" if run_status != "FAILED" else "FAILED"
        return {"status": truth, "id": run_id, "run_status": run_status,
                "experiments": len(results), "stop_reason": stop_reason, "results": results,
                "elapsed_seconds": details["elapsed_seconds"]}
