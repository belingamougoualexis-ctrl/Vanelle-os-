"""utils.py — helpers réels, aucune valeur inventée."""
import hashlib
import uuid
import datetime
import json


def now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:12]}"


def sha256_file(path: str, chunk_size: int = 1024 * 1024) -> str:
    """Hash réel du contenu d'un fichier, calculé par lecture effective du disque."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def dumps(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, default=str)


def loads(s):
    if s is None:
        return None
    return json.loads(s)
