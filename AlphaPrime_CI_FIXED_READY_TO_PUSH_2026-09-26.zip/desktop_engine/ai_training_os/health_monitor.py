"""Continuous local health sampling for important operations."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import threading
import time
from pathlib import Path
from typing import Any

from . import utils


def _gpu_sample() -> dict[str, Any]:
    nvsmi = shutil.which("nvidia-smi")
    if not nvsmi:
        return {"status": "NOT VERIFIED", "backend": None}
    try:
        p = subprocess.run([nvsmi, "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu", "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=5)
        if p.returncode != 0:
            return {"status": "FAILED", "error": p.stderr.strip()}
        samples = []
        for line in p.stdout.splitlines():
            parts = [x.strip() for x in line.split(",")]
            if len(parts) >= 4:
                samples.append({"utilization_percent": float(parts[0]), "memory_used_mb": float(parts[1]), "memory_total_mb": float(parts[2]), "temperature_c": float(parts[3])})
        return {"status": "VERIFIED", "backend": "NVIDIA", "devices": samples}
    except Exception as exc:
        return {"status": "FAILED", "error": f"{type(exc).__name__}: {exc}"}


def sample(workspace: str = ".") -> dict[str, Any]:
    data: dict[str, Any] = {"status": "VERIFIED", "timestamp": utils.now_iso()}
    try:
        import psutil
        vm = psutil.virtual_memory()
        data["cpu_percent"] = float(psutil.cpu_percent(interval=0.05))
        data["ram_percent"] = float(vm.percent)
        data["ram_available_mb"] = round(vm.available / 2**20, 1)
        data["process_rss_mb"] = round(psutil.Process(os.getpid()).memory_info().rss / 2**20, 1)
    except Exception as exc:
        data["resource_probe"] = {"status": "NOT VERIFIED", "reason": f"{type(exc).__name__}: {exc}"}
    try:
        total, used, free = shutil.disk_usage(workspace)
        data["disk_free_gb"] = round(free / 2**30, 2)
    except OSError as exc:
        data["disk"] = {"status": "FAILED", "reason": str(exc)}
    data["gpu"] = _gpu_sample()
    return data


class ContinuousHealthMonitor:
    def __init__(self, workspace: str, interval_seconds: float = 2.0, conn=None):
        self.workspace = str(Path(workspace).resolve())
        self.interval = max(0.5, float(interval_seconds))
        self.conn = conn
        self.operation_id: str | None = None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.log_path: str | None = None

    def start(self, operation_dir: str, operation_id: str | None = None) -> str:
        Path(operation_dir).mkdir(parents=True, exist_ok=True)
        self.operation_id = operation_id
        self.log_path = str(Path(operation_dir) / "health.jsonl")
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="aitos-health-monitor", daemon=True)
        self._thread.start()
        return self.log_path

    def stop(self) -> str | None:
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=max(2.0, self.interval + 1))
        return self.log_path

    def _run(self):
        while not self._stop.is_set():
            payload = sample(self.workspace)
            try:
                with open(self.log_path or "health.jsonl", "a", encoding="utf-8") as fh:
                    fh.write(json.dumps(payload, ensure_ascii=False, default=str) + "\n")
                if self.conn is not None:
                    self.conn.execute(
                        "INSERT INTO health_samples (id,operation_id,status,sample_json,created_at) VALUES (?,?,?,?,?)",
                        (utils.new_id("health"), self.operation_id, payload.get("status", "VERIFIED"), json.dumps(payload, ensure_ascii=False, default=str), payload.get("timestamp", utils.now_iso())),
                    )
                    self.conn.commit()
            except (OSError, Exception):
                pass
            self._stop.wait(self.interval)
