"""Real local model export/deployment; connected infrastructure only."""
import os, json, shutil
from . import utils
class DeploymentEngine:
    def __init__(self, conn, audit=None): self.conn=conn; self.audit=audit
    def export(self, model_version_id, output_dir):
        mv=self.conn.execute("SELECT * FROM model_versions WHERE id=?",(model_version_id,)).fetchone()
        if not mv: raise ValueError("model version introuvable")
        mv=dict(mv); path=mv.get("file_path")
        if not path or not os.path.isfile(path): return {"status":"UNAVAILABLE","reason":"Artefact modèle local absent."}
        os.makedirs(output_dir,exist_ok=True); model_dest=os.path.join(output_dir,os.path.basename(path)); shutil.copy2(path,model_dest)
        req=os.path.join(output_dir,"requirements.txt")
        deps=json.loads(mv.get("dependencies_json") or "{}")
        with open(req,"w") as f:
            for k,v in deps.items(): f.write(f"{k}{'=='+v if v and v!='n/a' else ''}\n")
        with open(os.path.join(output_dir,"metadata.json"),"w",encoding="utf-8") as f: json.dump({"status":"REAL","model_version_id":model_version_id,"sha256":utils.sha256_file(model_dest),"configuration":json.loads(mv.get("configuration_json") or "{}")},f,ensure_ascii=False,indent=2)
        with open(os.path.join(output_dir,"README.md"),"w") as f: f.write(f"# Model export\n\nModel version: {model_version_id}\nArtifact: {os.path.basename(model_dest)}\nSHA-256: {utils.sha256_file(model_dest)}\n")
        return {"status":"REAL","output_dir":os.path.abspath(output_dir),"model_path":model_dest,"sha256":utils.sha256_file(model_dest)}
    def deploy_local(self, model_version_id, target_dir):
        gate=self.conn.execute("SELECT * FROM safety_gate_reviews WHERE model_version_id=? ORDER BY created_at DESC LIMIT 1",(model_version_id,)).fetchone()
        if not gate:
            return {"status":"FAILED","operation_status":"BLOCKED","reason":"SAFETY_GATE_REQUIRED — aucune revue Safety Gate validée pour ce modèle."}
        gate=dict(gate)
        if gate.get("final_status")!="APPROVED":
            return {"status":"FAILED","operation_status":"BLOCKED","reason":f"SAFETY_GATE_REQUIRED — statut actuel: {gate.get('final_status')}.","safety_gate_status":gate.get("final_status")}
        result=self.export(model_version_id,target_dir)
        if result["status"]!="REAL": return result
        self.conn.execute("UPDATE model_versions SET status='DEPLOYED' WHERE id=?",(model_version_id,)); self.conn.commit()
        row=self.conn.execute("SELECT * FROM model_versions WHERE id=?",(model_version_id,)).fetchone()
        self.conn.execute("INSERT INTO deployments (id,model_version_id,target,status,metadata_json,created_at) VALUES (?,?,?,?,?,?)",(utils.new_id("deploy"),model_version_id,target_dir,"DEPLOYED",utils.dumps(result),utils.now_iso())); self.conn.commit()
        if self.audit:self.audit.log("system","DEPLOY_LOCAL","model_version",model_version_id,result)
        return {**result,"deployment_status":"DEPLOYED"}
    def unavailable_remote(self, target): return {"status":"UNAVAILABLE","target":target,"reason":"Aucune infrastructure distante connectée; l'export local reste disponible."}
