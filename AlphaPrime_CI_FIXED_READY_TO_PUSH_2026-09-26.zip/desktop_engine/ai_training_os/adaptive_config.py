"""Hardware-aware configuration planner with explicit uncertainty."""
from __future__ import annotations

from typing import Any


def _safe_int(value: Any, default: int) -> int:
    try:
        return max(1, int(value))
    except (TypeError, ValueError):
        return default


class AdaptiveConfigEngine:
    """Produces measured/hardware-aware candidates and can validate resources."""

    def propose(self, profile: dict[str, Any], workload: dict[str, Any] | None = None) -> dict[str, Any]:
        workload = workload or {}
        mem_mb = float(profile.get("memory", {}).get("available_mb", 0) or 0)
        gpu_devices = profile.get("gpu", {}).get("devices", []) or []
        backend = profile.get("training_runtime", {}).get("backend", "CPU")
        vram_mb = float(gpu_devices[0].get("vram_mb") or 0) if gpu_devices else 0
        cores = _safe_int(profile.get("cpu", {}).get("physical_cores") or profile.get("cpu", {}).get("logical_cores"), 1)
        requested_model = str(workload.get("model_type") or "mlp_torch")
        if backend == "CUDA" and vram_mb >= 16000:
            batch = 32
        elif backend in {"CUDA", "MPS"} and vram_mb >= 8000:
            batch = 16
        elif backend in {"CUDA", "MPS"}:
            batch = 4
        elif mem_mb >= 16384:
            batch = 32
        elif mem_mb >= 8192:
            batch = 16
        else:
            batch = 4

        max_length = 1024 if mem_mb >= 16384 else 512 if mem_mb >= 8192 else 256
        gradient_accumulation = 1 if batch >= 16 else 4 if batch >= 4 else 8
        workers = max(1, min(8, cores - 1 if cores > 1 else 1))
        precision = "float16" if backend == "CUDA" else "float32"
        qlora = backend == "CUDA"
        if not qlora:
            qlora = False

        candidate = {
            "device": "cuda" if backend == "CUDA" else "mps" if backend == "MPS" else "cpu",
            "precision": precision,
            "batch_size": batch,
            "gradient_accumulation": gradient_accumulation,
            "context_length": max_length,
            "workers": workers,
            "lora": {
                "method": "qlora" if qlora else "lora",
                "rank": 16 if mem_mb >= 8192 else 8,
                "alpha": 32 if mem_mb >= 8192 else 16,
                "dropout": 0.05,
            },
            "memory": {
                "available_ram_mb": mem_mb,
                "primary_gpu_vram_mb": vram_mb or None,
            },
            "model_type": requested_model,
            "epochs": _safe_int(workload.get("epochs"), 1),
        }
        return {
            "status": "TESTING",
            "basis": "MEASURED_HARDWARE",
            "candidate": candidate,
            "explanation": "Configuration proposée depuis les capacités mesurées; elle n'est pas déclarée VERIFIED tant qu'un canary compatible n'a pas réussi.",
        }

    def validate_candidate(self, candidate: dict[str, Any]) -> dict[str, Any]:
        """Validate parameter coherence and basic local resource allocation."""
        checks = []
        device = str(candidate.get("device", "cpu"))
        batch = _safe_int(candidate.get("batch_size"), 1)
        grad = _safe_int(candidate.get("gradient_accumulation"), 1)
        context = _safe_int(candidate.get("context_length"), 1)
        workers = _safe_int(candidate.get("workers"), 1)
        checks.append({"name": "parameters_positive", "status": "VERIFIED" if batch > 0 and grad > 0 and context > 0 and workers > 0 else "FAILED"})
        if device == "cpu":
            checks.append({"name": "device_resource", "status": "VERIFIED"})
        else:
            try:
                import torch
                if device == "cuda" and not torch.cuda.is_available():
                    raise RuntimeError("CUDA indisponible localement")
                if device == "mps" and not torch.backends.mps.is_available():
                    raise RuntimeError("MPS indisponible localement")
                x = torch.ones((batch, min(context, 64)), device=device)
                ok = bool(torch.isfinite(x).all().item())
                del x
                if device == "cuda":
                    torch.cuda.empty_cache()
                checks.append({"name": "device_allocation", "status": "VERIFIED" if ok else "FAILED", "device": device})
            except Exception as exc:
                checks.append({"name": "device_allocation", "status": "FAILED", "device": device, "reason": f"{type(exc).__name__}: {exc}"})
        status = "VERIFIED" if all(c["status"] == "VERIFIED" for c in checks) else "FAILED"
        return {"status": status, "candidate": candidate, "checks": checks}
