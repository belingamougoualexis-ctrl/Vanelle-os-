from . import utils


class AuditLog:
    def __init__(self, conn):
        self.conn = conn

    def log(self, actor: str, action: str, target_type: str = None, target_id: str = None, details: dict = None):
        self.conn.execute(
            "INSERT INTO audit_log (id, actor, action, target_type, target_id, details_json, created_at) VALUES (?,?,?,?,?,?,?)",
            (utils.new_id("audit"), actor, action, target_type, target_id, utils.dumps(details or {}), utils.now_iso()),
        )
        self.conn.commit()

    def list(self, limit: int = 200):
        rows = self.conn.execute(
            "SELECT * FROM audit_log ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]
