from . import utils


VALID_MODEL_STATUSES = {"DRAFT", "TRAINING", "EVALUATING", "VALIDATED", "DEPLOYED", "ARCHIVED", "FAILED"}


class ModelRegistry:
    def __init__(self, conn, audit=None):
        self.conn = conn
        self.audit = audit

    def create_model(self, project_id: str, name: str, architecture: str) -> str:
        model_id = utils.new_id("model")
        self.conn.execute(
            "INSERT INTO models (id, project_id, name, architecture, created_at) VALUES (?,?,?,?,?)",
            (model_id, project_id, name, architecture, utils.now_iso()),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "CREATE_MODEL", "model", model_id, {"name": name})
        return model_id

    def create_version(self, model_id: str, dataset_version_id: str, config: dict,
                        hyperparameters: dict, hardware: dict, file_path: str = None,
                        status: str = "DRAFT"):
        if status not in VALID_MODEL_STATUSES:
            raise ValueError(f"Statut de modèle invalide: {status}")
        cur = self.conn.execute(
            "SELECT COALESCE(MAX(version_number),0)+1 FROM model_versions WHERE model_id=?",
            (model_id,),
        )
        version_number = cur.fetchone()[0]
        mv_id = utils.new_id("mv")
        sha = utils.sha256_file(file_path) if file_path else None
        self.conn.execute(
            """INSERT INTO model_versions
            (id, model_id, version_number, dataset_version_id, code_version, dependencies_json,
             configuration_json, hyperparameters_json, hardware_json, file_path, sha256,
             metrics_json, status, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (mv_id, model_id, version_number, dataset_version_id, config.get("code_version", "n/a"),
             utils.dumps(config.get("dependencies", {})), utils.dumps(config), utils.dumps(hyperparameters),
             utils.dumps(hardware), file_path, sha, utils.dumps(None), status, utils.now_iso()),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "CREATE_MODEL_VERSION", "model_version", mv_id, {"status": status})
        return mv_id

    def update_status(self, model_version_id: str, status: str, metrics: dict = None):
        if status not in VALID_MODEL_STATUSES:
            raise ValueError(f"Statut de modèle invalide: {status}")
        if metrics is not None:
            self.conn.execute(
                "UPDATE model_versions SET status=?, metrics_json=? WHERE id=?",
                (status, utils.dumps(metrics), model_version_id),
            )
        else:
            self.conn.execute("UPDATE model_versions SET status=? WHERE id=?", (status, model_version_id))
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "MODEL_VERSION_STATUS", "model_version", model_version_id, {"status": status})

    def get_version(self, model_version_id: str):
        row = self.conn.execute("SELECT * FROM model_versions WHERE id=?", (model_version_id,)).fetchone()
        return dict(row) if row else None

    def genome(self, model_version_id: str):
        """Fiche complète permettant de reconstruire l'historique du modèle."""
        mv = self.get_version(model_version_id)
        if not mv:
            return None
        model_row = self.conn.execute("SELECT * FROM models WHERE id=?", (mv["model_id"],)).fetchone()
        checkpoints = self.conn.execute(
            """SELECT c.* FROM checkpoints c
               JOIN jobs j ON c.job_id = j.id
               JOIN experiments e ON j.experiment_id = e.id
               WHERE e.model_version_id = ?""",
            (model_version_id,),
        ).fetchall()
        return {
            "model": dict(model_row) if model_row else None,
            "version": mv,
            "checkpoints": [dict(c) for c in checkpoints],
        }
