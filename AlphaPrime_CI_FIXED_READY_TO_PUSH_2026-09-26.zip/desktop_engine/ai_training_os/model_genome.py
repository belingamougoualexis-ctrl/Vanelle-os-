"""Complete local provenance graph for a model version."""
import json
class ModelGenome:
    def __init__(self, conn, audit=None): self.conn=conn; self.audit=audit
    def build(self, model_version_id):
        mv=self.conn.execute("SELECT * FROM model_versions WHERE id=?",(model_version_id,)).fetchone()
        if not mv: return None
        mv=dict(mv); model=self.conn.execute("SELECT * FROM models WHERE id=?",(mv["model_id"],)).fetchone(); model=dict(model) if model else None
        dataset=self.conn.execute("SELECT * FROM dataset_versions WHERE id=?",(mv["dataset_version_id"],)).fetchone() if mv.get("dataset_version_id") else None
        exps=[dict(r) for r in self.conn.execute("SELECT * FROM experiments WHERE model_version_id=? ORDER BY created_at",(model_version_id,)).fetchall()]
        ck=[dict(r) for r in self.conn.execute("SELECT c.* FROM checkpoints c JOIN jobs j ON c.job_id=j.id WHERE j.experiment_id IN (SELECT id FROM experiments WHERE model_version_id=?) ORDER BY c.epoch",(model_version_id,)).fetchall()]
        ev=[dict(r) for r in self.conn.execute("SELECT * FROM evaluations WHERE model_version_id=? ORDER BY created_at",(model_version_id,)).fetchall()]
        safety=[dict(r) for r in self.conn.execute("SELECT * FROM safety_gate_reviews WHERE model_version_id=? ORDER BY created_at",(model_version_id,)).fetchall()]
        red=[dict(r) for r in self.conn.execute("SELECT * FROM red_team_runs WHERE model_version_id=? ORDER BY created_at",(model_version_id,)).fetchall()]
        deps=[dict(r) for r in self.conn.execute("SELECT * FROM deployments WHERE model_version_id=? ORDER BY created_at",(model_version_id,)).fetchall()]
        arts=[dict(r) for r in self.conn.execute("SELECT * FROM artifacts WHERE metadata_json LIKE ? ORDER BY created_at",(f"%{model_version_id}%",)).fetchall()]
        continuous=[dict(r) for r in self.conn.execute("SELECT * FROM continuous_training_runs WHERE new_model_version_id=? OR base_model_version_id=? ORDER BY created_at",(model_version_id,model_version_id)).fetchall()]
        champion=[dict(r) for r in self.conn.execute("SELECT * FROM champion_challenger WHERE champion_model_version_id=?",(model_version_id,)).fetchall()]
        return {"status":"REAL","model":model,"model_version":mv,"dataset_version":dict(dataset) if dataset else None,"experiments":exps,"checkpoints":ck,"evaluations":ev,"safety_gate_reviews":safety,"red_team_runs":red,"deployments":deps,"artifacts":arts,"continuous_training":continuous,"champion_history":champion}
