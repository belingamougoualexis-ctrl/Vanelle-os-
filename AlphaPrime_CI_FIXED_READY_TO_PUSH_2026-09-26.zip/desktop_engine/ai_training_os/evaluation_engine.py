from . import utils


class EvaluationEngine:
    def __init__(self, conn, audit=None):
        self.conn = conn
        self.audit = audit

    def record(self, model_version_id: str, dataset_version_id: str, metrics: dict, status="COMPLETED"):
        eval_id = utils.new_id("eval")
        self.conn.execute(
            """INSERT INTO evaluations (id, model_version_id, dataset_version_id, metrics_json, status, created_at)
               VALUES (?,?,?,?,?,?)""",
            (eval_id, model_version_id, dataset_version_id, utils.dumps(metrics), status, utils.now_iso()),
        )
        self.conn.commit()
        self.conn.execute("UPDATE model_versions SET status='EVALUATING', metrics_json=? WHERE id=?", (utils.dumps(metrics), model_version_id))
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "EVALUATION_RECORDED", "evaluation", eval_id, metrics)
        return eval_id

    def get(self, eval_id):
        row = self.conn.execute("SELECT * FROM evaluations WHERE id=?", (eval_id,)).fetchone()
        return dict(row) if row else None

    def compare_versions(self, eval_ids: list):
        """Evaluation Matrix — comparaison factuelle, pas de verdict automatique."""
        rows = []
        for eid in eval_ids:
            e = self.get(eid)
            if e:
                rows.append({"evaluation_id": eid, "metrics": utils.loads(e["metrics_json"])})
        return rows


class ErrorMining:
    def __init__(self, conn, audit=None):
        self.conn = conn
        self.audit = audit

    def mine(self, evaluation_id: str, y_true: list, y_pred: list, inputs: list = None):
        """
        Regroupe réellement les erreurs à partir des vraies prédictions/labels
        (aucune erreur inventée). inputs (optionnel) permet un futur regroupement
        sémantique ; ici on regroupe par (vrai_label -> label_prédit).
        """
        clusters = {}
        for i, (yt, yp) in enumerate(zip(y_true, y_pred)):
            if yt == yp:
                continue
            key = f"vrai={yt} -> prédit={yp}"
            clusters.setdefault(key, []).append(i)

        cluster_ids = []
        for label, indices in clusters.items():
            cid = utils.new_id("errc")
            self.conn.execute(
                """INSERT INTO error_clusters (id, evaluation_id, cluster_label, n_examples, example_indices_json, created_at)
                   VALUES (?,?,?,?,?,?)""",
                (cid, evaluation_id, label, len(indices), utils.dumps(indices), utils.now_iso()),
            )
            cluster_ids.append({"id": cid, "label": label, "n_examples": len(indices), "indices": indices})
        self.conn.commit()
        return cluster_ids
