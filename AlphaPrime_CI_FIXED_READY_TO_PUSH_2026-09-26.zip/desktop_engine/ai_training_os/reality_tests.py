"""Reality/verification orchestration for the local-first AI Training OS.

Nothing in this module turns configuration or discovery into a capability claim.
Critical capabilities receive a local test result and an official truth state.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import pickle
import socket
import tempfile
from pathlib import Path
from typing import Any

from .adaptive_config import AdaptiveConfigEngine
from .hardware_reality import scan, verify
from .truth import evidence, state_from_checks


class RealityTestEngine:
    def __init__(self, app):
        self.app = app
        self.workspace = str(Path(app.base_dir).resolve())
        self.profile_path = Path(self.workspace) / "machine_profile.json"
        self.adaptive = AdaptiveConfigEngine()

    def _record_run(self, scope: str, status: str, payload: dict[str, Any]) -> dict[str, Any]:
        run_id = self._new_id("verify")
        self.app.conn.execute(
            "INSERT INTO verification_runs (id,scope,status,evidence_json,created_at) VALUES (?,?,?,?,?)",
            (run_id, scope, status, json.dumps(payload, ensure_ascii=False, default=str), self._now()),
        )
        self.app.conn.commit()
        payload = dict(payload)
        payload["verification_run_id"] = run_id
        return payload

    @staticmethod
    def _new_id(prefix: str) -> str:
        import time
        return f"{prefix}_{time.time_ns():x}"

    @staticmethod
    def _now() -> str:
        from . import utils
        return utils.now_iso()

    def refresh_profile(self) -> dict[str, Any]:
        profile = scan(self.workspace)
        self.profile_path.write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
        pid = hashlib.sha256(profile["fingerprint"].encode()).hexdigest()[:24]
        self.app.conn.execute(
            "INSERT OR REPLACE INTO machine_profiles (id,fingerprint,profile_json,status,captured_at) VALUES (?,?,?,?,?)",
            (pid, profile["fingerprint"], json.dumps(profile, ensure_ascii=False), "VERIFIED", profile["scanned_at"]),
        )
        self.app.conn.commit()
        return {
            "status": "VERIFIED",
            "truth_status": "LOCAL_MEASUREMENT",
            "profile": profile,
            "path": str(self.profile_path),
            "note": "Digital Twin mis à jour à partir de mesures locales; ceci ne constitue pas à lui seul une preuve de toutes les capacités d'exécution.",
        }

    def profile(self) -> dict[str, Any]:
        current = scan(self.workspace)
        stored = None
        try:
            if self.profile_path.exists():
                stored = json.loads(self.profile_path.read_text(encoding="utf-8"))
        except Exception:
            stored = None
        if not stored:
            return {
                "status": "NOT VERIFIED",
                "changed": True,
                "current": current,
                "reason": "Aucun Digital Twin local validé auparavant.",
            }
        changed = current.get("fingerprint") != stored.get("fingerprint")
        return {
            "status": "VERIFIED" if not changed else "TESTING",
            "changed": changed,
            "stored": stored,
            "current": current,
            "reason": "Le fingerprint matériel/environnement a changé; une nouvelle validation est requise." if changed else "Aucun changement de fingerprint détecté.",
        }

    def full_test(self, include_llm: bool = True) -> dict[str, Any]:
        report = verify(self.workspace)
        checks = list(report.get("checks", []))
        from .dependency_manager import matrix
        deps = matrix()
        required_ok = all(v.get("available") for v in deps.get("packages", {}).values() if v.get("required"))
        checks.append({
            "name": "required_dependencies",
            "status": "VERIFIED" if required_ok else "DEGRADED",
            "evidence": evidence("VERIFIED" if required_ok else "DEGRADED", "LOCAL_TEST", "Import réel des dépendances critiques."),
            "packages": deps.get("packages", {}),
        })
        if include_llm:
            llm = self.app.llm_health.preflight()
            llm_state = "VERIFIED" if llm.get("status") == "REAL" else "NOT VERIFIED" if llm.get("status") == "UNAVAILABLE" else "FAILED"
            checks.append({
                "name": "local_llm",
                "status": llm_state,
                "evidence": evidence(llm_state, "LOCAL_TEST", "Preflight du backend LLM local.", {"provider": llm}),
                "details": llm,
            })
        state = state_from_checks([{"status": x.get("status")} for x in checks])
        profile = report.get("profile")
        self.profile_path.write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
        result = {
            "status": state,
            "truth_status": "REAL_LOCAL_TESTS",
            "scope": "FULL_LOCAL",
            "profile": profile,
            "checks": checks,
            "limitations": report.get("limitations", []),
            "official_rule": "VERIFIED signifie qu'une preuve locale réelle a réussi; NOT VERIFIED n'est jamais transformé en succès.",
        }
        return self._record_run("FULL_LOCAL", state, result)

    def auto_configure(self, workload: dict[str, Any] | None = None) -> dict[str, Any]:
        profile = scan(self.workspace)
        proposal = self.adaptive.propose(profile, workload)
        validation = self.adaptive.validate_candidate(proposal["candidate"])
        if validation["status"] == "VERIFIED":
            proposal["status"] = "VERIFIED"
            proposal["candidate_status"] = "RESOURCE_VERIFIED"
            proposal["note"] = "Les ressources demandées ont été testées localement. Une validation modèle/dataset par canary reste nécessaire avant entraînement."
        else:
            proposal["status"] = "FAILED"
        proposal["validation"] = validation
        return proposal

    def validate_dataset_version(self, dataset_version_id: str, tokenizer_path: str | None = None) -> dict[str, Any]:
        dv = self.app.datasets.get_version(dataset_version_id)
        if not dv:
            return self._record_run("DATASET", "FAILED", {"status": "FAILED", "scope": "DATASET", "dataset_version_id": dataset_version_id, "reason": "Version introuvable localement."})
        checks: list[dict[str, Any]] = []
        path = str(dv.get("file_path") or "")
        exists = os.path.isfile(path)
        checks.append({"name": "file_exists", "status": "VERIFIED" if exists else "FAILED", "details": {"path": path}})
        if not exists:
            return self._record_run("DATASET", "FAILED", {"status": "FAILED", "scope": "DATASET", "dataset_version_id": dataset_version_id, "checks": checks})

        from . import utils
        actual_hash = utils.sha256_file(path)
        checks.append({"name": "sha256", "status": "VERIFIED" if actual_hash == dv.get("sha256") else "FAILED", "details": {"expected": dv.get("sha256"), "actual": actual_hash}})

        try:
            raw = Path(path).read_bytes()
            raw.decode("utf-8")
            checks.append({"name": "utf8", "status": "VERIFIED", "details": {"bytes": len(raw)}})
        except UnicodeDecodeError as exc:
            checks.append({"name": "utf8", "status": "FAILED", "details": {"cause": str(exc)}})

        try:
            records, corrupted = self.app.data_engine.load_tabular(path)
            nonempty = len(records) > 0
            checks.append({"name": "parser", "status": "VERIFIED" if nonempty and corrupted == 0 else "DEGRADED" if nonempty else "FAILED", "details": {"rows": len(records), "corrupted": corrupted}})
            if nonempty:
                required_fields = set()
                config = self.app.conn.execute("SELECT split_json FROM dataset_versions WHERE id=?", (dataset_version_id,)).fetchone()
                split = json.loads((config[0] if config else "{}") or "{}")
                n = len(records)
                train = [int(i) for i in split.get("train", [])]
                val = [int(i) for i in split.get("val", [])]
                test = [int(i) for i in split.get("test", [])]
                all_idx = train + val + test
                valid_range = all(0 <= i < n for i in all_idx)
                unique = len(all_idx) == len(set(all_idx))
                checks.append({"name": "split_integrity", "status": "VERIFIED" if valid_range and unique else "FAILED", "details": {"train": len(train), "val": len(val), "test": len(test), "range_ok": valid_range, "disjoint": unique}})
                first_batch = records[: min(8, len(records))]
                batch_ok = isinstance(first_batch, list) and len(first_batch) > 0 and all(isinstance(r, dict) for r in first_batch)
                checks.append({"name": "real_batch", "status": "VERIFIED" if batch_ok else "FAILED", "details": {"batch_size": len(first_batch)}})

                # Generic quality gates: empty rows, duplicate rows and field
                # population are measured from the actual parsed records.
                nonempty_rows = [r for r in records if isinstance(r, dict) and any(v is not None and (not isinstance(v, str) or v.strip()) for v in r.values())]
                duplicate_keys = [json.dumps(r, sort_keys=True, ensure_ascii=False, default=str) for r in records]
                duplicate_count = len(duplicate_keys) - len(set(duplicate_keys))
                fields = sorted({str(k) for r in records if isinstance(r, dict) for k in r.keys()})
                missing_by_field = {f: sum(1 for r in records if not isinstance(r, dict) or r.get(f) is None or (isinstance(r.get(f), str) and not r.get(f).strip())) for f in fields}
                checks.append({"name": "content_quality", "status": "VERIFIED" if len(nonempty_rows) == len(records) else "DEGRADED", "details": {"empty_rows": len(records) - len(nonempty_rows), "duplicate_rows": duplicate_count, "fields": fields, "missing_by_field": missing_by_field}})
                if tokenizer_path:
                    try:
                        from transformers import AutoTokenizer
                        tok = AutoTokenizer.from_pretrained(tokenizer_path, local_files_only=True)
                        text_values = [str(r.get("text", r.get("prompt", r.get("input", "")))) for r in first_batch]
                        text_values = [x for x in text_values if x]
                        if text_values:
                            encoded = tok(text_values, truncation=True, padding=False)
                            token_ok = bool(encoded.get("input_ids"))
                        else:
                            token_ok = False
                        checks.append({"name": "tokenizer", "status": "VERIFIED" if token_ok else "FAILED", "details": {"tokenizer_path": tokenizer_path, "samples": len(text_values)}})
                    except Exception as exc:
                        checks.append({"name": "tokenizer", "status": "FAILED", "details": {"cause": f"{type(exc).__name__}: {exc}", "tokenizer_path": tokenizer_path}})
            else:
                checks.append({"name": "split_integrity", "status": "FAILED", "details": {"reason": "Dataset vide."}})
        except Exception as exc:
            checks.append({"name": "parser", "status": "FAILED", "details": {"cause": f"{type(exc).__name__}: {exc}"}})

        state = state_from_checks(checks)
        result = {"status": state, "scope": "DATASET", "truth_status": "REAL_LOCAL_TESTS", "dataset_version_id": dataset_version_id, "checks": checks}
        return self._record_run("DATASET", state, result)

    def validate_model_version(self, model_version_id: str, run_inference: bool = True) -> dict[str, Any]:
        mv = self.app.models.get_version(model_version_id)
        if not mv:
            return self._record_run("MODEL", "FAILED", {"status": "FAILED", "scope": "MODEL", "model_version_id": model_version_id, "reason": "Version de modèle introuvable localement."})
        checks: list[dict[str, Any]] = []
        path = str(mv.get("file_path") or "")
        exists = os.path.isfile(path)
        checks.append({"name": "artifact_exists", "status": "VERIFIED" if exists else "FAILED", "details": {"path": path}})
        if not exists:
            return self._record_run("MODEL", "FAILED", {"status": "FAILED", "scope": "MODEL", "model_version_id": model_version_id, "checks": checks})
        from . import utils
        actual_hash = utils.sha256_file(path)
        sha_ok = not mv.get("sha256") or actual_hash == mv.get("sha256")
        checks.append({"name": "sha256", "status": "VERIFIED" if sha_ok else "FAILED", "details": {"expected": mv.get("sha256"), "actual": actual_hash}})

        config = utils.loads(mv.get("configuration_json") or "{}")
        hparams = utils.loads(mv.get("hyperparameters_json") or "{}")
        checks.append({"name": "configuration", "status": "VERIFIED" if isinstance(config, dict) and isinstance(hparams, dict) else "FAILED", "details": {"config_keys": sorted(config.keys()) if isinstance(config, dict) else [], "hyperparameters": hparams}})

        # Pickle can execute arbitrary Python during deserialization. It is only
        # eligible for runtime loading when BOTH conditions are proven locally:
        # it lives below the private checkpoints tree AND the registry explicitly
        # records it as a LOCAL_TRAINING artifact with the same hash. Imported or
        # manually registered pickle files therefore stay NOT VERIFIED.
        workspace_path = Path(path).resolve()
        checkpoints_root = (Path(self.workspace) / "checkpoints").resolve()
        trusted_runtime = (
            checkpoints_root in workspace_path.parents
            and config.get("artifact_origin") == "LOCAL_TRAINING"
            and config.get("artifact_sha256") == actual_hash
        )
        loaded = None
        if path.endswith(".pt"):
            try:
                import torch
                state = torch.load(path, map_location="cpu", weights_only=True)
                ok = isinstance(state, dict) and "state_dict" in state
                checks.append({"name": "torch_load", "status": "VERIFIED" if ok else "FAILED", "details": {"keys": sorted(state.keys()) if isinstance(state, dict) else []}})
                loaded = state if ok else None
            except Exception as exc:
                checks.append({"name": "torch_load", "status": "FAILED", "details": {"cause": f"{type(exc).__name__}: {exc}"}})
        elif path.endswith(".pkl") and trusted_runtime:
            try:
                with open(path, "rb") as fh:
                    loaded = pickle.load(fh)
                checks.append({"name": "pickle_load", "status": "VERIFIED", "details": {"class": type(loaded).__name__}})
            except Exception as exc:
                checks.append({"name": "pickle_load", "status": "FAILED", "details": {"cause": f"{type(exc).__name__}: {exc}"}})
        else:
            checks.append({"name": "runtime_loader", "status": "NOT VERIFIED", "details": {"reason": "Aucun chargeur d'exécution local sûr et spécifique n'est associé à cet artefact."}})

        if run_inference and loaded is not None:
            try:
                model_type = str(hparams.get("model_type") or config.get("model_type") or "")
                if path.endswith(".pt") and isinstance(loaded, dict):
                    import torch
                    import torch.nn as nn
                    n_features = int(loaded.get("n_features"))
                    hidden = int(loaded.get("hidden_size", loaded.get("hidden", max(16, n_features * 2))))
                    classes = list(loaded.get("classes") or [])
                    if not classes or n_features <= 0:
                        raise ValueError("Métadonnées torch insuffisantes pour reconstruire le modèle")
                    model = nn.Sequential(nn.Linear(n_features, hidden), nn.ReLU(), nn.Dropout(float(loaded.get("dropout", 0.0))), nn.Linear(hidden, len(classes)))
                    model.load_state_dict(loaded["state_dict"])
                    model.eval()
                    x = torch.zeros((1, n_features), dtype=torch.float32)
                    with torch.no_grad():
                        y = model(x)
                    infer_ok = bool(y.shape[0] == 1 and y.shape[1] == len(classes) and torch.isfinite(y).all())
                    checks.append({"name": "real_inference", "status": "VERIFIED" if infer_ok else "FAILED", "details": {"model_type": model_type, "output_shape": list(y.shape)}})
                elif hasattr(loaded, "predict"):
                    import numpy as np
                    # sklearn estimators expose n_features_in_; text pipelines may expect strings.
                    if hasattr(loaded, "named_steps") and "tfidf" in getattr(loaded, "named_steps", {}):
                        y = loaded.predict(["local verification sample"])
                        input_shape = "text"
                    else:
                        n_features = int(getattr(loaded, "n_features_in_", getattr(loaded, "n_features", 1)))
                        x = np.zeros((1, max(1, n_features)), dtype=np.float32)
                        y = loaded.predict(x)
                        input_shape = [1, max(1, n_features)]
                    infer_ok = len(y) == 1
                    checks.append({"name": "real_inference", "status": "VERIFIED" if infer_ok else "FAILED", "details": {"model_type": model_type, "prediction_count": len(y), "input_shape": input_shape}})
                else:
                    checks.append({"name": "real_inference", "status": "NOT VERIFIED", "details": {"reason": "Artefact chargé mais aucune interface d'inférence locale connue."}})
            except Exception as exc:
                checks.append({"name": "real_inference", "status": "FAILED", "details": {"cause": f"{type(exc).__name__}: {exc}"}})

        if run_inference and loaded is not None:
            # Explicit unload -> reload proof. CPU-only `weights_only=True` is
            # used for torch artifacts; pickle is permitted only for the exact
            # internally-produced, hash-bound checkpoint class above.
            try:
                del loaded
                reloaded = None
                if path.endswith(".pt"):
                    import torch
                    reloaded = torch.load(path, map_location="cpu", weights_only=True)
                    reload_ok = isinstance(reloaded, dict) and "state_dict" in reloaded
                elif path.endswith(".pkl") and trusted_runtime:
                    with open(path, "rb") as fh:
                        reloaded = pickle.load(fh)
                    reload_ok = reloaded is not None
                else:
                    reload_ok = False
                checks.append({"name": "unload_reload", "status": "VERIFIED" if reload_ok else "FAILED", "details": {"path": path}})
            except Exception as exc:
                checks.append({"name": "unload_reload", "status": "FAILED", "details": {"cause": f"{type(exc).__name__}: {exc}"}})

        state = state_from_checks(checks)
        result = {"status": state, "scope": "MODEL", "truth_status": "REAL_LOCAL_TESTS", "model_version_id": model_version_id, "checks": checks}
        return self._record_run("MODEL", state, result)

    def offline_smoke(self) -> dict[str, Any]:
        """Run an actual local Data Engine operation while network sockets are denied."""
        from .data_engine import run_pipeline
        original_connect = socket.socket.connect
        network_attempts: list[str] = []

        def blocked_connect(sock, address):
            network_attempts.append(str(address))
            raise RuntimeError("OFFLINE_TEST_NETWORK_BLOCK")

        with tempfile.TemporaryDirectory(prefix="aitos_offline_test_") as td:
            root = Path(td)
            source = root / "offline.csv"
            source.write_text("x1,x2,label\n1,2,a\n2,1,b\n3,4,a\n4,3,b\n", encoding="utf-8")
            try:
                socket.socket.connect = blocked_connect
                out = run_pipeline(str(source), str(root / "storage"), "offline", 1)
            finally:
                socket.socket.connect = original_connect
            ok = out.get("n_rows") == 4 and not network_attempts
            result = {
                "status": "VERIFIED" if ok else "FAILED",
                "scope": "SIMULATED (TEST)",
                "truth_status": "REAL_LOCAL_TEST",
                "network": "blocked during test",
                "network_attempts": network_attempts,
                "dataset_rows": out.get("n_rows"),
                "version_path": out.get("version_path"),
            }
        return self._record_run("OFFLINE", result["status"], result)

    def latest_runs(self, limit: int = 50) -> list[dict[str, Any]]:
        rows = self.app.conn.execute(
            "SELECT id,scope,status,evidence_json,created_at FROM verification_runs ORDER BY created_at DESC LIMIT ?",
            (int(max(1, min(200, limit))),),
        ).fetchall()
        out = []
        for row in rows:
            item = dict(row)
            try:
                item["evidence"] = json.loads(item.pop("evidence_json") or "{}")
            except Exception:
                item["evidence"] = {}
            out.append(item)
        return out
