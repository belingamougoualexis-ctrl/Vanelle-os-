from .local_cpu import LocalCPUProvider
from .local_gpu import LocalGPUProvider
from .local_multi_gpu import LocalMultiGPUProvider
from .local_distributed import LocalDistributedProvider
from .base import UnavailableProvider

PROVIDER_REGISTRY = {
    "LOCAL_CPU_PROVIDER": LocalCPUProvider(),
    # Réellement adaptatifs : is_available() revérifie le matériel de LA
    # machine locale à chaque appel. Pas de stub figé — sur une machine
    # utilisateur avec GPU + PyTorch, ces deux providers s'activent seuls.
    "LOCAL_GPU_PROVIDER": LocalGPUProvider(),
    "LOCAL_MULTI_GPU_PROVIDER": LocalMultiGPUProvider(),
    # Distribué mais 100% local : d'autres coeurs CPU de cette machine et/ou
    # d'autres machines du réseau local de l'utilisateur (config["nodes"]),
    # jamais un service tiers. is_available() ne ment jamais sur le nombre
    # réel de coeurs disponibles ; les noeuds LAN sont pingés réellement au
    # moment de l'entraînement (voir LocalDistributedProvider.probe_nodes).
    "LOCAL_DISTRIBUTED_PROVIDER": LocalDistributedProvider(),
    "REMOTE_GPU_PROVIDER": UnavailableProvider(
        "REMOTE_GPU_PROVIDER",
        "Aucun accès réseau sortant dans cet environnement. "
        "Nécessite la configuration d'un endpoint distant (host, clé API, credentials).",
    ),
    "CLOUD_PROVIDER": UnavailableProvider(
        "CLOUD_PROVIDER",
        "Nécessite des identifiants cloud (AWS/GCP/Azure) et un accès réseau sortant, absents ici.",
    ),
}


def get_provider(name: str):
    if name not in PROVIDER_REGISTRY:
        raise KeyError(f"Provider inconnu: {name}")
    return PROVIDER_REGISTRY[name]


def list_providers():
    return {name: p.is_available() for name, p in PROVIDER_REGISTRY.items()}
