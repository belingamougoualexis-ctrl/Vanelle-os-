"""Real local GPU training provider for CUDA or Apple MPS."""
import os
import time
from .base import TrainingProvider
from .local_cpu import TrainingInterrupted
from .. import utils, compute


class LocalGPUProvider(TrainingProvider):
    name = "LOCAL_GPU_PROVIDER"

    def is_available(self) -> dict:
        backend = compute.detect_torch_backend()
        if backend["status"] != "REAL":
            return {"available": False, "reason": backend.get("reason", "GPU non disponible.")}
        return {"available": True, "reason": f"Backend {backend['backend']} détecté ({backend['n_devices']} device(s): {backend.get('device_names')})."}

    @staticmethod
    def _model(n_features, hidden_size, n_classes, dropout=0.0):
        import torch.nn as nn
        return nn.Sequential(
            nn.Linear(n_features, hidden_size), nn.ReLU(),
            nn.Dropout(float(dropout)), nn.Linear(hidden_size, n_classes)
        )

    def train(self, config: dict, checkpoint_cb=None) -> dict:
        if config.get("model_type", "mlp_torch") != "mlp_torch":
            raise RuntimeError("Ce provider GPU local prend en charge uniquement model_type=mlp_torch.")
        avail = self.is_available()
        if not avail["available"]:
            raise RuntimeError(f"LOCAL_GPU_PROVIDER UNAVAILABLE — DEPENDENCY REQUIRED: {avail['reason']}")

        import numpy as np
        import torch
        from sklearn.preprocessing import LabelEncoder
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

        backend = compute.detect_torch_backend()
        device = torch.device(backend["backend"])
        X_train = torch.tensor(np.asarray(config["X_train"], dtype=np.float32), device=device)
        X_val = torch.tensor(np.asarray(config["X_val"], dtype=np.float32), device=device)
        raw_train = np.asarray(config["y_train"], dtype=str)
        raw_val = np.asarray(config["y_val"], dtype=str)
        enc = LabelEncoder()
        resume_from = config.get("resume_from")
        start_epoch = int(config.get("start_epoch", 0))
        n_epochs = int(config.get("n_epochs", 10))
        checkpoint_dir = config.get("checkpoint_dir")
        if checkpoint_dir: os.makedirs(checkpoint_dir, exist_ok=True)

        if resume_from:
            checkpoint = torch.load(resume_from, map_location="cpu", weights_only=True)
            enc.classes_ = np.asarray(checkpoint["classes"], dtype=str)
            y_train_np = enc.transform(raw_train); y_val_np = enc.transform(raw_val)
            n_features = int(checkpoint["n_features"]); hidden_size = int(checkpoint["hidden_size"])
            dropout = float(checkpoint.get("dropout", config.get("dropout", 0.0)))
            model = self._model(n_features, hidden_size, len(enc.classes_), dropout).to(device)
            model.load_state_dict(checkpoint["state_dict"])
            optimizer = torch.optim.Adam(model.parameters(), lr=float(config.get("learning_rate", 1e-2)))
            if checkpoint.get("optimizer"):
                optimizer.load_state_dict(checkpoint["optimizer"])
            start_epoch = max(start_epoch, int(checkpoint.get("epoch", start_epoch)))
        else:
            y_train_np = enc.fit_transform(raw_train); y_val_np = enc.transform(raw_val)
            n_features = int(X_train.shape[1]); hidden_size = int(config.get("hidden_size", 32)); dropout = float(config.get("dropout", 0.0))
            model = self._model(n_features, hidden_size, len(enc.classes_), dropout).to(device)
            optimizer = torch.optim.Adam(model.parameters(), lr=float(config.get("learning_rate", 1e-2)))

        y_train = torch.tensor(y_train_np, dtype=torch.long, device=device)
        loss_fn = torch.nn.CrossEntropyLoss()
        use_amp = bool(config.get("mixed_precision", False)) and backend["backend"] == "cuda"
        scaler = torch.amp.GradScaler("cuda", enabled=use_amp) if backend["backend"] == "cuda" else None
        t0 = time.time(); checkpoints=[]; last_metrics=None; final_pred=None
        for epoch in range(start_epoch+1, n_epochs+1):
            model.train(); optimizer.zero_grad()
            if use_amp:
                with torch.autocast(device_type="cuda", dtype=torch.float16): out=model(X_train); loss=loss_fn(out,y_train)
                scaler.scale(loss).backward(); scaler.step(optimizer); scaler.update()
            else:
                out=model(X_train); loss=loss_fn(out,y_train); loss.backward(); optimizer.step()
            model.eval()
            with torch.no_grad(): val_pred=model(X_val).argmax(dim=1).detach().cpu().numpy()
            pred_labels=enc.inverse_transform(val_pred); true_labels=enc.inverse_transform(y_val_np)
            last_metrics={"loss":float(loss.detach().cpu()),"accuracy":float(accuracy_score(true_labels,pred_labels)),"precision_macro":float(precision_score(true_labels,pred_labels,average="macro",zero_division=0)),"recall_macro":float(recall_score(true_labels,pred_labels,average="macro",zero_division=0)),"f1_macro":float(f1_score(true_labels,pred_labels,average="macro",zero_division=0)),"device":str(device)}
            if checkpoint_dir:
                path=os.path.join(checkpoint_dir,f"epoch_{epoch}.pt")
                torch.save({"state_dict":model.state_dict(),"optimizer":optimizer.state_dict(),"classes":enc.classes_.tolist(),"n_features":n_features,"hidden_size":hidden_size,"dropout":dropout,"epoch":epoch,"backend":backend["backend"]},path)
                h=utils.sha256_file(path); checkpoints.append({"epoch":epoch,"path":path,"sha256":h,"metrics":last_metrics})
                if checkpoint_cb: checkpoint_cb(epoch,{"path":path,"sha256":h,"metrics":last_metrics,"progress":epoch/max(1,n_epochs)})
            final_pred=pred_labels
            if config.get("stop_after_epoch") and epoch>=int(config["stop_after_epoch"]): raise TrainingInterrupted(f"Interrupted after real checkpoint epoch {epoch}")

        if last_metrics is None:
            model.eval();
            with torch.no_grad(): val_pred=model(X_val).argmax(dim=1).detach().cpu().numpy()
            final_pred=enc.inverse_transform(val_pred); true_labels=enc.inverse_transform(y_val_np)
            last_metrics={"accuracy":float(accuracy_score(true_labels,final_pred)),"precision_macro":float(precision_score(true_labels,final_pred,average="macro",zero_division=0)),"recall_macro":float(recall_score(true_labels,final_pred,average="macro",zero_division=0)),"f1_macro":float(f1_score(true_labels,final_pred,average="macro",zero_division=0)),"device":str(device)}
        final_model_path=None; final_hash=None
        if checkpoint_dir:
            final_model_path=os.path.join(checkpoint_dir,"final_model.pt")
            torch.save({"state_dict":model.state_dict(),"classes":enc.classes_.tolist(),"n_features":n_features,"hidden_size":hidden_size,"dropout":dropout,"backend":backend["backend"]},final_model_path)
            final_hash=utils.sha256_file(final_model_path)
        return {"status":"REAL","provider":self.name,"duration_seconds":time.time()-t0,"metrics":last_metrics,"checkpoints":checkpoints,"final_model_path":final_model_path,"final_model_sha256":final_hash,"predictions":final_pred.tolist(),"y_val":enc.inverse_transform(y_val_np).tolist(),"model_format":"torch_state_dict","device":str(device)}
