"""Real local CPU training provider.

Supports classic tabular models plus genuinely local text/PDF/image/audio/video
classification using deterministic feature extraction. No remote model or
pretrained asset is required for these CPU pipelines.
"""
import os
import pickle
import time

from .base import TrainingProvider
from .. import utils


class TrainingInterrupted(RuntimeError):
    pass




class TorchMLPClassifier:
    """Pickle-safe sklearn-like wrapper around a locally trained Torch MLP."""
    def __init__(self, state_dict, classes, n_features, hidden, dropout=0.0):
        self.state_dict = state_dict
        self.classes = list(classes)
        self.n_features = int(n_features)
        self.hidden = int(hidden)
        self.dropout = float(dropout)

    def _model(self):
        import torch
        import torch.nn as nn
        model = nn.Sequential(nn.Linear(self.n_features, self.hidden), nn.ReLU(), nn.Dropout(self.dropout), nn.Linear(self.hidden, len(self.classes)))
        model.load_state_dict(self.state_dict)
        model.eval()
        return model

    def predict(self, X):
        import numpy as np
        import torch
        arr=np.asarray(X,dtype=np.float32)
        with torch.no_grad():
            idx=self._model()(torch.tensor(arr)).argmax(dim=1).cpu().numpy()
        return np.asarray([self.classes[int(i)] for i in idx])


class LocalCPUProvider(TrainingProvider):
    name = "LOCAL_CPU_PROVIDER"

    def is_available(self):
        try:
            import sklearn  # noqa: F401
            return {"available": True, "reason": "scikit-learn détecté, entraînement CPU local possible."}
        except ImportError:
            return {"available": False, "reason": "scikit-learn absent."}

    def _save(self, model, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump(model, f, protocol=pickle.HIGHEST_PROTOCOL)
        return utils.sha256_file(path)

    @staticmethod
    def _metrics_classification(y_true, pred):
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
        return {
            "accuracy": float(accuracy_score(y_true, pred)),
            "precision_macro": float(precision_score(y_true, pred, average="macro", zero_division=0)),
            "recall_macro": float(recall_score(y_true, pred, average="macro", zero_division=0)),
            "f1_macro": float(f1_score(y_true, pred, average="macro", zero_division=0)),
        }

    @staticmethod
    def _asset_paths(config, indices_key):
        root = os.path.abspath(config["asset_root"])
        rels = config.get(indices_key, [])
        return [os.path.join(root, rel) if not os.path.isabs(rel) else rel for rel in rels]

    def _specialized_data(self, config, train_indices, val_indices):
        modality = config.get("modality")
        from ..feature_engine import features_for_paths
        train_paths = self._asset_paths(config, "asset_train_paths")
        val_paths = self._asset_paths(config, "asset_val_paths")
        if not train_paths or not val_paths:
            raise ValueError("Aucun artefact local exploitable pour le dataset spécialisé.")
        y_train = list(config.get("asset_y_train", []))
        y_val = list(config.get("asset_y_val", []))
        if len(train_paths) != len(y_train) or len(val_paths) != len(y_val):
            raise ValueError("Nombre de fichiers et labels incohérent.")
        if modality in {"text", "pdf"}:
            from sklearn.pipeline import Pipeline
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.linear_model import LogisticRegression
            model = Pipeline([
                ("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=1, sublinear_tf=True)),
                ("classifier", LogisticRegression(max_iter=int(config.get("max_iter", 1000)))),
            ])
            X_train = features_for_paths(train_paths, modality)
            X_val = features_for_paths(val_paths, modality)
            return model, X_train, y_train, X_val, y_val

        X_train = features_for_paths(train_paths, modality)
        X_val = features_for_paths(val_paths, modality)
        return None, X_train, y_train, X_val, y_val

    def _train_mlp(self, config, checkpoint_cb=None):
        import numpy as np
        import torch
        import torch.nn as nn
        from sklearn.preprocessing import LabelEncoder

        X_train = torch.tensor(np.asarray(config.get("X_train", []), dtype=np.float32))
        X_val = torch.tensor(np.asarray(config.get("X_val", []), dtype=np.float32))
        if X_train.ndim != 2 or X_train.shape[0] == 0:
            raise ValueError("X_train vide ou non matriciel pour mlp_torch.")
        enc = LabelEncoder()
        raw_train = np.asarray(config.get("y_train", []), dtype=str)
        raw_val = np.asarray(config.get("y_val", []), dtype=str)
        resume_from = config.get("resume_from")
        checkpoint_dir = config.get("checkpoint_dir")
        if checkpoint_dir:
            os.makedirs(checkpoint_dir, exist_ok=True)

        torch.set_num_threads(max(1, int(config.get("torch_num_threads", min(4, os.cpu_count() or 1)))))
        device = torch.device("cpu")
        start_epoch = int(config.get("start_epoch", 0))
        n_epochs = int(config.get("n_epochs", 5))

        if resume_from:
            if not os.path.isfile(resume_from):
                raise FileNotFoundError(resume_from)
            checkpoint = torch.load(resume_from, map_location=device, weights_only=True)
            classes = np.asarray(checkpoint.get("classes", []), dtype=str)
            if classes.size < 2:
                raise ValueError("Checkpoint MLP invalide: classes absentes.")
            enc.classes_ = classes
            y_train_np = enc.transform(raw_train)
            y_val_np = enc.transform(raw_val)
            n_features = int(checkpoint["n_features"])
            hidden = int(checkpoint["hidden"])
            dropout = float(checkpoint.get("dropout", config.get("dropout", 0.0)))
            model = nn.Sequential(
                nn.Linear(n_features, hidden), nn.ReLU(), nn.Dropout(dropout),
                nn.Linear(hidden, len(enc.classes_))
            ).to(device)
            model.load_state_dict(checkpoint["state_dict"])
            optimizer = torch.optim.AdamW(model.parameters(), lr=float(config.get("learning_rate", 1e-3)))
            if checkpoint.get("optimizer"):
                optimizer.load_state_dict(checkpoint["optimizer"])
            start_epoch = max(start_epoch, int(checkpoint.get("epoch", start_epoch)))
        else:
            y_train_np = enc.fit_transform(raw_train)
            y_val_np = enc.transform(raw_val)
            n_features = int(X_train.shape[1]); n_classes = int(len(enc.classes_))
            hidden = int(config.get("hidden_size", min(128, max(16, n_features * 2))))
            dropout = float(config.get("dropout", 0.0))
            model = nn.Sequential(
                nn.Linear(n_features, hidden), nn.ReLU(), nn.Dropout(dropout),
                nn.Linear(hidden, n_classes)
            ).to(device)
            optimizer = torch.optim.AdamW(model.parameters(), lr=float(config.get("learning_rate", 1e-3)))

        y_train = torch.tensor(y_train_np, dtype=torch.long, device=device)
        X_train, X_val = X_train.to(device), X_val.to(device)
        loss_fn = nn.CrossEntropyLoss()
        t0 = time.time(); checkpoints=[]; last_metrics=None; final_pred=None

        for epoch in range(start_epoch + 1, n_epochs + 1):
            model.train(); optimizer.zero_grad()
            logits = model(X_train); loss = loss_fn(logits, y_train); loss.backward(); optimizer.step()
            model.eval()
            with torch.no_grad():
                pred_idx = model(X_val).argmax(dim=1).cpu().numpy()
            pred_labels = enc.inverse_transform(pred_idx)
            last_metrics = {"loss": float(loss.detach().cpu()), **self._metrics_classification(enc.inverse_transform(y_val_np), pred_labels)}
            path = os.path.join(checkpoint_dir, f"epoch_{epoch}.pt") if checkpoint_dir else None
            if path:
                torch.save({
                    "state_dict": model.state_dict(), "optimizer": optimizer.state_dict(),
                    "classes": enc.classes_.tolist(), "n_features": n_features,
                    "hidden": hidden, "dropout": dropout, "epoch": epoch,
                }, path)
                h = utils.sha256_file(path)
                checkpoints.append({"epoch": epoch, "path": path, "sha256": h, "metrics": last_metrics})
                if checkpoint_cb:
                    checkpoint_cb(epoch, {"path": path, "sha256": h, "metrics": last_metrics, "progress": epoch / max(1, n_epochs)})
            final_pred = pred_labels
            if config.get("stop_after_epoch") and epoch >= int(config["stop_after_epoch"]):
                raise TrainingInterrupted(f"Interrupted after real checkpoint epoch {epoch}")

        if last_metrics is None:
            # A resume request can legally point at the final requested epoch;
            # still return the actual model/checkpoint state without fabricating a new metric.
            model.eval()
            with torch.no_grad():
                pred_idx = model(X_val).argmax(dim=1).cpu().numpy()
            final_pred = enc.inverse_transform(pred_idx)
            last_metrics = self._metrics_classification(enc.inverse_transform(y_val_np), final_pred)
        final_path=os.path.join(checkpoint_dir,"final_model.pkl") if checkpoint_dir else None
        wrapper=TorchMLPClassifier(model.state_dict(), enc.classes_.tolist(), n_features, hidden, dropout)
        final_hash=self._save(wrapper, final_path) if final_path else None
        return {"status":"REAL","provider":self.name,"duration_seconds":time.time()-t0,"metrics":last_metrics,"checkpoints":checkpoints,"final_model_path":final_path,"final_model_sha256":final_hash,"predictions":final_pred.tolist() if final_pred is not None else [],"y_val":enc.inverse_transform(y_val_np).tolist(),"model_format":"torch_mlp_pickle","labels":enc.classes_.tolist()}

    def train(self, config, checkpoint_cb=None):
        import numpy as np
        from sklearn.linear_model import LogisticRegression, SGDClassifier, LinearRegression, SGDRegressor
        from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
        from sklearn.cluster import KMeans
        from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, silhouette_score

        task=config.get("task_type", "classification")
        model_type=config.get("model_type", "logistic_regression")
        if model_type == "mlp_torch":
            return self._train_mlp(config, checkpoint_cb)
        if model_type == "mlp_sklearn":
            from sklearn.neural_network import MLPClassifier
            X_train=np.asarray(config.get("X_train",[]),dtype=float); X_val=np.asarray(config.get("X_val",[]),dtype=float)
            y_train=np.asarray(config.get("y_train",[])); y_val=np.asarray(config.get("y_val",[]))
            if X_train.ndim!=2 or X_train.shape[0]==0: raise ValueError("X_train vide ou non matriciel pour mlp_sklearn.")
            checkpoint_dir=config.get("checkpoint_dir"); checkpoints=[]
            if checkpoint_dir: os.makedirs(checkpoint_dir,exist_ok=True)
            resume_from=config.get("resume_from"); start_epoch=int(config.get("start_epoch",0)); n_epochs=int(config.get("n_epochs",20))
            if resume_from:
                if not os.path.isfile(resume_from): raise FileNotFoundError(resume_from)
                with open(resume_from,"rb") as f: model=pickle.load(f)
                classes=np.asarray(getattr(model,"classes_",np.unique(y_train)))
            else:
                classes=np.unique(y_train)
                model=MLPClassifier(hidden_layer_sizes=(int(config.get("hidden_size",64)),),activation="relu",solver="adam",learning_rate_init=float(config.get("learning_rate",1e-3)),max_iter=1,random_state=42,shuffle=True)
            t0=time.time(); last_metrics=None
            for epoch in range(start_epoch+1,n_epochs+1):
                model.partial_fit(X_train,y_train,classes=classes)
                pred=model.predict(X_val); last_metrics=self._metrics_classification(y_val,pred)
                path=os.path.join(checkpoint_dir,f"epoch_{epoch}.pkl") if checkpoint_dir else None
                if path:
                    h=self._save(model,path); checkpoints.append({"epoch":epoch,"path":path,"sha256":h,"metrics":last_metrics})
                    if checkpoint_cb: checkpoint_cb(epoch,{"path":path,"sha256":h,"metrics":last_metrics,"progress":epoch/max(1,n_epochs)})
                if config.get("stop_after_epoch") and epoch>=int(config["stop_after_epoch"]): raise TrainingInterrupted(f"Interrupted after real checkpoint epoch {epoch}")
            if last_metrics is None:
                pred=model.predict(X_val); last_metrics=self._metrics_classification(y_val,pred)
            final=os.path.join(checkpoint_dir,"final_model.pkl") if checkpoint_dir else None; final_hash=self._save(model,final) if final else None
            return {"status":"REAL","provider":self.name,"duration_seconds":time.time()-t0,"metrics":last_metrics,"checkpoints":checkpoints,"final_model_path":final,"final_model_sha256":final_hash,"predictions":pred.tolist(),"y_val":y_val.tolist(),"model_format":"sklearn_mlp_pickle","modality":"tabular"}

        t0=time.time(); checkpoint_dir=config.get("checkpoint_dir")
        if checkpoint_dir: os.makedirs(checkpoint_dir,exist_ok=True)

        if model_type in {"text_tfidf","pdf_tfidf","image_pixel_logreg","audio_spectral_logreg","video_frame_stats_logreg"}:
            modality = config.get("modality")
            expected = {"text_tfidf":"text","pdf_tfidf":"pdf","image_pixel_logreg":"image","audio_spectral_logreg":"audio","video_frame_stats_logreg":"video"}[model_type]
            if modality != expected:
                raise ValueError(f"{model_type} attend la modalité {expected}; reçu {modality}")
            pipeline_model, X_train, y_train, X_val, y_val = self._specialized_data(config, [], [])
            if pipeline_model is None:
                mapping={"image_pixel_logreg":"logistic_regression","audio_spectral_logreg":"logistic_regression","video_frame_stats_logreg":"logistic_regression"}
                model=LogisticRegression(max_iter=int(config.get("max_iter",1000)))
                model.fit(np.asarray(X_train,dtype=float),y_train)
                pred=model.predict(np.asarray(X_val,dtype=float))
            else:
                model=pipeline_model; model.fit(X_train,y_train); pred=model.predict(X_val)
            metrics=self._metrics_classification(y_val,pred); checkpoints=[]
            if checkpoint_dir:
                p=os.path.join(checkpoint_dir,"epoch_1.pkl"); h=self._save(model,p); checkpoints.append({"epoch":1,"path":p,"sha256":h,"metrics":metrics})
                if checkpoint_cb: checkpoint_cb(1,{"path":p,"sha256":h,"metrics":metrics,"progress":1.0})
            final=os.path.join(checkpoint_dir,"final_model.pkl") if checkpoint_dir else None; final_hash=self._save(model,final) if final else None
            return {"status":"REAL","provider":self.name,"duration_seconds":time.time()-t0,"metrics":metrics,"checkpoints":checkpoints,"final_model_path":final,"final_model_sha256":final_hash,"predictions":pred.tolist(),"y_val":list(y_val),"modality":modality,"model_format":"pickle"}

        X_train=np.asarray(config.get("X_train",[]),dtype=float); X_val=np.asarray(config.get("X_val",[]),dtype=float); y_train=np.asarray(config.get("y_train",[])); y_val=np.asarray(config.get("y_val",[]))
        if X_train.ndim != 2 or X_train.shape[0] == 0: raise ValueError("X_train vide ou non matriciel.")
        checkpoints=[]; start_epoch=int(config.get("start_epoch",0))+1; n_epochs=int(config.get("n_epochs",5 if model_type in ("sgd_incremental","sgd_regressor") else 1))
        resume_from=config.get("resume_from")

        if task=="classification":
            classes=np.unique(y_train)
            if resume_from and model_type=="sgd_incremental" and os.path.isfile(resume_from):
                with open(resume_from,"rb") as f:model=pickle.load(f)
            elif model_type=="sgd_incremental": model=SGDClassifier(loss="log_loss",random_state=42)
            elif model_type=="random_forest": model=RandomForestClassifier(n_estimators=int(config.get("n_estimators",100)),random_state=42,n_jobs=max(1,(os.cpu_count() or 1)-1))
            else: model=LogisticRegression(max_iter=int(config.get("max_iter",1000)))
            if model_type=="sgd_incremental":
                for epoch in range(start_epoch,n_epochs+1):
                    model.partial_fit(X_train,y_train,classes=classes); pred=model.predict(X_val); m=self._metrics_classification(y_val,pred)
                    path=os.path.join(checkpoint_dir,f"epoch_{epoch}.pkl") if checkpoint_dir else None; h=self._save(model,path) if path else None
                    if path: checkpoints.append({"epoch":epoch,"path":path,"sha256":h,"metrics":m})
                    if checkpoint_cb: checkpoint_cb(epoch,{"path":path,"sha256":h if path else None,"metrics":m,"progress":epoch/max(1,n_epochs)})
                    if config.get("stop_after_epoch") and epoch>=int(config["stop_after_epoch"]): raise TrainingInterrupted(f"Interrupted after real checkpoint epoch {epoch}")
            else:
                if resume_from: raise RuntimeError(f"Reprise indisponible pour model_type={model_type}; utilisez sgd_incremental ou mlp_torch.")
                model.fit(X_train,y_train); pred=model.predict(X_val); m=self._metrics_classification(y_val,pred)
                path=os.path.join(checkpoint_dir,"epoch_1.pkl") if checkpoint_dir else None; h=self._save(model,path) if path else None
                if path: checkpoints.append({"epoch":1,"path":path,"sha256":h,"metrics":m})
                if checkpoint_cb and path: checkpoint_cb(1,{"path":path,"sha256":h,"metrics":m,"progress":1.0})
            pred=model.predict(X_val); metrics=self._metrics_classification(y_val,pred)
        elif task=="regression":
            if resume_from: raise RuntimeError("Reprise locale de regression non disponible pour le provider actuel.")
            if model_type=="random_forest_regressor": model=RandomForestRegressor(n_estimators=int(config.get("n_estimators",100)),random_state=42,n_jobs=max(1,(os.cpu_count() or 1)-1))
            elif model_type=="sgd_regressor": model=SGDRegressor(random_state=42,max_iter=int(config.get("max_iter",1000)))
            else: model=LinearRegression()
            model.fit(X_train,y_train); pred=model.predict(X_val); metrics={"mae":float(mean_absolute_error(y_val,pred)),"rmse":float(mean_squared_error(y_val,pred)**0.5),"r2":float(r2_score(y_val,pred))}
            path=os.path.join(checkpoint_dir,"epoch_1.pkl") if checkpoint_dir else None; h=self._save(model,path) if path else None
            if path: checkpoints.append({"epoch":1,"path":path,"sha256":h,"metrics":metrics})
            if checkpoint_cb and path: checkpoint_cb(1,{"path":path,"sha256":h,"metrics":metrics,"progress":1.0})
        elif task=="clustering":
            if resume_from: raise RuntimeError("Reprise locale du clustering non disponible pour le provider actuel.")
            k=int(config.get("n_clusters",2)); model=KMeans(n_clusters=k,random_state=42,n_init="auto"); model.fit(X_train); pred=model.predict(X_val); metrics={"silhouette_score":float(silhouette_score(X_val,pred)) if len(set(pred))>1 and len(pred)>len(set(pred)) else None}
            path=os.path.join(checkpoint_dir,"epoch_1.pkl") if checkpoint_dir else None; h=self._save(model,path) if path else None
            if path: checkpoints.append({"epoch":1,"path":path,"sha256":h,"metrics":metrics})
            if checkpoint_cb and path: checkpoint_cb(1,{"path":path,"sha256":h,"metrics":metrics,"progress":1.0})
        else:
            raise ValueError(f"task_type non supporte localement: {task}")

        final=os.path.join(checkpoint_dir,"final_model.pkl") if checkpoint_dir else None; final_hash=self._save(model,final) if final else None
        return {"status":"REAL","provider":self.name,"duration_seconds":time.time()-t0,"metrics":metrics,"checkpoints":checkpoints,"final_model_path":final,"final_model_sha256":final_hash,"predictions":pred.tolist(),"y_val":y_val.tolist(),"model_format":"pickle"}
