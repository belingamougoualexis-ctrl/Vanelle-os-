"""
base.py — Interface stable des Training/Compute Providers.

Tout nouveau provider (GPU distant, cluster, cloud) doit implémenter
cette interface pour être interchangeable, sans toucher au reste du
système (Training Engine, frontend, Job Engine).
"""
from abc import ABC, abstractmethod


class TrainingProvider(ABC):
    name: str = "BASE"

    @abstractmethod
    def is_available(self) -> dict:
        """Retourne {'available': bool, 'reason': str}. Jamais inventé."""
        raise NotImplementedError

    @abstractmethod
    def train(self, config: dict, checkpoint_cb=None) -> dict:
        """
        Exécute réellement un entraînement (ou lève NotImplementedError /
        RuntimeError si l'infrastructure n'est pas connectée).
        checkpoint_cb(epoch:int, state:dict) est appelé après chaque epoch réelle.
        Retourne un dict avec métriques RÉELLEMENT mesurées.
        """
        raise NotImplementedError


class UnavailableProvider(TrainingProvider):
    """Provider honnête : ne simule jamais, déclare l'infra manquante."""

    def __init__(self, name: str, reason: str):
        self.name = name
        self.reason = reason

    def is_available(self) -> dict:
        return {"available": False, "reason": self.reason}

    def train(self, config: dict, checkpoint_cb=None) -> dict:
        raise RuntimeError(
            f"Provider '{self.name}' UNAVAILABLE — DEPENDENCY REQUIRED: {self.reason}"
        )
