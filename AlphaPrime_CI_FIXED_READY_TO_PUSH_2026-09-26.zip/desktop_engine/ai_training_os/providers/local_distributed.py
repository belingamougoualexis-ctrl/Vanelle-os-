"""
local_distributed.py — Provider d'entraînement distribué 100% local.

Objectif : permettre de faire monter en charge l'entraînement (jusqu'à des
volumes de données massifs, "à la échelle d'un géant") en répartissant le
travail sur plusieurs WORKERS qui vivent entièrement chez l'utilisateur :
soit d'autres coeurs CPU de LA machine actuelle, soit d'autres machines de
SON PROPRE réseau local (LAN). Aucun accès Internet, aucun compte cloud,
aucune clé API externe n'est utilisé ni requis.

Deux sources de workers, toutes deux réellement vérifiées, jamais fabriquées :

  1. Workers "processus locaux" : des processus réels lancés automatiquement
     sur les coeurs CPU de CETTE machine — seulement si >=2 coeurs réels sont
     détectés (même règle d'honnêteté que LOCAL_MULTI_GPU_PROVIDER pour les
     GPU : jamais activé sur une machine qui n'a pas le matériel).

  2. Noeuds LAN : d'autres machines du réseau local de l'utilisateur, sur
     lesquelles il a lui-même lancé ce service worker au préalable (voir
     local_distributed_worker.py). Fournis explicitement via
     config["nodes"] = ["192.168.1.12:9500", ...]. Chaque noeud est
     réellement "pingé" en TCP avant d'être utilisé ; un noeud injoignable
     est rapporté comme tel, jamais présenté comme disponible.

Les deux types de workers utilisent exactement le même protocole réseau
(TCP local, JSON, longueur préfixée) — qu'il s'agisse d'un processus sur
127.0.0.1 ou d'une machine sur le réseau de l'entreprise. C'est ce qui rend
le système réellement extensible à un grand nombre de machines LAN sans
changer une ligne de code : ajouter de la capacité, c'est ajouter des
noeuds réels et joignables.

Algorithme réel : moyennage de gradients SGD par round (type
"federated averaging"), standard et mathématiquement correct. Chaque
worker entraîne réellement sa part des données (son shard) avec
scikit-learn (SGDClassifier.partial_fit), puis renvoie ses coefficients
réellement mesurés ; le driver fait une moyenne pondérée par le nombre
d'échantillons réels de chaque shard.
"""
import json
import os
import pickle
import socket
import struct
import time
import multiprocessing as mp

from .base import TrainingProvider
from .local_cpu import TrainingInterrupted
from .. import utils

DEFAULT_TIMEOUT = 5.0


# ---------------------------------------------------------------------------
# Protocole réseau minimal : TCP local, JSON, message préfixé par sa longueur.
# ---------------------------------------------------------------------------

def _send(sock, obj):
    payload = json.dumps(obj).encode("utf-8")
    sock.sendall(struct.pack(">I", len(payload)) + payload)


def _recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def _recv(sock):
    header = _recv_exact(sock, 4)
    if header is None:
        return None
    (length,) = struct.unpack(">I", header)
    body = _recv_exact(sock, length)
    if body is None:
        return None
    return json.loads(body.decode("utf-8"))


# ---------------------------------------------------------------------------
# Worker : service TCP réel. Utilisable en processus local (spawné par le
# driver) OU en service autonome lancé par l'utilisateur sur une machine LAN
# (voir local_distributed_worker.py).
# ---------------------------------------------------------------------------

def _train_shard(req):
    import numpy as np
    from sklearn.linear_model import SGDClassifier

    X = np.asarray(req["X"], dtype=float)
    y = np.asarray(req["y"], dtype=str)
    classes = list(req["classes"])
    if X.shape[0] == 0:
        return {"status": "FAILED", "reason": "Shard vide reçu par le worker."}

    model = SGDClassifier(loss="log_loss", random_state=42)
    coef = req.get("coef")
    intercept = req.get("intercept")
    if coef is not None:
        # Warm start réel à partir des poids globaux envoyés par le driver :
        # un premier micro partial_fit alloue les bonnes formes internes,
        # puis on écrase les poids avec ceux du driver avant de continuer.
        model.partial_fit(X[:1], y[:1], classes=classes)
        model.coef_ = np.asarray(coef, dtype=float)
        model.intercept_ = np.asarray(intercept, dtype=float)
        model.partial_fit(X, y)
    else:
        model.partial_fit(X, y, classes=classes)

    return {
        "status": "REAL",
        "coef": model.coef_.tolist(),
        "intercept": model.intercept_.tolist(),
        "n_samples": int(X.shape[0]),
    }


def worker_serve_forever(host, port, ready_queue=None, max_requests=None):
    """Boucle de service TCP réelle. `port=0` laisse l'OS choisir un port
    libre réel (utilisé pour les workers processus locaux) ; un port fixe
    est utilisé pour un service LAN autonome. `ready_queue`, si fourni,
    reçoit le port réellement lié pour que le driver puisse s'y connecter."""
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((host, port))
    srv.listen(8)
    bound_port = srv.getsockname()[1]
    if ready_queue is not None:
        ready_queue.put(bound_port)
    served = 0
    try:
        while True:
            conn, _ = srv.accept()
            try:
                req = _recv(conn)
                if req is None:
                    continue
                op = req.get("op")
                if op == "ping":
                    _send(conn, {"status": "REAL", "op": "pong"})
                elif op == "shutdown":
                    _send(conn, {"status": "REAL", "op": "shutdown_ack"})
                    conn.close()
                    break
                elif op == "train_shard":
                    _send(conn, _train_shard(req))
                else:
                    _send(conn, {"status": "FAILED", "reason": f"op inconnue: {op}"})
            except Exception as e:
                try:
                    _send(conn, {"status": "FAILED", "reason": f"{type(e).__name__}: {e}"})
                except Exception:
                    pass
            finally:
                conn.close()
            served += 1
            if max_requests is not None and served >= max_requests:
                break
    finally:
        srv.close()


# ---------------------------------------------------------------------------
# Provider
# ---------------------------------------------------------------------------

class LocalDistributedProvider(TrainingProvider):
    name = "LOCAL_DISTRIBUTED_PROVIDER"

    def is_available(self) -> dict:
        """Disponibilité du volet 'workers processus locaux' uniquement
        (les noeuds LAN sont vérifiés séparément dans probe_nodes, car ils
        dépendent d'une config fournie au moment de l'entraînement, pas du
        matériel de cette machine)."""
        try:
            import sklearn  # noqa: F401
        except ImportError:
            return {"available": False, "reason": "scikit-learn absent — requis pour l'entraînement distribué local."}
        cores = os.cpu_count() or 1
        if cores < 2:
            return {
                "available": False,
                "reason": (
                    f"{cores} coeur(s) CPU réel(s) détecté(s) sur cette machine — le multi-process "
                    "local nécessite ≥2 coeurs. Des noeuds LAN explicitement configurés via "
                    "config['nodes'] restent utilisables indépendamment de ce nombre."
                ),
            }
        return {
            "available": True,
            "reason": f"{cores} coeurs CPU réels détectés — jusqu'à {cores - 1} worker(s) local(aux) utilisables.",
        }

    @staticmethod
    def probe_nodes(nodes, timeout=DEFAULT_TIMEOUT):
        """Vérifie réellement (ping TCP) chaque noeud LAN fourni. Ne déclare
        jamais un noeud disponible sans réponse réelle."""
        results = []
        for endpoint in nodes:
            host, _, port_s = str(endpoint).partition(":")
            entry = {"endpoint": endpoint, "reachable": False, "reason": None}
            try:
                port = int(port_s)
                sock = socket.create_connection((host, port), timeout=timeout)
                _send(sock, {"op": "ping"})
                resp = _recv(sock)
                sock.close()
                if resp and resp.get("op") == "pong":
                    entry["reachable"] = True
                else:
                    entry["reason"] = "Réponse inattendue ou absente du noeud."
            except Exception as e:
                entry["reason"] = f"{type(e).__name__}: {e}"
            results.append(entry)
        return results

    def train(self, config: dict, checkpoint_cb=None) -> dict:
        if config.get("model_type", "sgd_incremental") != "sgd_incremental":
            raise RuntimeError(
                "LOCAL_DISTRIBUTED_PROVIDER prend en charge uniquement model_type=sgd_incremental "
                "(moyennage réel de gradients SGD entre workers)."
            )
        import numpy as np

        X_train = np.asarray(config.get("X_train", []), dtype=float)
        y_train = np.asarray(config.get("y_train", []), dtype=str)
        X_val = np.asarray(config.get("X_val", []), dtype=float)
        y_val = np.asarray(config.get("y_val", []), dtype=str)
        if X_train.ndim != 2 or X_train.shape[0] == 0:
            raise ValueError("X_train vide ou non matriciel.")
        classes = sorted(set(y_train.tolist()))

        endpoints = []
        spawned = []
        avail = self.is_available()
        if avail["available"]:
            max_local = (os.cpu_count() or 1) - 1
            n_local = max(0, min(int(config.get("n_local_workers", max_local)), max_local))
            for _ in range(n_local):
                q = mp.Queue()
                p = mp.Process(target=worker_serve_forever, args=("127.0.0.1", 0, q), daemon=True)
                p.start()
                try:
                    port = q.get(timeout=DEFAULT_TIMEOUT)
                except Exception:
                    p.terminate()
                    continue
                endpoints.append({"endpoint": f"127.0.0.1:{port}", "host": "127.0.0.1", "port": port, "kind": "LOCAL_PROCESS"})
                spawned.append(p)

        nodes = config.get("nodes", [])
        node_probe = self.probe_nodes(nodes) if nodes else []
        for entry in node_probe:
            if entry["reachable"]:
                host, _, port_s = str(entry["endpoint"]).partition(":")
                endpoints.append({"endpoint": entry["endpoint"], "host": host, "port": int(port_s), "kind": "LAN_NODE"})

        if not endpoints:
            for p in spawned:
                p.terminate()
            reasons = [avail["reason"]] + [f"{e['endpoint']}: {e['reason']}" for e in node_probe if not e["reachable"]]
            raise RuntimeError(
                "LOCAL_DISTRIBUTED_PROVIDER UNAVAILABLE — aucun worker local ni noeud LAN réellement "
                "joignable. " + " | ".join(str(r) for r in reasons)
            )

        try:
            return self._run_rounds(config, endpoints, X_train, y_train, X_val, y_val, classes, checkpoint_cb)
        finally:
            for e in endpoints:
                if e["kind"] == "LOCAL_PROCESS":
                    try:
                        sock = socket.create_connection((e["host"], e["port"]), timeout=2)
                        _send(sock, {"op": "shutdown"})
                        _recv(sock)
                        sock.close()
                    except Exception:
                        pass
            for p in spawned:
                p.join(timeout=2)
                if p.is_alive():
                    p.terminate()

    def _run_rounds(self, config, endpoints, X_train, y_train, X_val, y_val, classes, checkpoint_cb):
        import numpy as np
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

        n_epochs = int(config.get("n_epochs", 5))
        checkpoint_dir = config.get("checkpoint_dir")
        if checkpoint_dir:
            os.makedirs(checkpoint_dir, exist_ok=True)

        shards = np.array_split(np.arange(X_train.shape[0]), len(endpoints))
        coef = None
        intercept = None
        t0 = time.time()
        checkpoints = []
        last_metrics = None
        warnings = []

        for epoch in range(1, n_epochs + 1):
            round_results = []
            for e, idx in zip(endpoints, shards):
                if len(idx) == 0:
                    continue
                payload = {
                    "op": "train_shard",
                    "X": X_train[idx].tolist(),
                    "y": y_train[idx].tolist(),
                    "classes": classes,
                    "coef": coef.tolist() if coef is not None else None,
                    "intercept": intercept.tolist() if intercept is not None else None,
                }
                try:
                    sock = socket.create_connection((e["host"], e["port"]), timeout=DEFAULT_TIMEOUT)
                    _send(sock, payload)
                    resp = _recv(sock)
                    sock.close()
                except Exception as ex:
                    warnings.append(f"epoch {epoch}: {e['endpoint']} indisponible ({type(ex).__name__}: {ex}) — exclu de ce round.")
                    continue
                if not resp or resp.get("status") != "REAL":
                    warnings.append(f"epoch {epoch}: {e['endpoint']} a échoué: {resp.get('reason') if resp else 'aucune réponse'}.")
                    continue
                round_results.append(resp)

            if not round_results:
                raise RuntimeError(f"LOCAL_DISTRIBUTED_PROVIDER: tous les workers ont échoué réellement au round {epoch}.")

            total_n = sum(r["n_samples"] for r in round_results)
            coef = sum(np.asarray(r["coef"]) * (r["n_samples"] / total_n) for r in round_results)
            intercept = sum(np.asarray(r["intercept"]) * (r["n_samples"] / total_n) for r in round_results)

            pred = self._predict(coef, intercept, classes, X_val)
            last_metrics = {
                "accuracy": float(accuracy_score(y_val, pred)),
                "precision_macro": float(precision_score(y_val, pred, average="macro", zero_division=0)),
                "recall_macro": float(recall_score(y_val, pred, average="macro", zero_division=0)),
                "f1_macro": float(f1_score(y_val, pred, average="macro", zero_division=0)),
                "n_workers_used": len(round_results),
            }
            if checkpoint_dir:
                path = os.path.join(checkpoint_dir, f"epoch_{epoch}.pkl")
                with open(path, "wb") as f:
                    pickle.dump({"coef": coef.tolist(), "intercept": intercept.tolist(), "classes": classes}, f, protocol=pickle.HIGHEST_PROTOCOL)
                h = utils.sha256_file(path)
                checkpoints.append({"epoch": epoch, "path": path, "sha256": h, "metrics": last_metrics})
                if checkpoint_cb:
                    checkpoint_cb(epoch, {"path": path, "sha256": h, "metrics": last_metrics, "progress": epoch / max(1, n_epochs)})
            if config.get("stop_after_epoch") and epoch >= int(config["stop_after_epoch"]):
                raise TrainingInterrupted(f"Interrupted after real checkpoint epoch {epoch}")

        final_path = None
        final_hash = None
        if checkpoint_dir:
            final_path = os.path.join(checkpoint_dir, "final_model.pkl")
            with open(final_path, "wb") as f:
                pickle.dump({"coef": coef.tolist(), "intercept": intercept.tolist(), "classes": classes}, f, protocol=pickle.HIGHEST_PROTOCOL)
            final_hash = utils.sha256_file(final_path)

        pred = self._predict(coef, intercept, classes, X_val)
        return {
            "status": "REAL",
            "provider": self.name,
            "duration_seconds": time.time() - t0,
            "metrics": last_metrics,
            "checkpoints": checkpoints,
            "final_model_path": final_path,
            "final_model_sha256": final_hash,
            "predictions": pred.tolist(),
            "y_val": y_val.tolist() if hasattr(y_val, "tolist") else list(y_val),
            "model_format": "linear_coef_json",
            "endpoints_used": [e["endpoint"] for e in endpoints],
            "endpoint_kinds": {e["endpoint"]: e["kind"] for e in endpoints},
            "warnings": warnings,
        }

    @staticmethod
    def _predict(coef, intercept, classes, X):
        import numpy as np
        classes_arr = np.asarray(classes)
        scores = X @ coef.T + intercept
        if coef.shape[0] == 1:
            idx = (scores.ravel() > 0).astype(int)
        else:
            idx = np.argmax(scores, axis=1)
        return classes_arr[idx]
