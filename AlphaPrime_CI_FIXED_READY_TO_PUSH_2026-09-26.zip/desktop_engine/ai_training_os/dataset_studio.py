
"""Dataset Studio: inspect, validate and preview transformations without mutating originals."""
from __future__ import annotations
import json, os
from pathlib import Path
from . import utils
from . import data_engine

class DatasetStudio:
    def __init__(self, registry, audit=None):
        self.registry = registry
        self.audit = audit

    def inspect(self, dataset_version_id: str) -> dict:
        dv = self.registry.get_version(dataset_version_id)
        if not dv:
            raise ValueError("Version de dataset introuvable")
        path = dv["file_path"]
        if not os.path.isfile(path):
            return {"status":"FAILED","cause":"Fichier de version absent.","solution":"Réimportez ou restaurez la version du dataset."}
        integrity = self.registry.verify_integrity(dataset_version_id)
        try:
            records, corrupted = data_engine.load_tabular(path)
            analysis = data_engine.analyze(records)
        except Exception as exc:
            return {"status":"FAILED","cause":f"{type(exc).__name__}: {exc}","solution":"Ouvrez le fichier original et corrigez son format ou ses dépendances locales."}
        split = utils.loads(dv.get("split_json") or "{}")
        # Exact leakage check on JSON-serializable records by split.
        sets = {}
        for name, idxs in split.items():
            if name == "seed": continue
            sets[name] = {json.dumps(records[i], sort_keys=True, default=str) for i in idxs if i < len(records)}
        pairs = {}
        names=list(sets)
        for i,a in enumerate(names):
            for b in names[i+1:]: pairs[f"{a}_vs_{b}"] = len(sets[a] & sets[b])
        quality_score = 100.0
        if analysis.get("n_rows",0):
            quality_score -= min(30.0, (analysis.get("missing",0)/(analysis["n_rows"]*max(1,analysis.get("n_cols",1))))*100)
            quality_score -= min(20.0, (analysis.get("duplicates",0)/analysis["n_rows"])*100)
        if not integrity: quality_score = 0.0
        quality_score=max(0.0,min(100.0,round(quality_score,2)))
        return {"status":"REAL","dataset_version_id":dataset_version_id,"integrity":{"verified":integrity,"sha256":utils.sha256_file(path)},
                "quality":{"score":quality_score,"analysis":analysis,"corrupted_rows":corrupted},
                "split":{"sizes":{k:len(v) for k,v in split.items() if k!="seed"},"exact_leakage":pairs},
                "source":path}

    def preview_cleaning(self, dataset_version_id: str) -> dict:
        report=self.inspect(dataset_version_id)
        if report.get("status")!="REAL": return report
        a=report["quality"]["analysis"]
        actions=[]
        if a.get("duplicates",0): actions.append({"action":"DROP_EXACT_DUPLICATES","count":a["duplicates"]})
        if a.get("missing",0): actions.append({"action":"REVIEW_MISSING_VALUES","count":a["missing"]})
        if report["quality"].get("corrupted_rows"): actions.append({"action":"EXCLUDE_CORRUPTED_ROWS","count":report["quality"]["corrupted_rows"]})
        actions.append({"action":"KEEP_ORIGINAL","reason":"Aucune modification silencieuse."})
        return {"status":"PROPOSED","truth_status":"PROPOSED","dataset_version_id":dataset_version_id,"actions":actions,"source":report["source"],"note":"Aucune écriture effectuée. Exécutez une transformation explicite via le pipeline pour créer une nouvelle version."}
    def apply_cleaning(self, dataset_version_id: str, drop_duplicates=True, drop_missing=True, exclude_corrupted=True) -> dict:
        """Apply explicitly requested safe cleaning steps and create a NEW dataset version."""
        dv = self.registry.get_version(dataset_version_id)
        if not dv: raise ValueError("Version de dataset introuvable")
        path = dv["file_path"]
        if not os.path.isfile(path): raise FileNotFoundError(path)
        records, corrupted = data_engine.load_tabular(path)
        original_count = len(records)
        removed_duplicates = 0
        removed_missing = 0
        working = records
        if drop_duplicates:
            working, removed_duplicates = data_engine.deduplicate(working)
        if drop_missing:
            filtered=[]
            for r in working:
                if any(v is None or (isinstance(v,str) and not v.strip()) for v in r.values()):
                    removed_missing += 1
                else:
                    filtered.append(r)
            working=filtered
        out_root = self.registry.storage_dir / Path("dataset_studio") if isinstance(self.registry.storage_dir, Path) else Path(self.registry.storage_dir)/"dataset_studio"
        out_root.mkdir(parents=True, exist_ok=True)
        source = out_root / f"{dataset_version_id}_cleaned.jsonl"
        with source.open("w",encoding="utf-8") as f:
            for r in working:
                f.write(json.dumps(r,ensure_ascii=False,default=str)+"\n")
        # Re-enter the normal immutable pipeline; this creates a new version and re-splits deterministically.
        new_id, result = self.registry.import_version(dv["dataset_id"], str(source))
        row = self.registry.get_version(new_id)
        metadata = utils.loads(row.get("metadata_json") or "{}") if row else {}
        provenance = utils.loads(row.get("provenance_json") or "{}") if row else {}
        provenance.update({"parent_dataset_version_id":dataset_version_id,"studio_actions":{"drop_duplicates":bool(drop_duplicates),"drop_missing":bool(drop_missing),"exclude_corrupted":bool(exclude_corrupted),"corrupted_rows_detected":corrupted}})
        metadata.update({"studio":{"original_rows":original_count,"removed_duplicates":removed_duplicates,"removed_missing":removed_missing,"corrupted_rows_detected":corrupted,"created_from":dataset_version_id}})
        self.registry.conn.execute("UPDATE dataset_versions SET metadata_json=?, provenance_json=? WHERE id=?",(utils.dumps(metadata),utils.dumps(provenance),new_id))
        self.registry.conn.commit()
        if self.audit:
            self.audit.log("system","DATASET_STUDIO_CLEANED","dataset_version",new_id,{"parent":dataset_version_id,"removed_duplicates":removed_duplicates,"removed_missing":removed_missing})
        return {"status":"REAL","truth_status":"REAL","parent_dataset_version_id":dataset_version_id,"new_dataset_version_id":new_id,"removed_duplicates":removed_duplicates,"removed_missing":removed_missing,"corrupted_rows_detected":corrupted,"result":result}

