from . import utils


class ExperimentRegistry:
    def __init__(self, conn, audit=None):
        self.conn = conn
        self.audit = audit

    def create(self, project_id: str, mission_id: str, dataset_version_id: str,
               model_version_id: str, provider: str, hyperparameters: dict) -> str:
        rows = self.conn.execute("SELECT id FROM experiments WHERE id LIKE 'EXP-%'").fetchall()
        nums=[]
        for r in rows:
            try: nums.append(int(str(r[0]).split("-",1)[1]))
            except (ValueError, IndexError): pass
        exp_id = f"EXP-{(max(nums) if nums else 0)+1:06d}"
        self.conn.execute(
            """INSERT INTO experiments
            (id, project_id, mission_id, dataset_version_id, model_version_id, provider,
             hyperparameters_json, status, created_at)
            VALUES (?,?,?,?,?,?,?,?,?)""",
            (exp_id, project_id, mission_id, dataset_version_id, model_version_id, provider,
             utils.dumps(hyperparameters), "NOT_STARTED", utils.now_iso()),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "CREATE_EXPERIMENT", "experiment", exp_id, {"provider": provider})
        return exp_id

    def start(self, exp_id: str):
        self.conn.execute(
            "UPDATE experiments SET status='RUNNING', started_at=? WHERE id=?",
            (utils.now_iso(), exp_id),
        )
        self.conn.commit()

    def complete(self, exp_id: str, metrics: dict, duration_seconds: float, logs_path: str = None):
        self.conn.execute(
            """UPDATE experiments SET status='COMPLETED', finished_at=?, duration_seconds=?,
               metrics_json=?, logs_path=? WHERE id=?""",
            (utils.now_iso(), duration_seconds, utils.dumps(metrics), logs_path, exp_id),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "EXPERIMENT_COMPLETED", "experiment", exp_id, metrics)

    def pause(self, exp_id: str, message: str):
        self.conn.execute("UPDATE experiments SET status='PAUSED', finished_at=?, error_message=? WHERE id=?", (utils.now_iso(), message, exp_id))
        self.conn.commit()

    def fail(self, exp_id: str, error_message: str):
        self.conn.execute(
            "UPDATE experiments SET status='FAILED', finished_at=?, error_message=? WHERE id=?",
            (utils.now_iso(), error_message, exp_id),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "EXPERIMENT_FAILED", "experiment", exp_id, {"error": error_message})

    def get(self, exp_id: str):
        row = self.conn.execute("SELECT * FROM experiments WHERE id=?", (exp_id,)).fetchone()
        return dict(row) if row else None

    def list_for_project(self, project_id: str):
        rows = self.conn.execute(
            "SELECT * FROM experiments WHERE project_id=? ORDER BY created_at DESC", (project_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    def compare(self, exp_ids: list):
        """Evaluation Matrix — comparaison factuelle de plusieurs expériences réelles."""
        out = []
        for eid in exp_ids:
            e = self.get(eid)
            if e:
                out.append({
                    "experiment_id": eid,
                    "status": e["status"],
                    "metrics": utils.loads(e["metrics_json"]),
                    "duration_seconds": e["duration_seconds"],
                })
        return out
