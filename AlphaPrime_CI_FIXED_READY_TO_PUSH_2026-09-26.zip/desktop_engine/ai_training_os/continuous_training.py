"""Continuous-training orchestration with immutable previous versions."""
import os
from . import utils


class ContinuousTraining:
    def __init__(self, conn, audit=None):
        self.conn = conn
        self.audit = audit

    def create_cycle(self, project_id, dataset_version_id, base_model_version_id=None, config=None):
        cid = utils.new_id("ct")
        self.conn.execute(
            "INSERT INTO continuous_training_runs (id,project_id,dataset_version_id,base_model_version_id,status,config_json,created_at) VALUES (?,?,?,?,?,?,?)",
            (cid, project_id, dataset_version_id, base_model_version_id, "PROPOSED", utils.dumps(config or {}), utils.now_iso()),
        )
        self.conn.commit()
        if self.audit:
            self.audit.log("system", "CONTINUOUS_TRAINING_PROPOSED", "continuous_training", cid, {"dataset_version_id": dataset_version_id})
        return {"status": "PROPOSED", "id": cid, "previous_model_preserved": True}

    def run_tabular(self, app, project_id, source_path, dataset_name="continuous-data", model_name="continuous-model",
                    base_model_version_id=None, model_type="auto", n_epochs=3, security_policy=None):
        """Exécute réellement un cycle local et conserve toujours l'ancienne version."""
        ds_id = app.datasets.create_dataset(project_id, dataset_name, source_path)
        dv_id, imported = app.datasets.import_version(ds_id, source_path)

        baseline = None
        resume_from = None
        start_epoch = 0
        effective_type = model_type
        if base_model_version_id:
            base = app.models.get_version(base_model_version_id)
            if not base:
                raise ValueError("Base model version introuvable")
            base_metrics = utils.loads(base.get("metrics_json") or "{}") or {}
            if "accuracy" in base_metrics:
                baseline = {"accuracy": float(base_metrics["accuracy"])}
            hyper = utils.loads(base.get("hyperparameters_json") or "{}") or {}
            base_type = hyper.get("model_type")
            if effective_type in (None, "", "auto"):
                effective_type = base_type or "sgd_incremental"
            if effective_type == "sgd_incremental":
                row = app.conn.execute(
                    """SELECT c.* FROM checkpoints c JOIN jobs j ON c.job_id=j.id JOIN experiments e ON j.experiment_id=e.id
                       WHERE e.model_version_id=? ORDER BY c.epoch DESC, c.created_at DESC LIMIT 1""",
                    (base_model_version_id,),
                ).fetchone()
                if row and os.path.isfile(row["file_path"]):
                    ck = dict(row)
                    try:
                        if utils.sha256_file(ck["file_path"]) == ck["sha256"]:
                            resume_from = ck["file_path"]
                            start_epoch = int(ck["epoch"])
                    except Exception:
                        resume_from = None

        requested_epochs=int(n_epochs)
        target_epochs=requested_epochs + start_epoch if resume_from else requested_epochs
        cycle = self.create_cycle(
            project_id, dv_id, base_model_version_id,
            {"source_path": source_path, "method": "CONTINUATION_FROM_CHECKPOINT" if resume_from else "RETRAIN_FROM_NEW_DATA",
             "model_type": effective_type, "requested_epochs": requested_epochs, "target_total_epochs": target_epochs},
        )
        result = app.orchestrator.run_tabular_from_dataset_version(
            project_id, dv_id, model_name, effective_type, target_epochs, security_policy,
            regression_baseline=baseline, base_model_version_id=base_model_version_id,
            mission_text=f"Continuous training local à partir de nouvelles données : {source_path}",
            resume_from=resume_from, start_epoch=start_epoch,
        )
        new_status = result.get("status")
        cycle_status = "COMPLETED" if new_status == "REAL" else (new_status or "FAILED")
        if new_status == "REAL" and result.get("safety_gate", {}).get("final_status") == "REJECTED":
            cycle_status = "BLOCKED"
        self.mark(cycle["id"], cycle_status, result.get("model_version_id"), {
            "training_status": result.get("training", {}).get("status"),
            "safety_gate": result.get("safety_gate"),
            "previous_model_preserved": True,
            "imported_dataset": imported,
            "training_method": result.get("training_method"),
        })
        return {
            "status": "REAL" if new_status == "REAL" else new_status,
            "cycle_id": cycle["id"], "previous_model_version_id": base_model_version_id,
            "new_model_version_id": result.get("model_version_id"), "dataset_version_id": dv_id,
            "previous_model_preserved": True, "result": result,
        }

    def mark(self, cycle_id, status, model_version_id=None, details=None):
        self.conn.execute(
            "UPDATE continuous_training_runs SET status=?,new_model_version_id=?,details_json=? WHERE id=?",
            (status, model_version_id, utils.dumps(details or {}), cycle_id),
        )
        self.conn.commit()
        return {"status": status, "id": cycle_id, "model_version_id": model_version_id}
