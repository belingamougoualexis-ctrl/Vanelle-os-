"""Canary testing: candidate -> real test -> apply -> post-verify -> commit/rollback."""
from __future__ import annotations

import threading
import time
from typing import Any, Callable

from . import utils


class CanaryEngine:
    def __init__(self, audit=None, conn=None):
        self.audit = audit
        self.conn = conn
        self._lock = threading.Lock()

    def run(
        self,
        name: str,
        candidate: Any,
        test: Callable[[Any], bool],
        apply: Callable[[Any], None],
        rollback: Callable[[], None],
        verify_after_apply: Callable[[], bool] | None = None,
    ) -> dict[str, Any]:
        started = time.time()
        # Serialize mutable configuration changes. A second repair/canary never
        # overlaps the first one and therefore cannot race its rollback state.
        with self._lock:
            try:
                passed = bool(test(candidate))
                if not passed:
                    rollback()
                    result = {"status": "FAILED", "operation_status": "REJECTED", "name": name, "reason": "Canary test failed; candidate rejected before activation."}
                else:
                    apply(candidate)
                    if verify_after_apply is not None and not bool(verify_after_apply()):
                        raise RuntimeError("POST_APPLY_VERIFICATION_FAILED")
                    result = {"status": "VERIFIED", "operation_status": "COMMITTED", "name": name, "reason": "Canary test and post-apply verification succeeded; candidate was applied."}
            except Exception as exc:
                try:
                    rollback()
                except Exception as rb_exc:
                    return {"status": "RECOVERING", "operation_status": "ROLLBACK_FAILED", "name": name, "cause": f"{type(exc).__name__}: {exc}", "rollback_error": f"{type(rb_exc).__name__}: {rb_exc}"}
                result = {"status": "FAILED", "operation_status": "ROLLED_BACK", "name": name, "cause": f"{type(exc).__name__}: {exc}"}
            result["duration_seconds"] = time.time() - started
            if self.conn:
                self.conn.execute(
                    "INSERT INTO canary_runs (id,name,status,details_json,created_at) VALUES (?,?,?,?,?)",
                    (utils.new_id("canary"), name, result.get("status", "FAILED"), utils.dumps(result), utils.now_iso()),
                )
                self.conn.commit()
            if self.audit:
                self.audit.log("system", "CANARY_RESULT", "canary", None, result)
            return result
