"""Real synthetic tabular data generation with explicit provenance."""
import os, json, random, statistics
from . import utils

class SyntheticDataLab:
    def __init__(self, conn, storage_dir, audit=None): self.conn=conn; self.storage_dir=storage_dir; self.audit=audit; os.makedirs(storage_dir,exist_ok=True)
    def generate_bootstrap(self, dataset_version_id, n_rows=None, seed=42):
        row=self.conn.execute("SELECT * FROM dataset_versions WHERE id=?",(dataset_version_id,)).fetchone()
        if not row: raise ValueError("dataset version introuvable")
        src=dict(row); records=[json.loads(l) for l in open(src["file_path"],encoding="utf-8") if l.strip()]
        if not records: raise ValueError("dataset vide")
        n=int(n_rows or len(records)); rng=random.Random(seed); generated=[]
        for i in range(n):
            r=dict(records[rng.randrange(len(records))]); r["_synthetic"]=True; r["_synthetic_source_index"]=i%len(records); generated.append(r)
        sid=utils.new_id("synth")
        out=os.path.join(self.storage_dir,f"{sid}.jsonl")
        with open(out,"w",encoding="utf-8") as f:
            for r in generated: f.write(json.dumps(r,ensure_ascii=False,default=str)+"\n")
        meta={"status":"REAL","synthetic":True,"method":"bootstrap_sampling","source_dataset_version":dataset_version_id,"seed":seed,"n_rows":n,"output":out,"sha256":utils.sha256_file(out),"created_at":utils.now_iso()}
        with open(out+".manifest.json","w",encoding="utf-8") as f: json.dump(meta,f,ensure_ascii=False,indent=2)
        project_row=self.conn.execute("SELECT d.project_id FROM datasets d JOIN dataset_versions v ON v.dataset_id=d.id WHERE v.id=?",(dataset_version_id,)).fetchone()
        project_id=project_row[0] if project_row else None
        self.conn.execute("INSERT INTO synthetic_data_runs (id,project_id,source_dataset_version_id,method,output_path,sha256,metadata_json,status,created_at) VALUES (?,?,?,?,?,?,?,?,?)",(sid,project_id,dataset_version_id,"bootstrap_sampling",out,meta["sha256"],utils.dumps(meta),"COMPLETED",meta["created_at"]))
        self.conn.commit()
        if self.audit: self.audit.log("system","SYNTHETIC_DATA_CREATED","synthetic_run",sid,meta)
        return {"id":sid,"project_id":project_id,**meta}
