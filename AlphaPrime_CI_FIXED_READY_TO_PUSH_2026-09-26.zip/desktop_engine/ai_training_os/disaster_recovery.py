"""Workspace backup, integrity verification and safe restore."""
import os, json, shutil, zipfile
from . import utils

class DisasterRecovery:
    def __init__(self, workspace, audit=None):
        self.workspace = os.path.abspath(workspace)
        self.audit = audit

    def backup(self, output_zip):
        output_zip = os.path.abspath(output_zip)
        os.makedirs(os.path.dirname(output_zip), exist_ok=True)
        manifest = {"status":"REAL","workspace":self.workspace,"created_at":utils.now_iso(),"files":{}}
        with zipfile.ZipFile(output_zip,"w",zipfile.ZIP_DEFLATED) as z:
            for root, dirs, files in os.walk(self.workspace):
                dirs[:] = [d for d in dirs if d not in {"__pycache__", ".git"}]
                for fn in files:
                    fp=os.path.abspath(os.path.join(root,fn)); rel=os.path.relpath(fp,self.workspace)
                    if fp == output_zip: continue
                    z.write(fp, rel); manifest["files"][rel]=utils.sha256_file(fp)
            z.writestr("backup_manifest.json",json.dumps(manifest,ensure_ascii=False,indent=2))
        result={**manifest,"path":output_zip,"sha256":utils.sha256_file(output_zip)}
        if self.audit:self.audit.log("system","WORKSPACE_BACKUP","workspace",None,{"path":output_zip,"files":len(manifest["files"])})
        return result

    @staticmethod
    def _safe_extract(zip_path, extract_dir):
        extract_dir = os.path.abspath(extract_dir)
        with zipfile.ZipFile(zip_path) as z:
            for info in z.infolist():
                dest=os.path.abspath(os.path.join(extract_dir,info.filename))
                if os.path.commonpath([extract_dir,dest]) != extract_dir:
                    raise RuntimeError("Archive path traversal détecté")
            z.extractall(extract_dir)

    def verify(self, backup_zip):
        try:
            with zipfile.ZipFile(backup_zip) as z:
                m=json.loads(z.read("backup_manifest.json")); results={}
                for name,h in m["files"].items():
                    try:
                        actual=__import__("hashlib").sha256(z.read(name)).hexdigest(); results[name]=actual==h
                    except KeyError:
                        results[name]=False
            ok=all(results.values())
            return {"status":"REAL","integrity":"OK" if ok else "FAILED","files_checked":len(results),"all_match":ok}
        except Exception as exc:
            return {"status":"FAILED","integrity":"FAILED","error":str(exc)}

    def restore(self, backup_zip, target_dir):
        target_dir=os.path.abspath(target_dir)
        if os.path.exists(target_dir) and os.listdir(target_dir):
            return {"status":"FAILED","reason":"Le dossier de restauration doit être vide pour éviter d'écraser des données existantes."}
        os.makedirs(target_dir,exist_ok=True)
        tmp=target_dir+".restore_tmp"
        shutil.rmtree(tmp,ignore_errors=True); os.makedirs(tmp,exist_ok=True)
        try:
            self._safe_extract(backup_zip,tmp)
            verify=self._verify_restored(tmp)
            if not verify:
                return {"status":"FAILED","target":target_dir,"integrity":"FAILED"}
            for name in os.listdir(tmp):
                shutil.move(os.path.join(tmp,name),os.path.join(target_dir,name))
            result={"status":"REAL","target":target_dir,"integrity":"OK"}
            if self.audit:self.audit.log("system","WORKSPACE_RESTORE","workspace",None,result)
            return result
        except Exception as exc:
            return {"status":"FAILED","target":target_dir,"integrity":"FAILED","reason":str(exc)}
        finally:
            shutil.rmtree(tmp,ignore_errors=True)

    def _verify_restored(self,target):
        mp=os.path.join(target,"backup_manifest.json")
        if not os.path.isfile(mp): return False
        with open(mp,encoding="utf-8") as f:m=json.load(f)
        for n,h in m["files"].items():
            p=os.path.join(target,n)
            if not os.path.isfile(p) or utils.sha256_file(p)!=h: return False
        return True
