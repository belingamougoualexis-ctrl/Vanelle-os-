"""Budget/resource guard: estimates are explicitly ESTIMATED; observations are REAL."""
import os
from . import compute

class CostGuardian:
    def __init__(self, workspace=None): self.workspace=workspace or "."
    def estimate(self, n_rows, n_features, model_type, provider, limits=None):
        n_rows=max(0,int(n_rows)); n_features=max(0,int(n_features)); limits=limits or {}
        factor={"logistic_regression":1e-6,"sgd_incremental":1e-6,"random_forest":1e-5,"linear_regression":1e-6,"random_forest_regressor":1e-5,"kmeans":2e-6}.get(model_type,2e-6)
        est_s=max(.1,n_rows*n_features*factor)
        est_bytes=n_rows*n_features*8
        return {"status":"ESTIMATED","estimated_duration_seconds":round(est_s,3),"estimated_storage_bytes":int(est_bytes),"estimated_peak_ram_bytes":int(est_bytes*2),"estimated_cost_usd":None,"cost_note":"Aucun coût monétaire local n’est mesuré par ce moteur; valeur non chiffrée.","limits":limits,"within_limits":self._within(est_s,est_bytes,limits)}
    def _within(self, seconds, storage, limits):
        return (limits.get("max_seconds") is None or seconds<=limits["max_seconds"]) and (limits.get("max_storage_bytes") is None or storage<=limits["max_storage_bytes"])
    def actual(self, duration_seconds, artifact_paths=()):
        size=sum(os.path.getsize(p) for p in artifact_paths if p and os.path.isfile(p))
        return {"status":"REAL","duration_seconds":float(duration_seconds),"artifact_storage_bytes":size,"compute":compute.full_report(self.workspace)}
