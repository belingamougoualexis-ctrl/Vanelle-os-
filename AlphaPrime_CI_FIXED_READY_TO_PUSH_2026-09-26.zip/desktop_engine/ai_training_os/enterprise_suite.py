"""Enterprise-grade local governance, data quality and evaluation controls.

All analysis is computed from artifacts already present in the local workspace.
No HTTP call, API key, hosted telemetry or fabricated metric is used.
"""
from __future__ import annotations

import json
import os
import pickle
import re
from collections import Counter
from datetime import datetime, timezone

from . import utils, data_engine


PII_PATTERNS = {
    "email": re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I),
    "phone": re.compile(r"(?<!\d)(?:\+?\d[\d .()/-]{7,}\d)(?!\d)"),
    "payment_card_like": re.compile(r"(?<!\d)(?:\d[ -]?){13,19}(?!\d)"),
}


def _now():
    return datetime.now(timezone.utc).isoformat()


def _load_version(conn, dataset_version_id):
    row = conn.execute("SELECT * FROM dataset_versions WHERE id=?", (dataset_version_id,)).fetchone()
    if not row:
        raise ValueError("Version de dataset introuvable")
    value = dict(row)
    if not os.path.isfile(value["file_path"]):
        raise FileNotFoundError(value["file_path"])
    return value


def _records(conn, dataset_version_id):
    version = _load_version(conn, dataset_version_id)
    try:
        records, corrupted = data_engine.load_tabular(version["file_path"])
    except Exception as exc:
        raise ValueError(f"Profilage tabulaire indisponible: {exc}") from exc
    return version, records, corrupted


def _infer_type(values):
    nonempty = [v for v in values if v is not None and str(v).strip() != ""]
    if not nonempty:
        return "empty"
    lowered = {str(v).strip().lower() for v in nonempty[:5000]}
    if lowered <= {"true", "false", "0", "1", "yes", "no"}:
        return "boolean_like"
    numeric = 0
    for v in nonempty[:5000]:
        try:
            float(v)
            numeric += 1
        except (TypeError, ValueError):
            pass
    ratio = numeric / max(1, min(len(nonempty), 5000))
    return "numeric" if ratio >= 0.95 else "categorical"


def _fingerprint(schema):
    import hashlib
    raw = json.dumps(schema, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


class EnterpriseSuite:
    def __init__(self, conn, workspace, audit=None):
        self.conn = conn
        self.workspace = os.path.abspath(workspace)
        self.audit = audit
        self.root = os.path.join(self.workspace, "governance")
        self.cards_dir = os.path.join(self.workspace, "model_cards")
        os.makedirs(self.root, exist_ok=True)
        os.makedirs(self.cards_dir, exist_ok=True)

    def profile_dataset(self, dataset_version_id):
        version, records, corrupted = _records(self.conn, dataset_version_id)
        columns = list(records[0].keys()) if records else []
        total = len(records)
        columns_out = {}
        pii = {kind: {"count": 0, "columns": []} for kind in PII_PATTERNS}
        duplicate_keys = set()
        duplicates = 0
        for row in records:
            key = json.dumps(row, sort_keys=True, default=str, ensure_ascii=False)
            if key in duplicate_keys:
                duplicates += 1
            else:
                duplicate_keys.add(key)
        for col in columns:
            vals = [r.get(col) for r in records]
            nonempty = [v for v in vals if v is not None and str(v).strip() != ""]
            missing = total - len(nonempty)
            inferred = _infer_type(vals)
            uniques = len({str(v) for v in nonempty})
            info = {
                "type": inferred,
                "missing": missing,
                "missing_rate": missing / max(1, total),
                "unique": uniques,
            }
            if inferred == "numeric":
                nums = []
                for v in nonempty:
                    try:
                        nums.append(float(v))
                    except (TypeError, ValueError):
                        pass
                if nums:
                    mean = sum(nums) / len(nums)
                    variance = sum((x - mean) ** 2 for x in nums) / len(nums)
                    info.update({
                        "min": min(nums), "max": max(nums), "mean": mean,
                        "std": variance ** 0.5,
                        "zero_count": sum(1 for x in nums if x == 0),
                    })
            else:
                counts = Counter(str(v) for v in nonempty)
                info["top_values"] = [{"value": k, "count": v} for k, v in counts.most_common(5)]
            for kind, pattern in PII_PATTERNS.items():
                hits = sum(1 for v in nonempty if pattern.search(str(v)))
                pii[kind]["count"] += hits
                if hits:
                    pii[kind]["columns"].append(col)
            columns_out[col] = info

        missing_cells = sum(v["missing"] for v in columns_out.values())
        total_cells = max(1, total * max(1, len(columns)))
        missing_rate = missing_cells / total_cells
        dup_rate = duplicates / max(1, total)
        pii_hits = sum(v["count"] for v in pii.values())
        quality_score = max(0.0, 100.0 - 65.0 * missing_rate - 25.0 * dup_rate - min(10.0, pii_hits / max(1, total) * 10.0))
        schema = [{"name": c, "type": columns_out[c]["type"]} for c in columns]
        result = {
            "status": "REAL",
            "truth_status": "REAL",
            "dataset_version_id": dataset_version_id,
            "rows": total,
            "columns": len(columns),
            "corrupted_rows": corrupted,
            "duplicates": duplicates,
            "missing_cells": missing_cells,
            "missing_rate": missing_rate,
            "pii": pii,
            "schema": schema,
            "schema_fingerprint": _fingerprint(schema),
            "column_profile": columns_out,
            "quality_score": round(quality_score, 3),
            "generated_at": _now(),
        }
        if self.audit:
            self.audit.log("system", "DATASET_PROFILED", "dataset_version", dataset_version_id, {
                "rows": total, "columns": len(columns), "quality_score": result["quality_score"],
                "schema_fingerprint": result["schema_fingerprint"],
            })
        return result

    def create_contract(self, project_id, dataset_version_id, thresholds=None):
        profile = self.profile_dataset(dataset_version_id)
        thresholds = thresholds or {}
        contract = {
            "schema": profile["schema"],
            "min_rows": int(thresholds.get("min_rows", 1)),
            "max_missing_rate": float(thresholds.get("max_missing_rate", 0.20)),
            "max_duplicate_rate": float(thresholds.get("max_duplicate_rate", 0.05)),
            "forbid_pii": bool(thresholds.get("forbid_pii", False)),
        }
        cid = utils.new_id("contract")
        self.conn.execute(
            "INSERT INTO data_contracts (id,project_id,dataset_version_id,contract_json,status,created_at) VALUES (?,?,?,?,?,?)",
            (cid, project_id, dataset_version_id, utils.dumps(contract), "ACTIVE", utils.now_iso()),
        )
        self.conn.commit()
        if self.audit: self.audit.log("system", "CREATE_DATA_CONTRACT", "data_contract", cid, contract)
        return {"status": "REAL", "contract_id": cid, "contract": contract, "profile": profile}

    def validate_contract(self, dataset_version_id, contract_id=None):
        if contract_id:
            row = self.conn.execute("SELECT * FROM data_contracts WHERE id=?", (contract_id,)).fetchone()
        else:
            row = self.conn.execute("SELECT * FROM data_contracts WHERE dataset_version_id=? ORDER BY created_at DESC LIMIT 1", (dataset_version_id,)).fetchone()
        if not row:
            return {"status": "UNAVAILABLE", "reason": "Aucun data contract local enregistré pour cette version."}
        contract = utils.loads(row["contract_json"] or "{}")
        profile = self.profile_dataset(dataset_version_id)
        expected = contract.get("schema", [])
        actual = profile.get("schema", [])
        checks = {
            "schema_exact": expected == actual,
            "min_rows": profile["rows"] >= int(contract.get("min_rows", 1)),
            "missing_rate": profile["missing_rate"] <= float(contract.get("max_missing_rate", 1.0)),
            "duplicate_rate": profile["duplicates"] / max(1, profile["rows"]) <= float(contract.get("max_duplicate_rate", 1.0)),
            "pii_policy": (not contract.get("forbid_pii")) or sum(v["count"] for v in profile["pii"].values()) == 0,
        }
        status = "VALIDATED" if all(checks.values()) else "FAILED"
        self.conn.execute("UPDATE data_contracts SET status=? WHERE id=?", (status, row["id"]))
        self.conn.commit()
        result = {"status": "REAL", "contract_id": row["id"], "validation_status": status, "checks": checks, "profile": profile}
        if self.audit: self.audit.log("system", "VALIDATE_DATA_CONTRACT", "data_contract", row["id"], {"status": status, "checks": checks})
        return result

    @staticmethod
    def _distribution(values):
        counts = Counter(str(v) for v in values if v is not None and str(v).strip() != "")
        total = max(1, sum(counts.values()))
        return {k: v / total for k, v in counts.items()}

    def drift(self, baseline_dataset_version_id, candidate_dataset_version_id, project_id=None):
        base = self.profile_dataset(baseline_dataset_version_id)
        cand = self.profile_dataset(candidate_dataset_version_id)
        base_cols = {x["name"]: x["type"] for x in base["schema"]}
        cand_cols = {x["name"]: x["type"] for x in cand["schema"]}
        _, base_records, _ = _records(self.conn, baseline_dataset_version_id)
        _, cand_records, _ = _records(self.conn, candidate_dataset_version_id)
        per_column = {}
        any_drift = False
        threshold = 0.20
        for col in sorted(set(base_cols) | set(cand_cols)):
            if col not in base_cols or col not in cand_cols:
                per_column[col] = {"status": "SCHEMA_CHANGE", "baseline": base_cols.get(col), "candidate": cand_cols.get(col)}
                any_drift = True
                continue
            b = base["column_profile"][col]; c = cand["column_profile"][col]
            if base_cols[col] == "numeric" and cand_cols[col] == "numeric":
                mean_shift = abs(c.get("mean", 0.0) - b.get("mean", 0.0)) / max(abs(b.get("std", 0.0)), 1e-9)
                std_shift = abs(c.get("std", 0.0) - b.get("std", 0.0)) / max(abs(b.get("std", 0.0)), 1e-9)
                drifted = mean_shift > 1.0 or std_shift > 1.0
                per_column[col] = {"type": "numeric", "mean_shift_sigma": mean_shift, "std_shift_ratio": std_shift, "drifted": drifted}
            else:
                bdist = self._distribution([r.get(col) for r in base_records])
                cdist = self._distribution([r.get(col) for r in cand_records])
                keys = set(bdist) | set(cdist)
                l1 = sum(abs(bdist.get(k, 0.0) - cdist.get(k, 0.0)) for k in keys)
                drifted = l1 > threshold
                per_column[col] = {"type": "categorical", "distribution_l1": l1, "drifted": drifted, "threshold": threshold}
            any_drift = any_drift or bool(per_column[col].get("drifted"))
        result = {
            "status": "REAL", "truth_status": "REAL", "baseline_dataset_version_id": baseline_dataset_version_id,
            "candidate_dataset_version_id": candidate_dataset_version_id, "schema_changed": base_cols != cand_cols,
            "drift_detected": any_drift, "thresholds": {"categorical_l1": threshold}, "columns": per_column,
            "generated_at": _now(),
        }
        rid = utils.new_id("drift")
        self.conn.execute(
            "INSERT INTO drift_runs (id,project_id,baseline_dataset_version_id,candidate_dataset_version_id,result_json,status,created_at) VALUES (?,?,?,?,?,?,?)",
            (rid, project_id, baseline_dataset_version_id, candidate_dataset_version_id, utils.dumps(result), "DRIFT" if any_drift else "STABLE", utils.now_iso()),
        )
        self.conn.commit()
        result["drift_run_id"] = rid
        if self.audit: self.audit.log("system", "DATASET_DRIFT_SCAN", "drift_run", rid, {"drift_detected": any_drift})
        return result

    def lineage(self, project_id):
        nodes = []
        edges = []
        def add_node(node_id, kind, label, status=None, meta=None):
            nodes.append({"id": node_id, "type": kind, "label": label, "status": status, "metadata": meta or {}})
        datasets = self.conn.execute("SELECT * FROM datasets WHERE project_id=?", (project_id,)).fetchall()
        for ds in datasets:
            add_node(ds["id"], "dataset", ds["name"], "ACTIVE", {"origin_path": ds["origin_path"]})
        dvs = self.conn.execute("SELECT dv.*,d.name AS dataset_name FROM dataset_versions dv JOIN datasets d ON d.id=dv.dataset_id WHERE d.project_id=?", (project_id,)).fetchall()
        for dv in dvs:
            add_node(dv["id"], "dataset_version", f"{dv['dataset_name']} v{dv['version_number']}", dv["status"], {"sha256": dv["sha256"], "rows": dv["n_rows"]})
            edges.append({"from": dv["dataset_id"], "to": dv["id"], "relation": "VERSION_OF"})
        models = self.conn.execute("SELECT * FROM models WHERE project_id=?", (project_id,)).fetchall()
        for m in models:
            add_node(m["id"], "model", m["name"], "REGISTERED", {"architecture": m["architecture"]})
        mvs = self.conn.execute("SELECT mv.*,m.name AS model_name FROM model_versions mv JOIN models m ON m.id=mv.model_id WHERE m.project_id=?", (project_id,)).fetchall()
        for mv in mvs:
            add_node(mv["id"], "model_version", f"{mv['model_name']} v{mv['version_number']}", mv["status"], {"sha256": mv["sha256"], "file_path": mv["file_path"]})
            edges.append({"from": mv["model_id"], "to": mv["id"], "relation": "VERSION_OF"})
            if mv["dataset_version_id"]:
                edges.append({"from": mv["dataset_version_id"], "to": mv["id"], "relation": "TRAINED_ON"})
        exps = self.conn.execute("SELECT * FROM experiments WHERE project_id=?", (project_id,)).fetchall()
        for e in exps:
            add_node(e["id"], "experiment", e["id"], e["status"])
            if e["dataset_version_id"]: edges.append({"from": e["dataset_version_id"], "to": e["id"], "relation": "EXPERIMENT_INPUT"})
            if e["model_version_id"]: edges.append({"from": e["id"], "to": e["model_version_id"], "relation": "PRODUCED"})
        return {"status": "REAL", "project_id": project_id, "nodes": nodes, "edges": edges, "generated_at": _now()}

    def generate_model_card(self, project_id, model_version_id):
        row = self.conn.execute(
            "SELECT mv.*,m.name AS model_name,m.architecture FROM model_versions mv JOIN models m ON m.id=mv.model_id WHERE mv.id=? AND m.project_id=?",
            (model_version_id, project_id),
        ).fetchone()
        if not row: raise ValueError("Version de modèle introuvable pour ce projet")
        mv = dict(row)
        dataset = self.conn.execute("SELECT * FROM dataset_versions WHERE id=?", (mv.get("dataset_version_id"),)).fetchone() if mv.get("dataset_version_id") else None
        evals = [dict(r) for r in self.conn.execute("SELECT * FROM evaluations WHERE model_version_id=? ORDER BY created_at DESC", (model_version_id,)).fetchall()]
        gates = [dict(r) for r in self.conn.execute("SELECT * FROM safety_gate_reviews WHERE model_version_id=? ORDER BY created_at DESC", (model_version_id,)).fetchall()]
        deployments = [dict(r) for r in self.conn.execute("SELECT * FROM deployments WHERE model_version_id=? ORDER BY created_at DESC", (model_version_id,)).fetchall()]
        deps = utils.loads(mv.get("dependencies_json") or "{}")
        hp = utils.loads(mv.get("hyperparameters_json") or "{}")
        card = {
            "status": "REAL", "project_id": project_id, "model_version_id": model_version_id,
            "model_name": mv["model_name"], "architecture": mv["architecture"], "version": mv["version_number"],
            "lifecycle_status": mv["status"], "artifact": {"path": mv.get("file_path"), "sha256": mv.get("sha256")},
            "training": {"dataset_version_id": mv.get("dataset_version_id"), "hyperparameters": hp, "dependencies": deps, "hardware": utils.loads(mv.get("hardware_json") or "{}")},
            "dataset": dict(dataset) if dataset else None, "evaluations": evals, "safety_gate_reviews": gates,
            "deployments": deployments, "generated_at": _now(),
        }
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(self.cards_dir, f"{model_version_id}_{stamp}.md")
        lines = [
            f"# Model Card — {mv['model_name']} v{mv['version_number']}", "",
            f"- Lifecycle status: {mv['status']}", f"- Architecture: {mv['architecture']}",
            f"- Model version ID: `{model_version_id}`", f"- Artifact SHA-256: `{mv.get('sha256') or 'N/A'}`", "",
            "## Training provenance", f"- Dataset version: `{mv.get('dataset_version_id') or 'N/A'}`",
            f"- Code version: `{mv.get('code_version') or 'N/A'}`", f"- Dependencies: `{json.dumps(deps, ensure_ascii=False)}`", "",
            "## Metrics / evaluations",
        ]
        for e in evals:
            lines.append(f"- {e['created_at']}: {e['status']} — `{e['metrics_json']}`")
        lines += ["", "## Safety Gate"]
        for g in gates:
            lines.append(f"- {g['created_at']}: {g['final_status']} — `{g['details_json']}`")
        lines += ["", "## Deployments"]
        for d in deployments:
            lines.append(f"- {d['created_at']}: {d['status']} → `{d['target']}`")
        lines += ["", "## Local truth statement", "This card was generated from records and files present in the local Alpha Prime workspace. No remote metric or hosted service is consulted.", ""]
        with open(path, "w", encoding="utf-8") as f: f.write("\n".join(lines))
        sha = utils.sha256_file(path)
        card_id = utils.new_id("card")
        self.conn.execute(
            "INSERT INTO model_cards (id,project_id,model_version_id,path,sha256,status,created_at) VALUES (?,?,?,?,?, ?,?)",
            (card_id, project_id, model_version_id, path, sha, "GENERATED", utils.now_iso()),
        )
        self.conn.commit()
        if self.audit: self.audit.log("system", "MODEL_CARD_GENERATED", "model_card", card_id, {"model_version_id": model_version_id, "sha256": sha})
        return {"status": "REAL", "model_card_id": card_id, "path": path, "sha256": sha, "card": card}

    def create_eval_suite(self, project_id, name, golden_dataset_version_id, thresholds=None):
        thresholds = thresholds or {"accuracy": 0.0, "f1_macro": 0.0}
        sid = utils.new_id("suite")
        self.conn.execute(
            "INSERT INTO eval_suites (id,project_id,name,golden_dataset_version_id,task_type,thresholds_json,status,created_at) VALUES (?,?,?,?,?,?,?,?)",
            (sid, project_id, name, golden_dataset_version_id, "classification", utils.dumps(thresholds), "ACTIVE", utils.now_iso()),
        )
        self.conn.commit()
        if self.audit: self.audit.log("system", "CREATE_EVAL_SUITE", "eval_suite", sid, {"name": name, "golden_dataset_version_id": golden_dataset_version_id})
        return {"status": "REAL", "suite_id": sid, "name": name, "golden_dataset_version_id": golden_dataset_version_id, "thresholds": thresholds}

    def run_eval_suite(self, suite_id, model_version_id):
        suite = self.conn.execute("SELECT * FROM eval_suites WHERE id=?", (suite_id,)).fetchone()
        model = self.conn.execute("SELECT * FROM model_versions WHERE id=?", (model_version_id,)).fetchone()
        if not suite or not model: raise ValueError("Suite ou version de modèle introuvable")
        dataset_id = suite["golden_dataset_version_id"]
        version, records, _ = _records(self.conn, dataset_id)
        if not records: raise ValueError("Golden dataset vide")
        label = next((c for c in ("label", "class", "target", "category") if c in records[0]), None)
        if not label: raise ValueError("Golden dataset sans colonne label/class/target/category")
        feature_cols = []
        for c in records[0].keys():
            if c == label: continue
            vals = [r.get(c) for r in records]
            if _infer_type(vals) == "numeric": feature_cols.append(c)
        if not feature_cols: raise ValueError("Golden dataset sans features numériques compatibles avec les modèles tabulaires locaux")
        path = model["file_path"]
        if not path or not os.path.isfile(path):
            return {"status": "UNAVAILABLE", "reason": "Artefact modèle local absent."}
        try:
            with open(path, "rb") as f: loaded = pickle.load(f)
            X, y = [], []
            for r in records:
                try:
                    X.append([float(r[c]) for c in feature_cols]); y.append(r[label])
                except (TypeError, ValueError):
                    continue
            pred = loaded.predict(X)
            from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
            metrics = {
                "accuracy": float(accuracy_score(y, pred)),
                "precision_macro": float(precision_score(y, pred, average="macro", zero_division=0)),
                "recall_macro": float(recall_score(y, pred, average="macro", zero_division=0)),
                "f1_macro": float(f1_score(y, pred, average="macro", zero_division=0)),
                "rows_evaluated": len(y),
            }
        except Exception as exc:
            return {"status": "UNAVAILABLE", "reason": f"Évaluation locale incompatible avec ce modèle: {exc}"}
        thresholds = utils.loads(suite["thresholds_json"] or "{}")
        checks = {metric: float(metrics.get(metric, float("nan"))) >= float(value) for metric, value in thresholds.items() if metric in metrics}
        run_status = "PASSED" if checks and all(checks.values()) else ("FAILED" if checks else "PENDING")
        rid = utils.new_id("suite_run")
        self.conn.execute(
            "INSERT INTO eval_suite_runs (id,suite_id,model_version_id,status,metrics_json,checks_json,created_at) VALUES (?,?,?,?,?,?,?)",
            (rid, suite_id, model_version_id, run_status, utils.dumps(metrics), utils.dumps(checks), utils.now_iso()),
        )
        self.conn.commit()
        result = {"status": "REAL", "eval_suite_run_id": rid, "suite_id": suite_id, "model_version_id": model_version_id, "golden_dataset_version_id": dataset_id, "metrics": metrics, "checks": checks, "run_status": run_status}
        if self.audit: self.audit.log("system", "RUN_EVAL_SUITE", "eval_suite_run", rid, {"status": run_status, "metrics": metrics})
        return result

    def list(self, project_id):
        contracts = [dict(r) for r in self.conn.execute("SELECT * FROM data_contracts WHERE project_id=? ORDER BY created_at DESC", (project_id,)).fetchall()]
        drifts = [dict(r) for r in self.conn.execute("SELECT * FROM drift_runs WHERE project_id=? ORDER BY created_at DESC", (project_id,)).fetchall()]
        cards = [dict(r) for r in self.conn.execute("SELECT * FROM model_cards WHERE project_id=? ORDER BY created_at DESC", (project_id,)).fetchall()]
        suites = [dict(r) for r in self.conn.execute("SELECT * FROM eval_suites WHERE project_id=? ORDER BY created_at DESC", (project_id,)).fetchall()]
        suite_runs = [dict(r) for r in self.conn.execute("SELECT r.* FROM eval_suite_runs r JOIN eval_suites s ON s.id=r.suite_id WHERE s.project_id=? ORDER BY r.created_at DESC", (project_id,)).fetchall()]
        return {"status": "REAL", "contracts": contracts, "drift_runs": drifts, "model_cards": cards, "eval_suites": suites, "eval_suite_runs": suite_runs}
