"""
desktop_app.py — Alpha Prime comme vraie application desktop.

Contrairement à alpha_prime_launch.py (qui ouvre le navigateur), ce script
lance le serveur local puis l'affiche dans une fenêtre native (via pywebview) :
pas d'onglet de navigateur, une icône d'application, une fenêtre qu'on peut
fermer/réduire normalement. C'est ce format qui est publiable sur le
Microsoft Store (ou packagé en .app pour le Mac App Store).

AVERTISSEMENT HONNÊTE : pywebview n'est pas installé dans l'environnement où
ce fichier a été écrit (pas d'accès réseau pour le télécharger), donc ce
script n'a pas pu être exécuté ni testé ici. Le code suit l'API documentée
de pywebview (stable depuis plusieurs années) mais tu dois le tester
toi-même avec `pip install pywebview` sur ta machine avant de le publier.
"""
from __future__ import annotations

import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

APP_TITLE = "Alpha Prime"
HOST = "127.0.0.1"
PORT = 8787


def _start_server(workspace: Path):
    from ai_training_os.api_server import serve_forever
    serve_forever(str(workspace), HOST, PORT)


def main():
    try:
        import webview
    except ImportError:
        print("[Alpha Prime] Le module 'pywebview' n'est pas installé.")
        print("Installez-le avec : pip install pywebview")
        print("(Nécessite une connexion Internet — non disponible dans "
              "l'environnement où ce fichier a été généré, donc non testé ici.)")
        sys.exit(1)

    workspace = ROOT / "workspace"
    workspace.mkdir(exist_ok=True)
    # The local server starts the resumable bootstrap in its own background
    # thread. Avoid running it twice from the desktop wrapper.
    server_thread = threading.Thread(target=_start_server, args=(workspace,), daemon=True)
    server_thread.start()
    time.sleep(1.5)  # laisse le serveur local ouvrir son port avant d'afficher la fenêtre

    icon_path = ROOT / "frontend" / "icon.png"
    webview.create_window(
        title=APP_TITLE,
        url=f"http://{HOST}:{PORT}/",
        width=1280,
        height=820,
        min_size=(900, 600),
    )
    # pywebview gère l'icône différemment selon l'OS/backend (GTK, Cocoa,
    # EdgeChromium...) ; par prudence on ne fixe PAS un paramètre d'icône
    # que je n'ai pas pu vérifier ici. Ajoute-la toi-même une fois testé,
    # selon la méthode propre à ton OS (voir doc pywebview).
    webview.start()


if __name__ == "__main__":
    main()
