# AI Training OS — Reality / Recovery Layer

## But

Cette couche transforme les capacités critiques d'AI Training OS en capacités vérifiables : une détection, une configuration ou une réponse de l'IA ne suffit jamais à déclarer une fonction opérationnelle.

Le cycle officiel est :

`OBSERVE → UNDERSTAND → VERIFY → ADAPT → TEST → TRAIN → EVALUATE → RECOVER → VERIFY AGAIN`

## États officiels

- `VERIFIED` : preuve locale réelle réussie.
- `DEGRADED` : fonctionnement partiel avec une ou plusieurs capacités non vérifiées/indisponibles.
- `NOT VERIFIED` : preuve insuffisante ou environnement absent.
- `FAILED` : test réellement exécuté et échoué.
- `RECOVERING` : récupération/rollback en cours ou partiellement bloqué.
- `TESTING` : capacité ou proposition en cours de validation.

Les anciens statuts du projet (`REAL`, `COMPLETED`, etc.) restent utilisés pour compatibilité avec les fonctions historiques, mais la couche Reality fournit l'état officiel pour les capacités critiques.

## Nouveaux composants

`truth.py` définit les états officiels et la hiérarchie des preuves.

`hardware_reality.py` mesure OS, architecture, CPU, RAM, stockage, GPU, pilotes/runtime et réalise de vrais smoke-tests CPU/CUDA/MPS lorsque l'environnement le permet.

`adaptive_config.py` propose une configuration à partir des ressources réellement mesurées puis vérifie l'allocation de ressources.

`reality_tests.py` orchestre les validations Digital Twin, dépendances, dataset, modèle, inférence, offline et enregistre les preuves locales dans SQLite.

`diagnostic_engine.py` sépare les faits locaux des hypothèses de cause et attribue un niveau de confiance.

`self_healing.py` n'autorise qu'une petite liste de réparations réversibles, sauvegarde l'état avant modification, reteste et restaure automatiquement en cas d'échec.

`canary.py` applique `candidate → test → commit` et rejette/rollback la configuration si le test échoue.

`health_monitor.py` enregistre CPU/RAM/stockage/GPU et RSS du processus pendant les entraînements.

`research_engine.py` conserve la provenance des informations Internet sans exécuter automatiquement des commandes récupérées sur le web.

## Données persistées

Les nouvelles tables locales comprennent notamment :

- `machine_profiles`
- `verification_runs`
- `repair_runs`
- `canary_runs`
- `health_samples`
- `research_sources`

Le fichier `machine_profile.json` est également conservé dans le workspace.

## Validation modèle sécurisée

Les artefacts PyTorch sont chargés avec `weights_only=True`.

Un pickle n'est rechargé pour une validation d'exécution que s'il est :

1. dans l'arbre privé `checkpoints/` du workspace ;
2. marqué `artifact_origin=LOCAL_TRAINING` ;
3. lié au hash réellement mesuré du fichier.

Un pickle importé ou enregistré manuellement sans cette preuve reste `NOT VERIFIED` et n'est pas exécuté.

## Validation entraînement

Le `TrainingEngine` conserve les providers existants et ajoute une preuve post-train :

- checkpoint réel présent + hash validé ;
- artefact final réel présent + hash validé ;
- enregistrement du résultat d'entraînement ;
- rechargement/inférence réelle du modèle final ;
- journal de santé continu ;
- échec si la preuve post-training ne passe pas.

## Offline

`offline_smoke()` interdit temporairement les connexions socket pendant une opération locale réelle du Data Engine. Une opération réussie sans tentative réseau est marquée `VERIFIED` dans le périmètre du test.

## Internet

Internet est traité comme une source d'information et de provenance. Une source enregistrée/fetchée reçoit son URL, son type, sa version quand disponible et son hash de contenu. Une information distante ne devient jamais automatiquement une capacité validée de la machine courante.

## Plateformes

La CI desktop prépare une matrice Windows/macOS/Linux en Python 3.11. Aucun résultat GPU ou Apple Silicon n'est marqué comme testé physiquement tant que le runner correspondant n'a pas exécuté le test réel.

## Limites connues et honnêtes

Sur l'environnement d'audit utilisé ici :

- OS : Linux x86_64 uniquement ;
- GPU : aucun GPU physique disponible, donc GPU = `NOT VERIFIED` ;
- PyTorch : présent en CPU-only ;
- stack LLM Transformers/PEFT/Datasets/Accelerate : absent dans le runtime d'audit ;
- QLoRA/CUDA réel : non validé ici ;
- Windows/macOS/ARM64 : non exécutés physiquement ici.

Ces limites restent visibles dans les rapports et ne sont pas converties en succès.
