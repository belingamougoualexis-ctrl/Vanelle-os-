# Alpha Prime 1.0.1 — Release notes

## Correctifs

- Correction du workflow GitHub Actions Windows : Alpha Prime est extrait depuis le paquet ZIP avant la recherche de `requirements.txt`.
- Suppression du `cache-dependency-path` dynamique de `setup-python`, qui provoquait une résolution de chemin avant disponibilité de `PROJECT_ROOT`.
- Vérification explicite de la présence de `requirements.txt`, des scripts de test et de build.
- Vérification de la syntaxe Python avant les tests.
- Vérification réelle de l'exécutable Windows après PyInstaller.
- Runner de tests local avec délai par fichier augmenté à 300 secondes pour les environnements CI lents.
- Les tests et le build restent fondés sur des opérations réelles ; aucune réussite n'est fabriquée.

## Important

Le build Windows doit être effectué sur Windows. Le paquet source contient le code et le workflow ; le `.exe` final est généré par GitHub Actions lors d'un run réussi.
