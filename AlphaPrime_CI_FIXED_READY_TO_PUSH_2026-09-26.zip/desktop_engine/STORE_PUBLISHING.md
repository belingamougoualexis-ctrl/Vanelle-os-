# Publier Alpha Prime sur le Microsoft Store

Ce guide part de ce qui est réellement prêt dans ce projet aujourd'hui et de
ce qui reste à faire. Rien n'est inventé — chaque étape non testée est
signalée comme telle.

## Ce qui est déjà prêt dans ce dépôt

- `desktop_app.py` — lance Alpha Prime dans une vraie fenêtre native
  (via `pywebview`), pas un onglet de navigateur.
- `build_executable.py` — construit l'exécutable Windows à partir de
  `desktop_app.py` (mode fenêtré, sans console).

**Non testé ici** (pas d'accès réseau dans l'environnement de génération) :
`desktop_app.py` et l'installation de `pywebview`. À tester toi-même avant
de publier quoi que ce soit.

## Compiler sans rien installer toi-même : GitHub Actions

Un fichier `.github/workflows/build-windows-exe.yml` est déjà inclus dans ce
projet. Il fait compiler l'exécutable Windows automatiquement, sur une vraie
machine Windows fournie gratuitement par GitHub — tu n'as rien à installer
sur ton propre ordinateur.

Étapes :
1. Crée un dépôt GitHub (ou utilise un dépôt existant) et pousse-y ce projet
   (via l'interface web de GitHub — "Add file" → "Upload files" — si tu ne
   veux pas utiliser la ligne de commande `git`).
2. Va dans l'onglet **Actions** du dépôt.
3. Le workflow "Build Windows executable" se lance automatiquement après le
   push (ou clique sur "Run workflow" pour le lancer manuellement).
4. Une fois terminé (quelques minutes), un fichier téléchargeable nommé
   **AlphaPrime-Windows** apparaît en bas de la page du run — c'est ton
   exécutable Windows compilé, prêt à tester puis à empaqueter en MSIX.

Le workflow exécute aussi les 57 tests réels du projet avant de compiler —
si un test échoue, la compilation s'arrête et te le signale, au lieu de te
donner un exécutable potentiellement cassé.

**Non testé ici** (même contrainte que le reste : mon environnement ne peut
pas se connecter à GitHub). La syntaxe suit le format standard des workflows
GitHub Actions ; vérifie le résultat du premier run avant de faire confiance
au fichier produit.

## Étapes réelles si tu compiles toi-même à la place

1. **Tester la fenêtre native sur ta machine**
   ```
   pip install -r requirements-desktop.txt
   python3 desktop_app.py
   ```
   Vérifie que la fenêtre s'ouvre, que le dashboard répond, que le
   didacticiel s'affiche correctement.

2. **Construire l'exécutable**
   ```
   python3 build_executable.py
   ```
   Doit être lancé **sur Windows** pour produire un `.exe` Windows
   (contrainte réelle de PyInstaller — pas de cross-compilation).

3. **Empaqueter en MSIX** (format requis par le Microsoft Store)
   - Utilise le **MSIX Packaging Tool** (gratuit, Microsoft) pour convertir
     le dossier produit par PyInstaller (`dist/AlphaPrime/`) en `.msix`.
   - Alternative : `pyinstaller` + `briefcase` ou `Advanced Installer` gèrent
     aussi la génération MSIX ; je n'ai testé aucun des deux ici.

4. **Créer un compte développeur Microsoft**
   - Aller sur Partner Center (compte développeur Microsoft Store).
   - Depuis 2025-2026, l'inscription est **gratuite** pour les comptes
     individuels ET les comptes entreprise (les frais de 19$/99$ ont été
     supprimés).
   - Pour un compte entreprise, prévoir un numéro **D-U-N-S** si tu l'as, ou
     des documents d'entreprise (statuts, licence, registre) sinon —
     la vérification manuelle est plus longue sans D-U-N-S.

5. **Soumettre**
   - Réserver le nom "Alpha Prime" dans Partner Center.
   - Fournir : description, captures d'écran, icône, catégorie, lien vers
     `PRIVACY.md` (complété et idéalement validé légalement — voir ce fichier).
   - Microsoft fait passer l'app par sa certification (vérifie qu'elle
     démarre, ne plante pas, respecte les règles du store).

## Point d'attention réel avant de soumettre

Le serveur local n'a **aucune authentification** conçue pour un usage
multi-utilisateur/public. Pour un usage personnel/desktop mono-utilisateur
(ce à quoi l'app est destinée aujourd'hui), ce n'est pas un problème. Mais la
certification Microsoft peut poser des questions si l'app semble gérer des
données sensibles sans protection — sois prêt à expliquer le modèle
"tout reste en local sur la machine de l'utilisateur, à usage personnel/mono-poste".
