"""Real local LLM stack verification. Never reports READY from configuration alone."""
from __future__ import annotations
import importlib
import json
import platform
from pathlib import Path

REQUIRED = ("transformers", "peft", "datasets", "accelerate")
OPTIONAL_QLORA = "bitsandbytes"

def main():
    result = {"status": "REAL", "python": platform.python_version(), "dependencies": {}, "note": ""}
    for name in REQUIRED + (OPTIONAL_QLORA, "torch"):
        try:
            m = importlib.import_module(name)
            result["dependencies"][name] = {"installed": True, "version": getattr(m, "__version__", "unknown")}
        except Exception as e:
            result["dependencies"][name] = {"installed": False, "reason": str(e)}
    cfg = Path("workspace/llm_models/llm_config.json")
    if cfg.exists():
        result["generation_config"] = json.loads(cfg.read_text(encoding="utf-8"))
    else:
        result["generation_config"] = "NOT_CREATED_YET"
    required_ok = all(result["dependencies"][x]["installed"] for x in REQUIRED + ("torch",))
    result["lora_ready"] = required_ok
    result["qlora_ready"] = required_ok and result["dependencies"][OPTIONAL_QLORA]["installed"]
    if not required_ok:
        result["status"] = "UNAVAILABLE"
        result["note"] = "Le stack n'est pas réellement installé dans cet environnement; lancer AlphaPrime déclenche l'installation automatique."
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if required_ok else 2

if __name__ == "__main__":
    raise SystemExit(main())
