#!/usr/bin/env python3
"""Report the actual local LLM backends/models visible to a workspace."""
import argparse, json
from ai_training_os.llm_provider import LocalLLMProvider

p=argparse.ArgumentParser(); p.add_argument('--workspace',default='./workspace'); a=p.parse_args()
status=LocalLLMProvider(a.workspace).status()
print(json.dumps(status,ensure_ascii=False,indent=2))
