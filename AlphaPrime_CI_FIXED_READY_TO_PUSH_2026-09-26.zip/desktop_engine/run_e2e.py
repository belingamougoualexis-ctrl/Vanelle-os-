"""Run the real local E2E workflow on a temporary workspace.

Nothing is persisted into the source tree. Fixture data are marked TEST and are
never copied into the production workspace unless this script is explicitly run.
"""
import json
import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ai_training_os import AITrainingOS


def main():
    project_root = os.path.dirname(os.path.abspath(__file__))
    fixture = os.path.join(project_root, "fixtures", "sample_dataset.csv")

    with tempfile.TemporaryDirectory(prefix="aitos_e2e_") as tmp:
        app = AITrainingOS(os.path.join(tmp, "workspace"))
        pid = app.create_project("E2E TEST — Classification locale")

        result = app.orchestrator.run_tabular_classification(
            pid,
            fixture,
            "Dataset E2E TEST",
            "Model E2E TEST",
            "sgd_incremental",
            3,
            security_policy={"max_prediction_flip_rate": 1.0},
        )
        if result.get("status") != "REAL":
            raise RuntimeError(f"E2E training failed: {result}")

        synth = app.synthetic_lab.generate_bootstrap(result["dataset_version_id"], 5, 42)
        champion = app.champion_challenger.set_champion(pid, result["model_version_id"])
        comparison = app.champion_challenger.compare(
            result["model_version_id"], result["model_version_id"], [result["evaluation_id"]]
        )
        export_zip = os.path.join(tmp, "project_export.zip")
        export = app.exporter.export(pid, export_zip)
        imported_ws = os.path.join(tmp, "imported_project")
        imported = app.exporter.import_project(export_zip, imported_ws)
        backup_zip = os.path.join(tmp, "workspace_backup.zip")
        backup = app.disaster_recovery.backup(backup_zip)
        backup_verify = app.disaster_recovery.verify(backup_zip)
        restore_ws = os.path.join(tmp, "restored_workspace")
        restored = app.disaster_recovery.restore(backup_zip, restore_ws)
        deployment_export = app.deployment.export(result["model_version_id"], os.path.join(tmp, "model_export"))
        deployment = app.deployment.deploy_local(result["model_version_id"], os.path.join(tmp, "deploy_live"))
        unavailable_remote = app.deployment.unavailable_remote("REMOTE_GPU_TEST")

        report = {
            "status": "REAL",
            "workspace_is_temporary": True,
            "project_id": pid,
            "dataset_version_id": result["dataset_version_id"],
            "model_version_id": result["model_version_id"],
            "experiment_id": result["experiment_id"],
            "training": result["training"],
            "evaluation_id": result["evaluation_id"],
            "error_clusters": result["error_clusters"],
            "red_team": result["red_team"],
            "safety_gate": result["safety_gate"],
            "artifacts": result["artifacts"],
            "cost_estimate": result["cost_estimate"],
            "cost_actual": result["cost_actual"],
            "synthetic": synth,
            "champion": champion,
            "comparison": comparison,
            "project_export": export,
            "project_import": imported,
            "backup": backup,
            "backup_verify": backup_verify,
            "restore": restored,
            "deployment_export": deployment_export,
            "deployment": deployment,
            "remote_deployment_example": unavailable_remote,
            "compute": app.dashboard()["compute"],
            "local_llm": app.llm_provider.status(),
        }
        print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
