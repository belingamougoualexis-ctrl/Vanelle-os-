# AI Training OS — Audit final Reality / Recovery

Date de l'audit : 25 septembre 2026
Projet audité : `AI Training OS / AlphaPrime`
Source : archive existante fournie par l'utilisateur

## 1. Principe d'audit

Aucune capacité critique n'est considérée opérationnelle par simple détection, configuration ou déclaration de l'IA. La chaîne de preuve est :

`Détecter → Vérifier → Tester réellement → Valider → Surveiller`

En cas d'échec de réparation :

`Diagnostiquer → correction candidate sûre → sauvegarde → appliquer → retester → rollback si nécessaire`

Les environnements matériellement absents sont explicitement `NOT VERIFIED` ou `DEGRADED`.

## 2. Conservation du projet existant

L'archive a d'abord été extraite et comparée avec la copie de travail avant les modifications.

Aucun fichier source fonctionnel présent uniquement dans l'archive d'origine n'a été supprimé. Les différences hors caches générés sont uniquement des modifications ciblées ou des ajouts liés au moteur Reality/Recovery, à la validation, à l'interface, aux tests et à la CI.

Les fonctionnalités existantes ont été conservées : Data Engine, Model Registry, Training Engine, Evaluation, Auto Lab, Red Team, AI Council, AI Scientist, Compute Planner, Model Manager, Recovery, Security, Enterprise/Governance, Delivery, Deployment, Continuous Training, UI et compagnon mobile.

## 3. Composants ajoutés/intégrés

- `ai_training_os/truth.py` — états officiels et hiérarchie des preuves.
- `ai_training_os/hardware_reality.py` — profil machine + tests CPU/CUDA/MPS réels.
- `ai_training_os/adaptive_config.py` — configuration basée sur ressources mesurées.
- `ai_training_os/reality_tests.py` — orchestrateur de vérification locale.
- `ai_training_os/diagnostic_engine.py` — diagnostics factuels + hypothèses avec confiance.
- `ai_training_os/self_healing.py` — réparations réversibles avec backup/rollback.
- `ai_training_os/canary.py` — validation candidate avant activation.
- `ai_training_os/health_monitor.py` — monitoring continu local pendant les opérations.
- `ai_training_os/research_engine.py` — provenance des informations Internet sans exécution aveugle.
- `tests/test_reality_system.py` — validation centrale Reality.
- `tests/test_reality_api.py` — routes HTTP Reality locales réelles.
- `tests/test_reality_stress.py` — répétitions d'inférence/rechargement.
- `.github/workflows/desktop-platforms.yml` — matrice CI Windows/macOS/Linux.

Le `TrainingEngine` existant a été enrichi sans être remplacé : preuve de checkpoint, hash du modèle final, validation post-entraînement et journal de santé.

## 4. Correction importante de compatibilité

`ai_training_os/safety_gate.py` contenait une f-string Python incompatible avec Python 3.11 à cause de guillemets imbriqués. La syntaxe a été corrigée et `compileall` passe.

Le workflow Windows a également été restructuré pour localiser directement `desktop_engine` ou le moteur AlphaPrime présent dans le dépôt, au lieu d'exiger la présence d'un ZIP à la racine. Cela corrige le type d'erreur observé lorsque `requirements.txt` était imbriqué.

## 5. Test matériel réel de l'environnement d'audit

Environnement réellement disponible :

| Capacité | Résultat | Preuve / limite |
|---|---|---|
| OS | VERIFIED | Linux 6.18.44 |
| Architecture | VERIFIED | x86_64 / 64-bit |
| Python | VERIFIED | 3.13.5 |
| CPU | VERIFIED | Intel(R) Xeon(R) Platinum 8370C @ 2.80GHz |
| Cœurs physiques | VERIFIED | 3 mesurés |
| Threads logiques | VERIFIED | 3 mesurés |
| RAM | VERIFIED | ~5.95 GB total, mesure locale |
| Stockage | VERIFIED | ~29.33 GB libres pendant l'audit |
| GPU physique | NOT VERIFIED | Aucun GPU physique disponible dans l'environnement |
| CUDA | NOT VERIFIED | `torch.cuda.is_available()` = false |
| MPS | NOT VERIFIED | non disponible |
| ROCm | NOT VERIFIED | runtime ROCm absent |
| PyTorch | VERIFIED | 2.10.0+cpu |
| Backend d'entraînement courant | VERIFIED | CPU |
| Framework CPU | VERIFIED | PyTorch présent + smoke-test réel réussi |

Le profil machine est sauvegardé sous `machine_profile.json` dans le workspace et son fingerprint sert à détecter les changements d'environnement.

## 6. Reality Test Engine

Le test complet exécuté dans l'environnement d'audit a donné `DEGRADED`, et non `VERIFIED`, car deux limites réelles sont présentes :

1. aucun GPU physique disponible pour effectuer un test GPU ;
2. le runtime d'audit ne contient pas `transformers`, `peft`, `datasets` et `accelerate`, donc le LLM local n'est pas déclaré vérifié.

Tests réellement réussis dans ce même passage : CPU compute, système de fichiers/UTF-8, CPU fallback réel et configuration adaptative au niveau ressources.

## 7. Test offline

`offline_smoke()` a exécuté une vraie opération locale du Data Engine pendant que les connexions socket étaient bloquées.

Résultat : `VERIFIED` avec 4 lignes de dataset réellement traitées et 0 tentative réseau.

## 8. Auto-configuration

Configuration mesurée dans l'environnement d'audit :

- device : `cpu`
- precision : `float32`
- batch size : `4`
- gradient accumulation : `4`
- context : `256`
- workers : `2`
- LoRA : rang `8`, alpha `16`, dropout `0.05`

La proposition a été soumise à un test d'allocation de ressources local avant d'être marquée `VERIFIED` au niveau ressources. Elle ne remplace pas la validation modèle/dataset par canary.

## 9. Dataset / modèle / entraînement

Les nouveaux tests valident réellement :

- présence et hash du dataset ;
- décodage UTF-8 ;
- parsing réel ;
- intégrité des splits ;
- présence d'un vrai batch ;
- qualité générique : lignes vides, doublons, population des champs ;
- présence et hash du modèle ;
- chargement réel ;
- inférence réelle ;
- unload/reload réel ;
- checkpoint réel ;
- hash du checkpoint ;
- validation du modèle final après entraînement ;
- journal de santé pendant le training.

Les checkpoints PyTorch sont chargés avec `weights_only=True`. Les pickles ne sont rechargés que pour des artefacts de training interne, sous `checkpoints/`, avec origine et hash enregistrés dans le registre.

## 10. Self-healing et canary

Le moteur de self-healing est volontairement limité à des opérations locales réversibles :

- créer un dossier ;
- nettoyer un fichier temporaire ;
- restaurer un backup ;
- remplacer une configuration JSON.

Chaque modification est précédée d'une sauvegarde lorsque c'est possible. Un test post-réparation doit réussir pour conserver le changement. Sinon le rollback est automatique.

Le test canary suit `candidate → test → commit`; un candidat rejeté n'est pas laissé actif.

## 11. Diagnostic et Internet

Le Diagnostic Engine sépare :

- faits issus de la machine actuelle ;
- hypothèses probables ;
- confiance ;
- contradictions.

Une hypothèse n'est jamais transformée en certitude par son seul texte.

Le Research Engine conserve la provenance des sources Internet et refuse l'exécution directe d'une commande trouvée sur le web. L'information Internet reste une entrée de recherche ; la validation de la machine vient des tests locaux.

## 12. Interface

Le dashboard contient maintenant une section `Reality & Recovery` qui expose :

- Digital Twin / refresh ;
- full local test ;
- offline test ;
- auto-configuration ;
- diagnostic ;
- canary de configuration ;
- provenance des recherches.

Le dashboard n'a pas de dépendance à des assets externes pour son fonctionnement local.

## 13. Validation automatique réalisée

### Suite complète pytest

Commande : `python -m pytest -q tests`

Résultat final observé :

**87 passed, 1 skipped, 5 warnings, 50.63 s**

Le scénario skipped est explicite et dépend du matériel : il teste le cas « moins de 2 cœurs CPU ». Il n'est pas applicable à l'environnement actuel qui en expose 3.

### Validation syntaxique

`python -m compileall -q ai_training_os tests` : **PASS**

### Validation JavaScript du dashboard

Extraction du script inline puis `node --check` : **PASS**

### Tests Reality ciblés

`tests/test_reality_system.py` : **6/6 PASS**

`tests/test_reality_api.py` : **1/1 PASS**

`tests/test_reality_stress.py` : **PASS**

`tests/test_reality_system.py + tests/test_reality_stress.py + tests/test_professional_suite.py` après les derniers correctifs : **14/14 PASS**

## 14. Limites non masquées

Les validations suivantes ne peuvent pas être annoncées comme physiquement réussies depuis cet environnement :

| Environnement | État |
|---|---|
| Windows x64 physique | NOT VERIFIED — ENVIRONMENT UNAVAILABLE |
| Windows ARM64 physique | NOT VERIFIED — ENVIRONMENT UNAVAILABLE |
| macOS Intel physique | NOT VERIFIED — ENVIRONMENT UNAVAILABLE |
| macOS Apple Silicon physique | NOT VERIFIED — ENVIRONMENT UNAVAILABLE |
| Linux x64 CPU | VERIFIED sur l'environnement d'audit |
| Linux ARM64 physique | NOT VERIFIED — ENVIRONMENT UNAVAILABLE |
| NVIDIA CUDA réel | NOT VERIFIED — GPU indisponible |
| AMD ROCm réel | NOT VERIFIED — GPU/runtime indisponible |
| Apple MPS réel | NOT VERIFIED — environnement indisponible |
| QLoRA/bitsandbytes CUDA | NOT VERIFIED — GPU CUDA indisponible |
| LLM local Transformers | NOT VERIFIED — dépendances/modèle non présents dans l'audit |

La CI prépare les jobs Windows/macOS/Linux et l'application sait conserver `NOT VERIFIED` tant qu'un runner réel n'a pas exécuté la capacité concernée.

## 15. Conclusion technique

L'architecture existante a été conservée et renforcée par une couche Reality/Recovery intégrée, plutôt que remplacée.

Le résultat important de l'audit n'est pas de déclarer artificiellement toutes les fonctions « vertes » : sur la machine d'audit, AI Training OS prouve réellement le chemin CPU/local/offline et refuse de prétendre que le GPU ou le LLM sont opérationnels lorsqu'ils ne sont pas vérifiables.

La contrainte principale restante avant une déclaration multi-plateforme complète est physique : exécuter les matrices Windows/macOS/ARM/GPU et le stack LLM sur les matériels correspondants.
