"""
build_executable.py — construit un exécutable natif (Windows .exe / macOS / Linux)
d'Alpha Prime avec PyInstaller.

IMPORTANT — à lire avant d'exécuter :
Cet environnement de développement n'a pas d'accès réseau sortant, donc ce
script n'a PAS pu être exécuté ni le binaire testé ici. Il doit être lancé
UNE FOIS, sur TA machine (celle où tu veux produire l'exécutable), avec une
connexion Internet active pour installer PyInstaller.

Utilisation :
    python3 build_executable.py

Résultat : un dossier dist/AlphaPrime/ contenant l'exécutable natif pour
ton système d'exploitation. Un exécutable Windows doit être construit sur
Windows (PyInstaller ne fait pas de cross-compilation), macOS sur macOS,
Linux sur Linux — c'est une contrainte réelle de PyInstaller, pas de ce
projet.
"""
from __future__ import annotations

import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(cmd):
    print("$", " ".join(cmd), flush=True)
    subprocess.run(cmd, check=True)


def main():
    print("[build] Installation de PyInstaller (nécessite une connexion Internet)...")
    run([sys.executable, "-m", "pip", "install", "--quiet", "pyinstaller"])
    print("[build] Installation de pywebview (fenêtre native)...")
    run([sys.executable, "-m", "pip", "install", "--quiet", "-r", str(ROOT / "requirements-desktop.txt")])

    print("[build] Installation du support IA local sans forcer un backend matériel...")
    print("[build] Le runtime distribué ne doit jamais écraser le PyTorch CUDA/ROCm/MPS "
          "déjà présent sur la machine de build. La capacité accélérée n'est déclarée "
          "qu'après une exécution réelle sur la machine cible.")
    run([sys.executable, "-m", "pip", "install", "--quiet", "-r", str(ROOT / "requirements-local-llm.txt")])

    entry = ROOT / "desktop_app.py"
    name = "AlphaPrime"

    args = [
        sys.executable, "-m", "PyInstaller",
        "--name", name,
        "--onedir",
        "--windowed",
        "--add-data", f"{ROOT / 'frontend'}{';' if platform.system() == 'Windows' else ':'}frontend",
        "--add-data", f"{ROOT / 'ai_training_os'}{';' if platform.system() == 'Windows' else ':'}ai_training_os",
        "--hidden-import", "ai_training_os",
        "--hidden-import", "webview",
        # transformers/torch/llama-cpp chargent beaucoup de sous-modules
        # dynamiquement ; --collect-all est nécessaire pour que PyInstaller
        # les embarque tous plutôt que de planter au premier import réel.
        "--collect-all", "torch",
        "--collect-all", "transformers",
        "--collect-all", "llama_cpp",
        str(entry),
    ]
    print(f"[build] Construction de l'exécutable pour {platform.system()}...")
    print("[build] Attention : avec le support IA locale inclus, ceci peut "
          "prendre plusieurs minutes et produire un fichier de plusieurs "
          "centaines de Mo à ~1-2 Go — normal vu ce qui est embarqué.")
    run(args)
    print(f"[build] Terminé. Exécutable dans : {ROOT / 'dist' / name}")
    print("[build] Vérifie toi-même que dist/AlphaPrime/AlphaPrime(.exe) démarre "
          "correctement avant de le distribuer — il n'a pas pu être testé "
          "automatiquement dans l'environnement où ce script a été généré.")


if __name__ == "__main__":
    main()
