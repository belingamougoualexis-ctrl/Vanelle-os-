# TEST FIXTURES

Ces fichiers sont exclusivement destinés aux tests automatisés et au script `run_e2e.py`.
Ils ne sont pas chargés au démarrage normal et aucun workspace de démonstration n'est inclus dans la distribution de production.

Les artefacts temporaires créés par les tests sont supprimés à la fin des tests. Le script E2E utilise lui aussi un dossier temporaire.
