import json
import threading
import urllib.request
import urllib.error

from ai_training_os.api_server import create_server


def _request(server, method, path, payload=None):
    url = f"http://127.0.0.1:{server.server_address[1]}{path}"
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=20) as response:
        return response.status, json.loads(response.read().decode("utf-8"))


def test_reality_api_routes_are_live_and_local(tmp_path):
    server = create_server(str(tmp_path), port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        code, profile = _request(server, "GET", "/api/reality/profile")
        assert code == 200
        assert profile["status"] in {"VERIFIED", "NOT VERIFIED", "TESTING"}

        code, offline = _request(server, "GET", "/api/reality/offline")
        assert code == 200
        assert offline["status"] == "VERIFIED"
        assert offline["network_attempts"] == []

        code, auto = _request(server, "GET", "/api/reality/auto-config")
        assert code == 200
        assert auto["candidate"]["device"] in {"cpu", "cuda", "mps"}

        code, diag = _request(server, "POST", "/api/reality/diagnose", {"error": "CUDA out of memory", "context": {"claimed_gpu": True}})
        assert code == 200
        assert diag["status"] == "TESTING"

        code, canary = _request(
            server,
            "POST",
            "/api/reality/canary/config",
            {"name": "resource-canary", "candidate": {"device": "cpu", "precision": "float32", "batch_size": 1}},
        )
        assert code == 200
        assert canary["status"] in {"VERIFIED", "FAILED", "RECOVERING"}
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
