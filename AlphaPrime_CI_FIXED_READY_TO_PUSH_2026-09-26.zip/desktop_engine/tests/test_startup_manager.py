import hashlib, json, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from ai_training_os.startup_manager import StartupManager


def _serve(payload: bytes):
    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path.startswith('/file'):
                if self.headers.get('Range'):
                    start=int(self.headers['Range'].split('=')[1].split('-')[0])
                    body=payload[start:]
                    self.send_response(206)
                    self.send_header('Content-Length', str(len(body)))
                    self.end_headers(); self.wfile.write(body); return
                self.send_response(200); self.send_header('Content-Length',str(len(payload))); self.end_headers(); self.wfile.write(payload); return
            self.send_response(404); self.end_headers()
        def log_message(self,*a): pass
    srv=HTTPServer(('127.0.0.1',0),H)
    threading.Thread(target=srv.serve_forever,daemon=True).start()
    return srv


def test_resources_declared_and_hashes():
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        m=StartupManager(td)
        r=m.resources()
        assert r['smollm2']['sha256']=='16c7f1667fea34bacad196a57b548effcb37614db4ab5677a20c8c7b823b9e63'
        assert r['nomic_embed']['sha256']=='d4e388894e09cf3816e8b0896d81d265b55e7a9fff9ab03fe8bf4ef5e11295ac'
        assert r['llama_runtime']['name']


def test_consent_required_then_starts(monkeypatch):
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        m=StartupManager(td)
        assert m.start()['bootstrap_status']=='CONSENT_REQUIRED'
        monkeypatch.setattr(m,'_run',lambda: None)
        out=m.consent_and_start()
        assert out['status']=='REAL'
        assert m.state['consent'] is True


def test_download_resumable_and_verified():
    import tempfile
    payload=b'AI Training OS real bootstrap data\n'*200
    srv=_serve(payload)
    try:
        with tempfile.TemporaryDirectory() as td:
            m=StartupManager(td)
            target=Path(td)/'downloads'/'sample.bin'
            got=m._download('sample','http://127.0.0.1:%d/file'%srv.server_port,target,hashlib.sha256(payload).hexdigest(),'unused')
            assert got.read_bytes()==payload
            assert m.state['resources']['sample']['status']=='READY'
            assert m.state['resources']['sample']['progress_percent']==100
    finally:
        srv.shutdown()
