import os, json, sys, zipfile
import pytest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os import AITrainingOS

@pytest.fixture
def system(tmp_path): return AITrainingOS(str(tmp_path / "aitos")), tmp_path

def test_end_to_end_workflow(system):
    app,tmp=system
    assert all(v==0 for k,v in app.dashboard()["counts"].items())
    pid=app.create_project("Workflow E2E")
    source=os.path.join(os.path.dirname(__file__),"..","fixtures","sample_dataset.csv")
    result=app.orchestrator.run_tabular_classification(pid,source,"Dataset","Classifier","sgd_incremental",3,security_policy={"max_prediction_flip_rate":1.0})
    assert result["status"]=="REAL"
    assert result["training"]["status"]=="COMPLETED"
    assert result["training"]["logs_path"] and os.path.isfile(result["training"]["logs_path"])
    assert app.datasets.verify_integrity(result["dataset_version_id"])
    assert result["evaluation_id"]
    assert result["red_team"]["status"] in ("COMPLETED","UNAVAILABLE")
    genome=result["model_genome"]; assert genome["status"]=="REAL" and genome["experiments"] and genome["checkpoints"]
    synth=app.synthetic_lab.generate_bootstrap(result["dataset_version_id"],5,7); assert synth["status"]=="REAL" and synth["synthetic"] is True
    cc=app.champion_challenger.set_champion(pid,result["model_version_id"]); assert cc["status"]=="REAL"
    cmp=app.champion_challenger.compare(result["model_version_id"],result["model_version_id"],[result["evaluation_id"]]); assert cmp["automatic_replacement"] is False
    export=str(tmp/"project_export.zip"); manifest=app.exporter.export(pid,export); assert os.path.isfile(export) and manifest["project_id"]==pid
    verify=app.exporter.verify_and_import(export,str(tmp/"imported")); assert verify["integrity"]=="OK"
    dep=app.deployment.export(result["model_version_id"],str(tmp/"deploy")); assert dep["status"]=="REAL" and os.path.isfile(dep["model_path"])
    assert result["safety_gate"]["final_status"].startswith("PENDING")
    approval=app.safety_gate.approve(result["model_version_id"],"local-reviewer","Automated checks reviewed locally")
    assert approval["approval_status"]=="APPROVED"
    deployed=app.deployment.deploy_local(result["model_version_id"],str(tmp/"deploy_live")); assert deployed["deployment_status"]=="DEPLOYED"
    backup=str(tmp/"backup.zip"); b=app.disaster_recovery.backup(backup); assert b["status"]=="REAL" and app.disaster_recovery.verify(backup)["integrity"]=="OK"
    restored=app.disaster_recovery.restore(backup,str(tmp/"restore")); assert restored["status"]=="REAL" and restored["integrity"]=="OK"
    assert app.security.validate_path(result["training"]["logs_path"],True)["allowed"] is True
    assert app.security.code_execution_status()["status"]=="UNAVAILABLE"
