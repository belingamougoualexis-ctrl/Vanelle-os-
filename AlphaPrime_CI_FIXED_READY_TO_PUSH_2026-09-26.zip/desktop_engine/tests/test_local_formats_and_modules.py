import os, sys, json
import pytest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os import AITrainingOS
from ai_training_os import data_engine

def test_local_format_adapters_and_system_modules(tmp_path):
    app=AITrainingOS(str(tmp_path/"ws")); pid=app.create_project("formats")
    # PNG adapter: real file metadata, no fake decoding.
    from PIL import Image
    png=tmp_path/"sample.png"; Image.new("RGB",(12,8)).save(png)
    ds=app.datasets.create_dataset(pid,"image",str(png)); dsv,res=app.datasets.import_version(ds,str(png)); assert res["metadata"]["adapter"]=="PIL" and res["n_rows"]==1
    assert app.model_engine.plan("classification",{"n_rows":10},{"selected_tier":"CPU_ONLY"})["status"]=="REAL"
    assert app.orchestrator.inspect()["status"]=="REAL"
    assert app.observability.snapshot(str(tmp_path/"ws"))["status"]=="REAL"

def test_pdf_adapter_when_dependency_present(tmp_path):
    if not data_engine.capabilities()["adapters"].get("pdf"): pytest.skip("pypdf absent")
    from pypdf import PdfWriter
    pdf=tmp_path/"a.pdf"; w=PdfWriter(); w.add_blank_page(width=100,height=100)
    with open(pdf,"wb") as f:w.write(f)
    out=data_engine.run_pipeline(str(pdf),str(tmp_path/"storage"),"ds",1)
    assert out["metadata"]["adapter"]=="pypdf" and out["n_rows"]==1
