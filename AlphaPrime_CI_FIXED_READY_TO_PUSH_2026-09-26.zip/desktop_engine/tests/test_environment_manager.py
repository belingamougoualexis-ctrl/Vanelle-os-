import sys
sys.path.insert(0,'.')
from ai_training_os.environment.scanner import plan


def test_gpu_without_torch_cuda_is_not_ready():
    sample={
      'gpu':{'devices':[{'vendor':'NVIDIA','name':'Test GPU'}]},
      'drivers':{'nvidia':{'installed':True}},
      'frameworks':{'torch':{'installed':True,'cuda_available':False}},
      'training_runtime':{'backend':'GPU_DRIVER_ONLY','ready':False},
    }
    p=plan(sample)
    assert p['ready'] is False
    assert 'PYTORCH_CUDA_RUNTIME' in p['missing']


def test_cpu_machine_has_no_fake_gpu_dependency():
    sample={'gpu':{'devices':[]},'drivers':{},'frameworks':{'torch':{'installed':True,'cuda_available':False}},'training_runtime':{'backend':'CPU','ready':False}}
    p=plan(sample)
    assert p['ready'] is False
    assert 'NVIDIA_DRIVER' not in p['missing']
