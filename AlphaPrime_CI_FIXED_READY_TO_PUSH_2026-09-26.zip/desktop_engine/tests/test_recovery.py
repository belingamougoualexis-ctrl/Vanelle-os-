import os, json, sys
import pytest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os import AITrainingOS

@pytest.fixture
def system(tmp_path): return AITrainingOS(str(tmp_path / "aitos"))

def test_resume_from_last_valid_checkpoint_is_real(system, tmp_path):
    pid=system.create_project("Recovery")
    ds=os.path.join(os.path.dirname(__file__),"..","fixtures","sample_dataset.csv")
    d=system.datasets.create_dataset(pid,"DS",ds); dv_id,_=system.datasets.import_version(d,ds); dv=system.datasets.get_version(dv_id); split=json.loads(dv["split_json"]); rows=[json.loads(l) for l in open(dv["file_path"],encoding="utf-8")]
    def build(ix):
        X=[]; y=[]
        for i in ix:
            r=rows[i]
            if r.get("x1") in (None,"") or r.get("x2") in (None,"") or r.get("label") in (None,""): continue
            X.append([float(r["x1"]),float(r["x2"])]); y.append(int(float(r["label"])))
        return X,y
    Xt,yt=build(split["train"]); Xv,yv=build(split["val"]+split["test"])
    mid=system.models.create_model(pid,"Recovery model","sgd"); mvid=system.models.create_version(mid,dv_id,{"code_version":"recovery"},{"model_type":"sgd_incremental","n_epochs":4},{"provider":"LOCAL_CPU_PROVIDER"})
    exp=system.experiments.create(pid,None,dv_id,mvid,"LOCAL_CPU_PROVIDER",{})
    first=system.training.run(exp,"LOCAL_CPU_PROVIDER",{"X_train":Xt,"y_train":yt,"X_val":Xv,"y_val":yv,"model_type":"sgd_incremental","n_epochs":4,"stop_after_epoch":2})
    assert first["status"]=="PAUSED"
    job_id=first["job_id"]; ck=system.jobs.get_last_valid_checkpoint(job_id); assert ck and ck["epoch"]==2
    resume=system.training.resume(job_id)
    assert resume["status"]=="REAL" and resume["operation"]=="RESUMED" and resume["from_epoch"]==2
    assert resume["result"]["status"]=="COMPLETED"
    new_job=system.jobs.get(resume["result"]["job_id"]); assert new_job["status"]=="COMPLETED"
