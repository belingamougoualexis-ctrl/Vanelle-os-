import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os.compute_planner import SmartComputePlanner
from ai_training_os.providers import get_provider
from ai_training_os import compute


def test_torch_backend_detection_is_honest():
    backend = compute.detect_torch_backend()
    assert backend["status"] in ("REAL", "UNAVAILABLE")
    if backend["status"] == "UNAVAILABLE":
        assert "reason" in backend


def test_local_gpu_provider_matches_real_hardware():
    """
    Sur CETTE machine (sans PyTorch/GPU au moment du build), le provider
    doit honnêtement se déclarer indisponible — jamais l'inverse.
    """
    provider = get_provider("LOCAL_GPU_PROVIDER")
    avail = provider.is_available()
    backend = compute.detect_torch_backend()
    assert avail["available"] == (backend["status"] == "REAL")


def test_local_gpu_provider_raises_when_unavailable():
    provider = get_provider("LOCAL_GPU_PROVIDER")
    if provider.is_available()["available"]:
        pytest.skip("Un GPU réel est disponible sur cette machine — ce test ne s'applique pas ici.")
    with pytest.raises(RuntimeError):
        provider.train({})


def test_local_multi_gpu_requires_at_least_two_gpus():
    provider = get_provider("LOCAL_MULTI_GPU_PROVIDER")
    avail = provider.is_available()
    backend = compute.detect_torch_backend()
    if backend["status"] == "REAL" and backend.get("backend") == "cuda" and backend.get("n_devices", 0) >= 2:
        assert avail["available"] is True
    else:
        assert avail["available"] is False


def test_smart_compute_planner_selects_real_tier():
    planner = SmartComputePlanner()
    result = planner.plan()
    assert result["selected_tier"] in ("MULTI_GPU", "SINGLE_GPU", "CPU_ONLY", "NONE")
    # Sur cette machine (pas de GPU, scikit-learn présent) -> doit retomber sur CPU_ONLY
    backend = compute.detect_torch_backend()
    if backend["status"] != "REAL":
        assert result["selected_tier"] == "CPU_ONLY"
        assert result["selected_provider"] == "LOCAL_CPU_PROVIDER"


def test_smart_compute_planner_evaluates_all_tiers_honestly():
    planner = SmartComputePlanner()
    result = planner.plan()
    tiers = {t["tier"]: t["available"] for t in result["all_tiers_evaluated"]}
    assert set(tiers.keys()) == {"MULTI_GPU", "SINGLE_GPU", "CPU_ONLY"}
    assert tiers["CPU_ONLY"] is True  # scikit-learn est installé dans cet environnement
