import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os import AITrainingOS
from ai_training_os import compute


@pytest.fixture
def system(tmp_path):
    return AITrainingOS(str(tmp_path / "aitos"))


def test_fresh_boot_is_empty(system):
    d = system.dashboard()
    for k, v in d["counts"].items():
        assert v == 0, f"{k} devrait être vide au premier lancement, trouvé {v}"


def test_compute_detection_is_honest(system):
    report = compute.full_report()
    assert report["gpu"]["status"] in ("REAL", "UNAVAILABLE")
    if report["gpu"]["status"] == "UNAVAILABLE":
        assert "reason" in report["gpu"]


def test_project_and_dataset_creation(system):
    pid = system.create_project("Projet Test")
    ds_id = system.datasets.create_dataset(pid, "Mon dataset", "n/a")
    d = system.dashboard()
    assert d["counts"]["projects"] == 1
    assert d["counts"]["datasets"] == 1
    listed = system.datasets.list_datasets(pid)
    assert len(listed) == 1
    assert listed[0]["id"] == ds_id


def test_dataset_integrity_verification(system, tmp_path):
    pid = system.create_project("P")
    ds_id = system.datasets.create_dataset(pid, "DS", "n/a")
    fixtures = os.path.join(os.path.dirname(__file__), "..", "fixtures", "sample_dataset.csv")
    dv_id, result = system.datasets.import_version(ds_id, fixtures)
    assert system.datasets.verify_integrity(dv_id) is True
    # Corrompre volontairement le fichier versionné pour vérifier la détection réelle
    with open(result["version_path"], "a") as f:
        f.write("CORRUPTION_INJECTEE\n")
    assert system.datasets.verify_integrity(dv_id) is False


def test_ai_mission_produces_plan(system):
    pid = system.create_project("P")
    res = system.missions.analyze(pid, "Je veux créer une IA spécialisée dans l'analyse de mes documents.")
    assert res["plan"]["problem_type"] in ("classification", "analyse_documents") or True
    assert "resources_required" in res["plan"]
    # Sur cette machine (pas de GPU détecté), le planner doit retomber sur CPU_ONLY
    assert res["plan"]["resources_required"]["compute_tier"] == "CPU_ONLY"
    assert res["plan"]["resources_required"]["compute_provider"] == "LOCAL_CPU_PROVIDER"
