import os
import re
import subprocess
from html.parser import HTMLParser

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DASHBOARD = os.path.join(ROOT, "frontend", "dashboard.html")


class _HTMLProbe(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = set()
        self.srcs = []
        self.hrefs = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if attrs.get("id"):
            self.ids.add(attrs["id"])
        if attrs.get("src"):
            self.srcs.append(attrs["src"])
        if attrs.get("href"):
            self.hrefs.append(attrs["href"])


def _read():
    with open(DASHBOARD, "r", encoding="utf-8") as f:
        return f.read()


def test_dashboard_structure_is_present_and_local_first():
    html = _read()
    parser = _HTMLProbe()
    parser.feed(html)
    for required in {"nav", "content", "project", "modeBtn", "refresh", "themeBtn", "collapseBtn", "mobileNav"}:
        assert required in parser.ids
    for label in ["Dashboard", "AI Mission", "AI Council", "Datasets", "Models", "Training", "Evaluation", "Compute", "Model Manager", "Deployment", "Security", "Recovery", "Settings"]:
        assert label in html
    assert "TRUTH-FIRST" in html and "LOCAL-FIRST" in html
    assert "Choix explicite" in html or "choisir une version" in html.lower()
    assert "LLM & Model Manager" in html
    assert "/assets/alpha-prime-eagle.jpg" in html
    assert "cause" in html and "solution" in html
    assert 'id="canaryJson"' in html and '>{"device":"cpu"' not in html
    assert 'value="production-regression"' not in html
    assert 'value="0.80"' not in html and 'value="0.70"' not in html


def test_dashboard_has_no_external_asset_dependency():
    html = _read()
    parser = _HTMLProbe()
    parser.feed(html)
    assert not [x for x in parser.srcs if re.match(r"https?://", x)]
    assert not [x for x in parser.hrefs if re.match(r"https?://", x)]


def test_dashboard_javascript_compiles_with_node():
    html = _read()
    match = re.search(r"<script>(.*?)</script>", html, flags=re.S)
    assert match, "Dashboard script block missing"
    js_path = os.path.join(ROOT, ".dashboard_ui_test.js")
    try:
        with open(js_path, "w", encoding="utf-8") as f:
            f.write(match.group(1))
        proc = subprocess.run(["node", "--check", js_path], capture_output=True, text=True)
        assert proc.returncode == 0, proc.stderr
    finally:
        try:
            os.remove(js_path)
        except FileNotFoundError:
            pass
