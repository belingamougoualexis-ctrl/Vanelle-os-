import json
import os
import sys
import threading
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os.api_server import create_server


def request(base, path, method="GET", payload=None):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(base + path, data=data, method=method, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=8) as r:
        return r.status, json.loads(r.read().decode("utf-8"))


def test_local_api_and_dashboard_are_live(tmp_path):
    server = create_server(str(tmp_path / "workspace"), "127.0.0.1", 0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{server.server_address[1]}"
    try:
        status, health = request(base, "/api/health")
        assert status == 200 and health["status"] == "REAL"

        status, dashboard = request(base, "/api/dashboard")
        assert status == 200
        assert dashboard["counts"]["projects"] == 0
        assert "council" in dashboard and "red_team" in dashboard and "scientist" in dashboard

        status, page = urllib.request.urlopen(base + "/", timeout=5).status, None
        assert status == 200

        status, created = request(base, "/api/projects", "POST", {"name": "API Project"})
        assert status == 201
        pid = created["project_id"]

        status, options = request(base, "/api/training/options?project_id=" + pid)
        assert status == 200
        assert options["status"] == "REAL"
        assert isinstance(options["dataset_versions"], list)
        assert isinstance(options["candidates"], list)

        try:
            request(base, "/api/training/options?project_id=missing-project")
            assert False, "missing project must fail"
        except urllib.error.HTTPError as exc:
            assert exc.code == 400
            err = json.loads(exc.read().decode("utf-8"))
            assert err["status"] == "FAILED"
            assert err["cause"] and err["solution"]

        with urllib.request.urlopen(base + "/assets/alpha-prime-eagle.jpg", timeout=5) as asset:
            assert asset.status == 200
            assert asset.headers.get("Content-Type", "").startswith("image/jpeg")

        status, mission = request(base, "/api/missions/analyze", "POST", {"project_id": pid, "raw_request": "classifier des emails"})
        assert status == 201
        assert mission["status"] == "REAL"

        status, council = request(base, "/api/council/convene", "POST", {"project_id": pid, "raw_request": "classifier des emails"})
        assert status == 200
        assert council["status"] in ("LLM REQUIRED", "COMPLETED")
        if council["status"] == "LLM REQUIRED":
            assert council["council"]["decisions"] == []

        status, evaluations = request(base, "/api/evaluations?project_id=" + pid)
        assert status == 200
        assert evaluations["evaluations"] == []

        status, reports = request(base, "/api/scientist/reports?project_id=" + pid)
        assert status == 200
        assert isinstance(reports["reports"], list)
    finally:
        server.shutdown()
        server.server_close()


def test_extended_read_only_api_surface(tmp_path):
    server = create_server(str(tmp_path / "workspace"), "127.0.0.1", 0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{server.server_address[1]}"
    paths = [
        "/api/system", "/api/capabilities/data", "/api/observability", "/api/jobs",
        "/api/experiments", "/api/datasets", "/api/dataset-versions", "/api/models",
        "/api/model-versions", "/api/local-models", "/api/champion", "/api/deployments",
        "/api/backups", "/api/auto-lab", "/api/synthetic", "/api/artifacts",
        "/api/continuous-training", "/api/security",
    ]
    try:
        for path in paths:
            status, payload = request(base, path)
            assert status == 200, (path, status, payload)
            assert isinstance(payload, dict) and "status" in payload, path
    finally:
        server.shutdown()
        server.server_close()
