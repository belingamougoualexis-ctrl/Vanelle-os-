import json, os, sys, threading, hashlib, zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import pytest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os import AITrainingOS
from ai_training_os.model_manager import ModelManager

FIXTURE=os.path.join(os.path.dirname(__file__),"..","fixtures","sample_dataset.csv")


def test_project_export_reconstructs_real_workspace(tmp_path):
    src_app=AITrainingOS(str(tmp_path/"src")); pid=src_app.create_project("Exportable")
    result=src_app.orchestrator.run_tabular_classification(pid,FIXTURE,"DS","Model","sgd_incremental",2)
    assert result["status"]=="REAL"
    export=str(tmp_path/"project.zip"); src_app.exporter.export(pid,export)
    dst=str(tmp_path/"dst")
    imported=src_app.exporter.import_project(export,dst)
    assert imported["status"]=="REAL" and imported["project_exists"] is True
    dst_app=AITrainingOS(dst)
    assert dst_app.conn.execute("SELECT COUNT(*) FROM projects WHERE id=?",(pid,)).fetchone()[0]==1
    dsv=dst_app.datasets.get_version(result["dataset_version_id"])
    assert dsv and os.path.isfile(dsv["file_path"])
    mv=dst_app.models.get_version(result["model_version_id"])
    assert mv and os.path.isfile(mv["file_path"])


def test_autolab_runs_real_callback_and_stops_on_objective(tmp_path):
    app=AITrainingOS(str(tmp_path/"ws")); pid=app.create_project("AutoLab")
    result=app.auto_lab.run(
        pid,
        {"max_experiments":3},
        lambda i, plan: app.orchestrator.run_tabular_classification(pid,FIXTURE,f"DS-{i}",f"M-{i}","logistic_regression",1),
        is_success=lambda r: float(r.get("training",{}).get("metrics",{}).get("accuracy",-1)) >= 0.0,
    )
    assert result["status"]=="REAL" and result["experiments"]==1 and result["stop_reason"]=="OBJECTIVE_REACHED"
    row=app.conn.execute("SELECT status,details_json FROM autolab_runs WHERE id=?",(result["id"],)).fetchone()
    assert row[0]=="COMPLETED"
    assert json.loads(row[1])["results"][0]["status"]=="REAL"


def test_model_manager_real_http_range_resume(tmp_path):
    payload=os.urandom(20000)
    source=tmp_path/"source.bin"; source.write_bytes(payload)
    sha=hashlib.sha256(payload).hexdigest()
    received_ranges=[]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_GET(self):
            data=source.read_bytes(); start=0
            rng=self.headers.get("Range")
            if rng:
                start=int(rng.split("=",1)[1].split("-",1)[0]); received_ranges.append(start)
            body=data[start:]
            self.send_response(206 if rng else 200)
            self.send_header("Content-Length",str(len(body)))
            if rng:self.send_header("Content-Range",f"bytes {start}-{len(data)-1}/{len(data)}")
            self.end_headers(); self.wfile.write(body)
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler); th=threading.Thread(target=server.serve_forever,daemon=True); th.start()
    try:
        mm=ModelManager(str(tmp_path/"models")); base=f"http://127.0.0.1:{server.server_address[1]}/model.bin"
        first=mm.download("m1",base,expected_sha256=sha,max_bytes=7000)
        assert first["status"]=="PAUSED" and first["bytes_downloaded"]==7000
        second=mm.download("m1",base,expected_sha256=sha)
        assert second["status"]=="REAL" and second["sha256"]==sha
        assert 7000 in received_ranges
        assert open(second["path"],"rb").read()==payload
    finally:
        server.shutdown(); server.server_close()


def test_restore_rejects_archive_path_traversal(tmp_path):
    bad=tmp_path/"bad.zip"
    with zipfile.ZipFile(bad,"w") as z:
        manifest={"status":"REAL","workspace":"x","created_at":"now","files":{}}
        z.writestr("backup_manifest.json",json.dumps(manifest))
        z.writestr("../escape.txt","bad")
    app=AITrainingOS(str(tmp_path/"ws"))
    result=app.disaster_recovery.restore(str(bad),str(tmp_path/"restore"))
    assert result["status"]=="FAILED"
    assert not (tmp_path/"escape.txt").exists()


def test_continuous_training_is_explicitly_proposed(tmp_path):
    app=AITrainingOS(str(tmp_path/"ws")); pid=app.create_project("CT")
    ds=app.datasets.create_dataset(pid,"DS",FIXTURE); dsv,_=app.datasets.import_version(ds,FIXTURE)
    out=app.continuous_training.create_cycle(pid,dsv)
    assert out["status"]=="PROPOSED" and out["previous_model_preserved"] is True
    row=app.conn.execute("SELECT status FROM continuous_training_runs WHERE id=?",(out["id"],)).fetchone()
    assert row[0]=="PROPOSED"


def test_security_path_confinement(tmp_path):
    app=AITrainingOS(str(tmp_path/"ws"))
    inside=tmp_path/"ws"/"safe.txt"; inside.write_text("ok")
    outside=tmp_path/"outside.txt"; outside.write_text("no")
    assert app.security.validate_path(str(inside), True)["allowed"] is True
    result=app.security.validate_path(str(outside), True)
    assert result["allowed"] is False and result["status"]=="FAILED"


def test_continuous_training_runs_real_pipeline_and_preserves_base(tmp_path):
    app=AITrainingOS(str(tmp_path/"ws")); pid=app.create_project("CT-Real")
    result=app.orchestrator.run_tabular_classification(pid,FIXTURE,"BaseDS","BaseModel","sgd_incremental",2,security_policy={"max_prediction_flip_rate":1.0})
    assert result["status"]=="REAL"
    base=result["model_version_id"]
    ct=app.continuous_training.run_tabular(app,pid,FIXTURE,"NewData","ContinuedModel",base,"sgd_incremental",3,{"max_prediction_flip_rate":1.0})
    assert ct["status"]=="REAL"
    assert ct["previous_model_preserved"] is True
    assert ct["new_model_version_id"] != base
    assert app.models.get_version(base)["status"] in ("VALIDATED","DEPLOYED","EVALUATING")
    row=app.conn.execute("SELECT status FROM continuous_training_runs WHERE id=?",(ct["cycle_id"],)).fetchone()
    assert row[0] in ("COMPLETED", "BLOCKED")
    assert ct["result"].get("training_method")=="CONTINUATION_FROM_CHECKPOINT"
