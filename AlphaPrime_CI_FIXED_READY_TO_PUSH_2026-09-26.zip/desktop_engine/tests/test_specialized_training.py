import os
import wave
import pytest
import numpy as np
from PIL import Image

from ai_training_os.data_engine import build_labeled_asset_manifest
from ai_training_os.core import AITrainingOS


@pytest.fixture
def system(tmp_path):
    return AITrainingOS(str(tmp_path / "aitos"))


def _make_audio(path, freq):
    sr=8000; t=np.arange(sr,dtype=np.float32)/sr; sig=(0.2*np.sin(2*np.pi*freq*t)).astype(np.float32)
    import soundfile as sf
    sf.write(path,sig,sr,format='WAV')


def _asset_folder(tmp_path, ext, n=8):
    root=tmp_path/'assets'
    for label, value in [('low',0),('high',1)]:
        d=root/label; d.mkdir(parents=True)
        for i in range(n//2):
            if ext=='.txt': (d/f'{i}{ext}').write_text(f"class {label} example {'alpha' if value==0 else 'omega'}",encoding='utf-8')
            elif ext=='.png':
                arr=np.zeros((24,24,3),dtype=np.uint8); arr[:]=20 if value==0 else 230; Image.fromarray(arr).save(d/f'{i}{ext}')
            elif ext=='.wav': _make_audio(d/f'{i}{ext}',220 if value==0 else 880)
    return root


def test_class_folder_text_pipeline_trains_real(tmp_path, system):
    root=_asset_folder(tmp_path,'.txt',10)
    pid=system.create_project('text assets')
    ds=system.datasets.create_dataset(pid,'text-assets',str(root))
    dv,_=system.datasets.import_version(ds,str(root))
    result=system.orchestrator.run_tabular_from_dataset_version(pid,dv,model_name='text-cls',model_type='auto',n_epochs=1)
    assert result['status']=='REAL'
    assert result['training']['status']=='COMPLETED'
    assert result['training']['truth_status']=='REAL'
    assert result['training']['model_format']=='pickle'
    assert os.path.isfile(result['training']['final_model_path'])
    assert result['layout']['modality']=='text'


def test_class_folder_image_pipeline_trains_real(tmp_path, system):
    root=_asset_folder(tmp_path,'.png',10)
    pid=system.create_project('image assets')
    ds=system.datasets.create_dataset(pid,'image-assets',str(root))
    dv,_=system.datasets.import_version(ds,str(root))
    result=system.orchestrator.run_tabular_from_dataset_version(pid,dv,model_name='image-cls',model_type='auto',n_epochs=1)
    assert result['status']=='REAL'
    assert result['layout']['modality']=='image'
    assert result['training']['status']=='COMPLETED'
    assert result['training']['truth_status']=='REAL'
