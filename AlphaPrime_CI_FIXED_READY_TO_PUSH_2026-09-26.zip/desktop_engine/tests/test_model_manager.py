import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os.model_manager import ModelManager, NetworkModelProvider


@pytest.fixture
def manager(tmp_path):
    return ModelManager(str(tmp_path / "models"))


def test_package_and_validate(manager, tmp_path):
    src = tmp_path / "fake_model.bin"
    src.write_bytes(os.urandom(10 * 1024 * 1024))  # 10 MB -> plusieurs shards réels de 4MB
    manifest = manager.package("model-1", str(src))
    assert manifest["n_shards"] == 3  # 4+4+2 MB

    result = manager.validate("model-1")
    assert result["status"] == "READY"
    assert result["missing_shards"] == []
    assert result["corrupted_shards"] == []


def test_corrupted_shard_detected_and_repaired(manager, tmp_path):
    src = tmp_path / "fake_model2.bin"
    src.write_bytes(os.urandom(5 * 1024 * 1024))
    manifest = manager.package("model-2", str(src))

    # Corrompre réellement le premier shard sur disque
    shard0_path = manifest["shards"][0]["path"]
    with open(shard0_path, "r+b") as f:
        f.write(b"CORRUPTION")

    result = manager.validate("model-2")
    assert result["status"] == "INCOMPLETE"
    assert 0 in result["corrupted_shards"]

    manager.repair_shard("model-2", 0, str(src))
    result2 = manager.validate("model-2")
    assert result2["status"] == "READY"


def test_missing_shard_detected(manager, tmp_path):
    src = tmp_path / "fake_model3.bin"
    src.write_bytes(os.urandom(5 * 1024 * 1024))
    manifest = manager.package("model-3", str(src))
    os.remove(manifest["shards"][1]["path"])
    result = manager.validate("model-3")
    assert result["status"] == "INCOMPLETE"
    assert 1 in result["missing_shards"]


def test_reassemble_matches_original(manager, tmp_path):
    src = tmp_path / "fake_model4.bin"
    original_bytes = os.urandom(9 * 1024 * 1024)
    src.write_bytes(original_bytes)
    manager.package("model-4", str(src))
    out_path = tmp_path / "reassembled.bin"
    result = manager.reassemble("model-4", str(out_path))
    assert result["matches_manifest"] is True
    assert out_path.read_bytes() == original_bytes


def test_network_provider_reports_real_failure_for_unreachable_endpoint(tmp_path):
    provider = NetworkModelProvider()
    result = provider.download("http://127.0.0.1:1/model.bin", str(tmp_path/"out.bin"))
    assert result["status"] == "FAILED"
