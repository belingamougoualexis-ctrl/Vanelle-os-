import os
import json
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os import AITrainingOS


@pytest.fixture
def trained_system(tmp_path):
    system = AITrainingOS(str(tmp_path / "aitos"))
    pid = system.create_project("Red Team Test")
    mission = system.missions.analyze(pid, "Je veux classifier des points en deux catégories")
    ds_id = system.datasets.create_dataset(pid, "Dataset", "n/a")
    fixture = os.path.join(os.path.dirname(__file__), "..", "fixtures", "sample_dataset.csv")
    dv_id, _ = system.datasets.import_version(ds_id, fixture)
    v = system.datasets.get_version(dv_id)
    split = json.loads(v["split_json"])
    records = [json.loads(l) for l in open(v["file_path"], encoding="utf-8")]

    def build(indices):
        X, y = [], []
        for i in indices:
            r = records[i]
            if r.get("x1") in (None, "") or r.get("x2") in (None, "") or r.get("label") in (None, ""):
                continue
            X.append([float(r["x1"]), float(r["x2"])])
            y.append(int(float(r["label"])))
        return X, y

    X_train, y_train = build(split["train"])
    X_val, y_val = build(split["val"] + split["test"])
    mid = system.models.create_model(pid, "Classifier", "sgd")
    mvid = system.models.create_version(mid, dv_id, {"code_version": "test"}, {"model_type": "sgd_incremental", "n_epochs": 2}, {"provider": "LOCAL_CPU_PROVIDER"})
    eid = system.experiments.create(pid, mission["mission_id"], dv_id, mvid, "LOCAL_CPU_PROVIDER", {})
    result = system.training.run(eid, "LOCAL_CPU_PROVIDER", {"X_train": X_train, "y_train": y_train, "X_val": X_val, "y_val": y_val, "model_type": "sgd_incremental", "n_epochs": 2})
    eval_id = system.evaluations.record(mvid, dv_id, result["metrics"])
    return system, pid, eval_id, mvid


def test_red_team_executes_real_numeric_attack(trained_system):
    system, pid, eval_id, mvid = trained_system
    result = system.red_team.run_for_evaluation(eval_id, pid)
    assert result["status"] == "COMPLETED"
    assert result["summary"]["label"] == "REAL"
    assert result["summary"]["n_tests"] > 0
    assert result["summary"]["model_sha256_verified"] is True
    row = system.conn.execute("SELECT COUNT(*) AS c FROM red_team_tests WHERE run_id=?", (result["id"],)).fetchone()
    assert row["c"] == result["summary"]["n_tests"]


def test_red_team_refuses_missing_model_artifact(tmp_path):
    system = AITrainingOS(str(tmp_path / "aitos"))
    pid = system.create_project("Unavailable Red Team")
    mid = system.models.create_model(pid, "No Artifact", "unknown")
    mvid = system.models.create_version(mid, None, {}, {}, {})
    eval_id = system.evaluations.record(mvid, "missing-dataset", {"accuracy": 0.5})
    result = system.red_team.run_for_evaluation(eval_id, pid)
    assert result["status"] == "UNAVAILABLE"
    assert "modèle" in result["summary"]["reason"]
