import json
import os
import tempfile
from pathlib import Path

from ai_training_os.core import AITrainingOS
from ai_training_os.truth import OFFICIAL_STATES, state_from_checks


FIXTURE = Path(__file__).resolve().parents[1] / "fixtures" / "sample_dataset.csv"


def test_official_state_rules_never_promote_unverified():
    assert {"VERIFIED", "DEGRADED", "NOT VERIFIED", "FAILED", "RECOVERING", "TESTING"}.issubset(OFFICIAL_STATES)
    assert state_from_checks([{"status": "VERIFIED"}, {"status": "NOT VERIFIED"}]) == "DEGRADED"
    assert state_from_checks([{"status": "NOT VERIFIED"}]) == "NOT VERIFIED"
    assert state_from_checks([{"status": "FAILED"}, {"status": "VERIFIED"}]) == "FAILED"


def test_hardware_reality_auto_config_and_offline():
    with tempfile.TemporaryDirectory(prefix="aitos-reality-test-") as td:
        app = AITrainingOS(td)
        full = app.reality.full_test(include_llm=False)
        assert full["truth_status"] == "REAL_LOCAL_TESTS"
        assert full["status"] in {"VERIFIED", "DEGRADED", "NOT VERIFIED"}
        names = {c["name"]: c["status"] for c in full["checks"]}
        assert names["cpu_real_compute"] == "VERIFIED"
        assert names["cpu_fallback_real_inference"] == "VERIFIED"
        assert str(full["profile"]["cpu"]["model"]).strip() not in {"", "0", "unknown"}

        auto = app.reality.auto_configure()
        assert auto["candidate"]["device"] in {"cpu", "cuda", "mps"}
        assert auto["validation"]["status"] in {"VERIFIED", "FAILED", "NOT VERIFIED"}

        offline = app.reality.offline_smoke()
        assert offline["status"] == "VERIFIED"
        assert offline["network_attempts"] == []


def test_dataset_and_model_validation_are_real():
    with tempfile.TemporaryDirectory(prefix="aitos-validate-test-") as td:
        app = AITrainingOS(td)
        pid = app.create_project("validation")
        dsv, _ = app.datasets.import_version(app.datasets.create_dataset(pid, "ds", str(FIXTURE)), str(FIXTURE))
        dval = app.reality.validate_dataset_version(dsv)
        assert dval["status"] == "VERIFIED"
        assert any(c["name"] == "real_batch" and c["status"] == "VERIFIED" for c in dval["checks"])

        result = app.orchestrator.run_tabular_from_dataset_version(
            pid, dsv, model_name="validation-model", model_type="logistic_regression", n_epochs=1
        )
        assert result["status"] == "REAL"
        assert result["training"]["checkpoint_proof"]["status"] == "VERIFIED"
        assert result["training"]["post_validation"]["status"] == "VERIFIED"
        mval = app.reality.validate_model_version(result["model_version_id"], run_inference=True)
        assert mval["status"] == "VERIFIED"
        assert any(c["name"] == "real_inference" and c["status"] == "VERIFIED" for c in mval["checks"])
        assert result["training"]["health_log_path"] and os.path.isfile(result["training"]["health_log_path"])


def test_safe_healing_rolls_back_on_failed_verification():
    with tempfile.TemporaryDirectory(prefix="aitos-heal-test-") as td:
        app = AITrainingOS(td)
        target = Path(td) / "config.json"
        target.write_text('{"stable": true}', encoding="utf-8")
        original = target.read_bytes()
        failed = app.healing.run(
            "replace_json_config", str(target), lambda: False, value={"stable": False}
        )
        assert failed["status"] == "FAILED"
        assert failed["operation_status"] == "ROLLED_BACK"
        assert target.read_bytes() == original
        assert app.conn.execute("SELECT COUNT(*) FROM repair_runs").fetchone()[0] >= 1


def test_canary_rejects_candidate_without_leaving_it_active():
    with tempfile.TemporaryDirectory(prefix="aitos-canary-test-") as td:
        app = AITrainingOS(td)
        target = Path(td) / "candidate.json"
        target.write_text('{"active": false}', encoding="utf-8")
        previous = target.read_bytes()
        candidate = {"active": True}
        applied = {"value": None}

        def apply(x):
            applied["value"] = x
            target.write_text(json.dumps(x), encoding="utf-8")

        def rollback():
            target.write_bytes(previous)

        result = app.canary.run("test-rejection", candidate, lambda _: False, apply, rollback)
        assert result["status"] == "FAILED"
        assert result["operation_status"] == "REJECTED"
        assert applied["value"] is None
        assert target.read_bytes() == previous


def test_canary_rolls_back_when_post_apply_verification_fails():
    with tempfile.TemporaryDirectory(prefix="aitos-canary-postverify-") as td:
        app = AITrainingOS(td)
        target = Path(td) / "candidate.json"
        previous = b'{"active": false}'
        target.write_bytes(previous)

        def apply(x):
            target.write_text(json.dumps(x), encoding="utf-8")

        def rollback():
            target.write_bytes(previous)

        result = app.canary.run(
            "post-verify", {"active": True}, lambda _: True, apply, rollback,
            verify_after_apply=lambda: False,
        )
        assert result["status"] == "FAILED"
        assert result["operation_status"] == "ROLLED_BACK"
        assert target.read_bytes() == previous


def test_diagnostic_and_research_are_evidence_first():
    with tempfile.TemporaryDirectory(prefix="aitos-diag-test-") as td:
        app = AITrainingOS(td)
        diag = app.diagnostics.diagnose("CUDA out of memory", {"claimed_gpu": True})
        assert diag["status"] == "TESTING"
        assert any(h["cause"] == "MEMORY_PRESSURE" for h in diag["hypotheses"])

        blocked = app.research.fetch("file:///etc/passwd")
        assert blocked["status"] == "FAILED"
        recorded = app.research.record_source("https://example.com/docs", "Example documentation", version="1")
        assert recorded["status"] == "REAL"
        assert app.conn.execute("SELECT COUNT(*) FROM research_sources").fetchone()[0] == 1
