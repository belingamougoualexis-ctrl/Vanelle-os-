import os
import sys
import json
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os import AITrainingOS


@pytest.fixture
def scientist_system(tmp_path):
    system = AITrainingOS(str(tmp_path / "aitos"))
    pid = system.create_project("Scientist Test")
    mission = system.missions.analyze(pid, "Je veux classifier des points en deux catégories")
    ds_id = system.datasets.create_dataset(pid, "Dataset", "n/a")
    fixture = os.path.join(os.path.dirname(__file__), "..", "fixtures", "sample_dataset.csv")
    dv_id, _ = system.datasets.import_version(ds_id, fixture)
    v = system.datasets.get_version(dv_id)
    split = json.loads(v["split_json"])
    records = [json.loads(l) for l in open(v["file_path"], encoding="utf-8")]

    def build(indices):
        X, y = [], []
        for i in indices:
            r = records[i]
            if r.get("x1") in (None, "") or r.get("x2") in (None, "") or r.get("label") in (None, ""):
                continue
            X.append([float(r["x1"]), float(r["x2"])])
            y.append(int(float(r["label"])))
        return X, y

    X_train, y_train = build(split["train"])
    X_val, y_val = build(split["val"] + split["test"])
    mid = system.models.create_model(pid, "Classifier", "sgd")
    mvid = system.models.create_version(mid, dv_id, {"code_version": "test"}, {"model_type": "sgd_incremental", "n_epochs": 2}, {"provider": "LOCAL_CPU_PROVIDER"})
    for idx in (1, 2):
        eid = system.experiments.create(pid, mission["mission_id"], dv_id, mvid, "LOCAL_CPU_PROVIDER", {"trial": idx})
        result = system.training.run(eid, "LOCAL_CPU_PROVIDER", {"X_train": X_train, "y_train": y_train, "X_val": X_val, "y_val": y_val, "model_type": "sgd_incremental", "n_epochs": idx})
        system.evaluations.record(mvid, dv_id, result["metrics"])
    return system, pid


def test_scientist_analyzes_real_experiment_history(scientist_system):
    system, pid = scientist_system
    report = system.scientist.analyze(pid)
    assert report["status"] == "REAL"
    assert report["completed_experiments"] == 2
    assert report["observations"]
    assert report["hypotheses"]
    assert all(h["status"] == "PROPOSED" for h in report["hypotheses"])
    row = system.conn.execute("SELECT * FROM scientist_reports WHERE id=?", (report["id"],)).fetchone()
    assert row is not None


def test_scientist_status_never_fakes_llm(tmp_path):
    system = AITrainingOS(str(tmp_path / "aitos"))
    st = system.scientist.status()
    assert st["status"] == "READY"
    assert st["generative_hypotheses"] in ("READY", "UNAVAILABLE")
