import os
import sys
import shutil
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os import data_engine

FIXTURES = os.path.join(os.path.dirname(__file__), "..", "fixtures")


@pytest.fixture
def tmp_storage(tmp_path):
    return str(tmp_path)


def test_run_pipeline_real(tmp_storage):
    src = os.path.join(FIXTURES, "sample_dataset.csv")
    result = data_engine.run_pipeline(src, tmp_storage, "ds-test", 1)
    assert result["n_rows"] > 0
    assert result["n_duplicates_removed"] >= 2  # 2 doublons injectés volontairement
    assert os.path.exists(result["version_path"])
    # Le hash doit correspondre au fichier réellement écrit sur disque
    from ai_training_os import utils
    assert utils.sha256_file(result["version_path"]) == result["sha256"]


def test_original_never_modified(tmp_storage):
    src = os.path.join(FIXTURES, "sample_dataset.csv")
    with open(src, "rb") as f:
        original_bytes_before = f.read()
    data_engine.run_pipeline(src, tmp_storage, "ds-test2", 1)
    with open(src, "rb") as f:
        original_bytes_after = f.read()
    assert original_bytes_before == original_bytes_after


def test_corrupted_file_detected(tmp_storage):
    src = os.path.join(FIXTURES, "corrupted.csv")
    result = data_engine.run_pipeline(src, tmp_storage, "ds-corrupt", 1)
    # La ligne malformée doit être détectée et exclue, pas plantée silencieusement
    assert result["n_corrupted_rows"] >= 1
    assert result["n_rows"] == 2  # 2 lignes valides restantes


def test_unsupported_extension_raises(tmp_storage, tmp_path):
    bad_file = tmp_path / "data.xyz"
    bad_file.write_text("nope")
    with pytest.raises(data_engine.DataValidationError):
        data_engine.run_pipeline(str(bad_file), tmp_storage, "ds-bad", 1)


def test_missing_source_raises(tmp_storage):
    with pytest.raises(data_engine.DataValidationError):
        data_engine.run_pipeline("/nonexistent/file.csv", tmp_storage, "ds-missing", 1)
