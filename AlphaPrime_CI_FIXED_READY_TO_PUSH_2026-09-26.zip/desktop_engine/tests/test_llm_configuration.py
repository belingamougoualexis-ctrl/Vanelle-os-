from pathlib import Path
import json

from ai_training_os.llm_config import load_or_create, profile


def test_generation_config_is_created_and_has_task_profiles(tmp_path):
    cfg = load_or_create(tmp_path / "llm_config.json")
    assert cfg["runtime"]["context_size"] >= 2048
    assert cfg["runtime"]["repeat_penalty"] >= 1.0
    for task in ("council", "scientist", "verification", "general"):
        p = profile(cfg, task)
        assert p["max_tokens"] > 0
        assert 0 <= p["temperature"] <= 2
        assert 0 < p["top_p"] <= 1


def test_provider_persists_generation_config(tmp_path):
    from ai_training_os.llm_provider import LocalLLMProvider
    p = LocalLLMProvider(str(tmp_path))
    assert Path(p.config_path).exists()
    assert p.generation_profile("council")["temperature"] == 0.15
    data = json.loads(Path(p.config_path).read_text(encoding="utf-8"))
    assert data["profiles"]["scientist"]["max_tokens"] == 750
