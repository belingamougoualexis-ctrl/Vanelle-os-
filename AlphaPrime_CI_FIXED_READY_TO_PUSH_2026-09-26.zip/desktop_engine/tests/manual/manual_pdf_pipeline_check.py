import os
import tempfile


def test_pdf_pipeline_real():
    from reportlab.pdfgen import canvas
    from ai_training_os.core import AITrainingOS
    with tempfile.TemporaryDirectory() as td:
        root=os.path.join(td,"pdf_assets")
        for label,text in (("spam","urgent offer buy now"),("ham","team meeting project update")):
            d=os.path.join(root,label); os.makedirs(d)
            for i in range(4):
                path=os.path.join(d,f"sample_{i}.pdf")
                c=canvas.Canvas(path); c.drawString(72,720,text); c.save()
        app=AITrainingOS(os.path.join(td,"aitos")); pid=app.create_project("pdf")
        ds=app.datasets.create_dataset(pid,"pdf",root); dv,_=app.datasets.import_version(ds,root)
        result=app.orchestrator.run_tabular_from_dataset_version(pid,dv,model_name="pdf",model_type="auto",n_epochs=1)
        assert result["status"]=="REAL"
        assert result["layout"]["modality"]=="pdf"
        assert result["training"]["status"]=="COMPLETED"
        assert result["training"]["truth_status"]=="REAL"
