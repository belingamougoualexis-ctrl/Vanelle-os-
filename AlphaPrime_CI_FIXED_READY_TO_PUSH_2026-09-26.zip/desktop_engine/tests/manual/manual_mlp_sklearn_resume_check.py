import os
import tempfile


def test_mlp_sklearn_resume_real():
    import numpy as np
    from ai_training_os.providers.local_cpu import LocalCPUProvider
    X=[[0,0],[0,1],[1,0],[1,1],[0.1,0.1],[0.9,0.2],[0.2,0.9],[0.8,0.8]]
    y=["a","a","b","b","a","b","a","b"]
    with tempfile.TemporaryDirectory() as td:
        provider=LocalCPUProvider()
