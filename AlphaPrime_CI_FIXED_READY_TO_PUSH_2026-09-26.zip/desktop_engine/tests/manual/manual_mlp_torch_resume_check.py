import os
import tempfile


def test_mlp_torch_resume_real():
    from ai_training_os.providers.local_cpu import LocalCPUProvider, TrainingInterrupted
    X=[[0,0],[0,1],[1,0],[1,1],[0.1,0.1],[0.9,0.2],[0.2,0.9],[0.8,0.8]]
    y=["a","a","b","b","a","b","a","b"]
    with tempfile.TemporaryDirectory() as td:
        provider=LocalCPUProvider()
        cfg={"X_train":X,"y_train":y,"X_val":X,"y_val":y,"model_type":"mlp_torch","task_type":"classification","n_epochs":2,"checkpoint_dir":td,"torch_num_threads":1,"stop_after_epoch":1}
        try:
            provider.train(cfg)
        except TrainingInterrupted:
            pass
        ck=os.path.join(td,"epoch_1.pt")
        assert os.path.isfile(ck)
        result=provider.train({"X_train":X,"y_train":y,"X_val":X,"y_val":y,"model_type":"mlp_torch","task_type":"classification","n_epochs":2,"checkpoint_dir":td,"torch_num_threads":1,"resume_from":ck,"start_epoch":1})
        assert result["status"]=="REAL"
        assert result["checkpoints"] and result["checkpoints"][0]["epoch"]==2
        assert os.path.isfile(result["final_model_path"])
