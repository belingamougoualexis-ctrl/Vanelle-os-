import os, tempfile, numpy as np

def test_audio_pipeline_real():
    import soundfile as sf
    from ai_training_os.core import AITrainingOS
    with tempfile.TemporaryDirectory() as td:
        root=os.path.join(td,"audio_assets")
        sr=8000; t=np.arange(sr,dtype=np.float32)/sr
        for label,freq in (("low",220),("high",880)):
            d=os.path.join(root,label); os.makedirs(d)
            for i in range(5):
                sig=(0.2*np.sin(2*np.pi*freq*t)).astype(np.float32)
                sf.write(os.path.join(d,f"sample_{i}.wav"),sig,sr,format="WAV")
        app=AITrainingOS(os.path.join(td,"aitos")); pid=app.create_project("audio")
        ds=app.datasets.create_dataset(pid,"audio",root); dv,_=app.datasets.import_version(ds,root)
        result=app.orchestrator.run_tabular_from_dataset_version(pid,dv,model_name="audio",model_type="auto",n_epochs=1)
        assert result["status"]=="REAL"
        assert result["layout"]["modality"]=="audio"
        assert result["training"]["status"]=="COMPLETED"
        assert result["training"]["truth_status"]=="REAL"
