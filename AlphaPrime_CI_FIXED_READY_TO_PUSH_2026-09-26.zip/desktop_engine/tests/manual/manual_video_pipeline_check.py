import os
import tempfile
import numpy as np

def test_video_pipeline_real():
    import cv2
    from ai_training_os.core import AITrainingOS
    with tempfile.TemporaryDirectory() as td:
        root=os.path.join(td,"video_assets")
        for label,value in (("dark",30),("bright",220)):
            d=os.path.join(root,label); os.makedirs(d)
            for i in range(5):
                path=os.path.join(d,f"sample_{i}.avi")
                writer=cv2.VideoWriter(path,cv2.VideoWriter_fourcc(*"MJPG"),5.0,(32,32))
                assert writer.isOpened()
                for _ in range(6): writer.write(np.full((32,32,3),value,dtype=np.uint8))
                writer.release()
        app=AITrainingOS(os.path.join(td,"aitos")); pid=app.create_project("video")
        ds=app.datasets.create_dataset(pid,"video",root); dv,_=app.datasets.import_version(ds,root)
        result=app.orchestrator.run_tabular_from_dataset_version(pid,dv,model_name="video",model_type="auto",n_epochs=1)
        assert result["status"]=="REAL"
        assert result["layout"]["modality"]=="video"
        assert result["training"]["status"]=="COMPLETED"
        assert result["training"]["truth_status"]=="REAL"
