import os
import tempfile

def test_mlp_sklearn_real():
    import numpy as np
    from ai_training_os.providers.local_cpu import LocalCPUProvider
    with tempfile.TemporaryDirectory() as td:
        cfg={"X_train":[[0,0],[0,1],[1,0],[1,1],[0.1,0.1],[0.9,0.2]],"y_train":["a","a","b","b","a","b"],"X_val":[[0.2,0.8],[0.8,0.9]],"y_val":["a","b"],"model_type":"mlp_sklearn","task_type":"classification","n_epochs":10,"checkpoint_dir":td}
        result=LocalCPUProvider().train(cfg)
        assert result["status"]=="REAL"
        assert result["model_format"]=="sklearn_mlp_pickle"
        assert os.path.isfile(result["final_model_path"])
