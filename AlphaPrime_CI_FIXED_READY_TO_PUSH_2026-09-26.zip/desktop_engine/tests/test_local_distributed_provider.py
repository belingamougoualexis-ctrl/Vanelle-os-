import os
import socket
import sys
import time
import multiprocessing as mp

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os.providers import get_provider
from ai_training_os.providers.local_distributed import worker_serve_forever


def _spawn_lan_worker():
    """Simule une vraie machine LAN : un vrai processus, un vrai socket TCP
    réel sur 127.0.0.1 (le même code que pour une IP de LAN réelle)."""
    q = mp.Queue()
    p = mp.Process(target=worker_serve_forever, args=("127.0.0.1", 0, q), daemon=True)
    p.start()
    port = q.get(timeout=5)
    return p, f"127.0.0.1:{port}"


def test_is_available_matches_real_cpu_count():
    provider = get_provider("LOCAL_DISTRIBUTED_PROVIDER")
    avail = provider.is_available()
    cores = os.cpu_count() or 1
    assert avail["available"] == (cores >= 2)
    assert "reason" in avail


def test_train_raises_when_no_worker_and_no_reachable_node():
    provider = get_provider("LOCAL_DISTRIBUTED_PROVIDER")
    avail = provider.is_available()
    if avail["available"]:
        pytest.skip("Cette machine a >=2 coeurs réels — le volet local s'active, ce test ne s'applique pas ici.")
    with pytest.raises(RuntimeError):
        provider.train({"X_train": [[1.0]], "y_train": ["a"], "X_val": [[1.0]], "y_val": ["a"]})


def test_probe_nodes_reports_unreachable_node_honestly():
    provider = get_provider("LOCAL_DISTRIBUTED_PROVIDER")
    results = provider.probe_nodes(["127.0.0.1:1"])  # port 1 : rien n'écoute réellement ici
    assert results[0]["reachable"] is False
    assert results[0]["reason"]


def test_probe_nodes_confirms_real_reachable_worker():
    proc, endpoint = _spawn_lan_worker()
    try:
        provider = get_provider("LOCAL_DISTRIBUTED_PROVIDER")
        results = provider.probe_nodes([endpoint])
        assert results[0]["reachable"] is True
    finally:
        proc.terminate()
        proc.join(timeout=2)


def test_training_runs_real_across_simulated_lan_nodes(tmp_path):
    """Bout-en-bout : deux 'noeuds LAN' réels (vrais process, vrais sockets
    TCP en boucle locale — le même chemin de code qu'un vrai LAN) reçoivent
    chacun un vrai shard de données et renvoient des coefficients réellement
    mesurés ; le driver les agrège et mesure des métriques réelles."""
    proc_a, node_a = _spawn_lan_worker()
    proc_b, node_b = _spawn_lan_worker()
    try:
        provider = get_provider("LOCAL_DISTRIBUTED_PROVIDER")
        X = [[float(i), float(i % 3)] for i in range(40)]
        y = ["pos" if i % 2 == 0 else "neg" for i in range(40)]
        config = {
            "model_type": "sgd_incremental",
            "n_epochs": 3,
            "n_local_workers": 0,  # force l'usage exclusif des noeuds LAN simulés
            "nodes": [node_a, node_b],
            "X_train": X, "y_train": y,
            "X_val": X[:10], "y_val": y[:10],
            "checkpoint_dir": str(tmp_path / "ckpt"),
        }
        result = provider.train(config)
        assert result["status"] == "REAL"
        assert result["provider"] == "LOCAL_DISTRIBUTED_PROVIDER"
        assert set(result["endpoints_used"]) == {node_a, node_b}
        assert all(kind == "LAN_NODE" for kind in result["endpoint_kinds"].values())
        assert len(result["checkpoints"]) == 3
        assert result["metrics"]["n_workers_used"] == 2
        assert os.path.isfile(result["final_model_path"])
    finally:
        for p in (proc_a, proc_b):
            p.terminate()
            p.join(timeout=2)


def test_training_degrades_honestly_when_one_node_dies_mid_run(tmp_path):
    """Un noeud qui tombe réellement APRÈS le round 1 (pendant l'entraînement,
    pas avant) doit être exclu des rounds suivants avec un avertissement réel
    — jamais transformé en faux succès silencieux."""
    proc_a, node_a = _spawn_lan_worker()
    proc_b, node_b = _spawn_lan_worker()
    state = {"killed": False}

    def kill_node_b_after_first_round(epoch, info):
        if epoch == 1 and not state["killed"]:
            proc_b.terminate()
            proc_b.join(timeout=2)
            time.sleep(0.2)
            state["killed"] = True

    try:
        provider = get_provider("LOCAL_DISTRIBUTED_PROVIDER")
        X = [[float(i)] for i in range(20)]
        y = ["pos" if i % 2 == 0 else "neg" for i in range(20)]
        config = {
            "model_type": "sgd_incremental",
            "n_epochs": 3,
            "n_local_workers": 0,
            "nodes": [node_a, node_b],
            "X_train": X, "y_train": y,
            "X_val": X, "y_val": y,
            "checkpoint_dir": str(tmp_path / "ckpt"),
        }
        result = provider.train(config, checkpoint_cb=kill_node_b_after_first_round)
        assert result["status"] == "REAL"
        assert state["killed"] is True
        assert any("indisponible" in w for w in result["warnings"])
    finally:
        proc_a.terminate()
        proc_a.join(timeout=2)


def test_registry_lists_local_distributed_provider_honestly():
    from ai_training_os.providers import list_providers
    statuses = list_providers()
    assert "LOCAL_DISTRIBUTED_PROVIDER" in statuses
    assert "REMOTE_GPU_PROVIDER" in statuses
    assert "CLOUD_PROVIDER" in statuses
    # Ni le cloud ni le GPU distant ne doivent jamais être annoncés
    # disponibles dans un environnement 100% local sans identifiants.
    assert statuses["CLOUD_PROVIDER"]["available"] is False
    assert statuses["REMOTE_GPU_PROVIDER"]["available"] is False
