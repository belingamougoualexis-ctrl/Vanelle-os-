import os
import tempfile
from pathlib import Path

from ai_training_os.core import AITrainingOS

FIXTURE = Path(__file__).resolve().parents[1] / "fixtures" / "sample_dataset.csv"

def test_repeated_local_inference_and_reload_stays_real():
    with tempfile.TemporaryDirectory(prefix="aitos-stress-") as td:
        app = AITrainingOS(td)
        pid = app.create_project("stress")
        dsv, _ = app.datasets.import_version(app.datasets.create_dataset(pid, "ds", str(FIXTURE)), str(FIXTURE))
        result = app.orchestrator.run_tabular_from_dataset_version(pid, dsv, "stress-model", "logistic_regression", 1)
        assert result["status"] == "REAL"
        mvid = result["model_version_id"]
        for _ in range(5):
            val = app.reality.validate_model_version(mvid, run_inference=True)
            assert val["status"] == "VERIFIED"
            names = {c["name"]: c["status"] for c in val["checks"]}
            assert names.get("real_inference") == "VERIFIED"
            assert names.get("unload_reload") == "VERIFIED"
        assert os.path.isfile(result["training"]["health_log_path"])
