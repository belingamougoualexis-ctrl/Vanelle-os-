import json, os, shutil
from ai_training_os.core import AITrainingOS

ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC=os.path.join(ROOT,'fixtures','sample_dataset.csv')


def _app(tmp_path):
    app=AITrainingOS(str(tmp_path))
    pid=app.create_project('enterprise')
    ds=app.datasets.create_dataset(pid,'sample',SRC)
    dsv,_=app.datasets.import_version(ds,SRC)
    return app,pid,dsv


def test_profile_is_real_and_redacts_pii(tmp_path):
    app,pid,dsv=_app(tmp_path)
    r=app.enterprise.profile_dataset(dsv)
    assert r['status']=='REAL'
    assert r['rows'] > 0 and r['columns'] > 0
    assert 'schema_fingerprint' in r
    dumped=json.dumps(r)
    assert 'alice@example.com' not in dumped


def test_contract_create_and_validate_real(tmp_path):
    app,pid,dsv=_app(tmp_path)
    created=app.enterprise.create_contract(pid,dsv,{'min_rows':1,'max_missing_rate':1,'max_duplicate_rate':1})
    assert created['status']=='REAL'
    valid=app.enterprise.validate_contract(dsv,created['contract_id'])
    assert valid['status']=='REAL'
    assert valid['validation_status']=='VALIDATED'
    assert all(valid['checks'].values())


def test_drift_real_and_lineage_real(tmp_path):
    app,pid,dsv=_app(tmp_path)
    ds_id=app.datasets.get_version(dsv)['dataset_id']
    second=os.path.join(tmp_path,'second.csv')
    with open(SRC,encoding='utf-8') as f: data=f.read()
    with open(second,'w',encoding='utf-8') as f: f.write(data.replace('0.1','1000.1'))
    dsv2,_=app.datasets.import_version(ds_id,second)
    drift=app.enterprise.drift(dsv,dsv2,pid)
    assert drift['status']=='REAL'
    assert 'drift_run_id' in drift
    lineage=app.enterprise.lineage(pid)
    assert lineage['status']=='REAL'
    assert any(n['id']==dsv for n in lineage['nodes'])


def test_model_card_and_eval_suite_are_real(tmp_path):
    app,pid,dsv=_app(tmp_path)
    result=app.orchestrator.run_tabular_classification(pid,SRC,'DS','Model','logistic_regression',1,security_policy={'max_prediction_flip_rate':1.0})
    assert result['status']=='REAL'
    card=app.enterprise.generate_model_card(pid,result['model_version_id'])
    assert card['status']=='REAL' and os.path.isfile(card['path'])
    suite=app.enterprise.create_eval_suite(pid,'golden',dsv,{'accuracy':0.0,'f1_macro':0.0})
    run=app.enterprise.run_eval_suite(suite['suite_id'],result['model_version_id'])
    assert run['status']=='REAL'
    assert run['metrics']['rows_evaluated'] > 0


def test_governance_exports_with_project(tmp_path):
    app,pid,dsv=_app(tmp_path)
    app.enterprise.create_contract(pid,dsv,{'min_rows':1,'max_missing_rate':1,'max_duplicate_rate':1})
    out=os.path.join(tmp_path,'project.zip')
    exported=app.exporter.export(pid,out)
    assert exported['status']=='REAL' and os.path.isfile(out)
    imported=os.path.join(tmp_path,'imported')
    restored=app.exporter.import_project(out,imported)
    assert restored['status']=='REAL'
    import sqlite3
    conn=sqlite3.connect(os.path.join(imported,'aitos.db'))
    try:
        assert conn.execute('SELECT COUNT(*) FROM data_contracts').fetchone()[0] == 1
    finally:
        conn.close()
