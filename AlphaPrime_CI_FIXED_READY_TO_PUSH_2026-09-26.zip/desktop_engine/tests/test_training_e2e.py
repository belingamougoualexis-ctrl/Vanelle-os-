import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os import AITrainingOS


@pytest.fixture
def system(tmp_path):
    return AITrainingOS(str(tmp_path / "aitos"))


def _prepare_split(system, dv_id):
    """Reconstruit X/y à partir de la version dataset réellement écrite sur disque."""
    import json
    v = system.datasets.get_version(dv_id)
    from ai_training_os import utils
    split = utils.loads(v["split_json"])
    records = []
    with open(v["file_path"]) as f:
        for line in f:
            records.append(json.loads(line))
    def build(idx_list):
        X, y = [], []
        for i in idx_list:
            if i >= len(records):
                continue
            r = records[i]
            if r.get("x1") in (None, "") or r.get("x2") in (None, "") or r.get("label") in (None, ""):
                continue
            X.append([float(r["x1"]), float(r["x2"])])
            y.append(int(float(r["label"])))
        return X, y
    X_train, y_train = build(split["train"])
    X_val, y_val = build(split["val"] + split["test"])
    return X_train, y_train, X_val, y_val


def test_full_training_e2e_local_cpu(system):
    pid = system.create_project("Projet E2E")
    mission = system.missions.analyze(pid, "Je veux classifier des points en deux catégories")
    ds_id = system.datasets.create_dataset(pid, "Dataset E2E", "n/a")
    fixtures = os.path.join(os.path.dirname(__file__), "..", "fixtures", "sample_dataset.csv")
    dv_id, _ = system.datasets.import_version(ds_id, fixtures)

    X_train, y_train, X_val, y_val = _prepare_split(system, dv_id)
    assert len(X_train) > 10
    assert len(X_val) > 2

    model_id = system.models.create_model(pid, "Classifieur points", "logistic_regression")
    mv_id = system.models.create_version(
        model_id, dv_id,
        config={"code_version": "v1", "dependencies": {"scikit-learn": "1.8.0"}},
        hyperparameters={"model_type": "sgd_incremental", "n_epochs": 3},
        hardware={"provider": "LOCAL_CPU_PROVIDER"},
    )
    exp_id = system.experiments.create(pid, mission["mission_id"], dv_id, mv_id,
                                        "LOCAL_CPU_PROVIDER", {"model_type": "sgd_incremental", "n_epochs": 3})

    result = system.training.run(exp_id, "LOCAL_CPU_PROVIDER", {
        "X_train": X_train, "y_train": y_train, "X_val": X_val, "y_val": y_val,
        "model_type": "sgd_incremental", "n_epochs": 3,
    })

    assert result["status"] == "COMPLETED"
    assert 0.0 <= result["metrics"]["accuracy"] <= 1.0
    assert len(result.get("predictions", [])) == len(y_val)

    exp = system.experiments.get(exp_id)
    assert exp["status"] == "COMPLETED"

    # 3 epochs demandées -> 3 checkpoints réellement écrits et hashés
    job = system.jobs.list_jobs()[0]
    checkpoints = system.conn.execute("SELECT * FROM checkpoints WHERE job_id=?", (job["id"],)).fetchall()
    assert len(checkpoints) == 3
    for c in checkpoints:
        assert os.path.exists(c["file_path"])

    # Evaluation Engine + Error Mining sur les VRAIES prédictions
    eval_id = system.evaluations.record(mv_id, dv_id, result["metrics"])
    clusters = system.error_mining.mine(eval_id, result["y_val"], result["predictions"])
    total_errors = sum(c["n_examples"] for c in clusters)
    expected_errors = sum(1 for a, b in zip(result["y_val"], result["predictions"]) if a != b)
    assert total_errors == expected_errors

    # Safety Gate — vérification réelle, statut honnête
    review = system.safety_gate.review(mv_id, result["metrics"], min_accuracy=0.3)
    assert review["final_status"].startswith("PENDING") or review["final_status"] in ("APPROVED", "REJECTED")


def test_gpu_provider_is_honestly_unavailable(system):
    pid = system.create_project("P")
    exp_id = system.experiments.create(pid, None, None, None, "LOCAL_GPU_PROVIDER", {})
    result = system.training.run(exp_id, "LOCAL_GPU_PROVIDER", {})
    assert result["status"] == "UNAVAILABLE"
    exp = system.experiments.get(exp_id)
    assert exp["status"] == "FAILED"
    assert "UNAVAILABLE" in exp["error_message"]


def test_cloud_provider_is_honestly_unavailable(system):
    pid = system.create_project("P")
    exp_id = system.experiments.create(pid, None, None, None, "CLOUD_PROVIDER", {})
    result = system.training.run(exp_id, "CLOUD_PROVIDER", {})
    assert result["status"] == "UNAVAILABLE"
