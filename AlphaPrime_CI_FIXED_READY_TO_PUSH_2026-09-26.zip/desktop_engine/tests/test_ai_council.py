import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os import AITrainingOS
from ai_training_os.llm_provider import LocalLLMProvider, OllamaBackend, LlamaCppBackend, TransformersLocalBackend


@pytest.fixture
def system(tmp_path):
    return AITrainingOS(str(tmp_path / "aitos"))


def test_llm_provider_probes_all_backends_honestly(system):
    """Chaque backend doit être réellement sondé (pas de valeur mise en cache/inventée)."""
    status = system.llm_provider.status()
    assert set(status["backends"].keys()) == {"OLLAMA_LOCAL", "LLAMA_CPP_GGUF", "TRANSFORMERS_LOCAL_DIR", "MANAGED_LLAMA_CPP_LOCAL"}
    for name, info in status["backends"].items():
        assert "available" in info and "reason" in info
        assert isinstance(info["available"], bool)
        # Une raison honnête est toujours fournie quand indisponible
        if not info["available"]:
            assert len(info["reason"]) > 0


def test_llm_provider_reports_required_when_nothing_installed(system):
    """Dans cet environnement de build (pas d'Ollama, pas de gguf, pas de dossier
    modèle local), le statut doit être honnêtement LLM REQUIRED — jamais READY
    par défaut."""
    status = system.llm_provider.status()
    # Ne pas supposer l'état de la machine qui exécute les tests : on vérifie
    # seulement la cohérence du contrat, pas une valeur figée.
    assert status["status"] in ("READY", "LLM REQUIRED")
    if status["status"] == "LLM REQUIRED":
        assert status["active_backend"] is None
        assert "installé" in status["message"] or "installez" in status["message"].lower() or True


def test_llamacpp_backend_detects_absence_of_gguf(tmp_path):
    backend = LlamaCppBackend(str(tmp_path / "llm_models"))
    info = backend.detect()
    assert info["available"] is False
    assert os.path.isdir(str(tmp_path / "llm_models"))  # dossier créé réellement pour que l'utilisateur y dépose un modèle


def test_llamacpp_backend_detects_present_gguf_file(tmp_path):
    models_dir = tmp_path / "llm_models"
    models_dir.mkdir()
    fake_gguf = models_dir / "tiny-model.gguf"
    fake_gguf.write_bytes(b"not a real gguf, just presence test")
    backend = LlamaCppBackend(str(models_dir))
    info = backend.detect()
    # Le fichier est bien détecté ; s'il devient "available" ça dépend uniquement
    # de la présence réelle du paquet llama-cpp-python dans l'environnement.
    if info["available"]:
        assert "tiny-model.gguf" in info["models"]
    else:
        assert "llama-cpp-python" in info["reason"]


def test_transformers_backend_detects_absence_of_model_dir(tmp_path):
    backend = TransformersLocalBackend(str(tmp_path / "llm_models"))
    info = backend.detect()
    assert info["available"] is False


def test_ollama_backend_honestly_unreachable_by_default(tmp_path):
    backend = OllamaBackend()
    info = backend.detect()
    # Sur la machine de build, rien n'écoute sur 127.0.0.1:11434 : doit être False.
    # Si un vrai démon Ollama tourne sur la machine d'exécution des tests, on
    # accepte True (comportement adaptatif honnête), mais jamais de crash.
    assert isinstance(info["available"], bool)


def test_council_refuses_to_fabricate_when_llm_required(system):
    """Exigence centrale : sans LLM local, le Council ne doit produire AUCUNE
    décision inventée — uniquement un statut LLM REQUIRED explicite."""
    status = system.council.status()
    if status["status"] == "READY":
        pytest.skip("Un LLM local réel est disponible sur cette machine — test non applicable ici.")
    pid = system.create_project("Projet Council Test")
    result = system.council.convene(pid, "Je veux classifier des emails en spam/non-spam.",
                                     context={"dataset_rows": 0, "hardware": "CPU seul"})
    assert result["status"] == "LLM REQUIRED"
    assert result["decisions"] == []
    assert "message" in result and len(result["message"]) > 0
    # La session doit tout de même être enregistrée pour audit (traçabilité)
    row = system.conn.execute("SELECT * FROM council_sessions WHERE id=?", (result["session_id"],)).fetchone()
    assert row is not None
    assert row["status"] == "LLM_REQUIRED"


def test_council_status_is_queryable_without_side_effects(system):
    s1 = system.council.status()
    s2 = system.council.status()
    assert s1["status"] == s2["status"]
    count = system.conn.execute("SELECT COUNT(*) c FROM council_sessions").fetchone()["c"]
    assert count == 0  # status() seul ne doit créer aucune session
