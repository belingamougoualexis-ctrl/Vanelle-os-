# Mobile compatibility

| Plateforme | Build | Validation finale |
|---|---|---|
| Android | APK Release signé | Appareil Android physique connecté au runner |
| iOS | IPA Release signé | iPhone/iPad physique enregistré et connecté au runner |

La compilation seule produit un artefact **BUILD VERIFIED**. La mention **DEVICE VERIFIED** n’est accordée qu’après installation et lancement sur le matériel physique correspondant.

Les autres appareils, architectures ou backends non exécutés restent `NOT VERIFIED — ENVIRONMENT UNAVAILABLE`.
