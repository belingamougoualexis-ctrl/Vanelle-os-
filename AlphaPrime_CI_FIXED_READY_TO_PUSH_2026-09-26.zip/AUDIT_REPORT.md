# Alpha Prime Mobile 2.1 — audit technique

Date: 2026-09-25

## Vérifications effectuées dans l’environnement de build

- package.json, app.json, eas.json et tsconfig.json parseables.
- workflow GitHub situé sous `.github/workflows/mobile-build.yml`.
- aucun appel réseau dans le code mobile (`fetch`, axios, WebSocket ou URL HTTP absents du runtime mobile).
- contrôle TypeScript structurel sur tous les `.ts/.tsx` : PASS avec déclarations temporaires des modules natifs externes.
- syntaxe Python du moteur desktop : PASS.
- modules de tests desktop exécutés isolément : PASS sur les tests disponibles ; un test distribué est explicitement SKIP lorsqu'il ne correspond pas au matériel de l'environnement de build.
- tests de `test_local_operations.py` exécutés individuellement : tous PASS.
- archive finale vérifiée après création.

## Vérifications qui nécessitent encore un service de build/appareil

Aucune machine de ce type n'est disponible ici. Le workflow GitHub Actions fourni compile réellement Android et iOS Simulator, et lance un smoke test de démarrage sur émulateur Android et simulateur iOS. L'inférence Metal iOS ne peut pas être validée par le simulateur, car llama.rn la documente comme non supportée sur simulateur.

La compatibilité absolue avec chaque téléphone/tablette et chaque GGUF ne peut donc pas être certifiée sans appareils réels. L'application ne masque pas cette limite et n'affiche pas de succès fictif.

## Choix de versions

Expo SDK 57 cible React Native 0.86 et React 19.2.3. SDK 57 supporte Android 7+, compile/target SDK 36 et iOS 16.4+. Alpha Prime utilise ces bases. llama.rn 0.12.9 est utilisé avec la New Architecture ; le package documente Android arm64-v8a/x86_64, l'OpenCL sur certaines configurations Qualcomm Adreno et Metal sur appareils iOS compatibles.

## Protection contre les erreurs prévisibles

- modèle GGUF validé avant enregistrement ;
- modèle dépassant approximativement 75 % de la RAM déclarée refusé ;
- configuration mémoire réduite automatiquement sur petites RAM ;
- backend GPU détecté réellement ; repli CPU si l'initialisation GPU échoue ;
- échec de détection des backends traité comme absence de backend, pas comme GPU disponible ;
- datasets mobiles limités à 25 Mo pour éviter une surcharge mémoire évidente ;
- résultats et compteurs non préremplis.
