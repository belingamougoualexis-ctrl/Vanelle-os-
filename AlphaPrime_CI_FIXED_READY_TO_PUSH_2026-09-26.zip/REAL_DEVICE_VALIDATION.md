# Validation appareil réel

Alpha Prime n'utilise pas de moteur de simulation comme preuve de compatibilité utilisateur.

## États

- `BUILD VERIFIED` : le binaire a été construit et signé avec succès.
- `DEVICE VERIFIED` : le binaire a été installé et lancé sur le matériel physique cible.
- `NOT VERIFIED` : aucune preuve locale suffisante n’existe encore.

## Android

Le runner physique doit exposer exactement un appareil autorisé via ADB. Le workflow installe l’APK, lance `com.alphaprime.local`, puis vérifie que le processus et la version attendue sont réellement présents.

## iOS

Le runner macOS doit exposer un iPhone/iPad physique enregistré. Le workflow installe l’IPA avec `xcrun devicectl` puis lance le bundle `com.alphaprime.local`.
