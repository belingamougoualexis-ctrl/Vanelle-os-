# Release validation

Une release Alpha Prime n'est considérée comme validée pour un appareil que si :

1. les tests source passent ;
2. le binaire Release est construit ;
3. le binaire attendu existe réellement ;
4. l’appareil physique cible est connecté ;
5. l’installation réelle réussit ;
6. le lancement réel réussit ;
7. les résultats de vérification sont enregistrés.

Une absence de matériel ne devient jamais un succès automatique.
