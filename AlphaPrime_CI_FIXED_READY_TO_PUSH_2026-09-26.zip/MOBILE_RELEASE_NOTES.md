# Alpha Prime Mobile 2.1 — notes de version

- Expo SDK 57 / React Native 0.86.3.
- llama.rn 0.12.9 avec nouvelle architecture.
- Android API 36 et iOS 16.4.
- Android arm64-v8a et x86_64.
- Validation locale des modèles GGUF avant enregistrement.
- Détection et vérification réelles du moteur LLM ; aucune accélération matérielle n’est annoncée sans inférence réussie.
- Repli GPU → CPU uniquement lorsque le moteur local confirme l’échec du chemin matériel.
- Profilage CSV/JSON local avec limites mémoire explicites.
- Empreintes SHA-256 calculées localement.
- Les versions publiables sont construites réellement ; la validation matérielle est effectuée uniquement sur appareils physiques dédiés.
- Aucun compteur, résultat ou contenu de modèle prérempli n’est utilisé comme preuve de fonctionnement.
