# Alpha Prime / AI Training OS — Adaptive + Reality Audit

Date: 2026-09-26
Source project: existing `AlphaPrime_Mobile_2_1_0_Enterprise_Local` archive

## Scope

The existing project was preserved. Existing desktop AI Training OS services and mobile screens were extended rather than replaced. No functional screen or core service was intentionally removed.

## Adaptive UI

The mobile UI uses a single design token system and window-driven layout policy:

- compact: width < 540
- medium: 540–839
- expanded: 840–1199
- large: >= 1200
- short-height mode: height < 480

Navigation changes from a bottom bar on compact/medium windows to a sidebar on wider windows. Content uses a maximum width and dynamic horizontal padding. Safe-area insets are handled for the top and bottom regions.

The same visual language is used by the desktop dashboard: cool white surfaces, deep navy text, cobalt primary action color, aqua accent, restrained status colors, consistent radius/spacing and system typography.

## No prefilled results

The mobile initial state is empty. Imported models and datasets only appear after real local operations. The Canary configuration field is empty instead of containing a demonstration JSON payload. Desktop dashboard controls no longer contain the previous sample Canary configuration, regression suite name or default accuracy/F1 threshold values.

The interface does not present a model as runtime-verified merely because a GGUF file was imported. The mobile model screen performs a real local load and real inference before displaying the runtime as tested.

## Self-repair and recovery

Mobile state recovery:

1. Attempt to load current local state.
2. On malformed persisted JSON, preserve the raw payload in a local quarantine key.
3. Continue with legacy/empty valid state instead of overwriting the corrupt payload.

Desktop safe self-healing:

1. Allow only an explicit safe action allowlist.
2. Confine targets to the local workspace.
3. Backup existing state before mutation.
4. Apply the change atomically when writing JSON configuration.
5. Execute a post-change verification callback.
6. Commit only on verification success.
7. Roll back on failure.
8. Report `RECOVERING` if rollback itself fails.
9. Serialize healing operations with a lock.

Canary configuration follows the same candidate → real validation → apply → post-apply verification → commit/rollback chain and serializes concurrent changes.

## Workflow

Root workflow: `.github/workflows/build-all-platforms.yml`

- Mobile quality gate: Node 22.13.1, Expo Doctor, TypeScript, Jest.
- Windows: Python 3.11, Python compile check, dashboard JavaScript syntax, the existing real test runner, PyInstaller build, executable existence/size verification and artifact upload.
- Android: Expo prebuild, release APK, Android Emulator install + launch smoke test, artifact upload.
- iOS: Expo prebuild with scene support, CocoaPods, Release iOS Simulator build, simulator install + launch smoke test, artifact upload.
- Final gate waits for Windows + Android + iOS.

No `npm ci` is used because the project does not currently contain a committed lockfile. The workflow deliberately uses `npm install` rather than pretending lockfile-level reproducibility exists.

## Version choices verified against current official documentation

Expo SDK 57 currently supports Android 7+, compile/target SDK 36 and iOS 16.4+. Expo 57.0.23 adds opt-in UIKit scene support for the iOS 27 SDK/Xcode 27. The project uses Expo 57.0.23, React Native 0.86.3 and `ios.enableSceneSupport=true`.

GitHub's current runner image list shows `macos-latest` on macOS 26 Arm64 and Windows 2025 as a current x64 runner label. The workflow uses those labels for the corresponding platform gates.

The Windows application remains the existing Python/HTML desktop engine. React Native Windows was not added blindly because the currently documented RN Windows line exposed here is 0.84 while the project is on React Native 0.86.3; a forced mix would introduce an avoidable version-compatibility risk.

## Validation performed in this environment

Environment available here: Linux x86_64, Python 3.13.5, CPU-only runtime. Physical Windows, Android devices, iOS devices and GPU backends are not present.

Passed checks:

- Python `compileall` for engine and tests: PASS.
- Dashboard embedded JavaScript `node --check`: PASS.
- Critical desktop regression/reality group: 36 PASS.
- Professional suite: 7 PASS.
- Reality API: 1 PASS.
- Reality stress/reload test: 1 PASS.
- Reality system: 7 PASS.
- Recovery, red-team, registry, specialized-training, startup and training E2E tests: PASS when executed individually.
- Desktop test collection: 89 tests collected.
- One distributed-provider test is explicitly skipped because that scenario does not apply to this local environment.

The single-process full pytest invocation did not finish inside the available 300-second execution window, so the complete 89-test suite is not marked as “one-shot passed”. Individual file-level execution was used to separate cumulative runtime effects from functional failures.

The mobile npm dependency tree could not be installed inside this analysis container before the execution window expired. Therefore mobile Jest/typecheck and native Android/iOS compilation are marked for GitHub Actions verification rather than claimed as locally executed here.

## Official state rule

A critical capability is `VERIFIED` only after a local execution produces evidence. Hardware detection alone does not make a GPU verified. An imported model is not runtime-verified until load/inference succeeds. A completed process is not an accepted training result until forward/backward/optimizer/checkpoint/reload/evaluation evidence exists.

## Expected CI truthfulness

If a runner cannot provide a physical capability, the workflow should report that limitation rather than fabricate a success. Platform artifacts are published only after the corresponding build and smoke checks succeed.
