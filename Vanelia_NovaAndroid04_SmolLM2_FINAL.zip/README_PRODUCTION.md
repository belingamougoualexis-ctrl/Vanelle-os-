# Vanelia NovaAndroid04 — configuration de production

## Moteur IA local
Vanelia utilise un modèle GGUF SmolLM2-360M-Instruct Q4_K_M (~271 MB) avec llama.cpp Android.
Le fichier est téléchargé à la demande depuis une source publique, repris après interruption et vérifié par SHA-256 avant utilisation.

Aucun compte IA, token cloud ou clé API n'est requis pour ce moteur local. L'application utilise uniquement HTTPS pour télécharger le fichier du moteur.

## Première ouverture
- L'application demande les permissions sensibles déclarées et nécessaires à ses fonctions : caméra, microphone et notifications Android 13+.
- L'utilisateur voit une explication des conditions du moteur local et peut les accepter ou refuser.
- En cas de refus, Vanelia explique que le moteur ne sera pas téléchargé/activé.
- Si accepté et que le moteur manque, le téléchargement démarre automatiquement.

## Erreurs
`ErrorCenter` centralise les erreurs et `ErrorOverlay` les affiche dans les interfaces principales. Les messages conservent la cause système connue et n'inventent pas un faux diagnostic.

## Compatibilité
Le moteur llama.cpp utilisé ici est arm64-v8a. L'application cible Android API 26+.
Un appareil Android x86/x86_64 ne peut pas charger cette AAR dans cette configuration.

## Limite importante
Le moteur est petit et rapide pour un LLM local, mais ses capacités restent celles d'un modèle ~360M de paramètres. Il ne faut pas le présenter comme un modèle généraliste de grande taille.
