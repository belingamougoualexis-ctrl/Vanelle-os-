package com.vanelle.os

import android.app.*
import android.content.pm.ServiceInfo
import android.content.Intent
import android.os.Bundle
import android.os.IBinder
import android.speech.*
import android.speech.tts.TextToSpeech
import android.media.AudioManager
import android.media.ToneGenerator
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

/**
 * Service d'écoute du mot d'activation "Cassandra".
 *
 * UNIQUEMENT openWakeWord (AudioRecord silencieux) — aucun SpeechRecognizer
 * en boucle en arrière-plan (pas de bip permanent).
 * SpeechRecognizer n'est lancé qu'UNE fois après détection du wake word,
 * pour capturer la commande.
 */
class WakeWordService : Service() {
    companion object {
        private const val TAG = "WakeWordService"
        @Volatile var isRunning: Boolean = false
            private set
    }

    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var commandTimeoutJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val detector by lazy { OpenWakeWordDetector(this) }

    @Volatile
    private var isServiceDestroyed = false

    @Volatile
    private var capturingCommand = false

    private var speechRetryLeft = 0

    @Volatile private var lastPartialResult: String = ""

    @Volatile private var listeningStarting = false

    @Volatile private var wakeListening = false
    private var wakeRestartJob: Job? = null

    private val wakeVariants = listOf(
        "cassandra", "cassandre", "casandra", "cassandras", "kasandra", "cass", "sandra"
    )

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isServiceDestroyed = false
        isRunning = true
        Log.i(TAG, "onCreate")
        WakeWordDiagnostics.log(this, TAG, "service démarré (onCreate)")
        try {
            val id = "vanelle_wake"
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(
                NotificationChannel(id, "Vanelle", NotificationManager.IMPORTANCE_LOW)
            )
            val n = NotificationCompat.Builder(this, id)
                .setContentTitle("VanelleOS")
                .setContentText("Écoute active — dis Cassandra")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
            if (androidx.core.content.ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.RECORD_AUDIO
                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                WakeWordDiagnostics.log(this, TAG, "micro désactivé: RECORD_AUDIO non accordé")
                stopSelf()
                return
            }

            if (android.os.Build.VERSION.SDK_INT >= 29) {
                androidx.core.app.ServiceCompat.startForeground(
                    this,
                    1,
                    n,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(1, n)
            }
            tts = TextToSpeech(this) { status ->
                if (status == TextToSpeech.SUCCESS) tts?.language = Locale.FRANCE
            }
            scope.launch {
                withContext(Dispatchers.IO) {
                    WakeWordModelManager.downloadIfNeeded(this@WakeWordService)
                }
                if (isServiceDestroyed) return@launch
                startOpenWakeWordListening()
            }
        } catch (e: Exception) {
            Log.e(TAG, "onCreate failed: ${e.message}")
            WakeWordDiagnostics.log(this, TAG, "ERREUR onCreate : ${e.message}")
            stopSelf()
        }
    }

    /** Démarre uniquement openWakeWord. Si modèles absents → retry, jamais SpeechRecognizer en boucle. */
    private fun startOpenWakeWordListening() {
        if (isServiceDestroyed || capturingCommand) return
        // Une seule instance d'AudioRecord doit exister.
        if (wakeListening || detector.isListening()) return
        if (listeningStarting) return
        listeningStarting = true
        if (!WakeWordModelManager.isReady(this)) {
            listeningStarting = false
            Log.w(TAG, "models not ready, scheduling retry")
            WakeWordDiagnostics.log(this, TAG, "modèles pas prêts (isReady=false), nouvelle tentative dans 4s")
            scheduleModelRetry()
            return
        }
        try {
            Log.i(TAG, "starting openWakeWord detector")
            detector.start(
                onDetected = {
                    wakeListening = false
                    onWakeDetected()
                },
                onStalled = {
                    wakeListening = false
                    scheduleWakeRestart("AudioRecord bloqué")
                }
            )
            wakeListening = detector.isListening()
        } catch (e: Exception) {
            Log.e(TAG, "detector.start failed: ${e.message}")
            WakeWordDiagnostics.log(this, TAG, "ERREUR detector.start : ${e.message}")
            scheduleWakeRestart("échec detector.start")
        } finally {
            listeningStarting = false
        }
    }

    private fun scheduleWakeRestart(reason: String) {
        if (isServiceDestroyed || capturingCommand) return
        if (wakeRestartJob?.isActive == true) return
        WakeWordDiagnostics.log(this, TAG, "redémarrage écoute programmé: $reason")
        wakeRestartJob = scope.launch {
            delay(350)
            if (!isServiceDestroyed && !capturingCommand) {
                try { detector.stop() } catch (_: Exception) {}
                wakeListening = false
                startOpenWakeWordListening()
            }
        }
    }

    private fun scheduleModelRetry() {
        scope.launch {
            delay(4000)
            if (isServiceDestroyed) return@launch
            withContext(Dispatchers.IO) {
                WakeWordModelManager.downloadIfNeeded(this@WakeWordService)
            }
            if (!isServiceDestroyed) startOpenWakeWordListening()
        }
    }

    /**
     * Après détection silencieuse du wake word :
     * arrête AudioRecord, lance UN SpeechRecognizer pour la commande uniquement.
     */

    private fun onWakeDetected() {
        if (isServiceDestroyed) return
        // Si une capture précédente est restée bloquée, on force le reset
        if (capturingCommand) {
            WakeWordDiagnostics.log(this, TAG, "capture précédente encore active → reset forcé")
            forceResetCaptureState()
        }
        Log.i(TAG, "wake word detected — launching SpeechRecognizer")
        WakeWordDiagnostics.log(this, TAG, "Cassandra détectée → bip + préparation micro")
        capturingCommand = true
        speechRetryLeft = 2
        lastPartialResult = ""
        commandTimeoutJob?.cancel()

        // Bip IMMÉDIAT (feedback instantané, sans attendre la libération du micro)
        try {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
            tone.startTone(ToneGenerator.TONE_PROP_BEEP, 100)
            // release après le ton, hors du chemin critique
            scope.launch {
                delay(150)
                try { tone.release() } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            try { tts?.speak("Oui", TextToSpeech.QUEUE_FLUSH, null, "wake_ack") } catch (_: Exception) {}
        }

        // Arrêt AudioRecord puis attente courte avant SpeechRecognizer
        try { detector.stop() } catch (_: Exception) {}
        wakeListening = false

        scope.launch {
            // Libération micro système (nécessaire avant SpeechRecognizer, pas avant le bip)
            delay(500)
            if (isServiceDestroyed || !capturingCommand) return@launch
            WakeWordDiagnostics.log(this@WakeWordService, TAG, "micro libre → ouverture reconnaissance système")
            launchSystemVoiceCapture()
        }
    }



    private fun forceResetCaptureState() {
        capturingCommand = false
        speechRetryLeft = 0
        lastPartialResult = ""
        commandTimeoutJob?.cancel()
        try { rec?.cancel() } catch (_: Exception) {}
        try { rec?.destroy() } catch (_: Exception) {}
        rec = null
        try { getSystemService(NotificationManager::class.java)?.cancel(42) } catch (_: Exception) {}
        listeningStarting = false
    }

    private fun isAppInForeground(): Boolean {
        return try {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val procs = am.runningAppProcesses ?: return false
            val pkg = packageName
            procs.any {
                it.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND &&
                    it.processName == pkg
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Android 10+ bloque souvent startActivity depuis un Service en arrière-plan.
     * → Si l'app est au premier plan : startActivity direct.
     * → Sinon : notification haute priorité + full-screen intent (ouvre la dictée hors app).
     */
    private fun launchSystemVoiceCapture() {
        if (isServiceDestroyed || !capturingCommand) return
        val captureIntent = Intent(this, VoiceCaptureActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            )
        }

        commandTimeoutJob?.cancel()
        commandTimeoutJob = scope.launch {
            delay(8_000)
            if (!isServiceDestroyed && capturingCommand) {
                WakeWordDiagnostics.log(this@WakeWordService, TAG, "timeout capture vocale (8s)")
                capturingCommand = false
                resumeOpenWakeWord()
            }
        }

        val foreground = isAppInForeground()
        WakeWordDiagnostics.log(this, TAG, "lancement dictée (foreground=$foreground)")

        if (foreground) {
            try {
                startActivity(captureIntent)
                return
            } catch (e: Exception) {
                WakeWordDiagnostics.log(this, TAG, "startActivity foreground échoué: ${e.message}")
            }
        }

        // Hors app : full-screen intent + tentative startActivity
        try {
            showVoiceCaptureFullScreen(captureIntent)
        } catch (e: Exception) {
            WakeWordDiagnostics.log(this, TAG, "fullScreenIntent échoué: ${e.message}")
        }
        try {
            startActivity(captureIntent)
        } catch (e: Exception) {
            WakeWordDiagnostics.log(this, TAG, "startActivity background: ${e.message} — notification affichée")
        }
    }

    private fun showVoiceCaptureFullScreen(captureIntent: Intent) {
        val channelId = "vanelle_voice_capture"
        val nm = getSystemService(NotificationManager::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(
                channelId,
                "Dictée Vanelle",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Ouvre la reconnaissance vocale après Cassandra"
                setSound(null, null)
                enableVibration(true)
            }
            nm?.createNotificationChannel(ch)
        }

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (android.os.Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)

        val fullScreenPi = PendingIntent.getActivity(this, 42, captureIntent, flags)
        val contentPi = PendingIntent.getActivity(this, 43, captureIntent, flags)

        val notif = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Vanelle t'écoute")
            .setContentText("Touche ici ou parle — Cassandra a entendu")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(fullScreenPi, true)
            .setContentIntent(contentPi)
            .setAutoCancel(true)
            .setTimeoutAfter(8_000)
            .build()

        nm?.notify(42, notif)
        WakeWordDiagnostics.log(this, TAG, "notification full-screen dictée publiée")
    }

    private fun beginSpeechCapture() {
        if (isServiceDestroyed || !capturingCommand) return
        // Déjà en écoute commande → ne pas relancer (évite micro "aléatoire")
        if (rec != null) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            WakeWordDiagnostics.log(this, TAG, "ERREUR : SpeechRecognizer.isRecognitionAvailable=false (aucun moteur de reconnaissance vocale sur cet appareil/cette ROM)")
            capturingCommand = false
            resumeOpenWakeWord()
            return
        }
        try {
            try { rec?.destroy() } catch (_: Exception) {}
            rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onResults(r: Bundle?) {
                        if (isServiceDestroyed) return
                        var t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()?.trim().orEmpty()
                        if (t.isBlank()) t = lastPartialResult.trim()
                        lastPartialResult = ""
                        WakeWordDiagnostics.log(this@WakeWordService, TAG, "commande captée : \"$t\"")
                        try { rec?.destroy() } catch (_: Exception) {}
                        rec = null
                        commandTimeoutJob?.cancel()
                        capturingCommand = false
                        // Réarme Cassandra tout de suite : la tâche tourne en parallèle
                        resumeOpenWakeWord()
                        if (t.isNotBlank()) {
                            scope.launch { handleCommand(t) }
                        }
                    }

                    override fun onError(e: Int) {
                        WakeWordDiagnostics.log(this@WakeWordService, TAG, "ERREUR SpeechRecognizer : ${speechErrorLabel(e)}")
                        try { rec?.cancel() } catch (_: Exception) {}
                        try { rec?.destroy() } catch (_: Exception) {}
                        rec = null
                        commandTimeoutJob?.cancel()
                        // Si on a entendu un partiel, on l'utilise au lieu d'abandonner
                        val partial = lastPartialResult.trim()
                        if (partial.isNotBlank() && (
                                e == SpeechRecognizer.ERROR_NO_MATCH ||
                                e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                            )
                        ) {
                            WakeWordDiagnostics.log(this@WakeWordService, TAG, "commande via partiel : \"$partial\"")
                            lastPartialResult = ""
                            capturingCommand = false
                            resumeOpenWakeWord()
                            scope.launch { handleCommand(partial) }
                            return
                        }
                        val canRetry = !isServiceDestroyed && speechRetryLeft > 0 && (
                            e == SpeechRecognizer.ERROR_NO_MATCH ||
                            e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                            e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                            e == SpeechRecognizer.ERROR_CLIENT
                        )
                        if (canRetry) {
                            speechRetryLeft--
                            WakeWordDiagnostics.log(
                                this@WakeWordService, TAG,
                                "nouvelle tentative micro (${speechRetryLeft} restantes)…"
                            )
                            scope.launch {
                                delay(700)
                                if (!isServiceDestroyed && capturingCommand) beginSpeechCapture()
                            }
                            return
                        }
                        capturingCommand = false
                        if (!isServiceDestroyed) resumeOpenWakeWord()
                    }

                    override fun onReadyForSpeech(p: Bundle?) {
                        WakeWordDiagnostics.log(this@WakeWordService, TAG, "SpeechRecognizer prêt — parle maintenant")
                    }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                    override fun onPartialResults(p: Bundle?) {
                        val part = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()?.trim().orEmpty()
                        if (part.isNotBlank()) {
                            lastPartialResult = part
                            WakeWordDiagnostics.log(this@WakeWordService, TAG, "partiel: \"$part\"")
                        }
                    }
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                    // Partiels : si NO_MATCH final, on récupère quand même ce qui a été entendu
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    // Pas de timeouts silence trop courts (cause fréquente de NO_MATCH en 1s)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1200)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                }
                try {
                    WakeWordDiagnostics.log(this@WakeWordService, TAG, "micro commande activé — parle maintenant")
                    startListening(intent)
                    commandTimeoutJob = scope.launch {
                        delay(5_000)
                        if (!isServiceDestroyed && capturingCommand) {
                            WakeWordDiagnostics.log(
                                this@WakeWordService, TAG,
                                "timeout SpeechRecognizer (5s) → retour à openWakeWord"
                            )
                            try { rec?.cancel() } catch (_: Exception) {}
                            try { rec?.destroy() } catch (_: Exception) {}
                            rec = null
                            capturingCommand = false
                            resumeOpenWakeWord()
                        }
                    }
                } catch (e: Exception) {
                    WakeWordDiagnostics.log(this@WakeWordService, TAG, "ERREUR startListening : ${e.message}")
                    try { rec?.destroy() } catch (_: Exception) {}
                    rec = null
                    capturingCommand = false
                    resumeOpenWakeWord()
                }
            }
        } catch (e: Exception) {
            WakeWordDiagnostics.log(this, TAG, "ERREUR création SpeechRecognizer : ${e.message}")
            capturingCommand = false
            resumeOpenWakeWord()
        }
    }

    private fun speechErrorLabel(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH -> "aucune parole reconnue (ERROR_NO_MATCH)"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "silence, personne n'a parlé à temps (ERROR_SPEECH_TIMEOUT)"
        SpeechRecognizer.ERROR_NETWORK -> "erreur réseau (ERROR_NETWORK)"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "délai réseau dépassé (ERROR_NETWORK_TIMEOUT)"
        SpeechRecognizer.ERROR_AUDIO -> "erreur audio matérielle (ERROR_AUDIO)"
        SpeechRecognizer.ERROR_CLIENT -> "erreur côté app (ERROR_CLIENT)"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "permission micro refusée (ERROR_INSUFFICIENT_PERMISSIONS)"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "moteur de reconnaissance déjà occupé (ERROR_RECOGNIZER_BUSY)"
        SpeechRecognizer.ERROR_SERVER -> "erreur serveur du moteur de reconnaissance (ERROR_SERVER)"
        else -> "code $code"
    }

    private fun resumeOpenWakeWord() {
        if (isServiceDestroyed) return
        capturingCommand = false
        scope.launch {
            // Réarme Cassandra immédiatement pour accepter une nouvelle commande en parallèle
            delay(250)
            if (!isServiceDestroyed) startOpenWakeWordListening()
        }
    }

    private fun findWakeIndex(text: String): Int {
        val lower = text.lowercase()
        val regex = Regex("[a-zàâäéèêëîïôöùûüç]+")
        for (m in regex.findAll(lower)) {
            val w = m.value
            if (w in wakeVariants ||
                FuzzyMatch.close(w, "cassandra", 2) ||
                FuzzyMatch.close(w, "cassandre", 2)
            ) return m.range.first
        }
        return -1
    }

    private fun wakeWordEnd(text: String, startIdx: Int): Int {
        val lower = text.lowercase()
        val regex = Regex("[a-zàâäéèêëîïôöùûüç]+")
        val m = regex.find(lower, startIdx) ?: return startIdx
        return m.range.last + 1
    }

    private fun handleCommand(text: String) {
        if (isServiceDestroyed || text.isBlank()) return
        if (TranslateModePrefs.isActive(this)) {
            handleTranslateMode(text)
            return
        }
        val idx = findWakeIndex(text)
        val original = if (idx >= 0) {
            val endIdx = wakeWordEnd(text, idx)
            text.substring(endIdx.coerceAtMost(text.length)).trim().ifEmpty { text.trim() }
        } else text.trim()
        dispatchCommand(original, original.lowercase())
    }

    private fun dispatchCommand(originalCmd: String, cmd: String) {
        if (isServiceDestroyed) return
        val parsed = CommandParser.parse(originalCmd)
        if (parsed.intent == CommandIntent.CALL_CONTACT ||
            parsed.intent == CommandIntent.SEND_MESSAGE
        ) {
            try {
                val i = Intent(this@WakeWordService, MainActivity::class.java).apply {
                    putExtra(
                        "confirm_type",
                        if (parsed.intent == CommandIntent.CALL_CONTACT) "call" else "sms"
                    )
                    putExtra("confirm_name", parsed.args["name"] ?: "")
                    putExtra("confirm_message", parsed.args["message"] ?: "")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(i)
            } catch (_: Exception) {
            }
            return
        }
        scope.launch {
            if (isServiceDestroyed) return@launch
            try {
                val i = Intent(this@WakeWordService, MainActivity::class.java).apply {
                    putExtra("pending_command", originalCmd.ifBlank { cmd })
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(i)
            } catch (_: Exception) {
            }
        }
    }

    private fun handleTranslateMode(text: String) {
        if (isServiceDestroyed) return
        val lower = text.lowercase()
        val parsed = CommandParser.parse(text)
        if (parsed.intent == CommandIntent.TRANSLATE_MODE_OFF ||
            lower.contains("quitte mode") ||
            lower.contains("stop traduction") ||
            lower.contains("arrête traduction") ||
            lower.contains("arrete traduction")
        ) {
            TranslateModePrefs.stop(this)
            try {
                tts?.language = Locale.FRANCE
                tts?.speak("Mode traduction désactivé", TextToSpeech.QUEUE_FLUSH, null, "tr_off")
            } catch (_: Exception) {
            }
            return
        }
        val src = TranslateModePrefs.source(this)
        val tgt = TranslateModePrefs.target(this)
        scope.launch {
            if (isServiceDestroyed) return@launch
            val translated = withContext(Dispatchers.IO) {
                TranslateHelper(this@WakeWordService).translateText(text, src, tgt)
            }
            if (isServiceDestroyed) return@launch
            try {
                val tag = when (tgt) {
                    "zh-CN" -> "zh"
                    "auto" -> "fr"
                    else -> tgt
                }
                tts?.language = Locale.forLanguageTag(tag)
            } catch (_: Exception) {
                try { tts?.language = Locale.FRANCE } catch (_: Exception) {}
            }
            try {
                if (translated.isNotBlank() &&
                    !translated.startsWith("Traduction indisponible")
                ) {
                    tts?.speak(translated, TextToSpeech.QUEUE_FLUSH, null, "tr_out")
                } else {
                    tts?.language = Locale.FRANCE
                    tts?.speak(
                        "Traduction indisponible, vérifie ta connexion",
                        TextToSpeech.QUEUE_FLUSH, null, "tr_err"
                    )
                }
            } catch (_: Exception) {
            }
        }
    }

    override fun onDestroy() {
        isServiceDestroyed = true
        isRunning = false
        capturingCommand = false
        commandTimeoutJob?.cancel()
        try { rec?.destroy() } catch (_: Exception) {}
        rec = null
        try { detector.stop() } catch (_: Exception) {}
        wakeListening = false
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        scope.cancel()
        super.onDestroy()
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        // Le service doit rester vivant en arrière-plan. Un START_STICKY permet
        // à Android de le recréer après une terminaison non volontaire.
        if (!isServiceDestroyed && !capturingCommand && !wakeListening && !detector.isListening()) {
            scope.launch { delay(250); if (!isServiceDestroyed) startOpenWakeWordListening() }
        }
        if (i?.action == VoiceCaptureActivity.ACTION_VOICE_RESULT) {
            val text = i.getStringExtra(VoiceCaptureActivity.EXTRA_TEXT)?.trim().orEmpty()
            commandTimeoutJob?.cancel()
            capturingCommand = false
            try { getSystemService(NotificationManager::class.java)?.cancel(42) } catch (_: Exception) {}
            if (text.isNotBlank()) {
                WakeWordDiagnostics.log(this, TAG, "commande captée (UI système) : \"$text\"")
                scope.launch { handleCommand(text) }
            } else {
                WakeWordDiagnostics.log(this, TAG, "reconnaissance système : aucune phrase")
            }
            resumeOpenWakeWord()
        }
        return START_STICKY
    }
}
