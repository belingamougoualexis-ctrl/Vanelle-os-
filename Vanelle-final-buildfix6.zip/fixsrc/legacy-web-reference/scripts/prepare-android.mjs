#!/usr/bin/env node
/**
 * Prepare a Capacitor Android project so it compiles on JVM 17 with llama.cpp.
 *
 * Usage:
 *   npm run build
 *   npx cap add android   # first time only
 *   node scripts/prepare-android.mjs
 *   cd android && ./gradlew assembleDebug --init-script ../gradle/force-jvm17.gradle
 */
import { copyFileSync, existsSync, mkdirSync, readFileSync, writeFileSync, cpSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const androidApp = join(root, "android", "app");
const javaDir = join(androidApp, "src", "main", "java", "com", "vanelle", "app");
const nativeDir = join(root, "native", "android");

function patchJvm17(gradleFile) {
  if (!existsSync(gradleFile)) return;
  let s = readFileSync(gradleFile, "utf8");
  if (!s.includes("VERSION_17")) {
    s = s.replace(
      /android\s*\{/,
      `android {
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }`,
    );
  }
  if (!s.includes("jvmTarget")) {
    s += `

tasks.withType(org.jetbrains.kotlin.gradle.tasks.KotlinCompile).configureEach {
    compilerOptions.jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
}
`;
  }
  if (!s.includes("llamacpp-kotlin")) {
    s = s.replace(
      /dependencies\s*\{/,
      `dependencies {
    implementation("io.github.ljcamargo:llamacpp-kotlin:0.4.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.1")
`,
    );
  }
  writeFileSync(gradleFile, s);
}

function patchMainActivity(file) {
  if (!existsSync(file)) return;
  let s = readFileSync(file, "utf8");
  if (!s.includes("LlamaEnginePlugin")) {
    if (s.includes("super.onCreate")) {
      s = s.replace(
        "super.onCreate",
        "registerPlugin(LlamaEnginePlugin::class.java)\n        super.onCreate",
      );
    }
    if (!s.includes("import com.vanelle.app.LlamaEnginePlugin") && s.includes("package ")) {
      s = s.replace(
        /package .+\n/,
        (m) => m + "\nimport com.vanelle.app.LlamaEnginePlugin\n",
      );
    }
    writeFileSync(file, s);
  }
}

function main() {
  if (!existsSync(androidApp)) {
    console.log("Pas de dossier android/ — le module Gradle racine :app est déjà prêt.");
    console.log("Compilez avec : ./gradlew :app:assembleDebug");
    return;
  }
  mkdirSync(javaDir, { recursive: true });
  for (const name of ["LlamaEngine.kt", "LlamaEnginePlugin.kt"]) {
    copyFileSync(join(nativeDir, name), join(javaDir, name));
  }

  const gradleKts = join(androidApp, "build.gradle.kts");
  const gradleGroovy = join(androidApp, "build.gradle");
  patchJvm17(existsSync(gradleKts) ? gradleKts : gradleGroovy);

  const activityKt = join(javaDir, "MainActivity.kt");
  const activityJava = join(javaDir, "MainActivity.java");
  patchMainActivity(existsSync(activityKt) ? activityKt : activityJava);

  const webCandidates = [
    join(root, "dist", "client"),
    join(root, ".output", "public"),
    join(root, "dist"),
  ];
  const dest = join(androidApp, "src", "main", "assets", "public");
  for (const src of webCandidates) {
    if (existsSync(src)) {
      mkdirSync(dirname(dest), { recursive: true });
      cpSync(src, dest, { recursive: true });
      console.log("Assets web copiés depuis", src);
      break;
    }
  }
  console.log("Android Capacitor préparé (JVM 17 + llama.cpp).");
}

main();
