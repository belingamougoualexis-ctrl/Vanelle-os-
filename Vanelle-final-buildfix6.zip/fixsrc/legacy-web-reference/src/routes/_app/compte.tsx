import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button, Card, Input, Label, PageHead, Tag } from "@/components/vanelle/ui";
import { EngineList } from "@/components/vanelle/engine-list";
import { useEngineStore } from "@/lib/vanelle/engine-store";
import { Store } from "@/lib/vanelle/store";
import type { Profile } from "@/lib/vanelle/types";
import { blankProfile } from "@/lib/vanelle/types";

export const Route = createFileRoute("/_app/compte")({
  component: ComptePage,
});

function ComptePage() {
  const [profile, setProfile] = useState<Profile>(blankProfile());
  const [status, setStatus] = useState("");
  const { localReady, localProbing, localProgress, localDetail } = useEngineStore();

  useEffect(() => {
    void Store.getProfile().then(setProfile);
  }, []);

  async function saveProfile() {
    await Store.saveProfile(profile);
    setStatus("Profil enregistré.");
  }

  async function exportAll() {
    const ais = await Store.getAllAIs();
    const chats = Object.fromEntries(await Promise.all(ais.map(async (ai) => [ai.id, await Store.getChat(ai.id)] as const)));
    const { BlobWriter, TextReader, ZipWriter } = await import("@zip.js/zip.js");
    const writer = new ZipWriter(new BlobWriter("application/zip"));
    const exportProfile = { ...profile, engines: [], activeEngineId: "local" };
    await writer.add("profile.json", new TextReader(JSON.stringify(exportProfile, null, 2)));
    for (const ai of ais) {
      await writer.add(`ais/${ai.id}/config.json`, new TextReader(JSON.stringify(ai, null, 2)));
      await writer.add(`ais/${ai.id}/chat.json`, new TextReader(JSON.stringify(chats[ai.id] || [], null, 2)));
    }
    await writer.add("README.txt", new TextReader("Sauvegarde Vanelle locale. Moteur unique : llama.cpp + modèle GGUF local.\n"));
    const blob = await writer.close();
    downloadBlob(blob, "vanelle-sauvegarde.zip");
    setStatus("Export ZIP terminé.");
  }

  async function importAll(file: File) {
    try {
      const { BlobReader, TextWriter, ZipReader } = await import("@zip.js/zip.js");
      const reader = new ZipReader(new BlobReader(file));
      const entries = await reader.getEntries();
      const profileEntry = entries.find((e) => e.filename === "profile.json");
      if (profileEntry && "getData" in profileEntry && profileEntry.getData) {
        const data = JSON.parse(await profileEntry.getData(new TextWriter())) as Partial<Profile>;
        const next = { ...blankProfile(), ...data, engines: [], activeEngineId: "local" as const };
        await Store.saveProfile(next);
        setProfile(next);
      }
      for (const entry of entries.filter((e) => !e.directory && /\/config\.json$/.test(e.filename))) {
        if (!("getData" in entry) || !entry.getData) continue;
        await Store.saveAI(JSON.parse(await entry.getData(new TextWriter())));
      }
      await reader.close();
      setStatus("Sauvegarde ZIP importée.");
    } catch {
      setStatus("Ce fichier ZIP n'a pas pu être lu.");
    }
  }

  return (
    <>
      <PageHead eyebrow="Compte" title="Compte & moteur local">
        Vos IA restent sur l'appareil. Llama.cpp est le seul moteur : son modèle GGUF est téléchargé automatiquement à l'ouverture puis chargé en mémoire.
      </PageHead>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <h2 className="mt-0 text-base font-bold">Profil</h2>
          <Label>Votre nom ou pseudo</Label>
          <Input value={profile.pseudo} onChange={(e) => setProfile({ ...profile, pseudo: e.target.value })} placeholder="Ex. Camille" />
          <Button className="mt-3.5" onClick={() => void saveProfile()}>Enregistrer</Button>
        </Card>
        <Card>
          <h2 className="mt-0 text-base font-bold">Sauvegarde ZIP</h2>
          <p className="text-[12.5px] text-ink-soft">Toutes vos IA, apprentissages, données analysées et conversations sont exportés dans une seule archive ZIP.</p>
          <Button variant="ghost" size="sm" className="mt-3" onClick={() => void exportAll()}>Exporter toutes mes données (.zip)</Button>
          <Label>Importer une sauvegarde (.zip)</Label>
          <Input type="file" accept=".zip,application/zip" onChange={(e) => { const f = e.target.files?.[0]; if (f) void importAll(f); }} />
          {status ? <p className="mt-2 text-xs text-ink-soft">{status}</p> : null}
        </Card>
      </div>

      <Card className="mt-4">
        <h2 className="mt-0 flex items-center gap-2 text-base font-bold">
          Llama.cpp
          <Tag on={localReady}>{localReady ? "en mémoire" : localProbing ? "chargement" : "en attente"}</Tag>
        </h2>
        <p className="text-[12.5px] leading-relaxed text-ink-soft">
          Modèle open source léger SmolLM2-360M-Instruct, format GGUF Q4_K_M (~271 Mo). Le téléchargement est local et automatique au démarrage. Aucun moteur LLM distant n'est utilisé.
        </p>
        {localProbing ? (
          <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-mist">
            <div className="h-full bg-accent transition-[width] duration-300" style={{ width: `${Math.max(2, Math.round(localProgress * 100))}%` }} />
          </div>
        ) : null}
        <p className="mt-2 font-display text-[11.5px] text-ink-soft">{localDetail}</p>
        <div className="mt-3"><EngineList /></div>
      </Card>
    </>
  );
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
