import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button, Empty, PageHead, Tag } from "@/components/vanelle/ui";
import { Store } from "@/lib/vanelle/store";
import type { VanelleAI } from "@/lib/vanelle/types";

export const Route = createFileRoute("/_app/mes-ia")({
  component: MesIAPage,
});

function MesIAPage() {
  const [ais, setAis] = useState<VanelleAI[] | null>(null);
  useEffect(() => {
    void Store.getAllAIs().then((list) => setAis(list.sort((a, b) => b.createdAt - a.createdAt)));
  }, []);

  return (
    <>
      <PageHead eyebrow="Atelier" title="Mes IA">
        {ais ? `${ais.length} IA en cours de construction.` : "Chargement…"}
      </PageHead>
      {!ais ? null : ais.length === 0 ? (
        <Empty>
          Vous n'avez encore créé aucune IA.
          <div className="mt-3.5">
            <Link to="/">
              <Button>Créer ma première IA</Button>
            </Link>
          </div>
        </Empty>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {ais.map((ai) => (
            <Link
              key={ai.id}
              to="/ia/$id"
              params={{ id: ai.id }}
              search={{ tab: "vue" }}
              className="v-card block transition-[transform,box-shadow] duration-150 hover:-translate-y-0.5 hover:shadow-[0_8px_20px_rgba(14,14,16,0.08)]"
            >
              <h3 className="m-0 text-[14.5px] font-bold">{ai.nom}</h3>
              <p className="mt-1 text-[12.5px] text-ink-soft">{ai.description || "Pas encore de description."}</p>
              <div className="mt-2.5 flex items-center justify-between">
                <Tag on={ai.deployed}>{ai.deployed ? "déployée" : "en cours"}</Tag>
                <span className="text-[11px] text-ink-soft">
                  {ai.files.length} fichier(s) · {ai.training.length} notion(s) · {ai.apis.length} API
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </>
  );
}
