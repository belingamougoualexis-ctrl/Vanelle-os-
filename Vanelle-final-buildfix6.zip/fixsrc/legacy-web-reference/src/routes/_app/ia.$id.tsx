import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ChatPanel } from "@/components/vanelle/chat-panel";
import { ApiForm, EngineList } from "@/components/vanelle/engine-list";
import { Button, Card, Empty, Input, Label, PageHead, Select, Tag, Textarea } from "@/components/vanelle/ui";
import { CATEGORIES, cn, fmtSize, uid } from "@/lib/utils";
import { ingestFiles } from "@/lib/vanelle/files";
import { Secrets } from "@/lib/vanelle/secrets";
import { Store } from "@/lib/vanelle/store";
import type { UserApi, VanelleAI } from "@/lib/vanelle/types";

export const Route = createFileRoute("/_app/ia/$id")({
  validateSearch: (raw: Record<string, unknown>) => ({
    tab: typeof raw.tab === "string" ? raw.tab : "vue",
  }),
  component: AIPage,
});

function AIPage() {
  const { id } = Route.useParams();
  const { tab } = Route.useSearch();
  const navigate = useNavigate();
  const [ai, setAI] = useState<VanelleAI | null>(null);
  const [missing, setMissing] = useState(false);

  const load = useCallback(async () => {
    const row = await Store.getAI(id);
    if (!row) {
      setMissing(true);
      return;
    }
    setAI(row);
  }, [id]);

  useEffect(() => {
    void load();
  }, [load]);

  async function save(next: VanelleAI) {
    setAI(next);
    await Store.saveAI(next);
  }
  if (missing) {
    return (
      <Empty>
        Cette IA est introuvable. Elle a peut-être été supprimée.
        <div className="mt-3.5">
          <Link to="/mes-ia">
            <Button>Retour à Mes IA</Button>
          </Link>
        </div>
      </Empty>
    );
  }
  if (!ai) return <p className="text-ink-soft">Chargement…</p>;

  if (tab === "tester") {
    return <ChatPanel ai={ai} onAI={save} />;
  }

  return (
    <>
      <PageHead eyebrow="Profil de mon IA" title={`« ${ai.nom} »`}>
        {ai.description || "Pas encore de description."}
        <div className="pill-row mt-2 flex flex-wrap gap-1.5">
          <Tab id={ai.id} tab="vue" current={tab} label="Vue d'ensemble" />
          <Tab id={ai.id} tab="apprentissage" current={tab} label="Apprentissage (A à Z)" />
          <Tab id={ai.id} tab="fichiers" current={tab} label="Fichiers & données" />
          <Tab id={ai.id} tab="api" current={tab} label="Intégrations API" />
          <Tab id={ai.id} tab="tester" current={tab} label="Chat" />
        </div>
      </PageHead>
      {tab === "vue" && <TabVue ai={ai} onSave={save} onGone={() => navigate({ to: "/mes-ia" })} />}
      {tab === "apprentissage" && <TabApprentissage ai={ai} onSave={save} />}
      {tab === "fichiers" && <TabFichiers ai={ai} onSave={save} />}
      {tab === "api" && <TabApi ai={ai} onSave={save} />}
    </>
  );
}

function Tab({ id, tab, current, label }: { id: string; tab: string; current: string; label: string }) {
  const active = current === tab;
  return (
    <Link
      to="/ia/$id"
      params={{ id }}
      search={{ tab }}
      className={cn(
        "inline-flex min-h-10 items-center rounded-md px-3 text-xs font-semibold",
        active ? "bg-accent text-white" : "border-[1.5px] border-line bg-paper text-ink hover:bg-mist",
      )}
    >
      {label}
    </Link>
  );
}

function Step({ n, children }: { n: number; children: React.ReactNode }) {
  return (
    <h2 className="mt-0 flex items-center text-base font-bold">
      <span className="mr-2 inline-flex size-5 items-center justify-center rounded-full bg-accent text-[11px] font-bold text-white">
        {n}
      </span>
      {children}
    </h2>
  );
}

function TabVue({
  ai,
  onSave,
  onGone,
}: {
  ai: VanelleAI;
  onSave: (ai: VanelleAI) => Promise<void>;
  onGone: () => void;
}) {
  const [nom, setNom] = useState(ai.nom);
  const [description, setDescription] = useState(ai.description);
  const [modele, setModele] = useState(ai.modele);
  const [status, setStatus] = useState("");
  const uploadRef = useRef<HTMLInputElement>(null);
  const zipIARef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setNom(ai.nom);
    setDescription(ai.description);
    setModele(ai.modele);
  }, [ai.id, ai.nom, ai.description, ai.modele]);

  async function handleUpload(files: File[]) {
    const next = { ...ai, files: [...ai.files] };
    const r = await ingestFiles(files, next, setStatus);
    await onSave(next);
    setStatus(r.added ? `${r.added} fichier(s) ajouté(s).` : "Aucun fichier analysé.");
    if (r.skipped.length) setStatus(r.skipped.join(" "));
    else if (r.added) setStatus(`${r.added} fichier(s) indexé(s).`);
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[1.1fr_1fr_0.8fr]">
      <Card>
        <h2 className="mt-0 text-base font-bold">Fiche d'identité</h2>
        <Label>Nom de l'IA</Label>
        <Input value={nom} onChange={(e) => setNom(e.target.value)} />
        <Label>Description</Label>
        <Textarea value={description} onChange={(e) => setDescription(e.target.value)} />
        <Label>Style de base</Label>
        <Select value={modele} onChange={(e) => setModele(e.target.value)}>
          {["Généraliste", "Expert technique", "Conseil & vente", "Support client", "Créatif"].map((m) => (
            <option key={m}>{m}</option>
          ))}
        </Select>
        <Button
          className="mt-4"
          block
          onClick={() => {
            void onSave({ ...ai, nom: nom.trim() || ai.nom, description: description.trim(), modele });
          }}
        >
          Enregistrer la fiche
        </Button>
        <Button
          variant="ghost"
          className="mt-2"
          block
          onClick={() => {
            if (!confirm("Supprimer définitivement cette IA et tout son apprentissage ?")) return;
            void Store.deleteAI(ai.id).then(onGone);
          }}
        >
          Supprimer cette IA
        </Button>
      </Card>

      <Card>
        <Step n={1}>Ajouter des données</Step>
        <p className="text-xs text-ink-soft">
          ZIP, TXT, MD, CSV, JSON, HTML, JS, CSS, PDF — jusqu'à 3 Go. Les textes sont extraits, découpés, et réellement injectés dans le chat.
        </p>
        <button
          type="button"
          className="mt-3 w-full rounded-md border-[1.5px] border-dashed border-line bg-mist px-5 py-5 text-center hover:border-accent hover:bg-accent-soft"
          onClick={() => uploadRef.current?.click()}
        >
          Uploader
          <small className="mt-1.5 block text-[11px] text-ink-soft">TXT, MD, CSV, JSON, HTML, JS, CSS, PDF, ZIP (max 3 Go)</small>
        </button>
        <input
          ref={uploadRef}
          type="file"
          className="hidden"
          multiple
          accept=".zip,.txt,.md,.csv,.json,.html,.js,.css,.pdf,application/zip,text/*"
          onChange={(e) => {
            const files = Array.from(e.target.files || []);
            e.target.value = "";
            if (files.length) void handleUpload(files);
          }}
        />
        {status ? <div className="mt-2 text-xs text-ink-soft">{status}</div> : null}

        <hr className="my-4.5 border-0 border-t border-line" />
        <Step n={2}>Configurer une API</Step>
        <p className="text-xs text-ink-soft">
          Documentez un service externe. L'IA pourra vraiment l'appeler pendant le chat (et vous pouvez aussi en ajouter depuis le menu ⋮ du chat).
        </p>
        <ApiForm
          onAdd={async (form) => {
            const api: UserApi = {
              id: uid(),
              nom: form.nom,
              endpoint: form.endpoint,
              method: form.method,
              description: form.description,
              ts: Date.now(),
            };
            if (form.cle) Secrets.set(api.id, form.cle);
            await onSave({ ...ai, apis: [...ai.apis, api] });
          }}
        />

        <hr className="my-4.5 border-0 border-t border-line" />
        <Step n={3}>Moteur de cette IA</Step>
        <p className="mb-2 text-xs text-ink-soft">
          Llama.cpp est l'unique moteur. Son modèle GGUF est téléchargé automatiquement à l'ouverture de l'application puis chargé en mémoire.
        </p>
        <EngineList />

        <hr className="my-4.5 border-0 border-t border-line" />
        <Step n={4}>Ajouter une IA complète (ZIP)</Step>
        <button
          type="button"
          className="mt-2 w-full rounded-md border-[1.5px] border-dashed border-line bg-mist px-5 py-5 text-center hover:border-accent hover:bg-accent-soft"
          onClick={() => zipIARef.current?.click()}
        >
          Uploader l'IA (.zip)
        </button>
        <input
          ref={zipIARef}
          type="file"
          className="hidden"
          accept=".zip,application/zip"
          onChange={(e) => {
            const file = e.target.files?.[0];
            e.target.value = "";
            if (file) void importIAZip(file, ai, onSave);
          }}
        />
      </Card>

      <div>
        <Card>
          <h2 className="mt-0 text-base font-bold">Résumé</h2>
          <Row k="Notions enseignées" v={String(ai.training.length)} />
          <Row k="Fichiers analysés" v={String(ai.files.length)} />
          <Row k="API connectées" v={String(ai.apis.length)} />
          <div className="flex items-center justify-between border-b border-line py-2.5 last:border-0 text-sm">
            <span>Statut</span>
            <Tag on={ai.deployed}>{ai.deployed ? "déployée" : "brouillon"}</Tag>
          </div>
        </Card>
        <Link to="/ia/$id" params={{ id: ai.id }} search={{ tab: "tester" }}>
          <Button variant="ok" className="mt-3.5" block>
            Ouvrir le chat de test
          </Button>
        </Link>
        <Button
          variant="ghost"
          className="mt-2"
          block
          onClick={() => {
            void onSave({ ...ai, deployed: true, deployedAt: Date.now() });
          }}
        >
          Marquer déployée
        </Button>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between border-b border-line py-2.5 text-sm last:border-0">
      <span>{k}</span>
      <strong>{v}</strong>
    </div>
  );
}

function TabApprentissage({ ai, onSave }: { ai: VanelleAI; onSave: (ai: VanelleAI) => Promise<void> }) {
  const [cat, setCat] = useState<string>(CATEGORIES[0]);
  const [q, setQ] = useState("");
  const [a, setA] = useState("");
  const [error, setError] = useState("");

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <h2 className="mt-0 text-base font-bold">Enseigner une notion</h2>
        <p className="text-xs text-ink-soft">
          Ces paires question/réponse sont injectées dans le system prompt à chaque message — elles ne restent pas dans un tiroir.
        </p>
        <Label>Catégorie</Label>
        <Select value={cat} onChange={(e) => setCat(e.target.value)}>
          {CATEGORIES.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </Select>
        <Label>Question / situation</Label>
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ex. Quels sont vos horaires ?" />
        <Label>Réponse que doit donner l'IA</Label>
        <Textarea value={a} onChange={(e) => setA(e.target.value)} placeholder="Ex. Nous répondons du lundi au vendredi, 9h–18h." />
        {error ? <p className="mt-2 text-xs text-red-700">{error}</p> : null}
        <Button
          className="mt-3"
          block
          onClick={() => {
            if (!q.trim() || !a.trim()) {
              setError("Renseignez la question et la réponse.");
              return;
            }
            setError("");
            void onSave({
              ...ai,
              training: [...ai.training, { id: uid(), categorie: cat, question: q.trim(), reponse: a.trim(), ts: Date.now() }],
            });
            setQ("");
            setA("");
          }}
        >
          Ajouter à l'apprentissage
        </Button>
      </Card>
      <Card>
        <h2 className="mt-0 text-base font-bold">Ce qu'elle sait déjà ({ai.training.length})</h2>
        {ai.training.length === 0 ? (
          <p className="text-[12.5px] text-ink-soft">Rien enseigné pour l'instant — commencez par l'identité de votre IA.</p>
        ) : (
          CATEGORIES.map((c) => {
            const items = ai.training.filter((t) => t.categorie === c);
            if (!items.length) return null;
            return (
              <div key={c}>
                <h3 className="mt-3 mb-1 text-[13px] font-semibold text-ink-soft">{c}</h3>
                {items.map((t) => (
                  <div key={t.id} className="flex items-start justify-between gap-2 border-b border-line py-2">
                    <div>
                      <strong className="text-sm">{t.question}</strong>
                      <div className="text-[11.5px] text-ink-soft">{t.reponse}</div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => void onSave({ ...ai, training: ai.training.filter((x) => x.id !== t.id) })}
                    >
                      Retirer
                    </Button>
                  </div>
                ))}
              </div>
            );
          })
        )}
      </Card>
    </div>
  );
}

function TabFichiers({ ai, onSave }: { ai: VanelleAI; onSave: (ai: VanelleAI) => Promise<void> }) {
  return (
    <Card>
      <h2 className="mt-0 text-base font-bold">Fichiers analysés ({ai.files.length})</h2>
      {ai.files.length === 0 ? (
        <p className="text-[12.5px] text-ink-soft">Aucun fichier pour l'instant. Ajoutez-en depuis l'onglet Vue d'ensemble — limite 3 Go.</p>
      ) : (
        ai.files.map((f) => (
          <div key={f.id} className="flex items-start justify-between gap-3 border-b border-line py-2.5">
            <div>
              <strong className="text-sm">{f.nom}</strong>
              <div className="text-[11.5px] text-ink-soft">
                {f.type} · {fmtSize(f.taille || 0)} · {f.chunks?.length || 0} extraits · issu de {f.source || ""}
              </div>
              {f.resume ? <div className="mt-1 text-[11.5px] text-ink-soft italic">{f.resume.slice(0, 140)}{f.resume.length > 140 ? "…" : ""}</div> : null}
            </div>
            <Button variant="ghost" size="sm" onClick={() => void onSave({ ...ai, files: ai.files.filter((x) => x.id !== f.id) })}>
              Retirer
            </Button>
          </div>
        ))
      )}
    </Card>
  );
}

function TabApi({ ai, onSave }: { ai: VanelleAI; onSave: (ai: VanelleAI) => Promise<void> }) {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <h2 className="mt-0 text-base font-bold">Ajouter une API</h2>
        <p className="text-xs text-ink-soft">Identique au formulaire du chat (menu ⋮) et de la vue d'ensemble. Plusieurs API possibles.</p>
        <ApiForm
          onAdd={async (form) => {
            const api: UserApi = {
              id: uid(),
              nom: form.nom,
              endpoint: form.endpoint,
              method: form.method,
              description: form.description,
              ts: Date.now(),
            };
            if (form.cle) Secrets.set(api.id, form.cle);
            await onSave({ ...ai, apis: [...ai.apis, api] });
          }}
        />
      </Card>
      <Card>
        <h2 className="mt-0 text-base font-bold">Intégrations API ({ai.apis.length})</h2>
        {ai.apis.length === 0 ? (
          <p className="text-[12.5px] text-ink-soft">Aucune API configurée.</p>
        ) : (
          ai.apis.map((a) => (
            <div key={a.id} className="flex items-start justify-between gap-2 border-b border-line py-2.5">
              <div>
                <strong className="text-sm">{a.nom}</strong>
                <div className="text-[11.5px] text-ink-soft">
                  {a.endpoint}
                  {Secrets.get(a.id) ? " · clé enregistrée" : ""} · {a.method}
                </div>
                {a.description ? <div className="mt-1 text-[11.5px] text-ink-soft">{a.description}</div> : null}
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  Secrets.remove(a.id);
                  void onSave({ ...ai, apis: ai.apis.filter((x) => x.id !== a.id) });
                }}
              >
                Retirer
              </Button>
            </div>
          ))
        )}
      </Card>
    </div>
  );
}

async function importIAZip(file: File, ai: VanelleAI, onSave: (ai: VanelleAI) => Promise<void>) {
  try {
    const { BlobReader, TextWriter, ZipReader } = await import("@zip.js/zip.js");
    const reader = new ZipReader(new BlobReader(file));
    const entries = await reader.getEntries();
    const config = entries.find((e) => !e.directory && e.filename.endsWith("config.json"));
    if (!config || !("getData" in config) || !config.getData) {
      await reader.close();
      return;
    }
    const text = await config.getData(new TextWriter());
    const imported = JSON.parse(text) as Partial<VanelleAI>;
    await onSave({
      ...ai,
      training: [...ai.training, ...(imported.training || [])],
      apis: [...ai.apis, ...(imported.apis || [])],
      files: [...ai.files, ...(imported.files || [])],
      systemPrompt: ai.systemPrompt || imported.systemPrompt || "",
      engineId: "local",
    });
    const chatEntry = entries.find((e) => !e.directory && e.filename.endsWith("chat.json"));
    if (chatEntry && "getData" in chatEntry && chatEntry.getData) {
      try {
        const chat = JSON.parse(await chatEntry.getData(new TextWriter()));
        if (Array.isArray(chat)) await Store.saveChat(ai.id, chat);
      } catch {
        /* conversation is optional in an IA export */
      }
    }
    await reader.close();
  } catch {
  }
}
