import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button, Card, Input, Label, PageHead, Select, Textarea } from "@/components/vanelle/ui";
import { Store } from "@/lib/vanelle/store";
import { blankAI, type VanelleAI } from "@/lib/vanelle/types";

export const Route = createFileRoute("/_app/")({
  component: CreerPage,
});

function CreerPage() {
  const navigate = useNavigate();
  const [nom, setNom] = useState("");
  const [description, setDescription] = useState("");
  const [modele, setModele] = useState("Généraliste");
  const [busy, setBusy] = useState(false);
  const [recent, setRecent] = useState<VanelleAI[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    void Store.getAllAIs().then((list) => setRecent(list.sort((a, b) => b.createdAt - a.createdAt).slice(0, 4)));
  }, []);

  async function submit() {
    if (!nom.trim()) {
      setError("Donnez un nom à votre IA avant de continuer.");
      return;
    }
    setBusy(true);
    try {
      const ai = blankAI({ nom: nom.trim(), description: description.trim(), modele });
      await Store.saveAI(ai);

      await navigate({ to: "/ia/$id", params: { id: ai.id }, search: { tab: "vue" } });
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <PageHead eyebrow="Étape 0" title="Créer une nouvelle IA">
        Donnez-lui un nom et un point de départ. Ensuite vous lui apprenez ce qu'elle doit savoir — notions, fichiers et données. Llama.cpp est le moteur local unique et se prépare automatiquement à l'ouverture.
      </PageHead>
      <Card className="max-w-[520px]">
        <Label>Nom de l'IA</Label>
        <Input value={nom} onChange={(e) => setNom(e.target.value)} placeholder="Ex. Solutions Pro" />
        <Label>Description</Label>
        <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="En une phrase, à quoi sert cette IA ?" />
        <Label>Style de base</Label>
        <Select value={modele} onChange={(e) => setModele(e.target.value)}>
          <option>Généraliste</option>
          <option>Expert technique</option>
          <option>Conseil & vente</option>
          <option>Support client</option>
          <option>Créatif</option>
        </Select>
        {error ? <p className="mb-2 text-xs text-red-700">{error}</p> : null}
        <Button className="mt-4" block disabled={busy} onClick={() => void submit()}>
          Commencer l'apprentissage
        </Button>
      </Card>
      {recent.length ? (
        <div className="mt-8 max-w-[520px]">
          <h2 className="mb-3 text-sm font-semibold text-ink-soft">IA récentes</h2>
          <div className="flex flex-col gap-2">
            {recent.map((ai) => (
              <Link
                key={ai.id}
                to="/ia/$id"
                params={{ id: ai.id }}
                search={{ tab: "vue" }}
                className="v-card block py-3 transition-transform duration-150 hover:-translate-y-0.5"
              >
                <strong className="text-sm">{ai.nom}</strong>
                <div className="text-xs text-ink-soft">{ai.description || "Pas encore de description."}</div>
              </Link>
            ))}
          </div>
        </div>
      ) : null}
    </>
  );
}
