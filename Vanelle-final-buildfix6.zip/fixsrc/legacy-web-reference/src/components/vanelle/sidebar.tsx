import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutGrid, MessageSquarePlus, Plus, Settings2, Sparkles } from "lucide-react";
import { useEffect } from "react";
import { cn } from "@/lib/utils";
import { startLocalOnBoot, useEngineStore } from "@/lib/vanelle/engine-store";

const NAV = [
  { to: "/", label: "Créer une IA", icon: Plus, match: (p: string) => p === "/" },
  { to: "/mes-ia", label: "Mes IA", icon: MessageSquarePlus, match: (p: string) => p.startsWith("/mes-ia") || p.startsWith("/ia/") },
  { to: "/dashboard", label: "Tableau de bord", icon: LayoutGrid, match: (p: string) => p.startsWith("/dashboard") },
  { to: "/compte", label: "Compte & moteurs", icon: Settings2, match: (p: string) => p.startsWith("/compte") },
];

export function Sidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { localReady, localStatus, localProgress, localDetail } = useEngineStore();

  useEffect(() => {
    startLocalOnBoot();
  }, []);

  return (
    <aside className="hidden shrink-0 flex-col bg-sidebar text-sidebar-text md:flex md:h-screen md:w-[232px] md:sticky md:top-0 md:overflow-y-auto">
      <div className="flex items-center gap-2.5 px-5 pt-5 pb-7">
        <div className="size-9 overflow-hidden rounded-[9px] bg-accent">
          <img src="/vanelle_logo.png" alt="Vanelle" className="size-full object-cover" />
        </div>
        <div className="font-display text-[15px] font-bold leading-tight tracking-wide text-white">
          VANELLE
          <small className="block text-[10px] font-medium tracking-[0.14em] text-accent">ATELIER IA</small>
        </div>
      </div>

      <nav className="flex flex-1 flex-col gap-5 px-3 pb-4">
        <div>
          <div className="mb-2 px-2.5 font-display text-[10px] font-semibold tracking-[0.12em] text-white/35 uppercase">
            Atelier
          </div>
          {NAV.slice(0, 3).map((item) => (
            <NavLink key={item.to} {...item} active={item.match(pathname)} />
          ))}
        </div>
        <div>
          <div className="mb-2 px-2.5 font-display text-[10px] font-semibold tracking-[0.12em] text-white/35 uppercase">
            Compte
          </div>
          <NavLink {...NAV[3]} active={NAV[3].match(pathname)} />
        </div>
      </nav>

      <div className="mt-auto border-t border-sidebar-line px-4 py-3.5">
        <div className="flex items-start gap-2 text-[11px] leading-snug text-white/55">
          <span
            className={cn(
              "mt-1 size-1.5 shrink-0 rounded-full",
              localReady ? "bg-ok" : localStatus === "error" ? "bg-red-400" : "bg-accent animate-pulse",
            )}
          />
          <span>{localReady ? "Llama.cpp prêt" : localDetail}</span>
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-[10px] text-cyan/80">
          <Sparkles className="size-3" strokeWidth={2} />
          {localReady ? "Modèle local chargé en mémoire" : `Téléchargement / chargement ${Math.round(localProgress * 100)} %`}
        </div>
      </div>
    </aside>
  );
}

function NavLink({
  to,
  label,
  icon: Icon,
  active,
}: {
  to: string;
  label: string;
  icon: typeof Plus;
  active: boolean;
}) {
  return (
    <Link
      to={to}
      className={cn(
        "mb-0.5 flex min-h-11 items-center gap-2.5 rounded-md px-2.5 py-2 text-[13.5px] font-medium transition-colors duration-150",
        active ? "bg-accent text-white" : "text-sidebar-text hover:bg-white/10 hover:text-white",
      )}
    >
      <Icon className="size-4 shrink-0" strokeWidth={1.8} />
      {label}
    </Link>
  );
}

export function MobileTopBar() {
  const { localReady, localStatus } = useEngineStore();
  return (
    <header
      className="flex items-center gap-2.5 bg-sidebar px-4 text-sidebar-text md:hidden"
      style={{ paddingTop: "calc(0.625rem + var(--safe-top))", paddingBottom: "0.625rem" }}
    >
      <div className="size-8 overflow-hidden rounded-[8px] bg-accent">
        <img src="/vanelle_logo.png" alt="Vanelle" className="size-full object-cover" />
      </div>
      <div className="font-display text-[14px] font-bold tracking-wide text-white">VANELLE</div>
      <span
        className={cn(
          "ml-auto size-2 shrink-0 rounded-full",
          localReady ? "bg-ok" : localStatus === "error" ? "bg-red-400" : "bg-accent animate-pulse",
        )}
        title={localReady ? "Llama.cpp prêt" : "Llama.cpp en préparation"}
      />
    </header>
  );
}

export function MobileTabBar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="v-tabbar fixed inset-x-0 bottom-0 z-30 flex md:hidden">
      {NAV.map((item) => {
        const active = item.match(pathname);
        const Icon = item.icon;
        return (
          <Link
            key={item.to}
            to={item.to}
            className={cn(
              "flex flex-1 flex-col items-center gap-0.5 py-2 text-[10.5px] font-medium",
              active ? "text-accent" : "text-ink-soft",
            )}
          >
            <Icon className="size-5" strokeWidth={active ? 2.2 : 1.8} />
            {item.label === "Tableau de bord" ? "Tableau" : item.label === "Compte & moteurs" ? "Compte" : item.label}
          </Link>
        );
      })}
    </nav>
  );
}
