import { useState } from "react";
import { useEngineStore } from "@/lib/vanelle/engine-store";
import { Button, Input, Label } from "./ui";

/**
 * Le sélecteur d'ancien moteurs cloud a été supprimé.
 * Cette carte expose uniquement le moteur local llama.cpp.
 */
export function EngineList() {
  const { localReady, localProbing, localProgress, localDetail, loadLocal, reloadLocal } = useEngineStore();
  const action = localReady ? reloadLocal : loadLocal;

  return (
    <div>
      <div className="rounded-lg border border-line bg-mist p-3.5">
        <div className="flex items-center justify-between gap-3">
          <div>
            <div className="text-sm font-semibold">Llama.cpp — moteur local unique</div>
            <div className="mt-0.5 text-[11.5px] text-ink-soft">SmolLM2-360M-Instruct · GGUF Q4_K_M · ~271 Mo</div>
          </div>
          <span className="rounded-full border border-line bg-paper px-2 py-1 text-[11px] font-semibold">
            {localReady ? "en mémoire" : localProbing ? `${Math.round(localProgress * 100)} %` : "en attente"}
          </span>
        </div>
        <p className="mt-2 text-[12.5px] leading-relaxed text-ink-soft">{localDetail}</p>
        {localProbing ? (
          <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-paper">
            <div className="h-full bg-accent transition-[width] duration-300" style={{ width: `${Math.max(2, Math.round(localProgress * 100))}%` }} />
          </div>
        ) : null}
        <Button className="mt-3" variant="ghost" block disabled={localProbing} onClick={() => void action()}>
          {localReady ? "Recharger llama.cpp" : localProbing ? "Chargement…" : "Charger llama.cpp"}
        </Button>
      </div>
    </div>
  );
}

export function ApiForm({
  onAdd,
}: {
  onAdd: (api: { nom: string; endpoint: string; cle: string; description: string; method: "GET" | "POST" | "AUTO" }) => void | Promise<void>;
}) {
  const [nom, setNom] = useState("");
  const [endpoint, setEndpoint] = useState("");
  const [cle, setCle] = useState("");
  const [description, setDescription] = useState("");
  const [method, setMethod] = useState<"GET" | "POST" | "AUTO">("AUTO");
  const [error, setError] = useState("");

  async function submit() {
    if (!nom.trim() || !endpoint.trim()) {
      setError("Indiquez au moins un nom et un endpoint.");
      return;
    }
    setError("");
    await onAdd({
      nom: nom.trim(),
      endpoint: endpoint.trim(),
      cle: cle.trim(),
      description: description.trim(),
      method,
    });
    setNom("");
    setEndpoint("");
    setCle("");
    setDescription("");
    setMethod("AUTO");
  }

  return (
    <div>
      <Label>Nom de l'API</Label>
      <Input value={nom} onChange={(e) => setNom(e.target.value)} placeholder="Ex. Météo, CRM, Stocks" />
      <Label>Endpoint URL</Label>
      <Input type="url" value={endpoint} onChange={(e) => setEndpoint(e.target.value)} placeholder="https://api.exemple.com/v1" />
      <Label>Méthode</Label>
      <select className="v-input" value={method} onChange={(e) => setMethod(e.target.value as "GET" | "POST" | "AUTO")}>
        <option value="AUTO">Auto</option>
        <option value="GET">GET</option>
        <option value="POST">POST</option>
      </select>
      <Label>Clé d'authentification (optionnel)</Label>
      <Input type="password" value={cle} onChange={(e) => setCle(e.target.value)} placeholder="Bearer token" />
      <Label>Description — à quoi sert cette API</Label>
      <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Renvoie la météo pour une ville" />
      {error ? <p className="mt-2 text-xs text-red-700">{error}</p> : null}
      <Button variant="ghost" className="mt-2.5" block onClick={() => void submit()}>
        Ajouter l'API
      </Button>
    </div>
  );
}
