import { uid } from "@/lib/utils";
import { localChat, isLocalReady } from "./local-engine";
import { retrieveKnowledge } from "./rag";
import { buildSystemPrompt } from "./prompt";
import type { ChatAttachment, ChatMessage, VanelleAI } from "./types";

const LOCAL_SYSTEM_CHAR_BUDGET = 2600;

function humanError(raw: string): string {
  const map: Record<string, string> = {
    "llama-cpp-native-requis": "Cette version utilise uniquement llama.cpp dans l'application Android native.",
    "reponse-vide": "Le moteur llama.cpp a renvoyé une réponse vide. Réessayez.",
  };
  if (map[raw]) return map[raw];
  if (raw.length > 12 && !/^[a-z0-9_-]+$/i.test(raw)) return raw;
  return `Llama.cpp n'a pas répondu : ${raw}`;
}

function trimHistory(messages: ChatMessage[], maxChars = 2200): { role: "user" | "assistant"; content: string }[] {
  const valid = messages.filter((m) => m.text && m.text !== "…");
  let total = 0;
  const kept: { role: "user" | "assistant"; content: string }[] = [];
  for (let i = valid.length - 1; i >= 0; i--) {
    const item = {
      role: (valid[i].who === "user" ? "user" : "assistant") as "user" | "assistant",
      content: valid[i].text,
    };
    if (total + item.content.length > maxChars && kept.length >= 2) break;
    kept.unshift(item);
    total += item.content.length;
  }
  return kept;
}

export async function generateReply(opts: {
  ai: VanelleAI;
  history: ChatMessage[];
  userText: string;
  attachments: ChatAttachment[];
}): Promise<{ text: string; usedKnowledge: { source: string; score: number }[]; usedApis: string[] }> {
  const { ai, history, userText, attachments } = opts;
  const knowledge = retrieveKnowledge(ai, userText, 8);

  if (!isLocalReady()) {
    throw new Error("Llama.cpp est encore en cours de téléchargement ou de chargement en mémoire. Attendez qu'il soit prêt.");
  }

  const system = buildSystemPrompt(ai, knowledge, LOCAL_SYSTEM_CHAR_BUDGET);
  const textAttachments = attachments.filter((a) => a.kind === "text" && a.content);
  const imageAttachments = attachments.filter((a) => a.kind === "image" && a.dataUrl);
  const attachedBlock = textAttachments.map((a) => `[Fichier joint : ${a.name}]\n${a.content}`).join("\n\n");
  let userContent = [userText, attachedBlock].filter(Boolean).join("\n\n") || "Réponds à la demande.";
  if (imageAttachments.length) {
    userContent += "\n\n[Des images ont été jointes. Ce modèle texte local ne les analyse pas directement.]";
  }

  const prior = trimHistory(history);
  const messages = [
    { role: "system" as const, content: system },
    ...prior,
    { role: "user" as const, content: userContent },
  ];

  try {
    const text = await localChat(messages, {
      maxTokens: ai.maxTokens ?? 512,
      temperature: ai.temperature ?? 0.4,
    });
    return {
      text,
      usedKnowledge: knowledge.slice(0, 6).map((k) => ({ source: k.source, score: k.score })),
      usedApis: [],
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : "erreur-locale";
    throw new Error(humanError(msg));
  }
}

export function newMsg(partial: Omit<ChatMessage, "id" | "ts"> & { id?: string; ts?: number }): ChatMessage {
  return {
    id: partial.id || uid(),
    ts: partial.ts || Date.now(),
    who: partial.who,
    text: partial.text,
    attachments: partial.attachments,
    usedKnowledge: partial.usedKnowledge,
    usedApis: partial.usedApis,
  };
}
