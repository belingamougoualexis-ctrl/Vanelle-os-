import { create } from "zustand";
import {
  ensureLocalEngine,
  getLocalProgress,
  isLocalReady,
  reloadLocalEngine,
  subscribeLocalProgress,
  type LocalProgress,
} from "./local-engine";

type EngineState = {
  localReady: boolean;
  localProbing: boolean;
  localProgress: number;
  localStatus: LocalProgress["status"];
  localDetail: string;
  loadLocal: () => Promise<void>;
  reloadLocal: () => Promise<void>;
};

function mapLocal(p: LocalProgress): string {
  switch (p.status) {
    case "ready":
      return "Llama.cpp prêt — modèle chargé en mémoire.";
    case "downloading":
      return p.text
        ? `Téléchargement du modèle… ${Math.round(p.progress * 100)} % — ${p.text}`
        : `Téléchargement du modèle… ${Math.round(p.progress * 100)} %`;
    case "loading":
      return p.text
        ? `Chargement en mémoire… ${Math.round(p.progress * 100)} % — ${p.text}`
        : `Chargement en mémoire… ${Math.round(p.progress * 100)} %`;
    case "checking":
      return "Préparation de llama.cpp…";
    case "unsupported":
      return p.text || "Llama.cpp natif est requis. Les moteurs de navigateur sont désactivés.";
    case "error":
      return p.error || p.text || "Échec du chargement de llama.cpp.";
    default:
      return p.text || "Llama.cpp en attente.";
  }
}

export const useEngineStore = create<EngineState>((set, get) => {
  if (typeof window !== "undefined") {
    subscribeLocalProgress((p) => {
      set({
        localReady: p.status === "ready",
        localProbing: p.status === "downloading" || p.status === "loading" || p.status === "checking",
        localProgress: p.progress,
        localStatus: p.status,
        localDetail: mapLocal(p),
      });
    });
  }

  return {
    localReady: isLocalReady(),
    localProbing: false,
    localProgress: 0,
    localStatus: "idle",
    localDetail: "Llama.cpp sera chargé automatiquement.",

    loadLocal: async () => {
      if (get().localProbing && get().localStatus !== "error") return;
      set({ localProbing: true });
      try {
        await ensureLocalEngine();
        const p = getLocalProgress();
        set({
          localReady: p.status === "ready",
          localProbing: false,
          localProgress: p.progress,
          localStatus: p.status,
          localDetail: mapLocal(p),
        });
      } catch (e) {
        const msg = e instanceof Error ? e.message : "Impossible de charger llama.cpp.";
        set({
          localReady: false,
          localProbing: false,
          localProgress: 0,
          localStatus: "error",
          localDetail: msg,
        });
      }
    },

    reloadLocal: async () => {
      if (get().localProbing) return;
      set({ localProbing: true });
      try {
        await reloadLocalEngine();
        const p = getLocalProgress();
        set({
          localReady: p.status === "ready",
          localProbing: false,
          localProgress: p.progress,
          localStatus: p.status,
          localDetail: mapLocal(p),
        });
      } catch (e) {
        const msg = e instanceof Error ? e.message : "Rechargement de llama.cpp échoué.";
        set({ localReady: false, localProbing: false, localStatus: "error", localDetail: msg });
      }
    },
  };
});

/** Lance le téléchargement et le chargement mémoire dès le démarrage de l'interface. */
export function startLocalOnBoot() {
  if (typeof window === "undefined") return;
  void useEngineStore.getState().loadLocal();
}

export async function forceReloadLocalEngine() {
  await useEngineStore.getState().reloadLocal();
}
