const KEY = "vanelle-secrets-v1";

type SecretMap = Record<string, string>;

function read(): SecretMap {
  if (typeof localStorage === "undefined") return {};
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as SecretMap;
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function write(map: SecretMap) {
  localStorage.setItem(KEY, JSON.stringify(map));
}

export const Secrets = {
  get(id: string): string {
    return read()[id] || "";
  },
  set(id: string, value: string) {
    const map = read();
    if (value) map[id] = value;
    else delete map[id];
    write(map);
  },
  remove(id: string) {
    const map = read();
    delete map[id];
    write(map);
  },
};
