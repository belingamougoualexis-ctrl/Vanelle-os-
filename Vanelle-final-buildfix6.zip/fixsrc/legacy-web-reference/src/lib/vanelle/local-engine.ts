/**
 * Unique moteur LLM local de Vanelle.
 *
 * L'inférence passe exclusivement par llama.cpp dans l'application Android.
 * Aucun moteur LLM distant n'est utilisé.
 * Le modèle GGUF est téléchargé une seule fois dans filesDir puis chargé en mémoire.
 */

import { Capacitor } from "@capacitor/core";
import { NativeLlama, type NativeLlamaEvent } from "./native-llama-plugin";

export const VANELLE_LOCAL_MODEL_ID = "SmolLM2-360M-Instruct-Q4_K_M";
export const VANELLE_LOCAL_MODEL_SIZE = "271 Mo";
const CONTEXT_WINDOW = 2048;

export type LocalEngineStatus =
  | "idle"
  | "checking"
  | "downloading"
  | "loading"
  | "ready"
  | "error"
  | "unsupported";

export type LocalProgress = {
  status: LocalEngineStatus;
  progress: number;
  text: string;
  error?: string;
};

type ProgressListener = (p: LocalProgress) => void;

function isNative(): boolean {
  try {
    return Boolean(
      (typeof window !== "undefined" && window.__vanelleLlama) || Capacitor.isNativePlatform(),
    );
  } catch {
    return false;
  }
}

let lastProgress: LocalProgress = {
  status: "idle",
  progress: 0,
  text: `Llama.cpp sera téléchargé et chargé automatiquement à l'ouverture de l'application. Modèle : ${VANELLE_LOCAL_MODEL_ID} (${VANELLE_LOCAL_MODEL_SIZE}).`,
};
const listeners = new Set<ProgressListener>();

function emit(p: LocalProgress) {
  lastProgress = p;
  listeners.forEach((fn) => {
    try {
      fn(p);
    } catch {
      /* ignore listener errors */
    }
  });
}

export function subscribeLocalProgress(fn: ProgressListener): () => void {
  listeners.add(fn);
  fn(lastProgress);
  return () => listeners.delete(fn);
}

export function getLocalProgress(): LocalProgress {
  return lastProgress;
}

export function isLocalReady(): boolean {
  return lastProgress.status === "ready";
}

export type LocalChatMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

let nativeReadyPromise: Promise<void> | null = null;
let nativeListenerAttached = false;

function attachNativeListener() {
  if (nativeListenerAttached) return;
  nativeListenerAttached = true;
  void NativeLlama.addListener("progress", (event: NativeLlamaEvent) => {
    emit({
      status: event.status,
      progress: event.progress,
      text: event.text,
      error: event.error,
    });
  });
}

async function ensureNativeEngine(): Promise<void> {
  if (!isNative()) {
    const error = "llama.cpp est disponible dans l'application Android native. Les moteurs de navigateur sont désactivés.";
    emit({ status: "unsupported", progress: 0, text: error, error: "llama-cpp-native-requis" });
    throw new Error("llama-cpp-native-requis");
  }
  if (lastProgress.status === "ready") return;
  if (nativeReadyPromise) return nativeReadyPromise;

  attachNativeListener();
  emit({ status: "checking", progress: 0.02, text: "Préparation de llama.cpp…" });

  nativeReadyPromise = NativeLlama.ensureLoaded()
    .then((res) => {
      if (!res.ready) throw new Error("Le modèle llama.cpp n'a pas pu être chargé en mémoire.");
      emit({ status: "ready", progress: 1, text: "Llama.cpp prêt — modèle local chargé en mémoire." });
    })
    .catch((e) => {
      const msg = e instanceof Error ? e.message : "Chargement natif interrompu";
      nativeReadyPromise = null;
      emit({ status: "error", progress: 0, text: msg, error: msg });
      throw e;
    });

  return nativeReadyPromise;
}

export async function ensureLocalEngine(): Promise<void> {
  await ensureNativeEngine();
}

export async function reloadLocalEngine(): Promise<void> {
  nativeReadyPromise = null;
  emit({ status: "idle", progress: 0, text: "Rechargement de llama.cpp…" });
  await ensureNativeEngine();
}

export async function localChat(
  messages: LocalChatMessage[],
  opts?: { maxTokens?: number; temperature?: number },
): Promise<string> {
  await ensureNativeEngine();
  const maxTokens = Math.min(Math.max(opts?.maxTokens ?? 512, 32), 1024);
  const temperature = Math.min(Math.max(opts?.temperature ?? 0.4, 0), 1.5);
  const { text } = await NativeLlama.chat({ messages, maxTokens, temperature });
  const trimmed = (text || "").trim();
  if (!trimmed) throw new Error("Réponse vide du moteur llama.cpp.");
  return trimmed;
}

export const LOCAL_CONTEXT_WINDOW = CONTEXT_WINDOW;
