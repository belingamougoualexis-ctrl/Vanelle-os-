import { blankProfile, type ChatMessage, type Profile, type VanelleAI } from "./types";

const DB_NAME = "vanelle-ai-db";
const DB_VERSION = 3;

let dbP: Promise<IDBDatabase> | null = null;

function openDB() {
  if (typeof indexedDB === "undefined") {
    return Promise.reject(new Error("IndexedDB n'est pas disponible."));
  }
  if (dbP) return dbP;
  dbP = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = (e.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains("ais")) db.createObjectStore("ais", { keyPath: "id" });
      if (!db.objectStoreNames.contains("profile")) db.createObjectStore("profile", { keyPath: "id" });
      if (!db.objectStoreNames.contains("chats")) db.createObjectStore("chats", { keyPath: "aiId" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => {
      dbP = null;
      reject(req.error);
    };
  });
  return dbP;
}

function txDone<T>(req: IDBRequest<T>) {
  return new Promise<T>((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function waitTx(tx: IDBTransaction) {
  return new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error("transaction-aborted"));
  });
}

export const Store = {
  async getAllAIs(): Promise<VanelleAI[]> {
    const db = await openDB();
    const rows = await txDone(db.transaction("ais", "readonly").objectStore("ais").getAll());
    return (rows || []).map(normalizeAI);
  },
  async getAI(id: string): Promise<VanelleAI | null> {
    const db = await openDB();
    const row = await txDone(db.transaction("ais", "readonly").objectStore("ais").get(id));
    return row ? normalizeAI(row) : null;
  },
  async saveAI(ai: VanelleAI): Promise<VanelleAI> {
    const db = await openDB();
    const tx = db.transaction("ais", "readwrite");
    tx.objectStore("ais").put(ai);
    await waitTx(tx);
    return ai;
  },
  async deleteAI(id: string): Promise<void> {
    const db = await openDB();
    const tx = db.transaction(["ais", "chats"], "readwrite");
    tx.objectStore("ais").delete(id);
    tx.objectStore("chats").delete(id);
    await waitTx(tx);
  },
  async getProfile(): Promise<Profile> {
    const db = await openDB();
    const row = await txDone(db.transaction("profile", "readonly").objectStore("profile").get("p1"));
    return normalizeProfile(row || blankProfile());
  },
  async saveProfile(p: Profile): Promise<Profile> {
    const db = await openDB();
    const tx = db.transaction("profile", "readwrite");
    tx.objectStore("profile").put(p);
    await waitTx(tx);
    return p;
  },
  async getChat(aiId: string): Promise<ChatMessage[]> {
    const db = await openDB();
    const row = await txDone<{ aiId: string; messages: ChatMessage[] } | undefined>(
      db.transaction("chats", "readonly").objectStore("chats").get(aiId),
    );
    return row?.messages || [];
  },
  async saveChat(aiId: string, messages: ChatMessage[]): Promise<void> {
    const db = await openDB();
    const tx = db.transaction("chats", "readwrite");
    tx.objectStore("chats").put({ aiId, messages });
    await waitTx(tx);
  },
};

function normalizeAI(raw: VanelleAI): VanelleAI {
  return {
    ...raw,
    systemPrompt: raw.systemPrompt || "",
    maxTokens: typeof raw.maxTokens === "number" ? raw.maxTokens : 700,
    temperature: typeof raw.temperature === "number" ? raw.temperature : 0.4,
    engineId: "local",
    training: raw.training || [],
    apis: (raw.apis || []).map((a) => ({
      ...a,
      method: a.method || "AUTO",
    })),
    files: raw.files || [],
    deployed: !!raw.deployed,
    deployedAt: raw.deployedAt || null,
  };
}

function normalizeProfile(raw: Profile): Profile {
  return {
    id: "p1",
    pseudo: raw.pseudo || "",
    createdAt: raw.createdAt || Date.now(),
    // Les anciens moteurs cloud sont ignorés : llama.cpp est désormais l'unique moteur.
    engines: [],
    activeEngineId: "local",
  };
}
