import { BlobReader, TextWriter, Uint8ArrayWriter, ZipReader } from "@zip.js/zip.js";
import { MAX_TEXT_PER_BATCH, MAX_TEXT_PER_FILE, MAX_UPLOAD_BYTES, uid } from "@/lib/utils";
import type { KnowledgeFile, VanelleAI } from "./types";

const TEXT_EXTS = new Set(["txt", "md", "csv", "json", "html", "htm", "js", "css", "xml", "log", "tsv"]);

export function cleanText(text: string) {
  return String(text || "")
    .replace(/\r/g, "\n")
    .replace(/[\t ]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export function chunkText(text: string, size = 900, overlap = 120) {
  const t = cleanText(text);
  if (!t) return [];
  const chunks: string[] = [];
  let start = 0;
  while (start < t.length) {
    let end = Math.min(t.length, start + size);
    if (end < t.length) {
      const cut = t.lastIndexOf(" ", end);
      if (cut > start + Math.floor(size * 0.6)) end = cut;
    }
    chunks.push(t.slice(start, end).trim());
    if (end >= t.length) break;
    start = Math.max(end - overlap, start + 1);
  }
  return chunks.filter(Boolean);
}

function extOf(name: string) {
  return (name.split(".").pop() || "").toLowerCase();
}

function fileRecord(nom: string, taille: number, type: string, text: string, source: string): KnowledgeFile {
  const clipped = cleanText(text).slice(0, MAX_TEXT_PER_FILE);
  return {
    id: uid(),
    nom,
    taille,
    type,
    resume: clipped.slice(0, 600),
    chunks: chunkText(clipped, 900, 120).map((t) => ({ id: uid(), text: t })),
    source,
    ts: Date.now(),
  };
}

async function extractPdfText(data: ArrayBuffer | Uint8Array): Promise<string> {
  const pdfjs = await import("pdfjs-dist");
  const worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
  pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
  const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
  const doc = await pdfjs.getDocument({ data: bytes }).promise;
  const pages: string[] = [];
  const n = Math.min(doc.numPages, 80);
  for (let i = 1; i <= n; i++) {
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    const str = content.items.map((it) => ("str" in it ? String(it.str) : "")).join(" ");
    pages.push(str);
  }
  return pages.join("\n");
}

async function readPlainFile(file: File): Promise<KnowledgeFile> {
  const ext = extOf(file.name);
  if (ext === "pdf" || file.type === "application/pdf") {
    const buf = await file.arrayBuffer();
    const text = await extractPdfText(buf);
    return fileRecord(file.name, file.size, "pdf", text, file.name);
  }
  if (!TEXT_EXTS.has(ext)) {
    throw new Error(`format-non-supporte:${ext || "inconnu"}`);
  }
  const text = await file.text();
  return fileRecord(file.name, file.size, ext, text, file.name);
}

async function readZip(file: File, onProgress?: (msg: string) => void): Promise<KnowledgeFile[]> {
  const reader = new ZipReader(new BlobReader(file));
  const entries = await reader.getEntries();
  const out: KnowledgeFile[] = [];
  let extracted = 0;
  for (const entry of entries) {
    if (entry.directory || !("getData" in entry) || !entry.getData) continue;
    const name = entry.filename;
    const ext = extOf(name);
    if (!TEXT_EXTS.has(ext) && ext !== "pdf") continue;
    if (extracted >= MAX_TEXT_PER_BATCH) break;
    onProgress?.(`Lecture de ${name.split("/").pop()}…`);
    try {
      let text = "";
      if (ext === "pdf") {
        const data = await entry.getData(new Uint8ArrayWriter());
        text = await extractPdfText(data);
      } else {
        text = await entry.getData(new TextWriter());
      }
      text = cleanText(text).slice(0, MAX_TEXT_PER_FILE);
      if (!text) continue;
      extracted += text.length;
      out.push(fileRecord(name, Number(entry.uncompressedSize || text.length), ext, text, file.name));
    } catch {
      // skip unreadable entry
    }
  }
  await reader.close();
  if (!out.length) throw new Error("zip-sans-texte");
  return out;
}

export async function ingestFiles(
  files: File[],
  ai: VanelleAI,
  onProgress?: (msg: string) => void,
): Promise<{ added: number; skipped: string[] }> {
  const skipped: string[] = [];
  let added = 0;
  for (const file of files) {
    if (file.size > MAX_UPLOAD_BYTES) {
      skipped.push(`${file.name} dépasse 3 Go`);
      continue;
    }
    onProgress?.(`Analyse de ${file.name}…`);
    try {
      const isZip = extOf(file.name) === "zip" || file.type.includes("zip");
      if (isZip) {
        const recs = await readZip(file, onProgress);
        ai.files.push(...recs);
        added += recs.length;
      } else {
        const rec = await readPlainFile(file);
        ai.files.push(rec);
        added += 1;
      }
    } catch (e) {
      skipped.push(`${file.name} : ${e instanceof Error ? e.message : "illisible"}`);
    }
  }
  return { added, skipped };
}
