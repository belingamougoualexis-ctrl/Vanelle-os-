/**
 * Pont vers le moteur llama.cpp natif.
 *
 * Deux implémentations possibles :
 * 1. Plugin Capacitor "LlamaEngine" (app empaquetée via `npx cap add android`)
 * 2. Pont JS injecté par MainActivity (`window.__vanelleLlama`) pour l'APK Gradle autonome
 */
import { registerPlugin } from "@capacitor/core";

export type NativeLlamaEvent = {
  status: "checking" | "downloading" | "loading" | "ready" | "error";
  progress: number;
  text: string;
  error?: string;
};

export interface LlamaEnginePlugin {
  ensureLoaded(): Promise<{ ready: boolean }>;
  chat(options: {
    messages: { role: "system" | "user" | "assistant"; content: string }[];
    maxTokens: number;
    temperature: number;
  }): Promise<{ text: string }>;
  addListener(
    eventName: "progress",
    listenerFunc: (event: NativeLlamaEvent) => void,
  ): Promise<{ remove: () => void }>;
}

type JsBridge = {
  ensureLoaded: (cb: string) => void;
  chat: (payloadJson: string, cb: string) => void;
};

type Pending = {
  resolve: (v: unknown) => void;
  reject: (e: Error) => void;
};

declare global {
  interface Window {
    __vanelleLlama?: JsBridge;
    __vanelleLlamaResolve?: (id: string, payload: unknown, error?: string) => void;
    __vanelleLlamaProgress?: (event: NativeLlamaEvent) => void;
  }
}

const CapacitorLlama = registerPlugin<LlamaEnginePlugin>("LlamaEngine");

function getBridge(): JsBridge | null {
  if (typeof window === "undefined") return null;
  return window.__vanelleLlama || null;
}

function callBridge<T>(fn: (id: string) => void): Promise<T> {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined") {
      reject(new Error("Pont natif indisponible."));
      return;
    }
    const pending = (window as unknown as { __vanellePending?: Map<string, Pending> }).__vanellePending
      || new Map<string, Pending>();
    (window as unknown as { __vanellePending: Map<string, Pending> }).__vanellePending = pending;
    window.__vanelleLlamaResolve = (id, payload, error) => {
      const p = pending.get(id);
      if (!p) return;
      pending.delete(id);
      if (error) p.reject(new Error(error));
      else p.resolve(payload);
    };
    const id = "cb-" + Math.random().toString(36).slice(2);
    pending.set(id, { resolve: resolve as (v: unknown) => void, reject });
    fn(id);
  });
}

export const NativeLlama: LlamaEnginePlugin = {
  async ensureLoaded() {
    const bridge = getBridge();
    if (bridge) {
      return callBridge<{ ready: boolean }>((id) => bridge.ensureLoaded(id));
    }
    return CapacitorLlama.ensureLoaded();
  },
  async chat(options) {
    const bridge = getBridge();
    if (bridge) {
      return callBridge<{ text: string }>((id) => bridge.chat(JSON.stringify(options), id));
    }
    return CapacitorLlama.chat(options);
  },
  async addListener(eventName, listenerFunc) {
    if (typeof window !== "undefined") {
      const prev = window.__vanelleLlamaProgress;
      window.__vanelleLlamaProgress = (event) => {
        prev?.(event);
        listenerFunc(event);
      };
    }
    try {
      return await CapacitorLlama.addListener(eventName, listenerFunc);
    } catch {
      return { remove: () => undefined };
    }
  },
};
