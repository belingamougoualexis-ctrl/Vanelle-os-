import type { Category } from "@/lib/utils";

export type TrainingItem = {
  id: string;
  categorie: Category | string;
  question: string;
  reponse: string;
  ts: number;
};

export type FileChunk = { id: string; text: string };

export type KnowledgeFile = {
  id: string;
  nom: string;
  taille: number;
  type: string;
  resume: string;
  chunks: FileChunk[];
  source: string;
  ts: number;
};

export type UserApi = {
  id: string;
  nom: string;
  endpoint: string;
  method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE" | "AUTO";
  description: string;
  ts: number;
};

export type UserEngine = {
  id: string;
  name: string;
  kind: "openai";
  endpoint: string;
  model: string;
  ts: number;
};

export type VanelleAI = {
  id: string;
  nom: string;
  description: string;
  modele: string;
  systemPrompt: string;
  /** Longueur max de réponse (tokens) — configuré par l'utilisateur */
  maxTokens?: number;
  /** Température de génération — configuré par l'utilisateur */
  temperature?: number;
  /** Moteur unique : llama.cpp local. */
  engineId: "local";
  createdAt: number;
  deployed: boolean;
  deployedAt: number | null;
  training: TrainingItem[];
  apis: UserApi[];
  files: KnowledgeFile[];
};

export type Profile = {
  id: "p1";
  pseudo: string;
  createdAt: number;
  engines: UserEngine[];
  activeEngineId: string;
};

export type ChatAttachment = {
  id: string;
  kind: "image" | "text";
  name: string;
  mime?: string;
  dataUrl?: string;
  content?: string;
};

export type ChatMessage = {
  id: string;
  who: "user" | "bot";
  text: string;
  attachments?: ChatAttachment[];
  usedKnowledge?: { source: string; score: number }[];
  usedApis?: string[];
  ts: number;
};

export const VANELLE_LOCAL_ENGINE_ID = "local" as const;

export function blankAI(input: { nom: string; description: string; modele: string }): VanelleAI {
  return {
    id: crypto.randomUUID ? crypto.randomUUID() : "id-" + Date.now(),
    nom: input.nom || "Nouvelle IA",
    description: input.description || "",
    modele: input.modele || "Généraliste",
    systemPrompt: "",
    maxTokens: 700,
    temperature: 0.4,
    engineId: VANELLE_LOCAL_ENGINE_ID,
    createdAt: Date.now(),
    deployed: false,
    deployedAt: null,
    training: [],
    apis: [],
    files: [],
  };
}

export function blankProfile(): Profile {
  return {
    id: "p1",
    pseudo: "",
    createdAt: Date.now(),
    engines: [],
    activeEngineId: VANELLE_LOCAL_ENGINE_ID,
  };
}
