import type { Retrieved } from "./rag";
import type { VanelleAI } from "./types";

const HARD_RULES = `RÈGLES :
- N'invente jamais une information. Si elle n'est pas dans tes connaissances, tes fichiers ou tes notions enseignées, dis clairement que tu ne la sais pas.
- Respecte en priorité le system prompt et les notions enseignées par l'utilisateur.
- Réponds en français sauf demande contraire.
- Tu fonctionnes localement avec llama.cpp. Ne révèle pas le nom technique du modèle sous-jacent sauf si l'utilisateur le demande explicitement.`;

export function buildSystemPrompt(ai: VanelleAI, knowledge: Retrieved[] = [], maxChars = 2600): string {
  const parts: string[] = [];
  const custom = (ai.systemPrompt || "").trim();

  parts.push(
    custom || `Tu es ${ai.nom || "Vanelle"}, une IA configurée par l'utilisateur. ${ai.description || ""}`.trim(),
  );
  if (!custom && ai.modele) parts.push(`Style de base : ${ai.modele}.`);
  parts.push(`Le nom affiché de l'assistant est ${ai.nom || "Vanelle"}.`);
  parts.push(HARD_RULES);

  if (ai.training?.length) {
    parts.push("NOTIONS ENSEIGNÉES PAR L'UTILISATEUR :");
    const budget = Math.min(900, Math.floor(maxChars * 0.34));
    let used = 0;
    for (const t of ai.training) {
      const block = `- [${t.categorie}] Q : ${t.question}\n  R : ${t.reponse}`;
      if (used + block.length > budget) break;
      parts.push(block);
      used += block.length;
    }
  }

  if (knowledge.length) {
    parts.push("CONNAISSANCES RÉCUPÉRÉES :");
    knowledge.forEach((x, i) => {
      parts.push(`[${i + 1}] (${x.kind === "training" ? "notion" : "fichier"} : ${x.source})\n${x.text.slice(0, 700)}`);
    });
  } else if (ai.files?.length) {
    parts.push("FICHIERS DISPONIBLES :");
    ai.files.slice(0, 8).forEach((f, i) => {
      parts.push(`[F${i + 1}] ${f.nom} (${f.type}) : ${(f.resume || "").slice(0, 300)}`);
    });
  }

  if (ai.apis?.length) {
    parts.push(
      "INTÉGRATIONS API CONFIGURÉES : elles sont conservées dans les données de l'IA. Ce moteur local n'exécute pas automatiquement les appels API.",
    );
    ai.apis.forEach((a) => parts.push(`- ${a.nom} : ${a.description || a.endpoint}`));
  }

  return parts.join("\n\n").slice(0, maxChars);
}

export function describeEngine(_ai: VanelleAI, localReady: boolean): string {
  return localReady ? "Llama.cpp — modèle local en mémoire" : "Llama.cpp — chargement local en cours";
}
