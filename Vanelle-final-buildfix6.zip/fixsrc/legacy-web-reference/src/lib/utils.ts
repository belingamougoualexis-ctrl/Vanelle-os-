import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const uid = () =>
  crypto.randomUUID ? crypto.randomUUID() : "id-" + Date.now() + "-" + Math.random().toString(16).slice(2);

export function slug(s = "") {
  return (
    s
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "") || "mon-ia"
  );
}

export function fmtDate(ts: number) {
  return new Date(ts).toLocaleDateString("fr-FR", { day: "2-digit", month: "short", year: "numeric" });
}

export function fmtSize(b: number) {
  if (b < 1024) return b + " o";
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + " Ko";
  if (b < 1024 * 1024 * 1024) return (b / 1024 / 1024).toFixed(2) + " Mo";
  return (b / 1024 / 1024 / 1024).toFixed(2) + " Go";
}

export const MAX_UPLOAD_BYTES = 3 * 1024 * 1024 * 1024; // 3 Go
export const MAX_TEXT_PER_FILE = 5 * 1024 * 1024;
export const MAX_TEXT_PER_BATCH = 50 * 1024 * 1024;

export const CATEGORIES = ["Identité", "Personnalité", "Connaissances", "Compétences", "Règles"] as const;
export type Category = (typeof CATEGORIES)[number];
