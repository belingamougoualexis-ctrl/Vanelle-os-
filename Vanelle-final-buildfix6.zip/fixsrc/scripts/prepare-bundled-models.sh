#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/android/app/src/main/assets/models"
mkdir -p "$DEST"

fetch() {
  local url="$1" out="$2" sha="$3" min_size="$4"
  local tmp="${out}.download"
  if [[ -f "$out" ]]; then
    actual="$(sha256sum "$out" | awk '{print $1}')"
    size="$(stat -c '%s' "$out")"
    if [[ "$actual" == "$sha" && "$size" -ge "$min_size" ]]; then
      echo "Verified bundled model: $(basename "$out")"
      return
    fi
    rm -f "$out"
  fi
  echo "Downloading $(basename "$out") for build-time bundling..."
  curl --fail --location --retry 5 --retry-delay 2 --connect-timeout 60 --max-time 1800 \
    --user-agent 'Vanelle-build/1.0' -o "$tmp" "$url"
  actual="$(sha256sum "$tmp" | awk '{print $1}')"
  size="$(stat -c '%s' "$tmp")"
  if [[ "$actual" != "$sha" ]]; then
    rm -f "$tmp"
    echo "SHA-256 mismatch for $(basename "$out")" >&2
    exit 1
  fi
  if [[ "$size" -lt "$min_size" ]]; then
    rm -f "$tmp"
    echo "Model is unexpectedly small: $(basename "$out")" >&2
    exit 1
  fi
  mv "$tmp" "$out"
}

fetch \
  'https://huggingface.co/jc-builds/SmolLM2-360M-Instruct-Q4_K_M-GGUF/resolve/main/SmolLM2-360M-Instruct.Q4_K_M.gguf?download=true' \
  "$DEST/SmolLM2-360M-Instruct.Q4_K_M.gguf" \
  'ade7aee1e5bd7c3b8f1fedafc61a1a0be31e8afa64e006607cd202323e2ccce0' \
  260000000

fetch \
  'https://huggingface.co/nomic-ai/nomic-embed-text-v1.5-GGUF/resolve/main/nomic-embed-text-v1.5.Q4_K_M.gguf?download=true' \
  "$DEST/nomic-embed-text-v1.5.Q4_K_M.gguf" \
  'd4e388894e09cf3816e8b0896d81d265b55e7a9fff9ab03fe8bf4ef5e11295ac' \
  80000000

echo "Bundled AI models are ready:"
ls -lh "$DEST"/*.gguf
