-keep class org.nehuatl.llamacpp.** { *; }
-keep class com.vanelle.app.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.getcapacitor.** { *; }
