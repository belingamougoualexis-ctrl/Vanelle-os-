This directory is populated at build time by scripts/prepare-bundled-models.sh.

The generated Android application contains both GGUF files as packaged assets:
- SmolLM2-360M-Instruct Q4_K_M (~271 MB)
- nomic-embed-text-v1.5 Q4_K_M (~84.1 MB)

The app does not download models at runtime. The build verifies SHA-256 before packaging.
