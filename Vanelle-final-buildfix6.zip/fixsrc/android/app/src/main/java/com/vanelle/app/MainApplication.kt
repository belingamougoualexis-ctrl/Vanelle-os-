package com.vanelle.app
import android.app.Application
import com.facebook.react.PackageList
import com.facebook.react.ReactApplication
import com.facebook.react.ReactHost
import com.facebook.react.ReactNativeHost
import com.facebook.react.ReactPackage
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.load
import com.facebook.react.defaults.DefaultReactHost.getDefaultReactHost
import com.facebook.react.defaults.DefaultReactNativeHost
import com.facebook.react.soloader.OpenSourceMergedSoMapping
import com.facebook.soloader.SoLoader
class MainApplication:Application(),ReactApplication{override val reactNativeHost:ReactNativeHost=object:DefaultReactNativeHost(this){override fun getPackages():List<ReactPackage>=PackageList(this).packages.apply{add(VanelleNativePackage())};override fun getJSMainModuleName()="index";override fun getUseDeveloperSupport()=BuildConfig.DEBUG;override val isNewArchEnabled=BuildConfig.IS_NEW_ARCHITECTURE_ENABLED;override val isHermesEnabled=BuildConfig.IS_HERMES_ENABLED};override val reactHost:ReactHost get()=getDefaultReactHost(applicationContext,reactNativeHost);override fun onCreate(){super.onCreate();SoLoader.init(this,OpenSourceMergedSoMapping);if(BuildConfig.IS_NEW_ARCHITECTURE_ENABLED)load()}}
