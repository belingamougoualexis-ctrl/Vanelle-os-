package com.vanelle.app

import android.content.Context
import java.io.File

class EmbeddingEngine(private val context: Context) {
    val modelFile: File
        get() = ModelAssets.file(context, ModelAssets.EMBEDDING)

    fun isReady(): Boolean = ModelAssets.isReady(context, ModelAssets.EMBEDDING)

    fun ensureInstalled(): File = ModelAssets.ensureInstalled(context, ModelAssets.EMBEDDING)
}
