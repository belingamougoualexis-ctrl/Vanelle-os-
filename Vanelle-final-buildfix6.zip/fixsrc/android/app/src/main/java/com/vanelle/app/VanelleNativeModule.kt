package com.vanelle.app
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
class VanelleNativeModule(c:ReactApplicationContext):ReactContextBaseJavaModule(c){private val scope=CoroutineScope(SupervisorJob()+Dispatchers.IO);private val engine=LlamaEngine(c);override fun getName()="VanelleNative";@ReactMethod fun getModelStatus(p:Promise){try{val m=Arguments.createMap();m.putBoolean("llmReady",ModelAssets.isReady(reactApplicationContext,ModelAssets.LLM));m.putBoolean("embeddingReady",ModelAssets.isReady(reactApplicationContext,ModelAssets.EMBEDDING));p.resolve(m)}catch(e:Exception){p.reject("STATUS_ERROR",e)}}@ReactMethod fun chat(payload:String,p:Promise){scope.launch{try{val o=JSONObject(payload);val a=o.optJSONArray("messages")?:org.json.JSONArray();val pairs=ArrayList<Pair<String,String>>();for(i in 0 until a.length()){val m=a.getJSONObject(i);pairs.add(m.optString("role","user") to m.optString("content",""))};val text=engine.generate(engine.buildPrompt(pairs),o.optInt("maxTokens",700).coerceIn(32,1024),o.optDouble("temperature",.4).toFloat());val r=Arguments.createMap();r.putString("text",text);p.resolve(r)}catch(e:Exception){p.reject("CHAT_ERROR",e.message,e)}}}}
