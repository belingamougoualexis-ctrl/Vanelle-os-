# Vanelle — bundled local models

Vanelle no longer downloads the LLM or embedding model when the application starts.
Both GGUF files are build-time inputs and are packaged into the Android application under `android/app/src/main/assets/models/`.

## Build

From the repository root:

```bash
./scripts/prepare-bundled-models.sh
cd android
./gradlew :app:assembleRelease
```

The script downloads only during the build and verifies SHA-256. The installed application itself has no model-download service and does not need network access to obtain its models.

## Models

- `SmolLM2-360M-Instruct.Q4_K_M.gguf` — ~271 MB — SHA-256 `ade7aee1e5bd7c3b8f1fedafc61a1a0be31e8afa64e006607cd202323e2ccce0`
- `nomic-embed-text-v1.5.Q4_K_M.gguf` — ~84.1 MB — SHA-256 `d4e388894e09cf3816e8b0896d81d265b55e7a9fff9ab03fe8bf4ef5e11295ac`

The application copies each packaged asset once into private app storage and validates its hash before handing the file to the native engine.

## Size note

The two models total roughly 355 MB before APK packaging. A normal Play-distributed base APK/AAB has size constraints, so a Play release should use an install-time AI/asset pack rather than forcing the model files into the base APK. Android's current on-device AI delivery supports install-time model delivery; that still makes the models part of the installation rather than a first-launch download.
