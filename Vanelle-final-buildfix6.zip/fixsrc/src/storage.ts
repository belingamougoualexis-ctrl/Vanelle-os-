import AsyncStorage from '@react-native-async-storage/async-storage';import type{AI,Message}from'./types';
const A='@vanelle/ais',K=(id:string)=>`@vanelle/chat/${id}`;
export async function getAIs(){const r=await AsyncStorage.getItem(A);if(!r)return[];try{return JSON.parse(r)as AI[]}catch{return[]}}
export async function saveAI(ai:AI){const a=await getAIs();await AsyncStorage.setItem(A,JSON.stringify(a.some(x=>x.id===ai.id)?a.map(x=>x.id===ai.id?ai:x):[ai,...a]))}
export async function deleteAI(id:string){const a=await getAIs();await AsyncStorage.setItem(A,JSON.stringify(a.filter(x=>x.id!==id)));await AsyncStorage.removeItem(K(id))}
export async function getChat(id:string):Promise<Message[]>{const r=await AsyncStorage.getItem(K(id));if(!r)return[];try{return JSON.parse(r)as Message[]}catch{return[]}}
export async function saveChat(id:string,m:Message[]){await AsyncStorage.setItem(K(id),JSON.stringify(m))}
