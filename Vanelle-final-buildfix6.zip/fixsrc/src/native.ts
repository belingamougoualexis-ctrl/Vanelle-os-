import {NativeModules} from 'react-native';

export type ModelStatus = {llmReady: boolean; embeddingReady: boolean};

type API = {
  getModelStatus(): Promise<ModelStatus>;
  chat(payload: string): Promise<{text: string}>;
};

export const VanelleNative = NativeModules.VanelleNative as API | undefined;
