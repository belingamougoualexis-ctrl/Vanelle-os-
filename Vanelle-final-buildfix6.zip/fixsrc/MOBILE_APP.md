# Vanelle — Android, prêt à compiler (JVM 17)

Le moteur LLM est unique : llama.cpp + GGUF. Deux chemins de packaging sont disponibles :

## 1. APK natif (recommandé, compile sans Capacitor)

Le module Gradle `:app` à la racine **compile tel quel** :

```bash
# JDK 17 obligatoire
java -version   # 17.x

./gradlew :app:assembleDebug --init-script gradle/force-jvm17.gradle
# APK → app/build/outputs/apk/debug/app-debug.apk
```

Ce que l’APK fait vraiment :

- Télécharge **une fois** le modèle GGUF SmolLM2-360M-Instruct Q4_K_M (~271 Mo) depuis Hugging Face
- Le charge en mémoire via **llama.cpp** (`io.github.ljcamargo:llamacpp-kotlin:0.4.0`, classes `org.nehuatl.llamacpp.LlamaHelper`)
- Chat en français, 100 % sur l’appareil
- Pont JS `window.__vanelleLlama` pour l’UI (assets `www/index.html`)

Aucun TODO. L’ancien stub `NotImplementedError` a été remplacé par l’API réelle de la bibliothèque.

## 2. Capacitor (atelier web complet dans une WebView)

```bash
npm install
npm run build
npx cap add android          # première fois
node scripts/prepare-android.mjs
cd android && ./gradlew assembleDebug --init-script ../gradle/force-jvm17.gradle
```

`prepare-android.mjs` copie `LlamaEngine.kt` + `LlamaEnginePlugin.kt`, force JVM 17, enregistre le plugin.

Dans ce mode, le studio web (création d’IA, fichiers, API) tourne dans la WebView. Le moteur local llama.cpp est le même.

## PWA (sans compilation)

La version navigateur sert au studio, mais l'inférence locale llama.cpp nécessite l'application Android native. Les moteurs LLM de navigateur ne sont plus utilisés.

## Prérequis

| Outil | Version |
|---|---|
| JDK | **17** (pas 21) |
| Android SDK | compileSdk 35, minSdk 24 |
| Gradle | 8.10.2 (wrapper inclus) |
| Appareil | 64-bit (`arm64-v8a` ou `x86_64`), ~1,5 Go libres pour le modèle |
