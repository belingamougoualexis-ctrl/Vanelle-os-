# Vanelle — moteur local unique

```bash
npm install
npm run dev
```

- **Moteur unique : llama.cpp** dans l'application Android native.
- **Modèle : SmolLM2-360M-Instruct Q4_K_M**, GGUF, environ 271 Mo.
- Le modèle est téléchargé automatiquement au premier démarrage, repris si nécessaire, vérifié par SHA-256, puis chargé en mémoire.
- À chaque ouverture suivante, le fichier local est réutilisé et le modèle est rechargé en mémoire.
- Aucun moteur LLM distant n'est utilisé.
- Les notifications toast ont été supprimées : les actions n'affichent plus de message popup.
- Les exports sont des archives ZIP.
