# Vanelle — audit and model integration (2026-09-02)

## What was checked

- Android module and manifest
- LlamaEngine / Kotlin-LlamaCpp integration
- model download/resume/checksum flow
- startup behavior
- WebView/React DOM architecture
- model storage
- dependency declaration
- embedding-model compatibility with llama.cpp

## Changes in this build

1. Added `ModelDownloader.kt`
   - resumable HTTP Range downloads
   - 45 s connection timeout
   - 5 min read timeout
   - redirect handling
   - SHA-256 verification
   - safe `.part` file handling
   - separate model specifications for LLM and embeddings

2. Added `ModelDownloadService.kt`
   - Android foreground service
   - download continues independently from the chat/WebView
   - notification with progress
   - completion notification
   - error notification

3. Added `EmbeddingEngine.kt`
   - downloads and verifies Nomic Embed Text v1.5 Q4_K_M
   - stores it independently from the chat LLM
   - does not pretend that a vector was generated

4. Updated `MainActivity.kt`
   - starts the background model preparation service at launch
   - exposes `modelStatus()` to the existing JS bridge

5. Updated `LlamaEngine.kt`
   - uses the shared downloader instead of maintaining a second download implementation

## Embedding model selected

`nomic-ai/nomic-embed-text-v1.5-GGUF`, quantization `Q4_K_M`.

The official model page lists Q4_K_M at about 84.1 MB and reports its SHA-256 as:

`d4e388894e09cf3816e8b0896d81d265b55e7a9fff9ab03fe8bf4ef5e11295ac`

The model card documents llama.cpp embedding usage and the required task prefixes such as `search_query:`.

## Important limitation

The project currently depends on `io.github.ljcamargo:llamacpp-kotlin:0.4.0`. Its public `LlamaHelper` API documented by the project exposes model loading and text generation, but not a typed `embed(text): FloatArray` operation.

Therefore this build **downloads and verifies the embedding GGUF**, but does not fake an embedding vector.

To make semantic search/RAG fully operational, the next native step is to expose llama.cpp's embedding API through the Android binding (or use a binding/version that exposes it), then connect `EmbeddingEngine.embed()` to that native call. llama.cpp itself supports embeddings and its embedding example retrieves embedding vectors.

## React Native status

This project is still not 100% React Native. The UI is React/React DOM loaded in an Android WebView. The native AI/download layer is Kotlin/llama.cpp.

This build intentionally does not claim otherwise.


## 2026-09-02 bundled-model migration

The LLM and embedding GGUF files are now build-time bundled assets. Runtime model downloads and the foreground download service were removed. `ModelAssets` copies and validates packaged assets once in private storage.
