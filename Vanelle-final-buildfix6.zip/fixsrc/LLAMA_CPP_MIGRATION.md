# Migration llama.cpp locale

- Le moteur cloud a été retiré du chemin d'inférence.
- WebLLM et WebGPU ont été retirés des dépendances et du moteur local.
- Llama.cpp est maintenant l'unique moteur LLM.
- Modèle par défaut : SmolLM2-360M-Instruct Q4_K_M, GGUF (~271 Mo).
- Android télécharge le modèle automatiquement au démarrage, reprend un téléchargement interrompu, vérifie le SHA-256, puis charge le modèle en mémoire.
- Les anciennes configurations d'IA sont automatiquement normalisées vers `engineId: "local"`.
- Les moteurs cloud précédemment enregistrés ne sont plus utilisés.
- Les exports complets et individuels sont maintenant des archives ZIP contenant les configurations et conversations.
- Les notifications toast ont été supprimées ; les erreurs/statuts sont affichés dans l'interface.

La version navigateur du studio ne fait pas d'inférence : l'inférence locale nécessite le packaging Android natif, qui embarque llama.cpp via `llamacpp-kotlin`.
