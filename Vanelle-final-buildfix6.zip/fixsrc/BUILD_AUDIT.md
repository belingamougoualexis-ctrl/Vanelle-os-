# Vanelle final audit — 2026-09-02

- Active UI is React Native 0.87, not WebView/React DOM.
- New Architecture + Hermes enabled.
- Android uses a ReactActivity and MainApplication with the official RN host pattern.
- Native `VanelleNative` module calls the local llama.cpp Kotlin binding.
- LLM and Nomic embedding GGUF downloads are independent of the chat UI.
- Downloader is synchronized, resumable, retries transient IO failures, follows redirects, handles Range fallback, and verifies SHA-256.
- Android foreground-service notifications report progress and completion.
- Notification permission is requested on Android 13+.
- AI/chat data persists through AsyncStorage.
- LLM SHA-256: ade7aee1e5bd7c3b8f1fedafc61a1a0be31e8afa64e006607cd202323e2ccce0
- Embedding SHA-256: d4e388894e09cf3816e8b0896d81d265b55e7a9fff9ab03fe8bf4ef5e11295ac

## Build verification
This sandbox has Node 22.16 and JDK 21, but it cannot download the Gradle distribution/Maven/npm dependencies. Therefore an APK build could not be executed here. The ZIP is source/configuration audited, not falsely advertised as a compiled APK.
