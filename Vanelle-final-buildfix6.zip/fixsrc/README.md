# Vanelle

Vanelle is a bare React Native Android application with a native llama.cpp bridge.

## Requirements
- Node.js >= 22.13
- JDK 17 recommended
- Android SDK/Build Tools compatible with React Native 0.87
- Run `npm install`, then `npm run android`

## Models
The app downloads and verifies:
- SmolLM2-360M-Instruct Q4_K_M
- Nomic Embed Text v1.5 Q4_K_M

Downloads run in an Android foreground service and can resume from `.part` files.

## Important
The embedding GGUF lifecycle is implemented. The current `llamacpp-kotlin` dependency used by this project does not expose a typed embedding-vector API, so vector generation/RAG must be connected to a binding that exposes llama.cpp's embedding API; the app does not fake embeddings.
