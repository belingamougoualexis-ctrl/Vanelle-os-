# NEXUS Android 1.2.0

**NEXUS est un overlay décentralisé de réseau des réseaux.** Les appareils autorisés peuvent transporter du trafic IP par plusieurs sauts, sélectionner automatiquement une sortie Internet réelle, découvrir des pairs, résoudre des noms `.mesh`, stocker des données de façon distribuée et continuer à fonctionner lorsque certaines connexions disparaissent.

NEXUS ne crée pas de bande passante ou de portée radio à partir de rien. Un téléphone peut exploiter Wi‑Fi, cellulaire, Ethernet, Wi‑Fi Direct ou tout autre transport IP réellement exposé par l'appareil, mais une liaison longue portée, un satellite, une fibre ou une radio doit exister physiquement.

## Backhaul physique et multi-backhaul réel

`NexusPhysicalBackhaul` inventorie les réseaux IP réellement exposés par Android. NEXUS reconnaît notamment Wi‑Fi, cellulaire, Ethernet, USB, Wi‑Fi Aware, Bluetooth réseau, LoWPAN, Thread et le transport satellite lorsqu'il est disponible sur la version Android concernée. Les transports satellite et USB récents sont traités uniquement derrière les contrôles de version appropriés.

Un terminal fibre, radio longue portée ou laser qui fournit une interface IP à Android peut donc être utilisé comme backhaul. NEXUS ne génère pas lui-même le signal radio/laser ni une capacité satellite : il exploite le réseau que le matériel et son opérateur exposent réellement au système.

`NexusTransportManager` lie maintenant les sockets TCP/UDP sortants à de vrais objets `Network`. Pour plusieurs backhauls validés, les flux indépendants peuvent être répartis entre les réseaux disponibles, avec reprise sur un autre réseau en cas d'échec. Une seule session TCP n'est pas artificiellement "accélérée" par concaténation de liens incompatibles. NEXUS n'invente plus de valeurs de latence/perte pour classer ces backhauls : lorsqu'elles ne sont pas fournies par Android, elles sont simplement traitées comme inconnues.

`NexusExternalLinkProtocol` définit en plus un framing NXL1 avec séquence et CRC-32 pour les accessoires radio/laser/modem qui veulent transporter directement des trames NEXUS. Un accessoire non-IP doit cependant implémenter ce protocole ou fournir une passerelle IP : Android ne peut pas transformer génériquement n'importe quel modem radio USB en interface Internet sans pilote/protocole adapté.

## Architecture 1.0

```text
                         TRANSPORTS PHYSIQUES RÉELS
        Wi‑Fi / cellulaire / Ethernet / P2P / backhaul satellite-réseau / radio-IP
                                      │
                                      ▼
A ───── NEXUS ───── B ───── NEXUS ───── C ───── passerelle ───── Internet
 │                  │                    │
 TUN/VPN            relais               stockage distribué
 │                  │                    │
 E2E                QoS / crédits        DHT / DTN / contenu
                                      │
                               routage hiérarchique
                                      │
                              identité / confiance
```

Les rôles de passerelle et de transit restent opt-in.

## Routage mondial en overlay

`MeshRouter` reste le moteur de prochain saut local : il tient plusieurs candidats, mesure les liens, pénalise les échecs, évite les boucles et bascule sur un autre chemin.

`NexusGlobalRoutingTable` ajoute une couche hiérarchique :

- domaine virtuel `NXD-*` dérivé de l'identité du nœud ;
- préfixe d'overlay `nexus:NXD-*` ;
- annonces expirables ;
- chemin complet limité pour éviter les boucles ;
- plusieurs routes avec coût calculé à partir de la métrique et du nombre de sauts.

Cela représente un **routage mondial d'overlay**, pas un remplacement de BGP ou des routeurs opérateurs.

## DHT et nommage

`NexusDht` fournit une table de style Kademlia avec distance XOR, expiration et recherche de voisins proches.

Les enregistrements de noms sont signés. Le nommage NEXUS utilise une forme auto-certifiante :

```text
<empreinte de clé publique>.mesh
```

Les enregistrements sont vérifiés avant acceptation puis peuvent être répliqués à plusieurs pairs via `NexusDhtReplicator`.

## NAT traversal

`NexusNatTraversal` réalise une vraie découverte STUN et expose les candidats publics obtenus. Un mécanisme UDP de hole punching est également fourni.

NEXUS n'affirme jamais qu'un NAT permet forcément une connexion directe : quand le chemin direct échoue, le relais NEXUS reste le mécanisme de secours.

## DTN / réseau opportuniste

`NexusDtnStore` permet de conserver temporairement une donnée lorsqu'elle ne peut pas être livrée immédiatement.

Chaque bundle contient :

- identité d'origine et destination ;
- expiration ;
- priorité ;
- nombre de tentatives ;
- historique des nœuds visités ;
- vérification d'intégrité du payload.

Le bundle peut être retransmis lorsqu'un pair redevient disponible.

## Bande passante, énergie et QoS

NEXUS combine la politique de relais existante avec `NexusQosController`.

La régulation peut donc prendre en compte :

- débit maximal ;
- partage par pair ;
- quota journalier ;
- batterie et mode de charge ;
- réseaux mesurés ;
- classe de trafic et poids du flux.

L'algorithme applique effectivement des token buckets au chemin de données du relais.

## Crédits

Les crédits sont une **comptabilité interne de ressources** : les octets réellement relayés peuvent produire des crédits et leur solde peut être utilisé lorsque la politique de consommation stricte est activée.

Ce système n'est pas présenté comme une monnaie mondiale, ni comme une blockchain globale.

## Sécurité et lutte contre Sybil

NEXUS combine plusieurs mécanismes :

- identité cryptographique persistante ;
- signature des capacités ;
- HMAC du réseau ;
- chiffrement E2E des sessions ;
- réputation locale ;
- TOFU/listes autorisées ;
- preuve de travail légère `NexusAdmission`.

La preuve de travail **augmente le coût** de création d'identités mais ne résout pas seule les attaques Sybil. Le réseau public doit également utiliser la diversité de chemins, la réputation et des politiques d'admission appropriées.

## Stockage distribué

Le stockage NEXUS découpe les contenus en blocs adressés par hash SHA-256 et peut répliquer les contenus épinglés vers plusieurs pairs.

La récupération teste plusieurs fournisseurs puis vérifie le hash final avant de livrer le contenu.

Il s'agit d'une architecture P2P adressée par contenu inspirée de systèmes comme IPFS/BitTorrent, sans prétendre embarquer toute leur pile.

## Partage hors ligne

L'application peut exporter son APK et proposer son partage Android hors ligne. Un transfert NEXUS direct peut aussi envoyer le fichier à un pair en vérifiant taille et SHA-256.

L'installation finale dépend toujours des restrictions et autorisations Android.

## Un bouton

`CONNECTER AUTOMATIQUEMENT` lance le service, demande l'autorisation VPN si nécessaire, active la découverte et laisse le moteur sélectionner une route réelle.

Le partage de transit reste volontaire afin de protéger batterie, forfait et stockage.

## IPv4 / IPv6

Le cœur userspace conserve IPv4 et IPv6, TCP/UDP, fragments IPv6, contrôle TCP avancé, ICMPv6 et les fonctions ND/MLD ajoutées précédemment.

La gestion des extensions IPv6 reste explicitement limitée au sous-ensemble réellement pris en charge. Par exemple, la reconnaissance du Jumbo Payload ne signifie pas que NEXUS transporte actuellement des jumbograms au-delà du MTU TUN configuré.

## Interopérabilité

Les endpoints de bootstrap sont normalisés par `NexusInterop` :

```text
nexus://203.0.113.10:45454
nexus://[2001:db8::10]:45454
203.0.113.10:45454
```

Une organisation de résilience peut ainsi fournir de vrais points d'entrée distants. NEXUS peut exploiter le backhaul IP que ces points d'entrée exposent.

## Limite physique fondamentale

NEXUS peut résoudre les problèmes logiciels de découverte, routage, chiffrement, résilience, congestion et stockage. Il ne peut pas supprimer les lois physiques :

```text
logiciel NEXUS
      ↓
interfaces radio / câble / satellite / fibre réelles
      ↓
propagation physique
      ↓
autre nœud
```

Un réseau mondial réel nécessite donc suffisamment de nœuds, de liens longue portée et de points d'interconnexion.

## Validation réelle

La CI 1.2 exécute les contrôles du cœur par composant dans une matrice indépendante afin d'éviter qu'un ralentissement du compilateur local masque le résultat d'un autre module. Les contrôles principaux sont :

```text
ICMPv6 / ND / MLD                         OK
IPv6 / TCP / UDP                          OK
NXP authentifié                            OK
Auto-route / failover                     OK
Multi-hop TCP+UDP                         OK
E2E TCP+UDP                                OK
DHT / routage / admission                 OK
NAT hole-punch                             OK
DTN / QoS                                  OK
Persistance / contenu / crédits / noms    OK
Backhaul physique / USB NXL1              OK
```

Le SDK Android complet n'est pas disponible dans cet environnement de travail ; aucun APK n'est donc présenté comme compilé localement ici. Le workflow GitHub Actions fournit la construction Android séparément.

## Positionnement

NEXUS est conçu prioritairement pour la **résilience réseau, l'accès local/offline, les environnements mal connectés et la continuité de service lors de pannes d'infrastructure**, avec participation volontaire des appareils.
