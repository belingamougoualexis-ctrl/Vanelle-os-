package com.nexus.network

import android.content.Context
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Background, opt-in replication of pinned content to other relay nodes. */
class NexusContentReplicator(
    private val context: Context,
    private val peersProvider: () -> List<NsdController.Peer>
) {
    private val pool = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "nexus-content-replicator").apply { isDaemon = true }
    }
    private val lastAttempt = ConcurrentHashMap<String, Long>()
    @Volatile private var running = false

    fun start() {
        if (running) return
        running = true
        pool.scheduleWithFixedDelay({ replicateOnce() }, 15, 45, TimeUnit.SECONDS)
    }

    fun stop() {
        running = false
        pool.shutdownNow()
        lastAttempt.clear()
    }

    fun replicateOnce() {
        if (!running) return
        val manifests = NexusContentStore.allPinned(context).take(4)
        if (manifests.isEmpty()) return
        val peers = peersProvider()
            .asSequence()
            .filter { it.relay && it.host.isNotBlank() }
            .filter { NexusTrustStore.isAllowed(context, it.name) }
            .sortedByDescending { NexusTrustStore.reputation(context, it.name) }
            .distinctBy { it.host }
            .take(NexusSettings.replicationFactor(context))
            .toList()
        if (peers.isEmpty()) return
        val now = System.currentTimeMillis()
        for (manifest in manifests) {
            for (peer in peers) {
                val key = "${manifest.hash}:${peer.name}"
                if (now - (lastAttempt[key] ?: 0L) < 5 * 60_000L) continue
                lastAttempt[key] = now
                val ok = NexusContentClient.push(peer.host, context, manifest.hash).getOrDefault(false)
                if (ok) NexusTrustStore.reward(context, peer.name, 0.01) else NexusTrustStore.penalize(context, peer.name, 0.01)
            }
        }
    }
}
