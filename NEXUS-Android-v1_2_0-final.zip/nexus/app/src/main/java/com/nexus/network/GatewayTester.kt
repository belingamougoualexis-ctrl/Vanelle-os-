package com.nexus.network

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets

object GatewayTester {
    data class Result(val ok: Boolean, val detail: String)

    fun test(): Result {
        return runCatching {
            Socket().use { proxy ->
                proxy.soTimeout = 8000
                proxy.connect(InetSocketAddress("127.0.0.1", NexusConfig.SOCKS_PORT), 2000)
                val input = proxy.getInputStream()
                val output = proxy.getOutputStream()
                output.write(byteArrayOf(5, 1, 2))
                output.flush()
                check(input.read() == 5)
                check(input.read() == 2)

                val user = "nexus".toByteArray(StandardCharsets.UTF_8)
                val pass = NexusConfig.SOCKS_PASSWORD.toByteArray(StandardCharsets.UTF_8)
                output.write(byteArrayOf(1, user.size.toByte()))
                output.write(user)
                output.write(byteArrayOf(pass.size.toByte()))
                output.write(pass)
                output.flush()
                check(input.read() == 1)
                check(input.read() == 0) { "Authentification refusée" }

                val host = "example.com".toByteArray(StandardCharsets.UTF_8)
                output.write(byteArrayOf(5, 1, 0, 3, host.size.toByte()))
                output.write(host)
                output.write(byteArrayOf(0, 80))
                output.flush()
                check(input.read() == 5)
                val reply = input.read()
                check(reply == 0) { "Connexion cible refusée: code $reply" }
                repeat(8) { input.read() }

                val writer = OutputStreamWriter(output, StandardCharsets.US_ASCII)
                writer.write("HEAD / HTTP/1.1\r\nHost: example.com\r\nConnection: close\r\n\r\n")
                writer.flush()
                val reader = BufferedReader(InputStreamReader(input, StandardCharsets.US_ASCII))
                val line = reader.readLine() ?: error("Aucune réponse HTTP")
                Result(true, "Sortie Internet réelle OK • $line")
            }
        }.getOrElse { Result(false, "Échec réel: ${it.message ?: it.javaClass.simpleName}") }
    }
}
