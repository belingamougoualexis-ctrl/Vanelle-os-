package com.nexus.network

import android.content.Context
import java.util.concurrent.ConcurrentHashMap

/** TOFU identity pinning + local reputation. This reduces spoofing but cannot remove Sybil risk without an admission authority. */
object NexusTrustStore {
    private const val PREFS = "nexus_trust"
    private const val FP_PREFIX = "fp_"
    private const val SCORE_PREFIX = "score_"
    private val cache = ConcurrentHashMap<String, Double>()

    fun observe(context: Context, nodeId: String, publicKeyB64: String) {
        if (nodeId.isBlank() || publicKeyB64.isBlank()) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val fp = NexusCrypto.sha256Hex(publicKeyB64).take(24)
        val previous = prefs.getString(FP_PREFIX + nodeId, null)
        if (previous != null && previous != fp) {
            prefs.edit().putString(SCORE_PREFIX + nodeId, "0.0").apply()
            cache[nodeId] = 0.0
            return
        }
        if (previous == null) prefs.edit().putString(FP_PREFIX + nodeId, fp).apply()
        cache.putIfAbsent(nodeId, prefs.getString(SCORE_PREFIX + nodeId, "1.0")?.toDoubleOrNull() ?: 1.0)
    }

    fun reputation(context: Context, nodeId: String): Double {
        val raw = cache[nodeId] ?: context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(SCORE_PREFIX + nodeId, "0.5")?.toDoubleOrNull() ?: 0.5
        return if (isAllowed(context, nodeId)) raw.coerceIn(0.0, 1.0) else 0.0
    }

    fun isAllowed(context: Context, nodeId: String): Boolean =
        !NexusSettings.trustedOnly(context) || NexusSettings.trustedPeerIds(context).contains(nodeId)

    fun reward(context: Context, nodeId: String, delta: Double) = adjust(context, nodeId, delta.coerceIn(0.0, 0.2))
    fun penalize(context: Context, nodeId: String, delta: Double) = adjust(context, nodeId, -delta.coerceIn(0.0, 0.2))

    private fun adjust(context: Context, nodeId: String, delta: Double) {
        val current = reputation(context, nodeId)
        val next = (current + delta).coerceIn(0.0, 1.0)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(SCORE_PREFIX + nodeId, next.toString()).apply()
        cache[nodeId] = next
    }
}
