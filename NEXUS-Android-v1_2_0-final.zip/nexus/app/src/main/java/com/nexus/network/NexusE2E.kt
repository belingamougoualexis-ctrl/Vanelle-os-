package com.nexus.network

import java.io.InputStream
import java.io.OutputStream
import java.net.SocketTimeoutException

/** End-to-end session carried inside the hop-by-hop NEXUS relay path. */
object NexusE2E {
    private const val MAX_LINE = 4096

    fun client(
        context: android.content.Context,
        channel: NexusStreamChannel,
        nodeId: String,
        expectedGatewayPublicKey: String
    ): NexusStreamChannel {
        require(expectedGatewayPublicKey.isNotBlank()) { "Clé publique de passerelle absente" }
        val localEphemeral = NexusIdentity.generateEphemeral()
        val clientNonce = NexusCrypto.nonce(18)
        val eph = NexusCrypto.encodeBytes(localEphemeral.public.encoded)
        val node = NexusCrypto.encode(nodeId)
        val pub = NexusIdentity.publicKeyBase64(context)
        val canonical = "v=1&type=hello&node=$node&nonce=$clientNonce&eph=$eph&pub=${NexusCrypto.encode(pub)}"
        val sig = NexusCrypto.encodeBytes(NexusIdentity.sign(context, canonical))
        writeLine(channel.output, "NEXUS-E2E/1 HELLO v=1 node=$node nonce=$clientNonce eph=$eph pub=${NexusCrypto.encode(pub)} sig=${NexusCrypto.encode(sig)}")

        val response = readLine(channel.input) ?: error("Handshake E2E absent")
        val fields = parseFields(response)
        require(response.startsWith("NEXUS-E2E/1 OK")) { "Handshake E2E refusé" }
        val serverNonce = fields["nonce"] ?: error("Nonce E2E absent")
        val serverEphB64 = fields["eph"] ?: error("Clé E2E absente")
        val serverPub = NexusCrypto.decode(fields["pub"] ?: error("Identité passerelle absente"))
        val serverSig = NexusCrypto.decode(fields["sig"] ?: error("Signature passerelle absente"))
        require(serverPub == expectedGatewayPublicKey) { "Passerelle E2E inattendue" }
        val verifyCanonical = "v=1&type=ok&node=${fields["node"]}&clientNonce=$clientNonce&serverNonce=$serverNonce&eph=${fields["eph"]}&pub=${fields["pub"]}"
        require(NexusIdentity.verify(serverPub, verifyCanonical, serverSig)) { "Signature passerelle invalide" }

        val shared = NexusIdentity.ecdh(localEphemeral.private, serverEphB64)
        val key = NexusSecureFraming.deriveKey(NexusCrypto.encodeBytes(shared), "$clientNonce|$serverNonce", "e2e-v1")
        return FramedChannel(channel, NexusSecureInputStream(channel.input, key), NexusSecureOutputStream(channel.output, key))
    }

    fun server(context: android.content.Context, channel: NexusStreamChannel, expectedClientNetworkKey: Boolean = true): NexusStreamChannel {
        val hello = readLine(channel.input) ?: error("Handshake client E2E absent")
        val fields = parseFields(hello)
        require(hello.startsWith("NEXUS-E2E/1 HELLO")) { "HELLO E2E invalide" }
        val clientNonce = fields["nonce"] ?: error("Nonce E2E absent")
        val clientEphB64 = fields["eph"] ?: error("Clé éphémère absente")
        val clientPub = NexusCrypto.decode(fields["pub"] ?: error("Clé identité absente"))
        val clientSig = NexusCrypto.decode(fields["sig"] ?: error("Signature absente"))
        val canonical = "v=1&type=hello&node=${fields["node"]}&nonce=$clientNonce&eph=${fields["eph"]}&pub=${fields["pub"]}"
        if (expectedClientNetworkKey) require(NexusIdentity.verify(clientPub, canonical, clientSig)) { "Signature client invalide" }

        val serverEphemeral = NexusIdentity.generateEphemeral()
        val serverNonce = NexusCrypto.nonce(18)
        val serverNodeId = NexusIdentity.nodeId(context)
        val serverPub = NexusIdentity.publicKeyBase64(context)
        val serverEph = NexusCrypto.encodeBytes(serverEphemeral.public.encoded)
        val okCanonical = "v=1&type=ok&node=${NexusCrypto.encode(serverNodeId)}&clientNonce=$clientNonce&serverNonce=$serverNonce&eph=$serverEph&pub=${NexusCrypto.encode(serverPub)}"
        val sig = NexusCrypto.encodeBytes(NexusIdentity.sign(context, okCanonical))
        writeLine(channel.output, "NEXUS-E2E/1 OK v=1 node=${NexusCrypto.encode(serverNodeId)} nonce=$serverNonce eph=$serverEph pub=${NexusCrypto.encode(serverPub)} sig=${NexusCrypto.encode(sig)}")

        val shared = NexusIdentity.ecdh(serverEphemeral.private, clientEphB64)
        val key = NexusSecureFraming.deriveKey(NexusCrypto.encodeBytes(shared), "$clientNonce|$serverNonce", "e2e-v1")
        return FramedChannel(channel, NexusSecureInputStream(channel.input, key), NexusSecureOutputStream(channel.output, key))
    }

    private data class FramedChannel(
        private val base: NexusStreamChannel,
        override val input: InputStream,
        override val output: OutputStream
    ) : NexusStreamChannel {
        private val secureOut = output as NexusSecureOutputStream
        override fun shutdownOutput() { secureOut.shutdownOutput() }
        override fun close() { runCatching { secureOut.shutdownOutput() }; runCatching { base.close() } }
    }


    private fun parseFields(line: String): Map<String, String> = line.split(' ').drop(2).mapNotNull { token ->
        val i = token.indexOf('=')
        if (i <= 0) null else token.substring(0, i) to token.substring(i + 1)
    }.toMap()

    private fun writeLine(output: OutputStream, line: String) {
        output.write(line.toByteArray(Charsets.US_ASCII)); output.write('\n'.code); output.flush()
    }

    private fun readLine(input: InputStream): String? {
        val buffer = ByteArray(MAX_LINE)
        var count = 0
        while (count < MAX_LINE) {
            val b = try { input.read() } catch (_: SocketTimeoutException) { return null }
            if (b < 0) return if (count == 0) null else String(buffer, 0, count, Charsets.US_ASCII)
            if (b == '\n'.code) return String(buffer, 0, count, Charsets.US_ASCII)
            if (b != '\r'.code) buffer[count++] = b.toByte()
        }
        error("Handshake E2E trop long")
    }
}


class NexusE2EDatagram private constructor(
    private val base: DatagramRelayProtocol.Session,
    private val key: javax.crypto.spec.SecretKeySpec,
    private var sendSequence: Long = 0L,
    private var receiveSequence: Long = 0L
) : AutoCloseable {
    fun send(payload: ByteArray) {
        val frame = NexusSecureFraming.encryptFrame(key, sendSequence++, payload)
        base.send(frame)
    }

    fun receive(): ByteArray? {
        val frame = base.receive() ?: return null
        val decoded = NexusSecureFraming.decryptFrame(key, frame)
        require(decoded.sequence == receiveSequence++) { "Séquence E2E UDP invalide" }
        return decoded.plaintext
    }

    override fun close() = base.close()

    companion object {
        private const val PREFIX = "NEXUS-E2E-D/1"
        private const val MAX = 4096

        fun client(context: android.content.Context, base: DatagramRelayProtocol.Session, nodeId: String, expectedGatewayPublicKey: String): NexusE2EDatagram {
            require(expectedGatewayPublicKey.isNotBlank())
            val eph = NexusIdentity.generateEphemeral(); val nonce=NexusCrypto.nonce(18)
            val node=NexusCrypto.encode(nodeId); val ephB64=NexusCrypto.encodeBytes(eph.public.encoded); val pub=NexusIdentity.publicKeyBase64(context)
            val canonical="v=1&type=hello&node=$node&nonce=$nonce&eph=$ephB64&pub=${NexusCrypto.encode(pub)}"
            val sig=NexusCrypto.encodeBytes(NexusIdentity.sign(context,canonical))
            base.send("$PREFIX HELLO v=1 node=$node nonce=$nonce eph=$ephB64 pub=${NexusCrypto.encode(pub)} sig=${NexusCrypto.encode(sig)}".toByteArray(Charsets.US_ASCII))
            val response=String(base.receive() ?: error("Handshake E2E UDP absent"),Charsets.US_ASCII); val f=fields(response);require(response.startsWith("$PREFIX OK"))
            val serverNode=f["node"]?:error("Node UDP E2E absent"); val serverNonce=f["nonce"]?:error("Nonce UDP E2E absent"); val serverEph=f["eph"]?:error("Clé UDP E2E absente"); val serverPub=NexusCrypto.decode(f["pub"]?:error("Identité UDP E2E absente")); val sigRaw=NexusCrypto.decode(f["sig"]?:error("Signature UDP E2E absente"))
            require(serverPub==expectedGatewayPublicKey)
            val verify="v=1&type=ok&node=$serverNode&clientNonce=$nonce&serverNonce=$serverNonce&eph=$serverEph&pub=${f["pub"]}"
            require(NexusIdentity.verify(serverPub,verify,sigRaw))
            val shared=NexusIdentity.ecdh(eph.private, f["eph"]!!); val key=NexusSecureFraming.deriveKey(NexusCrypto.encodeBytes(shared),"$nonce|$serverNonce","e2e-d-v1")
            return NexusE2EDatagram(base,key)
        }

        fun server(context: android.content.Context, base: DatagramRelayProtocol.Session): NexusE2EDatagram {
            val hello=String(base.receive()?:error("Handshake UDP E2E absent"),Charsets.US_ASCII); val f=fields(hello); require(hello.startsWith("$PREFIX HELLO"))
            val clientNonce=f["nonce"]?:error("Nonce UDP E2E absent"); val clientEph=f["eph"]?:error("Clé UDP E2E absente"); val clientPub=NexusCrypto.decode(f["pub"]?:error("Identité client UDP absente")); val sigRaw=NexusCrypto.decode(f["sig"]?:error("Signature client UDP absente"))
            val canonical="v=1&type=hello&node=${f["node"]}&nonce=$clientNonce&eph=${f["eph"]}&pub=${f["pub"]}";require(NexusIdentity.verify(clientPub,canonical,sigRaw))
            val eph=NexusIdentity.generateEphemeral();val serverNonce=NexusCrypto.nonce(18);val node=NexusIdentity.nodeId(context);val pub=NexusIdentity.publicKeyBase64(context);val ephB64=NexusCrypto.encodeBytes(eph.public.encoded)
            val ok="v=1&type=ok&node=${NexusCrypto.encode(node)}&clientNonce=$clientNonce&serverNonce=$serverNonce&eph=$ephB64&pub=${NexusCrypto.encode(pub)}";val sig=NexusCrypto.encodeBytes(NexusIdentity.sign(context,ok));base.send("$PREFIX OK v=1 node=${NexusCrypto.encode(node)} nonce=$serverNonce eph=$ephB64 pub=${NexusCrypto.encode(pub)} sig=${NexusCrypto.encode(sig)}".toByteArray(Charsets.US_ASCII))
            val shared=NexusIdentity.ecdh(eph.private,clientEph);val key=NexusSecureFraming.deriveKey(NexusCrypto.encodeBytes(shared),"$clientNonce|$serverNonce","e2e-d-v1");return NexusE2EDatagram(base,key)
        }

        private fun fields(line: String): Map<String, String> = line.split(' ').drop(2).mapNotNull { token ->
            val i = token.indexOf('=')
            if (i > 0) token.substring(0, i) to token.substring(i + 1) else null
        }.toMap()
    }
}
