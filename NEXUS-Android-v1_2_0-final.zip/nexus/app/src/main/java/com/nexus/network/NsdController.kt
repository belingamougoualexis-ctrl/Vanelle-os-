package com.nexus.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class NsdController(private val context: Context) {
    data class Peer(
        val name: String,
        val host: String,
        val port: Int,
        @Volatile var gateway: Boolean = false,
        @Volatile var relay: Boolean = false,
        @Volatile var gatewayDistance: Int = Int.MAX_VALUE,
        @Volatile var gatewayPath: List<String> = emptyList(),
        @Volatile var latencyMs: Double = Double.POSITIVE_INFINITY,
        @Volatile var packetLossPct: Double = 100.0,
        @Volatile var bandwidthMbps: Double = 0.0,
        @Volatile var p2p: Boolean = false,
        @Volatile var lastSeenAt: Long = System.currentTimeMillis(),
        @Volatile var consecutiveFailures: Int = 0,
        @Volatile var lastProbeAt: Long = 0L,
        @Volatile var identityPublicKey: String = "",
        @Volatile var gatewayPublicKey: String = "",
        @Volatile var authenticatedIdentity: Boolean = false
    )

    private val manager = context.getSystemService(NsdManager::class.java)
    private val peers = ConcurrentHashMap<String, Peer>()
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var registrationListener: NsdManager.RegistrationListener? = null
    private val probePool = Executors.newCachedThreadPool { r -> Thread(r, "nexus-nsd-probe").apply { isDaemon = true } }

    @Volatile var onChanged: ((List<Peer>) -> Unit)? = null

    fun startDiscovery() {
        if (discoveryListener != null || manager == null) return
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) = Unit
            override fun onDiscoveryStopped(serviceType: String) = Unit
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) = Unit
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) = Unit
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                peers.remove(serviceInfo.serviceName)
                notifyChanged()
            }
            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                if (serviceInfo.serviceType == NexusConfig.SERVICE_TYPE || serviceInfo.serviceType == "${NexusConfig.SERVICE_TYPE}.") {
                    resolve(serviceInfo)
                }
            }
        }
        discoveryListener = listener
        runCatching { manager.discoverServices(NexusConfig.SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener) }
    }

    private fun resolve(service: NsdServiceInfo) {
        runCatching {
            manager.resolveService(service, object : NsdManager.ResolveListener {
                override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = Unit
                override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                    val host = serviceInfo.host?.hostAddress ?: return
                    if (serviceInfo.serviceName == NexusIdentity.nodeId(context)) return
                    val peer = peers.getOrPut(serviceInfo.serviceName) { Peer(serviceInfo.serviceName, host, serviceInfo.port) }
                    peer.lastSeenAt = System.currentTimeMillis()
                    if (peer.host != host || peer.port != serviceInfo.port) {
                        peers[serviceInfo.serviceName] = peer.copy(host = host, port = serviceInfo.port)
                    }
                    notifyChanged()
                    probe(serviceInfo.serviceName)
                }
            })
        }
    }

    fun refreshP2pEndpoints() {
        NexusP2PDirectory.snapshot().forEach { endpoint ->
            val key = "P2P-${endpoint.deviceAddress}"
            val peer = peers.getOrPut(key) { Peer(key, endpoint.host, endpoint.port, p2p = true) }
            peer.p2p = true
            peer.gateway = endpoint.gateway
            peer.relay = endpoint.relay
            peer.gatewayDistance = endpoint.gatewayDistance
            peer.gatewayPath = endpoint.gatewayPath
            peer.latencyMs = endpoint.latencyMs
            peer.packetLossPct = endpoint.packetLossPct
            peer.bandwidthMbps = endpoint.bandwidthMbps
            peer.lastSeenAt = System.currentTimeMillis()
            probe(key)
        }
        val current = NexusP2PDirectory.snapshot().map { "P2P-${it.deviceAddress}" }.toSet()
        peers.keys.filter { it.startsWith("P2P-") && it !in current }.forEach { peers.remove(it) }
        notifyChanged()
    }

    fun probeAll() {
        val now = System.currentTimeMillis()
        peers.values.forEach { peer ->
            val age = now - peer.lastSeenAt
            if (age < 35_000 || peer.consecutiveFailures > 0) probe(peer.name)
        }
        refreshP2pEndpoints()
    }

    private fun probe(name: String) {
        val peer = peers[name] ?: return
        val now = System.currentTimeMillis()
        if (now - peer.lastProbeAt < 7_000) return
        peer.lastProbeAt = now
        probePool.execute {
            runCatching {
                val caps = NxpProtocol.probeCapabilities(peer.host, peer.port) { NetworkKeyManager.accepted(context) }
                if (NexusSettings.trustedOnly(context) && !NexusSettings.trustedPeerIds(context).contains(caps.nodeId)) {
                    throw SecurityException("Nœud non autorisé par la politique de confiance")
                }
                updateCapabilities(name, caps.gateway, caps.relay, caps.gatewayDistance, caps.gatewayPath, caps.latencyMs, caps.packetLossPct, caps.bandwidthMbps, caps.identityPublicKey, caps.gatewayPublicKey, caps.authenticatedIdentity, success = true)
                if (caps.identityPublicKey.isNotBlank()) NexusTrustStore.observe(context, caps.nodeId, caps.identityPublicKey)
            }.onSuccess { caps ->
                if (caps.identityPublicKey.isNotBlank()) NexusTrustStore.reward(context, caps.nodeId, 0.02)
            }.onFailure {
                peers[name]?.let { peer ->
                    peer.consecutiveFailures = (peer.consecutiveFailures + 1).coerceAtMost(10)
                    NexusTrustStore.penalize(context, peer.name, 0.03)
                    notifyChanged()
                }
            }
        }
    }

    fun peersSnapshot(): List<Peer> = peers.values
        .filter { System.currentTimeMillis() - it.lastSeenAt <= 35_000 }
        .toList()

    fun addRemotePeer(host: String, port: Int, name: String = "BOOTSTRAP-$host-$port") {
        if (host.isBlank() || port !in 1..65535) return
        if (name == NexusIdentity.nodeId(context)) return
        val peer = peers.getOrPut(name) { Peer(name, host, port) }
        peer.lastSeenAt = System.currentTimeMillis()
        peer.p2p = false
        notifyChanged()
        probe(name)
    }

    fun updateCapabilities(
        peerName: String,
        gateway: Boolean,
        relay: Boolean,
        distance: Int,
        path: List<String> = emptyList(),
        latencyMs: Double,
        packetLossPct: Double = 100.0,
        bandwidthMbps: Double = 0.0,
        identityPublicKey: String = "",
        gatewayPublicKey: String = "",
        authenticatedIdentity: Boolean = false,
        success: Boolean = true
    ) {
        peers[peerName]?.let {
            it.gateway = gateway
            it.relay = relay
            it.gatewayDistance = distance
            it.gatewayPath = path
            it.latencyMs = latencyMs
            it.packetLossPct = packetLossPct
            it.bandwidthMbps = bandwidthMbps
            it.identityPublicKey = identityPublicKey
            it.gatewayPublicKey = gatewayPublicKey
            it.authenticatedIdentity = authenticatedIdentity
            it.lastSeenAt = System.currentTimeMillis()
            if (success) it.consecutiveFailures = 0
            if (it.p2p) {
                NexusP2PDirectory.snapshot().firstOrNull { endpoint -> endpoint.host == it.host }?.apply {
                    this.gateway = gateway
                    this.relay = relay
                    this.gatewayDistance = distance
                    this.gatewayPath = path
                    this.latencyMs = latencyMs
                    this.packetLossPct = packetLossPct
                    this.bandwidthMbps = bandwidthMbps
                }
            }
            notifyChanged()
        }
    }

    fun stopDiscovery() {
        discoveryListener?.let { runCatching { manager?.stopServiceDiscovery(it) } }
        discoveryListener = null
        peers.clear()
        notifyChanged()
    }

    fun close() {
        stopDiscovery()
        probePool.shutdownNow()
    }

    fun register(nodeId: String, port: Int, onRegistered: ((String) -> Unit)? = null) {
        if (registrationListener != null || manager == null) return
        val info = NsdServiceInfo().apply {
            serviceName = nodeId
            serviceType = NexusConfig.SERVICE_TYPE
            this.port = port
        }
        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) { onRegistered?.invoke(serviceInfo.serviceName) }
            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = Unit
            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) = Unit
            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = Unit
        }
        registrationListener = listener
        runCatching { manager.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener) }
    }

    fun unregister() {
        registrationListener?.let { runCatching { manager?.unregisterService(it) } }
        registrationListener = null
    }

    private fun notifyChanged() {
        onChanged?.invoke(peers.values.sortedBy { it.name })
    }
}
