package com.nexus.network

import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Lightweight proof-of-work admission stamp. It raises Sybil creation cost but is not a complete Sybil solution. */
object NexusAdmission {
    private const val DIFFICULTY_BITS = 10
    data class Stamp(val nodeId: String, val publicKey: String, val nonce: Long, val difficultyBits: Int, val digestHex: String)
    private val cache = ConcurrentHashMap<String, Stamp>()

    fun stamp(nodeId: String, publicKey: String): Stamp = cache.computeIfAbsent(nodeId + "|" + publicKey) {
        var nonce = 0L
        var result: Stamp?
        do {
            val digest = sha256("v=1|node=$nodeId|pub=$publicKey|nonce=$nonce")
            result = if (leadingZeroBits(digest) >= DIFFICULTY_BITS) Stamp(nodeId, publicKey, nonce, DIFFICULTY_BITS, digest) else null
            nonce++
        } while (result == null)
        return@computeIfAbsent checkNotNull(result)
    }

    fun verify(stamp: Stamp): Boolean {
        if (stamp.nodeId.isBlank() || stamp.publicKey.isBlank() || stamp.difficultyBits !in 4..20) return false
        val digest = sha256("v=1|node=${stamp.nodeId}|pub=${stamp.publicKey}|nonce=${stamp.nonce}")
        return digest.contentEquals(stamp.digestHex) && leadingZeroBits(digest) >= stamp.difficultyBits
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it.toInt() and 0xff) }

    private fun leadingZeroBits(hex: String): Int {
        var bits = 0
        for (c in hex) {
            val v = c.digitToInt(16)
            if (v == 0) bits += 4 else {
                bits += Integer.numberOfLeadingZeros(v) - 28
                break
            }
        }
        return bits
    }
}
