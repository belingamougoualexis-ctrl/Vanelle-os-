package com.nexus.network

import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.min

/** Per-flow weighted fair token buckets used in addition to the relay governor. */
class NexusQosController(private val globalRateBytesPerSecond: () -> Long) {
    enum class Class(val weight: Int) { CONTROL(8), INTERACTIVE(5), STREAMING(2), BULK(1) }
    private data class Bucket(var tokens: Long, var lastNs: Long)
    private val buckets = ConcurrentHashMap<String, Bucket>()

    fun classify(port: Int): Class = when (port) {
        53, 123, 443 -> Class.INTERACTIVE
        80, 8080 -> Class.INTERACTIVE
        in 20..25 -> Class.CONTROL
        else -> Class.BULK
    }

    fun allow(flowId: String, bytes: Int, clazz: Class): Boolean {
        if (bytes <= 0) return true
        val total = globalRateBytesPerSecond().coerceAtLeast(1L)
        val share = max(32 * 1024L, total * clazz.weight / 16L)
        val bucket = buckets.computeIfAbsent(flowId.ifBlank { "flow" }) { Bucket(share, System.nanoTime()) }
        synchronized(bucket) {
            refill(bucket, share)
            if (bucket.tokens >= bytes) {
                bucket.tokens -= bytes
                return true
            }
            val missing = bytes - bucket.tokens
            val waitMs = min(250L, (missing * 1000L / share.coerceAtLeast(1L)))
            if (waitMs > 0) Thread.sleep(waitMs)
            refill(bucket, share)
            if (bucket.tokens < bytes) return false
            bucket.tokens -= bytes
            return true
        }
    }

    private fun refill(bucket: Bucket, rate: Long) {
        val now = System.nanoTime()
        val elapsed = (now - bucket.lastNs).coerceAtLeast(0L) / 1_000_000_000.0
        if (elapsed <= 0) return
        bucket.tokens = min(rate * 2L, bucket.tokens + (elapsed * rate).toLong())
        bucket.lastNs = now
    }
}
