package com.nexus.network

import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.LinkProperties
import android.os.Build

/**
 * Physical-backhaul inventory. It never claims that software creates a radio,
 * fiber, laser or satellite link: it detects IP transports that Android exposes
 * and exposes external-hardware requirements when a non-IP radio needs a bridge.
 */
class NexusPhysicalBackhaul(private val context: Context) {
    enum class Medium {
        WIFI, CELLULAR, ETHERNET, USB, BLUETOOTH, WIFI_AWARE,
        LOWPAN, THREAD, SATELLITE, UNKNOWN
    }

    data class Backhaul(
        val network: Network?,
        val medium: Medium,
        val name: String,
        val ipCapable: Boolean,
        val internetValidated: Boolean,
        val metered: Boolean,
        val downstreamKbps: Int,
        val upstreamKbps: Int,
        val interfaceName: String?,
        val longRangeCapable: Boolean,
        val externalHardware: Boolean,
        val note: String
    )

    fun inventory(): List<Backhaul> {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return emptyList()
        return cm.allNetworks.mapNotNull { network ->
            val caps = cm.getNetworkCapabilities(network) ?: return@mapNotNull null
            if (caps.hasTransport(TRANSPORT_VPN)) return@mapNotNull null
            val links = cm.getLinkProperties(network)
            val medium = mediumOf(caps)
            val internet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            val validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            val metered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
            val external = medium == Medium.USB || medium == Medium.ETHERNET
            val longRange = medium == Medium.SATELLITE || medium == Medium.CELLULAR || external
            Backhaul(
                network = network,
                medium = medium,
                name = mediumLabel(medium),
                ipCapable = internet || links?.linkAddresses?.isNotEmpty() == true,
                internetValidated = validated,
                metered = metered,
                downstreamKbps = caps.linkDownstreamBandwidthKbps,
                upstreamKbps = caps.linkUpstreamBandwidthKbps,
                interfaceName = links?.interfaceName,
                longRangeCapable = longRange,
                externalHardware = external,
                note = noteFor(medium, validated, links)
            )
        }.sortedWith(
            compareByDescending<Backhaul> { it.internetValidated }
                .thenByDescending { it.longRangeCapable }
                .thenBy { it.metered }
                .thenByDescending { it.downstreamKbps }
        )
    }

    fun usbHostAvailable(): Boolean = context.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)

    fun bestValidatedIpBackhauls(): List<Backhaul> = inventory()
        .filter { it.ipCapable && it.internetValidated && it.network != null }
        .distinctBy { it.network!!.networkHandle }

    fun physicalSummary(): String {
        val items = inventory()
        val usb = if (usbHostAvailable()) "USB Host disponible" else "USB Host indisponible"
        if (items.isEmpty()) return "$usb • aucun backhaul IP exposé"
        return items.joinToString("\n") { item ->
            val quality = when {
                item.internetValidated -> "Internet validé"
                item.ipCapable -> "IP/local"
                else -> "détection matériel"
            }
            val tariff = if (item.metered) "mesuré" else "non mesuré"
            "${item.name} • $quality • $tariff • ${item.interfaceName ?: "interface système"}"
        } + "\n$usb"
    }

    fun globalCapabilitySummary(): String {
        val items = inventory()
        val hasLongRange = items.any { it.longRangeCapable && it.internetValidated }
        val hasExternal = items.any { it.externalHardware }
        return when {
            hasLongRange && hasExternal -> "Backhaul longue portée IP réel + matériel externe détecté"
            hasLongRange -> "Backhaul longue portée IP réel détecté"
            hasExternal -> "Matériel réseau externe détecté ; validation Internet requise"
            else -> "Pas de liaison longue portée externe détectée"
        }
    }

    private fun mediumOf(caps: NetworkCapabilities): Medium = when {
        caps.hasTransport(TRANSPORT_SATELLITE) -> Medium.SATELLITE
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> Medium.ETHERNET
        caps.hasTransport(TRANSPORT_USB) -> Medium.USB
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> Medium.CELLULAR
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> Medium.WIFI
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI_AWARE) -> Medium.WIFI_AWARE
        caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> Medium.BLUETOOTH
        caps.hasTransport(TRANSPORT_LOWPAN) -> Medium.LOWPAN
        caps.hasTransport(TRANSPORT_THREAD) -> Medium.THREAD
        else -> Medium.UNKNOWN
    }

    private fun mediumLabel(medium: Medium): String = when (medium) {
        Medium.WIFI -> "Wi‑Fi"
        Medium.CELLULAR -> "Cellulaire"
        Medium.ETHERNET -> "Ethernet / backhaul filaire"
        Medium.USB -> "USB / adaptateur externe"
        Medium.BLUETOOTH -> "Bluetooth réseau"
        Medium.WIFI_AWARE -> "Wi‑Fi Aware"
        Medium.LOWPAN -> "LoWPAN"
        Medium.THREAD -> "Thread"
        Medium.SATELLITE -> "Satellite / NTN"
        Medium.UNKNOWN -> "Transport IP inconnu"
    }

    private fun noteFor(medium: Medium, validated: Boolean, links: LinkProperties?): String = when (medium) {
        Medium.SATELLITE -> if (validated) "Satellite exposé comme réseau IP ; débit et services dépendent de l'opérateur/appareil." else "Satellite détecté mais Internet non validé."
        Medium.ETHERNET, Medium.USB -> if (validated) "Peut être un terminal fibre, radio, laser, modem ou autre passerelle IP externe." else "Un équipement externe est visible ; il doit fournir un chemin IP réel."
        Medium.CELLULAR -> "Backhaul longue portée fourni par le réseau mobile de l'opérateur."
        Medium.LOWPAN, Medium.THREAD -> "Réseau local basse puissance ; pas une sortie Internet garantie."
        Medium.BLUETOOTH, Medium.WIFI_AWARE -> "Transport de proximité ; peut servir de lien entre pairs si Android l'expose comme réseau."
        Medium.WIFI -> "Réseau Wi‑Fi local ou accès Internet."
        Medium.UNKNOWN -> if (links?.linkAddresses?.isNotEmpty() == true) "Réseau IP exposé par Android." else "Type de transport non identifié."
    }
    companion object {
        // Stable transport values from NetworkCapabilities for API-gated transports.
        private const val TRANSPORT_VPN = 4
        private const val TRANSPORT_LOWPAN = 6
        private const val TRANSPORT_USB = 8
        private const val TRANSPORT_THREAD = 9
        private const val TRANSPORT_SATELLITE = 10
    }

}
