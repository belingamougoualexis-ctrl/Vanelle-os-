package com.nexus.network

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.Closeable
import java.util.concurrent.atomic.AtomicLong

/**
 * Real USB bulk transport for an external device that speaks NXL1.
 *
 * This is intentionally protocol-driven: NEXUS does not guess how an arbitrary
 * radio/laser/satellite modem works. The external accessory must expose USB bulk
 * endpoints and exchange NexusExternalLinkProtocol frames.
 */
class NexusUsbNxlTransport(context: Context) {
    data class DeviceInfo(
        val device: UsbDevice,
        val vendorId: Int,
        val productId: Int,
        val productName: String?,
        val manufacturerName: String?,
        val hasPermission: Boolean,
        val interfaceIndex: Int,
        val interfaceClass: Int,
        val bulkInAddress: Int,
        val bulkOutAddress: Int
    )

    private val usb: UsbManager? = context.getSystemService(UsbManager::class.java)
    fun devices(): List<DeviceInfo> {
        val manager = usb ?: return emptyList()
        val result = ArrayList<DeviceInfo>()
        for (device in manager.deviceList.values) {
            val match = findBulkPair(device) ?: continue
            result += DeviceInfo(
                device = device,
                vendorId = device.vendorId,
                productId = device.productId,
                productName = device.productName,
                manufacturerName = device.manufacturerName,
                hasPermission = manager.hasPermission(device),
                interfaceIndex = match.iface.id,
                interfaceClass = match.iface.interfaceClass,
                bulkInAddress = match.bulkIn.address,
                bulkOutAddress = match.bulkOut.address
            )
        }
        return result
    }

    fun open(device: UsbDevice): Connection {
        val manager = usb ?: error("UsbManager indisponible")
        check(manager.hasPermission(device)) { "Autorisation USB Android requise" }
        val match = findBulkPair(device) ?: error("Aucune paire USB bulk IN/OUT compatible")
        val connection = manager.openDevice(device) ?: error("Impossible d'ouvrir le périphérique USB")
        check(connection.claimInterface(match.iface, true)) {
            connection.close()
            "Impossible de réserver l'interface USB"
        }
        return Connection(connection, match.iface, match.bulkIn, match.bulkOut)
    }

    inner class Connection internal constructor(
        private val connection: UsbDeviceConnection,
        private val usbInterface: UsbInterface,
        private val bulkIn: UsbEndpoint,
        private val bulkOut: UsbEndpoint
    ) : Closeable {
        @Volatile private var closed = false
        private var previousRxSequence: Long? = null
        private val txSequence = AtomicLong(0L)
        private var pendingRx = ByteArray(0)

        /** Send one NXL1 payload over the real USB bulk OUT endpoint. */
        fun send(payload: ByteArray, flags: Int = 0, timeoutMs: Int = 2_000): Long {
            check(!closed) { "Connexion USB fermée" }
            val seq = txSequence.getAndIncrement()
            val frame = NexusExternalLinkProtocol.encode(flags, seq, payload)
            var offset = 0
            while (offset < frame.size) {
                val written = connection.bulkTransfer(
                    bulkOut,
                    frame,
                    offset,
                    frame.size - offset,
                    timeoutMs
                )
                check(written > 0) { "Échec d'écriture USB NXL1" }
                offset += written
            }
            return seq
        }

        /**
         * Read one complete NXL1 frame from the real USB bulk IN endpoint.
         * The accessory is expected to preserve frame boundaries at the protocol level;
         * this method nevertheless buffers partial USB packets safely.
         */
        fun receive(timeoutMs: Int = 2_000): NexusExternalLinkProtocol.Frame {
            check(!closed) { "Connexion USB fermée" }
            while (true) {
                val frame = tryDecode(pendingRx, pendingRx.size)
                if (frame != null) {
                    val consumed = frame.encodedSize()
                    pendingRx = pendingRx.copyOfRange(consumed, pendingRx.size)
                    check(NexusExternalLinkProtocol.validateSequence(previousRxSequence, frame.sequence)) {
                        "Séquence NXL1 invalide"
                    }
                    previousRxSequence = frame.sequence
                    return frame
                }
                val chunk = ByteArray(16 * 1024)
                val read = connection.bulkTransfer(bulkIn, chunk, 0, chunk.size, timeoutMs)
                check(read > 0) { "Échec de lecture USB NXL1" }
                check(pendingRx.size + read <= MAX_BUFFER) { "Tampon NXL1 saturé" }
                pendingRx += chunk.copyOf(read)
            }
        }

        private fun tryDecode(buffer: ByteArray, length: Int): NexusExternalLinkProtocol.Frame? {
            if (length < HEADER_SIZE) return null
            val declaredPayload = readInt32BE(buffer, 14)
            if (declaredPayload < 0 || declaredPayload > NexusExternalLinkProtocol.MAX_PAYLOAD) {
                error("Taille NXL1 invalide")
            }
            val total = HEADER_SIZE + declaredPayload + TRAILER_SIZE
            if (length < total) return null
            return NexusExternalLinkProtocol.decode(buffer.copyOf(total))
        }

        private fun NexusExternalLinkProtocol.Frame.encodedSize(): Int = HEADER_SIZE + payload.size + TRAILER_SIZE

        override fun close() {
            if (!closed) {
                closed = true
                runCatching { connection.releaseInterface(usbInterface) }
                connection.close()
            }
        }
    }

    private data class BulkPair(
        val iface: UsbInterface,
        val bulkIn: UsbEndpoint,
        val bulkOut: UsbEndpoint
    )

    private fun findBulkPair(device: UsbDevice): BulkPair? {
        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)
            var input: UsbEndpoint? = null
            var output: UsbEndpoint? = null
            for (j in 0 until iface.endpointCount) {
                val endpoint = iface.getEndpoint(j)
                if (endpoint.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (endpoint.direction == UsbConstants.USB_DIR_IN && input == null) input = endpoint
                if (endpoint.direction == UsbConstants.USB_DIR_OUT && output == null) output = endpoint
            }
            if (input != null && output != null) {
                return BulkPair(iface, input, output)
            }
        }
        return null
    }

    companion object {
        // NXL1: 4 magic + 1 version + 1 flags + 8 sequence + 4 length + CRC32.
        private const val HEADER_SIZE = 18
        private const val TRAILER_SIZE = 4
        private const val MAX_BUFFER = NexusExternalLinkProtocol.MAX_PAYLOAD + HEADER_SIZE + TRAILER_SIZE

        private fun readInt32BE(bytes: ByteArray, offset: Int): Int =
            ((bytes[offset].toInt() and 0xff) shl 24) or
                ((bytes[offset + 1].toInt() and 0xff) shl 16) or
                ((bytes[offset + 2].toInt() and 0xff) shl 8) or
                (bytes[offset + 3].toInt() and 0xff)
    }
}
