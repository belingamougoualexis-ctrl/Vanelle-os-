package com.nexus.network

data class NetworkSnapshot(
    val connected: Boolean,
    val validated: Boolean,
    val transport: String,
    val interfaceName: String,
    val ipv4: String,
    val ipv6: String,
    val linkSpeedMbps: Int?,
    val dnsServers: List<String>
)
