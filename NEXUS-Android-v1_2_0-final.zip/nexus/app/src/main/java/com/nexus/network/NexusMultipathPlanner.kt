package com.nexus.network

/** Pure scheduling policy used when several real IP backhauls exist. */
object NexusMultipathPlanner {
    data class Path(
        val id: String,
        val downstreamKbps: Int,
        val upstreamKbps: Int,
        val latencyMs: Double? = null,
        val lossPct: Double? = null,
        val metered: Boolean,
        val available: Boolean
    )

    data class Allocation(val id: String, val weight: Double)

    fun allocate(paths: Collection<Path>): List<Allocation> {
        val usable = paths.filter {
            it.available &&
                it.downstreamKbps > 0 &&
                it.upstreamKbps > 0 &&
                (it.lossPct == null || it.lossPct < 80.0)
        }
        if (usable.isEmpty()) return emptyList()
        val scores = usable.associateWith { p ->
            val capacity = minOf(p.downstreamKbps, p.upstreamKbps).toDouble().coerceAtLeast(1.0)
            val latencyFactor = p.latencyMs?.let { 1.0 / (1.0 + it.coerceAtLeast(1.0) / 100.0) } ?: 1.0
            val lossFactor = p.lossPct?.let { (1.0 - it.coerceIn(0.0, 100.0) / 100.0).coerceAtLeast(0.05) } ?: 1.0
            val costFactor = if (p.metered) 0.75 else 1.0
            capacity * latencyFactor * lossFactor * costFactor
        }
        val total = scores.values.sum()
        if (total <= 0.0) return emptyList()
        return scores.entries
            .map { Allocation(it.key.id, it.value / total) }
            .sortedByDescending { it.weight }
    }

    fun choosePrimary(paths: Collection<Path>): String? = allocate(paths).firstOrNull()?.id
}
