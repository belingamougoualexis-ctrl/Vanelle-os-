package com.nexus.network

import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket

object DatagramRelayProtocol {
    private const val MAX_FRAME = 65_535

    data class Request(
        val from: String,
        val ttl: Int,
        val visited: List<String>,
        val host: String,
        val port: Int,
        val nonce: String,
        val mac: String,
        val endToEnd: Boolean = false
    )

    class Session(
        private val socket: Socket,
        networkKey: String,
        sessionNonce: String
    ) : AutoCloseable {
        private val input = DataInputStream(socket.getInputStream().buffered())
        private val output = DataOutputStream(socket.getOutputStream().buffered())
        private val key = NexusSecureFraming.deriveKey(networkKey, sessionNonce)
        private val lock = Any()
        private var sendSequence = 0L
        private var receiveSequence = 0L

        fun send(payload: ByteArray) {
            require(payload.size <= MAX_FRAME)
            synchronized(lock) {
                val frame = NexusSecureFraming.encryptFrame(key, sendSequence, payload)
                sendSequence++
                output.writeInt(frame.size)
                output.write(frame)
                output.flush()
            }
        }

        fun receive(): ByteArray? {
            val length = runCatching { input.readInt() }.getOrNull() ?: return null
            if (length == -1) return null
            require(length in 28..(MAX_FRAME + 28)) { "Frame DGRAM chiffrée invalide: $length" }
            val frame = ByteArray(length)
            input.readFully(frame)
            val decoded = NexusSecureFraming.decryptFrame(key, frame)
            require(decoded.sequence == receiveSequence) { "Séquence DGRAM invalide" }
            receiveSequence++
            return decoded.plaintext
        }

        override fun close() {
            synchronized(lock) {
                runCatching { output.writeInt(-1); output.flush() }
                runCatching { socket.close() }
            }
        }
    }


    fun openRelay(
        host: String,
        port: Int,
        targetHost: String,
        targetPort: Int,
        secret: String,
        fromNode: String,
        visited: List<String>,
        ttl: Int,
        timeoutMs: Int = 8_000,
        endToEnd: Boolean = false
    ): Session {
        require(ttl in 1..NexusConfig.MAX_HOPS)
        require(targetPort in 1..65_535)
        val nonce = NexusCrypto.nonce(24)
        val fields = linkedMapOf(
            "from" to NexusCrypto.encode(fromNode),
            "ttl" to ttl.toString(),
            "visited" to NexusCrypto.encode(visited.joinToString(",")),
            "host" to NexusCrypto.encode(targetHost),
            "port" to targetPort.toString(),
            "nonce" to nonce,
            "e2e" to if (endToEnd) "1" else "0"
        )
        val mac = NexusCrypto.hmacHex(secret, fields.entries.sortedBy { it.key }.joinToString("&") { "${it.key}=${it.value}" })
        val socket = Socket()
        socket.connect(InetSocketAddress(host, port), timeoutMs)
        socket.soTimeout = 20_000
        socket.getOutputStream().bufferedWriter(Charsets.US_ASCII).apply {
            write("${RelayProtocol.VERSION} DGRAM v=2 ${fields.entries.joinToString(" ") { "${it.key}=${it.value}" }} mac=$mac\n")
            flush()
        }
        val response = RelayProtocol.readAsciiLine(socket.getInputStream(), 256)
        if (response != "${RelayProtocol.VERSION} DGRAM-OK v=2") {
            socket.close()
            error(response.ifBlank { "Relais UDP refusé" })
        }
        socket.soTimeout = 0
        return Session(socket, secret, nonce)
    }

    internal fun acceptedSession(socket: Socket, request: Request, secret: String): Session =
        Session(socket, secret, request.nonce)

    fun parse(line: String): Request? {
        if (!line.startsWith("${RelayProtocol.VERSION} DGRAM ")) return null
        val fields = line.removePrefix("${RelayProtocol.VERSION} DGRAM ").trim().split(' ').filter { it.isNotEmpty() }
            .associate { token ->
                val i = token.indexOf('=')
                (if (i > 0) token.substring(0, i) else token) to (if (i > 0) token.substring(i + 1) else "")
            }
        val from = fields["from"] ?: return null
        val ttl = fields["ttl"]?.toIntOrNull() ?: return null
        val visited = fields["visited"] ?: return null
        val host = fields["host"] ?: return null
        val port = fields["port"]?.toIntOrNull() ?: return null
        val nonce = fields["nonce"] ?: return null
        val mac = fields["mac"] ?: return null
        return runCatching {
            Request(
                NexusCrypto.decode(from), ttl,
                NexusCrypto.decode(visited).split(',').filter { it.isNotBlank() },
                NexusCrypto.decode(host), port, nonce, mac, fields["e2e"] == "1"
            )
        }.getOrNull()
    }

    fun authenticate(request: Request, secret: String): Boolean {
        val fields = linkedMapOf(
            "from" to NexusCrypto.encode(request.from),
            "ttl" to request.ttl.toString(),
            "visited" to NexusCrypto.encode(request.visited.joinToString(",")),
            "host" to NexusCrypto.encode(request.host),
            "port" to request.port.toString(),
            "nonce" to request.nonce,
            "e2e" to if (request.endToEnd) "1" else "0"
        )
        val canonical = fields.entries.sortedBy { it.key }.joinToString("&") { "${it.key}=${it.value}" }
        return NexusCrypto.constantTimeEquals(NexusCrypto.hmacHex(secret, canonical), request.mac)
    }
}
