package com.nexus.network

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors

class RelayServer(
    private val port: Int,
    private val nodeIdProvider: () -> String,
    private val secretProvider: () -> List<String>,
    private val directInternetAvailable: () -> Boolean,
    private val nextHopSelector: (Set<String>) -> MeshRouter.NextHop?,
    private val nextHopCandidatesSelector: ((Set<String>) -> List<MeshRouter.NextHop>)? = null,
    private val onRouteFailure: (String) -> Unit = {},
    private val onRouteSuccess: (String) -> Unit = {},
    private val protectSocket: (Socket) -> Boolean = { true },
    private val protectDatagram: (DatagramSocket) -> Boolean = { true },
    private val context: android.content.Context? = null,
    private val qosController: NexusQosController? = null,
    private val transportManager: NexusTransportManager? = context?.let { NexusTransportManager(it) }
) {
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "nexus-relay-${System.nanoTime()}").apply { isDaemon = true } }
    private val seenNonces = ConcurrentHashMap<String, Long>()
    @Volatile private var running = false
    private var server: ServerSocket? = null
    private val bandwidthPolicy = context?.let { NexusBandwidthPolicy.forContext(it) }

    fun start() {
        if (running) return
        running = true
        pool.execute {
            runCatching {
                ServerSocket().use { s ->
                    s.reuseAddress = true
                    s.bind(InetSocketAddress("0.0.0.0", port))
                    server = s
                    while (running) {
                        val client = s.accept()
                        pool.execute { handle(client) }
                    }
                }
            }
        }
    }

    fun stop() {
        running = false
        runCatching { server?.close() }
        server = null
        pool.shutdownNow()
        seenNonces.clear()
    }

    private fun handle(client: Socket) {
        client.use { c ->
            c.soTimeout = 15_000
            val line = runCatching { RelayProtocol.readAsciiLine(c.getInputStream()) }.getOrNull() ?: return
            when {
                line.startsWith("${RelayProtocol.VERSION} RELAY ") -> handleTcp(c, line)
                line.startsWith("${RelayProtocol.VERSION} DGRAM ") -> handleDatagram(c, line)
            }
        }
    }

    private fun handleTcp(client: Socket, line: String) {
        val request = runCatching { RelayProtocol.parse(line) }.getOrNull() ?: return
        val key = secretProvider().firstOrNull { RelayProtocol.authenticate(request, it) } ?: return
        if (!validRequest(request)) return

        val visited = (request.visited + nodeIdProvider()).toSet()
        val upstream = try {
            if (directInternetAvailable()) {
                val socket = if (transportManager != null) {
                    transportManager.openTcpWithFailover(request.host, request.port, 10_000).first
                } else {
                    Socket().apply {
                        if (!protectSocket(this)) error("Socket TCP non protégé")
                        connect(InetSocketAddress(request.host, request.port), 10_000)
                        soTimeout = 0
                    }
                }
                if (!protectSocket(socket)) {
                    runCatching { socket.close() }
                    error("Socket TCP non protégé")
                }
                SocketStreamChannel(socket)
            } else {
                val candidates = nextHopCandidatesSelector?.invoke(visited).orEmpty().ifEmpty {
                    listOfNotNull(nextHopSelector(visited))
                }
                var opened: NexusStreamChannel? = null
                for (next in candidates) {
                    val candidate = runCatching {
                        RelayProtocol.openRelay(
                            host = next.host,
                            port = next.port,
                            targetHost = request.host,
                            targetPort = request.port,
                            secret = key,
                            fromNode = nodeIdProvider(),
                            visited = visited.toList(),
                            ttl = request.ttl - 1,
                            timeoutMs = 8_000
                        )
                    }.getOrNull()
                    if (candidate != null) { onRouteSuccess(next.nodeId); opened = candidate; break }
                    onRouteFailure(next.nodeId)
                }
                opened ?: return
            }
        } catch (_: Exception) {
            return
        }

        upstream.use { up ->
            client.getOutputStream().apply {
                write("${RelayProtocol.VERSION} RELAY-OK v=2\n".toByteArray(Charsets.US_ASCII))
                flush()
            }
            val inbound = RelayProtocol.acceptedChannel(client, request, key)
            if (request.endToEnd && directInternetAvailable()) {
                val e2eContext = context ?: return@use
                val secureInbound = runCatching { NexusE2E.server(e2eContext, inbound) }.getOrNull() ?: return@use
                tunnel(secureInbound, up, request.from, request.port)
            } else {
                tunnel(inbound, up, request.from, request.port)
            }
        }
    }

    private fun handleDatagram(client: Socket, line: String) {
        val request = runCatching { DatagramRelayProtocol.parse(line) }.getOrNull() ?: return
        val key = secretProvider().firstOrNull { DatagramRelayProtocol.authenticate(request, it) } ?: return
        if (!validRequest(request)) return
        val visited = (request.visited + nodeIdProvider()).toSet()
        if (directInternetAvailable()) {
            handleDatagramGateway(client, request, key)
        } else {
            val candidates = nextHopCandidatesSelector?.invoke(visited).orEmpty().ifEmpty {
                listOfNotNull(nextHopSelector(visited))
            }
            var upstream: DatagramRelayProtocol.Session? = null
            for (next in candidates) {
                val candidate = runCatching {
                    DatagramRelayProtocol.openRelay(
                        host = next.host,
                        port = next.port,
                        targetHost = request.host,
                        targetPort = request.port,
                        secret = key,
                        fromNode = nodeIdProvider(),
                        visited = visited.toList(),
                        ttl = request.ttl - 1,
                        timeoutMs = 8_000,
                        endToEnd = request.endToEnd
                    )
                }.getOrNull()
                if (candidate != null) { onRouteSuccess(next.nodeId); upstream = candidate; break }
                onRouteFailure(next.nodeId)
            }
            val selected = upstream ?: return
            selected.use {
                client.getOutputStream().bufferedWriter(Charsets.US_ASCII).apply {
                    write("${RelayProtocol.VERSION} DGRAM-OK v=2\n")
                    flush()
                }
                val incoming = DatagramRelayProtocol.acceptedSession(client, request, key)
                tunnelDatagrams(incoming, it, request.port)
            }
        }
    }

    private fun handleDatagramGateway(client: Socket, request: DatagramRelayProtocol.Request, key: String) {
        val socket = runCatching {
            val chosen = transportManager?.openUdpWithFailover()?.first ?: DatagramSocket()
            if (!protectDatagram(chosen)) error("Socket UDP non protégé")
            chosen.connect(InetSocketAddress(request.host, request.port))
            chosen
        }.getOrNull() ?: return
        socket.use { udp ->
            client.getOutputStream().bufferedWriter(Charsets.US_ASCII).apply {
                write("${RelayProtocol.VERSION} DGRAM-OK v=2\n")
                flush()
            }
            val incoming = DatagramRelayProtocol.acceptedSession(client, request, key)
            val secureIncoming = if (request.endToEnd) {
                val ctx = context ?: return@use
                runCatching { NexusE2EDatagram.server(ctx, incoming) }.getOrNull() ?: return@use
            } else null
            val done = CountDownLatch(2)
            val policy = bandwidthPolicy
            pool.execute {
                try {
                    while (running) {
                        val payload = (secureIncoming?.receive() ?: incoming.receive()) ?: break
                        if (policy != null && !policy.allow(payload.size, request.from)) break
                        if (qosController != null && !qosController.allow(request.from, payload.size, qosController.classify(request.port))) break
                        udp.send(DatagramPacket(payload, payload.size))
                        context?.let { NexusCredits.relay(it, request.from, payload.size.toLong()) }
                    }
                } catch (_: Exception) {
                } finally { done.countDown() }
            }
            pool.execute {
                try {
                    val buffer = ByteArray(65_535)
                    while (running) {
                        val packet = DatagramPacket(buffer, buffer.size)
                        udp.receive(packet)
                        if (policy != null && !policy.allow(packet.length, request.from)) break
                        if (qosController != null && !qosController.allow(request.from, packet.length, qosController.classify(request.port))) break
                        if (secureIncoming != null) secureIncoming.send(packet.data.copyOf(packet.length)) else incoming.send(packet.data.copyOf(packet.length))
                        context?.let { NexusCredits.relay(it, request.from, packet.length.toLong()) }
                    }
                } catch (_: Exception) {
                } finally { done.countDown() }
            }
            runCatching { done.await() }
        }
    }

    private fun tunnelDatagrams(client: DatagramRelayProtocol.Session, upstream: DatagramRelayProtocol.Session, port: Int = 0) {
        val done = CountDownLatch(2)
        pool.execute {
            try {
                while (running) {
                    val payload = client.receive() ?: break
                    if (context != null && !NexusBandwidthPolicy.forContext(context).allow(payload.size, "remote")) break
                    if (qosController != null && !qosController.allow("remote", payload.size, qosController.classify(port))) break
                    upstream.send(payload)
                    context?.let { NexusCredits.relay(it, "remote", payload.size.toLong()) }
                }
            } catch (_: Exception) {
            } finally { done.countDown() }
        }
        pool.execute {
            try {
                while (running) {
                    val payload = upstream.receive() ?: break
                    if (context != null && !NexusBandwidthPolicy.forContext(context).allow(payload.size, "remote")) break
                    if (qosController != null && !qosController.allow("remote", payload.size, qosController.classify(port))) break
                    client.send(payload)
                    context?.let { NexusCredits.relay(it, "remote", payload.size.toLong()) }
                }
            } catch (_: Exception) {
            } finally { done.countDown() }
        }
        runCatching { done.await() }
    }

    private fun tunnel(a: NexusStreamChannel, b: NexusStreamChannel, peerId: String, port: Int) {
        val done = CountDownLatch(2)
        val qosClass = qosController?.classify(port) ?: NexusQosController.Class.BULK
        pipe(a, b, done, peerId, qosClass)
        pipe(b, a, done, peerId, qosClass)
        runCatching { done.await() }
    }

    private fun pipe(from: NexusStreamChannel, to: NexusStreamChannel, done: CountDownLatch, peerId: String, qosClass: NexusQosController.Class) {
        val policy = bandwidthPolicy
        pool.execute {
            try {
                val input = BufferedInputStream(from.input)
                val output = BufferedOutputStream(to.output)
                val buffer = ByteArray(16 * 1024)
                while (running) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    if (n == 0) continue
                    if (policy != null && !policy.allow(n, peerId)) break
                    if (qosController != null && !qosController.allow(peerId, n, qosClass)) break
                    output.write(buffer, 0, n)
                    output.flush()
                    context?.let { NexusCredits.relay(it, peerId, n.toLong()) }
                }
            } catch (_: Exception) {
            } finally {
                runCatching { to.shutdownOutput() }
                done.countDown()
            }
        }
    }

    private fun validRequest(request: RelayProtocol.Request): Boolean {
        return request.ttl in 1..NexusConfig.MAX_HOPS &&
            request.port in 1..65_535 &&
            request.from.isNotBlank() &&
            request.visited.isNotEmpty() &&
            request.visited.distinct().size == request.visited.size &&
            request.visited.size <= NexusConfig.MAX_HOPS &&
            !request.visited.contains(nodeIdProvider()) &&
            acceptNonce(request.nonce)
    }

    private fun validRequest(request: DatagramRelayProtocol.Request): Boolean {
        return request.ttl in 1..NexusConfig.MAX_HOPS &&
            request.port in 1..65_535 &&
            request.from.isNotBlank() &&
            request.visited.isNotEmpty() &&
            request.visited.distinct().size == request.visited.size &&
            request.visited.size <= NexusConfig.MAX_HOPS &&
            !request.visited.contains(nodeIdProvider()) &&
            acceptNonce(request.nonce)
    }

    private fun acceptNonce(nonce: String): Boolean {
        val now = System.currentTimeMillis()
        seenNonces.entries.removeIf { now - it.value > 120_000 }
        return nonce.length in 16..128 && seenNonces.putIfAbsent(nonce, now) == null
    }
}
