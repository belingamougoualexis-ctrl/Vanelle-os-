package com.nexus.network

import java.net.Inet6Address

/** ICMPv6 codec for diagnostics, errors and IPv6 control protocols. */
object Icmpv6 {
    const val DEST_UNREACHABLE = 1
    const val PACKET_TOO_BIG = 2
    const val TIME_EXCEEDED = 3
    const val PARAMETER_PROBLEM = 4
    const val ECHO_REQUEST = 128
    const val ECHO_REPLY = 129
    const val ROUTER_SOLICITATION = 133
    const val ROUTER_ADVERTISEMENT = 134
    const val NEIGHBOR_SOLICITATION = 135
    const val NEIGHBOR_ADVERTISEMENT = 136
    const val REDIRECT = 137
    const val MLD_QUERY = 130
    const val MLD_REPORT_V1 = 131
    const val MLD_DONE = 132
    const val MLD_REPORT_V2 = 143

    data class Message(val type: Int, val code: Int, val checksum: Int, val body: ByteArray)

    fun parse(raw: ByteArray, src: Inet6Address, dst: Inet6Address): Message? {
        if (raw.size < 4) return null
        val checksum = IpPacket.u16(raw, 2)
        if (checksumPseudo(src, dst, raw) != 0) return null
        return Message(IpPacket.u8(raw[0]), IpPacket.u8(raw[1]), checksum, raw.copyOfRange(4, raw.size))
    }

    fun echoReply(request: Message): ByteArray {
        require(request.type == ECHO_REQUEST && request.body.size >= 4)
        return build( ECHO_REPLY, 0, request.body)
    }

    fun build(type: Int, code: Int, body: ByteArray): ByteArray {
        val out = ByteArray(4 + body.size)
        out[0] = type.toByte(); out[1] = code.toByte()
        if (body.isNotEmpty()) System.arraycopy(body, 0, out, 4, body.size)
        return out
    }

    fun error(type: Int, code: Int, value: Int, invokingPacket: ByteArray): ByteArray {
        val body = ByteArray(4 + minOf(invokingPacket.size, 1232))
        IpPacket.putU32(body, 0, value.toLong())
        System.arraycopy(invokingPacket, 0, body, 4, body.size - 4)
        return build(type, code, body)
    }

    fun finalize(src: Inet6Address, dst: Inet6Address, message: ByteArray): ByteArray {
        val out = message.copyOf()
        IpPacket.putU16(out, 2, 0)
        IpPacket.putU16(out, 2, checksumPseudo(src, dst, out))
        return out
    }

    fun checksumPseudo(src: Inet6Address, dst: Inet6Address, payload: ByteArray): Int {
        var sum = 0L
        fun add(a: ByteArray) {
            var i = 0
            while (i + 1 < a.size) {
                sum += ((a[i].toInt() and 0xff) shl 8) or (a[i + 1].toInt() and 0xff)
                i += 2
            }
            if (i < a.size) sum += (a[i].toInt() and 0xff) shl 8
        }
        add(src.address); add(dst.address)
        sum += ((payload.size ushr 16) and 0xffff).toLong()
        sum += (payload.size and 0xffff).toLong()
        sum += 58L
        add(payload)
        while ((sum ushr 16) != 0L) sum = (sum and 0xffffL) + (sum ushr 16)
        return sum.toInt().inv() and 0xffff
    }
}
