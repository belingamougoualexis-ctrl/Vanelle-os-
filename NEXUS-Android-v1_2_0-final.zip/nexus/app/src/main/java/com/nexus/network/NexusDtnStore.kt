package com.nexus.network

import android.content.Context
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicLong

/** Disk-backed store-and-forward bundle queue with explicit hop history and expiry. */
class NexusDtnStore(private val context: Context) {
    data class Bundle(
        val id: String,
        val origin: String,
        val destination: String,
        val payloadFile: File,
        val createdAt: Long,
        val expiresAt: Long,
        val attempts: Int,
        val priority: Int,
        val visited: List<String>
    )

    private val root = File(context.filesDir, "nexus-dtn").apply { mkdirs() }
    private val sequence = AtomicLong(0)

    @Synchronized
    fun enqueue(
        destination: String,
        payload: ByteArray,
        ttlMs: Long = 24 * 60 * 60 * 1000L,
        priority: Int = 5,
        origin: String = NexusIdentity.nodeId(context),
        visited: List<String> = listOf(NexusIdentity.nodeId(context)),
        id: String? = null
    ): String {
        require(destination.isNotBlank())
        require(payload.size <= NexusConfig.DTN_BUNDLE_MAX_BYTES)
        val now = System.currentTimeMillis()
        val cleanVisited = visited.filter { it.isNotBlank() }.distinct().take(NexusConfig.MAX_HOPS)
        val safeId = id?.takeIf { it.matches(Regex("[A-Za-z0-9._:-]{8,96}")) }
            ?: sha256(payload + origin.toByteArray() + destination.toByteArray() + now.toString().toByteArray() + sequence.incrementAndGet().toString().toByteArray()).take(40)
        val bin = File(root, "$safeId.bin")
        val meta = File(root, "$safeId.meta")
        if (!bin.exists()) bin.writeBytes(payload)
        writeMeta(meta, mapOf(
            "id" to safeId, "origin" to origin, "destination" to destination,
            "createdAt" to now.toString(), "expiresAt" to (now + ttlMs.coerceIn(1_000L, 7L * 24 * 60 * 60 * 1000)).toString(),
            "attempts" to "0", "priority" to priority.coerceIn(0, 10).toString(), "sha256" to sha256(payload),
            "visited" to cleanVisited.joinToString(",")
        ))
        return safeId
    }

    fun pending(limit: Int = 64): List<Bundle> = root.listFiles().orEmpty()
        .filter { it.extension == "meta" }
        .mapNotNull { read(it) }
        .filter { it.expiresAt > System.currentTimeMillis() && it.payloadFile.isFile && it.attempts < 16 }
        .sortedWith(compareByDescending<Bundle> { it.priority }.thenBy { it.createdAt })
        .take(limit.coerceIn(1, 256))

    @Synchronized
    fun ack(id: String) {
        runCatching { File(root, "$id.bin").delete(); File(root, "$id.meta").delete() }
    }

    @Synchronized
    fun defer(id: String, nextVisited: List<String>? = null) {
        val file = File(root, "$id.meta")
        val b = read(file) ?: return
        val visited = (nextVisited ?: b.visited).filter { it.isNotBlank() }.distinct().take(NexusConfig.MAX_HOPS)
        writeMeta(file, mapOf(
            "id" to b.id, "origin" to b.origin, "destination" to b.destination,
            "createdAt" to b.createdAt.toString(), "expiresAt" to b.expiresAt.toString(),
            "attempts" to (b.attempts + 1).toString(), "priority" to b.priority.toString(),
            "sha256" to sha256(b.payloadFile.readBytes()), "visited" to visited.joinToString(",")
        ))
    }

    fun cleanup() {
        val now = System.currentTimeMillis()
        root.listFiles().orEmpty().filter { it.extension == "meta" }.forEach { meta ->
            val b = read(meta)
            if (b == null || b.expiresAt <= now || b.attempts >= 16) ack(meta.nameWithoutExtension)
        }
    }

    private fun read(file: File): Bundle? = runCatching {
        val fields = file.readLines(Charsets.UTF_8).mapNotNull { line ->
            val i = line.indexOf('=')
            if (i > 0) line.substring(0, i) to NexusCrypto.decode(line.substring(i + 1)) else null
        }.toMap()
        val id = fields["id"] ?: return@runCatching null
        val payload = File(root, "$id.bin")
        if (!payload.isFile || fields["sha256"] != sha256(payload.readBytes())) return@runCatching null
        Bundle(
            id = id,
            origin = fields["origin"].orEmpty(),
            destination = fields["destination"].orEmpty(),
            payloadFile = payload,
            createdAt = fields["createdAt"]?.toLongOrNull() ?: 0L,
            expiresAt = fields["expiresAt"]?.toLongOrNull() ?: 0L,
            attempts = fields["attempts"]?.toIntOrNull() ?: 0,
            priority = fields["priority"]?.toIntOrNull()?.coerceIn(0, 10) ?: 5,
            visited = fields["visited"].orEmpty().split(',').filter { it.isNotBlank() }.distinct()
        )
    }.getOrNull()?.takeIf { it.destination.isNotBlank() }

    private fun writeMeta(file: File, fields: Map<String, String>) {
        file.writeText(fields.entries.joinToString("\n") { (k, v) -> "$k=${NexusCrypto.encode(v)}" }, Charsets.UTF_8)
    }

    private fun sha256(data: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(data).joinToString("") { "%02x".format(it.toInt() and 0xff) }
}
