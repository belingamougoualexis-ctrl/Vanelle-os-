package com.nexus.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import java.net.Inet4Address
import java.net.Inet6Address

object NetworkInspector {
    fun snapshot(context: Context): NetworkSnapshot {
        val cm = context.getSystemService(ConnectivityManager::class.java)
        val network = cm.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        val props: LinkProperties? = network?.let { cm.getLinkProperties(it) }

        val transports = mutableListOf<String>()
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) transports += "Wi‑Fi"
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) transports += "Mobile"
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true) transports += "Ethernet"
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) == true) transports += "Bluetooth"
        if (transports.isEmpty()) transports += "Inconnu"

        val address = props?.linkAddresses
            ?.firstOrNull { it.address is Inet4Address && !it.address.isLoopbackAddress }
            ?.address
            ?.hostAddress
            ?: "—"

        val ipv6 = props?.linkAddresses
            ?.firstOrNull { it.address is Inet6Address && !it.address.isLoopbackAddress && !it.address.isLinkLocalAddress }
            ?.address
            ?.hostAddress
            ?: "—"
        val iface = props?.interfaceName ?: "—"
        val speed = caps?.linkDownstreamBandwidthKbps?.takeIf { it > 0 }?.div(1000)
        return NetworkSnapshot(
            connected = network != null,
            validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true,
            transport = transports.joinToString(" + "),
            interfaceName = iface,
            ipv4 = address,
            ipv6 = ipv6,
            linkSpeedMbps = speed,
            dnsServers = props?.dnsServers?.mapNotNull { it.hostAddress } ?: emptyList()
        )
    }
}
