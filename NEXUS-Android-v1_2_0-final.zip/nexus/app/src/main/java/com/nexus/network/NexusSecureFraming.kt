package com.nexus.network

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Authenticated encrypted framing for NEXUS relay links.
 * Each direction has a monotonically increasing frame sequence number,
 * authenticated as AES-GCM AAD, so duplicate/reordered frames are rejected.
 * Encryption remains hop-by-hop; the payload itself is not hidden from a relay
 * that legitimately terminates that relay hop.
 */
object NexusSecureFraming {
    private const val SEQUENCE_BYTES = 8
    private const val IV_BYTES = 12
    private const val TAG_BITS = 128
    private const val MAX_FRAME = 65_535
    private val random = SecureRandom()

    data class DecodedFrame(val sequence: Long, val plaintext: ByteArray)

    fun deriveKey(networkKey: String, sessionNonce: String, role: String = "link-v1"): SecretKeySpec {
        val material = "$role|$sessionNonce|$networkKey".toByteArray(Charsets.UTF_8)
        val digest = MessageDigest.getInstance("SHA-256").digest(material)
        return SecretKeySpec(digest, "AES")
    }

    /** Compatibility helper for unit tests/one-off encrypted values. */
    fun encrypt(key: SecretKeySpec, plaintext: ByteArray): ByteArray =
        encryptFrame(key, 0L, plaintext)

    /** Compatibility helper; only accepts sequence zero. */
    fun decrypt(key: SecretKeySpec, frame: ByteArray): ByteArray {
        val decoded = decryptFrame(key, frame)
        require(decoded.sequence == 0L) { "Séquence inattendue" }
        return decoded.plaintext
    }

    fun encryptFrame(key: SecretKeySpec, sequence: Long, plaintext: ByteArray): ByteArray {
        require(sequence >= 0)
        require(plaintext.size <= MAX_FRAME)
        val iv = ByteArray(IV_BYTES).also(random::nextBytes)
        val aad = sequence.toAad()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(TAG_BITS, iv))
        cipher.updateAAD(aad)
        val ciphertext = cipher.doFinal(plaintext)
        return ByteArray(SEQUENCE_BYTES + iv.size + ciphertext.size).also {
            writeLong(it, 0, sequence)
            System.arraycopy(iv, 0, it, SEQUENCE_BYTES, iv.size)
            System.arraycopy(ciphertext, 0, it, SEQUENCE_BYTES + iv.size, ciphertext.size)
        }
    }

    fun decryptFrame(key: SecretKeySpec, frame: ByteArray): DecodedFrame {
        require(frame.size >= SEQUENCE_BYTES + IV_BYTES + 16)
        val sequence = readLong(frame, 0)
        require(sequence >= 0)
        val ivOffset = SEQUENCE_BYTES
        val iv = frame.copyOfRange(ivOffset, ivOffset + IV_BYTES)
        val ciphertext = frame.copyOfRange(ivOffset + IV_BYTES, frame.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_BITS, iv))
        cipher.updateAAD(sequence.toAad())
        return DecodedFrame(sequence, cipher.doFinal(ciphertext))
    }

    private fun Long.toAad(): ByteArray = ByteArray(SEQUENCE_BYTES).also { writeLong(it, 0, this) }

    private fun writeLong(buffer: ByteArray, offset: Int, value: Long) {
        for (i in 0 until 8) buffer[offset + i] = (value ushr (56 - i * 8)).toByte()
    }

    private fun readLong(buffer: ByteArray, offset: Int): Long {
        var result = 0L
        for (i in 0 until 8) result = (result shl 8) or (buffer[offset + i].toLong() and 0xffL)
        return result
    }
}

class NexusSecureInputStream(
    input: InputStream,
    private val key: SecretKeySpec
) : InputStream() {
    private val data = DataInputStream(input)
    private var current = ByteArray(0)
    private var offset = 0
    private var eof = false
    private var expectedSequence = 0L

    override fun read(): Int {
        val one = ByteArray(1)
        return if (read(one, 0, 1) == 1) one[0].toInt() and 0xff else -1
    }

    override fun read(buffer: ByteArray, off: Int, len: Int): Int {
        require(off >= 0 && len >= 0 && off + len <= buffer.size)
        if (len == 0) return 0
        if (eof) return -1
        if (offset >= current.size) {
            if (!loadFrame()) return -1
        }
        val count = minOf(len, current.size - offset)
        System.arraycopy(current, offset, buffer, off, count)
        offset += count
        return count
    }

    private fun loadFrame(): Boolean {
        val frameLength = try {
            data.readInt()
        } catch (_: EOFException) {
            eof = true
            return false
        }
        if (frameLength == 0) {
            eof = true
            return false
        }
        require(frameLength in 36..(65_535 + 36)) { "Frame chiffrée invalide: $frameLength" }
        val frame = ByteArray(frameLength)
        data.readFully(frame)
        val decoded = NexusSecureFraming.decryptFrame(key, frame)
        require(decoded.sequence == expectedSequence) { "Séquence de trame invalide" }
        expectedSequence++
        current = decoded.plaintext
        offset = 0
        return true
    }
}

class NexusSecureOutputStream(
    output: OutputStream,
    private val key: SecretKeySpec
) : OutputStream() {
    private val data = DataOutputStream(output)
    private val lock = Any()
    private var closed = false
    private var nextSequence = 0L

    override fun write(value: Int) = write(byteArrayOf(value.toByte()), 0, 1)

    override fun write(buffer: ByteArray, off: Int, len: Int) {
        require(off >= 0 && len >= 0 && off + len <= buffer.size)
        check(!closed) { "Flux sécurisé fermé" }
        if (len == 0) return
        val plaintext = buffer.copyOfRange(off, off + len)
        val frame = NexusSecureFraming.encryptFrame(key, nextSequence, plaintext)
        nextSequence++
        synchronized(lock) {
            data.writeInt(frame.size)
            data.write(frame)
            data.flush()
        }
    }

    fun shutdownOutput() {
        if (closed) return
        synchronized(lock) {
            data.writeInt(0)
            data.flush()
            closed = true
        }
    }

    override fun flush() { synchronized(lock) { data.flush() } }
    override fun close() = shutdownOutput()
}
