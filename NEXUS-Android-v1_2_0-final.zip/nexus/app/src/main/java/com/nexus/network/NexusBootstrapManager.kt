package com.nexus.network

import android.content.Context

/** Remote bootstrap is optional and explicit; it provides the first routable IP peers beyond local discovery. */
class NexusBootstrapManager(private val context: Context, private val discovery: NsdController) {
    fun refresh() {
        NexusSettings.bootstrapPeers(context).forEach { entry ->
            parse(entry)?.let { (host, port) -> discovery.addRemotePeer(host, port) }
        }
    }

    private fun parse(value: String): Pair<String, Int>? = NexusInterop.parse(value)?.let { it.host to it.port }
}
