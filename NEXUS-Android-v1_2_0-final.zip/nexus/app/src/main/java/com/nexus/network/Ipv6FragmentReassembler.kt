package com.nexus.network

import java.net.InetAddress
import java.util.TreeMap

/** Bounded IPv6 fragment reassembly with overlap rejection and timeout. */
class Ipv6FragmentReassembler(
    private val maxBytes: Int = 1_048_576,
    private val timeoutMs: Long = 30_000L
) {
    data class Key(val src: String, val dst: String, val id: Long, val nextHeader: Int)
    private data class Entry(
        val createdAt: Long,
        val fragments: TreeMap<Int, ByteArray> = TreeMap(),
        var totalLength: Int? = null
    )

    private val entries = HashMap<Key, Entry>()

    @Synchronized
    fun offer(key: Key, offsetBytes: Int, more: Boolean, payload: ByteArray): ByteArray? {
        purge()
        if (offsetBytes < 0 || offsetBytes % 8 != 0 || payload.size > maxBytes) return null
        val entry = entries.getOrPut(key) { Entry(System.currentTimeMillis()) }
        if (entry.fragments.values.sumOf { it.size } + payload.size > maxBytes) {
            entries.remove(key)
            return null
        }
        val end = offsetBytes + payload.size
        if (!more) {
            if (end > maxBytes) { entries.remove(key); return null }
            entry.totalLength = end
        }
        val floor = entry.fragments.floorEntry(offsetBytes)
        if (floor != null && floor.key + floor.value.size > offsetBytes) {
            entries.remove(key); return null
        }
        val ceil = entry.fragments.ceilingEntry(offsetBytes)
        if (ceil != null && end > ceil.key) {
            entries.remove(key); return null
        }
        entry.fragments[offsetBytes] = payload
        val total = entry.totalLength ?: return null
        var cursor = 0
        val out = ByteArray(total)
        for ((off, bytes) in entry.fragments) {
            if (off != cursor) return null
            System.arraycopy(bytes, 0, out, off, bytes.size)
            cursor += bytes.size
        }
        if (cursor != total) return null
        entries.remove(key)
        return out
    }

    @Synchronized
    fun clear() = entries.clear()

    private fun purge() {
        val now = System.currentTimeMillis()
        entries.entries.removeIf { now - it.value.createdAt > timeoutMs }
    }
}
