package com.nexus.network

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

/** Content-addressed local store with fixed-size chunks and verifiable manifests. */
object NexusContentStore {
    const val CHUNK_SIZE = 256 * 1024
    private const val ROOT = "nexus-content"

    data class Manifest(
        val hash: String,
        val size: Long,
        val chunkSize: Int,
        val chunks: List<String>,
        val name: String,
        val mime: String,
        val pinned: Boolean = false
    )

    fun putFile(context: Context, source: File, name: String = source.name, mime: String = "application/octet-stream", pin: Boolean = true): Manifest {
        require(source.isFile) { "Source introuvable" }
        val root = File(context.filesDir, ROOT).apply { mkdirs() }
        val tmp = File(root, ".upload-${System.nanoTime()}").apply { mkdirs() }
        val chunks = mutableListOf<String>()
        FileInputStream(source).use { input ->
            val buffer = ByteArray(CHUNK_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                if (read == 0) continue
                val bytes = buffer.copyOf(read)
                val hash = sha256(bytes)
                File(tmp, hash).writeBytes(bytes)
                chunks += hash
            }
        }
        val whole = MessageDigest.getInstance("SHA-256")
        for (hash in chunks) whole.update(File(tmp, hash).readBytes())
        val fileHash = whole.digest().toHex()
        val dir = File(root, fileHash).apply { mkdirs() }
        chunks.forEach { File(tmp, it).copyTo(File(dir, it), overwrite = true) }
        tmp.deleteRecursively()
        val manifest = Manifest(fileHash, source.length(), CHUNK_SIZE, chunks, name, mime, pin)
        writeManifest(context, manifest)
        return manifest
    }

    fun has(context: Context, hash: String): Boolean = manifest(context, hash) != null

    fun manifest(context: Context, hash: String): Manifest? {
        val file = File(File(File(context.filesDir, ROOT), hash), "manifest.json")
        if (!file.exists()) return null
        return runCatching {
            val j = org.json.JSONObject(file.readText())
            Manifest(
                j.getString("hash"), j.getLong("size"), j.getInt("chunkSize"),
                List(j.getJSONArray("chunks").length()) { i -> j.getJSONArray("chunks").getString(i) },
                j.getString("name"), j.getString("mime"), j.optBoolean("pinned", false)
            )
        }.getOrNull()
    }

    fun chunk(context: Context, hash: String, index: Int): ByteArray? {
        val m = manifest(context, hash) ?: return null
        val chunkHash = m.chunks.getOrNull(index) ?: return null
        val data = File(File(context.filesDir, ROOT), "$hash/$chunkHash")
        if (!data.isFile) return null
        val bytes = data.readBytes()
        return bytes.takeIf { sha256(it) == chunkHash }
    }

    fun pin(context: Context, hash: String, pinned: Boolean) {
        val m = manifest(context, hash) ?: return
        writeManifest(context, m.copy(pinned = pinned))
    }

    fun usedBytes(context: Context): Long {
        val root = File(context.filesDir, ROOT)
        return root.listFiles().orEmpty().filter { it.isDirectory }.sumOf { dir ->
            dir.listFiles().orEmpty().filter { it.isFile && it.name != "manifest.json" }.sumOf { it.length() }
        }
    }

    fun allPinned(context: Context): List<Manifest> {
        val root = File(context.filesDir, ROOT)
        return root.listFiles().orEmpty().mapNotNull { manifest(context, it.name) }.filter { it.pinned }
    }

    fun storeFetchedManifest(context: Context, m: Manifest) {
        File(File(context.filesDir, ROOT), m.hash).mkdirs()
        writeManifest(context, m)
    }

    fun writeChunk(context: Context, manifestHash: String, chunkHash: String, bytes: ByteArray): Boolean {
        if (sha256(bytes) != chunkHash) return false
        val dir = File(File(context.filesDir, ROOT), manifestHash).apply { mkdirs() }
        File(dir, chunkHash).writeBytes(bytes)
        return true
    }


    fun verifyComplete(context: Context, hash: String): Boolean {
        val m = manifest(context, hash) ?: return false
        if (m.size < 0 || m.chunkSize !in 1..CHUNK_SIZE || m.chunks.any { !it.matches(Regex("[0-9a-f]{64}")) }) return false
        var total = 0L
        val digest = MessageDigest.getInstance("SHA-256")
        for (chunkHash in m.chunks) {
            val file = File(File(context.filesDir, ROOT), "$hash/$chunkHash")
            if (!file.isFile) return false
            val bytes = runCatching { file.readBytes() }.getOrNull() ?: return false
            if (sha256(bytes) != chunkHash) return false
            total += bytes.size.toLong()
            digest.update(bytes)
            if (bytes.size > CHUNK_SIZE) return false
        }
        return total == m.size && digest.digest().toHex() == hash
    }

    fun assemble(context: Context, hash: String, destination: File): Boolean {
        val m = manifest(context, hash) ?: return false
        val tmp = File(destination.parentFile ?: context.cacheDir, ".${destination.name}.tmp")
        return runCatching {
            tmp.outputStream().use { out -> m.chunks.forEach { ch -> out.write(File(File(context.filesDir, ROOT), "$hash/$ch").readBytes()) } }
            require(tmp.length() == m.size) { "Taille de contenu invalide" }
            require(wholeHash(tmp) == hash) { "Hash final invalide" }
            tmp.renameTo(destination).also { require(it) }
            true
        }.getOrElse { runCatching { tmp.delete() }; false }
    }

    private fun writeManifest(context: Context, m: Manifest) {
        val file = File(File(File(context.filesDir, ROOT), m.hash).apply { mkdirs() }, "manifest.json")
        file.writeText(org.json.JSONObject().apply {
            put("hash", m.hash); put("size", m.size); put("chunkSize", m.chunkSize)
            put("chunks", org.json.JSONArray(m.chunks)); put("name", m.name); put("mime", m.mime); put("pinned", m.pinned)
        }.toString())
    }

    fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).toHex()
    fun sha256(file: File): String = wholeHash(file)
    private fun wholeHash(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) { val n = input.read(buffer); if (n < 0) break; if (n > 0) digest.update(buffer, 0, n) }
        }
        return digest.digest().toHex()
    }
    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it.toInt() and 0xff) }
}
