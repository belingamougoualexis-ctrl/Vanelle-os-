package com.nexus.network

import android.content.Context

object NetworkKeyManager {
    private const val PREVIOUS = "network_key_previous"
    private const val PREVIOUS_UNTIL = "network_key_previous_until"
    private const val GRACE_MS = 24L * 60 * 60 * 1000

    fun current(context: Context): String = NexusIdentity.networkKey(context)

    fun accepted(context: Context): List<String> {
        val current = NexusIdentity.networkKey(context)
        val now = System.currentTimeMillis()
        val previousUntil = NexusSecureStore.get(context, PREVIOUS_UNTIL)?.toLongOrNull() ?: 0L
        val previous = NexusSecureStore.get(context, PREVIOUS)
        return buildList {
            add(current)
            if (previous != null && previousUntil > now) add(previous)
        }.distinct()
    }

    fun rotate(context: Context): String {
        val current = NexusIdentity.networkKey(context)
        val next = generateKey()
        NexusSecureStore.put(context, PREVIOUS, current)
        NexusSecureStore.put(context, PREVIOUS_UNTIL, (System.currentTimeMillis() + GRACE_MS).toString())
        NexusSecureStore.put(context, "network_key", next)
        return next
    }

    fun fingerprint(key: String): String = NexusCrypto.sha256Hex(key).take(12).uppercase()

    private fun generateKey(): String {
        val a = NexusCrypto.nonce(24).replace("-", "_")
        return "NXK-$a"
    }
}
