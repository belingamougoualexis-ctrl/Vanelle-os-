package com.nexus.network

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stockage chiffré via Android Keystore, avec repli non chiffré si le keystore
 * est indisponible (émulateurs / certains appareils) pour éviter un crash au lancement.
 */
object NexusSecureStore {
    private const val KEYSTORE = "AndroidKeyStore"
    private const val ALIAS = "nexus-master-v1"
    private const val PREFS = "nexus_secure_store"
    private const val FALLBACK_PREFS = "nexus_secure_fallback"
    private const val IV_BYTES = 12
    private const val TAG_BITS = 128

    fun get(context: Context, key: String): String? {
        // Essai keystore
        val encoded = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key, null)
        if (encoded != null) {
            val decrypted = runCatching {
                val blob = Base64.getDecoder().decode(encoded)
                if (blob.size <= IV_BYTES) return@runCatching null
                val iv = blob.copyOfRange(0, IV_BYTES)
                val ciphertext = blob.copyOfRange(IV_BYTES, blob.size)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, masterKey(), GCMParameterSpec(TAG_BITS, iv))
                String(cipher.doFinal(ciphertext), Charsets.UTF_8)
            }.getOrNull()
            if (decrypted != null) return decrypted
        }
        // Repli
        return context.getSharedPreferences(FALLBACK_PREFS, Context.MODE_PRIVATE).getString(key, null)
    }

    fun put(context: Context, key: String, value: String) {
        val ok = runCatching {
            val iv = ByteArray(IV_BYTES).also { SecureRandom().nextBytes(it) }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, masterKey(), GCMParameterSpec(TAG_BITS, iv))
            val ciphertext = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
            val blob = ByteArray(iv.size + ciphertext.size)
            System.arraycopy(iv, 0, blob, 0, iv.size)
            System.arraycopy(ciphertext, 0, blob, iv.size, ciphertext.size)
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(key, Base64.getEncoder().encodeToString(blob))
                .apply()
            true
        }.getOrDefault(false)

        if (!ok) {
            context.getSharedPreferences(FALLBACK_PREFS, Context.MODE_PRIVATE).edit()
                .putString(key, value)
                .apply()
        }
    }

    fun remove(context: Context, key: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(key).apply()
        context.getSharedPreferences(FALLBACK_PREFS, Context.MODE_PRIVATE).edit().remove(key).apply()
    }

    private fun masterKey(): SecretKey {
        val ks = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }
}
