package com.nexus.network

import android.content.Context
import android.net.ConnectivityManager
import android.os.BatteryManager
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.min

/** Real background-relay governor: battery, metering, daily quota, global and per-peer token buckets. */
class NexusBandwidthPolicy private constructor(private val context: Context) {
    private data class Bucket(var tokens: Long, var lastNs: Long)

    private val global = Bucket(0L, System.nanoTime())
    private val peerBuckets = ConcurrentHashMap<String, Bucket>()
    @Volatile private var lastDayKey = persistedDay()
    @Volatile private var bytesToday = persistedBytes()

    fun allow(bytes: Int, peerId: String = "remote"): Boolean {
        if (bytes <= 0) return true
        if (!NexusSettings.transitEnabled(context)) return true
        if (!resourceConditionsAllow()) return false
        resetDayIfNeeded()
        synchronized(this) {
            val limit = NexusSettings.relayDailyLimitBytes(context)
            if (limit > 0 && bytesToday + bytes > limit) return false
            val rate = rateBytesPerSecond()
            if (rate <= 0) return false
            refill(global, rate)
            val perPeerRate = max((rate * 0.5).toLong(), 64L * 1024L)
            val bucket = peerBuckets.computeIfAbsent(peerId.ifBlank { "remote" }) { Bucket(0L, System.nanoTime()) }
            refill(bucket, min(perPeerRate, rate))
            val available = min(global.tokens, bucket.tokens)
            if (available < bytes) {
                val missingGlobal = (bytes - global.tokens).coerceAtLeast(0L)
                val missingPeer = (bytes - bucket.tokens).coerceAtLeast(0L)
                val missing = max(missingGlobal, missingPeer)
                val waitMs = (missing * 1000L / min(rate, perPeerRate)).coerceAtMost(250L)
                if (waitMs > 0) Thread.sleep(waitMs)
                refill(global, rate)
                refill(bucket, min(perPeerRate, rate))
            }
            if (global.tokens < bytes || bucket.tokens < bytes) return false
            global.tokens -= bytes
            bucket.tokens -= bytes
            bytesToday += bytes
            persistUsage()
            return true
        }
    }

    fun dailyBytes(): Long {
        resetDayIfNeeded()
        return bytesToday
    }

    fun rateMbps(): Double = NexusSettings.relayLimitMbps(context)

    private fun resourceConditionsAllow(): Boolean {
        val battery = batteryPercent()
        val charging = isCharging()
        if (battery < NexusSettings.minRelayBattery(context) && !charging) return false
        if (NexusSettings.relayChargingOnly(context) && !charging) return false
        val cm = context.getSystemService(ConnectivityManager::class.java)
        if (cm?.isActiveNetworkMetered == true && !NexusSettings.allowMeteredRelay(context)) return false
        return true
    }

    private fun refill(bucket: Bucket, rate: Long) {
        val now = System.nanoTime()
        val elapsedSeconds = (now - bucket.lastNs).coerceAtLeast(0L) / 1_000_000_000.0
        if (elapsedSeconds <= 0) return
        val burst = max(rate * 2L, 64L * 1024L)
        bucket.tokens = min(burst, bucket.tokens + (elapsedSeconds * rate).toLong())
        bucket.lastNs = now
    }

    private fun rateBytesPerSecond(): Long = (NexusSettings.relayLimitMbps(context) * 1_000_000.0 / 8.0).toLong()

    private fun batteryPercent(): Int = context.getSystemService(BatteryManager::class.java)
        ?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)?.coerceIn(0, 100) ?: 100

    private fun isCharging(): Boolean = runCatching {
        val intent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    }.getOrDefault(false)

    private fun resetDayIfNeeded() {
        val now = currentDayKey()
        if (now != lastDayKey) synchronized(this) {
            if (now != lastDayKey) {
                lastDayKey = now
                bytesToday = 0L
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString(DAY, now).putLong(BYTES, 0L).apply()
            }
        }
    }

    private fun persistedDay(): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(DAY, currentDayKey()) ?: currentDayKey()

    private fun persistedBytes(): Long = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getLong(BYTES, 0L).coerceAtLeast(0L)

    private fun persistUsage() {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(DAY, lastDayKey).putLong(BYTES, bytesToday).apply()
    }

    private fun currentDayKey(): String = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        .format(java.util.Date())

    companion object {
        private const val PREFS = "nexus_relay_usage"
        private const val DAY = "day"
        private const val BYTES = "bytes"
        private val instances = java.util.WeakHashMap<Context, NexusBandwidthPolicy>()

        fun forContext(context: Context): NexusBandwidthPolicy = synchronized(instances) {
            val app = context.applicationContext ?: context
            instances[app] ?: NexusBandwidthPolicy(app).also { instances[app] = it }
        }
    }
}
