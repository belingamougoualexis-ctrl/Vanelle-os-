package com.nexus.network

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** Cryptographic local naming: <public-key-fingerprint>.mesh. No central registrar is required. */
object NexusNaming {
    data class Record(
        val name: String,
        val nodeId: String,
        val publicKey: String,
        val addresses: List<String>,
        val createdAt: Long,
        val expiresAt: Long,
        val signature: String
    )

    private const val DIR = "nexus-names"
    private val memory = ConcurrentHashMap<String, Record>()

    fun own(context: Context, addresses: List<String>): Record {
        val publicKey = NexusIdentity.publicKeyBase64(context)
        val name = "${NexusCrypto.sha256Hex(publicKey).take(24)}.mesh"
        val created = System.currentTimeMillis()
        val expires = created + 30L * 24 * 60 * 60 * 1000
        val canonical = canonical(name, NexusIdentity.nodeId(context), publicKey, addresses, created, expires)
        val record = Record(name, NexusIdentity.nodeId(context), publicKey, addresses.distinct(), created, expires, NexusCrypto.encodeBytes(NexusIdentity.sign(context, canonical)))
        save(context, record)
        return record
    }

    fun save(context: Context, record: Record) {
        val dir = File(context.filesDir, DIR).apply { mkdirs() }
        File(dir, "${safe(record.name)}.json").writeText(JSONObject().apply {
            put("name", record.name); put("nodeId", record.nodeId); put("publicKey", record.publicKey)
            put("addresses", record.addresses.joinToString(",")); put("createdAt", record.createdAt)
            put("expiresAt", record.expiresAt); put("signature", record.signature)
        }.toString())
        memory[record.name] = record
    }

    fun resolve(context: Context, name: String): Record? {
        val normalized = name.trim().lowercase().removeSuffix(".")
        memory[normalized]?.takeIf { it.expiresAt > System.currentTimeMillis() }?.let { return it }
        val file = File(File(context.filesDir, DIR), "${safe(normalized)}.json")
        if (!file.exists()) return null
        return runCatching {
            val j = JSONObject(file.readText())
            Record(
                j.getString("name"), j.getString("nodeId"), j.getString("publicKey"),
                j.optString("addresses", "").split(',').filter { it.isNotBlank() },
                j.getLong("createdAt"), j.getLong("expiresAt"), j.getString("signature")
            ).also { memory[normalized] = it }
        }.getOrNull()?.takeIf { it.expiresAt > System.currentTimeMillis() && verify(it) }
    }

    fun verify(record: Record): Boolean {
        val canonical = canonical(record.name, record.nodeId, record.publicKey, record.addresses, record.createdAt, record.expiresAt)
        return NexusIdentity.verify(record.publicKey, canonical, record.signature)
    }

    fun nameForPublicKey(publicKey: String): String = "${NexusCrypto.sha256Hex(publicKey).take(24)}.mesh"

    fun wire(record: Record): String = NexusCrypto.encode(JSONObject().apply {
        put("name", record.name); put("nodeId", record.nodeId); put("publicKey", record.publicKey)
        put("addresses", record.addresses.joinToString(",")); put("createdAt", record.createdAt)
        put("expiresAt", record.expiresAt); put("signature", record.signature)
    }.toString())

    fun fromWire(wire: String): Record? = runCatching {
        val j = JSONObject(NexusCrypto.decode(wire))
        Record(
            j.getString("name"), j.getString("nodeId"), j.getString("publicKey"),
            j.optString("addresses", "").split(',').filter { it.isNotBlank() },
            j.getLong("createdAt"), j.getLong("expiresAt"), j.getString("signature")
        )
    }.getOrNull()?.takeIf { it.expiresAt > System.currentTimeMillis() && verify(it) }

    fun resolveDistributed(context: Context, name: String, peers: Collection<NsdController.Peer>): Record? {
        resolve(context, name)?.let { return it }
        val normalized = name.trim().lowercase().removeSuffix(".")
        peers.asSequence()
            .filter { it.host.isNotBlank() && NexusTrustStore.isAllowed(context, it.name) }
            .sortedByDescending { NexusTrustStore.reputation(context, it.name) }
            .take(12)
            .forEach { peer ->
                val record = NxpProtocol.queryName(peer.host, peer.port, normalized) { NetworkKeyManager.accepted(context) }
                if (record != null && record.name.lowercase() == normalized && verify(record)) {
                    save(context, record)
                    return record
                }
            }
        return null
    }

    private fun canonical(name: String, nodeId: String, publicKey: String, addresses: List<String>, created: Long, expires: Long): String =
        "v=1&name=$name&node=$nodeId&publicKey=${NexusCrypto.encode(publicKey)}&addresses=${NexusCrypto.encode(addresses.sorted().joinToString(","))}&created=$created&expires=$expires"

    private fun safe(value: String): String = value.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(160)
}
