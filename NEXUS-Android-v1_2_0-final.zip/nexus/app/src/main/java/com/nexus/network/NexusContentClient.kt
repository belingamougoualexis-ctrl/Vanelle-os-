package com.nexus.network

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.io.File

object NexusContentClient {
    data class PinnedRemote(val hash: String, val size: Long, val name: String)

    fun listPinned(host: String, context: android.content.Context): Result<List<PinnedRemote>> = runCatching {
        val socket = Socket(); check(NexusVpnRegistry.protect(socket)); socket.connect(InetSocketAddress(host, NexusConfig.CONTENT_PORT), 8_000)
        socket.use { s ->
            s.soTimeout = 10_000
            val input=BufferedInputStream(s.getInputStream()); val output=BufferedOutputStream(s.getOutputStream())
            val nonce=NexusCrypto.nonce(18); val auth=NexusCrypto.hmacHex(NexusIdentity.networkKey(context), "v=1&type=hello&node=${NexusIdentity.nodeId(context)}&nonce=$nonce")
            line(output,"NEXUS-CONTENT/1 HELLO v=1 node=${NexusCrypto.encode(NexusIdentity.nodeId(context))} nonce=$nonce auth=$auth")
            val ok=readLine(input) ?: error("Réponse contenu absente"); check(ok.startsWith("NEXUS-CONTENT/1 OK"))
            line(output,"LIST-PINNED")
            val header=readLine(input) ?: error("Inventaire absent"); check(header.startsWith("PINNED ")); val count=header.removePrefix("PINNED ").toIntOrNull()?.coerceIn(0, 256) ?: 0
            buildList { repeat(count) { val row=readLine(input) ?: error("Inventaire interrompu"); val p=row.split(' ', limit=3); if(p.size==3) add(PinnedRemote(p[0],p[1].toLongOrNull() ?: 0L,NexusCrypto.decode(p[2]))) } }
        }
    }

    fun fetchFromAny(context: android.content.Context, hash: String, peers: Collection<NsdController.Peer>, destination: File): Result<File> = runCatching {
        require(hash.matches(Regex("[0-9a-f]{64}")))
        val ranked=peers.asSequence().filter { it.host.isNotBlank() && NexusTrustStore.isAllowed(context,it.name) }.sortedByDescending { NexusTrustStore.reputation(context,it.name) }.toList()
        var last: Throwable? = null
        for (peer in ranked) {
            val listed=runCatching { listPinned(peer.host,context).getOrThrow().any { it.hash == hash } }.getOrDefault(false)
            if (!listed) continue
            val fetched=fetch(peer.host,context,hash,destination)
            if (fetched.isSuccess) return@runCatching fetched.getOrThrow()
            last=fetched.exceptionOrNull()
        }
        throw last ?: IllegalStateException("Contenu $hash introuvable sur les pairs connus")
    }

    fun fetch(host: String, context: android.content.Context, hash: String, destination: File): Result<File> = runCatching {
        require(hash.matches(Regex("[0-9a-f]{64}")))
        val socket = Socket()
        check(NexusVpnRegistry.protect(socket)) { "Socket contenu non protégé" }
        socket.connect(InetSocketAddress(host, NexusConfig.CONTENT_PORT), 10_000)
        socket.use { s ->
            s.soTimeout = 20_000
            val input=BufferedInputStream(s.getInputStream()); val output=BufferedOutputStream(s.getOutputStream())
            val nonce=NexusCrypto.nonce(18); val auth=NexusCrypto.hmacHex(NexusIdentity.networkKey(context), "v=1&type=hello&node=${NexusIdentity.nodeId(context)}&nonce=$nonce")
            line(output,"NEXUS-CONTENT/1 HELLO v=1 node=${NexusCrypto.encode(NexusIdentity.nodeId(context))} nonce=$nonce auth=$auth")
            val ok=readLine(input) ?: error("Réponse contenu absente"); check(ok.startsWith("NEXUS-CONTENT/1 OK"))
            val f=fields(ok); check(f["nonce"]==nonce); check(NexusCrypto.constantTimeEquals(NexusCrypto.hmacHex(NexusIdentity.networkKey(context), "v=1&type=ok&node=${NexusCrypto.decode(f["node"]!!)}&nonce=$nonce"), f["auth"].orEmpty()))
            line(output,"MANIFEST $hash")
            val meta=readLine(input) ?: error("Manifest absent"); check(meta.startsWith("MANIFEST-OK"))
            val json=String(NexusCrypto.decodeBytes(readLine(input) ?: error("Manifest JSON absent")), Charsets.UTF_8)
            val j=org.json.JSONObject(json)
            val manifest=NexusContentStore.Manifest(j.getString("hash"),j.getLong("size"),j.getInt("chunkSize"),List(j.getJSONArray("chunks").length()){i->j.getJSONArray("chunks").getString(i)},j.getString("name"),j.getString("mime"),false)
            NexusContentStore.storeFetchedManifest(context,manifest)
            val temp=File(destination.parentFile ?: context.cacheDir,".${destination.name}.nexus-part")
            temp.outputStream().use { out ->
                manifest.chunks.indices.forEach { index ->
                    line(output,"GET $hash $index")
                    val hdr=readLine(input) ?: error("Chunk absent"); check(hdr.startsWith("CHUNK-OK "))
                    val len=hdr.removePrefix("CHUNK-OK ").toIntOrNull() ?: error("Chunk length")
                    require(len in 1..NexusContentStore.CHUNK_SIZE)
                    val chunk=ByteArray(len); readFully(input,chunk); require(NexusContentStore.sha256(chunk)==manifest.chunks[index])
                    out.write(chunk)
                    NexusContentStore.writeChunk(context,hash,manifest.chunks[index],chunk)
                }
            }
            temp.copyTo(destination, overwrite=true); temp.delete(); check(destination.length()==manifest.size); check(NexusContentStore.sha256(destination) == hash); destination
        }
    }

    fun push(host: String, context: android.content.Context, hash: String): Result<Boolean> = runCatching {
        val m=NexusContentStore.manifest(context,hash) ?: error("Contenu local absent")
        val socket=Socket(); check(NexusVpnRegistry.protect(socket)); socket.connect(InetSocketAddress(host,NexusConfig.CONTENT_PORT),10_000)
        socket.use { s ->
            s.soTimeout=20_000; val input=BufferedInputStream(s.getInputStream()); val output=BufferedOutputStream(s.getOutputStream())
            val nonce=NexusCrypto.nonce(18); val auth=NexusCrypto.hmacHex(NexusIdentity.networkKey(context),"v=1&type=hello&node=${NexusIdentity.nodeId(context)}&nonce=$nonce")
            line(output,"NEXUS-CONTENT/1 HELLO v=1 node=${NexusCrypto.encode(NexusIdentity.nodeId(context))} nonce=$nonce auth=$auth")
            check((readLine(input) ?: "").startsWith("NEXUS-CONTENT/1 OK"))
            line(output,"PUSH $hash"); val manifestJson=org.json.JSONObject().apply{put("hash",m.hash);put("size",m.size);put("chunkSize",m.chunkSize);put("chunks",org.json.JSONArray(m.chunks));put("name",m.name);put("mime",m.mime);put("pinned",true)}.toString()
            line(output,"PUSH-MANIFEST ${NexusCrypto.encode(manifestJson)}")
            m.chunks.forEachIndexed { i,ch -> val bytes=NexusContentStore.chunk(context,hash,i) ?: error("Chunk local absent"); line(output,"PUSH-CHUNK $i ${bytes.size}"); output.write(bytes); output.flush() }
            (readLine(input) ?: "") == "PUSH-OK"
        }
    }

    private fun line(out:BufferedOutputStream,v:String){out.write(v.toByteArray(Charsets.US_ASCII));out.write('\n'.code);out.flush()}
    private fun readLine(input:BufferedInputStream):String?{val b=ByteArray(8192);var n=0;while(n<b.size){val x=input.read();if(x<0)return if(n==0)null else String(b,0,n,Charsets.US_ASCII);if(x=='\n'.code)return String(b,0,n,Charsets.US_ASCII);if(x!='\r'.code)b[n++]=x.toByte()};error("Ligne trop longue")}
    private fun readFully(input:BufferedInputStream,b:ByteArray){var o=0;while(o<b.size){val n=input.read(b,o,b.size-o);if(n<0)error("Flux interrompu");o+=n}}
    private fun fields(line:String):Map<String,String> = line.split(' ').drop(2).mapNotNull{t->val i=t.indexOf('=');if(i>0)t.substring(0,i) to t.substring(i+1) else null}.toMap()
}
