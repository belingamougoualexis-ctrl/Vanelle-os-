package com.nexus.network

import java.net.Inet4Address
import java.net.InetAddress
import kotlin.math.min

/** Strict IPv4/TCP/UDP codec used by the NEXUS userspace VPN stack. */
object IpPacket {
    data class IPv4(
        val src: Inet4Address,
        val dst: Inet4Address,
        val protocol: Int,
        val headerLength: Int,
        val totalLength: Int,
        val identification: Int,
        val flagsAndFragment: Int,
        val ttl: Int,
        val payload: ByteArray
    )

    data class Udp(
        val srcPort: Int,
        val dstPort: Int,
        val length: Int,
        val checksum: Int,
        val payload: ByteArray
    )

    data class Tcp(
        val srcPort: Int,
        val dstPort: Int,
        val sequence: Long,
        val acknowledgement: Long,
        val headerLength: Int,
        val flags: Int,
        val window: Int,
        val checksum: Int,
        val urgentPointer: Int,
        val payload: ByteArray,
        val options: TcpOptions = TcpOptions()
    ) {
        val syn: Boolean get() = flags and 0x002 != 0
        val fin: Boolean get() = flags and 0x001 != 0
        val rst: Boolean get() = flags and 0x004 != 0
        val ack: Boolean get() = flags and 0x010 != 0
        val psh: Boolean get() = flags and 0x008 != 0
    }

    fun parseIpv4(packet: ByteArray): IPv4? {
        if (packet.size < 20) return null
        val version = (packet[0].toInt() ushr 4) and 0x0f
        val ihl = (packet[0].toInt() and 0x0f) * 4
        if (version != 4 || ihl !in 20..60 || packet.size < ihl) return null
        val totalLength = u16(packet, 2)
        if (totalLength < ihl || totalLength > packet.size) return null
        if (checksum(packet, 0, ihl) != 0xffff) return null
        val flagsAndFragment = u16(packet, 6)
        // Only first fragments are accepted. Reassembly is deliberately not implicit.
        if ((flagsAndFragment and 0x1fff) != 0) return null
        if ((flagsAndFragment and 0x2000) != 0) return null
        val src = ipv4(packet, 12) ?: return null
        val dst = ipv4(packet, 16) ?: return null
        return IPv4(
            src = src,
            dst = dst,
            protocol = u8(packet[9]),
            headerLength = ihl,
            totalLength = totalLength,
            identification = u16(packet, 4),
            flagsAndFragment = flagsAndFragment,
            ttl = u8(packet[8]),
            payload = packet.copyOfRange(ihl, totalLength)
        )
    }

    fun parseUdp(payload: ByteArray): Udp? {
        if (payload.size < 8) return null
        val srcPort = u16(payload, 0)
        val dstPort = u16(payload, 2)
        val length = u16(payload, 4)
        if (length < 8 || length > payload.size) return null
        return Udp(srcPort, dstPort, length, u16(payload, 6), payload.copyOfRange(8, length))
    }

    fun parseTcp(payload: ByteArray): Tcp? {
        if (payload.size < 20) return null
        val srcPort = u16(payload, 0)
        val dstPort = u16(payload, 2)
        val sequence = u32(payload, 4)
        val acknowledgement = u32(payload, 8)
        val headerLength = ((payload[12].toInt() ushr 4) and 0x0f) * 4
        if (headerLength !in 20..60 || headerLength > payload.size) return null
        val flags = u16(payload, 12) and 0x01ff
        val window = u16(payload, 14)
        val checksum = u16(payload, 16)
        val urgent = u16(payload, 18)
        return Tcp(
            srcPort,
            dstPort,
            sequence,
            acknowledgement,
            headerLength,
            flags,
            window,
            checksum,
            urgent,
            payload.copyOfRange(headerLength, payload.size),
            TcpOptionCodec.parse(payload.copyOfRange(20, headerLength))
        )
    }

    fun validateUdpChecksum(ip: IPv4, udp: Udp, rawUdp: ByteArray): Boolean {
        if (udp.checksum == 0) return true // Optional for IPv4 UDP.
        return checksumPseudo(ip.src.address, ip.dst.address, 17, rawUdp) == 0xffff
    }

    fun validateUdpChecksum(src: Inet4Address, dst: Inet4Address, rawUdp: ByteArray): Boolean {
        val checksum = u16(rawUdp, 6)
        if (checksum == 0) return true
        return checksumPseudo(src.address, dst.address, 17, rawUdp) == 0xffff
    }

    fun validateTcpChecksum(ip: IPv4, tcpPayload: ByteArray): Boolean =
        checksumPseudo(ip.src.address, ip.dst.address, 6, tcpPayload) == 0xffff

    fun validateTcpChecksum(src: Inet4Address, dst: Inet4Address, tcpPayload: ByteArray): Boolean =
        checksumPseudo(src.address, dst.address, 6, tcpPayload) == 0xffff

    fun buildUdp(
        src: Inet4Address,
        dst: Inet4Address,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray,
        identification: Int = 0
    ): ByteArray {
        val udp = ByteArray(8 + payload.size)
        putU16(udp, 0, srcPort)
        putU16(udp, 2, dstPort)
        putU16(udp, 4, udp.size)
        System.arraycopy(payload, 0, udp, 8, payload.size)
        var sum = checksumPseudoSum(src.address, dst.address, 17, udp)
        var folded = fold16(sum)
        if (folded == 0) folded = 0xffff
        putU16(udp, 6, folded.inv() and 0xffff)
        return buildIpv4(src, dst, 17, udp, identification)
    }

    fun buildTcp(
        src: Inet4Address,
        dst: Inet4Address,
        srcPort: Int,
        dstPort: Int,
        sequence: Long,
        acknowledgement: Long,
        flags: Int,
        window: Int = 65535,
        payload: ByteArray = ByteArray(0),
        identification: Int = 0,
        options: ByteArray = ByteArray(0)
    ): ByteArray {
        require(options.size <= 40 && options.size % 4 == 0)
        val tcp = ByteArray(20 + options.size + payload.size)
        putU16(tcp, 0, srcPort)
        putU16(tcp, 2, dstPort)
        putU32(tcp, 4, sequence)
        putU32(tcp, 8, acknowledgement)
        putU16(tcp, 12, ((20 + options.size) / 4) shl 12 or (flags and 0x01ff))
        putU16(tcp, 14, window)
        putU16(tcp, 16, 0)
        putU16(tcp, 18, 0)
        if (options.isNotEmpty()) System.arraycopy(options, 0, tcp, 20, options.size)
        if (payload.isNotEmpty()) System.arraycopy(payload, 0, tcp, 20 + options.size, payload.size)
        val sum = checksumPseudoSum(src.address, dst.address, 6, tcp)
        putU16(tcp, 16, fold16(sum).inv() and 0xffff)
        return buildIpv4(src, dst, 6, tcp, identification)
    }

    fun buildIpv4(
        src: Inet4Address,
        dst: Inet4Address,
        protocol: Int,
        payload: ByteArray,
        identification: Int = 0,
        ttl: Int = 64
    ): ByteArray {
        require(protocol in 0..255)
        require(payload.size <= 65515)
        val packet = ByteArray(20 + payload.size)
        packet[0] = 0x45
        packet[1] = 0
        putU16(packet, 2, packet.size)
        putU16(packet, 4, identification and 0xffff)
        putU16(packet, 6, 0)
        packet[8] = ttl.coerceIn(1, 255).toByte()
        packet[9] = protocol.toByte()
        packet[10] = 0
        packet[11] = 0
        System.arraycopy(src.address, 0, packet, 12, 4)
        System.arraycopy(dst.address, 0, packet, 16, 4)
        putU16(packet, 10, checksum(packet, 0, 20).inv() and 0xffff)
        System.arraycopy(payload, 0, packet, 20, payload.size)
        return packet
    }

    fun ipv4(bytes: ByteArray, offset: Int): Inet4Address? {
        if (offset < 0 || offset + 4 > bytes.size) return null
        return runCatching {
            InetAddress.getByAddress(bytes.copyOfRange(offset, offset + 4)) as Inet4Address
        }.getOrNull()
    }

    fun u8(b: Byte): Int = b.toInt() and 0xff
    fun u16(b: ByteArray, offset: Int): Int = (u8(b[offset]) shl 8) or u8(b[offset + 1])
    fun u32(b: ByteArray, offset: Int): Long =
        (u16(b, offset).toLong() shl 16) or u16(b, offset + 2).toLong()

    fun putU16(b: ByteArray, offset: Int, value: Int) {
        b[offset] = (value ushr 8).toByte()
        b[offset + 1] = value.toByte()
    }

    fun putU32(b: ByteArray, offset: Int, value: Long) {
        putU16(b, offset, (value ushr 16).toInt())
        putU16(b, offset + 2, value.toInt())
    }

    fun checksum(buffer: ByteArray, offset: Int, length: Int): Int =
        fold16(sumWords(buffer, offset, length))

    private fun checksumPseudo(src: ByteArray, dst: ByteArray, protocol: Int, payload: ByteArray): Int =
        fold16(checksumPseudoSum(src, dst, protocol, payload))

    private fun checksumPseudoSum(src: ByteArray, dst: ByteArray, protocol: Int, payload: ByteArray): Long {
        var sum = 0L
        sum += ((src[0].toInt() and 0xff) shl 8) or (src[1].toInt() and 0xff)
        sum += ((src[2].toInt() and 0xff) shl 8) or (src[3].toInt() and 0xff)
        sum += ((dst[0].toInt() and 0xff) shl 8) or (dst[1].toInt() and 0xff)
        sum += ((dst[2].toInt() and 0xff) shl 8) or (dst[3].toInt() and 0xff)
        sum += (protocol.toLong() and 0xffL)
        sum += payload.size.toLong()
        sum += sumWords(payload, 0, payload.size)
        return sum
    }

    private fun sumWords(buffer: ByteArray, offset: Int, length: Int): Long {
        var sum = 0L
        var i = offset
        val end = offset + length
        while (i + 1 < end) {
            sum += ((buffer[i].toInt() and 0xff) shl 8) or (buffer[i + 1].toInt() and 0xff)
            i += 2
        }
        if (i < end) sum += (buffer[i].toInt() and 0xff) shl 8
        return sum
    }

    private fun fold16(value: Long): Int {
        var v = value
        while ((v ushr 16) != 0L) v = (v and 0xffffL) + (v ushr 16)
        return v.toInt() and 0xffff
    }
}
