package com.nexus.network

import java.io.FilterOutputStream
import java.io.InputStream
import java.io.OutputStream

/** Applies the local resource-credit policy to traffic generated through remote relays. */
class NexusCreditGatedChannel(
    private val base: NexusStreamChannel,
    private val context: android.content.Context?,
    private val peerId: String
) : NexusStreamChannel {
    override val input: InputStream = base.input
    override val output: OutputStream = object : FilterOutputStream(base.output) {
        override fun write(b: Int) {
            check(allow(1)) { "Crédits NEXUS insuffisants" }
            super.write(b)
        }
        override fun write(b: ByteArray, off: Int, len: Int) {
            check(allow(len)) { "Crédits NEXUS insuffisants" }
            super.write(b, off, len)
        }
        private fun allow(bytes: Int): Boolean = context?.let { NexusCredits.spend(it, peerId, bytes.toLong()) } ?: true
    }

    override fun shutdownOutput() = base.shutdownOutput()
    override fun close() = base.close()
}
