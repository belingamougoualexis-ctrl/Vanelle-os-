package com.nexus.network

import android.content.Context
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress

/** DNS shim for the VPN: self-certifying .mesh names are resolved locally; other DNS is forwarded. */
object NexusDns {
    val IPV4 = InetAddress.getByName("10.255.0.1")
    val IPV6 = InetAddress.getByName("fd00:4e58:5553::1")

    private data class Question(val id: Int, val name: String, val type: Int, val questionEnd: Int)

    fun handleQuery(
        context: Context,
        query: ByteArray,
        peers: Collection<NsdController.Peer>,
        protect: (DatagramSocket) -> Boolean,
        dnsServers: List<String>
    ): ByteArray? {
        val q = parseQuestion(query) ?: return null
        if (!q.name.lowercase().endsWith(".mesh") && q.name.lowercase() != "mesh") {
            return forward(query, dnsServers, protect)
        }
        val record = NexusNaming.resolveDistributed(context, q.name, peers)
        if (record == null) return response(query, q, rcode = 3, answers = emptyList())
        val candidates = record.addresses.mapNotNull { runCatching { InetAddress.getByName(it) }.getOrNull() }
            .filter { it is java.net.Inet4Address && q.type == 1 || it is java.net.Inet6Address && q.type == 28 }
        if (candidates.isEmpty()) return response(query, q, rcode = 0, answers = emptyList())
        return response(query, q, rcode = 0, answers = candidates.take(4))
    }

    private fun parseQuestion(packet: ByteArray): Question? {
        if (packet.size < 17) return null
        val qd = u16(packet, 4)
        if (qd != 1) return null
        var off = 12
        val labels = mutableListOf<String>()
        while (off < packet.size) {
            val len = packet[off].toInt() and 0xff
            off++
            if (len == 0) break
            if (len > 63 || off + len > packet.size) return null
            labels += String(packet, off, len, Charsets.US_ASCII)
            off += len
        }
        if (off + 4 > packet.size) return null
        val type = u16(packet, off)
        val qclass = u16(packet, off + 2)
        if (qclass != 1 || type !in setOf(1, 28)) return null
        return Question(u16(packet, 0), labels.joinToString(".").lowercase(), type, off + 4)
    }

    private fun response(query: ByteArray, q: Question, rcode: Int, answers: List<InetAddress>): ByteArray {
        val question = query.copyOfRange(12, q.questionEnd)
        val out = ByteArray(12 + question.size + answers.sumOf { 12 + it.address.size })
        putU16(out, 0, q.id)
        putU16(out, 2, 0x8000 or (if (rcode == 0 && answers.isNotEmpty()) 0 else 0) or (rcode and 0x0f))
        putU16(out, 4, 1)
        putU16(out, 6, answers.size)
        putU16(out, 8, 0)
        putU16(out, 10, 0)
        var off = 12
        System.arraycopy(question, 0, out, off, question.size)
        off += question.size
        answers.forEach { address ->
            putU16(out, off, 0xc00c); off += 2
            putU16(out, off, if (address is java.net.Inet4Address) 1 else 28); off += 2
            putU16(out, off, 1); off += 2
            putU32(out, off, 30); off += 4
            putU16(out, off, address.address.size); off += 2
            System.arraycopy(address.address, 0, out, off, address.address.size)
            off += address.address.size
        }
        return out
    }

    private fun forward(query: ByteArray, dnsServers: List<String>, protect: (DatagramSocket) -> Boolean): ByteArray? {
        val transportManager = NexusTransportManager(context)
        for (server in dnsServers) {
            val address = runCatching { InetAddress.getByName(server) }.getOrNull() ?: continue
            runCatching {
                val socket = runCatching { transportManager.openUdpWithFailover().first }
                    .getOrElse { DatagramSocket() }
                socket.use {
                    it.soTimeout = 2500
                    if (!protect(it)) return@runCatching null
                    it.connect(InetSocketAddress(address, 53))
                    it.send(DatagramPacket(query, query.size))
                    val buffer = ByteArray(4096)
                    val packet = DatagramPacket(buffer, buffer.size)
                    it.receive(packet)
                    return@runCatching packet.data.copyOf(packet.length)
                }
            }.getOrNull()?.let { return it }
        }
        return null
    }

    private fun u16(b: ByteArray, o: Int): Int = ((b[o].toInt() and 0xff) shl 8) or (b[o + 1].toInt() and 0xff)
    private fun putU16(b: ByteArray, o: Int, v: Int) { b[o] = (v ushr 8).toByte(); b[o + 1] = v.toByte() }
    private fun putU32(b: ByteArray, o: Int, v: Long) { putU16(b, o, (v ushr 16).toInt()); putU16(b, o + 2, v.toInt()) }
}
