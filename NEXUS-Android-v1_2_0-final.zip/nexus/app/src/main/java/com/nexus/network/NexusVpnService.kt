package com.nexus.network

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.IBinder
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.Executors

class NexusVpnService : VpnService() {
    private val controlPool = Executors.newSingleThreadExecutor()
    private var tunInterface: android.os.ParcelFileDescriptor? = null
    private var stack: UserSpaceIpStack? = null
    private lateinit var discovery: NsdController
    private lateinit var router: MeshRouter

    override fun onCreate() {
        super.onCreate()
        NexusVpnRegistry.register(this)
        createChannel()
        discovery = NsdController(this)
        router = MeshRouter(NexusIdentity.nodeId(this), { discovery.peersSnapshot() }) { peer -> NexusTrustStore.reputation(this, peer.name) }
        startForeground(2001, notification("NEXUS userspace IP prêt"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            NexusConfig.ACTION_VPN_STOP -> {
                stopTunnel()
                stopSelf()
                return START_NOT_STICKY
            }
            NexusConfig.ACTION_VPN, null -> startTunnel()
        }
        return START_STICKY
    }

    private fun startTunnel() {
        if (tunInterface != null) return
        val prepared = VpnService.prepare(this) == null
        if (!prepared) {
            updateNotification("Autorisation VPN Android requise")
            return
        }

        val snapshot = NetworkInspector.snapshot(this)
        val upstreamDns = snapshot.dnsServers.filter { it.isNotBlank() }.take(4)
        val tun = runCatching {
            Builder()
                .setSession("NEXUS")
                .setMtu(1500)
                .addAddress("10.255.0.2", 30)
                .addAddress("fd00:4e58:5553::2", 128)
                .addAddress("fe80::2", 64)
                .addRoute("0.0.0.0", 0)
                // IPv6 is captured so unsupported IPv6 packets cannot silently escape.
                .addRoute("::", 0)
                .addDisallowedApplication(packageName)
                // All DNS first enters NEXUS. .mesh is answered from the cryptographic
                // naming layer; public names are forwarded to the real DNS servers below.
                .apply { runCatching { addDnsServer(NexusDns.IPV4) }; runCatching { addDnsServer(NexusDns.IPV6) } }
                .establish()
        }.getOrNull()

        if (tun == null) {
            updateNotification("Établissement TUN impossible")
            return
        }
        tunInterface = tun
        runCatching { setUnderlyingNetworks(NexusTransportManager(this).validatedUnderlyingNetworks()) }
        discovery.startDiscovery()
        discovery.refreshP2pEndpoints()

        val input = FileInputStream(tun.fileDescriptor)
        val output = FileOutputStream(tun.fileDescriptor)
        val upstream = RoutedNexusUpstream(
            vpn = this,
            nodeId = NexusIdentity.nodeId(this),
            networkKeyProvider = { NexusIdentity.networkKey(this) },
            gatewayEnabled = { NexusSettings.gatewayEnabled(this) },
            transitEnabled = { NexusSettings.transitEnabled(this) },
            router = router,
            context = this
        )
        stack = UserSpaceIpStack(
            tunInput = input,
            tunOutput = output,
            upstream = upstream,
            dnsContext = this,
            dnsPeers = { discovery.peersSnapshot() },
            dnsServers = { upstreamDns },
            dnsSocketProtect = { socket -> protect(socket) }
        ).also { it.start() }

        updateNotification("VPN NEXUS actif • IPv4/IPv6 TCP/UDP userspace")
        controlPool.execute {
            while (tunInterface != null) {
                Thread.sleep(5000)
                runCatching { setUnderlyingNetworks(NexusTransportManager(this@NexusVpnService).validatedUnderlyingNetworks()) }
                publishStatus()
            }
        }
    }

    private fun publishStatus() {
        val engine = stack?.status() ?: "moteur arrêté"
        val route = router.summary(
            gatewayEnabled = NexusSettings.gatewayEnabled(this),
            transitEnabled = NexusSettings.transitEnabled(this)
        )
        updateNotification("VPN NEXUS • $route • $engine")
    }

    private fun stopTunnel() {
        stack?.stop()
        stack = null
        runCatching { tunInterface?.close() }
        tunInterface = null
        discovery.stopDiscovery()
        updateNotification("VPN NEXUS arrêté")
    }

    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopTunnel()
        discovery.close()
        NexusVpnRegistry.unregister(this)
        controlPool.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? = super.onBind(intent)

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("nexus-vpn", "NEXUS VPN", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun notification(text: String): Notification =
        Notification.Builder(this, "nexus-vpn")
            .setContentTitle("NEXUS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(2001, notification(text.take(120)))
    }
}
