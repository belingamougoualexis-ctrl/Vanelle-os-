package com.nexus.network

object NexusConfig {
    const val VERSION = "1.2.0"
    const val SERVICE_TYPE = "_nexus._tcp"
    const val NODE_PORT = 45454
    const val SOCKS_PORT = 45455
    const val RELAY_PORT = 45456
    const val CONTENT_PORT = 45457
    const val APP_SHARE_PORT = 45458
    const val DTN_BUNDLE_MAX_BYTES = 8 * 1024 * 1024
    const val DHT_K = 20
    const val NAT_STUN_TIMEOUT_MS = 2500
    const val MAX_HOPS = 24
    const val MAX_ADVERTISED_PATH = 24
    const val CONTENT_REPLICATION_DEFAULT = 3
    const val ACTION_AUTO_CONNECT = "com.nexus.network.ACTION_AUTO_CONNECT"
    const val ACTION_GATEWAY = "com.nexus.network.ACTION_GATEWAY"
    const val ACTION_TRANSIT = "com.nexus.network.ACTION_TRANSIT"
    const val ACTION_VPN = "com.nexus.network.ACTION_VPN"
    const val ACTION_VPN_STOP = "com.nexus.network.ACTION_VPN_STOP"
    const val ACTION_ROTATE_KEY = "com.nexus.network.ACTION_ROTATE_KEY"
    const val ACTION_STOP = "com.nexus.network.ACTION_STOP"
    const val EXTRA_ENABLED = "enabled"
    const val SOCKS_USERNAME = "nexus"
    const val SOCKS_PASSWORD = "NEXUS-LOCAL"
}
