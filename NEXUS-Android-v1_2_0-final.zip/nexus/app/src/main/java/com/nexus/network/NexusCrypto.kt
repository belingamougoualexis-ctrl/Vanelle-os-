package com.nexus.network

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object NexusCrypto {
    private val random = SecureRandom()
    private val encoder = Base64.getUrlEncoder().withoutPadding()
    private val decoder = Base64.getUrlDecoder()

    fun nonce(bytes: Int = 18): String {
        val value = ByteArray(bytes)
        random.nextBytes(value)
        return encoder.encodeToString(value)
    }

    fun encode(value: String): String = encoder.encodeToString(value.toByteArray(Charsets.UTF_8))
    fun decode(value: String): String = String(decoder.decode(value), Charsets.UTF_8)
    fun encodeBytes(value: ByteArray): String = encoder.encodeToString(value)
    fun decodeBytes(value: String): ByteArray = decoder.decode(value)

    fun hmacHex(key: String, message: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(message.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    fun constantTimeEquals(a: String, b: String): Boolean =
        MessageDigest.isEqual(a.toByteArray(Charsets.US_ASCII), b.toByteArray(Charsets.US_ASCII))

    fun sha256Hex(value: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 0xff) }
}
