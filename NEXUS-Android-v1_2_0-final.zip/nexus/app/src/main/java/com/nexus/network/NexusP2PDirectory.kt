package com.nexus.network

import java.util.concurrent.ConcurrentHashMap

object NexusP2PDirectory {
    data class Endpoint(
        val id: String,
        val displayName: String,
        val deviceAddress: String,
        val host: String,
        val port: Int = NexusConfig.NODE_PORT,
        @Volatile var gateway: Boolean = false,
        @Volatile var relay: Boolean = false,
        @Volatile var gatewayDistance: Int = Int.MAX_VALUE,
        @Volatile var gatewayPath: List<String> = emptyList(),
        @Volatile var latencyMs: Double = Double.POSITIVE_INFINITY,
        @Volatile var packetLossPct: Double = 100.0,
        @Volatile var bandwidthMbps: Double = 0.0,
        @Volatile var identityPublicKey: String = "",
        @Volatile var gatewayPublicKey: String = "",
        @Volatile var authenticatedIdentity: Boolean = false
    )

    private val endpoints = ConcurrentHashMap<String, Endpoint>()

    fun upsert(endpoint: Endpoint) { endpoints[endpoint.deviceAddress] = endpoint }
    fun remove(deviceAddress: String) { endpoints.remove(deviceAddress) }
    fun snapshot(): List<Endpoint> = endpoints.values.sortedBy { it.displayName.lowercase() }
    fun clear() = endpoints.clear()
}
