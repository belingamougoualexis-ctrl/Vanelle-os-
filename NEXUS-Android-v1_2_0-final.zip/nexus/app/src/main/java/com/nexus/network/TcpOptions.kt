package com.nexus.network

data class SackBlock(val left: Long, val rightExclusive: Long)

/** TCP option codec used by the real terminating userspace TCP implementation. */
data class TcpOptions(
    val mss: Int? = null,
    val windowScale: Int? = null,
    val sackPermitted: Boolean = false,
    val timestampValue: Long? = null,
    val timestampEcho: Long? = null,
    val sackBlocks: List<SackBlock> = emptyList()
)

object TcpOptionCodec {
    fun parse(raw: ByteArray): TcpOptions {
        var i = 0
        var mss: Int? = null
        var ws: Int? = null
        var sack = false
        var tsVal: Long? = null
        var tsEcho: Long? = null
        val sackBlocks = mutableListOf<SackBlock>()
        while (i < raw.size) {
            val kind = raw[i].toInt() and 0xff
            when (kind) {
                0 -> break
                1 -> i += 1
                2 -> if (i + 4 <= raw.size && u8(raw[i + 1]) == 4) {
                    mss = u16(raw, i + 2)
                    i += 4
                } else break
                3 -> if (i + 3 <= raw.size && u8(raw[i + 1]) == 3) {
                    ws = u8(raw[i + 2]).coerceIn(0, 14)
                    i += 3
                } else break
                4 -> if (i + 2 <= raw.size && u8(raw[i + 1]) == 2) {
                    sack = true
                    i += 2
                } else break
                5 -> {
                    val len = if (i + 1 < raw.size) u8(raw[i + 1]) else 0
                    if (len < 10 || (len - 2) % 8 != 0 || i + len > raw.size) break
                    var p = i + 2
                    while (p + 8 <= i + len) {
                        sackBlocks += SackBlock(u32(raw, p), u32(raw, p + 4))
                        p += 8
                    }
                    i += len
                }
                8 -> if (i + 10 <= raw.size && u8(raw[i + 1]) == 10) {
                    tsVal = u32(raw, i + 2)
                    tsEcho = u32(raw, i + 6)
                    i += 10
                } else break
                else -> {
                    val len = if (i + 1 < raw.size) u8(raw[i + 1]) else 0
                    if (len < 2 || i + len > raw.size) break
                    i += len
                }
            }
        }
        return TcpOptions(mss, ws, sack, tsVal, tsEcho, sackBlocks)
    }

    fun synAck(localMss: Int, localWindowScale: Int, sackPermitted: Boolean, timestampValue: Long?, timestampEcho: Long?): ByteArray {
        val out = MutableBytes()
        out.add(option(2, byteArrayOf((localMss ushr 8).toByte(), localMss.toByte())))
        out.add(option(3, byteArrayOf(localWindowScale.coerceIn(0, 14).toByte())))
        if (sackPermitted) out.add(option(4, byteArrayOf()))
        if (timestampValue != null && timestampEcho != null) out.add(option(8, bytesOfU32(timestampValue) + bytesOfU32(timestampEcho)))
        return pad4(out.toByteArray())
    }

    fun timestamp(value: Long, echo: Long): ByteArray =
        pad4(option(8, bytesOfU32(value) + bytesOfU32(echo)))

    fun sack(blocks: List<SackBlock>): ByteArray {
        if (blocks.isEmpty()) return ByteArray(0)
        val b = blocks.take(3)
        val raw = MutableBytes()
        raw.add(5)
        raw.add((2 + 8 * b.size).toByte())
        b.forEach {
            raw.add(bytesOfU32(it.left)); raw.add(bytesOfU32(it.rightExclusive))
        }
        return pad4(raw.toByteArray())
    }

    fun ackOptions(timestampValue: Long?, timestampEcho: Long?, sacks: List<SackBlock>): ByteArray {
        val out = MutableBytes()
        if (timestampValue != null && timestampEcho != null) out.add(option(8, bytesOfU32(timestampValue) + bytesOfU32(timestampEcho)))
        if (sacks.isNotEmpty()) out.add(sack(sacks))
        return pad4(out.toByteArray())
    }

    private fun option(kind: Int, body: ByteArray): ByteArray = byteArrayOf(kind.toByte(), (body.size + 2).toByte()) + body

    private fun pad4(input: ByteArray): ByteArray {
        val size = (input.size + 3) and -4
        return input.copyOf(size)
    }

    private fun bytesOfU32(v: Long): ByteArray = byteArrayOf(
        (v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte()
    )

    private fun u8(b: Byte): Int = b.toInt() and 0xff
    private fun u16(b: ByteArray, o: Int): Int = (u8(b[o]) shl 8) or u8(b[o + 1])
    private fun u32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 0xff) shl 24) or ((b[o + 1].toLong() and 0xff) shl 16) or
            ((b[o + 2].toLong() and 0xff) shl 8) or (b[o + 3].toLong() and 0xff)

    private class MutableBytes {
        private val list = ArrayList<Byte>()
        fun add(bytes: ByteArray) { bytes.forEach(list::add) }
        fun add(value: Byte) { list.add(value) }
        fun add(value: Int) { list.add(value.toByte()) }
        fun toByteArray() = list.toByteArray()
    }
}
