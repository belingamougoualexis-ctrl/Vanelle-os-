package com.nexus.network

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

/** Authenticated content-addressed storage server. */
class NexusContentServer(private val context: android.content.Context) {
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "nexus-content-${System.nanoTime()}").apply { isDaemon = true } }
    @Volatile private var running = false
    private var server: ServerSocket? = null

    fun start() {
        if (running) return
        running = true
        pool.execute {
            runCatching {
                ServerSocket().use { s ->
                    s.reuseAddress = true
                    s.bind(InetSocketAddress("0.0.0.0", NexusConfig.CONTENT_PORT))
                    server = s
                    while (running) pool.execute { handle(s.accept()) }
                }
            }
        }
    }

    fun stop() {
        running = false
        runCatching { server?.close() }
        server = null
        pool.shutdownNow()
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            s.soTimeout = 20_000
            val input = BufferedInputStream(s.getInputStream())
            val output = BufferedOutputStream(s.getOutputStream())
            val hello = readLine(input) ?: return
            val fields = fields(hello)
            if (!hello.startsWith("NEXUS-CONTENT/1 HELLO")) return
            val nonce = fields["nonce"] ?: return
            val node = NexusCrypto.decode(fields["node"] ?: return)
            val key = NetworkKeyManager.accepted(context).firstOrNull { k ->
                NexusCrypto.constantTimeEquals(NexusCrypto.hmacHex(k, "v=1&type=hello&node=$node&nonce=$nonce"), fields["auth"].orEmpty())
            } ?: return
            val auth = NexusCrypto.hmacHex(key, "v=1&type=ok&node=${NexusIdentity.nodeId(context)}&nonce=$nonce")
            line(output, "NEXUS-CONTENT/1 OK v=1 node=${NexusCrypto.encode(NexusIdentity.nodeId(context))} nonce=$nonce auth=$auth")
            while (true) {
                when (val command = readLine(input) ?: break) {
                    "PING" -> line(output, "PONG")
                    "LIST-PINNED" -> {
                        val items = NexusContentStore.allPinned(context)
                        line(output, "PINNED ${items.size}")
                        items.forEach { line(output, "${it.hash} ${it.size} ${NexusCrypto.encode(it.name)}") }
                    }
                    else -> when {
                        command.startsWith("MANIFEST ") -> sendManifest(output, command.removePrefix("MANIFEST ").trim())
                        command.startsWith("GET ") -> sendChunk(input, output, command.removePrefix("GET ").trim())
                        command.startsWith("PUSH ") -> receivePush(input, output, command.removePrefix("PUSH ").trim())
                        command == "BYE" -> return
                    }
                }
            }
        }
    }

    private fun sendManifest(out: BufferedOutputStream, hash: String) {
        val m = NexusContentStore.manifest(context, hash)
        if (m == null) { line(out, "NOT-FOUND"); return }
        line(out, "MANIFEST-OK size=${m.size} chunkSize=${m.chunkSize} chunks=${m.chunks.size} name=${NexusCrypto.encode(m.name)} mime=${NexusCrypto.encode(m.mime)} pinned=${m.pinned}")
        line(out, NexusCrypto.encode(org.json.JSONObject().apply {
            put("hash", m.hash); put("size", m.size); put("chunkSize", m.chunkSize); put("chunks", org.json.JSONArray(m.chunks)); put("name", m.name); put("mime", m.mime); put("pinned", m.pinned)
        }.toString()))
    }

    private fun sendChunk(input: BufferedInputStream, out: BufferedOutputStream, arg: String) {
        val parts = arg.split(' ')
        if (parts.size != 2) { line(out, "ERROR invalid-request"); return }
        val bytes = NexusContentStore.chunk(context, parts[0], parts[1].toIntOrNull() ?: -1)
        if (bytes == null) { line(out, "NOT-FOUND"); return }
        line(out, "CHUNK-OK ${bytes.size}")
        out.write(bytes); out.flush()
    }

    private fun receivePush(input: BufferedInputStream, out: BufferedOutputStream, hash: String) {
        if (!NexusSettings.storageRelayEnabled(context)) { line(out, "REFUSED storage-disabled"); return }
        val manifestLine = readLine(input) ?: return
        if (!manifestLine.startsWith("PUSH-MANIFEST ")) { line(out, "ERROR missing-manifest"); return }
        val raw = runCatching { String(NexusCrypto.decodeBytes(manifestLine.removePrefix("PUSH-MANIFEST ")), Charsets.UTF_8) }.getOrNull() ?: run { line(out, "ERROR manifest"); return }
        val j = runCatching { org.json.JSONObject(raw) }.getOrNull() ?: run { line(out, "ERROR manifest-json"); return }
        val manifest = runCatching {
            NexusContentStore.Manifest(
                j.getString("hash"), j.getLong("size"), j.getInt("chunkSize"),
                List(j.getJSONArray("chunks").length()) { i -> j.getJSONArray("chunks").getString(i) },
                j.getString("name"), j.getString("mime"), true
            )
        }.getOrNull() ?: run { line(out, "ERROR manifest-data"); return }
        if (manifest.hash != hash || !hash.matches(Regex("[0-9a-f]{64}"))) { line(out, "ERROR hash"); return }
        if (manifest.chunkSize !in 1..NexusContentStore.CHUNK_SIZE || manifest.size !in 0..NexusSettings.storageQuotaBytes(context)) { line(out, "REFUSED storage-quota"); return }
        val currentBytes = NexusContentStore.usedBytes(context)
        if (currentBytes + manifest.size > NexusSettings.storageQuotaBytes(context) && !NexusContentStore.has(context, manifest.hash)) { line(out, "REFUSED storage-quota"); return }
        NexusContentStore.storeFetchedManifest(context, manifest)
        repeat(manifest.chunks.size) {
            val header = readLine(input) ?: throw IllegalStateException("chunk header absent")
            val parts = header.split(' ')
            if (parts.size != 3 || parts[0] != "PUSH-CHUNK") throw IllegalStateException("chunk header invalide")
            val index = parts[1].toIntOrNull() ?: throw IllegalStateException("chunk index")
            val length = parts[2].toIntOrNull()?.coerceIn(1, NexusContentStore.CHUNK_SIZE) ?: throw IllegalStateException("chunk length")
            val chunk = ByteArray(length); readFully(input, chunk)
            val expected = manifest.chunks.getOrNull(index) ?: throw IllegalStateException("chunk index")
            if (!NexusContentStore.writeChunk(context, manifest.hash, expected, chunk)) throw IllegalStateException("chunk hash invalide")
        }
        if (!NexusContentStore.verifyComplete(context, manifest.hash)) { line(out, "ERROR final-hash"); return }
        line(out, "PUSH-OK")
    }

    private fun readFully(input: BufferedInputStream, bytes: ByteArray) { var o = 0; while (o < bytes.size) { val n = input.read(bytes, o, bytes.size - o); if (n < 0) error("Flux contenu interrompu"); o += n } }
    private fun fields(line: String): Map<String,String> = line.split(' ').drop(2).mapNotNull { t -> val i=t.indexOf('='); if(i>0)t.substring(0,i) to t.substring(i+1) else null }.toMap()
    private fun line(out: BufferedOutputStream, value: String) { out.write(value.toByteArray(Charsets.US_ASCII)); out.write('\n'.code); out.flush() }
    private fun readLine(input: BufferedInputStream): String? { val b=ByteArray(8192); var n=0; while(n<b.size){ val x=input.read(); if(x<0)return if(n==0)null else String(b,0,n,Charsets.US_ASCII); if(x=='\n'.code)return String(b,0,n,Charsets.US_ASCII); if(x!='\r'.code)b[n++]=x.toByte() }; error("Ligne contenu trop longue") }
}
