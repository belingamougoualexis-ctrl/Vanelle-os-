package com.nexus.network

import android.content.Context
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Replicates signed DHT records across trusted peers so one node leaving does not erase a name entry. */
class NexusDhtReplicator(
    private val context: Context,
    private val dht: NexusDht,
    private val peersProvider: () -> List<NsdController.Peer>
) {
    private val pool = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "nexus-dht-replicator").apply { isDaemon = true } }
    @Volatile private var running = false

    fun start() {
        if (running) return
        running = true
        pool.scheduleWithFixedDelay({ replicateOnce() }, 10, 60, TimeUnit.SECONDS)
    }

    fun stop() { running = false; pool.shutdownNow() }

    fun replicateOnce() {
        if (!running) return
        val peers = peersProvider()
            .filter { it.host.isNotBlank() }
            .filter { NexusTrustStore.isAllowed(context, it.name) }
            .sortedByDescending { NexusTrustStore.reputation(context, it.name) }
            .take(8)
        if (peers.isEmpty()) return
        dht.recordsSnapshot().take(16).forEach { record ->
            peers.forEach { peer ->
                val ok = NxpProtocol.pushDhtRecord(peer.host, peer.port, record, { NetworkKeyManager.accepted(context) })
                if (ok) NexusTrustStore.reward(context, peer.name, 0.003) else NexusTrustStore.penalize(context, peer.name, 0.001)
            }
        }
    }
}
