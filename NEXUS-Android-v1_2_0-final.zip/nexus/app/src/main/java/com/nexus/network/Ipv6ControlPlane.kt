package com.nexus.network

import java.net.Inet6Address
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap

/** Real IPv6 control-plane implementation for the virtual NEXUS link. */
class Ipv6ControlPlane(
    private val virtualAddress: Inet6Address,
    private val linkLocal: Inet6Address,
    private val prefixLength: Int = 64,
    private val mtu: Int = 1500
) {
    data class Neighbor(val address: Inet6Address, var reachableUntil: Long, val router: Boolean)
    data class Group(val address: Inet6Address, var expiresAt: Long)

    private val neighbors = ConcurrentHashMap<String, Neighbor>()
    private val groups = ConcurrentHashMap<String, Group>()

    fun handle(src: Inet6Address, msg: Icmpv6.Message): ByteArray? {
        return when (msg.type) {
            Icmpv6.ECHO_REQUEST -> replyEcho(msg)
            Icmpv6.ROUTER_SOLICITATION -> routerAdvertisement()
            Icmpv6.NEIGHBOR_SOLICITATION -> neighborSolicitation(src, msg.body)
            Icmpv6.NEIGHBOR_ADVERTISEMENT -> neighborAdvertisement(src, msg.body)
            Icmpv6.MLD_QUERY -> handleMldQuery(msg.body)
            Icmpv6.MLD_REPORT_V1 -> handleMldV1Report(msg.body)
            Icmpv6.MLD_REPORT_V2 -> handleMldV2Report(msg.body)
            Icmpv6.MLD_DONE -> handleMldDone(msg.body)
            else -> null
        }
    }

    fun expire(now: Long = System.currentTimeMillis()) {
        neighbors.entries.removeIf { it.value.reachableUntil < now }
        groups.entries.removeIf { it.value.expiresAt < now }
    }

    fun neighborsSnapshot(): List<Neighbor> = neighbors.values.toList()
    fun groupsSnapshot(): List<Group> = groups.values.toList()

    private fun replyEcho(msg: Icmpv6.Message): ByteArray = Icmpv6.echoReply(msg)

    private fun routerAdvertisement(): ByteArray {
        // RFC 4861 RA: hop-limit 64, managed/other flags clear, lifetime 1800s,
        // one autonomous on-link /64 prefix for the NEXUS virtual link.
        val body = ByteArray(12 + 32)
        body[0] = 64.toByte() // Cur Hop Limit
        body[1] = 0          // flags
        IpPacket.putU16(body, 2, 1800)
        IpPacket.putU32(body, 4, 0) // reachable time
        IpPacket.putU32(body, 8, 0) // retrans timer
        // Prefix Information option, length 4 (32 bytes).
        body[12] = 3; body[13] = 4; body[14] = prefixLength.toByte(); body[15] = 0xc0.toByte()
        IpPacket.putU32(body, 16, 86400)
        IpPacket.putU32(body, 20, 14400)
        IpPacket.putU32(body, 24, 0)
        System.arraycopy(virtualAddress.address, 0, body, 28, 16)
        return Icmpv6.build(Icmpv6.ROUTER_ADVERTISEMENT, 0, body)
    }

    private fun neighborSolicitation(src: Inet6Address, body: ByteArray): ByteArray? {
        if (body.size < 20) return null
        val target = InetAddress.getByAddress(body.copyOfRange(4, 20)) as Inet6Address
        if (target != virtualAddress) return null
        neighbors[src.hostAddress] = Neighbor(src, System.currentTimeMillis() + 30_000, false)
        val na = ByteArray(20)
        IpPacket.putU32(na, 0, 0x60000000L) // solicited + override
        System.arraycopy(virtualAddress.address, 0, na, 4, 16)
        return Icmpv6.build(Icmpv6.NEIGHBOR_ADVERTISEMENT, 0, na)
    }

    private fun neighborAdvertisement(src: Inet6Address, body: ByteArray): ByteArray? {
        if (body.size < 20) return null
        val target = InetAddress.getByAddress(body.copyOfRange(4, 20)) as Inet6Address
        val flags = ((body[0].toInt() and 0xff) shl 24) or ((body[1].toInt() and 0xff) shl 16) or
            ((body[2].toInt() and 0xff) shl 8) or (body[3].toInt() and 0xff)
        neighbors[target.hostAddress] = Neighbor(src, System.currentTimeMillis() + 30_000, (flags and 0x80000000.toInt()) != 0)
        return null
    }

    private fun handleMldQuery(body: ByteArray): ByteArray? {
        // MLDv1 query: 24 bytes. Respond with reports for groups currently joined.
        if (body.size < 20) return null
        val records = groups.values.toList()
        if (records.isEmpty()) return null
        val group = records.first().address
        val mldBody = ByteArray(20)
        System.arraycopy(group.address, 0, mldBody, 4, 16)
        return Icmpv6.build(Icmpv6.MLD_REPORT_V1, 0, mldBody)
    }

    private fun handleMldV1Report(body: ByteArray): ByteArray? {
        if (body.size < 20) return null
        val group = InetAddress.getByAddress(body.copyOfRange(4, 20)) as Inet6Address
        groups[group.hostAddress] = Group(group, System.currentTimeMillis() + 260_000)
        return null
    }

    private fun handleMldV2Report(body: ByteArray): ByteArray? {
        if (body.size < 4) return null
        val count = IpPacket.u16(body, 2)
        var off = 4
        repeat(count) {
            if (off + 20 > body.size) return@repeat
            val auxLenWords = IpPacket.u8(body[off + 1])
            val sources = IpPacket.u16(body, off + 2)
            val recordLen = 20 + sources * 16 + auxLenWords * 4
            if (recordLen < 20 || off + recordLen > body.size) return@repeat
            val group = InetAddress.getByAddress(body.copyOfRange(off + 4, off + 20)) as Inet6Address
            groups[group.hostAddress] = Group(group, System.currentTimeMillis() + 260_000)
            off += recordLen
        }
        return null
    }

    private fun handleMldDone(body: ByteArray): ByteArray? {
        if (body.size < 20) return null
        val group = InetAddress.getByAddress(body.copyOfRange(4, 20)) as Inet6Address
        groups.remove(group.hostAddress)
        return null
    }
}
