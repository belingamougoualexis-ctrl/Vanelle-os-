package com.nexus.network

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.AnimationSet
import android.view.animation.DecelerateInterpolator
import android.view.animation.ScaleAnimation
import android.view.animation.TranslateAnimation
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.app.AlertDialog
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import android.net.wifi.p2p.WifiP2pDevice
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var networkText: TextView
    private lateinit var nodeText: TextView
    private lateinit var peersText: TextView
    private lateinit var gatewayText: TextView
    private lateinit var routeText: TextView
    private lateinit var p2pText: TextView
    private lateinit var transportText: TextView
    private lateinit var physicalText: TextView
    private lateinit var creditsText: TextView
    private lateinit var storageText: TextView
    private lateinit var autoConnectButton: Button
    private lateinit var gatewayButton: Button
    private lateinit var transitButton: Button
    private lateinit var vpnButton: Button
    private lateinit var networkKeyInput: EditText
    private lateinit var bootstrapText: TextView
    private lateinit var trustText: TextView
    private lateinit var homeSummaryText: TextView
    private lateinit var diagnosisText: TextView
    private lateinit var tabAccueil: TextView
    private lateinit var tabReseau: TextView
    private lateinit var tabSecurite: TextView
    private lateinit var tabActivite: TextView
    private lateinit var tabParametres: TextView
    private lateinit var pageAccueil: LinearLayout
    private lateinit var pageReseau: LinearLayout
    private lateinit var pageSecurite: LinearLayout
    private lateinit var pageActivite: LinearLayout
    private lateinit var pageParametres: LinearLayout
    private lateinit var allPages: List<LinearLayout>
    private lateinit var allTabs: List<TextView>
    private lateinit var rootFrame: FrameLayout
    private lateinit var mainContent: LinearLayout
    private lateinit var discovery: NsdController
    private lateinit var p2p: WifiDirectController
    private var gatewayEnabled = false
    private var transitEnabled = false
    private var currentPageIndex = 0
    private var pageSwitchGeneration = 0
    private val peerRows = mutableListOf<NsdController.Peer>()
    private val p2pRows = mutableListOf<WifiP2pDevice>()

    private val prefs: SharedPreferences by lazy {
        getSharedPreferences("nexus_ui", MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "NEXUS"
        gatewayEnabled = NexusSettings.gatewayEnabled(this)
        transitEnabled = NexusSettings.transitEnabled(this)
        discovery = NsdController(this)
        p2p = WifiDirectController(this)
        buildUi()
        playOpeningAnimation {
            if (!isNetworkParticipationAccepted()) {
                showActivationGate()
            } else {
                startActivatedSession()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshNetwork()
        if (isNetworkParticipationAccepted()) {
            startDiscovery()
            p2p.start()
        }
    }

    private fun isNetworkParticipationAccepted(): Boolean =
        prefs.getBoolean("activation_accepted", false)

    private fun startActivatedSession() {
        requestPermissionsSequentially {
            startNodeService()
            startDiscovery()
            refreshAll()
            if (!prefs.getBoolean("onboarding_done", false)) {
                showOnboarding()
            }
        }
    }

    override fun onDestroy() {
        discovery.close()
        p2p.stop()
        super.onDestroy()
    }

    private fun buildUi() {
        rootFrame = FrameLayout(this).apply {
            setBackgroundColor(getColor(R.color.nexus_background))
        }
        setContentView(rootFrame)

        mainContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.nexus_background))
            alpha = 0f
        }
        rootFrame.addView(mainContent, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        // Header style photo : logo + titre côte à côte
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(20), dp(16), dp(8))
            setBackgroundColor(getColor(R.color.nexus_surface))
        }
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val logo = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher_foreground)
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply {
                marginEnd = dp(10)
                gravity = Gravity.CENTER_VERTICAL
            }
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleCol.addView(label("NEXUS", 24, true).apply {
            setTextColor(getColor(R.color.nexus_text_primary))
            setPadding(0, 0, 0, 0)
        })
        titleCol.addView(label("Réseau de résilience  ·  v${NexusConfig.VERSION}", 11, false).apply {
            setPadding(0, 0, 0, 0)
        })
        titleRow.addView(logo)
        titleRow.addView(titleCol)
        header.addView(titleRow)
        mainContent.addView(header)

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            isFillViewport = true
        }
        val pages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
        }
        scroll.addView(pages)
        mainContent.addView(scroll)

        pageAccueil = pageContainer()
        pageReseau = pageContainer()
        pageSecurite = pageContainer()
        pageActivite = pageContainer()
        pageParametres = pageContainer()
        allPages = listOf(pageAccueil, pageReseau, pageSecurite, pageActivite, pageParametres)
        allPages.forEach { pages.addView(it) }

        // Bottom nav style photo (icônes + labels)
        val tabBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundResource(R.drawable.bg_tab_bar)
            setPadding(dp(4), dp(6), dp(4), dp(10))
            elevation = dp(4).toFloat()
        }
        tabAccueil = tabItemIcon("⌂", "Accueil") { showPage(pageAccueil, tabAccueil) }
        tabReseau = tabItemIcon("⇄", "Réseau") { showPage(pageReseau, tabReseau) }
        tabSecurite = tabItemIcon("⛨", "Sécurité") { showPage(pageSecurite, tabSecurite) }
        tabActivite = tabItemIcon("▤", "Activité") { showPage(pageActivite, tabActivite) }
        tabParametres = tabItemIcon("⚙", "Paramètres") { showPage(pageParametres, tabParametres) }
        allTabs = listOf(tabAccueil, tabReseau, tabSecurite, tabActivite, tabParametres)
        allTabs.forEach { tabBar.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        mainContent.addView(tabBar)

        // ---------------- ACCUEIL ----------------
        homeSummaryText = label("Chargement…", 14, false)
        pageAccueil.addView(sectionCard("Résumé", homeSummaryText))
        autoConnectButton = primaryButton("Se connecter automatiquement") { connectAutomatically() }
        pageAccueil.addView(autoConnectButton)
        pageAccueil.addView(label("Démarre le nœud, recherche les appareils proches et choisit une route disponible.", 12, false))
        statusText = label("Initialisation…", 14, false)
        pageAccueil.addView(sectionCard("État du nœud", statusText))

        diagnosisText = label("Analyse en cours…", 13, false)
        val diagnosisCard = sectionContainer()
        diagnosisCard.addView(sectionTitle("Diagnostic"))
        diagnosisCard.addView(diagnosisText)
        diagnosisCard.addView(outlineButton("Actualiser le diagnostic") { runIntelligentDiagnosis() })
        pageAccueil.addView(diagnosisCard)

        val vpnCard = sectionContainer()
        vpnCard.addView(sectionTitle("Tunnel sécurisé"))
        vpnCard.addView(label("Optionnel. Route le trafic de vos applications via le réseau NEXUS, de façon chiffrée.", 12, false))
        vpnButton = outlineButton("") {}
        vpnCard.addView(vpnButton)
        pageAccueil.addView(vpnCard)

        // ---------------- RÉSEAU ----------------
        networkText = label("Chargement…", 14, false)
        pageReseau.addView(sectionCard("Connexion", networkText))
        transportText = label("Chargement…", 13, false)
        pageReseau.addView(sectionCard("Réseaux disponibles", transportText))
        val physicalCard = sectionContainer()
        physicalCard.addView(sectionTitle("Liaisons utilisées"))
        physicalText = label("Chargement…", 13, false)
        physicalCard.addView(physicalText)
        physicalCard.addView(label("NEXUS s’appuie sur le Wi‑Fi, les données mobiles ou une connexion filaire déjà présentes sur l’appareil.", 12, false))
        pageReseau.addView(physicalCard)
        nodeText = label("Chargement…", 14, false)
        pageReseau.addView(sectionCard("Identité", nodeText))
        val routeCard = sectionContainer()
        routeCard.addView(sectionTitle("Itinéraire"))
        routeText = label("Chargement…", 14, false)
        routeCard.addView(routeText)
        routeCard.addView(label("Les données transitent de nœud en nœud jusqu’à une sortie Internet validée, lorsqu’elle est disponible.", 12, false))
        pageReseau.addView(routeCard)
        val gatewayOpsCard = sectionContainer()
        gatewayOpsCard.addView(sectionTitle("Passerelle et partage"))
        gatewayText = label("", 14, false)
        gatewayOpsCard.addView(gatewayText)
        gatewayButton = outlineButton("") { toggleGateway() }
        gatewayOpsCard.addView(gatewayButton)
        transitButton = outlineButton("") { toggleTransit() }
        gatewayOpsCard.addView(transitButton)
        gatewayOpsCard.addView(outlineButton("Tester Internet") { testGateway() })
        pageReseau.addView(gatewayOpsCard)
        peersText = label("Recherche…", 14, false)
        pageReseau.addView(sectionCard("Appareils NEXUS proches", peersText))
        pageReseau.addView(outlineButton("Tester la connexion aux appareils") { testPeers() })
        pageReseau.addView(outlineButton("Mesurer le débit") { measurePeerBandwidth() })
        p2pText = label("Recherche…", 14, false)
        pageReseau.addView(sectionCard("Connexion directe (Wi‑Fi Direct)", p2pText))
        pageReseau.addView(outlineButton("Relancer la recherche") { p2p.discover() })
        pageReseau.addView(label("Les appareils proches peuvent se relayer entre eux lorsque le réseau le permet.", 12, false))

        // ---------------- SÉCURITÉ ----------------
        val securityCard = sectionContainer()
        securityCard.addView(sectionTitle("Sécurité"))
        securityCard.addView(label("Définissez une clé partagée avec les personnes de confiance (minimum 8 caractères).", 12, false))
        networkKeyInput = EditText(this).apply {
            hint = "Clé réseau (8 caractères minimum)"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText("")
            setBackgroundResource(R.drawable.bg_input)
            setTextColor(getColor(R.color.nexus_text_primary))
        }
        securityCard.addView(networkKeyInput)
        securityCard.addView(outlineButton("Enregistrer la clé") {
            val key = networkKeyInput.text.toString().trim()
            if (key.length < 8) {
                Toast.makeText(this@MainActivity, "La clé doit contenir au moins 8 caractères.", Toast.LENGTH_SHORT).show()
            } else {
                NexusIdentity.setNetworkKey(this@MainActivity, key)
                startNodeService()
                Toast.makeText(this@MainActivity, "Clé enregistrée.", Toast.LENGTH_SHORT).show()
            }
        })
        securityCard.addView(outlineButton("Ajouter un point d’entrée distant") { addRemoteBootstrap() })
        bootstrapText = label("Chargement…", 12, false)
        securityCard.addView(bootstrapText)
        securityCard.addView(outlineButton("Mode confiance renforcée") {
            NexusSettings.setTrustedOnly(this@MainActivity, !NexusSettings.trustedOnly(this@MainActivity))
            refreshSecurity()
            startNodeService()
        })
        securityCard.addView(outlineButton("Gérer les appareils de confiance") { manageTrustedPeers() })
        trustText = label("Chargement…", 12, false)
        securityCard.addView(trustText)
        securityCard.addView(outlineButton("Renouveler la clé") {
            sendAction(NexusConfig.ACTION_ROTATE_KEY, true)
            Toast.makeText(this@MainActivity, "Renouvellement demandé. L’ancienne clé reste valable le temps de la transition.", Toast.LENGTH_LONG).show()
            thread(start = true, name = "nexus-key-refresh") {
                Thread.sleep(250)
                runOnUiThread { refreshGateway() }
            }
        })
        pageSecurite.addView(securityCard)

        // ---------------- ACTIVITÉ ----------------
        val resourceCard = sectionContainer()
        resourceCard.addView(sectionTitle("Ressources"))
        creditsText = label("Chargement…", 13, false)
        resourceCard.addView(creditsText)
        resourceCard.addView(outlineButton("Importer un fichier") { chooseContentFile() })
        resourceCard.addView(outlineButton("Stockage partagé") {
            NexusSettings.setStorageRelayEnabled(this@MainActivity, !NexusSettings.storageRelayEnabled(this@MainActivity))
            refreshResources()
        })
        resourceCard.addView(outlineButton("Limite de crédits") {
            NexusSettings.setCreditsEnforced(this@MainActivity, !NexusSettings.creditsEnforced(this@MainActivity))
            refreshResources()
        })
        storageText = label("Chargement…", 13, false)
        resourceCard.addView(storageText)
        pageActivite.addView(resourceCard)

        // ---------------- PARAMÈTRES ----------------
        val settingsCard = sectionContainer()
        settingsCard.addView(sectionTitle("Réglages"))
        settingsCard.addView(outlineButton("Limite de partage de connexion") { editRelayLimit() })
        settingsCard.addView(outlineButton("Quota journalier") { editRelayQuota() })
        settingsCard.addView(outlineButton("Nombre de copies (réplication)") { editReplicationFactor() })
        settingsCard.addView(outlineButton("Réglages réseau du téléphone") { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) })
        settingsCard.addView(outlineButton("Partager l’application") { startActivity(Intent.createChooser(NexusAppTransfer.shareIntent(this@MainActivity), "Partager NEXUS")) })
        settingsCard.addView(outlineButton("Envoyer l’application à un appareil NEXUS") { choosePeerForApk() })
        pageParametres.addView(settingsCard)

        val legalCard = sectionContainer()
        legalCard.addView(sectionTitle("Informations légales"))
        legalCard.addView(label("Éditeur : NEXUS\nContact : monsieurmoi68@gmail.com\nVersion ${NexusConfig.VERSION}", 13, false))
        legalCard.addView(outlineButton("Politique de confidentialité") { showPrivacyPolicy() })
        legalCard.addView(outlineButton("Conditions d’utilisation") { showTermsOfUse() })
        legalCard.addView(outlineButton("Nous contacter") {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = android.net.Uri.parse("mailto:monsieurmoi68@gmail.com")
                putExtra(Intent.EXTRA_SUBJECT, "NEXUS — contact")
            }
            runCatching { startActivity(intent) }
                .onFailure { Toast.makeText(this, "Écrivez à monsieurmoi68@gmail.com", Toast.LENGTH_LONG).show() }
        })
        legalCard.addView(outlineButton("Revoir le guide d’utilisation") {
            prefs.edit().putBoolean("onboarding_done", false).apply()
            showOnboarding()
        })
        pageParametres.addView(legalCard)

        showPage(pageAccueil, tabAccueil)
        updateButtons()
        updateVpnButton()
    }

    // ---- Design system helpers (cartes, boutons, onglets) ----

    private fun pageContainer(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        visibility = View.GONE
    }

    private fun sectionContainer(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(18), dp(18), dp(18))
        setBackgroundResource(R.drawable.bg_card)
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(12)
        }
        elevation = dp(1).toFloat()
    }

    private fun sectionTitle(text: String): TextView = label(text, 16, true).apply {
        setPadding(0, 0, 0, dp(6))
    }

    private fun sectionCard(title: String, body: TextView): LinearLayout = sectionContainer().apply {
        addView(sectionTitle(title))
        addView(body)
    }

    private fun primaryButton(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 15f
        setTextColor(getColor(R.color.nexus_surface))
        setBackgroundResource(R.drawable.bg_button_primary)
        setPadding(dp(18), dp(16), dp(18), dp(16))
        elevation = dp(2).toFloat()
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6); bottomMargin = dp(10)
        }
        setOnClickListener { onClick() }
    }

    private fun outlineButton(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 14f
        setTextColor(getColor(R.color.nexus_primary))
        setBackgroundResource(R.drawable.bg_button_outline)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        elevation = 0f
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(4); bottomMargin = dp(6)
        }
        setOnClickListener { onClick() }
    }

    private fun tabItemIcon(icon: String, text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = "$icon\n$text"
        textSize = 11f
        gravity = Gravity.CENTER
        setPadding(dp(2), dp(8), dp(2), dp(8))
        setTextColor(getColor(R.color.nexus_text_secondary))
        setLineSpacing(dp(2).toFloat(), 1f)
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun highlightTabs(selected: TextView) {
        allTabs.forEach {
            val isSelected = it === selected
            if (isSelected) it.setBackgroundResource(R.drawable.bg_tab_selected)
            else it.background = null
            it.setTextColor(getColor(if (isSelected) R.color.nexus_primary else R.color.nexus_text_secondary))
        }
    }

    private fun showPage(target: LinearLayout, selected: TextView) {
        val newIndex = allPages.indexOf(target).coerceAtLeast(0)
        if (newIndex == currentPageIndex && target.visibility == View.VISIBLE) {
            highlightTabs(selected)
            return
        }
        val goingRight = newIndex > currentPageIndex
        val switchToken = ++pageSwitchGeneration

        allPages.forEach { page ->
            page.clearAnimation()
            if (page === target) {
                page.visibility = View.VISIBLE
                val set = AnimationSet(true).apply {
                    interpolator = AccelerateDecelerateInterpolator()
                    duration = 220
                    fillAfter = true
                    addAnimation(
                        TranslateAnimation(
                            Animation.RELATIVE_TO_SELF, if (goingRight) 0.08f else -0.08f,
                            Animation.RELATIVE_TO_SELF, 0f,
                            Animation.RELATIVE_TO_SELF, 0f,
                            Animation.RELATIVE_TO_SELF, 0f
                        )
                    )
                    addAnimation(AlphaAnimation(0.4f, 1f))
                }
                page.startAnimation(set)
            } else if (page.visibility == View.VISIBLE) {
                val fadeOut = AlphaAnimation(1f, 0f).apply {
                    duration = 120
                    fillAfter = true
                    setAnimationListener(object : Animation.AnimationListener {
                        override fun onAnimationStart(a: Animation?) {}
                        override fun onAnimationRepeat(a: Animation?) {}
                        override fun onAnimationEnd(a: Animation?) {
                            // Only hide if no newer page switch has started
                            if (switchToken == pageSwitchGeneration && page !== target) {
                                page.visibility = View.GONE
                                page.clearAnimation()
                            }
                        }
                    })
                }
                page.startAnimation(fadeOut)
            } else {
                page.visibility = View.GONE
            }
        }

        highlightTabs(selected)
        currentPageIndex = newIndex
    }

    private fun startNodeService() {
        if (!isNetworkParticipationAccepted()) {
            if (::statusText.isInitialized) {
                statusText.text = "NEXUS non activé. Acceptez les conditions de participation pour démarrer."
            }
            return
        }
        NexusSettings.setGateway(this, gatewayEnabled)
        NexusSettings.setTransit(this, transitEnabled)
        val intent = Intent(this, NexusNodeService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        if (::statusText.isInitialized) statusText.text = "Service démarré."
    }

    private fun toggleGateway() {
        gatewayEnabled = !gatewayEnabled
        NexusSettings.setGateway(this, gatewayEnabled)
        sendAction(NexusConfig.ACTION_GATEWAY, gatewayEnabled)
        updateButtons()
        refreshGateway()
        refreshRoute()
    }

    private fun toggleTransit() {
        transitEnabled = !transitEnabled
        NexusSettings.setTransit(this, transitEnabled)
        sendAction(NexusConfig.ACTION_TRANSIT, transitEnabled)
        updateButtons()
        refreshRoute()
    }

    private fun sendAction(action: String, enabled: Boolean) {
        val intent = Intent(this, NexusNodeService::class.java).apply {
            this.action = action
            putExtra(NexusConfig.EXTRA_ENABLED, enabled)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun startDiscovery() {
        discovery.onChanged = { peers ->
            runOnUiThread {
                peerRows.clear()
                peerRows.addAll(peers.filter { it.name != NexusIdentity.nodeId(this) })
                updatePeersText()
                refreshRoute()
            }
        }
        runCatching { discovery.startDiscovery() }
        p2p.onDevicesChanged = { devices ->
            runOnUiThread {
                p2pRows.clear()
                p2pRows.addAll(devices)
                updateP2pText()
                discovery.refreshP2pEndpoints()
                refreshRoute()
            }
        }
        p2p.onStatus = { message ->
            runOnUiThread { p2pText.text = message }
        }
        p2p.start()
    }

    private fun refreshAll() {
        refreshNetwork()
        refreshPhysicalBackhaul()
        refreshNode()
        refreshGateway()
        refreshRoute()
        updatePeersText()
        updateP2pText()
        updateVpnButton()
        refreshResources()
        refreshSecurity()
        runIntelligentDiagnosis()
    }

    private fun refreshNetwork() {
        val snapshot = NetworkInspector.snapshot(this)
        if (!snapshot.connected) {
            networkText.text = emptyState(
                title = "Aucun réseau actif",
                body = "• Activez le Wi‑Fi ou les données mobiles\n• Vérifiez le mode Avion\n• Acceptez les permissions demandées",
                actionHint = "Sans réseau, NEXUS reste limité à cet appareil."
            )
        } else {
            val validation = when {
                snapshot.validated -> "Internet disponible"
                else -> "Connecté au réseau local"
            }
            networkText.text = "État : $validation\nType : ${snapshot.transport}" +
                (snapshot.linkSpeedMbps?.let { "\nDébit annoncé : $it Mbps" } ?: "")
        }
        transportText.text = NexusTransportManager(this).humanSummary()
        statusText.text = if (snapshot.validated) {
            "Sortie Internet disponible."
        } else if (snapshot.connected) {
            "Nœud actif. Sortie Internet non confirmée."
        } else {
            "Hors ligne. Activez le Wi‑Fi ou les données mobiles."
        }
        refreshHomeSummary(snapshot)
        runIntelligentDiagnosis()
    }

    private fun refreshHomeSummary(snapshot: NetworkSnapshot = NetworkInspector.snapshot(this)) {
        val connectivity = when {
            snapshot.validated -> "Connecté • Internet validé"
            snapshot.connected -> "Connecté au réseau local • Internet non validé"
            else -> "Non connecté"
        }
        val gw = if (gatewayEnabled) "activée" else "désactivée"
        val tr = if (transitEnabled) "activé" else "désactivé"
        homeSummaryText.text =
            "$connectivity\n" +
            "Transport actuel : ${snapshot.transport}\n" +
            "Appareils détectés : ${peerRows.size}\n" +
            "Passerelle : $gw  •  Partage : $tr"
    }

    private fun refreshPhysicalBackhaul() {
        val detector = NexusPhysicalBackhaul(this)
        val summary = detector.globalCapabilitySummary() + "\n" + detector.physicalSummary()
        physicalText.text = if (summary.isBlank() || summary.contains("aucun", ignoreCase = true)) {
            emptyState(
                title = "Aucune connexion réseau détectée",
                body = "Activez le Wi‑Fi ou les données mobiles pour que NEXUS puisse fonctionner.",
                actionHint = "Vous pouvez aussi brancher une connexion filaire si votre appareil le permet."
            )
        } else {
            summary
        }
    }

    private fun refreshNode() {
        val name = NexusNaming.own(this, emptyList()).name
        nodeText.text = "Identifiant : ${NexusIdentity.nodeId(this)}\nNom : $name"
    }

    private fun refreshGateway() {
        val validated = NetworkInspector.snapshot(this).validated
        gatewayText.text = if (gatewayEnabled) {
            if (validated) "Passerelle active — sortie Internet disponible."
            else "Passerelle activée — sortie Internet non confirmée pour le moment."
        } else {
            "Passerelle désactivée. Vous pouvez toujours partager la connexion en mode transit."
        }
    }

    private fun refreshRoute() {
        val router = MeshRouter(NexusIdentity.nodeId(this), { discovery.peersSnapshot() }) { peer -> NexusTrustStore.reputation(this, peer.name) }
        val summary = router.summary(gatewayEnabled, transitEnabled)
        routeText.text = if (peerRows.isEmpty() && !gatewayEnabled) {
            emptyState(
                title = "Aucun itinéraire disponible",
                body = "Aucun appareil NEXUS à proximité et aucune passerelle active.\n\n• Activez la passerelle si vous avez Internet\n• Ou rapprochez-vous d’autres utilisateurs NEXUS\n• Ou ajoutez un point d’entrée distant dans Sécurité",
                actionHint = ""
            )
        } else {
            summary
        }
    }

    private fun updateButtons() {
        gatewayButton.text = if (gatewayEnabled) "Désactiver la passerelle" else "Activer la passerelle"
        transitButton.text = if (transitEnabled) "Désactiver le partage de connexion" else "Activer le partage de connexion"
        if (::homeSummaryText.isInitialized) refreshHomeSummary()
    }

    private fun updatePeersText() {
        if (peerRows.isEmpty()) {
            peersText.text = emptyState(
                title = "Aucun appareil à proximité",
                body = "Aucun autre téléphone avec NEXUS n’a été trouvé sur ce réseau.\n\n• Vérifiez le Wi‑Fi\n• Demandez à quelqu’un d’ouvrir NEXUS à côté de vous\n• Ou ajoutez un point d’entrée distant dans Sécurité",
                actionHint = "Astuce : utilisez « Se connecter automatiquement » sur Accueil."
            )
            refreshHomeSummary()
            runIntelligentDiagnosis()
            return
        }
        peersText.text = peerRows.joinToString("\n\n") { peer ->
            val distance = if (peer.gatewayDistance == Int.MAX_VALUE) "∞" else peer.gatewayDistance.toString()
            val path = peer.gatewayPath.takeIf { it.isNotEmpty() }?.joinToString(" → ") ?: "chemin en découverte"
            "${peer.name}\n${peer.host}:${peer.port}\npasserelle=${peer.gateway} • transit=${peer.relay}\ndistance annoncée=$distance • chemin=$path • ${if (peer.latencyMs.isFinite()) String.format(Locale.US, "%.1f ms", peer.latencyMs) else "latence inconnue"}"
        }
        refreshHomeSummary()
        runIntelligentDiagnosis()
    }

    private fun updateP2pText() {
        if (p2pRows.isEmpty()) {
            p2pText.text = emptyState(
                title = "Aucun appareil en connexion directe",
                body = "• Activez le Wi‑Fi\n• Autorisez la proximité si Android le demande\n• Rapprochez les téléphones\n• Appuyez sur « Relancer la recherche »",
                actionHint = "La connexion directe est optionnelle."
            )
            return
        }
        val body = p2pRows.joinToString("\n") { it.deviceName.ifBlank { it.deviceAddress } }
        p2pText.text = "$body\n\nAppuie sur un appareil pour demander une connexion P2P."
        // A compact row of buttons keeps the screen usable on phones without requiring RecyclerView.
        val parent = p2pText.parent as? LinearLayout ?: return
        parent.childrenButtons().forEach { parent.removeView(it) }
        p2pRows.forEach { device ->
            parent.addView(outlineButton("Connecter • ${device.deviceName.ifBlank { device.deviceAddress }}") {
                p2p.connect(device)
                Toast.makeText(this@MainActivity, "Connexion Wi‑Fi Direct demandée.", Toast.LENGTH_SHORT).show()
            })
        }
    }

    private fun LinearLayout.childrenButtons(): List<Button> =
        (0 until childCount).map { getChildAt(it) }.filterIsInstance<Button>()

    private fun refreshResources() {
        creditsText.text =
            "Crédits disponibles : ${NexusCredits.balance(this)}\n" +
            "Limite stricte : ${if (NexusSettings.creditsEnforced(this)) "oui" else "non"}\n" +
            "Partage de connexion : ${if (transitEnabled) "actif" else "inactif"}\n" +
            "Limite : ${String.format(Locale.US, "%.1f", NexusSettings.relayLimitMbps(this))} Mb/s  •  Quota journalier : ${NexusSettings.relayDailyLimitBytes(this) / (1024L * 1024L)} Mo"
        val pinned = NexusContentStore.allPinned(this).size
        storageText.text = if (pinned == 0) {
            emptyState(
                title = "Aucun fichier enregistré",
                body = "Importez un fichier pour le conserver localement.\nLe stockage partagé est ${if (NexusSettings.storageRelayEnabled(this)) "activé" else "désactivé"}.",
                actionHint = ""
            )
        } else {
            "Stockage partagé : ${if (NexusSettings.storageRelayEnabled(this)) "activé" else "désactivé"}\nFichiers enregistrés : $pinned"
        }
    }

    private fun addRemoteBootstrap() {
        val input = EditText(this).apply {
            hint = "hôte:45454 ou nexus://hôte:45454"
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Point d’entrée distant")
            .setMessage("Ajoutez uniquement un appareil NEXUS de confiance, ou une adresse fournie par votre organisation. NEXUS ne crée pas de serveur mondial automatiquement.")
            .setView(input)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Ajouter") { _, _ ->
                val value = input.text.toString().trim()
                val existing = NexusSettings.bootstrapPeers(this)
                NexusSettings.setBootstrapPeers(this, existing + value)
                parseBootstrap(value)?.let { (host, port) -> discovery.addRemotePeer(host, port) }
                refreshSecurity()
                Toast.makeText(this, "Point d’entrée enregistré.", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun parseBootstrap(value: String): Pair<String, Int>? = NexusInterop.parse(value)?.let { it.host to it.port }

    private fun manageTrustedPeers() {
        val peers = peerRows.distinctBy { it.name }.sortedBy { it.name }
        if (peers.isEmpty()) {
            Toast.makeText(this, "Aucun appareil découvert à autoriser.", Toast.LENGTH_SHORT).show()
            return
        }
        val current = NexusSettings.trustedPeerIds(this).toMutableSet()
        val names = peers.map { it.name }.toTypedArray()
        val checked = peers.map { current.contains(it.name) }.toBooleanArray()
        AlertDialog.Builder(this)
            .setTitle("Nœuds autorisés")
            .setMultiChoiceItems(names, checked) { _, which, isChecked ->
                val node = peers[which].name
                if (isChecked) current.add(node) else current.remove(node)
            }
            .setNegativeButton("Fermer", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                NexusSettings.setTrustedPeerIds(this, current)
                refreshSecurity()
                discovery.probeAll()
            }.show()
    }

    private fun refreshSecurity() {
        val trusted = NexusSettings.trustedPeerIds(this).size
        trustText.text = if (NexusSettings.trustedOnly(this)) {
            "Mode confiance renforcée activé. Appareils autorisés : $trusted"
        } else {
            "Mode ouvert avec vérification progressive. Appareils explicitement autorisés : $trusted"
        }
        bootstrapText.text = NexusSettings.bootstrapPeers(this).let { peers ->
            if (peers.isEmpty()) {
                emptyState(
                    title = "Aucun point d’entrée distant",
                    body = "Seule la recherche locale est active.\nAjoutez une adresse fournie par votre organisation si besoin.",
                    actionHint = ""
                )
            } else {
                "Points d’entrée : ${peers.joinToString(" • ")}"
            }
        }
    }

    private fun editRelayLimit() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            setText(String.format(Locale.US, "%.1f", NexusSettings.relayLimitMbps(this@MainActivity)))
            hint = "Mb/s"
        }
        AlertDialog.Builder(this)
            .setTitle("Limite de débit de transit")
            .setMessage("Cette limite s’applique au trafic relayé en arrière-plan.")
            .setView(input)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                val value = input.text.toString().replace(',', '.').toDoubleOrNull()
                if (value != null) NexusSettings.setRelayLimitMbps(this, value)
                refreshResources()
            }.show()
    }

    private fun editRelayQuota() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setText((NexusSettings.relayDailyLimitBytes(this@MainActivity) / (1024L * 1024L)).toString())
            hint = "Mo / jour"
        }
        AlertDialog.Builder(this)
            .setTitle("Quota journalier de transit")
            .setMessage("0 = sans quota journalier. Le contrôle de débit et la batterie restent actifs.")
            .setView(input)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                val value = input.text.toString().toLongOrNull()
                if (value != null) NexusSettings.setRelayDailyLimitMb(this, value)
                refreshResources()
            }.show()
    }

    private fun connectAutomatically() {
        if (!isNetworkParticipationAccepted()) {
            showActivationGate()
            return
        }
        startNodeService()
        startDiscovery()
        startVpnConsentFlow()
        updateButtons()
        Toast.makeText(this, "NEXUS recherche une route disponible. Le partage reste optionnel.", Toast.LENGTH_LONG).show()
    }

    private fun editReplicationFactor() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setText(NexusSettings.replicationFactor(this@MainActivity).toString())
            hint = "1 à 8 appareils"
        }
        AlertDialog.Builder(this)
            .setTitle("Nombre de copies")
            .setMessage("Nombre maximum d’appareils sur lesquels un fichier peut être copié.")
            .setView(input)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                input.text.toString().toIntOrNull()?.let { NexusSettings.setReplicationFactor(this, it) }
                refreshResources()
            }.show()
    }

    private fun choosePeerForApk() {
        val peers = peerRows.filter { it.host.isNotBlank() }
        if (peers.isEmpty()) { Toast.makeText(this, "Aucun nœud NEXUS joignable.", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Envoyer NEXUS à")
            .setItems(peers.map { it.name }.toTypedArray()) { _, which ->
                val peer = peers[which]
                Toast.makeText(this, "Transfert APK vers ${peer.name}…", Toast.LENGTH_SHORT).show()
                thread(start=true,name="nexus-apk-send") {
                    val result=NexusAppTransferClient.send(this, peer.host)
                    runOnUiThread { Toast.makeText(this, result.fold({ "APK reçu par ${peer.name}" }, { "Échec : ${it.message ?: "transfert"}" }), Toast.LENGTH_LONG).show() }
                }
            }.show()
    }

    private fun chooseContentFile() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 812)
    }

    private fun importContent(uri: android.net.Uri) {
        thread(start=true,name="nexus-content-import") {
            val temp=File(cacheDir,"nexus-import-${System.nanoTime()}")
            runCatching { contentResolver.openInputStream(uri).use { input -> requireNotNull(input); temp.outputStream().use { out -> input.copyTo(out) } }; val name=queryDisplayName(uri) ?: "contenu"; val manifest=NexusContentStore.putFile(this,temp,name); val peers=peerRows.filter { it.host.isNotBlank() && it.relay }; peers.take(3).forEach { NexusContentClient.push(it.host,this,manifest.hash) }; temp.delete(); manifest }
                .onSuccess { _ -> runOnUiThread { refreshResources(); Toast.makeText(this, "Fichier enregistré. Une copie pourra être proposée aux appareils autorisés.", Toast.LENGTH_LONG).show() } }
                .onFailure { e -> temp.delete(); runOnUiThread { Toast.makeText(this, "Import impossible. Réessayez ou choisissez un autre fichier.", Toast.LENGTH_LONG).show() } }
        }
    }

    private fun queryDisplayName(uri: android.net.Uri): String? = contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

    private fun testGateway() {
        if (!gatewayEnabled) {
            Toast.makeText(this, "Active d’abord la passerelle.", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Test Internet réel…", Toast.LENGTH_SHORT).show()
        thread(start = true, name = "nexus-gateway-test") {
            val result = GatewayTester.test()
            runOnUiThread { Toast.makeText(this, result.detail, Toast.LENGTH_LONG).show() }
        }
    }

    private fun testPeers() {
        if (peerRows.isEmpty()) {
            Toast.makeText(this, "Aucun nœud à tester.", Toast.LENGTH_SHORT).show()
            return
        }
        val snapshot = peerRows.toList()
        thread(start = true, name = "nexus-peer-test") {
            val results = snapshot.map { peer ->
                runCatching {
                    val result = NxpProtocol.measurePeer(peer.host, peer.port) { NetworkKeyManager.accepted(this) }.getOrThrow()
                    discovery.updateCapabilities(
                        peer.name, peer.gateway, peer.relay, peer.gatewayDistance, peer.gatewayPath,
                        result.latencyMs, result.packetLossPct, peer.bandwidthMbps, success = true
                    )
                    "${peer.name}: ${String.format(Locale.US, "%.1f", result.latencyMs)} ms • perte ${String.format(Locale.US, "%.1f", result.packetLossPct)}%"
                }.getOrElse { "${peer.name}: échec (${it.message ?: "erreur réseau"})" }
            }
            runOnUiThread { peersText.text = results.joinToString("\n") }
        }
    }

    private fun measurePeerBandwidth() {
        if (peerRows.isEmpty()) {
            Toast.makeText(this, "Aucun nœud à mesurer.", Toast.LENGTH_SHORT).show()
            return
        }
        val snapshot = peerRows.toList()
        Toast.makeText(this, "Mesure réelle du débit (256 KiB par sens et par nœud)…", Toast.LENGTH_SHORT).show()
        thread(start = true, name = "nexus-bandwidth-test") {
            val results = snapshot.map { peer ->
                runCatching {
                    val result = NxpProtocol.measureBandwidth(peer.host, peer.port, { NetworkKeyManager.accepted(this) }).getOrThrow()
                    peer.bandwidthMbps = (result.downloadMbps + result.uploadMbps) / 2.0
                    discovery.updateCapabilities(
                        peer.name, peer.gateway, peer.relay, peer.gatewayDistance, peer.gatewayPath, peer.latencyMs,
                        peer.packetLossPct, peer.bandwidthMbps, success = true
                    )
                    "${peer.name}: ↓ ${String.format(Locale.US, "%.1f", result.downloadMbps)} Mb/s • ↑ ${String.format(Locale.US, "%.1f", result.uploadMbps)} Mb/s"
                }.getOrElse { "${peer.name}: débit indisponible (${it.message ?: "erreur réseau"})" }
            }
            runOnUiThread { updatePeersText(); Toast.makeText(this, results.joinToString("\n"), Toast.LENGTH_LONG).show() }
        }
    }

    private fun updateVpnButton() {
        vpnButton.text = "Activer le tunnel sécurisé"
        vpnButton.setOnClickListener { startVpnConsentFlow() }
    }

    private fun startVpnConsentFlow() {
        val prepare = VpnService.prepare(this)
        if (prepare != null) {
            startActivityForResult(prepare, 811)
        } else {
            startVpnService()
        }
    }

    private fun startVpnService() {
        val intent = Intent(this, NexusVpnService::class.java).apply { action = NexusConfig.ACTION_VPN }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        vpnButton.text = "Désactiver le tunnel sécurisé"
        vpnButton.setOnClickListener { stopVpnService() }
    }

    private fun stopVpnService() {
        startService(Intent(this, NexusVpnService::class.java).apply { action = NexusConfig.ACTION_VPN_STOP })
        vpnButton.text = "Activer le tunnel sécurisé"
        vpnButton.setOnClickListener { startVpnConsentFlow() }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 811 && resultCode == RESULT_OK) startVpnService()
        if (requestCode == 812 && resultCode == RESULT_OK && data?.data != null) importContent(data.data!!)
    }

    private var pendingPermissionCallback: (() -> Unit)? = null
    private var permissionQueue: MutableList<Pair<String, String>> = mutableListOf()
    private var permissionFlowActive = false

    /** Permissions une par une, avec explication avant chaque demande. */
    private fun requestPermissionsSequentially(onDone: () -> Unit) {
        if (permissionFlowActive) {
            pendingPermissionCallback = onDone
            return
        }
        val needed = mutableListOf<Pair<String, String>>()
        if (Build.VERSION.SDK_INT >= 33) {
            needed += Manifest.permission.NEARBY_WIFI_DEVICES to
                "Appareils à proximité\n\nNEXUS a besoin de cette autorisation pour détecter d’autres téléphones sur le même réseau ou en Wi‑Fi Direct, sans utiliser votre position précise."
            needed += Manifest.permission.POST_NOTIFICATIONS to
                "Notifications\n\nNEXUS peut afficher une notification lorsque le service réseau est actif en arrière-plan."
        } else {
            needed += Manifest.permission.ACCESS_FINE_LOCATION to
                "Localisation\n\nSur cette version d’Android, la découverte Wi‑Fi nécessite cette autorisation. NEXUS ne suit pas votre position et ne l’envoie à aucun serveur."
        }
        if (Build.VERSION.SDK_INT >= 31) {
            needed += Manifest.permission.BLUETOOTH_SCAN to
                "Bluetooth (recherche)\n\nPermet de détecter d’éventuels accessoires ou voisins compatibles. Vous pouvez refuser si vous n’utilisez pas cette fonction."
            needed += Manifest.permission.BLUETOOTH_CONNECT to
                "Bluetooth (connexion)\n\nPermet la connexion à des accessoires compatibles si vous les utilisez."
        }
        permissionQueue = needed.filter { checkSelfPermission(it.first) != PackageManager.PERMISSION_GRANTED }.toMutableList()
        pendingPermissionCallback = onDone
        permissionFlowActive = true
        askNextPermission()
    }

    private fun askNextPermission() {
        if (isFinishing) {
            permissionFlowActive = false
            pendingPermissionCallback = null
            return
        }
        if (permissionQueue.isEmpty()) {
            permissionFlowActive = false
            val done = pendingPermissionCallback
            pendingPermissionCallback = null
            if (isNetworkParticipationAccepted()) {
                startDiscovery()
                p2p.start()
                refreshNetwork()
            }
            done?.invoke()
            return
        }
        val (permission, explanation) = permissionQueue.removeAt(0)
        AlertDialog.Builder(this)
            .setTitle("Autorisation requise")
            .setMessage(explanation)
            .setCancelable(false)
            .setPositiveButton("Continuer") { _, _ ->
                requestPermissions(arrayOf(permission), 701)
            }
            .setNegativeButton("Passer") { _, _ ->
                askNextPermission()
            }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 701 || requestCode == 700) {
            askNextPermission()
        }
    }

    private fun label(text: String, size: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(getColor(if (bold) R.color.nexus_text_primary else R.color.nexus_text_secondary))
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        setLineSpacing(dp(2).toFloat(), 1f)
        setPadding(0, dp(4), 0, dp(8))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    // ---------- États vide / erreur détaillés ----------
    private fun emptyState(title: String, body: String, actionHint: String = ""): String {
        val hint = if (actionHint.isNotBlank()) "\n\n$actionHint" else ""
        return "$title\n\n$body$hint"
    }

    // ---------- Diagnostic (problème / cause / solution) ----------
    private fun runIntelligentDiagnosis() {
        if (!::diagnosisText.isInitialized) return
        val snapshot = NetworkInspector.snapshot(this)
        val issues = mutableListOf<Triple<String, String, String>>()

        if (!snapshot.connected) {
            issues += Triple(
                "Pas de réseau",
                "Wi‑Fi ou données mobiles désactivés, ou mode Avion activé.",
                "Activez une connexion réseau et acceptez les permissions demandées."
            )
        } else if (!snapshot.validated) {
            issues += Triple(
                "Internet non confirmé",
                "Le téléphone est connecté mais Internet n’est pas encore accessible.",
                "Ouvrez un navigateur pour valider la connexion, ou attendez quelques instants."
            )
        }

        if (peerRows.isEmpty() && snapshot.connected) {
            issues += Triple(
                "Aucun appareil NEXUS trouvé",
                "Personne d’autre n’utilise NEXUS sur ce réseau pour le moment.",
                "Demandez à quelqu’un d’ouvrir NEXUS à proximité, ou ajoutez un point d’entrée distant dans Sécurité."
            )
        }

        if (gatewayEnabled && !snapshot.validated) {
            issues += Triple(
                "Passerelle sans Internet",
                "La passerelle est activée alors qu’Internet n’est pas disponible.",
                "Désactivez la passerelle ou rétablissez Internet avant de la partager."
            )
        }

        val key = NexusIdentity.networkKey(this)
        if (key.isBlank() || key.length < 8) {
            issues += Triple(
                "Clé réseau manquante",
                "Une clé partagée renforce la sécurité du groupe.",
                "Dans Sécurité, définissez une clé d’au moins 8 caractères."
            )
        }

        diagnosisText.text = if (issues.isEmpty()) {
            "Aucun problème détecté.\n\n" +
                "Connexion : ${if (snapshot.validated) "Internet disponible" else if (snapshot.connected) "réseau local" else "hors ligne"}\n" +
                "Appareils NEXUS : ${peerRows.size}\n" +
                "Passerelle : ${if (gatewayEnabled) "oui" else "non"}  •  Partage : ${if (transitEnabled) "oui" else "non"}"
        } else {
            issues.mapIndexed { i, (problem, cause, solution) ->
                "${i + 1}. $problem\nCause : $cause\nQue faire : $solution"
            }.joinToString("\n\n")
        }
    }

    // ---------- Légal (UpToDown / confidentialité) ----------
    private fun showPrivacyPolicy() {
        val text =
            "Politique de confidentialité — NEXUS\n" +
            "Dernière mise à jour : septembre 2026\n\n" +
            "1. Responsable\n" +
            "L’application NEXUS est éditée par le développeur joignable à : monsieurmoi68@gmail.com\n\n" +
            "2. Données collectées\n" +
            "NEXUS fonctionne principalement en local sur votre appareil. Nous ne gérons pas de serveur central de collecte publicitaire.\n" +
            "Selon l’usage, l’application peut traiter localement :\n" +
            "• identifiants techniques du nœud (générés sur l’appareil)\n" +
            "• informations de réseau nécessaires au fonctionnement (état Wi‑Fi / mobile, appareils découverts)\n" +
            "• clé réseau que vous saisissez (stockée de façon sécurisée sur l’appareil)\n" +
            "• contenus que vous importez volontairement dans le stockage local\n\n" +
            "3. Finalités\n" +
            "Ces données servent uniquement à faire fonctionner le réseau maillé, la sécurité et les fonctions que vous activez.\n\n" +
            "4. Partage\n" +
            "Aucune vente de données personnelles. Les échanges entre appareils NEXUS se font selon les réglages que vous choisissez (clé, confiance, passerelle).\n\n" +
            "5. Conservation\n" +
            "Les données restent sur votre appareil tant que l’application est installée, sauf suppression par vos soins ou désinstallation.\n\n" +
            "6. Permissions Android\n" +
            "Réseau, proximité / localisation (si requis par Android pour la découverte), notifications, et éventuellement VPN si vous activez le tunnel. Chaque permission est demandée pour une fonction précise.\n\n" +
            "7. Vos droits\n" +
            "Vous pouvez demander des informations, une correction ou une suppression des données liées à l’app en écrivant à monsieurmoi68@gmail.com. La désinstallation de l’application supprime les données locales de NEXUS.\n\n" +
            "8. Mineurs\n" +
            "L’application n’est pas destinée aux enfants de moins de 13 ans.\n\n" +
            "9. Contact\n" +
            "monsieurmoi68@gmail.com"
        showLegalDialog("Politique de confidentialité", text)
    }

    private fun showTermsOfUse() {
        val text =
            "Conditions d’utilisation — NEXUS\n" +
            "Dernière mise à jour : septembre 2026\n\n" +
            "1. Objet\n" +
            "NEXUS est une application de réseau maillé de résilience. Elle permet de relayer, stocker et router du trafic entre appareils compatibles, dans le respect des lois applicables.\n\n" +
            "2. Acceptation\n" +
            "En installant ou utilisant NEXUS, vous acceptez ces conditions. Si vous n’acceptez pas, n’utilisez pas l’application.\n\n" +
            "3. Licence\n" +
            "Une licence personnelle, non exclusive et non transférable vous est accordée pour utiliser l’application sur vos appareils.\n\n" +
            "4. Usage autorisé\n" +
            "Vous vous engagez à utiliser NEXUS de façon légale, notamment :\n" +
            "• ne pas nuire aux autres utilisateurs ou aux réseaux\n" +
            "• ne pas tenter de contourner les mesures de sécurité\n" +
            "• respecter la vie privée d’autrui\n" +
            "• ne pas utiliser l’app pour des activités illicites\n\n" +
            "5. Contenu et responsabilités\n" +
            "Vous êtes responsable des contenus que vous importez ou partagez. NEXUS ne crée pas de radio, de fibre ou de satellite : il s’appuie sur les connexions déjà présentes.\n\n" +
            "6. Disponibilité\n" +
            "Le service dépend de votre environnement réseau et des autres nœuds. Aucune disponibilité permanente n’est garantie.\n\n" +
            "7. Limitation de responsabilité\n" +
            "Dans les limites autorisées par la loi, l’éditeur ne saurait être tenu responsable des dommages indirects liés à l’usage de l’application.\n\n" +
            "8. Données personnelles\n" +
            "Le traitement des données est décrit dans la Politique de confidentialité.\n\n" +
            "9. Modifications\n" +
            "Ces conditions peuvent être mises à jour. La version en vigueur est consultable dans l’application.\n\n" +
            "10. Contact\n" +
            "monsieurmoi68@gmail.com"
        showLegalDialog("Conditions d’utilisation", text)
    }

    private fun showLegalDialog(title: String, message: String) {
        val scroll = ScrollView(this)
        val body = TextView(this).apply {
            text = message
            textSize = 13f
            setTextColor(getColor(R.color.nexus_text_primary))
            setPadding(dp(20), dp(12), dp(20), dp(12))
            setLineSpacing(dp(2).toFloat(), 1.15f)
        }
        scroll.addView(body)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton("Fermer", null)
            .show()
    }

    // ---------- Activation obligatoire (participation au réseau) ----------
    private fun showActivationGate() {
        // Évite d’empiler plusieurs écrans d’activation
        for (i in 0 until rootFrame.childCount) {
            val child = rootFrame.getChildAt(i)
            if (child.tag == "activation_gate") {
                return
            }
        }
        val overlay = FrameLayout(this).apply {
            tag = "activation_gate"
            setBackgroundColor(getColor(R.color.nexus_background))
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            isClickable = true
            isFocusable = true
        }

        val scroll = ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(48), dp(28), dp(32))
        }

        val logo = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher_foreground)
            layoutParams = LinearLayout.LayoutParams(dp(72), dp(72)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(12)
            }
        }
        content.addView(logo)

        content.addView(TextView(this).apply {
            text = "NEXUS"
            textSize = 26f
            setTextColor(getColor(R.color.nexus_text_primary))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        content.addView(TextView(this).apply {
            text = "Activation"
            textSize = 15f
            setTextColor(getColor(R.color.nexus_primary))
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(20))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })

        content.addView(TextView(this).apply {
            text = "Votre appareil va devenir un nœud NEXUS."
            textSize = 16f
            setTextColor(getColor(R.color.nexus_text_primary))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(16))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })

        content.addView(TextView(this).apply {
            text = "NEXUS nécessite votre autorisation pour fonctionner.\n\n" +
                "NEXUS utilise votre appareil comme nœud du réseau. Cela permet à l’application de communiquer avec d’autres appareils et, selon vos réglages, de relayer du trafic.\n\n" +
                "Vous gardez le contrôle : NEXUS respecte les limites de batterie, de données et les règles que vous avez définies.\n\n" +
                "Pour utiliser NEXUS, vous devez accepter les conditions de participation au réseau."
            textSize = 14f
            setTextColor(getColor(R.color.nexus_text_secondary))
            setLineSpacing(dp(3).toFloat(), 1.15f)
            setPadding(0, 0, 0, dp(18))
        })

        val features = listOf(
            "Communication réseau",
            "Routage",
            "Sécurité",
            "Contrôle de consommation"
        )
        features.forEach { f ->
            content.addView(TextView(this).apply {
                text = "  ✓  $f"
                textSize = 14f
                setTextColor(getColor(R.color.nexus_text_primary))
                setPadding(dp(8), dp(4), 0, dp(4))
            })
        }

        val check = CheckBox(this).apply {
            text = "J’ai lu et j’accepte les conditions de participation"
            textSize = 14f
            setTextColor(getColor(R.color.nexus_text_primary))
            setPadding(0, dp(20), 0, dp(12))
        }
        content.addView(check)

        val activateBtn = primaryButton("Activer NEXUS") { }
        activateBtn.isEnabled = false
        activateBtn.alpha = 0.45f
        content.addView(activateBtn)

        check.setOnCheckedChangeListener { _, isChecked ->
            activateBtn.isEnabled = isChecked
            activateBtn.alpha = if (isChecked) 1f else 0.45f
        }

        activateBtn.setOnClickListener {
            if (!check.isChecked) return@setOnClickListener
            prefs.edit().putBoolean("activation_accepted", true).apply()
            rootFrame.removeView(overlay)
            startActivatedSession()
        }

        val links = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(8))
        }
        val termsLink = TextView(this).apply {
            text = "Conditions"
            textSize = 13f
            setTextColor(getColor(R.color.nexus_primary))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { showTermsOfUse() }
        }
        val sep = TextView(this).apply {
            text = "•"
            textSize = 13f
            setTextColor(getColor(R.color.nexus_text_secondary))
        }
        val privacyLink = TextView(this).apply {
            text = "Confidentialité"
            textSize = 13f
            setTextColor(getColor(R.color.nexus_primary))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { showPrivacyPolicy() }
        }
        links.addView(termsLink)
        links.addView(sep)
        links.addView(privacyLink)
        content.addView(links)

        val refuseBtn = outlineButton("Fermer") {
            AlertDialog.Builder(this@MainActivity)
                .setTitle("NEXUS ne peut pas être activé")
                .setMessage("Sans cette autorisation, les fonctions réseau de NEXUS restent désactivées.\n\nVous pourrez revenir à cet écran au prochain lancement.")
                .setPositiveButton("Compris") { _, _ -> finish() }
                .setCancelable(false)
                .show()
        }
        content.addView(refuseBtn)

        scroll.addView(content)
        overlay.addView(scroll)
        rootFrame.addView(overlay)
    }

    // ---------- Animation d’ouverture ----------
    private fun playOpeningAnimation(onDone: () -> Unit) {
        // Splash overlay avec logo
        val splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(getColor(R.color.nexus_background))
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        val splashLogo = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher_foreground)
            layoutParams = LinearLayout.LayoutParams(dp(96), dp(96)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(12)
            }
            scaleX = 0.6f
            scaleY = 0.6f
            alpha = 0f
        }
        val splashTitle = TextView(this).apply {
            text = "NEXUS"
            textSize = 28f
            setTextColor(getColor(R.color.nexus_text_primary))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            alpha = 0f
        }
        val splashSub = TextView(this).apply {
            text = "Réseau de résilience"
            textSize = 13f
            setTextColor(getColor(R.color.nexus_text_secondary))
            gravity = Gravity.CENTER
            alpha = 0f
            setPadding(0, dp(6), 0, 0)
        }
        splash.addView(splashLogo)
        splash.addView(splashTitle)
        splash.addView(splashSub)
        rootFrame.addView(splash)

        // Animation logo : scale + fade
        splashLogo.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(550)
            .setInterpolator(DecelerateInterpolator())
            .start()
        splashTitle.animate().alpha(1f).setStartDelay(200).setDuration(400).start()
        splashSub.animate().alpha(1f).setStartDelay(320).setDuration(400).start()

        // Après ~1.1s : fade out splash, fade in contenu
        splash.postDelayed({
            splash.animate()
                .alpha(0f)
                .setDuration(350)
                .withEndAction {
                    rootFrame.removeView(splash)
                    mainContent.animate()
                        .alpha(1f)
                        .setDuration(400)
                        .setInterpolator(DecelerateInterpolator())
                        .withEndAction { onDone() }
                        .start()
                }
                .start()
        }, 1100)
    }

    // ---------- Didacticiel d’ouverture (comment utiliser + comment ça marche) ----------
    private fun showOnboarding() {
        val steps = listOf(
            "Bienvenue dans NEXUS" to
                "NEXUS transforme chaque téléphone en point d’un réseau de résilience.\n\n" +
                "Vous pouvez :\n" +
                "• rester connecté avec d’autres appareils proches\n" +
                "• partager une sortie Internet lorsque c’est possible\n" +
                "• conserver des fichiers localement\n\n" +
                "L’application utilise le Wi‑Fi et les données déjà disponibles sur votre téléphone.",
            "Comment ça fonctionne" to
                "1. Au démarrage, NEXUS tourne en arrière-plan.\n" +
                "2. Il recherche les appareils NEXUS à proximité.\n" +
                "3. Il choisit un chemin vers une sortie Internet si elle existe.\n" +
                "4. Vous pouvez activer un tunnel sécurisé pour vos applications.\n" +
                "5. Une clé partagée protège votre groupe.",
            "L’écran Accueil" to
                "• Résumé : état de la connexion et des appareils.\n" +
                "• Se connecter automatiquement : démarre la recherche et la route.\n" +
                "• Diagnostic : indique le problème et la solution.\n" +
                "• Tunnel sécurisé : option pour router le trafic des apps.",
            "Réseau et Sécurité" to
                "Réseau\n" +
                "• Voir la connexion, les appareils proches, la passerelle.\n" +
                "• Tester les appareils et relancer la recherche.\n\n" +
                "Sécurité\n" +
                "• Définir une clé (8 caractères minimum).\n" +
                "• Ajouter un point d’entrée distant si besoin.\n" +
                "• Activer le mode confiance renforcée.",
            "Activité et Paramètres" to
                "Activité\n" +
                "• Crédits, import de fichiers, stockage partagé.\n\n" +
                "Paramètres\n" +
                "• Limites de partage, quotas, partage de l’application.\n" +
                "• Politique de confidentialité et conditions d’utilisation.\n\n" +
                "En cas de doute, utilisez le Diagnostic sur Accueil.",
            "Pour commencer" to
                "1. Acceptez les permissions demandées.\n" +
                "2. Appuyez sur « Se connecter automatiquement ».\n" +
                "3. Si vous êtes seul : ajoutez un point d’entrée dans Sécurité.\n" +
                "4. Définissez une clé partagée avec votre groupe.\n" +
                "5. Optionnel : activez le tunnel sécurisé."
        )
        var index = 0
        fun showStep() {
            val (title, message) = steps[index]
            val progress = "Didacticiel  ${index + 1}/${steps.size}"
            val builder = AlertDialog.Builder(this)
                .setTitle("$progress\n$title")
                .setMessage(message)
                .setCancelable(false)
            if (index < steps.lastIndex) {
                builder.setPositiveButton("Suivant") { _, _ ->
                    index++
                    showStep()
                }
                builder.setNegativeButton("Passer le didacticiel") { _, _ ->
                    prefs.edit().putBoolean("onboarding_done", true).apply()
                }
            } else {
                builder.setPositiveButton("Commencer à utiliser NEXUS") { _, _ ->
                    prefs.edit().putBoolean("onboarding_done", true).apply()
                    runIntelligentDiagnosis()
                    Toast.makeText(this, "Didacticiel terminé. Bienvenue sur NEXUS.", Toast.LENGTH_SHORT).show()
                }
            }
            builder.show()
        }
        showStep()
    }
}
