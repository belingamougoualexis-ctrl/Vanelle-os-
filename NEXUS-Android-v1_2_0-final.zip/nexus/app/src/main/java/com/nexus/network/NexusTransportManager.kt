package com.nexus.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicLong

/**
 * Chooses real IP-capable Android networks for NEXUS upstream traffic.
 * A satellite/radio/fiber/laser modem is usable when Android exposes it as an
 * actual IP Network (for example Ethernet, USB or satellite transport).
 */
class NexusTransportManager(private val context: Context) {
    private val flowCounter = AtomicLong(0L)
    private val connectivity = context.getSystemService(ConnectivityManager::class.java)

    data class Transport(
        val network: Network,
        val labels: Set<String>,
        val validated: Boolean,
        val metered: Boolean,
        val downKbps: Int,
        val upKbps: Int,
        val transportTypes: Set<Int> = emptySet()
    ) {
        val primaryLabel: String get() = labels.firstOrNull() ?: "IP inconnu"
    }

    fun transports(): List<Transport> {
        val cm = connectivity ?: return emptyList()
        return cm.allNetworks.mapNotNull { network ->
            val caps = cm.getNetworkCapabilities(network) ?: return@mapNotNull null
            val labels = buildSet {
                if (Build.VERSION.SDK_INT >= 35 && caps.hasTransport(TRANSPORT_SATELLITE)) add("Satellite / NTN")
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) add("Ethernet")
                if (Build.VERSION.SDK_INT >= 31 && caps.hasTransport(TRANSPORT_USB)) add("USB")
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) add("Cellulaire")
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) add("Wi‑Fi")
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH)) add("Bluetooth")
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI_AWARE)) add("Wi‑Fi Aware")
                if (Build.VERSION.SDK_INT >= 27 && caps.hasTransport(TRANSPORT_LOWPAN)) add("LoWPAN")
                if (Build.VERSION.SDK_INT >= 34 && caps.hasTransport(TRANSPORT_THREAD)) add("Thread")
                if (isEmpty()) add("IP inconnu")
            }
            val types = buildSet {
                if (Build.VERSION.SDK_INT >= 35 && caps.hasTransport(TRANSPORT_SATELLITE)) add(TRANSPORT_SATELLITE)
                addIf(caps, NetworkCapabilities.TRANSPORT_ETHERNET)
                if (Build.VERSION.SDK_INT >= 31 && caps.hasTransport(TRANSPORT_USB)) add(TRANSPORT_USB)
                addIf(caps, NetworkCapabilities.TRANSPORT_CELLULAR)
                addIf(caps, NetworkCapabilities.TRANSPORT_WIFI)
                addIf(caps, NetworkCapabilities.TRANSPORT_BLUETOOTH)
                addIf(caps, NetworkCapabilities.TRANSPORT_WIFI_AWARE)
                if (Build.VERSION.SDK_INT >= 27 && caps.hasTransport(TRANSPORT_LOWPAN)) add(TRANSPORT_LOWPAN)
                if (Build.VERSION.SDK_INT >= 34 && caps.hasTransport(TRANSPORT_THREAD)) add(TRANSPORT_THREAD)
            }
            Transport(
                network = network,
                labels = labels,
                validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED),
                metered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED),
                downKbps = caps.linkDownstreamBandwidthKbps,
                upKbps = caps.linkUpstreamBandwidthKbps,
                transportTypes = types
            )
        }.sortedWith(
            compareByDescending<Transport> { it.validated }
                .thenBy { it.metered }
                .thenByDescending { it.downKbps }
        )
    }

    fun validatedUnderlyingNetworks(): Array<Network> = transports()
        .filter { it.validated && NetworkCapabilities.TRANSPORT_VPN !in it.transportTypes }
        .map { it.network }
        .distinctBy { it.networkHandle }
        .toTypedArray()

    /** Return all usable backhauls ordered for primary/secondary use. */
    fun rankedValidatedNetworks(): List<Transport> {
        val items = transports().filter { it.validated }
        val paths = items.map {
            NexusMultipathPlanner.Path(
                id = it.network.networkHandle.toString(),
                downstreamKbps = it.downKbps.coerceAtLeast(1),
                upstreamKbps = it.upKbps.coerceAtLeast(1),
                latencyMs = null,
                lossPct = null,
                metered = it.metered,
                available = true
            )
        }
        val weights = NexusMultipathPlanner.allocate(paths).associateBy { it.id }
        return items.sortedByDescending { weights[it.network.networkHandle.toString()]?.weight ?: 0.0 }
    }

    /** Open a TCP socket explicitly bound to a chosen real Android Network. */
    fun openTcp(network: Network, host: String, port: Int, timeoutMs: Int = 10_000): Socket {
        val socket = network.socketFactory.createSocket()
        try {
            socket.connect(InetSocketAddress(host, port), timeoutMs)
            socket.soTimeout = 0
            return socket
        } catch (t: Throwable) {
            runCatching { socket.close() }
            throw t
        }
    }

    /** Open a UDP socket explicitly bound to a chosen real Android Network. */
    fun openUdp(network: Network): DatagramSocket {
        val socket = DatagramSocket()
        try {
            network.bindSocket(socket)
            return socket
        } catch (t: Throwable) {
            runCatching { socket.close() }
            throw t
        }
    }

    /** Try candidate backhauls until one really establishes the connection. */
    fun openTcpWithFailover(host: String, port: Int, timeoutMs: Int = 10_000): Pair<Socket, Transport> =
        openTcpOnOrder(host, port, rankedValidatedNetworks(), timeoutMs)

    /** Distribute independent NEXUS flows across available real backhauls. */
    fun openTcpMultipath(host: String, port: Int, timeoutMs: Int = 10_000): Pair<Socket, Transport> {
        val ranked = rankedValidatedNetworks()
        if (ranked.isEmpty()) throw IllegalStateException("Aucun backhaul IP validé disponible")
        val start = (flowCounter.getAndIncrement() and Long.MAX_VALUE).toInt() % ranked.size
        val rotated = ranked.drop(start) + ranked.take(start)
        return openTcpOnOrder(host, port, rotated, timeoutMs)
    }

    fun openUdpWithFailover(): Pair<DatagramSocket, Transport> = openUdpOnOrder(rankedValidatedNetworks())

    fun openUdpMultipath(): Pair<DatagramSocket, Transport> {
        val ranked = rankedValidatedNetworks()
        if (ranked.isEmpty()) throw IllegalStateException("Aucun backhaul IP validé disponible")
        val start = (flowCounter.getAndIncrement() and Long.MAX_VALUE).toInt() % ranked.size
        val rotated = ranked.drop(start) + ranked.take(start)
        return openUdpOnOrder(rotated)
    }

    private fun openTcpOnOrder(host: String, port: Int, transports: List<Transport>, timeoutMs: Int): Pair<Socket, Transport> {
        var last: Throwable? = null
        for (transport in transports) {
            try {
                return openTcp(transport.network, host, port, timeoutMs) to transport
            } catch (t: Throwable) {
                last = t
            }
        }
        throw (last ?: IllegalStateException("Aucun backhaul IP validé disponible"))
    }

    private fun openUdpOnOrder(transports: List<Transport>): Pair<DatagramSocket, Transport> {
        var last: Throwable? = null
        for (transport in transports) {
            try {
                return openUdp(transport.network) to transport
            } catch (t: Throwable) {
                last = t
            }
        }
        throw (last ?: IllegalStateException("Aucun backhaul IP validé disponible"))
    }

    fun humanSummary(): String = transports().joinToString(" • ") { t ->
        val state = if (t.validated) "Internet" else "local"
        val meter = if (t.metered) "mesuré" else "non mesuré"
        "${t.labels.joinToString("/")}=$state,$meter,↓${t.downKbps}kb/s,↑${t.upKbps}kb/s"
    }.ifBlank { "Aucun transport IP visible par Android" }

    fun physicalSummary(): String = NexusPhysicalBackhaul(context).physicalSummary()
    private fun MutableSet<Int>.addIf(caps: NetworkCapabilities, transport: Int) {
        if (caps.hasTransport(transport)) add(transport)
    }

    companion object {
        // Stable NetworkCapabilities transport values introduced on newer Android releases.
        private const val TRANSPORT_LOWPAN = 6
        private const val TRANSPORT_USB = 8
        private const val TRANSPORT_THREAD = 9
        private const val TRANSPORT_SATELLITE = 10
    }

}
