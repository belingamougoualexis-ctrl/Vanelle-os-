package com.nexus.network

import java.net.Inet6Address
import java.net.InetAddress
import java.net.URI

/** Standard endpoint parsing for IP, DNS, IPv6, nexus:// bootstrap and SOCKS-compatible transport. */
object NexusInterop {
    data class Endpoint(val scheme: String, val host: String, val port: Int)

    fun parse(value: String, defaultPort: Int = NexusConfig.NODE_PORT): Endpoint? = runCatching {
        val raw = value.trim()
        require(raw.isNotEmpty())
        if (!raw.contains("://") && raw.count { it == ':' } > 1) {
            val host = raw.trim('[', ']')
            return@runCatching Endpoint("nexus", host, defaultPort)
        }
        val uri = if (raw.contains("://")) URI(raw) else URI("nexus://$raw")
        val scheme = uri.scheme ?: "nexus"
        val host = uri.host ?: throw IllegalArgumentException("Hôte invalide")
        val port = if (uri.port > 0) uri.port else defaultPort
        require(port in 1..65535)
        Endpoint(scheme.lowercase(), host, port)
    }.getOrNull()

    fun isIpLiteral(host: String): Boolean = runCatching {
        InetAddress.getByName(host)
        host == InetAddress.getByName(host).hostAddress || host.trim('[', ']') == InetAddress.getByName(host).hostAddress
    }.getOrDefault(false)

    fun display(endpoint: Endpoint): String = when {
        runCatching { InetAddress.getByName(endpoint.host) is Inet6Address }.getOrDefault(false) -> "${endpoint.scheme}://[${endpoint.host}]:${endpoint.port}"
        else -> "${endpoint.scheme}://${endpoint.host}:${endpoint.port}"
    }
}
