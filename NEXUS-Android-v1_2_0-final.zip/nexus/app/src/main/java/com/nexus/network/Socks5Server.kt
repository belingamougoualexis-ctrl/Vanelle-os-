package com.nexus.network

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.Executors

/**
 * Real SOCKS5 server with CONNECT and UDP ASSOCIATE (RFC 1928/RFC 1929).
 * UDP associations use the same real NEXUS UDP transport as the TUN stack.
 */
class Socks5Server(
    private val port: Int,
    private val username: String,
    private val password: String,
    private val connector: (String, Int) -> NexusStreamChannel = { host, targetPort ->
        SocketStreamChannel(Socket().apply {
            check(NexusVpnRegistry.protect(this)) { "Impossible de protéger le socket du VPN" }
            connect(InetSocketAddress(host, targetPort), 10_000)
        })
    },
    private val udpConnector: (String, Int) -> UserSpaceIpStack.UdpChannel = { host, targetPort ->
        NexusUdpChannels.direct(host, targetPort)
    }
) {
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "nexus-socks-${System.nanoTime()}").apply { isDaemon = true } }
    @Volatile private var running = false
    private var serverSocket: ServerSocket? = null

    fun start() {
        if (running) return
        running = true
        pool.execute {
            runCatching {
                ServerSocket().use { server ->
                    server.reuseAddress = true
                    server.bind(InetSocketAddress("0.0.0.0", port))
                    serverSocket = server
                    while (running) {
                        val client = server.accept()
                        pool.execute { handleClient(client) }
                    }
                }
            }
        }
    }

    fun stop() {
        running = false
        runCatching { serverSocket?.close() }
        serverSocket = null
        pool.shutdownNow()
    }

    private fun handleClient(client: Socket) {
        client.use { c ->
            c.soTimeout = 15_000
            val input = BufferedInputStream(c.getInputStream())
            val output = BufferedOutputStream(c.getOutputStream())
            if (!authenticate(input, output)) return
            val request = runCatching { readRequest(input) }.getOrNull() ?: return
            when (request.command) {
                1 -> openTarget(c, output, request.target) // CONNECT
                3 -> openUdpAssociate(c, input, output)     // UDP ASSOCIATE
                else -> {
                    writeReply(output, 7)
                    output.flush()
                }
            }
        }
    }

    private fun authenticate(input: InputStream, output: OutputStream): Boolean {
        val version = input.read()
        if (version != 5) return false
        val methodCount = input.read()
        if (methodCount < 0 || methodCount > 255) return false
        val methods = ByteArray(methodCount)
        readFully(input, methods)
        if (!methods.contains(0x02.toByte())) {
            output.write(byteArrayOf(0x05, 0xFF.toByte()))
            output.flush()
            return false
        }
        output.write(byteArrayOf(0x05, 0x02))
        output.flush()
        if (input.read() != 1) return false
        val uLen = input.read()
        if (uLen !in 0..255) return false
        val u = String(readBytes(input, uLen), StandardCharsets.UTF_8)
        val pLen = input.read()
        if (pLen !in 0..255) return false
        val p = String(readBytes(input, pLen), StandardCharsets.UTF_8)
        val ok = u == username && p == password
        output.write(byteArrayOf(0x01, if (ok) 0 else 0x01))
        output.flush()
        return ok
    }

    private fun readRequest(input: InputStream): Request {
        if (input.read() != 5) error("SOCKS version invalide")
        val command = input.read()
        if (command !in 1..3) error("SOCKS commande inconnue")
        if (input.read() != 0) error("SOCKS reserved invalide")
        val target = readTarget(input)
        return Request(command, target)
    }

    private fun readTarget(input: InputStream): Target {
        return when (val atyp = input.read()) {
            1 -> {
                val raw = readBytes(input, 4)
                val host = raw.joinToString(".") { (it.toInt() and 0xFF).toString() }
                Target(host, readPort(input), 1)
            }
            3 -> {
                val len = input.read()
                if (len !in 1..255) error("SOCKS domain invalide")
                val host = String(readBytes(input, len), StandardCharsets.UTF_8)
                Target(host, readPort(input), 3)
            }
            4 -> {
                val raw = readBytes(input, 16)
                val host = InetAddress.getByAddress(raw).hostAddress ?: error("IPv6 invalide")
                Target(host, readPort(input), 4)
            }
            else -> error("ATYP SOCKS inconnu: $atyp")
        }
    }

    private fun readPort(input: InputStream): Int {
        val hi = input.read()
        val lo = input.read()
        if (hi !in 0..255 || lo !in 0..255) error("Port SOCKS invalide")
        return (hi shl 8) or lo
    }

    private fun openTarget(client: Socket, output: OutputStream, target: Target): Boolean {
        return runCatching {
            connector(target.host, target.port).use { upstream ->
                writeReply(output, 0, client.localAddress, upstreamAddressPort = 0)
                output.flush()
                relay(client, upstream)
                true
            }
        }.getOrElse {
            runCatching { writeReply(output, 5); output.flush() }
            false
        }
    }

    private fun openUdpAssociate(client: Socket, controlInput: InputStream, output: OutputStream) {
        val bindAddress = client.localAddress ?: InetAddress.getLoopbackAddress()
        val udp = DatagramSocket(null)
        udp.reuseAddress = true
        udp.bind(InetSocketAddress(bindAddress, 0))
        val targetChannels = ConcurrentHashMap<UdpKey, UserSpaceIpStack.UdpChannel>()
        val lastClient = AtomicReference<InetSocketAddress?>(null)
        val stopped = CountDownLatch(1)

        try {
writeReply(output, 0, bindAddress, udp.localPort)
            output.flush()
            client.soTimeout = 0

            Thread({
                val packetBuffer = ByteArray(65_535)
                try {
                    while (running && !client.isClosed) {
                        val packet = DatagramPacket(packetBuffer, packetBuffer.size)
                        udp.receive(packet)
                        lastClient.set(InetSocketAddress(packet.address, packet.port))
                        val request = parseUdpDatagram(packet.data.copyOf(packet.length)) ?: continue
                        val key = UdpKey(request.host, request.port)
                        val channel = targetChannels[key] ?: runCatching {
                            udpConnector(request.host, request.port).also { newChannel ->
                                newChannel.startReceiver { response ->
                                    val endpoint = lastClient.get() ?: return@startReceiver
                                    val encoded = encodeUdpDatagram(request, response)
                                    runCatching {
                                        udp.send(DatagramPacket(encoded, encoded.size, endpoint.address, endpoint.port))
                                    }
                                }
                            }
                        }.getOrNull()
                        if (channel != null) {
                            targetChannels.putIfAbsent(key, channel)?.let { created ->
                                runCatching { created.close() }
                            }
                            runCatching { targetChannels[key]?.send(request.payload) }
                                .onFailure { targetChannels.remove(key)?.close() }
                        }
                    }
                } catch (_: Exception) {
                    // Association ends when the UDP socket or control connection closes.
                } finally {
                    stopped.countDown()
                }
            }, "nexus-socks-udp-assoc").apply { isDaemon = true; start() }

            // Keep the RFC 1928 control TCP connection alive. Its closure ends the UDP association.
            val drain = ByteArray(256)
            while (running && !client.isClosed) {
                val n = controlInput.read(drain)
                if (n < 0) break
            }
        } finally {
            runCatching { udp.close() }
            targetChannels.values.forEach { runCatching { it.close() } }
            targetChannels.clear()
            stopped.awaitNanosCompat(500)
        }
    }

    private fun parseUdpDatagram(data: ByteArray): UdpRequest? {
        if (data.size < 4 || data[0].toInt() != 0 || data[1].toInt() != 0) return null
        // Fragmentation is not silently reassembled. Reject FRAG != 0.
        if (data[2].toInt() != 0) return null
        var offset = 3
        val atyp = data[offset].toInt() and 0xff
        offset++
        val host: String
        val rawAddress: ByteArray?
        when (atyp) {
            1 -> {
                if (offset + 4 > data.size) return null
                rawAddress = data.copyOfRange(offset, offset + 4)
                host = rawAddress.joinToString(".") { (it.toInt() and 0xff).toString() }
                offset += 4
            }
            3 -> {
                if (offset >= data.size) return null
                val len = data[offset].toInt() and 0xff
                offset++
                if (len !in 1..255 || offset + len > data.size) return null
                host = String(data, offset, len, StandardCharsets.UTF_8)
                rawAddress = null
                offset += len
            }
            4 -> {
                if (offset + 16 > data.size) return null
                rawAddress = data.copyOfRange(offset, offset + 16)
                host = InetAddress.getByAddress(rawAddress).hostAddress ?: return null
                offset += 16
            }
            else -> return null
        }
        if (offset + 2 > data.size) return null
        val port = ((data[offset].toInt() and 0xff) shl 8) or (data[offset + 1].toInt() and 0xff)
        offset += 2
        if (port !in 1..65_535) return null
        return UdpRequest(host, port, atyp, rawAddress, data.copyOfRange(offset, data.size))
    }

    private fun encodeUdpDatagram(target: UdpRequest, payload: ByteArray): ByteArray {
        val hostBytes = when (target.atyp) {
            1 -> target.rawAddress ?: InetAddress.getByName(target.host).address
            4 -> target.rawAddress ?: InetAddress.getByName(target.host).address
            else -> target.host.toByteArray(StandardCharsets.UTF_8)
        }
        val addressPart = when (target.atyp) {
            1, 4 -> hostBytes
            else -> byteArrayOf(hostBytes.size.toByte()) + hostBytes
        }
        return ByteArray(3 + 1 + addressPart.size + 2 + payload.size).also { out ->
            // RSV + FRAG
            out[0] = 0
            out[1] = 0
            out[2] = 0
            var o = 3
            out[o++] = target.atyp.toByte()
            System.arraycopy(addressPart, 0, out, o, addressPart.size)
            o += addressPart.size
            out[o++] = (target.port ushr 8).toByte()
            out[o++] = target.port.toByte()
            System.arraycopy(payload, 0, out, o, payload.size)
        }
    }

    private fun writeReply(output: OutputStream, code: Int, address: InetAddress? = null, upstreamAddressPort: Int = 0) {
        val addr = address ?: InetAddress.getLoopbackAddress()
        val raw = when (addr) {
            is Inet6Address -> addr.address
            else -> (addr as Inet4Address).address
        }
        val atyp = if (raw.size == 16) 4 else 1
        output.write(byteArrayOf(5, code.toByte(), 0, atyp.toByte()))
        output.write(raw)
        output.write((upstreamAddressPort ushr 8) and 0xff)
        output.write(upstreamAddressPort and 0xff)
    }

    private fun relay(client: Socket, upstream: NexusStreamChannel) {
        val done = CountDownLatch(2)
        pipe(client.getInputStream(), upstream.output, done) { upstream.shutdownOutput() }
        pipe(upstream.input, client.getOutputStream(), done) { runCatching { client.shutdownOutput() } }
        runCatching { done.await() }
    }

    private fun pipe(input: InputStream, output: OutputStream, done: CountDownLatch, onEof: () -> Unit = {}) {
        pool.execute {
            val buffer = ByteArray(16 * 1024)
            try {
                while (running) {
                    val count = input.read(buffer)
                    if (count < 0) { onEof(); break }
                    if (count == 0) continue
                    output.write(buffer, 0, count)
                    output.flush()
                }
            } catch (_: Exception) {
                // Closing either side ends the session.
            } finally {
                done.countDown()
            }
        }
    }

    private fun readFully(input: InputStream, buffer: ByteArray) {
        var offset = 0
        while (offset < buffer.size) {
            val count = input.read(buffer, offset, buffer.size - offset)
            if (count < 0) error("Unexpected end of stream")
            offset += count
        }
    }

    private fun readBytes(input: InputStream, length: Int): ByteArray {
        require(length in 0..255)
        return ByteArray(length).also { readFully(input, it) }
    }

    private data class Target(val host: String, val port: Int, val atyp: Int)
    private data class Request(val command: Int, val target: Target)
    private data class UdpKey(val host: String, val port: Int)
    private data class UdpRequest(
        val host: String,
        val port: Int,
        val atyp: Int,
        val rawAddress: ByteArray?,
        val payload: ByteArray
    )

    private fun CountDownLatch.awaitNanosCompat(timeoutMs: Long) {
        runCatching { await(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS) }
    }
}
