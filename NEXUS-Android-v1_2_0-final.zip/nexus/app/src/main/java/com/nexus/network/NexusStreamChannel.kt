package com.nexus.network

import java.io.InputStream
import java.io.OutputStream
import java.net.Socket

interface NexusStreamChannel : AutoCloseable {
    val input: InputStream
    val output: OutputStream
    fun shutdownOutput()
    override fun close()
}

class SocketStreamChannel(private val socket: Socket) : NexusStreamChannel {
    override val input: InputStream get() = socket.getInputStream()
    override val output: OutputStream get() = socket.getOutputStream()
    override fun shutdownOutput() = runCatching { socket.shutdownOutput() }.getOrDefault(Unit)
    override fun close() = runCatching { socket.close() }.getOrDefault(Unit)
}

class RelayStreamChannel(
    private val socket: Socket,
    sessionNonce: String,
    networkKey: String
) : NexusStreamChannel {
    private val key = NexusSecureFraming.deriveKey(networkKey, sessionNonce)
    override val input: InputStream = NexusSecureInputStream(socket.getInputStream(), key)
    override val output: OutputStream = NexusSecureOutputStream(socket.getOutputStream(), key)
    private val secureOut get() = output as NexusSecureOutputStream

    override fun shutdownOutput() = secureOut.shutdownOutput()
    override fun close() {
        runCatching { secureOut.shutdownOutput() }
        runCatching { socket.close() }
    }
}
