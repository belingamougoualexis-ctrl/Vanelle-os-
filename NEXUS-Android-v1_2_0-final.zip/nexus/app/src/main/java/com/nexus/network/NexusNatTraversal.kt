package com.nexus.network

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.security.SecureRandom

/** Real STUN binding discovery and UDP candidate probing. No synthetic relay is used. */
class NexusNatTraversal(private val protect: ((DatagramSocket) -> Boolean)? = null) {
    data class Candidate(val address: String, val port: Int, val source: String)
    data class Result(val candidates: List<Candidate>, val reachable: Boolean, val server: String)

    fun discover(stunServers: List<String> = DEFAULT_STUN): Result {
        for (server in stunServers.distinct()) {
            val endpoint = parse(server) ?: continue
            val result = runCatching { query(endpoint.first, endpoint.second) }.getOrNull() ?: continue
            return Result(listOf(result), true, server)
        }
        return Result(emptyList(), false, "")
    }

    fun punch(candidates: Collection<Candidate>, token: String, durationMs: Long = 2_000L): Boolean {
        if (candidates.isEmpty()) return false
        val payload = "NEXUS-PUNCH/1|$token".toByteArray(Charsets.US_ASCII)
        return runCatching {
            DatagramSocket().use { socket ->
                if (protect != null && !protect.invoke(socket)) return false
                val deadline = System.currentTimeMillis() + durationMs.coerceIn(250, 10_000)
                while (System.currentTimeMillis() < deadline) {
                    candidates.forEach { candidate ->
                        val host = InetAddress.getByName(candidate.address)
                        socket.send(DatagramPacket(payload, payload.size, host, candidate.port))
                    }
                    Thread.sleep(100)
                }
                true
            }
        }.getOrDefault(false)
    }

    private fun query(host: String, port: Int): Candidate? {
        val tx = ByteArray(12).also(SecureRandom()::nextBytes)
        val request = ByteArray(20)
        putU16(request, 0, 0x0001)
        putU16(request, 2, 0)
        putU32(request, 4, 0x2112A442L)
        System.arraycopy(tx, 0, request, 8, 12)
        val server = InetAddress.getByName(host)
        DatagramSocket().use { socket ->
            socket.soTimeout = NexusConfig.NAT_STUN_TIMEOUT_MS
            if (protect != null && !protect.invoke(socket)) return null
            socket.send(DatagramPacket(request, request.size, server, port))
            val buffer = ByteArray(2048)
            val response = DatagramPacket(buffer, buffer.size)
            socket.receive(response)
            if (response.length < 20) return null
            if ((u32(buffer, 4) and 0xffffffffL) != 0x2112A442L) return null
            if (!tx.contentEquals(buffer.copyOfRange(8, 20))) return null
            return parseMappedAddress(buffer, response.length, tx)
        }
    }

    private fun parseMappedAddress(packet: ByteArray, length: Int, tx: ByteArray): Candidate? {
        var off = 20
        while (off + 4 <= length) {
            val type = u16(packet, off)
            val size = u16(packet, off + 2)
            off += 4
            if (off + size > length) return null
            if (type == 0x0020 || type == 0x0001) {
                val family = packet[off + 1].toInt() and 0xff
                val portRaw = u16(packet, off + 2)
                val port = if (type == 0x0020) portRaw xor 0x2112 else portRaw
                if (family == 1 && size >= 8) {
                    val addrBytes = ByteArray(4)
                    for (i in 0 until 4) {
                        addrBytes[i] = if (type == 0x0020) (packet[off + 4 + i].toInt() xor ((0x2112A442L ushr (24 - i * 8)).toInt())).toByte() else packet[off + 4 + i]
                    }
                    return Candidate(InetAddress.getByAddress(addrBytes).hostAddress, port, "STUN")
                }
                if (family == 2 && size >= 20 && type == 0x0020) {
                    val addrBytes = ByteArray(16)
                    val cookie = byteArrayOf(0x21, 0x12, 0xA4.toByte(), 0x42)
                    for (i in 0 until 16) addrBytes[i] = (packet[off + 4 + i].toInt() xor (if (i < 4) cookie[i].toInt() else tx[i - 4].toInt())).toByte()
                    return Candidate(InetAddress.getByAddress(addrBytes).hostAddress, port, "STUN")
                }
            }
            off += ((size + 3) / 4) * 4
        }
        return null
    }

    private fun parse(value: String): Pair<String, Int>? {
        val v = value.trim()
        val parts = v.substringAfter("://", v).split(":")
        val host = parts.firstOrNull()?.trim()?.trim('[', ']') ?: return null
        val port = parts.getOrNull(1)?.toIntOrNull() ?: 3478
        return host.takeIf { it.isNotBlank() }?.let { it to port.coerceIn(1, 65535) }
    }

    private fun u16(b: ByteArray, o: Int): Int = ((b[o].toInt() and 0xff) shl 8) or (b[o + 1].toInt() and 0xff)
    private fun putU16(b: ByteArray, o: Int, v: Int) { b[o] = (v ushr 8).toByte(); b[o + 1] = v.toByte() }
    private fun putU32(b: ByteArray, o: Int, v: Long) { b[o] = (v ushr 24).toByte(); b[o+1] = (v ushr 16).toByte(); b[o+2] = (v ushr 8).toByte(); b[o+3] = v.toByte() }
    private fun u32(b: ByteArray, o: Int): Long = ((b[o].toLong() and 0xff) shl 24) or ((b[o+1].toLong() and 0xff) shl 16) or ((b[o+2].toLong() and 0xff) shl 8) or (b[o+3].toLong() and 0xff)

    companion object {
        val DEFAULT_STUN = listOf("stun.cloudflare.com:3478", "stun.l.google.com:19302")
    }
}
