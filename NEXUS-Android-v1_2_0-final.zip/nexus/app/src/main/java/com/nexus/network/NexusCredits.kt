package com.nexus.network

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.floor

/**
 * Local resource-credit ledger. Credits are not money or a cryptocurrency.
 * Relay/use receipts are signed by the device identity and can be exchanged
 * when peers reconnect. A global, Byzantine-proof currency would need a
 * consensus/admission layer that NEXUS intentionally does not fake.
 */
object NexusCredits {
    private const val PREFS = "nexus_credits"
    private const val BALANCE = "balance"
    private const val RECEIPTS = "receipts"
    private const val RELAY_REMAINDER = "relay_remainder_bytes"
    private const val USE_REMAINDER = "use_remainder_bytes"
    private const val BYTES_PER_CREDIT = 1_048_576L
    private val initialized = AtomicBoolean(false)

    fun balance(context: Context): Long = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getLong(BALANCE, 0L)

    fun relay(context: Context, peerId: String, bytes: Long): Long = synchronized(this) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val previousRemainder = prefs.getLong(RELAY_REMAINDER, 0L).coerceAtLeast(0L)
        val total = previousRemainder + bytes.coerceAtLeast(0L)
        val credits = floor(total.toDouble() / BYTES_PER_CREDIT).toLong()
        val remainder = total - credits * BYTES_PER_CREDIT
        if (credits <= 0) {
            prefs.edit().putLong(RELAY_REMAINDER, remainder).apply()
            return@synchronized balance(context)
        }
        val next = balance(context) + credits
        appendReceipt(context, "relay", peerId, bytes, credits)
        prefs.edit().putLong(RELAY_REMAINDER, remainder).putLong(BALANCE, next).apply()
        next
    }

    fun spend(context: Context, peerId: String, bytes: Long): Boolean = synchronized(this) {
        val safeBytes = bytes.coerceAtLeast(0L)
        if (safeBytes == 0L) return@synchronized true
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val previousRemainder = prefs.getLong(USE_REMAINDER, 0L).coerceAtLeast(0L)
        val total = previousRemainder + safeBytes
        val credits = floor(total.toDouble() / BYTES_PER_CREDIT).toLong()
        val remainder = total - credits * BYTES_PER_CREDIT
        val current = balance(context)
        if (NexusSettings.creditsEnforced(context) && current < credits) return@synchronized false
        appendReceipt(context, "use", peerId, safeBytes, credits)
        prefs.edit().putLong(USE_REMAINDER, remainder).putLong(BALANCE, current - credits).apply()
        true
    }

    fun receiptLog(context: Context): JSONArray = JSONArray(
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(RECEIPTS, "[]") ?: "[]"
    )

    private fun appendReceipt(context: Context, type: String, peerId: String, bytes: Long, credits: Long) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val array = JSONArray(prefs.getString(RECEIPTS, "[]") ?: "[]")
        val canonical = "v=1&type=$type&node=${NexusIdentity.nodeId(context)}&peer=$peerId&bytes=$bytes&credits=$credits"
        val obj = JSONObject().apply {
            put("v", 1)
            put("type", type)
            put("node", NexusIdentity.nodeId(context))
            put("peer", peerId)
            put("bytes", bytes)
            put("credits", credits)
            put("ts", System.currentTimeMillis())
            put("sig", NexusCrypto.encodeBytes(NexusIdentity.sign(context, canonical)))
        }
        array.put(obj)
        while (array.length() > 256) array.remove(0)
        prefs.edit().putString(RECEIPTS, array.toString()).apply()
    }
}
