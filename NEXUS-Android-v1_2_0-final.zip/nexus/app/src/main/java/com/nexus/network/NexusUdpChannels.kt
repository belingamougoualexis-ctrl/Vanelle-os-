package com.nexus.network

import android.net.VpnService
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress

/** Real UDP channel backed by a protected Android/JVM DatagramSocket. */
object NexusUdpChannels {
    fun direct(host: String, port: Int, vpn: VpnService? = null, transportManager: NexusTransportManager? = null): UserSpaceIpStack.UdpChannel {
        require(port in 1..65_535)
        val socket = transportManager?.openUdpMultipath()?.first ?: DatagramSocket()
        try {
            check((vpn?.protect(socket) ?: NexusVpnRegistry.protect(socket))) {
                "Impossible de protéger le socket UDP du VPN"
            }
            socket.connect(InetSocketAddress(host, port))
        } catch (e: Exception) {
            runCatching { socket.close() }
            throw e
        }
        return object : UserSpaceIpStack.UdpChannel {
            @Volatile private var closed = false

            override fun send(payload: ByteArray) {
                check(!closed) { "Canal UDP fermé" }
                socket.send(DatagramPacket(payload, payload.size))
            }

            override fun startReceiver(onPayload: (ByteArray) -> Unit): Thread =
                Thread({
                    val buffer = ByteArray(65_535)
                    while (!closed) {
                        try {
                            val packet = DatagramPacket(buffer, buffer.size)
                            socket.receive(packet)
                            if (packet.length > 0 && !closed) {
                                onPayload(packet.data.copyOf(packet.length))
                            }
                        } catch (_: Exception) {
                            break
                        }
                    }
                }, "nexus-udp-direct").apply {
                    isDaemon = true
                    start()
                }

            override fun close() {
                closed = true
                runCatching { socket.close() }
            }
        }
    }
}
