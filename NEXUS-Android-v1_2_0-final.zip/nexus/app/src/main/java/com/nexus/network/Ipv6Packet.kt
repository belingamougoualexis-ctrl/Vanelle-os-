package com.nexus.network

import java.net.Inet6Address
import java.net.InetAddress

/** IPv6 base header + common extension headers + Fragment header codec. */
object Ipv6Packet {
    data class FragmentInfo(val id: Long, val offsetBytes: Int, val more: Boolean)
    data class IPv6(
        val src: Inet6Address,
        val dst: Inet6Address,
        val nextHeader: Int,
        val headerLength: Int,
        val payloadLength: Int,
        val hopLimit: Int,
        val trafficClass: Int,
        val flowLabel: Int,
        val payload: ByteArray,
        val fragment: FragmentInfo? = null,
        val routerAlert: Boolean = false,
        val jumboPayload: Boolean = false
    )

    fun parse(packet: ByteArray): IPv6? {
        if (packet.size < 40) return null
        if (((packet[0].toInt() ushr 4) and 0x0f) != 6) return null
        val trafficClass = ((packet[0].toInt() and 0x0f) shl 4) or ((packet[1].toInt() ushr 4) and 0x0f)
        val flowLabel = ((packet[1].toInt() and 0x0f) shl 16) or ((packet[2].toInt() and 0xff) shl 8) or (packet[3].toInt() and 0xff)
        val payloadLength = IpPacket.u16(packet, 4)
        if (packet.size < 40 + payloadLength) return null
        var next = IpPacket.u8(packet[6])
        var offset = 40
        var fragment: FragmentInfo? = null
        var routerAlert = false
        var jumboPayload = false
        val end = 40 + payloadLength
        val src = runCatching { InetAddress.getByAddress(packet.copyOfRange(8, 24)) as Inet6Address }.getOrNull() ?: return null
        val dst = runCatching { InetAddress.getByAddress(packet.copyOfRange(24, 40)) as Inet6Address }.getOrNull() ?: return null
        var guard = 0
        while (offset < end && guard++ < 8) {
            when (next) {
                0, 43, 60 -> {
                    if (offset + 2 > end) return null
                    val following = IpPacket.u8(packet[offset])
                    val len = (IpPacket.u8(packet[offset + 1]) + 1) * 8
                    if (len < 8 || offset + len > end) return null
                    // RFC 2711 Router Alert option: type 5, length 2, value 0.
                    var opt = offset + 2
                    val optEnd = offset + len
                    while (opt < optEnd) {
                        val type = IpPacket.u8(packet[opt])
                        if (type == 0) { opt += 1; continue }
                        if (opt + 2 > optEnd) return null
                        val olen = IpPacket.u8(packet[opt + 1])
                        if (opt + 2 + olen > optEnd) return null
                        if (type == 5 && olen == 2 && IpPacket.u16(packet, opt + 2) == 0) routerAlert = true
                        if (type == 0xc2 && olen == 4) jumboPayload = true
                        opt += 2 + olen
                    }
                    next = following
                    offset += len
                }
                44 -> {
                    if (offset + 8 > end) return null
                    val following = IpPacket.u8(packet[offset])
                    val fragField = IpPacket.u16(packet, offset + 2)
                    val fragOffset = ((fragField ushr 3) and 0x1fff) * 8
                    val more = (fragField and 1) != 0
                    val id = ((packet[offset + 4].toLong() and 0xff) shl 24) or
                        ((packet[offset + 5].toLong() and 0xff) shl 16) or
                        ((packet[offset + 6].toLong() and 0xff) shl 8) or
                        (packet[offset + 7].toLong() and 0xff)
                    fragment = FragmentInfo(id, fragOffset, more)
                    next = following
                    offset += 8
                }
                51 -> {
                    if (offset + 2 > end) return null
                    val following = IpPacket.u8(packet[offset])
                    val len = (IpPacket.u8(packet[offset + 1]) + 2) * 4
                    if (len < 8 || offset + len > end) return null
                    next = following
                    offset += len
                }
                59 -> return IPv6(src, dst, next, offset, payloadLength, IpPacket.u8(packet[7]), trafficClass, flowLabel, ByteArray(0), fragment, routerAlert, jumboPayload)
                else -> return IPv6(src, dst, next, offset, payloadLength, IpPacket.u8(packet[7]), trafficClass, flowLabel, packet.copyOfRange(offset, end), fragment, routerAlert, jumboPayload)
            }
        }
        if (offset > end) return null
        return IPv6(src, dst, next, offset, payloadLength, IpPacket.u8(packet[7]), trafficClass, flowLabel, packet.copyOfRange(offset, end), fragment, routerAlert, jumboPayload)
    }

    fun buildUdp(src: Inet6Address, dst: Inet6Address, srcPort: Int, dstPort: Int, payload: ByteArray, hopLimit: Int = 64, trafficClass: Int = 0, flowLabel: Int = 0): ByteArray {
        val udp = ByteArray(8 + payload.size)
        IpPacket.putU16(udp, 0, srcPort); IpPacket.putU16(udp, 2, dstPort); IpPacket.putU16(udp, 4, udp.size); IpPacket.putU16(udp, 6, 0)
        System.arraycopy(payload, 0, udp, 8, payload.size)
        IpPacket.putU16(udp, 6, checksumPseudo(src, dst, 17, udp))
        return build(src, dst, 17, udp, hopLimit, trafficClass, flowLabel)
    }

    fun buildTcp(src: Inet6Address, dst: Inet6Address, srcPort: Int, dstPort: Int, sequence: Long, acknowledgement: Long, flags: Int, window: Int = 65535, payload: ByteArray = ByteArray(0), hopLimit: Int = 64, trafficClass: Int = 0, flowLabel: Int = 0, options: ByteArray = ByteArray(0)): ByteArray {
        require(options.size <= 40 && options.size % 4 == 0)
        val tcp = ByteArray(20 + options.size + payload.size)
        IpPacket.putU16(tcp, 0, srcPort); IpPacket.putU16(tcp, 2, dstPort); IpPacket.putU32(tcp, 4, sequence); IpPacket.putU32(tcp, 8, acknowledgement)
        IpPacket.putU16(tcp, 12, ((20 + options.size) / 4) shl 12 or (flags and 0x01ff)); IpPacket.putU16(tcp, 14, window); IpPacket.putU16(tcp, 16, 0); IpPacket.putU16(tcp, 18, 0)
        if (options.isNotEmpty()) System.arraycopy(options, 0, tcp, 20, options.size)
        if (payload.isNotEmpty()) System.arraycopy(payload, 0, tcp, 20 + options.size, payload.size)
        IpPacket.putU16(tcp, 16, checksumPseudo(src, dst, 6, tcp))
        return build(src, dst, 6, tcp, hopLimit, trafficClass, flowLabel)
    }

    fun build(src: Inet6Address, dst: Inet6Address, nextHeader: Int, payload: ByteArray, hopLimit: Int = 64, trafficClass: Int = 0, flowLabel: Int = 0): ByteArray {
        require(payload.size <= 65535)
        val p = ByteArray(40 + payload.size)
        p[0] = (0x60 or ((trafficClass ushr 4) and 0x0f)).toByte()
        p[1] = (((trafficClass and 0x0f) shl 4) or ((flowLabel ushr 16) and 0x0f)).toByte()
        p[2] = (flowLabel ushr 8).toByte(); p[3] = flowLabel.toByte()
        IpPacket.putU16(p, 4, payload.size); p[6] = nextHeader.toByte(); p[7] = hopLimit.coerceIn(1, 255).toByte()
        System.arraycopy(src.address, 0, p, 8, 16); System.arraycopy(dst.address, 0, p, 24, 16); System.arraycopy(payload, 0, p, 40, payload.size)
        return p
    }

    private fun checksumPseudo(src: Inet6Address, dst: Inet6Address, nextHeader: Int, payload: ByteArray): Int {
        var sum = 0L
        fun addWords(a: ByteArray) { var i = 0; while (i + 1 < a.size) { sum += ((a[i].toInt() and 0xff) shl 8) or (a[i + 1].toInt() and 0xff); i += 2 } }
        addWords(src.address); addWords(dst.address)
        val len = payload.size
        sum += (len ushr 16).toLong() and 0xffff; sum += len.toLong() and 0xffff; sum += nextHeader.toLong() and 0xff
        while ((sum ushr 16) != 0L) sum = (sum and 0xffffL) + (sum ushr 16)
        var i = 0
        while (i + 1 < payload.size) { sum += ((payload[i].toInt() and 0xff) shl 8) or (payload[i + 1].toInt() and 0xff); i += 2; while ((sum ushr 16) != 0L) sum = (sum and 0xffffL) + (sum ushr 16) }
        if (i < payload.size) sum += (payload[i].toInt() and 0xff) shl 8
        while ((sum ushr 16) != 0L) sum = (sum and 0xffffL) + (sum ushr 16)
        return sum.toInt().inv() and 0xffff
    }

    fun validateTcpChecksum(ip: IPv6, raw: ByteArray): Boolean = checksumPseudo(ip.src, ip.dst, 6, raw) == 0
    fun validateUdpChecksum(ip: IPv6, raw: ByteArray): Boolean = checksumPseudo(ip.src, ip.dst, 17, raw) == 0
    fun validateTcpChecksum(src: Inet6Address, dst: Inet6Address, raw: ByteArray): Boolean = checksumPseudo(src, dst, 6, raw) == 0
    fun validateUdpChecksum(src: Inet6Address, dst: Inet6Address, raw: ByteArray): Boolean = checksumPseudo(src, dst, 17, raw) == 0
}
