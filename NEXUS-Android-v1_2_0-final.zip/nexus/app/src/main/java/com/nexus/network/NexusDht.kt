package com.nexus.network

import java.math.BigInteger
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Kademlia-style content lookup core. Records remain signed by their publishers. */
class NexusDht(private val localNodeId: String, private val k: Int = 20) {
    data class Record(
        val key: String,
        val value: String,
        val publisher: String,
        val createdAt: Long,
        val expiresAt: Long,
        val signature: String
    )

    private val records = ConcurrentHashMap<String, Record>()
    private val peers = ConcurrentHashMap<String, Long>()

    fun observePeer(nodeId: String) {
        if (nodeId.isNotBlank() && nodeId != localNodeId) peers[nodeId] = System.currentTimeMillis()
    }

    fun put(record: Record, verifier: ((Record) -> Boolean)? = null): Boolean {
        val now = System.currentTimeMillis()
        if (!valid(record, now)) return false
        if (verifier != null && !verifier(record)) return false
        val old = records[record.key]
        if (old == null || record.createdAt >= old.createdAt) records[record.key] = record
        return true
    }

    fun get(key: String): Record? {
        val record = records[key] ?: return null
        if (record.expiresAt <= System.currentTimeMillis()) {
            records.remove(key, record)
            return null
        }
        return record
    }

    fun closestNodes(key: String, limit: Int = k): List<String> = peers.keys
        .sortedBy { xorDistance(key, it) }
        .take(limit.coerceIn(1, k))

    fun size(): Int = records.size

    fun signed(context: android.content.Context, key: String, value: String, ttlMs: Long = 30L * 24 * 60 * 60 * 1000): Record {
        val created = System.currentTimeMillis()
        val expires = created + ttlMs.coerceIn(60_000L, 90L * 24 * 60 * 60 * 1000)
        val publisher = NexusIdentity.nodeId(context)
        val canonical = canonical(key, value, publisher, created, expires)
        val signature = NexusCrypto.encodeBytes(NexusIdentity.sign(context, canonical))
        return Record(key, value, publisher, created, expires, signature)
    }

    fun verify(record: Record, publisherPublicKey: String): Boolean {
        return NexusIdentity.verify(publisherPublicKey, canonical(record.key, record.value, record.publisher, record.createdAt, record.expiresAt), record.signature)
    }


    fun wire(record: Record): String = NexusCrypto.encode(
        listOf(record.key, record.value, record.publisher, record.createdAt.toString(), record.expiresAt.toString(), record.signature)
            .joinToString("\u001f")
    )

    fun fromWire(wire: String): Record? = runCatching {
        val parts = NexusCrypto.decode(wire).split("\u001f")
        require(parts.size == 6)
        Record(parts[0], parts[1], parts[2], parts[3].toLong(), parts[4].toLong(), parts[5])
    }.getOrNull()

    fun recordsSnapshot(): List<Record> = records.values.filter { it.expiresAt > System.currentTimeMillis() }

    fun expire() {
        val now = System.currentTimeMillis()
        records.entries.removeIf { it.value.expiresAt <= now }
        peers.entries.removeIf { now - it.value > 120_000 }
    }

    fun xorDistance(key: String, nodeId: String): BigInteger {
        val a = idBytes(key)
        val b = idBytes(nodeId)
        return BigInteger(1, ByteArray(32) { i -> (a[i].toInt() xor b[i].toInt()).toByte() })
    }

    private fun canonical(key: String, value: String, publisher: String, createdAt: Long, expiresAt: Long): String =
        "v=1&key=${NexusCrypto.encode(key)}&publisher=$publisher&created=$createdAt&expires=$expiresAt&value=${NexusCrypto.encode(value)}"

    private fun valid(record: Record, now: Long): Boolean =
        record.key.isNotBlank() && record.key.length <= 512 &&
            record.publisher.isNotBlank() && record.value.length <= 16 * 1024 &&
            record.createdAt <= now + 60_000 && record.expiresAt > now &&
            record.expiresAt - record.createdAt <= 90L * 24 * 60 * 60 * 1000

    private fun idBytes(value: String): ByteArray = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
}
