package com.nexus.network

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32

/**
 * Wire framing for a real external radio/laser/modem bridge.
 * The external hardware must provide a byte stream or packet transport.
 * NEXUS supplies framing/integrity; it does not emulate the physical modem.
 */
object NexusExternalLinkProtocol {
    private val MAGIC = byteArrayOf(0x4E, 0x58, 0x4C, 0x31) // NXL1
    const val VERSION = 1
    private const val HEADER = 4 + 1 + 1 + 8 + 4
    private const val TRAILER = 4
    const val MAX_PAYLOAD = 64 * 1024

    data class Frame(val flags: Int, val sequence: Long, val payload: ByteArray)

    fun encode(flags: Int, sequence: Long, payload: ByteArray): ByteArray {
        require(flags in 0..255)
        require(sequence >= 0)
        require(payload.size <= MAX_PAYLOAD)
        val out = ByteArray(HEADER + payload.size + TRAILER)
        System.arraycopy(MAGIC, 0, out, 0, MAGIC.size)
        out[4] = VERSION.toByte()
        out[5] = flags.toByte()
        ByteBuffer.wrap(out, 6, 8).order(ByteOrder.BIG_ENDIAN).putLong(sequence)
        ByteBuffer.wrap(out, 14, 4).order(ByteOrder.BIG_ENDIAN).putInt(payload.size)
        System.arraycopy(payload, 0, out, HEADER, payload.size)
        val crc = CRC32().apply { update(out, 4, HEADER - 4 + payload.size) }.value.toInt()
        ByteBuffer.wrap(out, HEADER + payload.size, 4).order(ByteOrder.BIG_ENDIAN).putInt(crc)
        return out
    }

    fun decode(frame: ByteArray): Frame {
        require(frame.size >= HEADER + TRAILER) { "Trame NXL trop courte" }
        require(MAGIC.contentEquals(frame.copyOfRange(0, 4))) { "Magic NXL invalide" }
        require((frame[4].toInt() and 0xFF) == VERSION) { "Version NXL invalide" }
        val flags = frame[5].toInt() and 0xFF
        val sequence = ByteBuffer.wrap(frame, 6, 8).order(ByteOrder.BIG_ENDIAN).long
        val length = ByteBuffer.wrap(frame, 14, 4).order(ByteOrder.BIG_ENDIAN).int
        require(length >= 0 && length <= MAX_PAYLOAD) { "Taille NXL invalide" }
        require(frame.size == HEADER + length + TRAILER) { "Longueur NXL incohérente" }
        val expected = ByteBuffer.wrap(frame, HEADER + length, 4).order(ByteOrder.BIG_ENDIAN).int
        val actual = CRC32().apply { update(frame, 4, HEADER - 4 + length) }.value.toInt()
        require(expected == actual) { "CRC NXL invalide" }
        return Frame(flags, sequence, frame.copyOfRange(HEADER, HEADER + length))
    }

    fun validateSequence(previous: Long?, current: Long): Boolean = previous == null || current == previous + 1
}
