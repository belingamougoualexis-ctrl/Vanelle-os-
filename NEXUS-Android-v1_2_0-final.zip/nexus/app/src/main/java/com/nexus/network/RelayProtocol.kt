package com.nexus.network

import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket

object RelayProtocol {
    const val VERSION = "NEXUS/1"
    private const val MAX_LINE = 4096
    private const val DEFAULT_TTL = NexusConfig.MAX_HOPS

    data class Request(
        val from: String,
        val ttl: Int,
        val visited: List<String>,
        val host: String,
        val port: Int,
        val nonce: String,
        val mac: String,
        val endToEnd: Boolean = false
    )

    fun openRelay(
        host: String,
        port: Int,
        targetHost: String,
        targetPort: Int,
        secret: String,
        fromNode: String,
        visited: List<String> = listOf(fromNode),
        ttl: Int = DEFAULT_TTL,
        timeoutMs: Int = 8000,
        endToEnd: Boolean = false
    ): NexusStreamChannel {
        require(ttl in 1..NexusConfig.MAX_HOPS)
        require(targetPort in 1..65535)
        require(visited.isNotEmpty() && visited.distinct().size == visited.size)
        val nonce = NexusCrypto.nonce(24)
        val fields = linkedMapOf(
            "from" to NexusCrypto.encode(fromNode),
            "ttl" to ttl.toString(),
            "visited" to NexusCrypto.encode(visited.joinToString(",")),
            "host" to NexusCrypto.encode(targetHost),
            "port" to targetPort.toString(),
            "nonce" to nonce,
            "e2e" to if (endToEnd) "1" else "0"
        )
        val mac = NexusCrypto.hmacHex(secret, canonical(fields))
        val header = "$VERSION RELAY v=2 ${fields.entries.joinToString(" ") { "${it.key}=${it.value}" }} mac=$mac\n"

        val socket = Socket()
        socket.connect(InetSocketAddress(host, port), timeoutMs)
        socket.soTimeout = 15000
        socket.getOutputStream().apply {
            write(header.toByteArray(Charsets.US_ASCII))
            flush()
        }
        val response = readAsciiLine(socket.getInputStream(), 256)
        if (response != "$VERSION RELAY-OK v=2") {
            socket.close()
            error(response.ifBlank { "Relay refusé" })
        }
        socket.soTimeout = 0
        return RelayStreamChannel(socket, nonce, secret)
    }

    fun acceptedChannel(socket: Socket, request: Request, secret: String): NexusStreamChannel =
        RelayStreamChannel(socket, request.nonce, secret)

    fun parse(line: String): Request? {
        if (!line.startsWith("$VERSION RELAY ")) return null
        val fields = line.removePrefix("$VERSION RELAY ").trim().split(' ').filter { it.isNotEmpty() }
            .associate { token ->
                val i = token.indexOf('=')
                (if (i > 0) token.substring(0, i) else token) to (if (i > 0) token.substring(i + 1) else "")
            }
        val from = fields["from"] ?: return null
        val ttl = fields["ttl"]?.toIntOrNull() ?: return null
        val visitedRaw = fields["visited"] ?: return null
        val host = fields["host"] ?: return null
        val port = fields["port"]?.toIntOrNull() ?: return null
        val nonce = fields["nonce"] ?: return null
        val mac = fields["mac"] ?: return null
        return runCatching {
            Request(
                NexusCrypto.decode(from),
                ttl,
                NexusCrypto.decode(visitedRaw).split(',').filter { it.isNotBlank() },
                NexusCrypto.decode(host),
                port,
                nonce,
                mac,
                fields["e2e"] == "1"
            )
        }.getOrNull()
    }

    fun authenticate(request: Request, secret: String): Boolean {
        val fields = linkedMapOf(
            "from" to NexusCrypto.encode(request.from),
            "ttl" to request.ttl.toString(),
            "visited" to NexusCrypto.encode(request.visited.joinToString(",")),
            "host" to NexusCrypto.encode(request.host),
            "port" to request.port.toString(),
            "nonce" to request.nonce,
            "e2e" to if (request.endToEnd) "1" else "0"
        )
        val expected = NexusCrypto.hmacHex(secret, canonical(fields))
        return NexusCrypto.constantTimeEquals(expected, request.mac)
    }

    fun canonical(fields: Map<String, String>): String =
        fields.entries.sortedBy { it.key }.joinToString("&") { "${it.key}=${it.value}" }

    fun readAsciiLine(input: InputStream, maxBytes: Int = MAX_LINE): String {
        val buffer = ByteArray(maxBytes)
        var count = 0
        while (count < maxBytes) {
            val b = input.read()
            if (b < 0) break
            if (b == '\n'.code) break
            if (b != '\r'.code) buffer[count++] = b.toByte()
        }
        if (count >= maxBytes) error("Relay header trop longue")
        return String(buffer, 0, count, Charsets.US_ASCII)
    }
}
