# Conditions d’utilisation — NEXUS

**Dernière mise à jour : septembre 2026**  
**Contact : monsieurmoi68@gmail.com**

## 1. Objet

NEXUS est une application de **réseau maillé de résilience**. Elle permet de relayer, stocker et router du trafic entre appareils compatibles, dans le respect des lois applicables.

## 2. Acceptation

En installant ou utilisant NEXUS, vous acceptez les présentes conditions. Si vous ne les acceptez pas, n’utilisez pas l’application.

## 3. Licence

Une licence personnelle, non exclusive et non transférable vous est accordée pour utiliser l’application sur vos appareils.

## 4. Usage autorisé

Vous vous engagez à utiliser NEXUS de façon légale, notamment :

- ne pas nuire aux autres utilisateurs ni aux réseaux ;
- ne pas contourner les mesures de sécurité ;
- respecter la vie privée d’autrui ;
- ne pas utiliser l’application à des fins illicites.

## 5. Contenu et responsabilités

Vous êtes responsable des contenus que vous importez ou partagez.  
NEXUS s’appuie sur les connexions déjà présentes sur l’appareil (Wi‑Fi, mobile, etc.) et ne crée pas de lien radio, fibre ou satellite.

## 6. Disponibilité

Le fonctionnement dépend de votre environnement réseau et des autres nœuds éventuels. Aucune disponibilité permanente n’est garantie.

## 7. Limitation de responsabilité

Dans les limites autorisées par la loi, l’éditeur ne saurait être tenu responsable des dommages indirects liés à l’usage de l’application.

## 8. Données personnelles

Le traitement des données est décrit dans la **Politique de confidentialité**.

## 9. Modifications

Ces conditions peuvent être mises à jour. La version en vigueur est consultable dans l’application (Paramètres → Informations légales).

## 10. Contact

**monsieurmoi68@gmail.com**
