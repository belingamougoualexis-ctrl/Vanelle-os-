# Politique de confidentialité — NEXUS

**Dernière mise à jour : septembre 2026**  
**Contact : monsieurmoi68@gmail.com**

## 1. Responsable du traitement

L’application **NEXUS** est éditée par le développeur joignable à l’adresse **monsieurmoi68@gmail.com**.

## 2. Données collectées

NEXUS fonctionne principalement **en local** sur votre appareil. Il n’existe pas de serveur publicitaire central géré par l’éditeur.

Selon l’usage, l’application peut traiter localement :

- un identifiant technique de nœud généré sur l’appareil ;
- des informations de réseau nécessaires au fonctionnement (état de connexion, appareils découverts sur le réseau local) ;
- la clé réseau que vous saisissez (stockée de façon sécurisée sur l’appareil) ;
- les fichiers que vous importez volontairement dans le stockage local.

## 3. Finalités

Ces données sont utilisées uniquement pour :

- faire fonctionner le réseau maillé ;
- assurer la sécurité des échanges que vous activez ;
- fournir les fonctions que vous choisissez (passerelle, tunnel, stockage).

## 4. Partage et vente

**Aucune vente de données personnelles.**  
Les échanges entre appareils NEXUS dépendent de vos réglages (clé, confiance, passerelle).

## 5. Conservation

Les données restent sur votre appareil tant que l’application est installée. La désinstallation de NEXUS supprime les données locales de l’application.

## 6. Permissions Android

Selon les fonctions utilisées, NEXUS peut demander :

- accès réseau ;
- proximité / localisation (si requis par Android pour la découverte d’appareils) ;
- notifications ;
- autorisation VPN (uniquement si vous activez le tunnel sécurisé).

Chaque permission est liée à une fonction précise.

## 7. Vos droits

Vous pouvez demander des informations, une correction ou une suppression en écrivant à **monsieurmoi68@gmail.com**.

## 8. Mineurs

L’application n’est pas destinée aux enfants de moins de 13 ans.

## 9. Contact

**monsieurmoi68@gmail.com**
