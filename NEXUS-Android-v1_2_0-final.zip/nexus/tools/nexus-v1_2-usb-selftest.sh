#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
kotlinc \
  "$ROOT/tools/test-stubs/android/content/Context.kt" \
  "$ROOT/tools/test-stubs/android/content/pm/PackageManager.kt" \
  "$ROOT/tools/test-stubs/android/net/ConnectivityManager.kt" \
  "$ROOT/tools/test-stubs/android/net/Network.kt" \
  "$ROOT/tools/test-stubs/android/net/NetworkCapabilities.kt" \
  "$ROOT/tools/test-stubs/android/net/LinkProperties.kt" \
  "$ROOT/tools/test-stubs/android/hardware/usb/UsbConstants.kt" \
  "$ROOT/tools/test-stubs/android/hardware/usb/UsbEndpoint.kt" \
  "$ROOT/tools/test-stubs/android/hardware/usb/UsbInterface.kt" \
  "$ROOT/tools/test-stubs/android/hardware/usb/UsbDevice.kt" \
  "$ROOT/tools/test-stubs/android/hardware/usb/UsbDeviceConnection.kt" \
  "$ROOT/tools/test-stubs/android/hardware/usb/UsbManager.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusExternalLinkProtocol.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusUsbNxlTransport.kt" \
  "$ROOT/tools/physical_usb_nxl_selftest.kt" \
  -include-runtime -d "$OUT/test.jar"
java -jar "$OUT/test.jar"
