import com.nexus.network.MeshRouter
import com.nexus.network.NsdController

fun main() {
    val now = System.currentTimeMillis()
    val peers = listOf(
        NsdController.Peer("G1", "127.0.0.1", 45456, relay = true, gatewayDistance = 0, gatewayPath = listOf("G1"), latencyMs = 30.0, lastSeenAt = now),
        NsdController.Peer("B", "127.0.0.2", 45456, relay = true, gatewayDistance = 1, gatewayPath = listOf("B", "G4"), latencyMs = 5.0, lastSeenAt = now),
        NsdController.Peer("G2", "127.0.0.4", 45456, relay = true, gatewayDistance = 0, gatewayPath = listOf("G2"), latencyMs = 50.0, lastSeenAt = now),
        NsdController.Peer("G3", "127.0.0.5", 45456, relay = true, gatewayDistance = 0, gatewayPath = listOf("G3"), latencyMs = 70.0, lastSeenAt = now),
        NsdController.Peer("G4", "127.0.0.6", 45456, relay = true, gatewayDistance = 0, gatewayPath = listOf("G4"), latencyMs = 90.0, lastSeenAt = now)
    )
    val router = MeshRouter("LOCAL") { peers }
    check(router.gatewayPath(false, true) == listOf("LOCAL", "G1"))
    check(router.gatewayDistance(false, true) == 1)
    router.reportFailure("G1")
    check(router.gatewayPath(false, true) == listOf("LOCAL", "G2"))
    router.reportFailure("G2")
    check(router.gatewayPath(false, true) == listOf("LOCAL", "G3"))
    router.reportFailure("G3")
    check(router.gatewayPath(false, true) == listOf("LOCAL", "G4"))
    router.reportFailure("G4")
    check(router.gatewayPath(false, true) == listOf("LOCAL", "B", "G4"))
    check(router.gatewayDistance(false, true) == 2)
    println("MESH ROUTE CORE REAL SELF-TEST: OK")
}
