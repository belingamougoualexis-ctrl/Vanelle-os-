package com.nexus.network

import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

fun main() {
    secureFramingTest()
    nxpControlAndBandwidthTest()
    singleRelayTcpTest()
    singleRelayUdpTest()
    multiHopRelayTcpTest()
    multiHopRelayUdpTest()
    userspaceTunTcpTest()
    userspaceTunUdpTest()
    socks5ConnectTest()
    socks5UdpAssociateTest()
    println("NEXUS legacy REAL self-test: OK")
}

private fun secureFramingTest() {
    val secret = "NEXUS-test-secret-2026"
    val nonce = NexusCrypto.nonce(24)
    val key = NexusSecureFraming.deriveKey(secret, nonce)
    val message = "confidential-nexus".repeat(64).toByteArray()
    val encrypted = NexusSecureFraming.encrypt(key, message)
    check(!encrypted.contentEquals(message))
    check(NexusSecureFraming.decrypt(key, encrypted).contentEquals(message))
    val tampered = encrypted.clone().also { it[it.lastIndex] = (it.last().toInt() xor 1).toByte() }
    check(runCatching { NexusSecureFraming.decrypt(key, tampered) }.isFailure)
}

private fun nxpControlAndBandwidthTest() {
    val secret = "NEXUS-test-secret-2026"
    val server = ServerSocket(0)
    val worker = thread(start = true, isDaemon = true) {
        repeat(2) {
            server.accept().use { socket ->
                socket.soTimeout = 15_000
                NxpProtocol.serverHandshake(
                    socket,
                    "NX-NXP",
                    gateway = true,
                    relay = true,
                    gatewayDistance = 0,
                    secretProvider = { listOf(secret) }
                )
            }
        }
        server.close()
    }
    val metrics = NxpProtocol.measurePeer("127.0.0.1", server.localPort) { listOf(secret) }.getOrThrow()
    check(metrics.latencyMs.isFinite())
    check(metrics.packetLossPct in 0.0..100.0)
    val bandwidth = NxpProtocol.measureBandwidth("127.0.0.1", server.localPort, { listOf(secret) }, 64 * 1024).getOrThrow()
    check(bandwidth.downloadMbps > 0.0)
    check(bandwidth.uploadMbps > 0.0)
    worker.join(3000)
}

private fun singleRelayTcpTest() {
    val echo = tcpEchoServer()
    val secret = "NEXUS-test-secret-2026"
    val relay = relay(45_456, "NX-RELAY", direct = true, secret = secret)
    relay.start()
    sleep()
    RelayProtocol.openRelay("127.0.0.1", 45_456, "127.0.0.1", echo.first, secret, "NX-A").use { channel ->
        val payload = "single-hop-tcp".toByteArray()
        channel.output.write(payload); channel.output.flush()
        check(readExactly(channel.input, payload.size).contentEquals(payload))
    }
    relay.stop()
    echo.second.join(1000)
}

private fun singleRelayUdpTest() {
    val echo = udpEchoServer()
    val secret = "NEXUS-test-secret-2026"
    val relay = relay(45_456, "NX-RELAY", direct = true, secret = secret)
    relay.start(); sleep()
    DatagramRelayProtocol.openRelay(
        "127.0.0.1", 45_456, "127.0.0.1", echo.first, secret, "NX-A", listOf("NX-A"), 8
    ).use { session ->
        val payload = "single-hop-udp".toByteArray()
        session.send(payload)
        check(session.receive()?.contentEquals(payload) == true)
    }
    relay.stop()
    echo.second.join(1000)
}

private fun multiHopRelayTcpTest() {
    val echo = tcpEchoServer()
    val secret = "NEXUS-test-secret-2026"
    val gateway = relay(45_460, "NX-C", direct = true, secret = secret)
    val relayB = RelayServer(
        45_461,
        nodeIdProvider = { "NX-B" },
        secretProvider = { listOf(secret) },
        directInternetAvailable = { false },
        nextHopSelector = { visited -> if ("NX-C" !in visited) MeshRouter.NextHop("NX-C", "127.0.0.1", 45_460, 0, 0.0, false) else null },
        nextHopCandidatesSelector = { visited -> if ("NX-C" !in visited) listOf(MeshRouter.NextHop("NX-C", "127.0.0.1", 45_460, 0, 0.0, false)) else emptyList() }
    )
    gateway.start(); relayB.start(); sleep()
    RelayProtocol.openRelay("127.0.0.1", 45_461, "127.0.0.1", echo.first, secret, "NX-A", listOf("NX-A"), 8).use { channel ->
        val payload = "multi-hop-tcp".toByteArray()
        channel.output.write(payload); channel.output.flush()
        check(readExactly(channel.input, payload.size).contentEquals(payload))
    }
    relayB.stop(); gateway.stop(); echo.second.join(1000)
}

private fun multiHopRelayUdpTest() {
    val echo = udpEchoServer()
    val secret = "NEXUS-test-secret-2026"
    val gateway = relay(45_462, "NX-C", direct = true, secret = secret)
    val relayB = RelayServer(
        45_463,
        nodeIdProvider = { "NX-B" },
        secretProvider = { listOf(secret) },
        directInternetAvailable = { false },
        nextHopSelector = { visited -> if ("NX-C" !in visited) MeshRouter.NextHop("NX-C", "127.0.0.1", 45_462, 0, 0.0, false) else null },
        nextHopCandidatesSelector = { visited -> if ("NX-C" !in visited) listOf(MeshRouter.NextHop("NX-C", "127.0.0.1", 45_462, 0, 0.0, false)) else emptyList() }
    )
    gateway.start(); relayB.start(); sleep()
    DatagramRelayProtocol.openRelay("127.0.0.1", 45_463, "127.0.0.1", echo.first, secret, "NX-A", listOf("NX-A"), 8).use { session ->
        val payload = "multi-hop-udp".toByteArray()
        session.send(payload)
        check(session.receive()?.contentEquals(payload) == true)
    }
    relayB.stop(); gateway.stop(); echo.second.join(1000)
}

private fun userspaceTunTcpTest() {
    val echo = tcpEchoServer()
    val (tunInWriter, tunInReader) = pipePair()
    val (tunOutWriter, tunOutReader) = pipePair()
    val clientIp = InetAddress.getByName("10.255.0.2") as Inet4Address
    val remoteIp = InetAddress.getByName("127.0.0.1") as Inet4Address
    val stack = UserSpaceIpStack(tunInReader, tunOutWriter, object : UserSpaceIpStack.UpstreamTransport {
        override fun openTcp(host: String, port: Int): NexusStreamChannel = SocketStreamChannel(Socket().apply { connect(InetSocketAddress(host, port), 3000) })
        override fun openUdp(host: String, port: Int): UserSpaceIpStack.UdpChannel = error("unused")
    })
    stack.start()
    val clientSeq = 10_000L
    tunInWriter.write(IpPacket.buildTcp(clientIp, remoteIp, 40_000, echo.first, clientSeq, 0, 0x002, identification = 1)); tunInWriter.flush()
    val synAck = waitForIpPacket(tunOutReader)
    val synAckTcp = IpPacket.parseTcp(synAck.payload) ?: error("SYN-ACK absent")
    check(synAckTcp.syn && synAckTcp.ack)
    val ack = IpPacket.buildTcp(clientIp, remoteIp, 40_000, echo.first, clientSeq + 1, synAckTcp.sequence + 1, 0x010, identification = 2)
    tunInWriter.write(ack); tunInWriter.flush()
    val payload = "tun-real-tcp".toByteArray()
    tunInWriter.write(IpPacket.buildTcp(clientIp, remoteIp, 40_000, echo.first, clientSeq + 1, synAckTcp.sequence + 1, 0x018, payload = payload, identification = 3)); tunInWriter.flush()
    val tcp = waitForTcpPayload(tunOutReader, payload.size)
    check(tcp.payload.contentEquals(payload))
    stack.stop(); closePipes(tunInWriter, tunInReader, tunOutWriter, tunOutReader); echo.second.join(1000)
}

private fun userspaceTunUdpTest() {
    val echo = udpEchoServer()
    val (tunInWriter, tunInReader) = pipePair()
    val (tunOutWriter, tunOutReader) = pipePair()
    val clientIp = InetAddress.getByName("10.255.0.2") as Inet4Address
    val remoteIp = InetAddress.getByName("127.0.0.1") as Inet4Address
    val stack = UserSpaceIpStack(tunInReader, tunOutWriter, object : UserSpaceIpStack.UpstreamTransport {
        override fun openTcp(host: String, port: Int): NexusStreamChannel = error("unused")
        override fun openUdp(host: String, port: Int): UserSpaceIpStack.UdpChannel = NexusUdpChannels.direct(host, port)
    })
    stack.start()
    val payload = "tun-real-udp".toByteArray()
    tunInWriter.write(IpPacket.buildUdp(clientIp, remoteIp, 40_001, echo.first, payload, identification = 11)); tunInWriter.flush()
    val response = waitForIpPacket(tunOutReader)
    val udp = IpPacket.parseUdp(response.payload) ?: error("UDP response absent")
    check(udp.payload.contentEquals(payload))
    check(IpPacket.validateUdpChecksum(response, udp, response.payload))
    stack.stop(); closePipes(tunInWriter, tunInReader, tunOutWriter, tunOutReader); echo.second.join(1000)
}

private fun socks5ConnectTest() {
    val echo = tcpEchoServer()
    val server = Socks5Server(45_470, "nexus", "NEXUS-LOCAL")
    server.start(); sleep()
    Socket("127.0.0.1", 45_470).use { socket ->
        val input = socket.getInputStream(); val output = socket.getOutputStream()
        output.write(byteArrayOf(5, 1, 2)); output.flush(); check(readBytes(input, 2).contentEquals(byteArrayOf(5, 2)))
        val u = "nexus".toByteArray(); val p = "NEXUS-LOCAL".toByteArray()
        output.write(byteArrayOf(1, u.size.toByte())); output.write(u); output.write(p.size); output.write(p); output.flush()
        check(readBytes(input, 2).contentEquals(byteArrayOf(1, 0)))
        val req = byteArrayOf(5, 1, 0, 1, 127, 0, 0, 1, (echo.first ushr 8).toByte(), echo.first.toByte())
        output.write(req); output.flush()
        val reply = readBytes(input, 10); check(reply[1].toInt() == 0)
        val payload = "socks-connect".toByteArray(); output.write(payload); output.flush()
        check(readExactly(input, payload.size).contentEquals(payload))
    }
    server.stop(); echo.second.join(1000)
}

private fun socks5UdpAssociateTest() {
    val echo = udpEchoServer()
    val server = Socks5Server(45_471, "nexus", "NEXUS-LOCAL", udpConnector = { host, port -> NexusUdpChannels.direct(host, port) })
    server.start(); sleep()
    Socket("127.0.0.1", 45_471).use { control ->
        val input = control.getInputStream(); val output = control.getOutputStream()
        output.write(byteArrayOf(5, 1, 2)); output.flush(); check(readBytes(input, 2).contentEquals(byteArrayOf(5, 2)))
        val u = "nexus".toByteArray(); val p = "NEXUS-LOCAL".toByteArray()
        output.write(byteArrayOf(1, u.size.toByte())); output.write(u); output.write(p.size); output.write(p); output.flush()
        check(readBytes(input, 2).contentEquals(byteArrayOf(1, 0)))
        output.write(byteArrayOf(5, 3, 0, 1, 0, 0, 0, 0, 0, 0)); output.flush()
        val reply = readBytes(input, 10); check(reply[1].toInt() == 0)
        val atyp = reply[3].toInt() and 0xff
        val bindHostBytes = if (atyp == 1) 4 else 16
        val addrStart = 4
        val bindHost = InetAddress.getByAddress(reply.copyOfRange(addrStart, addrStart + bindHostBytes)).hostAddress
        val bindPort = ((reply[addrStart + bindHostBytes].toInt() and 0xff) shl 8) or (reply[addrStart + bindHostBytes + 1].toInt() and 0xff)
        check(bindPort > 0)
        DatagramSocket().use { clientUdp ->
            val body = "socks-udp".toByteArray()
            val header = byteArrayOf(0, 0, 0, 1, 127, 0, 0, 1, (echo.first ushr 8).toByte(), echo.first.toByte())
            val packetBytes = header + body
            clientUdp.send(DatagramPacket(packetBytes, packetBytes.size, InetAddress.getByName(bindHost), bindPort))
            clientUdp.soTimeout = 3000
            val receivedBuffer = ByteArray(2048)
            val packet = DatagramPacket(receivedBuffer, receivedBuffer.size)
            clientUdp.receive(packet)
            val response = packet.data.copyOf(packet.length)
            check(response.copyOfRange(response.size - body.size, response.size).contentEquals(body))
        }
    }
    server.stop(); echo.second.join(1000)
}

private fun relay(port: Int, id: String, direct: Boolean, secret: String): RelayServer = RelayServer(
    port = port,
    nodeIdProvider = { id },
    secretProvider = { listOf(secret) },
    directInternetAvailable = { direct },
    nextHopSelector = { null },
    protectSocket = { true },
    protectDatagram = { true }
)

private fun tcpEchoServer(): Pair<Int, Thread> {
    val server = ServerSocket(0)
    val t = thread(start = true, isDaemon = true) {
        server.use { s -> s.accept().use { c ->
            val buffer = ByteArray(16 * 1024)
            while (true) {
                val n = c.getInputStream().read(buffer)
                if (n < 0) break
                if (n > 0) { c.getOutputStream().write(buffer, 0, n); c.getOutputStream().flush() }
            }
        }}
    }
    return server.localPort to t
}

private fun udpEchoServer(): Pair<Int, Thread> {
    val socket = DatagramSocket(0)
    val t = thread(start = true, isDaemon = true) {
        socket.use { s ->
            val buffer = ByteArray(65_535)
            while (!s.isClosed) {
                try {
                    val packet = DatagramPacket(buffer, buffer.size)
                    s.receive(packet)
                    s.send(DatagramPacket(packet.data.copyOf(packet.length), packet.length, packet.address, packet.port))
                    break
                } catch (_: Exception) { break }
            }
        }
    }
    return socket.localPort to t
}

private fun pipePair(): Pair<PipedOutputStream, PipedInputStream> {
    val out = PipedOutputStream()
    return out to PipedInputStream(out, 128 * 1024)
}

private fun waitForIpPacket(input: PipedInputStream, timeoutMs: Long = 5000): IpPacket.IPv4 {
    val deadline = System.currentTimeMillis() + timeoutMs
    while (System.currentTimeMillis() < deadline) {
        if (input.available() >= 20) {
            val header = ByteArray(20); readFully(input, header)
            val total = IpPacket.u16(header, 2)
            val rest = ByteArray(total - 20); readFully(input, rest)
            return IpPacket.parseIpv4(header + rest) ?: error("invalid IP")
        }
        Thread.sleep(5)
    }
    error("TUN output timeout")
}

private fun waitForTcpPayload(input: PipedInputStream, size: Int, timeoutMs: Long = 5000): IpPacket.Tcp {
    val deadline = System.currentTimeMillis() + timeoutMs
    while (System.currentTimeMillis() < deadline) {
        if (input.available() >= 20) {
            val packet = waitForIpPacket(input, 1000)
            val tcp = IpPacket.parseTcp(packet.payload) ?: continue
            if (tcp.payload.size == size && tcp.payload.isNotEmpty()) return tcp
        } else Thread.sleep(5)
    }
    error("TCP payload output timeout")
}

private fun readBytes(input: java.io.InputStream, size: Int): ByteArray = ByteArray(size).also { readFully(input, it) }
private fun readExactly(input: java.io.InputStream, size: Int): ByteArray = readBytes(input, size)
private fun readFully(input: java.io.InputStream, bytes: ByteArray) {
    var o = 0
    while (o < bytes.size) {
        val n = input.read(bytes, o, bytes.size - o)
        if (n < 0) error("EOF")
        o += n
    }
}

private fun closePipes(vararg closeables: AutoCloseable) = closeables.forEach { runCatching { it.close() } }
private fun sleep() = Thread.sleep(150)
