#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
kotlinc "$ROOT/tools/test-stubs/com/nexus/network/NsdController.kt" "$ROOT/tools/test-stubs/com/nexus/network/NexusP2PDirectory.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusConfig.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusGlobalRouting.kt" "$ROOT/app/src/main/java/com/nexus/network/MeshRouter.kt" "$ROOT/tools/meshroute_core_selftest.kt" -include-runtime -d "$OUT/test.jar"
java -jar "$OUT/test.jar"
