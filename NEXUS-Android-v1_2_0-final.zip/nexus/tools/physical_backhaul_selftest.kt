package com.nexus.network

fun main() {
    val frame = NexusExternalLinkProtocol.encode(7, 41L, "NEXUS-PHYSICAL-LINK".toByteArray())
    val parsed = NexusExternalLinkProtocol.decode(frame)
    check(parsed.flags == 7)
    check(parsed.sequence == 41L)
    check(String(parsed.payload) == "NEXUS-PHYSICAL-LINK")
    check(NexusExternalLinkProtocol.validateSequence(null, 0L))
    check(NexusExternalLinkProtocol.validateSequence(9L, 10L))
    check(!NexusExternalLinkProtocol.validateSequence(9L, 12L))

    val allocations = NexusMultipathPlanner.allocate(
        listOf(
            NexusMultipathPlanner.Path("fiber", 100_000, 50_000, 15.0, 1.0, false, true),
            NexusMultipathPlanner.Path("satellite", 20_000, 8_000, 120.0, 2.0, true, true),
            NexusMultipathPlanner.Path("dead", 50_000, 50_000, 10.0, 100.0, false, false)
        )
    )
    check(allocations.size == 2)
    check(allocations.sumOf { it.weight } in 0.999..1.001)
    check(allocations.first().id == "fiber")
    println("PHYSICAL BACKHAUL / EXTERNAL LINK / MULTIPATH SELF-TEST: OK")
}
