package com.nexus.network
import android.content.Context
import java.io.InputStream
import java.io.OutputStream
class NexusCreditGatedChannel(private val base: NexusStreamChannel, context: Context?, peerId: String): NexusStreamChannel {
    override val input: InputStream get() = base.input
    override val output: OutputStream get() = base.output
    override fun shutdownOutput() = base.shutdownOutput()
    override fun close() = base.close()
}
