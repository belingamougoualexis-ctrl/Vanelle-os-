package com.nexus.network

object NexusP2PDirectory {
    data class Endpoint(
        val id: String, val displayName: String, val deviceAddress: String, val host: String,
        val port: Int = 45454, var gateway: Boolean = false, var relay: Boolean = false,
        var gatewayDistance: Int = Int.MAX_VALUE, var gatewayPath: List<String> = emptyList(), var latencyMs: Double = Double.POSITIVE_INFINITY,
        var packetLossPct: Double = 100.0, var bandwidthMbps: Double = 0.0, var consecutiveFailures: Int = 0,
        var identityPublicKey: String = "", var gatewayPublicKey: String = "", var authenticatedIdentity: Boolean = false
    )
    fun snapshot(): List<Endpoint> = emptyList()
}
