package com.nexus.network
import android.content.Context
object NexusNaming {
    data class Record(val name:String, val nodeId:String, val publicKey:String, val addresses:List<String>, val createdAt:Long, val expiresAt:Long, val signature:String)
    fun resolve(context: Context, name: String): Record? = null
    fun wire(record: Record): String = NexusCrypto.encode("stub")
    fun fromWire(value: String): Record? = null
    fun resolveDistributed(context: Context, name: String, peers: Collection<NsdController.Peer>): Record? = null
}
