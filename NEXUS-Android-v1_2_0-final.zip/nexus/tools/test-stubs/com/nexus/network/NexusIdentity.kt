package com.nexus.network

import android.content.Context
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.KeyAgreement

object NexusIdentity {
    private val keyPair: KeyPair = KeyPairGenerator.getInstance("EC").apply {
        initialize(ECGenParameterSpec("secp256r1"))
    }.generateKeyPair()

    fun generateEphemeral(): KeyPair = KeyPairGenerator.getInstance("EC").apply {
        initialize(ECGenParameterSpec("secp256r1"))
    }.generateKeyPair()

    fun publicKeyBase64(context: Context): String = NexusCrypto.encodeBytes(keyPair.public.encoded)
    fun sign(context: Context, canonical: String): ByteArray = Signature.getInstance("SHA256withECDSA").apply {
        initSign(keyPair.private)
        update(canonical.toByteArray(Charsets.UTF_8))
    }.sign()

    fun verify(publicKeyB64: String, canonical: String, signatureB64: String): Boolean = runCatching {
        val publicKey = KeyFactory.getInstance("EC").generatePublic(
            X509EncodedKeySpec(NexusCrypto.decodeBytes(publicKeyB64))
        )
        Signature.getInstance("SHA256withECDSA").apply {
            initVerify(publicKey)
            update(canonical.toByteArray(Charsets.UTF_8))
        }.verify(NexusCrypto.decodeBytes(signatureB64))
    }.getOrDefault(false)

    fun ecdh(privateKey: PrivateKey, peerPublicKeyB64: String): ByteArray {
        val publicKey = KeyFactory.getInstance("EC").generatePublic(
            X509EncodedKeySpec(NexusCrypto.decodeBytes(peerPublicKeyB64))
        )
        return KeyAgreement.getInstance("ECDH").apply {
            init(privateKey)
            doPhase(publicKey, true)
        }.generateSecret()
    }

    fun nodeId(context: Context): String = "TEST-NODE"
}
