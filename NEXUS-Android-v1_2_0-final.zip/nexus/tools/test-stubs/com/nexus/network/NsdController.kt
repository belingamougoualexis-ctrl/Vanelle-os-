package com.nexus.network

class NsdController {
    data class Peer(
        val name: String,
        val host: String,
        val port: Int,
        var gateway: Boolean = false,
        var relay: Boolean = false,
        var gatewayDistance: Int = Int.MAX_VALUE,
        var gatewayPath: List<String> = emptyList(),
        var latencyMs: Double = Double.POSITIVE_INFINITY,
        var packetLossPct: Double = 100.0,
        var bandwidthMbps: Double = 0.0,
        var consecutiveFailures: Int = 0,
        var lastSeenAt: Long = System.currentTimeMillis(),
        var lastProbeAt: Long = 0L,
        var p2p: Boolean = false,
        var identityPublicKey: String = "",
        var gatewayPublicKey: String = "",
        var authenticatedIdentity: Boolean = false
    )
}
