package com.nexus.network
import android.content.Context
object NexusCredits {
    fun relay(context: Context, peerId: String, bytes: Long): Long = 0L
    fun spend(context: Context, peerId: String, bytes: Long): Boolean = true
}
