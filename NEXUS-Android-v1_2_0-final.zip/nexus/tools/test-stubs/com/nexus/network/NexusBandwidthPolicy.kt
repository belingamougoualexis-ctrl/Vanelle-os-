package com.nexus.network
import android.content.Context
class NexusBandwidthPolicy private constructor() {
    fun allow(bytes: Int, peerId: String = "remote"): Boolean = bytes >= 0
    companion object { fun forContext(context: Context): NexusBandwidthPolicy = NexusBandwidthPolicy() }
}
