package com.nexus.network
import android.content.Context
import java.net.DatagramSocket
import java.net.InetAddress
object NexusDns {
    val IPV4: InetAddress = InetAddress.getByName("10.255.0.1")
    val IPV6: InetAddress = InetAddress.getByName("fd00:4e58:5553::1")
    fun handleQuery(context: Context, query: ByteArray, peers: Collection<NsdController.Peer>, protect: (DatagramSocket) -> Boolean, dnsServers: List<String>): ByteArray? = null
}
