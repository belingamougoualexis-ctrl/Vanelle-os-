package android.content.pm

open class PackageManager {
    companion object { const val FEATURE_USB_HOST = "android.hardware.usb.host" }
    open fun hasSystemFeature(name: String): Boolean = false
}
