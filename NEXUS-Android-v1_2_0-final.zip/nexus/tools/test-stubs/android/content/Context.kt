package android.content

import java.io.File
import android.net.ConnectivityManager
import android.content.pm.PackageManager
import kotlin.io.path.createTempDirectory

open class Context {
    open val filesDir: File = createTempDirectory("nexus-test-files-").toFile().apply { mkdirs() }
    open val cacheDir: File = File(filesDir, "cache").apply { mkdirs() }
    open val applicationContext: Context get() = this
    open val packageManager: PackageManager = PackageManager()
    open fun <T> getSystemService(serviceClass: Class<T>): T? =
        if (serviceClass == ConnectivityManager::class.java) ConnectivityManager() as T else null
    fun getSharedPreferences(name: String, mode: Int): SharedPreferences = SharedPreferences()
    companion object { const val MODE_PRIVATE: Int = 0 }
}

class SharedPreferences {
    private val values = mutableMapOf<String, Any?>()
    fun getString(key: String, def: String?): String? = values[key] as? String ?: def
    fun getStringSet(key: String, def: Set<String>?): Set<String>? = values[key] as? Set<String> ?: def
    fun getLong(key: String, def: Long): Long = (values[key] as? Number)?.toLong() ?: def
    fun getInt(key: String, def: Int): Int = (values[key] as? Number)?.toInt() ?: def
    fun getBoolean(key: String, def: Boolean): Boolean = values[key] as? Boolean ?: def
    fun edit(): Editor = Editor(values)
    class Editor(private val values: MutableMap<String, Any?>) {
        fun putString(key: String, value: String?): Editor { values[key] = value; return this }
        fun putStringSet(key: String, value: Set<String>): Editor { values[key] = value; return this }
        fun putLong(key: String, value: Long): Editor { values[key] = value; return this }
        fun putInt(key: String, value: Int): Editor { values[key] = value; return this }
        fun putBoolean(key: String, value: Boolean): Editor { values[key] = value; return this }
        fun remove(key: String): Editor { values.remove(key); return this }
        fun apply() = Unit
    }
}
