package android.hardware.usb
open class UsbDeviceConnection {
    open fun claimInterface(usbInterface: UsbInterface, force: Boolean): Boolean = true
    open fun releaseInterface(usbInterface: UsbInterface): Boolean = true
    open fun bulkTransfer(endpoint: UsbEndpoint, buffer: ByteArray, offset: Int, length: Int, timeout: Int): Int = length
    open fun close() = Unit
}
