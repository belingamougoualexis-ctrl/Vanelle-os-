package android.hardware.usb
open class UsbDevice(
    open val vendorId: Int = 0,
    open val productId: Int = 0,
    open val productName: String? = null,
    open val manufacturerName: String? = null,
    open val interfaces: Array<UsbInterface> = emptyArray()
) {
    val interfaceCount: Int get() = interfaces.size
    fun getInterface(index: Int): UsbInterface = interfaces[index]
}
