package android.hardware.usb
open class UsbManager {
    open val deviceList: Map<String, UsbDevice> = emptyMap()
    open fun hasPermission(device: UsbDevice): Boolean = false
    open fun openDevice(device: UsbDevice): UsbDeviceConnection? = UsbDeviceConnection()
}
