package android.hardware.usb
open class UsbInterface(open val id: Int = 0, open val interfaceClass: Int = 0, open val endpoints: Array<UsbEndpoint> = emptyArray()) {
    val endpointCount: Int get() = endpoints.size
    fun getEndpoint(index: Int): UsbEndpoint = endpoints[index]
}
