package android.hardware.usb
object UsbConstants {
    const val USB_ENDPOINT_XFER_BULK: Int = 2
    const val USB_DIR_IN: Int = 0x80
    const val USB_DIR_OUT: Int = 0x00
}
