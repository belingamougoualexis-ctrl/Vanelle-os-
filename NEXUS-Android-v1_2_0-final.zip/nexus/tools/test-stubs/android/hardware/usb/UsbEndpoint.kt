package android.hardware.usb
open class UsbEndpoint(open val type: Int = UsbConstants.USB_ENDPOINT_XFER_BULK, open val direction: Int = UsbConstants.USB_DIR_IN, open val address: Int = 0)
