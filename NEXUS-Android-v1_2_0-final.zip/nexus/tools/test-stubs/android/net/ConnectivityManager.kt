package android.net

open class ConnectivityManager {
    open val allNetworks: Array<Network> = emptyArray()
    open fun getNetworkCapabilities(network: Network): NetworkCapabilities? = null
    open fun getLinkProperties(network: Network): LinkProperties? = null
}
