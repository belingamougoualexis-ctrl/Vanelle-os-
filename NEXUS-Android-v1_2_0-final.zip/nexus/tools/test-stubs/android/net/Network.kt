package android.net

import java.net.DatagramSocket
import javax.net.SocketFactory

open class Network {
    open val networkHandle: Long = 0L
    open val socketFactory: SocketFactory = SocketFactory.getDefault()
    open fun bindSocket(socket: DatagramSocket) = Unit
}
