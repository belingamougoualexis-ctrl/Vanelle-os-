package android.net

open class LinkProperties {
    open val interfaceName: String? = null
    open val linkAddresses: List<Any> = emptyList()
}
