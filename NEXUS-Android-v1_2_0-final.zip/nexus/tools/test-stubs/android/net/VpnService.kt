package android.net

import java.net.DatagramSocket
import java.net.Socket

open class VpnService {
    open fun protect(socket: Socket): Boolean = true
    open fun protect(socket: DatagramSocket): Boolean = true
}
