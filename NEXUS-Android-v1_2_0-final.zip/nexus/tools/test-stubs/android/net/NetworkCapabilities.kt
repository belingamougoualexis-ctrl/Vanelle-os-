package android.net

open class NetworkCapabilities {
    companion object {
        const val TRANSPORT_CELLULAR = 0
        const val TRANSPORT_WIFI = 1
        const val TRANSPORT_BLUETOOTH = 2
        const val TRANSPORT_ETHERNET = 3
        const val TRANSPORT_VPN = 4
        const val TRANSPORT_WIFI_AWARE = 5
        const val NET_CAPABILITY_INTERNET = 12
        const val NET_CAPABILITY_VALIDATED = 16
        const val NET_CAPABILITY_NOT_METERED = 11
    }
    open fun hasTransport(transport: Int): Boolean = false
    open fun hasCapability(capability: Int): Boolean = false
    open val linkDownstreamBandwidthKbps: Int = 0
    open val linkUpstreamBandwidthKbps: Int = 0
}
