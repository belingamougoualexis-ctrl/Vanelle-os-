package com.nexus.network
class NexusDht(val id:String) {
    data class Record(val key:String,val value:String,val publisher:String,val createdAt:Long,val expiresAt:Long,val signature:String)
    fun wire(record:Record):String=""
    fun fromWire(wire:String):Record?=null
}
