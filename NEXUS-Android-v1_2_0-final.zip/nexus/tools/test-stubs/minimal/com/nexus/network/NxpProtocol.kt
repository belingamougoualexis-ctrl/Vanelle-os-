package com.nexus.network
object NxpProtocol {
    fun queryName(host: String, port: Int, name: String, secretProvider: () -> List<String>): NexusNaming.Record? = null
}
