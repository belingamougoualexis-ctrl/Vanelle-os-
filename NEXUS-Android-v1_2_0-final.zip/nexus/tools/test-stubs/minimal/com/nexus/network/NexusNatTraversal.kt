package com.nexus.network
class NexusNatTraversal { data class Candidate(val address:String,val port:Int,val source:String) }
