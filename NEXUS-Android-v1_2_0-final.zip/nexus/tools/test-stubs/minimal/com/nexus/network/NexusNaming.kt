package com.nexus.network
object NexusNaming {
    data class Record(val name:String,val nodeId:String,val publicKey:String,val addresses:List<String>,val createdAt:Long,val expiresAt:Long,val signature:String)
    fun resolve(context: android.content.Context,name:String): Record? = null
    fun wire(record: Record): String = NexusCrypto.encode(record.name)
    fun fromWire(wire:String): Record? = null
}
