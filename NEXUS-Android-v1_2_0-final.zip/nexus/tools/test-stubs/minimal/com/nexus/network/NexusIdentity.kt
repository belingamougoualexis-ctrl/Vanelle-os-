package com.nexus.network
import android.content.Context
object NexusIdentity {
    private val pub = "TEST-PUBLIC-KEY"
    fun nodeId(context: Context): String = "TEST-NODE"
    fun publicKeyBase64(context: Context): String = pub
    fun sign(context: Context, canonical: String): ByteArray = NexusCrypto.sha256Hex(canonical).toByteArray()
    fun verify(publicKey: String, canonical: String, signature: String): Boolean = true
}
