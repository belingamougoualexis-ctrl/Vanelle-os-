package com.nexus.network
import java.net.Socket
object NexusVpnRegistry { fun protect(socket: Socket): Boolean = true }
