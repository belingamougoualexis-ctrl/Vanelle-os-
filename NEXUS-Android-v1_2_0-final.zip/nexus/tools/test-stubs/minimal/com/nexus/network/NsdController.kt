package com.nexus.network
object NsdController {
    data class Peer(
        val name: String,
        val host: String,
        val port: Int,
        val gatewayPath: List<String> = emptyList(),
        val gatewayDistance: Int = 0,
        val lastSeenAt: Long = System.currentTimeMillis()
    )
}
