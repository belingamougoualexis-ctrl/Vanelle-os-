#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export ROOT
python3 - <<'PY'
from pathlib import Path
import re, xml.etree.ElementTree as ET
root=Path(__import__('os').environ['ROOT'])
errors=[]

# Version consistency.
config=(root/'app/src/main/java/com/nexus/network/NexusConfig.kt').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
readme=(root/'README.md').read_text()
if 'const val VERSION = "1.2.0"' not in config: errors.append('NexusConfig version != 1.2.0')
if 'versionCode = 12' not in gradle or 'versionName = "1.2.0"' not in gradle: errors.append('Gradle version != 1.2.0 / code 12')
if not readme.startswith('# NEXUS Android 1.2.0'): errors.append('README title version mismatch')

# XML parse and reference existence.
xmls=list((root/'app/src/main').rglob('*.xml'))
for p in xmls:
    try: ET.parse(p)
    except Exception as e: errors.append(f'XML invalid: {p}: {e}')
manifest=root/'app/src/main/AndroidManifest.xml'
if not manifest.exists(): errors.append('AndroidManifest.xml missing')
else:
    text=manifest.read_text()
    for token in ['android.permission.INTERNET','android.permission.ACCESS_NETWORK_STATE','android.permission.FOREGROUND_SERVICE']:
        if token not in text: errors.append(f'Manifest missing {token}')

# Kotlin source references: local file classes/types are not exhaustively resolved here,
# but obvious dead imports/ghost references and prohibited placeholders are scanned.
sources=list((root/'app/src/main').rglob('*.kt'))
alltext='\n'.join(p.read_text(errors='ignore') for p in sources)
patterns={
    'xAI/Grok references': r'(?i)\b(grok|xai)\b',
    'WebGPU references': r'(?i)webgpu',
    'simulation markers': r'(?i)\b(simulat(?:e|ed|ion)|fake metric|dummy|placeholder)\b',
    'hard-coded fabricated latency': r'latencyMs\s*=\s*50(?:\.0)?',
    'hard-coded fabricated loss': r'(?:lossPct|packetLossPct)\s*=\s*0(?:\.0)?',
}
for name, pat in patterns.items():
    if re.search(pat, alltext): errors.append(name)

# Production files mentioned by major integration points must exist.
required=[
    'NexusPhysicalBackhaul.kt','NexusExternalLinkProtocol.kt','NexusUsbNxlTransport.kt',
    'NexusTransportManager.kt','NexusMultipathPlanner.kt','NexusDht.kt','NexusGlobalRouting.kt',
    'NexusNatTraversal.kt','NexusDtnStore.kt','NexusQosController.kt','NexusE2E.kt',
    'NexusContentStore.kt','NexusContentReplicator.kt','NexusCredits.kt','NexusNaming.kt',
    'NexusTrustStore.kt','NexusAppTransfer.kt','Icmpv6.kt','Ipv6ControlPlane.kt','UserSpaceIpStack.kt'
]
prod=root/'app/src/main/java/com/nexus/network'
for name in required:
    if not (prod/name).exists(): errors.append(f'missing production module: {name}')

# CI presence.
wf=(root/'.github/workflows/android-build.yml').read_text()
for token in ['android-37','build-tools;36.0.0','gradle-version: \'9.5.0\'','nexus-android-1.2.0']:
    if token not in wf: errors.append(f'CI missing {token}')

if errors:
    print('NEXUS v1.2 STATIC QA: FAIL')
    for e in errors: print(' -',e)
    raise SystemExit(1)
print(f'NEXUS v1.2 STATIC QA: OK ({len(sources)} Kotlin files, {len(xmls)} XML files checked)')
PY
