import com.nexus.network.IpPacket
import com.nexus.network.Ipv6FragmentReassembler
import com.nexus.network.Ipv6Packet
import com.nexus.network.TcpOptionCodec
import java.net.InetAddress
import java.net.Inet6Address

fun main() {
    val a = InetAddress.getByName("fd00:4e58:5553::2") as Inet6Address
    val b = InetAddress.getByName("2001:db8::10") as Inet6Address
    val tcpOptions = TcpOptionCodec.synAck(1220, 4, true, 1234, 5678)
    val p = Ipv6Packet.buildTcp(a, b, 40000, 443, 100, 0, 0x002, options = tcpOptions)
    val parsed = Ipv6Packet.parse(p) ?: error("IPv6 parse failed")
    check(parsed.src == a && parsed.dst == b && parsed.nextHeader == 6)
    check(Ipv6Packet.validateTcpChecksum(parsed, parsed.payload))
    val tcp = IpPacket.parseTcp(parsed.payload) ?: error("TCP parse failed")
    check(tcp.options.mss == 1220)
    check(tcp.options.windowScale == 4)
    check(tcp.options.sackPermitted)
    check(tcp.options.timestampValue == 1234L && tcp.options.timestampEcho == 5678L)

    val frag = Ipv6FragmentReassembler(maxBytes = 4096)
    val key = Ipv6FragmentReassembler.Key(a.hostAddress, b.hostAddress, 99, 17)
    check(frag.offer(key, 0, true, "01234567".toByteArray()) == null)
    check(String(frag.offer(key, 8, false, "89".toByteArray()) ?: error("not complete")) == "0123456789")
    // overlap is rejected and the ambiguous fragment context is discarded.
    check(frag.offer(key, 0, true, "AAAAAAAA".toByteArray()) == null)
    check(frag.offer(key, 4, false, "BBBB".toByteArray()) == null)
    println("NEXUS IPv6/TCP self-test OK")
}
