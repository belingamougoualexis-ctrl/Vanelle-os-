package com.nexus.network

import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

fun main() {
    secureRelayTcpTest()
    secureRelayUdpTest()
    userspaceTunTcpTest()
    println("NEXUS v0.5 integration self-test: OK")
}

private fun secureRelayTcpTest() {
    val echo = ServerSocket(0)
    val echoThread = thread(start = true, isDaemon = true) {
        echo.use { server ->
            server.accept().use { client ->
                val input = client.getInputStream()
                val output = client.getOutputStream()
                val buffer = ByteArray(4096)
                val n = input.read(buffer)
                check(n > 0)
                output.write(buffer, 0, n)
                output.flush()
            }
        }
    }

    val secret = "NEXUS-test-secret-2026"
    val relay = RelayServer(
        port = 45456,
        nodeIdProvider = { "NX-RELAY" },
        secretProvider = { listOf(secret) },
        directInternetAvailable = { true },
        nextHopSelector = { null },
        protectSocket = { true },
        protectDatagram = { true }
    )
    relay.start()
    Thread.sleep(120)

    RelayProtocol.openRelay(
        host = "127.0.0.1",
        port = 45456,
        targetHost = "127.0.0.1",
        targetPort = echo.localPort,
        secret = secret,
        fromNode = "NX-A"
    ).use { channel ->
        val msg = "nexus-secure-tcp".toByteArray()
        channel.output.write(msg)
        channel.output.flush()
        val response = readExactly(channel.input, msg.size)
        check(response.contentEquals(msg))
    }

    relay.stop()
    echoThread.join(1000)
}

private fun secureRelayUdpTest() {
    val udpEcho = DatagramSocket(0)
    val thread = thread(start = true, isDaemon = true) {
        udpEcho.use { socket ->
            val buffer = ByteArray(2048)
            val packet = DatagramPacket(buffer, buffer.size)
            socket.receive(packet)
            socket.send(DatagramPacket(packet.data, packet.length, packet.address, packet.port))
        }
    }

    val secret = "NEXUS-test-secret-2026"
    val relay = RelayServer(
        port = 45456,
        nodeIdProvider = { "NX-RELAY" },
        secretProvider = { listOf(secret) },
        directInternetAvailable = { true },
        nextHopSelector = { null },
        protectSocket = { true },
        protectDatagram = { true }
    )
    relay.start()
    Thread.sleep(120)

    DatagramRelayProtocol.openRelay(
        host = "127.0.0.1",
        port = 45456,
        targetHost = "127.0.0.1",
        targetPort = udpEcho.localPort,
        secret = secret,
        fromNode = "NX-A",
        visited = listOf("NX-A"),
        ttl = 8
    ).use { session ->
        val msg = "nexus-secure-udp".toByteArray()
        session.send(msg)
        val response = session.receive() ?: error("UDP response missing")
        check(response.contentEquals(msg))
    }

    relay.stop()
    thread.join(1000)
}

private fun userspaceTunTcpTest() {
    val echo = ServerSocket(0)
    val echoThread = thread(start = true, isDaemon = true) {
        echo.use { server ->
            server.accept().use { client ->
                val input = client.getInputStream()
                val output = client.getOutputStream()
                val buffer = ByteArray(4096)
                val n = input.read(buffer)
                check(n > 0)
                output.write(buffer, 0, n)
                output.flush()
                runCatching { client.shutdownOutput() }
            }
        }
    }

    val tunWriter = PipedOutputStream()
    val tunReader = PipedInputStream(tunWriter, 128 * 1024)
    val tunOutputWriter = PipedOutputStream()
    val tunOutputReader = PipedInputStream(tunOutputWriter, 128 * 1024)

    val clientIp = InetAddress.getByName("10.255.0.2") as Inet4Address
    val remoteIp = InetAddress.getByName("127.0.0.1") as Inet4Address
    val clientPort = 40_000
    val remotePort = echo.localPort

    val stack = UserSpaceIpStack(
        tunInput = tunReader,
        tunOutput = tunOutputWriter,
        tunAddress = clientIp,
        upstream = object : UserSpaceIpStack.UpstreamTransport {
            override fun openTcp(host: String, port: Int): NexusStreamChannel =
                SocketStreamChannel(Socket().apply { connect(java.net.InetSocketAddress(host, port), 3000) })
            override fun openUdp(host: String, port: Int): UserSpaceIpStack.UdpChannel = error("not used")
        }
    )
    stack.start()

    val clientSeq = 10_000L
    val syn = IpPacket.buildTcp(
        clientIp, remoteIp, clientPort, remotePort,
        sequence = clientSeq, acknowledgement = 0,
        flags = 0x002, identification = 1
    )
    tunWriter.write(syn); tunWriter.flush()
    val synAck = readIpPacket(tunOutputReader)
    val synAckTcp = IpPacket.parseTcp(synAck.payload) ?: error("SYN-ACK missing")
    check(synAckTcp.syn && synAckTcp.ack)
    check(synAckTcp.acknowledgement == clientSeq + 1)

    val ack = IpPacket.buildTcp(
        clientIp, remoteIp, clientPort, remotePort,
        sequence = clientSeq + 1,
        acknowledgement = synAckTcp.sequence + 1,
        flags = 0x010, identification = 2
    )
    tunWriter.write(ack); tunWriter.flush()

    val payload = "real-tun-tcp".toByteArray()
    val data = IpPacket.buildTcp(
        clientIp, remoteIp, clientPort, remotePort,
        sequence = clientSeq + 1,
        acknowledgement = synAckTcp.sequence + 1,
        flags = 0x018,
        payload = payload,
        identification = 3
    )
    tunWriter.write(data); tunWriter.flush()

    val responseTcp = waitForTcpPayload(tunOutputReader, payload.size, timeoutMs = 5000)
    check(responseTcp.payload.contentEquals(payload))

    stack.stop()
    tunReader.close()
    tunWriter.close()
    tunOutputReader.close()
    tunOutputWriter.close()
    echoThread.join(1000)
}

private fun readIpPacket(input: java.io.InputStream, timeoutMs: Long = 3000): IpPacket.IPv4 {
    val deadline = System.currentTimeMillis() + timeoutMs
    while (System.currentTimeMillis() < deadline) {
        if (input.available() >= 20) {
            val header = ByteArray(20)
            readFully(input, header)
            val total = IpPacket.u16(header, 2)
            val rest = ByteArray(total - 20)
            readFully(input, rest)
            return IpPacket.parseIpv4(header + rest) ?: error("invalid IPv4")
        }
        Thread.sleep(10)
    }
    error("TUN packet timeout")
}

private fun waitForTcpPayload(input: java.io.InputStream, expectedSize: Int, timeoutMs: Long): IpPacket.Tcp {
    val deadline = System.currentTimeMillis() + timeoutMs
    while (System.currentTimeMillis() < deadline) {
        val ip = runCatching { readIpPacketBlocking(input, 500) }.getOrNull() ?: continue
        val tcp = IpPacket.parseTcp(ip.payload) ?: continue
        if (tcp.payload.size == expectedSize && tcp.payload.isNotEmpty()) return tcp
    }
    error("TCP payload response timeout")
}

private fun readIpPacketBlocking(input: java.io.InputStream, timeoutMs: Long): IpPacket.IPv4 {
    val header = ByteArray(20)
    val future = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "nexus-test-reader").apply { isDaemon = true } }
    return try {
        val f = future.submit<IpPacket.IPv4> {
            readFully(input, header)
            val total = IpPacket.u16(header, 2)
            require(total >= 20)
            val rest = ByteArray(total - 20)
            readFully(input, rest)
            IpPacket.parseIpv4(header + rest) ?: error("invalid IPv4")
        }
        f.get(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS)
    } finally {
        future.shutdownNow()
    }
}

private fun readExactly(input: java.io.InputStream, length: Int): ByteArray {
    val result = ByteArray(length)
    readFully(input, result)
    return result
}

private fun readFully(input: java.io.InputStream, target: ByteArray) {
    var offset = 0
    while (offset < target.size) {
        val n = input.read(target, offset, target.size - offset)
        if (n < 0) error("unexpected EOF")
        offset += n
    }
}
