import com.nexus.network.*
import java.net.InetAddress
import java.net.Inet6Address

fun main() {
    val src = InetAddress.getByName("fe80::10") as Inet6Address
    val local = InetAddress.getByName("fd00:4e58:5553::2") as Inet6Address
    val control = Ipv6ControlPlane(local, InetAddress.getByName("fe80::2") as Inet6Address)

    val echo = Icmpv6.build(Icmpv6.ECHO_REQUEST, 0, byteArrayOf(0,1,2,3,4,5,6,7))
    val echoMsg = Icmpv6.parse(Icmpv6.finalize(src, local, echo), src, local) ?: error("echo parse")
    check(echoMsg.type == 128)
    val echoReply = control.handle(src, echoMsg) ?: error("echo reply")
    check(echoReply[0].toInt() and 0xff == 129)

    val nsBody = ByteArray(20)
    System.arraycopy(local.address, 0, nsBody, 4, 16)
    val ns = Icmpv6.build(Icmpv6.NEIGHBOR_SOLICITATION, 0, nsBody)
    val nsMsg = Icmpv6.parse(Icmpv6.finalize(src, local, ns), src, local) ?: error("ns parse")
    val na = control.handle(src, nsMsg) ?: error("na")
    check(na[0].toInt() and 0xff == 136)

    val rs = Icmpv6.build(Icmpv6.ROUTER_SOLICITATION, 0, ByteArray(4))
    val rsMsg = Icmpv6.parse(Icmpv6.finalize(src, local, rs), src, local) ?: error("rs parse")
    val ra = control.handle(src, rsMsg) ?: error("ra")
    check(ra[0].toInt() and 0xff == 134)
    check(ra.size == 48)

    val group = InetAddress.getByName("ff02::1234") as Inet6Address
    val mld = ByteArray(20)
    System.arraycopy(group.address, 0, mld, 4, 16)
    val report = Icmpv6.build(Icmpv6.MLD_REPORT_V1, 0, mld)
    val reportMsg = Icmpv6.parse(Icmpv6.finalize(src, group, report), src, group) ?: error("mld parse")
    control.handle(src, reportMsg)
    check(control.groupsSnapshot().any { it.address == group })

    println("ICMPv6/ND/MLD REAL SELF-TEST: OK")
}
