#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
kotlinc "$ROOT/tools/test-stubs/minimal/android/content/Context.kt" "$ROOT/tools/test-stubs/minimal/com/nexus/network/NexusIdentity.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusConfig.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusDtnStore.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusQosController.kt" "$ROOT/tools/nexus_v1_0_dtn_qos_selftest.kt" -include-runtime -d "$OUT/test.jar"
java -jar "$OUT/test.jar"
