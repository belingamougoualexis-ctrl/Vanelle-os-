import com.nexus.network.MeshRouter
import com.nexus.network.NsdController

fun main() {
    val peers = listOf(
        NsdController.Peer("NX-B", "10.0.0.2", 45454, relay = true, gatewayDistance = 2, latencyMs = 10.0),
        NsdController.Peer("NX-C", "10.0.0.3", 45454, relay = true, gatewayDistance = 1, latencyMs = 80.0),
        NsdController.Peer("NX-D", "10.0.0.4", 45454, relay = true, gatewayDistance = 4, latencyMs = 1.0)
    )
    val router = MeshRouter("NX-A") { peers }
    check(router.gatewayDistance(false, true) == 2)
    check(router.chooseNextHop(setOf("NX-A"), 2)?.nodeId == "NX-C")
    check(router.chooseNextHop(setOf("NX-A", "NX-C"), 1) == null)
    println("NEXUS router self-test OK")
}
