import com.nexus.network.DatagramRelayProtocol
import com.nexus.network.MeshRouter
import com.nexus.network.NexusVpnRegistry
import com.nexus.network.RelayProtocol
import com.nexus.network.RelayServer
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.ServerSocket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

fun main() {
    val key = "nexus-mesh-e2e-key"
    val target = ServerSocket(0)
    val targetReady = CountDownLatch(1)
    val udpTarget = DatagramSocket(0)
    udpTarget.soTimeout = 10_000
    Thread {
        runCatching {
            targetReady.countDown()
            target.accept().use { socket ->
                val input = socket.getInputStream()
                val output = socket.getOutputStream()
                val buf = ByteArray(32)
                var read = 0
                while (read < buf.size) {
                    val n = input.read(buf, read, buf.size - read)
                    if (n < 0) return@use
                    read += n
                }
                output.write(buf.reversedArray())
                output.flush()
            }
        }
    }.apply { isDaemon = true; start() }

    Thread {
        runCatching {
            val receive = ByteArray(32)
            val packet = DatagramPacket(receive, receive.size)
            udpTarget.receive(packet)
            val response = receive.copyOf(packet.length).reversedArray()
            udpTarget.send(DatagramPacket(response, response.size, packet.address, packet.port))
        }
    }.apply { isDaemon = true; start() }

    // RelayServer binds a requested port directly; use free OS ports discovered first.
    val gatewayPort = ServerSocket(0).use { it.localPort }
    val transitPort = ServerSocket(0).use { it.localPort }
    val gatewayServer = RelayServer(
        port = gatewayPort,
        nodeIdProvider = { "GATEWAY" },
        secretProvider = { listOf(key) },
        directInternetAvailable = { true },
        nextHopSelector = { null },
        protectSocket = { NexusVpnRegistry.protect(it) }
    )
    val transitPeers = listOf(
        com.nexus.network.NsdController.Peer(
            name = "GATEWAY", host = "127.0.0.1", port = gatewayPort,
            gateway = true, relay = true, gatewayDistance = 0,
            gatewayPath = listOf("GATEWAY"), latencyMs = 1.0,
            lastSeenAt = System.currentTimeMillis()
        )
    )
    val transitRouter = MeshRouter("TRANSIT") { transitPeers }
    val transitServer = RelayServer(
        port = transitPort,
        nodeIdProvider = { "TRANSIT" },
        secretProvider = { listOf(key) },
        directInternetAvailable = { false },
        nextHopSelector = { visited -> transitRouter.chooseNextHop(visited, transitRouter.gatewayDistance(false, true)) },
        nextHopCandidatesSelector = { visited -> transitRouter.candidates(visited, transitRouter.gatewayDistance(false, true), 4) },
        protectSocket = { NexusVpnRegistry.protect(it) }
    )
    check(targetReady.await(2, TimeUnit.SECONDS))
    gatewayServer.start()
    transitServer.start()
    Thread.sleep(300)

    val payload = ByteArray(32) { it.toByte() }
    RelayProtocol.openRelay(
        host = "127.0.0.1",
        port = transitPort,
        targetHost = "127.0.0.1",
        targetPort = target.localPort,
        secret = key,
        fromNode = "CLIENT",
        visited = listOf("CLIENT"),
        ttl = 8,
        timeoutMs = 4000
    ).use { channel ->
        channel.output.write(payload)
        channel.output.flush()
        val response = ByteArray(payload.size)
        var read = 0
        while (read < response.size) {
            val n = channel.input.read(response, read, response.size - read)
            check(n >= 0) { "Tunnel multi-hop interrompu" }
            read += n
        }
        check(response.contentEquals(payload.reversedArray())) { "Payload multi-hop altéré" }
    }

    val udpPayload = ByteArray(24) { (it + 3).toByte() }
    DatagramRelayProtocol.openRelay(
        host = "127.0.0.1",
        port = transitPort,
        targetHost = "127.0.0.1",
        targetPort = udpTarget.localPort,
        secret = key,
        fromNode = "CLIENT",
        visited = listOf("CLIENT"),
        ttl = 8,
        timeoutMs = 4000
    ).use { session ->
        session.send(udpPayload)
        val response = session.receive() ?: error("Réponse UDP multi-hop absente")
        check(response.contentEquals(udpPayload.reversedArray())) { "Payload UDP multi-hop altéré" }
    }

    gatewayServer.stop()
    transitServer.stop()
    target.close()
    udpTarget.close()
    println("NEXUS v0.8 MULTI-HOP TCP+UDP REAL SELF-TEST: OK")
}
