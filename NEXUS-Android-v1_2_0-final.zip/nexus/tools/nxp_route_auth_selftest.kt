import com.nexus.network.NexusCrypto
import com.nexus.network.NxpProtocol
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

fun main() {
    val key = "nexus-auth-test-key"
    val ready = CountDownLatch(1)
    val server = ServerSocket(0)
    Thread {
        runCatching {
            ready.countDown()
            server.accept().use { socket ->
                NxpProtocol.serverHandshake(
                    socket = socket,
                    nodeId = "GATEWAY-A",
                    gateway = true,
                    relay = true,
                    gatewayDistance = 0,
                    gatewayPath = listOf("GATEWAY-A"),
                    secretProvider = { listOf(key) }
                )
            }
        }
    }.apply { isDaemon = true; start() }

    check(ready.await(2, TimeUnit.SECONDS))
    val caps = NxpProtocol.probeCapabilities("127.0.0.1", server.localPort) { listOf(key) }
    check(caps.gateway)
    check(caps.relay)
    check(caps.nodeId == "GATEWAY-A")
    check(caps.gatewayDistance == 0)
    check(caps.gatewayPath == listOf("GATEWAY-A"))

    // Wrong key must not authenticate the capability response.
    val rejected = runCatching {
        NxpProtocol.probeCapabilities("127.0.0.1", server.localPort) { listOf("wrong-key") }
    }.isFailure
    check(rejected)

    server.close()
    println("NXP AUTHENTICATED ROUTE ADVERTISEMENT SELF-TEST: OK")
}
