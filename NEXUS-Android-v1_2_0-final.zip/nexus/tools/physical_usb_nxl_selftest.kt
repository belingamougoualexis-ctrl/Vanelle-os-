package com.nexus.network

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.util.Arrays

private class FakeUsbConnection : UsbDeviceConnection() {
    var wire = ByteArray(0)
    var maxChunk = 7
    override fun bulkTransfer(endpoint: UsbEndpoint, buffer: ByteArray, offset: Int, length: Int, timeout: Int): Int {
        return if (endpoint.direction == UsbConstants.USB_DIR_OUT) {
            wire += buffer.copyOfRange(offset, offset + length)
            length
        } else {
            val n = minOf(length, wire.size, maxChunk)
            System.arraycopy(wire, 0, buffer, offset, n)
            wire = wire.copyOfRange(n, wire.size)
            n
        }
    }
}

private class FakeUsbManager(private val device: UsbDevice, private val connection: UsbDeviceConnection) : UsbManager() {
    override val deviceList: Map<String, UsbDevice> = mapOf("nxl" to device)
    override fun hasPermission(device: UsbDevice): Boolean = device === this.device
    override fun openDevice(device: UsbDevice): UsbDeviceConnection? = if (device === this.device) connection else null
}

private class FakeContext(private val manager: UsbManager) : Context() {
    override fun <T> getSystemService(serviceClass: Class<T>): T? =
        if (serviceClass == UsbManager::class.java) manager as T else super.getSystemService(serviceClass)
}

fun main() {
    val bulkIn = UsbEndpoint(UsbConstants.USB_ENDPOINT_XFER_BULK, UsbConstants.USB_DIR_IN, 0x81)
    val bulkOut = UsbEndpoint(UsbConstants.USB_ENDPOINT_XFER_BULK, UsbConstants.USB_DIR_OUT, 0x02)
    val iface = UsbInterface(3, 0xff, arrayOf(bulkIn, bulkOut))
    val device = UsbDevice(0x1234, 0x5678, "NXL Bridge", "NEXUS", arrayOf(iface))
    val wire = FakeUsbConnection()
    val adapter = NexusUsbNxlTransport(FakeContext(FakeUsbManager(device, wire)))

    val devices = adapter.devices()
    check(devices.size == 1)
    check(devices.first().hasPermission)
    check(devices.first().bulkInAddress == 0x81)
    check(devices.first().bulkOutAddress == 0x02)

    adapter.open(device).use { connection ->
        val payload = "hello-radio".toByteArray()
        val sent = connection.send(payload)
        check(sent == 0L)
        connection.send("second".toByteArray())
        val received = connection.receive()
        check(received.sequence == 0L)
        check(Arrays.equals(received.payload, payload))
        val second = connection.receive()
        check(second.sequence == 1L)
        check(Arrays.equals(second.payload, "second".toByteArray()))
    }
    println("USB NXL1 REAL PATH SELF-TEST: OK")
}
