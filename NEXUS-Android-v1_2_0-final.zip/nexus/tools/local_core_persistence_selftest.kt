package com.nexus.network

import android.content.Context
import java.io.File

fun main() {
    val context = Context()

    // Settings + credits.
    NexusSettings.setCreditsEnforced(context, false)
    check(NexusCredits.balance(context) == 0L)
    check(NexusCredits.relay(context, "PEER-A", 1_048_576L) == 1L)
    check(NexusCredits.balance(context) == 1L)
    check(NexusCredits.spend(context, "PEER-B", 1_048_576L))
    check(NexusCredits.balance(context) == 0L)
    NexusSettings.setCreditsEnforced(context, true)
    check(!NexusCredits.spend(context, "PEER-C", 1_048_576L))
    check(NexusCredits.receiptLog(context).length() == 2)

    // Content store: chunk, integrity, pinning and reassembly.
    val source = File(context.filesDir, "source.bin")
    val payload = ByteArray(300_000) { (it * 31).toByte() }
    source.writeBytes(payload)
    val manifest = NexusContentStore.putFile(context, source, "source.bin", "application/octet-stream", true)
    check(NexusContentStore.has(context, manifest.hash))
    check(NexusContentStore.verifyComplete(context, manifest.hash))
    check(NexusContentStore.chunk(context, manifest.hash, 0) != null)
    check(NexusContentStore.allPinned(context).any { it.hash == manifest.hash })
    val out = File(context.filesDir, "assembled.bin")
    check(NexusContentStore.assemble(context, manifest.hash, out))
    check(out.readBytes().contentEquals(payload))
    val first = NexusContentStore.chunk(context, manifest.hash, 0)!!
    check(!NexusContentStore.writeChunk(context, manifest.hash, "0".repeat(64), first))

    // Cryptographic naming: own record -> wire -> parse -> verify -> disk resolve.
    val name = NexusNaming.own(context, listOf("127.0.0.1:45454", "[::1]:45454"))
    check(NexusNaming.verify(name))
    check(NexusNaming.nameForPublicKey(name.publicKey) == name.name)
    val wire = NexusNaming.wire(name)
    val decoded = NexusNaming.fromWire(wire) ?: error("Wire naming decode failed")
    check(decoded.name == name.name && NexusNaming.verify(decoded))
    check(NexusNaming.resolve(context, name.name)?.nodeId == name.nodeId)

    println("NEXUS LOCAL PERSISTENCE / CONTENT / CREDITS / NAMING SELF-TEST: OK")
}
