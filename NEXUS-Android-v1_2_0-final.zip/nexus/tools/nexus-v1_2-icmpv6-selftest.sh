#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
kotlinc "$ROOT/app/src/main/java/com/nexus/network/IpPacket.kt" "$ROOT/app/src/main/java/com/nexus/network/TcpOptions.kt" "$ROOT/app/src/main/java/com/nexus/network/Ipv6Packet.kt" "$ROOT/app/src/main/java/com/nexus/network/Icmpv6.kt" "$ROOT/app/src/main/java/com/nexus/network/Ipv6ControlPlane.kt" "$ROOT/tools/icmpv6_nd_mld_selftest.kt" -include-runtime -d "$OUT/test.jar"
java -jar "$OUT/test.jar"
