#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/nexus-userspace-test-$$"
mkdir -p "$OUT"
trap 'rm -rf "$OUT"' EXIT
kotlinc \
  "$ROOT/app/src/main/java/com/nexus/network/NexusConfig.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusSecureFraming.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusStreamChannel.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/IpPacket.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/TcpOptions.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/Ipv6Packet.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/Ipv6FragmentReassembler.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/RelayProtocol.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/DatagramRelayProtocol.kt" \
  "$ROOT/tools/userspace_core_selftest.kt" \
  -include-runtime -d "$OUT/test.jar"
java -jar "$OUT/test.jar"
