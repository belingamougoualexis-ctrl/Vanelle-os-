import com.nexus.network.NexusCrypto
import com.nexus.network.RelayProtocol

fun main() {
    val key = "test-network-key"
    val line = run {
        val nonce = "abc123"
        val fields = linkedMapOf(
            "from" to NexusCrypto.encode("NX-A"),
            "ttl" to "6",
            "visited" to NexusCrypto.encode("NX-A,NX-B"),
            "host" to NexusCrypto.encode("example.com"),
            "port" to "443",
            "nonce" to nonce,
            "e2e" to "0"
        )
        val mac = NexusCrypto.hmacHex(key, RelayProtocol.canonical(fields))
        "$${RelayProtocol.VERSION} RELAY v=1 ${fields.entries.joinToString(" ") { "${it.key}=${it.value}" }} mac=$mac".removePrefix("$")
    }
    val parsed = RelayProtocol.parse(line) ?: error("parse failed")
    check(parsed.from == "NX-A")
    check(parsed.visited == listOf("NX-A", "NX-B"))
    check(parsed.host == "example.com")
    check(parsed.port == 443)
    check(RelayProtocol.authenticate(parsed, key))
    check(!RelayProtocol.authenticate(parsed.copy(host = "example.net"), key))
    println("NEXUS protocol self-test OK")
}
