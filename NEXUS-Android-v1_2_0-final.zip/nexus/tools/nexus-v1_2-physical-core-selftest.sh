#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
kotlinc \
  "$ROOT/app/src/main/java/com/nexus/network/NexusMultipathPlanner.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusExternalLinkProtocol.kt" \
  "$ROOT/tools/physical_backhaul_selftest.kt" \
  -include-runtime -d "$OUT/test.jar"
java -jar "$OUT/test.jar"
