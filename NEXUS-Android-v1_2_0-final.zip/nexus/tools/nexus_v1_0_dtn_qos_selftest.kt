import android.content.Context
import com.nexus.network.NexusDtnStore
import com.nexus.network.NexusQosController

private class TestContext : Context()

fun main() {
    val ctx = TestContext()
    val dtn = NexusDtnStore(ctx)
    val payload = "offline-bundle".toByteArray()
    val id = dtn.enqueue("NX-DEST", payload, ttlMs = 60_000, priority = 9, origin = "NX-ORIGIN", visited = listOf("NX-ORIGIN"))
    val b = dtn.pending().single()
    check(b.id == id && b.destination == "NX-DEST" && b.visited == listOf("NX-ORIGIN"))
    check(b.payloadFile.readBytes().contentEquals(payload))
    dtn.defer(id, b.visited + "NX-HOP")
    check(dtn.pending().single().attempts == 1)
    check(dtn.pending().single().visited == listOf("NX-ORIGIN", "NX-HOP"))
    dtn.ack(id)
    check(dtn.pending().isEmpty())

    val qos = NexusQosController { 4L * 1024 * 1024 }
    check(qos.classify(53) == NexusQosController.Class.INTERACTIVE)
    check(qos.classify(22) == NexusQosController.Class.CONTROL)
    check(qos.classify(6881) == NexusQosController.Class.BULK)
    check(qos.allow("flow-a", 1024, NexusQosController.Class.INTERACTIVE))

    println("NEXUS v1.0 DTN/QOS REAL CORE SELF-TEST: OK")
}
