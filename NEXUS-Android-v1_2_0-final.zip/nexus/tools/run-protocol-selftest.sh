#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/tools/protocol_selftest.jar"
rm -f "$OUT"
kotlinc \
  "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusStreamChannel.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusSecureFraming.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/RelayProtocol.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusConfig.kt" \
  "$ROOT/tools/test-stubs/com/nexus/network/NsdController.kt" \
  "$ROOT/tools/test-stubs/com/nexus/network/NexusP2PDirectory.kt" \
  "$ROOT/tools/protocol_selftest.kt" \
  -include-runtime -d "$OUT"
java -jar "$OUT"
rm -f "$OUT"
