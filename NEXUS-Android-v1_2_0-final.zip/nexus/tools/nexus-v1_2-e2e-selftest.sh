#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; OUT="$(mktemp -d)"; trap 'rm -rf "$OUT" /tmp/nexus-e2e-secure-store.kt /tmp/nexus-e2e-context.kt /tmp/nexus-e2e-vpn.kt' EXIT
cat > /tmp/nexus-e2e-secure-store.kt <<'EOF'
package com.nexus.network
import android.content.Context
object NexusSecureStore { private val values=mutableMapOf<String,String>(); fun get(context:Context,key:String):String?=values[key]; fun put(context:Context,key:String,value:String){values[key]=value} }
EOF
cat > /tmp/nexus-e2e-context.kt <<'EOF'
package android.content
import java.io.File
import kotlin.io.path.createTempDirectory
open class Context { open val filesDir:File=createTempDirectory("nx-").toFile().apply{mkdirs()}; open val cacheDir:File=File(filesDir,"cache").apply{mkdirs()}; private val prefs=mutableMapOf<String,SharedPreferences>(); fun getSharedPreferences(n:String,m:Int)=prefs.getOrPut(n){SharedPreferences()}; companion object{const val MODE_PRIVATE=0} }
class SharedPreferences { private val v=mutableMapOf<String,Any?>(); fun getString(k:String,d:String?)=v[k] as? String?:d; fun edit()=Editor(v); class Editor(private val v:MutableMap<String,Any?>){fun putString(k:String,x:String?)=apply{v[k]=x}; fun remove(k:String)=apply{v.remove(k)}; fun apply()=Unit} }
EOF
cat > /tmp/nexus-e2e-vpn.kt <<'EOF'
package android.net
import java.net.DatagramSocket
import java.net.Socket
open class VpnService { open fun protect(s:Socket)=true; open fun protect(s:DatagramSocket)=true }
EOF
kotlinc /tmp/nexus-e2e-context.kt /tmp/nexus-e2e-vpn.kt /tmp/nexus-e2e-secure-store.kt "$ROOT/app/src/main/java/com/nexus/network/NexusConfig.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusIdentity.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusSecureFraming.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusStreamChannel.kt" "$ROOT/app/src/main/java/com/nexus/network/RelayProtocol.kt" "$ROOT/app/src/main/java/com/nexus/network/DatagramRelayProtocol.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusE2E.kt" "$ROOT/tools/nexus_v0_9_e2e_selftest.kt" -include-runtime -d "$OUT/test.jar"
java -jar "$OUT/test.jar"
