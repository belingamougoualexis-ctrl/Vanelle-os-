import com.nexus.network.NexusNatTraversal
import java.net.DatagramPacket
import java.net.DatagramSocket

fun main() {
    val receiver = DatagramSocket(0)
    receiver.soTimeout = 2000
    val port = receiver.localPort
    val traversal = NexusNatTraversal()
    check(traversal.punch(listOf(NexusNatTraversal.Candidate("127.0.0.1", port, "TEST")), "self-test", 500))
    val buf = ByteArray(128)
    val packet = DatagramPacket(buf, buf.size)
    receiver.receive(packet)
    check(String(packet.data, 0, packet.length, Charsets.US_ASCII).startsWith("NEXUS-PUNCH/1|self-test"))
    receiver.close()
    println("NEXUS v1.0 NAT UDP PUNCH SELF-TEST: OK")
}
