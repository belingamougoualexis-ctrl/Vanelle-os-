package com.nexus.network

import android.content.Context
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.BlockingQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

private class TestContext : Context()

private class PipeChannel(
    override val input: InputStream,
    override val output: OutputStream
) : NexusStreamChannel {
    override fun shutdownOutput() = runCatching { output.close() }.getOrNull() ?: Unit
    override fun close() {
        runCatching { output.close() }
        runCatching { input.close() }
    }
}

private fun tcpTest() {
    val aToB = java.io.PipedOutputStream()
    val bToA = java.io.PipedOutputStream()
    val aIn = java.io.PipedInputStream(bToA, 1 shl 16)
    val bIn = java.io.PipedInputStream(aToB, 1 shl 16)
    val clientBase = PipeChannel(aIn, aToB)
    val serverBase = PipeChannel(bIn, bToA)
    val clientContext = TestContext()
    val serverContext = TestContext()
    val serverReady = CountDownLatch(1)
    lateinit var server: NexusStreamChannel
    var failure: Throwable? = null
    val serverThread = Thread {
        try {
            server = NexusE2E.server(serverContext, serverBase)
            serverReady.countDown()
            val buffer = ByteArray(64)
            var offset = 0
            while (offset < 9) {
                val n = server.input.read(buffer, offset, 9 - offset)
                if (n < 0) error("TCP E2E EOF")
                offset += n
            }
            check(String(buffer, 0, 9) == "NEXUS-E2E")
        } catch (t: Throwable) {
            failure = t
            serverReady.countDown()
        }
    }.apply { isDaemon = true; name = "nexus-e2e-test-server" }
    serverThread.start()

    val client = NexusE2E.client(
        clientContext,
        clientBase,
        "TEST-CLIENT",
        NexusIdentity.publicKeyBase64(serverContext)
    )
    check(serverReady.await(5, TimeUnit.SECONDS))
    client.output.write("NEXUS-E2E".toByteArray())
    client.output.flush()
    serverThread.join(5_000)
    check(failure == null) { "TCP E2E test failure: ${failure?.message}" }
    client.close()
    server.close()
}

private fun udpTest() {
    val serverSocket = java.net.ServerSocket(0)
    val baseNonce = NexusCrypto.nonce(24)
    val baseKey = "test-datagram-session-key"
    val clientContext = TestContext()
    val serverContext = TestContext()
    val serverReady = CountDownLatch(1)
    lateinit var server: NexusE2EDatagram
    var failure: Throwable? = null
    val serverThread = Thread {
        try {
            serverSocket.accept().use { socket ->
                val serverBase = DatagramRelayProtocol.Session(socket, baseKey, baseNonce)
                server = NexusE2EDatagram.server(serverContext, serverBase)
                serverReady.countDown()
                check(String(server.receive() ?: error("UDP E2E request absent")) == "hello")
                server.send("world".toByteArray())
                server.close()
            }
        } catch (t: Throwable) {
            failure = t
            serverReady.countDown()
        }
    }.apply { isDaemon = true; name = "nexus-e2e-udp-server" }
    serverThread.start()

    val clientSocket = java.net.Socket("127.0.0.1", serverSocket.localPort)
    val clientBase = DatagramRelayProtocol.Session(clientSocket, baseKey, baseNonce)
    val client = NexusE2EDatagram.client(
        clientContext,
        clientBase,
        "TEST-CLIENT",
        NexusIdentity.publicKeyBase64(serverContext)
    )
    check(serverReady.await(5, TimeUnit.SECONDS))
    client.send("hello".toByteArray())
    check(String(client.receive() ?: error("UDP E2E response absent")) == "world")
    client.close()
    serverSocket.close()
    serverThread.join(5_000)
    check(failure == null) { "UDP E2E test failure: ${failure?.message}" }
}

fun main() {
    tcpTest()
    udpTest()
    println("NEXUS v0.9 E2E TCP+UDP REAL SELF-TEST: OK")
}
