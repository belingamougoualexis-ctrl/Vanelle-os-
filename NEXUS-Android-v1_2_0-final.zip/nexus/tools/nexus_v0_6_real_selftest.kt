import com.nexus.network.IpPacket
import com.nexus.network.Ipv6Packet
import com.nexus.network.NexusStreamChannel
import com.nexus.network.SocketStreamChannel
import com.nexus.network.TcpOptionCodec
import com.nexus.network.UserSpaceIpStack
import java.io.ByteArrayOutputStream
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet6Address
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.TimeUnit

private fun waitForPacket(input: PipedInputStream, timeoutMs: Long = 3000): ByteArray {
    val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMs)
    val out = ByteArrayOutputStream()
    var expected = 40
    while (System.nanoTime() < deadline) {
        if (input.available() == 0) { Thread.sleep(5); continue }
        val buf = ByteArray(minOf(8192, input.available()))
        val n = input.read(buf)
        if (n <= 0) continue
        out.write(buf, 0, n)
        val bytes = out.toByteArray()
        if (bytes.size >= 40 && expected == 40) expected = 40 + IpPacket.u16(bytes, 4)
        if (bytes.size >= expected) return bytes.copyOf(expected)
    }
    error("timeout waiting for TUN packet")
}

fun main() {
    val v6 = InetAddress.getByName("::1") as Inet6Address
    val client = InetAddress.getByName("fd00:4e58:5553::2") as Inet6Address
    val clientPort = 40123

    val tcpServer = ServerSocket(0, 16, v6)
    Thread {
        tcpServer.accept().use { socket ->
            val input = socket.getInputStream(); val output = socket.getOutputStream()
            val data = input.readNBytes(10)
            check(String(data) == "helloworld")
            output.write(data); output.flush()
        }
    }.apply { isDaemon = true; start() }

    val udpServer = DatagramSocket(0, v6)
    Thread {
        val buf = ByteArray(2048)
        val packet = DatagramPacket(buf, buf.size)
        udpServer.receive(packet)
        udpServer.send(DatagramPacket(packet.data, packet.length, packet.address, packet.port))
    }.apply { isDaemon = true; start() }

    val tunIn = PipedInputStream(128 * 1024)
    val tunWriter = PipedOutputStream(tunIn)
    val tunOut = PipedInputStream(128 * 1024)
    val tunReader = PipedOutputStream(tunOut)
    val upstream = object : UserSpaceIpStack.UpstreamTransport {
        override fun openTcp(host: String, port: Int): NexusStreamChannel {
            val socket = Socket(host, port)
            return SocketStreamChannel(socket)
        }
        override fun openUdp(host: String, port: Int): UserSpaceIpStack.UdpChannel = object : UserSpaceIpStack.UdpChannel {
            private val socket = DatagramSocket()
            private var closed = false
            override fun send(payload: ByteArray) {
                if (closed) return
                socket.send(DatagramPacket(payload, payload.size, InetAddress.getByName(host), port))
            }
            override fun startReceiver(onPayload: (ByteArray) -> Unit): Thread = Thread {
                val buf = ByteArray(65535)
                while (!closed) {
                    val p = DatagramPacket(buf, buf.size)
                    try {
                        socket.receive(p)
                        onPayload(p.data.copyOf(p.length))
                    } catch (_: Exception) {
                        break
                    }
                }
            }.apply { isDaemon = true; start() }
            override fun close() { closed = true; socket.close() }
        }
    }
    val stack = UserSpaceIpStack(tunIn, tunReader, upstream)
    stack.start()

    val synOpts = TcpOptionCodec.synAck(1220, 4, true, 100, 0)
    val syn = Ipv6Packet.buildTcp(client, v6, clientPort, tcpServer.localPort, 1000, 0, 0x002, options = synOpts)
    tunWriter.write(syn); tunWriter.flush()
    val synAckRaw = waitForPacket(tunOut)
    val synAck = Ipv6Packet.parse(synAckRaw)!!
    check(Ipv6Packet.validateTcpChecksum(synAck, synAck.payload))
    val synAckTcp = IpPacket.parseTcp(synAck.payload)!!
    check(synAckTcp.options.windowScale == 4 && synAckTcp.options.sackPermitted)
    val remoteSeq = synAckTcp.sequence

    val ack = Ipv6Packet.buildTcp(client, v6, clientPort, tcpServer.localPort, 1001, (remoteSeq + 1) and 0xffffffffL, 0x010,
        window = 65535, options = TcpOptionCodec.timestamp(101, remoteSeq))
    tunWriter.write(ack); tunWriter.flush()
    waitForPacket(tunOut) // pure cumulative ACK completing the handshake
    val outOfOrder = Ipv6Packet.buildTcp(client, v6, clientPort, tcpServer.localPort, 1006, (remoteSeq + 1) and 0xffffffffL, 0x018,
        payload = "world".toByteArray(), options = TcpOptionCodec.timestamp(102, remoteSeq))
    tunWriter.write(outOfOrder)
    tunWriter.flush()
    val sackAckRaw = waitForPacket(tunOut)
    val sackAck = Ipv6Packet.parse(sackAckRaw)!!
    val sackTcp = IpPacket.parseTcp(sackAck.payload)!!
    check(sackTcp.acknowledgement == 1001L)

    val first = Ipv6Packet.buildTcp(client, v6, clientPort, tcpServer.localPort, 1001, (remoteSeq + 1) and 0xffffffffL, 0x018,
        payload = "hello".toByteArray(), options = TcpOptionCodec.timestamp(103, remoteSeq))
    tunWriter.write(first); tunWriter.flush()
    var responsePayload = ByteArray(0)
    val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(5)
    while (responsePayload.isEmpty() && System.nanoTime() < deadline) {
        val p = Ipv6Packet.parse(waitForPacket(tunOut)) ?: continue
        if (p.nextHeader != 6) continue
        val t = IpPacket.parseTcp(p.payload) ?: continue
        if (t.payload.isNotEmpty()) responsePayload += t.payload
    }
    check(String(responsePayload) == "helloworld")

    val udpPayload = "nexus-ipv6-udp".toByteArray()
    val udp = Ipv6Packet.buildUdp(client, v6, 40124, udpServer.localPort, udpPayload)
    tunWriter.write(udp); tunWriter.flush()
    val udpResp = Ipv6Packet.parse(waitForPacket(tunOut))!!
    check(udpResp.nextHeader == 17)
    val udpRaw = udpResp.payload
    check(Ipv6Packet.validateUdpChecksum(udpResp, udpRaw))
    check(String(udpRaw.copyOfRange(8, udpRaw.size)) == String(udpPayload))

    stack.stop(); tcpServer.close(); udpServer.close()
    println("NEXUS v0.6 real IPv6/TCP/UDP integration self-test OK")
}
