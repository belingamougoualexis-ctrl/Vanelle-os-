import com.nexus.network.IpPacket
import java.net.InetAddress

fun main() {
    val client = InetAddress.getByName("10.1.2.3") as java.net.Inet4Address
    val server = InetAddress.getByName("1.1.1.1") as java.net.Inet4Address

    val udp = IpPacket.buildUdp(client, server, 53000, 53, byteArrayOf(1, 2, 3, 4), 17)
    val udpIp = IpPacket.parseIpv4(udp) ?: error("IPv4/UDP packet rejected")
    val parsedUdp = IpPacket.parseUdp(udpIp.payload) ?: error("UDP header rejected")
    check(IpPacket.validateUdpChecksum(udpIp, parsedUdp, udpIp.payload))

    val tcp = IpPacket.buildTcp(
        client, server, 50000, 443,
        sequence = 100, acknowledgement = 200,
        flags = 0x018,
        payload = byteArrayOf(9, 8, 7),
        identification = 18
    )
    val tcpIp = IpPacket.parseIpv4(tcp) ?: error("IPv4/TCP packet rejected")
    val parsedTcp = IpPacket.parseTcp(tcpIp.payload) ?: error("TCP header rejected")
    check(IpPacket.validateTcpChecksum(tcpIp, tcpIp.payload))
    check(parsedTcp.sequence == 100L)
    check(parsedTcp.acknowledgement == 200L)
    check(parsedTcp.payload.contentEquals(byteArrayOf(9, 8, 7)))

    println("NEXUS userspace core self-test: OK")
}
