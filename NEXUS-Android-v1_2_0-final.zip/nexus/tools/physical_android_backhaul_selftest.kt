package com.nexus.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities

private class FakeCapabilities(
    private val types: Set<Int>,
    private val internet: Boolean,
    private val validated: Boolean,
    private val notMetered: Boolean,
    override val linkDownstreamBandwidthKbps: Int,
    override val linkUpstreamBandwidthKbps: Int
) : NetworkCapabilities() {
    override fun hasTransport(transport: Int): Boolean = transport in types
    override fun hasCapability(capability: Int): Boolean = when (capability) {
        NetworkCapabilities.NET_CAPABILITY_INTERNET -> internet
        NetworkCapabilities.NET_CAPABILITY_VALIDATED -> validated
        NetworkCapabilities.NET_CAPABILITY_NOT_METERED -> notMetered
        else -> false
    }
}

private class FakeNetwork(private val id: Long) : Network() {
    override val networkHandle: Long get() = id
}

private class FakeLinks(private val iface: String) : LinkProperties() {
    override val interfaceName: String get() = iface
    override val linkAddresses: List<Any> = listOf("ip")
}

private class FakeConnectivity(
    private val ns: Array<Network>,
    private val caps: Map<Network, NetworkCapabilities>,
    private val links: Map<Network, LinkProperties>
) : ConnectivityManager() {
    override val allNetworks: Array<Network> get() = ns
    override fun getNetworkCapabilities(network: Network): NetworkCapabilities? = caps[network]
    override fun getLinkProperties(network: Network): LinkProperties? = links[network]
}

private class FakeContext(private val cm: ConnectivityManager) : Context() {
    override val packageManager: android.content.pm.PackageManager = object : android.content.pm.PackageManager() {
        override fun hasSystemFeature(name: String): Boolean = name == android.content.pm.PackageManager.FEATURE_USB_HOST
    }
    override fun <T> getSystemService(serviceClass: Class<T>): T? =
        if (serviceClass == ConnectivityManager::class.java) cm as T else super.getSystemService(serviceClass)
}

fun main() {
    val ethernet = FakeNetwork(11)
    val satellite = FakeNetwork(22)
    val cm = FakeConnectivity(
        arrayOf(ethernet, satellite),
        mapOf(
            ethernet to FakeCapabilities(setOf(3), true, true, true, 100_000, 40_000),
            satellite to FakeCapabilities(setOf(10), true, true, false, 25_000, 8_000)
        ),
        mapOf(ethernet to FakeLinks("eth0"), satellite to FakeLinks("sat0"))
    )
    val context = FakeContext(cm)
    val detector = NexusPhysicalBackhaul(context)
    val inventory = detector.inventory()
    check(inventory.size == 2)
    check(inventory.any { it.medium == NexusPhysicalBackhaul.Medium.SATELLITE && it.internetValidated })
    check(inventory.any { it.medium == NexusPhysicalBackhaul.Medium.ETHERNET && it.externalHardware })
    check(detector.usbHostAvailable())
    val manager = NexusTransportManager(context)
    check(manager.rankedValidatedNetworks().size == 2)
    check(manager.rankedValidatedNetworks().first().downKbps == 100_000)
    println("ANDROID PHYSICAL BACKHAUL / SATELLITE / USB / MULTI-BACKHAUL SELF-TEST: OK")
}
