import com.nexus.network.NexusAdmission
import com.nexus.network.NexusDht
import com.nexus.network.NexusGlobalRoutingTable
import com.nexus.network.NexusInterop
import java.net.InetAddress

fun main() {
    val dht = NexusDht("NX-LOCAL", 20)
    val now = System.currentTimeMillis()
    val record = NexusDht.Record("alpha.mesh", "payload", "NX-REMOTE", now, now + 60_000, "sig")
    check(dht.put(record))
    check(dht.get("alpha.mesh")?.value == "payload")
    dht.observePeer("NX-B")
    dht.observePeer("NX-C")
    check(dht.closestNodes("alpha.mesh").size == 2)

    val a = NexusAdmission.stamp("NX-TEST", "PUBKEY")
    check(NexusAdmission.verify(a))

    check(NexusInterop.parse("127.0.0.1:45454")?.port == 45454)
    check(NexusInterop.parse("nexus://example.org:45454")?.host == "example.org")
    check(NexusInterop.parse("2001:db8::1", 45454)?.host == "2001:db8::1")

    val table = NexusGlobalRoutingTable("NX-LOCAL")
    val route = NexusGlobalRoutingTable.Announcement(
        originNode = "NX-REMOTE", domainId = NexusGlobalRoutingTable.domainFor("NX-REMOTE"),
        prefix = NexusGlobalRoutingTable.domainPrefix(NexusGlobalRoutingTable.domainFor("NX-REMOTE")),
        nextHop = "NX-HOP", metric = 2, path = listOf("NX-REMOTE", "NX-HOP"), sequence = 1,
        expiresAt = now + 60_000
    )
    check(table.install(route))
    check(table.best(route.prefix)?.announcement?.nextHop == "NX-HOP")
    check(!table.install(route.copy(path = listOf("NX-REMOTE", "NX-LOCAL"))))

    println("NEXUS v1.0 DISTRIBUTED CORE SELF-TEST: OK")
}
