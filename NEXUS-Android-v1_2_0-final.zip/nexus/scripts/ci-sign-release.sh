#!/usr/bin/env bash
set -euo pipefail

UNSIGNED_APK=$(find . -path "*/outputs/apk/release/*" -name "*.apk" | head -n 1 || true)
if [ -z "$UNSIGNED_APK" ] || [ ! -f "$UNSIGNED_APK" ]; then
  echo "Erreur : Aucun APK trouve."
  find . -name "*.apk" 2>/dev/null || true
  exit 1
fi
echo "APK trouve : $UNSIGNED_APK"

if [ -z "${KEYSTORE_BASE64:-}" ] || [ -z "${KEYSTORE_PASSWORD:-}" ] || [ -z "${KEY_ALIAS:-}" ] || [ -z "${KEY_PASSWORD:-}" ]; then
  echo "ERREUR : secrets KEYSTORE manquants."
  exit 1
fi

echo "$KEYSTORE_BASE64" | base64 -d > release.jks

if [ -n "${ANDROID_SDK_ROOT:-}" ]; then
  SDK="$ANDROID_SDK_ROOT"
elif [ -n "${ANDROID_HOME:-}" ]; then
  SDK="$ANDROID_HOME"
else
  SDK="$HOME/android-sdk"
fi
echo "SDK=$SDK"

BUILD_TOOLS_DIR=$(ls -d "$SDK"/build-tools/* 2>/dev/null | sort -V | tail -n 1 || true)
if [ -z "$BUILD_TOOLS_DIR" ] || [ ! -d "$BUILD_TOOLS_DIR" ]; then
  echo "ERREUR : build-tools introuvable sous $SDK"
  ls -la "$SDK" 2>/dev/null || true
  exit 1
fi
echo "Build-tools : $BUILD_TOOLS_DIR"

"$BUILD_TOOLS_DIR/zipalign" -f -v -p 4 "$UNSIGNED_APK" app-aligned.apk
"$BUILD_TOOLS_DIR/apksigner" sign \
  --ks release.jks \
  --ks-pass "pass:$KEYSTORE_PASSWORD" \
  --key-pass "pass:$KEY_PASSWORD" \
  --ks-key-alias "$KEY_ALIAS" \
  --out NEXUS-release-signed.apk \
  app-aligned.apk

rm -f release.jks
ls -la NEXUS-release-signed.apk
