#!/usr/bin/env bash
set -euo pipefail

echo "=== Contenu du depot ==="
ls -la

find . -maxdepth 2 -type f -name "*.zip" -print | while read -r z; do
  echo ">>> Decompression de $z"
  unzip -o "$z"
done

echo "=== Apres decompression ==="
ls -la

if [ -f "./nexus/settings.gradle.kts" ]; then
  ANDROID_DIR="./nexus"
elif [ -f "./settings.gradle.kts" ]; then
  ANDROID_DIR="."
else
  GRADLE_FILE=$(find . -name "settings.gradle.kts" -o -name "settings.gradle" 2>/dev/null | grep -v node_modules | head -n 1 || true)
  if [ -z "$GRADLE_FILE" ]; then
    echo "ERREUR : Aucun settings.gradle trouve"
    find . -maxdepth 5 -type f | head -50
    exit 1
  fi
  ANDROID_DIR=$(dirname "$GRADLE_FILE")
fi

echo "ANDROID_DIR=$ANDROID_DIR"
cd "$ANDROID_DIR"
ls -la

touch gradle.properties
grep -q "android.useAndroidX" gradle.properties || echo "android.useAndroidX=true" >> gradle.properties
grep -q "org.gradle.jvmargs" gradle.properties || echo "org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8" >> gradle.properties

if [ -f "./gradlew" ]; then
  chmod +x ./gradlew
  if ./gradlew --version >/dev/null 2>&1; then
    ./gradlew :app:assembleRelease --stacktrace --no-daemon
  else
    curl -sSL -o /tmp/gradle.zip https://services.gradle.org/distributions/gradle-8.11.1-bin.zip
    unzip -q /tmp/gradle.zip -d /tmp
    /tmp/gradle-8.11.1/bin/gradle :app:assembleRelease --stacktrace --no-daemon
  fi
else
  curl -sSL -o /tmp/gradle.zip https://services.gradle.org/distributions/gradle-8.11.1-bin.zip
  unzip -q /tmp/gradle.zip -d /tmp
  /tmp/gradle-8.11.1/bin/gradle :app:assembleRelease --stacktrace --no-daemon
fi

echo "ANDROID_DIR=$ANDROID_DIR" >> "$GITHUB_ENV"
