package com.nova.ai

import android.Manifest
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.animation.ScaleAnimation
import android.widget.*
import java.util.concurrent.Executors
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.compose.setContent
import com.nova.ai.ui.VanelleRoot
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import com.nova.ai.platform.DatasetManager
import com.nova.ai.legal.ConsentStore
import com.nova.ai.legal.LegalActivity
import com.nova.ai.crash.CrashReporter
import com.nova.ai.crash.SentryBridge
import com.nova.ai.db.AppDatabase
import com.nova.ai.llm.LlmRouter
import com.nova.ai.llm.RuleBasedLlm

class MainActivity : AppCompatActivity() {
    private lateinit var accountStore: AccountStore
    private lateinit var mascotStore: MascotStore
    private lateinit var session: NovaSession
    private lateinit var chat: TextView
    private lateinit var status: TextView
    private lateinit var title: TextView
    private lateinit var avatar: ImageView
    private lateinit var xpBar: ProgressBar
    private lateinit var input: EditText
    private lateinit var voiceEngine: VoiceEngine
    private lateinit var aiStudio: AIStudioStore
    private lateinit var secretVault: AISecretVault
    private lateinit var modelLab: ModelLab
    private var speakEnabled = true
    private var lastUserQuestion = ""
    private var lastNovaAnswer = ""
    private var pendingExportKind = "identity"
    private var pendingImportKind = "identity"
    private var pendingAccountPassword = ""
    private var pendingDatasetProjectId = ""
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        accountStore = AccountStore(this)
        aiStudio = AIStudioStore(this)
        secretVault = AISecretVault(this)
        modelLab = ModelLab(this, aiStudio)
        AppDatabase.get(this)
        // UI Compose pro (consentement + auth + chat + bootstrap intégrés)
        setContent {
            VanelleRoot(accountStore = accountStore)
        }
    }

    private fun openMainUi() {
        setContentView(R.layout.activity_main)

        mascotStore = MascotStore(this)
        ensureDefaultMascot()
        session = buildSession()
        voiceEngine = VoiceEngine(this)
        LanguagePackManager.startBackgroundPrepare(this)
        NightlyConsolidationWorker.schedule(this)

        title = findViewById(R.id.title)
        avatar = findViewById(R.id.avatar)
        status = findViewById(R.id.status)
        xpBar = findViewById(R.id.xp_bar)
        chat = findViewById(R.id.chat)
        input = findViewById(R.id.input)

        findViewById<Button>(R.id.mascots).setOnClickListener { showMascotPicker() }
        findViewById<Button>(R.id.send).setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            input.setText("")
            handleUserText(text)
        }
        findViewById<Button>(R.id.mic).setOnClickListener { startVoiceInput() }
        findViewById<Button>(R.id.teach).setOnClickListener { showTeachMode() }
        findViewById<Button>(R.id.consolidate).setOnClickListener { runConsolidation() }
        findViewById<Button>(R.id.correct).setOnClickListener { showCorrectionDialog() }
        findViewById<Button>(R.id.export).setOnClickListener { startExport() }
        findViewById<Button>(R.id.import_id).setOnClickListener { startImport() }
        findViewById<Button>(R.id.overlay).setOnClickListener { toggleOverlay() }
        findViewById<Button>(R.id.journal).setOnClickListener { showJournal() }
        findViewById<Button>(R.id.share_card).setOnClickListener { shareCard() }
        findViewById<Button>(R.id.shop).setOnClickListener { showShop() }
        findViewById<Button>(R.id.settings).setOnClickListener { showInfo() }
        findViewById<Button>(R.id.ai_studio).setOnClickListener { showAIStudio() }
        findViewById<Button>(R.id.speak_toggle).setOnClickListener {
            speakEnabled = !speakEnabled
            (it as Button).text = if (speakEnabled) "🔊 Voix" else "🔇 Muet"
        }
        findViewById<Button>(R.id.speak_toggle).setOnLongClickListener {
            showVoiceSettings()
            true
        }

        // Accessibilité (TalkBack)
        AccessibilityHelper.setButtonLabel(findViewById(R.id.send), getString(R.string.cd_send))
        AccessibilityHelper.setButtonLabel(findViewById(R.id.mic), getString(R.string.cd_mic))
        AccessibilityHelper.setButtonLabel(findViewById(R.id.settings), getString(R.string.cd_settings))
        AccessibilityHelper.setChatLiveRegion(chat)
        AccessibilityHelper.setAvatarLabel(avatar, session.mascot.name, session.progress().stage)

        requestNeededPermissions()
        refreshHeader()

        if (!Onboarding.isDone(this)) {
            runOnboarding()
        } else {
            ProactiveEngine.onAppOpen(this, session)?.let { msg ->
                append(session.mascot.name, msg)
                setEmotion(GrowthSystem.Emotion.HAPPY)
                if (speakEnabled) voiceEngine.speak(msg, session.mascot.voice)
            }
        }
        refreshWidget()
        startModelBootstrap()
        val acc = accountStore.current()
        append("Système", "VanelleLife · ${acc?.username} · données locales par défaut; aucun moteur externe sans configuration explicite.")
    }

    private fun showAuthGate() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 16)
        }
        box.addView(TextView(this).apply {
            text = "Compte 100% local (pas de serveur).\nChanger de téléphone = exporter puis importer le compte."
            setTextColor(0xFFB9C0CC.toInt())
        })
        val user = EditText(this).apply { hint = "Identifiant"; setSingleLine() }
        val pass = EditText(this).apply {
            hint = "Mot de passe (min. 4)"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(user)
        box.addView(pass)
        AlertDialog.Builder(this)
            .setTitle("VanelleLife — Compte local")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton("Connexion") { _, _ ->
                val err = accountStore.login(user.text.toString(), pass.text.toString())
                if (err != null) {
                    Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                    showAuthGate()
                } else openMainUi()
            }
            .setNeutralButton("Inscription") { _, _ ->
                val err = accountStore.register(user.text.toString(), pass.text.toString())
                if (err != null) {
                    Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                    showAuthGate()
                } else openMainUi()
            }
            .setNegativeButton("Importer compte") { _, _ ->
                pendingImportKind = "account"
                pendingAccountPassword = pass.text.toString()
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                startActivityForResult(intent, REQ_IMPORT_ACCOUNT)
            }
            .show()
    }

    private fun ensureDefaultMascot() {
        if (mascotStore.all().isEmpty()) {
            val m = mascotStore.add("Vanelle", MascotStore.DEFAULT_SKIN)
            mascotStore.setActive(m.id)
        } else if (mascotStore.active() == null) {
            mascotStore.setActive(mascotStore.all().first().id)
        }
    }

    private fun buildSession(): NovaSession {
        val m = mascotStore.active() ?: mascotStore.add("Vanelle", MascotStore.DEFAULT_SKIN)
        return NovaSession(this, m)
    }

    private fun refreshHeader() {
        val titleId = XpShop.activeTitle(this, session.mascot.id)
        val titleExtra = XpShop.titleLabel(titleId)
        title.text = if (titleExtra.isNotEmpty()) "${session.mascot.name} · $titleExtra" else session.mascot.name
        val spendable = XpShop.spendableXp(this, session.mascot.id)
        val lang = LanguageCatalog.labelOf(session.mascot.voice.languageTag)
        status.text = session.statusLine() + " · $lang · boutique $spendable XP"
        avatar.setImageResource(MascotStore.drawableId(this, session.mascot.skin))
        avatar.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            avatar.clipToOutline = true
            avatar.outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: android.view.View, outline: android.graphics.Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, 24f)
                }
            }
        }
        val p = session.progress()
        xpBar.progress = (p.progress01 * 100).toInt()
    }

    private fun setEmotion(e: GrowthSystem.Emotion) {
        val scale = when (e) {
            GrowthSystem.Emotion.LISTENING -> 1.1f
            GrowthSystem.Emotion.THINKING -> 0.94f
            GrowthSystem.Emotion.HAPPY, GrowthSystem.Emotion.PROUD -> 1.15f
            GrowthSystem.Emotion.SURPRISED -> 1.2f
            else -> 1.05f
        }
        val anim = ScaleAnimation(
            1f, scale, 1f, scale,
            ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
            ScaleAnimation.RELATIVE_TO_SELF, 0.5f
        ).apply { duration = 160; repeatMode = ScaleAnimation.REVERSE; repeatCount = 1 }
        avatar.startAnimation(anim)
        val matrix = ColorMatrix()
        when (e) {
            GrowthSystem.Emotion.LISTENING -> matrix.setScale(0.85f, 0.95f, 1.25f, 1f)
            GrowthSystem.Emotion.PROUD, GrowthSystem.Emotion.HAPPY -> matrix.setScale(1.15f, 1.1f, 0.9f, 1f)
            GrowthSystem.Emotion.SURPRISED -> matrix.setScale(1.2f, 1.2f, 1.2f, 1f)
            GrowthSystem.Emotion.SAD -> matrix.setScale(0.85f, 0.85f, 0.95f, 1f)
            else -> { avatar.clearColorFilter(); return }
        }
        avatar.colorFilter = ColorMatrixColorFilter(matrix)
        avatar.postDelayed({ avatar.clearColorFilter() }, 700)
    }

    private fun handleUserText(text: String) {
        lastUserQuestion = text
        append("Toi", text)
        setEmotion(GrowthSystem.Emotion.THINKING)
        session.development.observe(text)
        session.journal.add("message", text.take(100))
        GrowthSystem.addBonusXp(this, session.mascot.id, 1)
        refreshHeader()
        val send = findViewById<Button>(R.id.send)
        send.isEnabled = false
        lifecycleScope.launch {
            // ChatEngine tente d'abord un vrai provider IA externe si configuré (Réglages IA),
            // et ne retombe sur le moteur de règles local que si aucun provider n'est actif
            // ou que l'appel a échoué. lifecycleScope annule automatiquement la requête réseau
            // si l'utilisateur quitte l'écran avant la réponse (fuite évitée vs l'ancien Executor).
            val result = ChatEngine.reply(this@MainActivity, session, text)
            val answer = result.text
            lastNovaAnswer = answer
            session.learning.addExperience("Question : $text", "Réponse : $answer")
            session.development.indexVector(text, "experience", session.embedder)
            val emotion = if (answer.contains("ne sais pas", true) || answer.contains("Enseigne", true))
                GrowthSystem.Emotion.SURPRISED else GrowthSystem.Emotion.HAPPY
            append(session.mascot.name, answer)
            setEmotion(emotion)
            send.isEnabled = true
            refreshHeader()
            refreshWidget()
            if (speakEnabled) voiceEngine.speak(answer, session.mascot.voice)
        }
    }

    private fun runOnboarding() {
        val name = EditText(this).apply { hint = "Nom de ta mascotte"; setText("Vanelle") }
        AlertDialog.Builder(this)
            .setTitle("✨ Bienvenue")
            .setMessage("Donne un nom à ta mascotte.")
            .setView(name)
            .setCancelable(false)
            .setPositiveButton("Continuer") { _, _ ->
                val n = name.text.toString().trim().ifBlank { "Vanelle" }
                pickSkinForOnboarding(n)
            }
            .show()
    }

    private fun pickSkinForOnboarding(n: String) {
        val skins = MascotStore.SKINS.filter { it.first in XpShop.FREE_SKINS }
        AlertDialog.Builder(this)
            .setTitle("Choisis son apparence (gratuite)")
            .setItems(skins.map { it.second }.toTypedArray()) { _, which ->
                val m = mascotStore.add(n, skins[which].first)
                mascotStore.setActive(m.id)
                session = buildSession()
                refreshHeader()
                askSecret(m)
            }
            .setCancelable(false)
            .show()
    }

    private fun askSecret(m: Mascot) {
        val secret = EditText(this).apply {
            hint = "Un secret ou un fait sur toi (ex: je m'appelle Alex)"
            minLines = 2
        }
        AlertDialog.Builder(this)
            .setTitle("Dis un secret à ${m.name}")
            .setMessage("Elle s'en souviendra. C'est le premier souvenir.")
            .setView(secret)
            .setCancelable(false)
            .setPositiveButton("C'est dit") { _, _ ->
                val s = secret.text.toString().trim()
                if (s.isNotEmpty()) {
                    Onboarding.saveSecret(this, m.id, s)
                    session.development.observe(s)
                    session.memory.remember(s, 5)
                    session.learning.learn("identité", s, 0.9)
                    session.journal.add("naissance", "Premier secret : ${s.take(80)}")
                    GrowthSystem.addBonusXp(this, m.id, 15)
                    session = buildSession()
                    val reply = "Je m'en souviendrai. ${s.take(60)}. Je suis ${m.name}, à toi de m'élever."
                    append(m.name, reply)
                    setEmotion(GrowthSystem.Emotion.PROUD)
                    if (speakEnabled) voiceEngine.speak(reply, session.mascot.voice)
                }
                Onboarding.markDone(this)
                refreshHeader()
                append("Système", "Astuce : Enseigner · Corriger · Bulle ON · appui long sur 🔊 pour les voix.")
            }
            .show()
    }

    private fun showTeachMode() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 12, 40, 8)
        }
        val fact = EditText(this).apply {
            hint = "Fait à retenir (ex: La capitale de l'Italie est Rome)"
            minLines = 2
        }
        val topic = EditText(this).apply { hint = "Sujet (ex: géographie)" }
        box.addView(TextView(this).apply {
            text = "Mode Enseigner — une phrase claire, elle enregistre."
            setTextColor(0xFFB9C0CC.toInt())
        })
        box.addView(topic)
        box.addView(fact)
        AlertDialog.Builder(this)
            .setTitle("Enseigner ${session.mascot.name}")
            .setView(box)
            .setPositiveButton("Apprendre") { _, _ ->
                val t = topic.text.toString().trim().ifBlank { "leçon" }
                val f = fact.text.toString().trim()
                if (f.isEmpty()) return@setPositiveButton
                session.learning.learn(t, f, 0.95)
                session.memory.remember(f, 4)
                session.development.observe(f)
                session.journal.add("leçon", f.take(100))
                GrowthSystem.addBonusXp(this, session.mascot.id, 8)
                setEmotion(GrowthSystem.Emotion.PROUD)
                val quiz = "Compris. « $f ». Tu veux me tester ? Demande-moi : $t"
                append(session.mascot.name, quiz)
                refreshHeader()
                if (speakEnabled) voiceEngine.speak("J'ai appris. $f", session.mascot.voice)
            }
            .setNeutralButton("Quiz") { _, _ ->
                val k = session.learning.knowledge().lastOrNull()
                if (k == null) {
                    Toast.makeText(this, "Aucune leçon encore", Toast.LENGTH_SHORT).show()
                } else {
                    append("Système", "Quiz : de quoi se souvient ${session.mascot.name} à propos de « ${k.subject} » ?")
                    input.setText(k.subject)
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showJournal() {
        val text = session.journal.timelineText(40)
        val tv = TextView(this).apply {
            this.text = text
            setTextColor(0xFFEEEEEE.toInt())
            setPadding(30, 20, 30, 20)
            textSize = 13f
        }
        val scroll = ScrollView(this).apply { addView(tv) }
        AlertDialog.Builder(this)
            .setTitle("Carnet de ${session.mascot.name}")
            .setView(scroll)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun shareCard() {
        val card = ProactiveEngine.shareCard(session, session.progress())
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, card)
        }
        startActivity(Intent.createChooser(intent, "Carte de ${session.mascot.name}"))
    }

    private fun showMascotPicker() {
        val list = mascotStore.all()
        if (list.isEmpty()) {
            showAddMascot()
            return
        }
        val labels = list.map { m ->
            val skinLabel = MascotStore.SKINS.firstOrNull { it.first == m.skin }?.second ?: m.skin
            "${m.name} ($skinLabel)"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Tes mascottes")
            .setItems(labels) { _, which ->
                mascotStore.setActive(list[which].id)
                session = buildSession()
                refreshHeader()
                append("Système", "Mascotte active : ${session.mascot.name}")
                reloadOverlay()
                refreshWidget()
            }
            .setPositiveButton("Ajouter") { _, _ -> showAddMascot() }
            .setNeutralButton("Renommer") { _, _ -> showRenameMascot() }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun showAddMascot() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 16, 40, 8)
        }
        box.addView(TextView(this).apply {
            text = "Nom libre (Lila, Max, Pixel…)"
            setTextColor(0xFFB9C0CC.toInt())
        })
        val name = EditText(this).apply { hint = "Nom"; setSingleLine() }
        box.addView(name)
        AlertDialog.Builder(this)
            .setTitle("Nouvelle mascotte")
            .setView(box)
            .setPositiveButton("Apparence") { _, _ ->
                val n = name.text.toString().trim().ifBlank { "Vanelle" }
                val skins = MascotStore.SKINS.filter { it.first in XpShop.FREE_SKINS }
                AlertDialog.Builder(this)
                    .setTitle("Apparence gratuite pour « $n »")
                    .setItems(skins.map { it.second }.toTypedArray()) { _, which ->
                        val m = mascotStore.add(n, skins[which].first)
                        mascotStore.setActive(m.id)
                        session = buildSession()
                        session.journal.add("naissance", "Création de $n")
                        refreshHeader()
                        append("Système", "« ${m.name} » est prête — à toi de l'élever.")
                        reloadOverlay()
                        refreshWidget()
                    }
                    .setNegativeButton("Annuler", null)
                    .show()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showRenameMascot() {
        val current = session.mascot
        val name = EditText(this).apply {
            setText(current.name); setSingleLine(); setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("Renommer")
            .setView(name)
            .setPositiveButton("OK") { _, _ ->
                val n = name.text.toString().trim()
                if (n.isEmpty()) return@setPositiveButton
                mascotStore.rename(current.id, n)
                session = buildSession()
                refreshHeader()
                append("Système", "Elle s'appelle « ${session.mascot.name} ».")
                reloadOverlay()
                refreshWidget()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun toggleOverlay() {
        if (!canDrawOverlays()) {
            AlertDialog.Builder(this)
                .setTitle("Permission requise")
                .setMessage("Autorise « Afficher par-dessus d'autres apps ».")
                .setPositiveButton("Réglages") { _, _ ->
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
                .setNegativeButton("Plus tard", null)
                .show()
            return
        }
        val intent = Intent(this, MascotOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "Bulle active — toucher = micro, long = ouvrir", Toast.LENGTH_LONG).show()
    }

    private fun reloadOverlay() {
        if (!canDrawOverlays()) return
        val i = Intent(this, MascotOverlayService::class.java).setAction(MascotOverlayService.ACTION_RELOAD)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun canDrawOverlays(): Boolean =
        if (Build.VERSION.SDK_INT >= 23) Settings.canDrawOverlays(this) else true

    private fun requestNeededPermissions() {
        // 1) Permissions runtime dangereuses (dialogues système dès l'ouverture)
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.READ_MEDIA_IMAGES)
            }
        } else if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), REQ_PERM)
        }
        // 2) Overlay = réglage spécial (pas un simple requestPermissions)
        main.postDelayed({ maybeAskOverlayPermission() }, 600)
    }

    private fun maybeAskOverlayPermission() {
        if (canDrawOverlays()) return
        AlertDialog.Builder(this)
            .setTitle("Afficher la mascotte partout")
            .setMessage(
                "Pour la bulle par-dessus les autres apps, Android exige l'autorisation " +
                "« Afficher par-dessus d'autres applications »."
            )
            .setPositiveButton("Autoriser") { _, _ ->
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (_: Exception) {
                    Toast.makeText(this, "Ouvre les réglages des apps → NOVA → Autorisations", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Plus tard", null)
            .show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERM) return
        val denied = permissions.filterIndexed { i, _ ->
            grantResults.getOrNull(i) != PackageManager.PERMISSION_GRANTED
        }
        if (denied.isNotEmpty()) {
            Toast.makeText(
                this,
                "Autorisations refusées : ${denied.joinToString { it.substringAfterLast('.') }}. Certaines fonctions seront limitées.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun startVoiceInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_PERM)
            return
        }
        setEmotion(GrowthSystem.Emotion.LISTENING)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val lang = session.mascot.voice.languageTag.ifBlank { LanguageCatalog.DEFAULT }
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, LanguageCatalog.speechOf(lang))
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, LanguageCatalog.speechOf(lang))
        }
        if (intent.resolveActivity(packageManager) != null) startActivityForResult(intent, REQ_SPEECH)
        else Toast.makeText(this, "Reconnaissance vocale indisponible", Toast.LENGTH_SHORT).show()
    }

    private fun runConsolidation() {
        append("Système", "Consolidation de ${session.mascot.name}…")
        setEmotion(GrowthSystem.Emotion.THINKING)
        executor.execute {
            val r = session.development.consolidateNow()
            session.journal.add("consolidation", "lot ${r.batchSize}, concepts ${r.conceptsFormed}")
            GrowthSystem.addBonusXp(this, session.mascot.id, 5)
            main.post {
                append(
                    "Système",
                    if (r.batchSize == 0) "Rien à consolider."
                    else "Lot ${r.batchSize} · concepts ${r.conceptsFormed} · croyances ${r.beliefsRevised}"
                )
                setEmotion(GrowthSystem.Emotion.PROUD)
                refreshHeader()
                refreshWidget()
            }
        }
    }

    private fun showCorrectionDialog() {
        if (lastUserQuestion.isBlank()) {
            Toast.makeText(this, "Rien à corriger pour l'instant.", Toast.LENGTH_SHORT).show()
            return
        }
        val preferred = EditText(this).apply { setText(lastNovaAnswer); minLines = 3 }
        AlertDialog.Builder(this)
            .setTitle("Éduquer ${session.mascot.name}")
            .setMessage("Question : ${lastUserQuestion.take(100)}")
            .setView(preferred)
            .setPositiveButton("Enregistrer") { _, _ ->
                val p = preferred.text.toString().trim()
                if (p.isNotEmpty()) {
                    session.development.recordCorrection(lastUserQuestion, p)
                    session.journal.add("correction", p.take(80))
                    GrowthSystem.addBonusXp(this, session.mascot.id, 10)
                    setEmotion(GrowthSystem.Emotion.PROUD)
                    append("Système", "Correction enregistrée.")
                    refreshHeader()
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }



    private fun askPasswordThenExportAccount() {
        val pass = EditText(this).apply {
            hint = "Mot de passe du compte"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle("Exporter le compte complet")
            .setMessage("Toutes les mascottes + boutique. Protégé par ton mot de passe.")
            .setView(pass)
            .setPositiveButton("Exporter") { _, _ ->
                pendingAccountPassword = pass.text.toString()
                if (!accountStore.verifyPassword(pendingAccountPassword)) {
                    Toast.makeText(this, "Mot de passe incorrect", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "nova_compte_${accountStore.current()?.username}.json")
                }
                startActivityForResult(intent, REQ_EXPORT)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun startExport() {
        AlertDialog.Builder(this)
            .setTitle("Exporter l'IA de ${session.mascot.name}")
            .setItems(
                arrayOf(
                    "Identité d'une mascotte (NOVA)",
                    "Cerveau portable JSON (autres apps)",
                    "Dataset JSONL (fine-tuning)",
                    "COMPTE COMPLET (changement de téléphone)"
                )
            ) { _, which ->
                pendingExportKind = when (which) {
                    1 -> "portable"
                    2 -> "jsonl"
                    3 -> "account"
                    else -> "identity"
                }
                if (pendingExportKind == "account") {
                    askPasswordThenExportAccount()
                    return@setItems
                }
                val ext = if (pendingExportKind == "jsonl") "jsonl" else "json"
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "nova_${session.mascot.name}_$pendingExportKind.$ext")
                }
                startActivityForResult(intent, REQ_EXPORT)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }


    private fun startImport() {
        AlertDialog.Builder(this)
            .setTitle("Importer")
            .setItems(
                arrayOf(
                    "Identité NOVA (restaurer une mascotte)",
                    "Données d'apprentissage (txt, json, jsonl) → lui enseigner"
                )
            ) { _, which ->
                pendingImportKind = if (which == 1) "teach" else "identity"
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                        "application/json",
                        "text/plain",
                        "text/markdown",
                        "text/csv",
                        "application/octet-stream"
                    ))
                }
                startActivityForResult(intent, REQ_IMPORT)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_DATASET) {
            if(resultCode==RESULT_OK && data!=null) handleDatasetResult(data)
            pendingDatasetProjectId=""
            return
        }
        if (requestCode == REQ_AI_EXPORT) {
            if (resultCode == RESULT_OK && data?.data != null) {
                try { contentResolver.openOutputStream(data.data!!)?.bufferedWriter()?.use { it.write(buildSecureAIExport(pendingExportKind.removePrefix("ai_"),pendingAccountPassword)) }; Toast.makeText(this,"IA exportée : secrets protégés par mot de passe.",Toast.LENGTH_LONG).show() } catch(e:Exception){ Toast.makeText(this,"Export IA : ${e.message}",Toast.LENGTH_LONG).show() }
            }
            return
        }
        if (requestCode == REQ_AI_IMPORT) {
            if (resultCode == RESULT_OK && data?.data != null) try {
                val raw=contentResolver.openInputStream(data.data!!)?.bufferedReader()?.use{it.readText()} ?: ""
                val root=org.json.JSONObject(raw); val pass=EditText(this).apply{hint="Mot de passe de l'export";inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD}
                AlertDialog.Builder(this).setTitle("Importer l'IA").setView(pass).setPositiveButton("Importer") { _, _ ->
                    try { val p=aiStudio.importJson(raw); val sec=root.optJSONObject("encryptedApiSecrets"); if(sec!=null) listOf("image","video","voix","conversation").forEach{kind->if(sec.has(kind))secretVault.put("${p.id}:$kind",AIExportCrypto.decrypt(sec.getString(kind),pass.text.toString()))};append("AI Studio","${p.name} a été restaurée avec son éducation et ses secrets protégés.");manageUserAI(p) } catch(e:Exception){Toast.makeText(this,"Import IA : ${e.message}",Toast.LENGTH_LONG).show()}
                }.setNegativeButton("Annuler",null).show()
            } catch(e:Exception){Toast.makeText(this,"Import IA : ${e.message}",Toast.LENGTH_LONG).show()}
            return
        }
        if (requestCode == REQ_IMPORT_ACCOUNT) {
            if (resultCode != RESULT_OK || data?.data == null) {
                showAuthGate()
                return
            }
            try {
                val text = contentResolver.openInputStream(data.data!!)?.bufferedReader()?.use { it.readText() } ?: ""
                // demander mot de passe si vide
                if (pendingAccountPassword.isBlank()) {
                    val pass = EditText(this).apply {
                        hint = "Mot de passe du compte exporté"
                        inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
                    }
                    AlertDialog.Builder(this)
                        .setTitle("Mot de passe")
                        .setView(pass)
                        .setPositiveButton("Importer") { _, _ ->
                            val err = FullAccountBackup.import(this, text, pass.text.toString())
                            if (err != null) {
                                Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                                showAuthGate()
                            } else {
                                Toast.makeText(this, "Compte restauré", Toast.LENGTH_SHORT).show()
                                openMainUi()
                            }
                        }
                        .setNegativeButton("Annuler") { _, _ -> showAuthGate() }
                        .show()
                } else {
                    val err = FullAccountBackup.import(this, text, pendingAccountPassword)
                    if (err != null) {
                        Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                        showAuthGate()
                    } else {
                        Toast.makeText(this, "Compte restauré", Toast.LENGTH_SHORT).show()
                        openMainUi()
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Import : ${e.message}", Toast.LENGTH_LONG).show()
                showAuthGate()
            }
            return
        }
        if (requestCode == REQ_TTS_CHECK) {
            if (resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {
                LanguagePackManager.refreshAll()
                Toast.makeText(this, "Packs vocaux prêts", Toast.LENGTH_SHORT).show()
            } else {
                try {
                    startActivity(VoiceStore.installTtsDataIntent())
                } catch (_: Exception) {
                    Toast.makeText(this, "Réglages → Synthèse vocale", Toast.LENGTH_LONG).show()
                }
            }
            return
        }
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQ_SPEECH -> data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let {
                input.setText(it)
                handleUserText(it)
            }
            REQ_EXPORT -> data.data?.let { uri ->
                try {
                    val content = when (pendingExportKind) {
                        "portable" -> IdentityBackup.exportPortable(this, session)
                        "jsonl" -> IdentityBackup.exportDatasetJsonl(session)
                        "account" -> FullAccountBackup.export(this, pendingAccountPassword)
                            ?: throw Exception("Export compte impossible")
                        else -> IdentityBackup.export(this, session.mascot.id)
                    }
                    contentResolver.openOutputStream(uri)?.use {
                        it.write(content.toByteArray(Charsets.UTF_8))
                    }
                    Toast.makeText(this, "IA exportée ($pendingExportKind)", Toast.LENGTH_SHORT).show()
                    append("Système", "Export $pendingExportKind de ${session.mascot.name} réussi.")
                } catch (_: Exception) {
                    Toast.makeText(this, "Export échoué", Toast.LENGTH_SHORT).show()
                }
            }
            REQ_IMPORT -> data.data?.let { uri ->
                try {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return
                    val name = uri.lastPathSegment ?: ""
                    if (pendingImportKind == "teach") {
                        setEmotion(GrowthSystem.Emotion.THINKING)
                        executor.execute {
                            val report = KnowledgeImporter.importText(session, text, name)
                            main.post {
                                session = buildSession()
                                refreshHeader()
                                refreshWidget()
                                setEmotion(GrowthSystem.Emotion.PROUD)
                                append("Système", "Apprentissage fichier : ${report.message}")
                                if (speakEnabled) {
                                    voiceEngine.speak(
                                        "J'ai appris ${report.knowledge + report.supervised} éléments.",
                                        session.mascot.voice
                                    )
                                }
                                Toast.makeText(this, report.message, Toast.LENGTH_LONG).show()
                            }
                        }
                    } else {
                        IdentityBackup.import(this, text)
                        session = buildSession()
                        refreshHeader()
                        append("Système", "Identité importée.")
                        Toast.makeText(this, "Identité restaurée", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Import échoué : ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showVoiceSettings() {
        val langLabel = LanguageCatalog.labelOf(session.mascot.voice.languageTag)
        val items = arrayOf(
            "Langue micro + TTS ($langLabel)",
            "Régler la voix de ${session.mascot.name}",
            "Télécharger des packs / profils",
            "Installer données vocales système",
            "Tester"
        )
        AlertDialog.Builder(this)
            .setTitle("Centre des voix")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showLanguagePicker()
                    1 -> showVoiceTuner()
                    2 -> showVoiceDownloadList()
                    3 -> startSystemVoiceInstall()
                    4 -> {
                        val sample = samplePhrase(session.mascot.voice.languageTag)
                        voiceEngine.speak(sample, session.mascot.voice)
                    }
                }
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun samplePhrase(tag: String): String {
        val name = session.mascot.name
        return when (tag.substringBefore('-').lowercase()) {
            "fr" -> "Bonjour, je suis $name. Ma voix est prête."
            "en" -> "Hello, I am $name. My voice is ready."
            "es" -> "Hola, soy $name. Mi voz está lista."
            "pt" -> "Olá, eu sou $name. A minha voz está pronta."
            "de" -> "Hallo, ich bin $name. Meine Stimme ist bereit."
            "it" -> "Ciao, sono $name. La mia voce è pronta."
            "ar" -> "مرحبا، أنا $name."
            "zh" -> "你好，我是$name。"
            "ja" -> "こんにちは、$nameです。"
            "sw" -> "Habari, mimi ni $name."
            "ln" -> "Mbote, nazo $name."
            else -> "Hello, I am $name."
        }
    }

    private fun showLanguagePicker() {
        LanguagePackManager.refreshAll()
        val langs = LanguageCatalog.ALL
        val current = session.mascot.voice.languageTag
        val labels = langs.map {
            val st = LanguagePackManager.stateOf(it.tag)
            val badge = when (st) {
                LanguagePackManager.State.READY -> "✓"
                LanguagePackManager.State.DOWNLOADING -> "↓…"
                LanguagePackManager.State.MISSING -> "!"
                else -> "…"
            }
            val mark = if (it.tag.equals(current, true)) " · active" else ""
            "$badge ${it.label}$mark"
        }.toTypedArray()
        val selected = langs.indexOfFirst { it.tag.equals(current, true) }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Langue micro + voix")
            .setMessage(LanguagePackManager.statusSummary() + "\n✓ prêt · ↓… préparation · ! à installer")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                val lang = langs[which]
                val reason = LanguagePackManager.reasonIfNotReady(lang.tag)
                if (reason != null) {
                    // Ne pas appliquer tant que pas prêt
                    LanguagePackManager.ensureLanguage(this, lang.tag)
                    AlertDialog.Builder(this)
                        .setTitle("Pack pas encore prêt")
                        .setMessage(reason)
                        .setPositiveButton("Installer le pack") { _, _ ->
                            try {
                                startActivityForResult(LanguagePackManager.checkSystemDataIntent(), REQ_TTS_CHECK)
                            } catch (_: Exception) {
                                try {
                                    startActivity(LanguagePackManager.installSystemDataIntent())
                                } catch (_: Exception) {
                                    Toast.makeText(this, "Réglages → Synthèse vocale", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                        .setNeutralButton("Réessayer") { _, _ ->
                            LanguagePackManager.refreshAll()
                            main.postDelayed({ showLanguagePicker() }, 800)
                        }
                        .setNegativeButton("OK", null)
                        .show()
                    return@setSingleChoiceItems
                }
                val vs = session.mascot.voice.copy(languageTag = lang.tag, voiceName = "")
                mascotStore.setVoice(session.mascot.id, vs)
                session = buildSession()
                refreshHeader()
                val msg = "Langue active : ${lang.label}. Micro + TTS branchés."
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                append("Système", msg)
                voiceEngine.speak(samplePhrase(lang.tag), session.mascot.voice)
                dialog.dismiss()
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun showVoiceDownloadList() {
        val packs = VoiceStore.CATALOG
        val labels = packs.map { p ->
            val state = when {
                p.systemInstall -> "↓ système"
                VoiceStore.isDownloaded(this, p) -> "✓"
                else -> "~${p.approxMb} Mo"
            }
            "${p.label} [$state]"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Télécharger une voix")
            .setItems(labels) { _, which ->
                val pack = packs[which]
                when {
                    pack.systemInstall -> startSystemVoiceInstall()
                    pack.url != null -> downloadVoicePack(pack)
                    else -> {
                        val settings = VoiceStore.toVoiceSettings(pack, languageTag = session.mascot.voice.languageTag)
                        mascotStore.setVoice(session.mascot.id, settings)
                        session = buildSession()
                        voiceEngine.speak("Profil ${pack.label} appliqué.", settings)
                    }
                }
            }
            .setNegativeButton("Retour", null)
            .show()
    }

    private fun downloadVoicePack(pack: VoiceStore.VoicePack) {
        val progress = ProgressDialog(this).apply {
            setTitle(pack.label)
            setMessage("Téléchargement…")
            setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
            max = 100
            setCancelable(false)
            show()
        }
        executor.execute {
            val err = VoiceStore.download(this, pack) { pct -> main.post { progress.progress = pct } }
            main.post {
                progress.dismiss()
                if (err != null) Toast.makeText(this, "Échec : $err", Toast.LENGTH_LONG).show()
                else {
                    val settings = VoiceStore.toVoiceSettings(pack, languageTag = session.mascot.voice.languageTag)
                    mascotStore.setVoice(session.mascot.id, settings)
                    session = buildSession()
                    voiceEngine.speak("Téléchargement terminé.", settings)
                    Toast.makeText(this, "Voix prête", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun startSystemVoiceInstall() {
        try {
            startActivityForResult(VoiceStore.checkTtsDataIntent(), REQ_TTS_CHECK)
        } catch (_: Exception) {
            try {
                startActivity(VoiceStore.installTtsDataIntent())
            } catch (_: Exception) {
                Toast.makeText(this, "Réglages → Synthèse vocale", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showVoiceTuner() {
        val current = session.mascot.voice
        val voices = voiceEngine.availableVoices(current.languageTag)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 16, 40, 8)
        }
        var selectedVoice = current.voiceName
        var selectedIdx = voices.indexOfFirst { it.name == current.voiceName }.let { if (it < 0) 0 else it }
        val pitchLabel = TextView(this).apply { text = "Ton : ${"%.1f".format(current.pitch)}" }
        val pitch = SeekBar(this).apply {
            max = 15
            progress = ((current.pitch - 0.5f) * 10).toInt().coerceIn(0, 15)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    pitchLabel.text = "Ton : ${"%.1f".format(0.5f + p / 10f)}"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        val rateLabel = TextView(this).apply { text = "Débit : ${"%.1f".format(current.rate)}" }
        val rate = SeekBar(this).apply {
            max = 15
            progress = ((current.rate - 0.5f) * 10).toInt().coerceIn(0, 15)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    rateLabel.text = "Débit : ${"%.1f".format(0.5f + p / 10f)}"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        box.addView(pitchLabel); box.addView(pitch); box.addView(rateLabel); box.addView(rate)
        val labels = if (voices.isEmpty()) arrayOf("Voix système") else voices.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Réglage voix")
            .setView(box)
            .setSingleChoiceItems(labels, selectedIdx) { _, which ->
                selectedIdx = which
                selectedVoice = if (voices.isEmpty()) "" else voices[which].name
            }
            .setPositiveButton("Sauver") { _, _ ->
                val settings = VoiceEngine.VoiceSettings(
                    selectedVoice,
                    0.5f + pitch.progress / 10f,
                    0.5f + rate.progress / 10f,
                    current.languageTag
                )
                mascotStore.setVoice(session.mascot.id, settings)
                session = buildSession()
                voiceEngine.speak(samplePhrase(current.languageTag), settings)
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun showShop() {
        val mid = session.mascot.id
        val available = XpShop.spendableXp(this, mid)
        val items = XpShop.CATALOG
        val labels = items.map { item ->
            val state = when {
                XpShop.has(this, mid, item.id) -> "✓ possédé"
                available >= item.cost -> "${item.cost} XP"
                else -> "${item.cost} XP (manque)"
            }
            "${item.label} — $state"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Boutique · $available XP dépensables")
            .setItems(labels) { _, which ->
                val item = items[which]
                if (XpShop.has(this, mid, item.id)) {
                    // ré-équiper
                    when (item.kind) {
                        XpShop.Item.Kind.TITLE -> {
                            XpShop.setTitle(this, mid, item.id)
                            Toast.makeText(this, "Titre équipé", Toast.LENGTH_SHORT).show()
                        }
                        XpShop.Item.Kind.AURA -> {
                            XpShop.setAura(this, mid, item.id)
                            Toast.makeText(this, "Aura équipée (bulle)", Toast.LENGTH_SHORT).show()
                            reloadOverlay()
                        }
                        XpShop.Item.Kind.SKIN -> {
                            XpShop.skinIdFromItem(item.id)?.let { skin ->
                                mascotStore.setSkin(mid, skin)
                                session = buildSession()
                                reloadOverlay()
                            }
                        }
                        XpShop.Item.Kind.VOICE_PROFILE -> {
                            XpShop.voiceSettingsFor(item.id, session.mascot.voice.languageTag)?.let { vs ->
                                mascotStore.setVoice(mid, vs)
                                session = buildSession()
                                voiceEngine.speak("Voix équipée. Je suis ${session.mascot.name}.", vs)
                            }
                        }
                        XpShop.Item.Kind.BOOST -> {}
                    }
                    refreshHeader()
                    return@setItems
                }
                val err = XpShop.buy(this, mid, item)
                if (err != null) {
                    Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                    return@setItems
                }
                // appliquer
                when (item.kind) {
                    XpShop.Item.Kind.SKIN -> {
                        XpShop.skinIdFromItem(item.id)?.let { skin ->
                            mascotStore.setSkin(mid, skin)
                            session = buildSession()
                            reloadOverlay()
                        }
                    }
                    XpShop.Item.Kind.VOICE_PROFILE -> {
                        XpShop.voiceSettingsFor(item.id, session.mascot.voice.languageTag)?.let { vs ->
                            mascotStore.setVoice(mid, vs)
                            session = buildSession()
                            if (speakEnabled) voiceEngine.speak("Merci ! Nouvelle voix.", vs)
                        }
                    }
                    XpShop.Item.Kind.TITLE, XpShop.Item.Kind.AURA -> reloadOverlay()
                    XpShop.Item.Kind.BOOST -> {
                        refreshHeader()
                        append("Système", "Bonbon : +15 XP boutique !")
                    }
                }
                val costNote = if (item.cost > 0) " (−${item.cost} XP)" else " (cadeau)"
                session.journal.add("boutique", "Achat ${item.label}$costNote")
                setEmotion(GrowthSystem.Emotion.PROUD)
                refreshHeader()
                refreshWidget()
                append("Système", "Acheté : ${item.label} (−${item.cost} XP)")
                Toast.makeText(this, "Acheté !", Toast.LENGTH_SHORT).show()
            }
            .setMessage(
                "Les XP de boutique viennent de tes actions (enseigner, corriger, importer…).\n" +
                "Tu n'achètes pas l'intelligence — seulement looks, titres, auras, voix."
            )
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun showAIStudio() {
        val list = aiStudio.all()
        val labels = if (list.isEmpty()) arrayOf("➕ Créer une nouvelle IA", "📥 Importer une IA") else list.map { "🧠 ${it.name} · ${it.stage}" }.toTypedArray() + arrayOf("➕ Créer une nouvelle IA", "📥 Importer une IA")
        AlertDialog.Builder(this)
            .setTitle("AI Studio — créer et élever une IA")
            .setItems(labels) { _, which ->
                when { which == labels.lastIndex -> importUserAI(); which == labels.lastIndex - 1 -> createUserAI(); else -> manageUserAI(list[which]) }
            }
            .setNeutralButton("À propos") { _, _ ->
                AlertDialog.Builder(this).setTitle("Architecture AI Studio").setMessage(
                    "Une IA créée ici possède son identité, ses règles, son éducation, ses souvenirs, ses compétences et ses modèles.\n\n" +
                    "Les API sont optionnelles. Pour une image ou vidéo, l'IA peut utiliser un moteur local, un modèle créé par l'utilisateur, ou une API qu'il connecte.\n\n" +
                    "Le niveau 3 prépare et pilote un vrai projet d'entraînement; VanelleLife n'affiche jamais un faux pourcentage. L'entraînement lourd peut être exécuté sur le PC/serveur GPU personnel de l'utilisateur."
                ).setPositiveButton("OK", null).show()
            }.show()
    }

    private fun createUserAI() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 8, 32, 4) }
        val name = EditText(this).apply { hint = "Nom de l'IA" }
        val desc = EditText(this).apply { hint = "Ce qu'elle doit devenir"; minLines = 2 }
        val type = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Conversation", "Génération d'images", "Génération vidéo", "Multimodale")) }
        box.addView(name); box.addView(desc); box.addView(type)
        AlertDialog.Builder(this).setTitle("Naissance d'une IA").setView(box)
            .setMessage("Elle commence sans personnalité apprise. Tu l'éduques ensuite avec des leçons, corrections, règles et compétences.")
            .setPositiveButton("Créer") { _, _ ->
                val kind = when (type.selectedItemPosition) { 1 -> "image"; 2 -> "video"; else -> "chat" }
                val p = aiStudio.create(name.text.toString(), kind)
                p.description = desc.text.toString().trim().ifBlank { "IA créée par son utilisateur" }
                aiStudio.save(p)
                append("AI Studio", "${p.name} est née. Elle commence sans connaissances personnelles : à toi de l'élever.")
                manageUserAI(p)
            }.setNegativeButton("Annuler", null).show()
    }

    private fun manageUserAI(p0: AIStudioStore.AIProfile) {
        val p = aiStudio.get(p0.id) ?: p0
        val actions = arrayOf("📚 Éduquer l'IA", "🛠️ Compétences", "🔌 Connecter une API", "🧪 Tester une génération", "🏗️ Laboratoire niveau 3", "📦 Exporter cette IA", "ℹ️ État et ressources")
        AlertDialog.Builder(this).setTitle("${p.name} — Studio").setItems(actions) { _, which ->
            when (which) {
                0 -> teachUserAI(p)
                1 -> skillsUserAI(p)
                2 -> connectProvider(p)
                3 -> testProvider(p)
                4 -> modelLabDialog(p)
                5 -> exportUserAI(p)
                6 -> aiStatus(p)
            }
        }.setNegativeButton("Fermer", null).show()
    }

    private fun teachUserAI(p: AIStudioStore.AIProfile) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(32,8,32,4)}
        val topic=EditText(this).apply{hint="Sujet / règle"}; val content=EditText(this).apply{hint="Ce que tu lui enseignes";minLines=3}
        box.addView(topic);box.addView(content)
        AlertDialog.Builder(this).setTitle("Éduquer ${p.name}").setView(box).setMessage("Chaque leçon est conservée localement dans son dossier d'éducation.")
            .setPositiveButton("Apprendre") { _, _ ->
                val c=content.text.toString().trim(); if(c.isNotEmpty()){aiStudio.teach(p.id,topic.text.toString().trim().ifBlank{"règle"},c);p.stage="apprentissage";aiStudio.save(p);append("AI Studio","${p.name} a appris : ${c.take(120)}");refreshHeader()}
            }.setNegativeButton("Annuler",null).show()
    }

    private fun skillsUserAI(p: AIStudioStore.AIProfile) {
        val current=aiStudio.skills(p.id).joinToString("\n"){ "• ${it.name} [${it.kind}]" }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(32,8,32,4)}
        val name=EditText(this).apply{hint="Nom de la compétence"};val kind=EditText(this).apply{hint="Type : image / video / audio / chat / outil"};val d=EditText(this).apply{hint="Description"}
        box.addView(TextView(this).apply{text="Compétences actuelles:\n${current.ifBlank{"Aucune"})"}});box.addView(name);box.addView(kind);box.addView(d)
        AlertDialog.Builder(this).setTitle("Compétences de ${p.name}").setView(box).setPositiveButton("Ajouter") { _, _ -> if(name.text.isNotBlank()){aiStudio.addSkill(AIStudioStore.Skill(java.util.UUID.randomUUID().toString(),p.id,name.text.toString().trim(),d.text.toString().trim(),kind.text.toString().trim().ifBlank{"outil"},true));append("AI Studio","Compétence ajoutée à ${p.name}.")}}.setNegativeButton("Fermer",null).show()
    }

    private fun connectProvider(p: AIStudioStore.AIProfile) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(32,8,32,4)}
        val type=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Image","Vidéo","Voix","Conversation"))}
        val endpoint=EditText(this).apply{hint="Endpoint HTTPS POST"};val key=EditText(this).apply{hint="Clé API (stockée chiffrée)";inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD}
        box.addView(type);box.addView(endpoint);box.addView(key)
        AlertDialog.Builder(this).setTitle("Connecter un moteur externe").setView(box).setMessage("L'API est optionnelle. La clé est protégée par Android Keystore et n'est pas enregistrée en clair.")
            .setPositiveButton("Enregistrer") { _, _ ->
                val ep=endpoint.text.toString().trim();if(!ep.startsWith("https://")){Toast.makeText(this,"Endpoint HTTPS requis",Toast.LENGTH_LONG).show();return@setPositiveButton}
                val kind=type.selectedItem.toString().lowercase();when(kind){"image"->p.imageBackend=ep;"vidéo"->p.videoBackend=ep;"voix"->p.voiceBackend=ep;else->p.chatBackend=ep};aiStudio.save(p);secretVault.put("${p.id}:$kind",key.text.toString());append("AI Studio","Moteur $kind connecté à ${p.name}. La clé est protégée localement.")
            }.setNegativeButton("Annuler",null).show()
    }

    private fun testProvider(p: AIStudioStore.AIProfile) {
        val options=arrayOf("Image","Vidéo","Conversation","Voix")
        AlertDialog.Builder(this).setTitle("Tester une capacité").setItems(options){_,w->
            val kind=options[w].lowercase();val ep=when(w){0->p.imageBackend;1->p.videoBackend;2->p.chatBackend;else->p.voiceBackend};val key=secretVault.get("${p.id}:$kind")
            if(ep.isBlank()||ep=="none"){Toast.makeText(this,"Aucun moteur $kind connecté. Tu peux utiliser le laboratoire local ou en créer un.",Toast.LENGTH_LONG).show();return@setItems}
            val prompt=EditText(this).apply{hint="Prompt de test"};AlertDialog.Builder(this).setTitle("Test $kind").setView(prompt).setPositiveButton("Envoyer") { _, _ ->
                Thread { val r=AIProviderClient.postJson(ep,AIProviderClient.generationRequest(prompt.text.toString(),kind),key);runOnUiThread{append("AI Studio",if(r.ok)"Réponse réelle reçue ($r.code): ${r.body.take(800)}" else "Échec réel ($r.code): ${r.body.take(500)}")}}.start()
            }.setNegativeButton("Annuler",null).show()
        }.show()
    }

    private fun modelLabDialog(p: AIStudioStore.AIProfile) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,4,28,4)}
        val modality=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("image","video"))}
        val arch=EditText(this).apply{hint="Architecture (ex: diffusion-transformer)"};val res=EditText(this).apply{hint="Résolution (ex: 256x256)"};val fps=EditText(this).apply{hint="FPS";setText("8");inputType=2};val epochs=EditText(this).apply{hint="Epochs";setText("1");inputType=2};val batch=EditText(this).apply{hint="Batch size";setText("1");inputType=2}
        box.addView(modality);box.addView(arch);box.addView(res);box.addView(fps);box.addView(epochs);box.addView(batch)
        AlertDialog.Builder(this).setTitle("Laboratoire niveau 3 — ${p.name}").setView(box).setMessage("Ici tu définis un modèle depuis zéro. VanelleLife prépare le projet; le calcul lourd doit être exécuté sur une machine GPU compatible. Aucun entraînement n'est simulé.")
            .setPositiveButton("Créer le projet") { _, _ ->
                val m=modality.selectedItem.toString();val pr=modelLab.createProject(p.id,m,arch.text.toString().ifBlank{"transformer-diffusion"},res.text.toString().ifBlank{"256x256"},fps.text.toString().toIntOrNull()?:8,epochs.text.toString().toIntOrNull()?:1,batch.text.toString().toIntOrNull()?:1,null);append("AI Studio","Projet ${pr.modality} créé. ${modelLab.capabilityMessage(pr)}");chooseDatasetForProject(pr.id)
            }.setNeutralButton("Ressources appareil") { _, _ -> val h=modelLab.hardware();AlertDialog.Builder(this).setTitle("Ressources réelles").setMessage("RAM totale : ${h.ramMb} Mo\nRAM disponible : ${h.freeMb} Mo\nCPU : ${h.cpuCores} cœurs\nABI : ${h.abi}").setPositiveButton("OK",null).show()}.setNegativeButton("Annuler",null).show()
    }

    private fun chooseDatasetForProject(projectId:String) {
        pendingDatasetProjectId=projectId
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("image/*","video/*","audio/*","text/plain","text/csv","application/json","application/octet-stream"))}
        startActivityForResult(intent,REQ_DATASET)
    }

    private fun handleDatasetResult(data:Intent) {
        val projectId=pendingDatasetProjectId
        if(projectId.isBlank()) return
        val uris=mutableListOf<Uri>();data.data?.let{uris+=it};data.clipData?.let{clip->for(i in 0 until clip.itemCount)uris+=clip.getItemAt(i).uri}
        if(uris.isEmpty()) return
        uris.distinct().forEach{uri->runCatching{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}}
        Thread {
            try {
                val path=DatasetManager(this).importDataset(projectId,uris){}
                var owner:AIStudioStore.ModelProject?=null
                for(profile in aiStudio.all()){owner=aiStudio.projects(profile.id).firstOrNull{it.id==projectId};if(owner!=null)break}
                if(owner!=null){owner.datasetUri=path;owner.outputUri=filesDir.resolve("checkpoints/$projectId").absolutePath;aiStudio.saveProject(owner)}
                runOnUiThread{append("AI Studio","Dataset importé et copié dans le stockage privé. Manifest: $path")}
            }catch(e:Exception){runOnUiThread{Toast.makeText(this,"Dataset refusé : ${e.message ?: e.javaClass.simpleName}",Toast.LENGTH_LONG).show()}}
        }.start()
    }

    private fun exportUserAI(p: AIStudioStore.AIProfile) {
        val pass=EditText(this).apply{hint="Mot de passe d'export (8 caractères minimum)";inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD}
        AlertDialog.Builder(this).setTitle("Protéger l'export de ${p.name}").setMessage("L'identité, l'éducation, les compétences et les configurations sont exportées. Les clés API sont placées dans une enveloppe chiffrée avec ce mot de passe.").setView(pass)
            .setPositiveButton("Continuer") { _, _ ->
                if(pass.text.length<8){Toast.makeText(this,"Mot de passe trop court",Toast.LENGTH_LONG).show();return@setPositiveButton}
                pendingExportKind="ai_${p.id}";pendingAccountPassword=pass.text.toString()
                val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_TITLE,"${p.name.replace(" ","_")}_AI.vanai.json")}
                startActivityForResult(intent,REQ_AI_EXPORT)
            }.setNegativeButton("Annuler",null).show()
    }

    private fun buildSecureAIExport(aiId:String,password:String):String {
        val root=org.json.JSONObject(aiStudio.exportJson(aiId))
        val secrets=org.json.JSONObject()
        listOf("image","video","voix","conversation").forEach { kind -> secretVault.get("$aiId:$kind")?.let { secrets.put(kind,AIExportCrypto.encrypt(it,password)) } }
        root.put("encryptedApiSecrets",secrets)
        return root.toString(2)
    }

    private fun importUserAI() {
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"}
        startActivityForResult(intent,REQ_AI_IMPORT)
    }

    private fun aiStatus(p: AIStudioStore.AIProfile) {
        val h=modelLab.hardware();val lessons=aiStudio.lessons(p.id).size;val skills=aiStudio.skills(p.id).size;val projects=aiStudio.projects(p.id).size
        AlertDialog.Builder(this).setTitle("État de ${p.name}").setMessage("Stade : ${p.stage}\nLeçons : $lessons\nCompétences : $skills\nProjets modèles : $projects\n\nRessources de cet appareil : ${h.ramMb} Mo RAM, ${h.cpuCores} cœurs CPU.").setPositiveButton("OK",null).show()
    }


    /** Télécharge automatiquement tous les modèles à URL (une seule barre de progression). */
    private fun startModelBootstrap() {
        val row = findViewById<android.view.View?>(R.id.bootstrap_row) ?: return
        val line = findViewById<TextView>(R.id.bootstrap_line)
        val bar = findViewById<ProgressBar>(R.id.bootstrap_bar)
        if (ModelBootstrap.isDone(this)) {
            row.visibility = android.view.View.GONE
            return
        }
        row.visibility = android.view.View.VISIBLE
        line.text = "Préparation des modèles…"
        bar.progress = 0
        executor.execute {
            val err = ModelBootstrap.run(this) { text, pct ->
                main.post {
                    line.text = text
                    bar.progress = pct
                }
            }
            main.post {
                if (err == null) {
                    line.text = "Modèles prêts"
                    bar.progress = 100
                    row.postDelayed({ row.visibility = android.view.View.GONE }, 2500)
                    append("Système", "Modèles locaux prêts (embeddings + LLM si téléchargés).")
                } else {
                    line.text = "Téléchargement partiel — réessai au prochain lancement"
                    append("Système", "Téléchargement modèles :\n$err")
                }
            }
        }
    }

    private fun showInfo() {
        val consent = ConsentStore(this)
        val llmStatus = try {
            LlmRouter(rules = RuleBasedLlm { session.brain }).statusLine(this)
        } catch (_: Exception) {
            "LLM : moteur de règles local"
        }
        val msg = """Mascotte élevée par toi, 100% local.

• Stades : Œuf → Bébé → Curieuse → Sage → Complice
• Enseigner / Corriger / Consolider
• Bulle partout + micro
• Carnet de croissance + Partager
• Voix téléchargeables (appui long 🔊)
• Widget écran d'accueil

$llmStatus
Version 1.0.0-production
Rapport plantage : ${if (consent.crashReportingOptIn()) "activé" else "désactivé"}"""
        AlertDialog.Builder(this)
            .setTitle("VanelleLife")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .setNegativeButton("Plus…") { _, _ -> showInfoMore() }
            .setNeutralButton("Déconnexion") { _, _ ->
                accountStore.logout()
                recreate()
            }
            .show()
    }

    private fun showInfoMore() {
        val items = arrayOf(
            "Politique de confidentialité",
            "Conditions d'utilisation",
            "Provider IA (chat / image)",
            "Hub modèles (téléchargement léger)",
            "Prompt système de la mascotte",
            "Générer une image",
            "Rapport de plantage (opt-in)",
            "Configurer Sentry DSN",
            "État LLM on-device",
            "Retélécharger les modèles"
        )
        AlertDialog.Builder(this)
            .setTitle("Paramètres & légal")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, LegalActivity::class.java).putExtra(LegalActivity.EXTRA_DOC, LegalActivity.DOC_PRIVACY))
                    1 -> startActivity(Intent(this, LegalActivity::class.java).putExtra(LegalActivity.EXTRA_DOC, LegalActivity.DOC_TERMS))
                    2 -> showChatProviderSettings()
                    3 -> startActivity(Intent(this, ModelHubActivity::class.java))
                    4 -> showSystemPromptEditor()
                    5 -> showImageGenDialog()
                    6 -> showCrashOptIn()
                    7 -> showSentryDsnDialog()
                    8 -> showLlmStatus()
                    9 -> {
                        ModelBootstrap.reset(this)
                        startModelBootstrap()
                    }
                }
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun showConsentGate() {
        AlertDialog.Builder(this)
            .setTitle(R.string.consent_title)
            .setMessage(R.string.consent_message)
            .setCancelable(false)
            .setPositiveButton(R.string.consent_accept) { _, _ ->
                val store = ConsentStore(this)
                store.acceptPrivacyAndTerms()
                AppDatabase.get(this).recordConsentEvent("privacy_terms", "accepted")
                if (!accountStore.isLoggedIn()) showAuthGate() else openMainUi()
            }
            .setNeutralButton(R.string.consent_read_privacy) { _, _ ->
                startActivity(Intent(this, LegalActivity::class.java).putExtra(LegalActivity.EXTRA_DOC, LegalActivity.DOC_PRIVACY))
                showConsentGate()
            }
            .setNegativeButton(R.string.consent_read_terms) { _, _ ->
                startActivity(Intent(this, LegalActivity::class.java).putExtra(LegalActivity.EXTRA_DOC, LegalActivity.DOC_TERMS))
                showConsentGate()
            }
            .show()
    }

    private fun showCrashOptIn() {
        val store = ConsentStore(this)
        AlertDialog.Builder(this)
            .setTitle(R.string.crash_opt_in_title)
            .setMessage(R.string.crash_opt_in_message)
            .setPositiveButton("Activer") { _, _ ->
                store.setCrashReporting(true)
                AppDatabase.get(this).recordConsentEvent("crash_reporting", "on")
                SentryBridge.initIfAllowed(this)
                android.widget.Toast.makeText(this, "Rapport de plantage activé", android.widget.Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Désactiver") { _, _ ->
                store.setCrashReporting(false)
                AppDatabase.get(this).recordConsentEvent("crash_reporting", "off")
            }
            .show()
    }



    private fun showSystemPromptEditor() {
        val current = session.mascot.systemPrompt
        val field = EditText(this).apply {
            hint = "Ex: Tu tutoies toujours. Tu es curieuse et concise. Tu n'inventes pas de faits."
            setText(current)
            minLines = 4
            setSelection(text.length)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
            addView(TextView(this@MainActivity).apply {
                text = "Ce texte est injecté réellement dans le chat (provider, LLM local et moteur de règles)."
                setPadding(0, 0, 0, 16)
            })
            addView(field)
        }
        AlertDialog.Builder(this)
            .setTitle("Prompt système — ${session.mascot.name}")
            .setView(box)
            .setPositiveButton("Enregistrer") { _, _ ->
                mascotStore.setSystemPrompt(session.mascot.id, field.text.toString())
                session = buildSession()
                Toast.makeText(this, "Prompt système actif", Toast.LENGTH_SHORT).show()
                append("Système", "Prompt mis à jour pour ${session.mascot.name}.")
            }
            .setNeutralButton("Effacer") { _, _ ->
                mascotStore.setSystemPrompt(session.mascot.id, "")
                session = buildSession()
                Toast.makeText(this, "Prompt système effacé", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showImageGenDialog() {
        val field = EditText(this).apply {
            hint = "Décris l'image (prompt)"
            minLines = 3
        }
        AlertDialog.Builder(this)
            .setTitle("Générer une image")
            .setMessage(
                "Priorité : 1) modèle on-device MediaPipe  2) provider HTTPS image  3) AI Studio.\n" +
                "Hub modèles → instructions pour installer les bins on-device."
            )
            .setView(field)
            .setPositiveButton("Générer") { _, _ ->
                val prompt = field.text.toString().trim()
                if (prompt.isEmpty()) {
                    Toast.makeText(this, "Prompt vide", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                append(session.mascot.name, "Je lance la génération d'image…")
                executor.execute {
                    val sys = ChatEngine.buildSystemPrompt(session)
                    val result = ImageGenService.generate(this@MainActivity, prompt, sys)
                    main.post {
                        if (result.ok && result.file != null) {
                            append("Image", "OK (${result.source}) → ${result.file.name}")
                            // Affiche un aperçu simple
                            try {
                                val bmp = android.graphics.BitmapFactory.decodeFile(result.file.absolutePath)
                                val iv = ImageView(this).apply {
                                    setImageBitmap(bmp)
                                    adjustViewBounds = true
                                    maxHeight = 900
                                }
                                AlertDialog.Builder(this)
                                    .setTitle("Image générée")
                                    .setView(iv)
                                    .setPositiveButton("OK", null)
                                    .show()
                            } catch (_: Exception) {
                                Toast.makeText(this, "Fichier: ${result.file.absolutePath}", Toast.LENGTH_LONG).show()
                            }
                        } else {
                            append("Image", result.message)
                            AlertDialog.Builder(this)
                                .setTitle("Génération image")
                                .setMessage(result.message)
                                .setPositiveButton("OK", null)
                                .show()
                        }
                    }
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showSentryDsnDialog() {
        val field = EditText(this).apply {
            hint = "https://...@o....ingest.sentry.io/..."
            setText(SentryBridge.getDsn(this@MainActivity))
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle("Sentry DSN (optionnel)")
            .setMessage("Uniquement utilisé si le rapport de plantage est activé. Laisse vide pour rester 100 % local.")
            .setView(field)
            .setPositiveButton("Enregistrer") { _, _ ->
                SentryBridge.setDsn(this, field.text.toString())
                SentryBridge.initIfAllowed(this)
                Toast.makeText(this, "DSN enregistré", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showLlmStatus() {
        val router = LlmRouter(rules = RuleBasedLlm { session.brain })
        AlertDialog.Builder(this)
            .setTitle("LLM on-device")
            .setMessage(router.detailedStatus(this) + "\n\nOuvre Hub modèles pour télécharger les ressources IA locales de Vanelle (~550 Mo) ou les embeddings (~24 Mo).")
            .setPositiveButton("Hub modèles") { _, _ ->
                startActivity(Intent(this, ModelHubActivity::class.java))
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    /**
     * Configuration d'un provider de chat externe réel (endpoint HTTPS + clé API).
     * Tant qu'aucun provider n'est configuré ici, ChatEngine utilise uniquement le moteur
     * de règles local (LocalBrain) — c'est le comportement d'origine, inchangé par défaut.
     */
    private fun showChatProviderSettings() {
        val registry = com.nova.ai.platform.ProviderRegistry(this)
        val existing = registry.all().firstOrNull { it.capabilities.any { c -> c == "chat" || c == "text" || c.equals("image", true) } }

        val nameField = EditText(this).apply {
            hint = "Nom (ex: mon serveur IA)"
            setText(existing?.name ?: "")
        }
        val endpointField = EditText(this).apply {
            hint = "https://... (endpoint HTTPS obligatoire)"
            setText(existing?.endpoint ?: "")
        }
        val keyField = EditText(this).apply {
            hint = "Clé API (laisser vide pour ne pas changer)"
            transformationMethod = android.text.method.PasswordTransformationMethod.getInstance()
        }
        val templateField = EditText(this).apply {
            hint = "Corps de requête JSON (doit contenir un champ \"prompt\")"
            setText(existing?.requestTemplate ?: "{\"prompt\":\"\"}")
        }
        val responsePathField = EditText(this).apply {
            hint = "Chemin de la réponse dans le JSON (ex: choices.0.text)"
            setText(existing?.responsePath ?: "text")
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
            addView(nameField); addView(endpointField); addView(keyField)
            addView(templateField); addView(responsePathField)
        }

        val builder = AlertDialog.Builder(this)
            .setTitle("Provider IA externe")
            .setMessage("HTTPS uniquement. Variables injectées: prompt, system, system_prompt, context. Coche image dans le template si besoin (capacité image incluse).")
            .setView(layout)
            .setPositiveButton("Enregistrer") { _, _ ->
                val endpoint = endpointField.text.toString().trim()
                if (!endpoint.startsWith("https://")) {
                    Toast.makeText(this, "L'endpoint doit être en HTTPS.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val spec = com.nova.ai.platform.ProviderSpec(
                    id = existing?.id ?: java.util.UUID.randomUUID().toString(),
                    name = nameField.text.toString().trim().ifBlank { "Provider IA" },
                    endpoint = endpoint,
                    authType = "bearer",
                    capabilities = setOf("chat", "text", "image"),
                    requestTemplate = templateField.text.toString().trim().ifBlank { """{"prompt":"","system":""}""" },
                    responsePath = responsePathField.text.toString().trim(),
                    enabled = true
                )
                registry.save(spec)
                val key = keyField.text.toString()
                if (key.isNotBlank()) secretVault.put(spec.id, key)
                Toast.makeText(this, "Provider enregistré.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Annuler", null)
        if (existing != null) {
            builder.setNeutralButton("Désactiver") { _, _ -> registry.save(existing.copy(enabled = false)) }
        }
        builder.show()
    }

    private fun refreshWidget() {
        try {
            val mgr = AppWidgetManager.getInstance(this)
            val ids = mgr.getAppWidgetIds(ComponentName(this, MascotWidget::class.java))
            if (ids.isNotEmpty()) {
                val intent = Intent(this, MascotWidget::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                sendBroadcast(intent)
            }
        } catch (_: Exception) {}
    }

    private fun append(who: String, text: String) {
        chat.append("\n$who : $text\n")
    }

    override fun onDestroy() {
        executor.shutdownNow()
        voiceEngine.stop()
        voiceEngine.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val REQ_SPEECH = 1001
        private const val REQ_EXPORT = 1002
        private const val REQ_IMPORT = 1003
        private const val REQ_PERM = 1005
        private const val REQ_TTS_CHECK = 1006
        private const val REQ_IMPORT_ACCOUNT = 1007
        private const val REQ_AI_EXPORT = 1008
        private const val REQ_AI_IMPORT = 1009
        private const val REQ_DATASET = 1010
    }
}
