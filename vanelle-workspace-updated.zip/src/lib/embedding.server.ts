import type { AI, VFile } from "./types";

type EmbeddingRow = { index: number; embedding: number[] };
type EmbeddingResponse = { data?: EmbeddingRow[]; model?: string };

let cachedModel: string | null | undefined;

async function getEmbeddingModel(apiKey: string): Promise<string | null> {
  if (cachedModel !== undefined) return cachedModel;
  const configured = process.env.XAI_EMBEDDING_MODEL?.trim();
  if (configured) {
    cachedModel = configured;
    return configured;
  }
  try {
    const res = await fetch("https://api.x.ai/v1/embedding-models", {
      headers: { Authorization: `Bearer ${apiKey}` },
    });
    if (!res.ok) {
      cachedModel = null;
      return null;
    }
    const body = (await res.json()) as { models?: Array<{ id?: string }> };
    const first = body.models?.find((m) => m.id?.trim())?.id?.trim();
    cachedModel = first || null;
    return cachedModel;
  } catch {
    cachedModel = null;
    return null;
  }
}

async function embed(inputs: string[], apiKey: string): Promise<number[][] | null> {
  if (!inputs.length) return [];
  const model = await getEmbeddingModel(apiKey);
  if (!model) return null;
  try {
    const res = await fetch("https://api.x.ai/v1/embeddings", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        input: inputs,
        encoding_format: "float",
      }),
    });
    if (!res.ok) return null;
    const body = (await res.json()) as EmbeddingResponse;
    if (!Array.isArray(body.data) || body.data.length !== inputs.length) return null;
    return body.data
      .sort((a, b) => a.index - b.index)
      .map((row) => row.embedding)
      .filter((v) => Array.isArray(v) && v.length > 0);
  } catch {
    return null;
  }
}

function cosine(a: number[], b: number[]) {
  if (a.length !== b.length || !a.length) return -1;
  let dot = 0, aa = 0, bb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    aa += a[i] * a[i];
    bb += b[i] * b[i];
  }
  const denom = Math.sqrt(aa) * Math.sqrt(bb);
  return denom ? dot / denom : -1;
}

export async function retrieveRelevantFiles(
  ai: AI,
  query: string,
  limit = 5,
): Promise<VFile[] | null> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey || !query.trim() || !ai.files.length) return null;
  const passages = ai.files.map((f) => `passage: ${f.name}\n${f.note.slice(0, 8000)}`);
  const vectors = await embed([`query: ${query}`, ...passages], apiKey);
  if (!vectors || vectors.length !== passages.length + 1) return null;
  const q = vectors[0];
  return ai.files
    .map((file, i) => ({ file, score: cosine(q, vectors[i + 1]) }))
    .sort((a, b) => b.score - a.score)
    .slice(0, Math.max(1, limit))
    .map(({ file }) => file);
}
