import { buildSystemPrompt, listApisForTools } from "./prompt";
import { retrieveRelevantFiles } from "./embedding.server";
import { executeProxy, summarizeApiData, type ProxyAuth, type ProxyRequest } from "./proxy.server";
import type { ChatEvent } from "./chat-events";
import type { AI, HttpMethod, Message, UserApi } from "./types";

const MODEL = process.env.XAI_MODEL?.trim() || "grok-4.5";
const SAFE_METHODS = new Set<string>(["GET", "HEAD", "OPTIONS"]);

export type ChatPayload = {
  ai: AI;
  messages: Message[];
  secrets: Record<string, string>;
  confirmed?: {
    apiId: string;
    method?: string;
    query?: Record<string, string>;
    body?: unknown;
  };
};

export type { ChatEvent };

type GrokMsg = {
  role: "system" | "user" | "assistant" | "tool";
  content?: string | null;
  tool_calls?: Array<{
    id: string;
    type: "function";
    function: { name: string; arguments: string };
  }>;
  tool_call_id?: string;
};

function grokTools(ai: AI) {
  const available = listApisForTools(ai);
  if (!available.length) return undefined;
  return [
    {
      type: "function" as const,
      function: {
        name: "vanelle_call_api",
        description:
          "Appelle une API configurée de cette IA. Utilise uniquement un apiId de la liste. Ne fabrique jamais de secret. GET/HEAD/OPTIONS s'exécutent directement. POST/PUT/PATCH/DELETE exigent userConfirmed=true après accord explicite de l'utilisateur.",
        parameters: {
          type: "object",
          properties: {
            apiId: {
              type: "string",
              description: `Un de : ${available.map((a) => `${a.id} (${a.name})`).join(", ")}`,
            },
            method: {
              type: "string",
              enum: ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"],
            },
            query: { type: "object", additionalProperties: { type: "string" } },
            body: {},
            userConfirmed: { type: "boolean" },
          },
          required: ["apiId"],
        },
      },
    },
  ];
}

function resolveAuth(api: UserApi, secrets: Record<string, string>): ProxyAuth {
  const secret = api.secretRef ? secrets[api.secretRef] : undefined;
  if (api.authType === "apiKey" && secret) {
    return { type: "apiKey", key: secret, header: api.authHeader || "X-API-Key" };
  }
  if (api.authType === "bearer" && secret) {
    return { type: "bearer", token: secret };
  }
  if (api.authType === "basic") {
    return { type: "basic", username: api.username || "", password: secret || "" };
  }
  return { type: "none" };
}

async function runApi(
  ai: AI,
  secrets: Record<string, string>,
  args: {
    apiId: string;
    method?: string;
    query?: Record<string, string>;
    body?: unknown;
    userConfirmed?: boolean;
  },
): Promise<{ kind: "ok" | "confirm" | "error"; text: string; extra?: ChatEvent }> {
  const api = ai.apis.find((x) => x.id === args.apiId);
  if (!api) return { kind: "error", text: "API demandée introuvable dans cette IA." };
  const method = (args.method || api.method || "GET").toUpperCase() as HttpMethod;
  if (!SAFE_METHODS.has(method) && !args.userConfirmed) {
    return {
      kind: "confirm",
      text: `CONFIRMATION_REQUISE: l'appel ${method} vers « ${api.name} » peut modifier des données. Demande confirmation à l'utilisateur avant de l'exécuter.`,
      extra: {
        type: "confirm",
        apiId: api.id,
        apiName: api.name,
        method,
        query: args.query,
        body: args.body,
      },
    };
  }
  try {
    const req: ProxyRequest = {
      endpoint: api.endpoint,
      method,
      headers: api.requestHeaders,
      query: { ...(api.queryParams ?? {}), ...(args.query ?? {}) },
      body: args.body ?? (api.body ? safeJson(api.body) : undefined),
      auth: resolveAuth(api, secrets),
      timeoutMs: api.timeoutMs || 15000,
      retries: api.retries ?? 2,
      retryNonIdempotent: api.retryNonIdempotent,
    };
    const result = await executeProxy(req);
    const preview = summarizeApiData(result.data);
    return {
      kind: "ok",
      text: `API_RESULT\nHTTP ${result.status} ${result.statusText}\n${preview}`,
    };
  } catch (e) {
    return {
      kind: "error",
      text: `API_ERROR: ${e instanceof Error ? e.message : "échec"}`,
    };
  }
}

function safeJson(raw: string): unknown {
  try {
    return JSON.parse(raw);
  } catch {
    return raw;
  }
}

async function grokComplete(messages: GrokMsg[], tools: ReturnType<typeof grokTools>, ai: AI) {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) throw new Error("AI_UNAVAILABLE");
  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: MODEL,
      messages,
      tools,
      temperature: Math.min(1.4, Math.max(0, ai.temperature ?? 0.4)),
      max_tokens: Math.min(2000, Math.max(128, ai.maxTokens ?? 700)),
    }),
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`xAI API error ${res.status}${t ? `: ${t.slice(0, 200)}` : ""}`);
  }
  const body = (await res.json()) as {
    choices: Array<{
      message: {
        role: string;
        content?: string | null;
        tool_calls?: GrokMsg["tool_calls"];
      };
    }>;
  };
  return body.choices[0]?.message;
}

export async function runChat(
  payload: ChatPayload,
  emit: (e: ChatEvent) => void,
): Promise<void> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) {
    emit({
      type: "error",
      message: "Le moteur IA n'est pas disponible dans cet environnement.",
    });
    emit({ type: "done" });
    return;
  }

  const { ai, secrets } = payload;
  // Semantic retrieval is optional: if the configured embedding service is
  // unavailable, the prompt builder safely falls back to the existing files.
  const lastUserMessage = [...payload.messages].reverse().find((m) => m.role === "user")?.text ?? "";
  const relevantFiles = ai.files.length
    ? await retrieveRelevantFiles(ai, lastUserMessage, 5)
    : null;
  const system = buildSystemPrompt(ai, relevantFiles ?? undefined);
  const tools = grokTools(ai);

  const history: GrokMsg[] = [
    { role: "system", content: system },
    ...payload.messages
      .filter((m) => m.role === "user" || m.role === "assistant")
      .slice(-24)
      .map((m) => ({ role: m.role, content: m.text })),
  ];

  if (payload.confirmed) {
    const result = await runApi(ai, secrets, { ...payload.confirmed, userConfirmed: true });
    emit({
      type: "tool",
      name: payload.confirmed.apiId,
      ok: result.kind === "ok",
      preview: result.text.slice(0, 400),
    });
    history.push({
      role: "user",
      content: `L'utilisateur a confirmé l'appel API. Résultat réel :\n${result.text}\n\nRéponds maintenant à l'utilisateur sans inventer de données.`,
    });
  }

  try {
    for (let round = 0; round < 3; round++) {
      const msg = await grokComplete(history, tools, ai);
      if (!msg) throw new Error("Réponse vide du moteur IA.");

      const calls = msg.tool_calls ?? [];
      if (!calls.length) {
        const text = (msg.content || "").trim() || "Réponse vide.";
        emit({ type: "delta", text });
        emit({ type: "done" });
        return;
      }

      history.push({
        role: "assistant",
        content: msg.content ?? "",
        tool_calls: calls,
      });

      for (const call of calls) {
        let args: {
          apiId: string;
          method?: string;
          query?: Record<string, string>;
          body?: unknown;
          userConfirmed?: boolean;
        };
        try {
          args = JSON.parse(call.function.arguments || "{}");
        } catch {
          args = { apiId: "" };
        }
        const result = await runApi(ai, secrets, args);
        if (result.extra) emit(result.extra);
        const apiName = ai.apis.find((a) => a.id === args.apiId)?.name || args.apiId;
        emit({
          type: "tool",
          name: apiName,
          ok: result.kind === "ok",
          preview: result.text.slice(0, 400),
        });
        history.push({
          role: "tool",
          tool_call_id: call.id,
          content: result.text,
        });
      }
    }
    emit({
      type: "delta",
      text: "L'appel d'outils a atteint sa limite. Reformulez votre demande.",
    });
    emit({ type: "done" });
  } catch (e) {
    const reason = e instanceof Error ? e.message : "Échec du moteur IA.";
    const friendly = /timeout|timed out|deadline/i.test(reason)
      ? "Le modèle met plus de temps que prévu. Réessayez — ce n'est pas une coupure."
      : reason === "AI_UNAVAILABLE"
        ? "Le moteur IA n'est pas disponible dans cet environnement."
        : reason;
    emit({ type: "error", message: friendly });
    emit({ type: "done" });
  }
}

export function isAiAvailable() {
  return Boolean(process.env.XAI_API_KEY);
}
