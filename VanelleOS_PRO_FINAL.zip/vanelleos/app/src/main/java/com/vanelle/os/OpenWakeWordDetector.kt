package com.vanelle.os

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.nio.channels.FileChannel
import kotlinx.coroutines.*

/**
 * Pipeline openWakeWord optimisé (melspectrogram → embedding → classifieur "Cassandra").
 * - Audio 16 kHz / mono / 16-bit
 * - Fenêtres 80 ms, fenêtre glissante 16 embeddings
 * - Seuil 0.28 + cooldown anti-double détection
 * - Score lissé (moyenne mobile) pour plus de robustesse
 */
class OpenWakeWordDetector(private val context: Context) {
    companion object {
        private const val TAG = "OpenWakeWord"
        private const val SAMPLE_RATE = 16000
        private const val CHUNK_SAMPLES = 1280 // 80 ms
        private const val EMBED_WINDOW = 16
        private const val THRESHOLD = 0.28f
        private const val COOLDOWN_MS = 2200L
        private const val ENERGY_FLOOR = 80.0
    }

    private var melInterp: Interpreter? = null
    private var embInterp: Interpreter? = null
    private var clsInterp: Interpreter? = null
    private val embedBuffer = ArrayDeque<FloatArray>()
    private var record: AudioRecord? = null
    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    @Volatile private var lastDetectAt = 0L
    private val recentScores = ArrayDeque<Float>()

    private fun loadModel(file: File): Interpreter? {
        return try {
            val fis = FileInputStream(file)
            val channel = fis.channel
            val buffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
            val interp = Interpreter(buffer)
            try {
                interp.allocateTensors()
            } catch (_: Exception) { /* certains modèles n'en ont pas besoin */ }
            interp
        } catch (e: Exception) {
            Log.e(TAG, "loadModel ${file.name}: ${e.message}")
            null
        }
    }

    /**
     * melspectrogram.tflite a une forme d'entrée dynamique : TensorFlow Lite sur Android
     * ne la résout pas tout seul. Sans resize explicite, l'inférence échoue silencieusement.
     * Cf. openWakeWord GitHub issue #223.
     */
    private fun loadMelModel(file: File): Interpreter? {
        return try {
            val fis = FileInputStream(file)
            val channel = fis.channel
            val buffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
            val interp = Interpreter(buffer)
            try {
                interp.resizeInput(0, intArrayOf(1, CHUNK_SAMPLES))
                interp.allocateTensors()
            } catch (e: Exception) {
                Log.e(TAG, "resizeInput mel failed: ${e.message}")
                interp.close()
                return null
            }
            interp
        } catch (e: Exception) {
            Log.e(TAG, "loadMelModel: ${e.message}")
            null
        }
    }

    private fun loadAssetModel(name: String): Interpreter? {
        return try {
            val afd = context.assets.openFd(name)
            val fis = FileInputStream(afd.fileDescriptor)
            val buffer = fis.channel.map(
                FileChannel.MapMode.READ_ONLY,
                afd.startOffset,
                afd.declaredLength
            )
            val interp = Interpreter(buffer)
            try { interp.allocateTensors() } catch (_: Exception) {}
            interp
        } catch (e: Exception) {
            Log.e(TAG, "loadAssetModel $name: ${e.message}")
            null
        }
    }

    fun prepare(): Boolean {
        if (!WakeWordModelManager.isReady(context)) {
            Log.w(TAG, "prepare: models not ready")
            return false
        }
        if (melInterp == null) melInterp = loadMelModel(WakeWordModelManager.melFile(context))
        if (embInterp == null) embInterp = loadModel(WakeWordModelManager.embFile(context))
        if (clsInterp == null) clsInterp = loadAssetModel("wakeword_classifier.tflite")
        val ok = melInterp != null && embInterp != null && clsInterp != null
        Log.i(TAG, "prepare -> $ok (mel=${melInterp != null} emb=${embInterp != null} cls=${clsInterp != null})")
        return ok
    }

    @Suppress("MissingPermission")
    fun start(onDetected: () -> Unit) {
        stop()
        if (melInterp == null && !prepare()) {
            Log.w(TAG, "start: prepare failed")
            return
        }
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) {
            Log.e(TAG, "getMinBufferSize failed: $minBuf")
            return
        }
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, CHUNK_SAMPLES * 4)
            )
        } catch (e: Exception) {
            Log.e(TAG, "AudioRecord create: ${e.message}")
            null
        } ?: return
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "AudioRecord not initialized")
            try { rec.release() } catch (_: Exception) {}
            return
        }
        record = rec
        try {
            rec.startRecording()
        } catch (e: Exception) {
            Log.e(TAG, "startRecording: ${e.message}")
            try { rec.release() } catch (_: Exception) {}
            record = null
            return
        }
        embedBuffer.clear()
        recentScores.clear()
        Log.i(TAG, "listening started")
        job = scope.launch {
            val buf = ShortArray(CHUNK_SAMPLES)
            while (isActive) {
                val n = try {
                    rec.read(buf, 0, CHUNK_SAMPLES)
                } catch (_: Exception) {
                    -1
                }
                if (n <= 0) {
                    delay(15)
                    continue
                }
                // Ignore near-silence (réduit faux positifs)
                var energy = 0.0
                for (i in 0 until n) energy += kotlin.math.abs(buf[i].toInt())
                if (energy / n < ENERGY_FLOOR) continue
                try {
                    val mel = runMel(buf)
                    val emb = runEmbedding(mel) ?: continue
                    embedBuffer.addLast(emb)
                    while (embedBuffer.size > EMBED_WINDOW) embedBuffer.removeFirst()
                    if (embedBuffer.size == EMBED_WINDOW) {
                        val score = runClassifier(embedBuffer.toList())
                        recentScores.addLast(score)
                        while (recentScores.size > 3) recentScores.removeFirst()
                        val smoothed = recentScores.average().toFloat()
                        val now = System.currentTimeMillis()
                        if (smoothed > THRESHOLD && now - lastDetectAt > COOLDOWN_MS) {
                            lastDetectAt = now
                            Log.i(TAG, "WAKE DETECTED score=$smoothed")
                            embedBuffer.clear()
                            recentScores.clear()
                            withContext(Dispatchers.Main) { onDetected() }
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "inference: ${e.message}")
                }
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        try { record?.stop() } catch (_: Exception) {}
        try { record?.release() } catch (_: Exception) {}
        record = null
        embedBuffer.clear()
        recentScores.clear()
    }

    private fun runMel(pcm: ShortArray): FloatArray {
        val input = Array(1) { FloatArray(pcm.size) { i -> pcm[i] / 32768f } }
        val outShape = melInterp!!.getOutputTensor(0).shape()
        val outSize = outShape.fold(1) { a, b -> a * b }
        val output = Array(1) { FloatArray(outSize) }
        melInterp!!.run(input, output)
        return output[0]
    }

    private fun runEmbedding(melFrame: FloatArray): FloatArray? {
        return try {
            val input = arrayOf(melFrame)
            val outShape = embInterp!!.getOutputTensor(0).shape()
            val outSize = outShape.fold(1) { a, b -> a * b }
            val output = Array(1) { FloatArray(outSize) }
            embInterp!!.run(input, output)
            output[0]
        } catch (_: Exception) {
            null
        }
    }

    private fun runClassifier(embeddings: List<FloatArray>): Float {
        return try {
            val input = Array(1) { Array(embeddings.size) { i -> embeddings[i] } }
            val output = Array(1) { FloatArray(1) }
            clsInterp!!.run(input, output)
            output[0][0]
        } catch (_: Exception) {
            0f
        }
    }
}
