package com.vanelle.os
import android.content.Context

object MascotManager {
    /** id -> label affiché */
    val mascots = listOf(
        "kawaii" to "Kawaii",
        "ice" to "Glace",
        "pastel" to "Pastel",
        "crystal" to "Cristal",
        "coral" to "Corail",
        "galaxy" to "Galaxie",
        "lava" to "Lave",
        "rose" to "Rose Gold",
        "mint" to "Menthe",
        "carbon" to "Carbone",
        "gold" to "Or",
        "bronze" to "Bronze",
        "aurora" to "Aurore",
        "obsidian" to "Obsidienne"
    )

    private fun prefs(c: Context) = c.getSharedPreferences("vanelle_prefs", 0)

    fun getSelected(c: Context): String =
        prefs(c).getString("mascot", "galaxy") ?: "galaxy"

    fun setSelected(c: Context, id: String) {
        if (mascots.any { it.first == id }) {
            prefs(c).edit().putString("mascot", id).apply()
        }
    }

    fun getDrawableId(c: Context, id: String): Int =
        c.resources.getIdentifier("mascot_$id", "drawable", c.packageName)

    /** Nom personnalisé donné par l'utilisateur (ex: "Luna", "Buddy"). Vide = utilise le label par défaut. */
    fun getCustomName(c: Context): String =
        prefs(c).getString("mascot_custom_name", "") ?: ""

    fun setCustomName(c: Context, name: String) {
        prefs(c).edit().putString("mascot_custom_name", name.trim()).apply()
    }

    /** Nom affiché / dit à voix haute : nom custom si défini, sinon label du style. */
    fun getDisplayName(c: Context): String {
        val custom = getCustomName(c)
        if (custom.isNotBlank()) return custom
        val id = getSelected(c)
        return mascots.find { it.first == id }?.second ?: "Vanelle"
    }

    /**
     * Vérifie si le texte reconnu contient le nom de la mascotte
     * (nom custom OU label du style, tolérant aux accents / casse).
     */
    fun isMascotNameSpoken(c: Context, spoken: String): Boolean {
        val lower = spoken.lowercase().trim()
        if (lower.isBlank()) return false
        val names = mutableListOf<String>()
        val custom = getCustomName(c).lowercase()
        if (custom.isNotBlank()) names.add(custom)
        val id = getSelected(c)
        mascots.find { it.first == id }?.second?.lowercase()?.let { names.add(it) }
        // Aussi accepter "mascotte" et "vanelle" comme appel générique
        names.addAll(listOf("mascotte", "vanelle"))
        return names.any { n ->
            n.isNotBlank() && (lower.contains(n) || FuzzyMatch.close(lower, n, 2) ||
                lower.split(Regex("\\s+")).any { w -> w == n || FuzzyMatch.close(w, n, 2) })
        }
    }
}
