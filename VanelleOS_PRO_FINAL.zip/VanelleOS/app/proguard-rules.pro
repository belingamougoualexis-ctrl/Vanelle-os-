# VanelleOS – règles ProGuard production

# ── App ──────────────────────────────────────────────────────────────────
-keep class com.vanelle.os.** { *; }
-keepclassmembers class com.vanelle.os.** { *; }
-keepclassmembers class com.vanelle.os.** {
    public <init>(...);
    *;
}

# Data classes / sérialisation
-keepclassmembers class com.vanelle.os.** {
    <fields>;
}
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# Enums (CommandIntent, etc.)
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
    **[] $VALUES;
    public *;
}

# ── TensorFlow Lite ──────────────────────────────────────────────────────
-keep class org.tensorflow.** { *; }
-keep class org.tensorflow.lite.** { *; }
-keep class org.tensorflow.lite.Interpreter { *; }
-keep class org.tensorflow.lite.Interpreter$* { *; }
-dontwarn org.tensorflow.**
-dontwarn org.tensorflow.lite.**

# ── Llama.cpp Kotlin / JNI ───────────────────────────────────────────────
-keep class org.nehuatl.** { *; }
-keep class org.nehuatl.llamacpp.** { *; }
-keep class io.github.ljcamargo.** { *; }
-keep class com.ljcamargo.** { *; }
-keepclassmembers class org.nehuatl.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
-keepclassmembers class * {
    native <methods>;
}
-dontwarn org.nehuatl.**
-dontwarn io.github.ljcamargo.**

# ── EncryptedSharedPreferences / Security Crypto ─────────────────────────
-keep class androidx.security.crypto.** { *; }
-keep class com.google.crypto.tink.** { *; }
-dontwarn androidx.security.crypto.**
-dontwarn com.google.crypto.tink.**

# ── Kotlin / Coroutines ──────────────────────────────────────────────────
-keepnames class kotlinx.coroutines.** { *; }
-dontwarn kotlinx.coroutines.**
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}

# ── JSON ─────────────────────────────────────────────────────────────────
-keep class org.json.** { *; }

# ── AndroidX ─────────────────────────────────────────────────────────────
-keep class androidx.** { *; }
-dontwarn androidx.**

# ── Attributes ───────────────────────────────────────────────────────────
-keepattributes Signature, InnerClasses, EnclosingMethod, *Annotation*, Exception, SourceFile, LineNumberTable
-renamesourcefileattribute SourceFile
