package com.vanelle.os

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.*
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

/**
 * Service d'écoute du mot d'activation "Cassandra".
 *
 * Vrai Foreground Service type microphone :
 *  - permission FOREGROUND_SERVICE + FOREGROUND_SERVICE_MICROPHONE dans le manifest
 *  - android:foregroundServiceType="microphone"
 *  - startForeground(..., FOREGROUND_SERVICE_TYPE_MICROPHONE) + notification persistante
 *
 * UNIQUEMENT openWakeWord (AudioRecord silencieux) — aucun SpeechRecognizer
 * en boucle en arrière-plan (pas de bip permanent).
 * SpeechRecognizer n'est lancé qu'UNE fois après détection du wake word,
 * pour capturer la commande.
 */
class WakeWordService : Service() {
    companion object {
        private const val TAG = "WakeWordService"
        private const val CHANNEL_ID = "vanelle_wake"
        private const val NOTIF_ID = 1001
    }

    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val detector by lazy { OpenWakeWordDetector(this) }

    @Volatile
    private var isServiceDestroyed = false

    @Volatile
    private var capturingCommand = false

    @Volatile
    private var foregroundStarted = false

    private val wakeVariants = listOf(
        "cassandra", "cassandre", "casandra", "cassandras", "kasandra", "cass", "sandra"
    )

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isServiceDestroyed = false
        Log.i(TAG, "onCreate")
        try {
            promoteToForeground("Écoute active — dis Cassandra")
            tts = TextToSpeech(this) { status ->
                if (status == TextToSpeech.SUCCESS) tts?.language = Locale.FRANCE
            }
            scope.launch {
                withContext(Dispatchers.IO) {
                    WakeWordModelManager.downloadIfNeeded(this@WakeWordService)
                }
                if (isServiceDestroyed) return@launch
                startOpenWakeWordListening()
            }
        } catch (e: Exception) {
            Log.e(TAG, "onCreate failed: ${e.message}", e)
            stopSelf()
        }
    }

    /**
     * Passe le service en premier plan avec le type microphone (Android 10+).
     * Obligatoire après startForegroundService(), sinon l'OS tue le service.
     */
    private fun promoteToForeground(text: String) {
        createWakeChannel()
        val notif = buildWakeNotification(text)
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(
                    NOTIF_ID,
                    notif,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIF_ID, notif)
            }
            foregroundStarted = true
            Log.i(TAG, "startForeground OK (microphone)")
        } catch (e: Exception) {
            // Repli sans type si le device refuse (rare) — mieux que de crasher
            Log.e(TAG, "startForeground typed failed: ${e.message}")
            try {
                startForeground(NOTIF_ID, notif)
                foregroundStarted = true
            } catch (e2: Exception) {
                Log.e(TAG, "startForeground fallback failed: ${e2.message}")
                throw e2
            }
        }
    }

    private fun createWakeChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java) ?: return
        val existing = nm.getNotificationChannel(CHANNEL_ID)
        if (existing != null) return
        val ch = NotificationChannel(
            CHANNEL_ID,
            "Écoute VanelleOS",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Notification persistante pendant l'écoute du mot Cassandra"
            setShowBadge(false)
            enableVibration(false)
            setSound(null, null)
        }
        nm.createNotificationChannel(ch)
    }

    private fun buildWakeNotification(text: String): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VanelleOS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openApp)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    /** Démarre uniquement openWakeWord. Si modèles absents → retry, jamais SpeechRecognizer en boucle. */
    private fun startOpenWakeWordListening() {
        if (isServiceDestroyed || capturingCommand) return
        scope.launch(Dispatchers.IO) {
            val ready = try {
                WakeWordModelManager.isReady(this@WakeWordService) && detector.prepareSuspend()
            } catch (e: Exception) {
                Log.e(TAG, "prepareSuspend failed: ${e.message}")
                false
            }
            if (isServiceDestroyed || capturingCommand) return@launch
            if (ready) {
                try {
                    Log.i(TAG, "starting openWakeWord detector")
                    withContext(Dispatchers.Main) {
                        if (!isServiceDestroyed && !capturingCommand) {
                            detector.start { onWakeDetected() }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "detector.start failed: ${e.message}")
                    scheduleModelRetry()
                }
            } else {
                Log.w(TAG, "models not ready, scheduling retry")
                scheduleModelRetry()
            }
        }
    }

    private fun scheduleModelRetry() {
        scope.launch {
            delay(4000)
            if (isServiceDestroyed) return@launch
            withContext(Dispatchers.IO) {
                WakeWordModelManager.downloadIfNeeded(this@WakeWordService)
            }
            if (!isServiceDestroyed) startOpenWakeWordListening()
        }
    }

    /**
     * Après détection silencieuse du wake word :
     * arrête AudioRecord, lance UN SpeechRecognizer pour la commande uniquement.
     */
    private fun onWakeDetected() {
        if (isServiceDestroyed || capturingCommand) return
        Log.i(TAG, "wake word detected — launching SpeechRecognizer")
        capturingCommand = true
        detector.stop()

        // Filet de sécurité : si SpeechRecognizer ne callback jamais, on reprend l'écoute
        scope.launch {
            delay(8000)
            if (capturingCommand && !isServiceDestroyed) {
                Log.w(TAG, "SpeechRecognizer timeout — resume listening")
                capturingCommand = false
                try { rec?.cancel() } catch (_: Exception) {}
                try { rec?.destroy() } catch (_: Exception) {}
                rec = null
                resumeOpenWakeWord()
            }
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            capturingCommand = false
            resumeOpenWakeWord()
            return
        }
        try {
            rec?.destroy()
            rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onResults(r: Bundle?) {
                        if (isServiceDestroyed) return
                        val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull() ?: ""
                        Log.i(TAG, "command result: \"$t\"")
                        if (t.isNotBlank()) handleCommand(t)
                        capturingCommand = false
                        resumeOpenWakeWord()
                    }

                    override fun onError(e: Int) {
                        Log.w(TAG, "SpeechRecognizer error=$e")
                        capturingCommand = false
                        if (!isServiceDestroyed) resumeOpenWakeWord()
                    }

                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                    override fun onPartialResults(p: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    // Évite un timeout trop court sur certains appareils
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200)
                }
                try {
                    startListening(intent)
                } catch (_: Exception) {
                    capturingCommand = false
                    resumeOpenWakeWord()
                }
            }
        } catch (_: Exception) {
            capturingCommand = false
            resumeOpenWakeWord()
        }
    }

    private fun resumeOpenWakeWord() {
        if (isServiceDestroyed) return
        capturingCommand = false
        scope.launch {
            delay(400)
            if (!isServiceDestroyed) startOpenWakeWordListening()
        }
    }

    private fun findWakeIndex(text: String): Int {
        val lower = text.lowercase()
        val regex = Regex("[a-zàâäéèêëîïôöùûüç]+")
        for (m in regex.findAll(lower)) {
            val w = m.value
            if (w in wakeVariants ||
                FuzzyMatch.close(w, "cassandra", 2) ||
                FuzzyMatch.close(w, "cassandre", 2)
            ) return m.range.first
        }
        return -1
    }

    private fun wakeWordEnd(text: String, startIdx: Int): Int {
        val lower = text.lowercase()
        val regex = Regex("[a-zàâäéèêëîïôöùûüç]+")
        val m = regex.find(lower, startIdx) ?: return startIdx
        return m.range.last + 1
    }

    private fun handleCommand(text: String) {
        if (isServiceDestroyed || text.isBlank()) return
        if (TranslateModePrefs.isActive(this)) {
            handleTranslateMode(text)
            return
        }
        val idx = findWakeIndex(text)
        val original = if (idx >= 0) {
            val endIdx = wakeWordEnd(text, idx)
            text.substring(endIdx.coerceAtMost(text.length)).trim().ifEmpty { text.trim() }
        } else text.trim()
        dispatchCommand(original, original.lowercase())
    }

    private fun dispatchCommand(originalCmd: String, cmd: String) {
        if (isServiceDestroyed) return
        val parsed = CommandParser.parse(originalCmd)
        if (parsed.intent == CommandIntent.CALL_CONTACT ||
            parsed.intent == CommandIntent.SEND_MESSAGE
        ) {
            try {
                val i = Intent(this@WakeWordService, MainActivity::class.java).apply {
                    putExtra(
                        "confirm_type",
                        if (parsed.intent == CommandIntent.CALL_CONTACT) "call" else "sms"
                    )
                    putExtra("confirm_name", parsed.args["name"] ?: "")
                    putExtra("confirm_message", parsed.args["message"] ?: "")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(i)
            } catch (_: Exception) {
            }
            return
        }
        scope.launch {
            if (isServiceDestroyed) return@launch
            try {
                val i = Intent(this@WakeWordService, MainActivity::class.java).apply {
                    putExtra("pending_command", originalCmd.ifBlank { cmd })
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(i)
            } catch (_: Exception) {
            }
        }
    }

    private fun handleTranslateMode(text: String) {
        if (isServiceDestroyed) return
        val lower = text.lowercase()
        val parsed = CommandParser.parse(text)
        if (parsed.intent == CommandIntent.TRANSLATE_MODE_OFF ||
            lower.contains("quitte mode") ||
            lower.contains("stop traduction") ||
            lower.contains("arrête traduction") ||
            lower.contains("arrete traduction")
        ) {
            TranslateModePrefs.stop(this)
            try {
                tts?.language = Locale.FRANCE
                tts?.speak("Mode traduction désactivé", TextToSpeech.QUEUE_FLUSH, null, "tr_off")
            } catch (_: Exception) {
            }
            return
        }
        val src = TranslateModePrefs.source(this)
        val tgt = TranslateModePrefs.target(this)
        scope.launch {
            if (isServiceDestroyed) return@launch
            val translated = withContext(Dispatchers.IO) {
                TranslateHelper(this@WakeWordService).translateText(text, src, tgt)
            }
            if (isServiceDestroyed) return@launch
            try {
                val tag = when (tgt) {
                    "zh-CN" -> "zh"
                    "auto" -> "fr"
                    else -> tgt
                }
                tts?.language = Locale.forLanguageTag(tag)
            } catch (_: Exception) {
                try { tts?.language = Locale.FRANCE } catch (_: Exception) {}
            }
            try {
                if (translated.isNotBlank() &&
                    !translated.startsWith("Traduction indisponible")
                ) {
                    tts?.speak(translated, TextToSpeech.QUEUE_FLUSH, null, "tr_out")
                } else {
                    tts?.language = Locale.FRANCE
                    tts?.speak(
                        "Traduction indisponible, vérifie ta connexion",
                        TextToSpeech.QUEUE_FLUSH, null, "tr_err"
                    )
                }
            } catch (_: Exception) {
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Garantit le passage en foreground même si onCreate a déjà tourné
        // (re-démarrage OS / startForegroundService répété).
        if (!foregroundStarted) {
            try {
                promoteToForeground("Écoute active — dis Cassandra")
            } catch (e: Exception) {
                Log.e(TAG, "onStartCommand promote failed: ${e.message}")
            }
        }
        if (!isServiceDestroyed && !capturingCommand) {
            startOpenWakeWordListening()
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Libère micro + TFLite si l'utilisateur swipe l'app (évite fuite)
        try { detector.releaseModels() } catch (_: Exception) {}
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        isServiceDestroyed = true
        capturingCommand = false
        foregroundStarted = false
        try { rec?.destroy() } catch (_: Exception) {}
        try { detector.releaseModels() } catch (_: Exception) { try { detector.stop() } catch (_: Exception) {} }
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        try {
            if (Build.VERSION.SDK_INT >= 24) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        } catch (_: Exception) {}
        scope.cancel()
        super.onDestroy()
    }
}
