package com.vanelle.os

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat

/**
 * Urgence : ouvre le composeur 112.
 * ACTION_DIAL ne nécessite pas CALL_PHONE ; on vérifie quand même avant tout appel direct.
 * Toujours applicationContext pour éviter les fuites Activity.
 */
class EmergencyManager(context: Context) {
    private val app = context.applicationContext

    fun sos(): String {
        // Composeur (pas d'appel auto) — pas de CALL_PHONE requis
        return try {
            val dial = Intent(Intent.ACTION_DIAL, Uri.parse("tel:112")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(dial)
            "Numéro d'urgence 112 ouvert. Compose pour appeler les secours."
        } catch (e: SecurityException) {
            "Accès téléphone refusé. Compose manuellement le 112."
        } catch (_: Exception) {
            // Tentative d'appel direct uniquement si CALL_PHONE accordé
            if (ContextCompat.checkSelfPermission(app, Manifest.permission.CALL_PHONE)
                == PackageManager.PERMISSION_GRANTED
            ) {
                try {
                    val call = Intent(Intent.ACTION_CALL, Uri.parse("tel:112")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    app.startActivity(call)
                    return "Appel d'urgence 112 lancé."
                } catch (_: SecurityException) {
                    return "Permission d'appel refusée. Compose manuellement le 112."
                } catch (_: Exception) {}
            }
            "Je n'ai pas pu ouvrir le numérateur d'urgence. Compose manuellement le 112 ou le 15 / 18 / 17 selon le besoin."
        }
    }
}
