package com.vanelle.os

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Demandes système réelles et fonctionnelles :
 *  - Exclusion de l'optimisation batterie (évite l'arrêt de l'écoute en arrière-plan)
 *  - Activation / « redémarrage » du service d'accessibilité (toggle via réglages système)
 *
 * Android interdit d'activer l'accessibilité ou d'ignorer la batterie sans action utilisateur :
 * on ouvre les bons écrans et on guide clairement.
 */
object SystemGuards {
    private const val TAG = "SystemGuards"

    // ── Battery optimization ──────────────────────────────────────────────

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.isIgnoringBatteryOptimizations(context.packageName)
        } catch (e: Exception) {
            Log.w(TAG, "isIgnoringBatteryOptimizations: ${e.message}")
            true // ne pas spammer si API indisponible
        }
    }

    /**
     * Demande d'exclusion batterie.
     * 1) Intent direct REQUEST_IGNORE_BATTERY_OPTIMIZATIONS (dialogue système)
     * 2) Repli : liste des apps / détails batterie
     */
    @SuppressLint("BatteryLife")
    fun requestIgnoreBatteryOptimizations(activity: Activity) {
        if (isIgnoringBatteryOptimizations(activity)) return
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${activity.packageName}")
            }
            activity.startActivity(intent)
            return
        } catch (e: Exception) {
            Log.w(TAG, "REQUEST_IGNORE failed: ${e.message}")
        }
        openBatteryOptimizationSettings(activity)
    }

    fun openBatteryOptimizationSettings(context: Context) {
        val attempts = listOf(
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${context.packageName}")
            },
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
            }
        )
        for (i in attempts) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                return
            } catch (_: Exception) {}
        }
    }

    /**
     * Dialogue de démarrage : explique pourquoi + lance la demande système.
     * Affiché une seule fois tant que non accordé (ou jusqu'à « Plus tard » mémorisé).
     */
    fun maybePromptBatteryOptimization(activity: Activity) {
        if (isIgnoringBatteryOptimizations(activity)) return
        if (SetupPrefs.batteryPromptDismissed(activity)) return
        try {
            AlertDialog.Builder(activity)
                .setTitle("Autoriser l'exécution en arrière-plan")
                .setMessage(
                    "Android peut arrêter l'écoute « Cassandra » pour économiser la batterie.\n\n" +
                    "Choisis « Autoriser » / « Sans restriction » pour VanelleOS afin que le service d'écoute reste actif."
                )
                .setPositiveButton("Autoriser") { _, _ ->
                    requestIgnoreBatteryOptimizations(activity)
                }
                .setNegativeButton("Plus tard") { _, _ ->
                    SetupPrefs.setBatteryPromptDismissed(activity, true)
                }
                .setCancelable(true)
                .show()
        } catch (e: Exception) {
            Log.w(TAG, "maybePromptBatteryOptimization: ${e.message}")
        }
    }

    // ── Accessibility ─────────────────────────────────────────────────────

    fun accessibilityComponent(context: Context): String =
        "${context.packageName}/${VanelleAccessibilityService::class.java.canonicalName}"

    fun isAccessibilityEnabled(context: Context): Boolean {
        return try {
            val exp = accessibilityComponent(context)
            val en = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val split = TextUtils.SimpleStringSplitter(':')
            split.setString(en)
            while (split.hasNext()) {
                if (split.next().equals(exp, ignoreCase = true)) return true
            }
            false
        } catch (_: Exception) {
            false
        }
    }

    /** Ouvre les réglages d'accessibilité (activation du service). */
    fun openAccessibilitySettings(context: Context) {
        // Tentative d'ouvrir directement la fiche du service (certains OEM)
        try {
            val component = ComponentName(
                context.packageName,
                VanelleAccessibilityService::class.java.name
            )
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(":settings:fragment_args_key", component.flattenToString())
                val bundle = android.os.Bundle()
                bundle.putString(":settings:fragment_args_key", component.flattenToString())
                putExtra(":settings:show_fragment_args", bundle)
            }
            context.startActivity(intent)
            return
        } catch (_: Exception) {}
        try {
            context.startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Log.e(TAG, "openAccessibilitySettings: ${e.message}")
        }
    }

    /**
     * « Redémarrage » du service d'accessibilité.
     * Android n'autorise pas de le basculer par code : on ouvre les réglages
     * et on affiche la procédure (désactiver → réactiver VanelleOS).
     */
    fun promptRestartAccessibility(activity: Activity) {
        val enabled = isAccessibilityEnabled(activity)
        val msg = if (enabled) {
            "Pour redémarrer le service d'accessibilité VanelleOS :\n\n" +
            "1. Touche « Ouvrir les réglages »\n" +
            "2. Trouve VanelleOS dans la liste\n" +
            "3. Désactive-le, puis réactive-le\n\n" +
            "Cela recharge le service (lecture d'écran, gestes, retour/accueil)."
        } else {
            "Le service d'accessibilité VanelleOS est désactivé.\n\n" +
            "1. Touche « Ouvrir les réglages »\n" +
            "2. Active « VanelleOS »\n\n" +
            "Sans ça : retour, accueil, lecture d'écran et clics automatiques ne fonctionnent pas."
        }
        try {
            AlertDialog.Builder(activity)
                .setTitle(if (enabled) "Redémarrer l'accessibilité" else "Activer l'accessibilité")
                .setMessage(msg)
                .setPositiveButton("Ouvrir les réglages") { _, _ ->
                    openAccessibilitySettings(activity)
                }
                .setNegativeButton("Plus tard", null)
                .show()
        } catch (e: Exception) {
            Log.w(TAG, "promptRestartAccessibility: ${e.message}")
            openAccessibilitySettings(activity)
        }
    }

    fun maybePromptAccessibility(activity: Activity) {
        if (isAccessibilityEnabled(activity)) return
        if (SetupPrefs.accessibilityPromptDismissed(activity)) return
        try {
            AlertDialog.Builder(activity)
                .setTitle("Accessibilité requise")
                .setMessage(
                    "Active le service VanelleOS dans Accessibilité pour :\n" +
                    "• lire l'écran\n• cliquer / remplir des champs\n• retour, accueil, notifications, récents"
                )
                .setPositiveButton("Activer") { _, _ ->
                    openAccessibilitySettings(activity)
                }
                .setNegativeButton("Plus tard") { _, _ ->
                    SetupPrefs.setAccessibilityPromptDismissed(activity, true)
                }
                .show()
        } catch (e: Exception) {
            Log.w(TAG, "maybePromptAccessibility: ${e.message}")
        }
    }

    // ── Notifications (Android 13+) ───────────────────────────────────────

    fun areNotificationsEnabled(context: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 33) {
                ContextCompat.checkSelfPermission(
                    context, Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.areNotificationsEnabled()
            }
        } catch (_: Exception) {
            true
        }
    }

    /** Ouvre les réglages de notifications de l'app (repli si permission refusée définitivement). */
    fun openAppNotificationSettings(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(i)
                return
            }
        } catch (_: Exception) {}
        try {
            context.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        } catch (e: Exception) {
            Log.w(TAG, "openAppNotificationSettings: ${e.message}")
        }
    }

    /**
     * Demande POST_NOTIFICATIONS (API 33+) via le dialogue système.
     * Si refus permanent → ouvre les réglages notifications de l'app.
     * @return true si déjà accordée
     */
    fun requestNotificationPermission(activity: Activity, requestCode: Int = 4401): Boolean {
        if (areNotificationsEnabled(activity)) return true
        if (Build.VERSION.SDK_INT < 33) {
            openAppNotificationSettings(activity)
            return areNotificationsEnabled(activity)
        }
        val shouldRationale = ActivityCompat.shouldShowRequestPermissionRationale(
            activity, Manifest.permission.POST_NOTIFICATIONS
        )
        if (shouldRationale) {
            try {
                AlertDialog.Builder(activity)
                    .setTitle("Notifications requises")
                    .setMessage(
                        "Les notifications permettent d'afficher « Écoute active » " +
                        "et les rappels de relances. Sans elles, Android peut masquer le service d'écoute."
                    )
                    .setPositiveButton("Autoriser") { _, _ ->
                        ActivityCompat.requestPermissions(
                            activity,
                            arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                            requestCode
                        )
                    }
                    .setNegativeButton("Réglages") { _, _ ->
                        openAppNotificationSettings(activity)
                    }
                    .setNeutralButton("Plus tard", null)
                    .show()
            } catch (_: Exception) {
                ActivityCompat.requestPermissions(
                    activity,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    requestCode
                )
            }
        } else {
            // Première demande ou refus permanent : tenter le dialogue, sinon réglages
            try {
                ActivityCompat.requestPermissions(
                    activity,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    requestCode
                )
            } catch (e: Exception) {
                Log.w(TAG, "requestNotificationPermission: ${e.message}")
                openAppNotificationSettings(activity)
            }
        }
        return false
    }

    /**
     * Enchaîne les demandes après les permissions runtime :
     * accessibilité puis batterie (légèrement différé pour éviter de superposer les dialogues).
     */
    fun runStartupPrompts(activity: Activity) {
        // Notifications d'abord si manquantes (sinon FGS peut être silencieux)
        if (!areNotificationsEnabled(activity) && !SetupPrefs.notifPromptDismissed(activity)) {
            activity.window?.decorView?.postDelayed({
                if (activity.isFinishing) return@postDelayed
                try {
                    AlertDialog.Builder(activity)
                        .setTitle("Autoriser les notifications")
                        .setMessage(
                            "VanelleOS a besoin des notifications pour afficher " +
                            "« Écoute active — dis Cassandra » et les relances programmées."
                        )
                        .setPositiveButton("Autoriser") { _, _ ->
                            requestNotificationPermission(activity)
                        }
                        .setNegativeButton("Plus tard") { _, _ ->
                            SetupPrefs.setNotifPromptDismissed(activity, true)
                        }
                        .show()
                } catch (_: Exception) {
                    requestNotificationPermission(activity)
                }
            }, 300)
        }
        maybePromptAccessibility(activity)
        activity.window?.decorView?.postDelayed({
            if (!activity.isFinishing) maybePromptBatteryOptimization(activity)
        }, 900)
    }
}

object SetupPrefs {
    private fun p(c: Context) = SecurePrefs.get(c, "vanelle_prefs")

    fun batteryPromptDismissed(c: Context): Boolean =
        p(c).getBoolean("battery_opt_dismissed", false)

    fun setBatteryPromptDismissed(c: Context, v: Boolean) {
        p(c).edit().putBoolean("battery_opt_dismissed", v).apply()
    }

    fun accessibilityPromptDismissed(c: Context): Boolean =
        p(c).getBoolean("a11y_prompt_dismissed", false)

    fun setAccessibilityPromptDismissed(c: Context, v: Boolean) {
        p(c).edit().putBoolean("a11y_prompt_dismissed", v).apply()
    }

    fun notifPromptDismissed(c: Context): Boolean =
        p(c).getBoolean("notif_prompt_dismissed", false)

    fun setNotifPromptDismissed(c: Context, v: Boolean) {
        p(c).edit().putBoolean("notif_prompt_dismissed", v).apply()
    }
}
