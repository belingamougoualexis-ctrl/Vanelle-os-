package com.vanelle.os

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.util.Log

/**
 * Déchargement systématique de la mémoire native / TFLite sous pression
 * ou quand l'app passe en arrière-plan (hors service d'écoute actif).
 *
 * - Llama GGUF : gros footprint → unload dès TRIM_MEMORY_RUNNING_MODERATE
 * - TFLite wake word : libéré seulement si le service d'écoute n'est pas en cours
 *   (sinon l'écoute Cassandra s'arrêterait)
 */
object ModelMemoryManager : ComponentCallbacks2 {
    private const val TAG = "ModelMemory"

    @Volatile private var registered = false

    fun install(appContext: Context) {
        if (registered) return
        synchronized(this) {
            if (registered) return
            try {
                appContext.applicationContext.registerComponentCallbacks(this)
                registered = true
                Log.i(TAG, "installed")
            } catch (e: Exception) {
                Log.w(TAG, "install failed: ${e.message}")
            }
        }
    }

    /** Appelé depuis Activity.onStop / onTrimMemory. */
    fun onAppBackgrounded() {
        // Ne décharge que Llama (réutilisable au prochain warmUp).
        // Les modèles wake restent si le FGS micro tourne.
        try {
            LocalLlamaHelper.unloadIfPresent()
            Log.i(TAG, "Llama unloaded (background)")
        } catch (e: Exception) {
            Log.w(TAG, "onAppBackgrounded: ${e.message}")
        }
    }

    override fun onTrimMemory(level: Int) {
        when {
            level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE ||
                level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL -> {
                Log.w(TAG, "critical trim level=$level — unload all possible")
                try { LocalLlamaHelper.unloadIfPresent() } catch (_: Exception) {}
                System.gc()
            }
            level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE ||
                level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND -> {
                Log.i(TAG, "moderate trim level=$level — unload Llama")
                try { LocalLlamaHelper.unloadIfPresent() } catch (_: Exception) {}
            }
            else -> { /* UI hidden / UI_HIDDEN : laisser warm si possible */ }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {}

    override fun onLowMemory() {
        Log.w(TAG, "onLowMemory — unload Llama")
        try { LocalLlamaHelper.unloadIfPresent() } catch (_: Exception) {}
        System.gc()
    }
}
