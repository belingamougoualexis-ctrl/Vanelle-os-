package com.vanelle.os

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Fabrique de SharedPreferences chiffrées (AES-256 via Android Keystore).
 * Utilisée pour toute donnée utilisateur sensible stockée localement.
 *
 * Fallback non chiffré uniquement si le Keystore est indisponible (émulateurs rares).
 */
object SecurePrefs {
    private const val TAG = "SecurePrefs"

    @Volatile private var masterKey: MasterKey? = null

    private fun master(context: Context): MasterKey {
        masterKey?.let { return it }
        synchronized(this) {
            masterKey?.let { return it }
            val mk = MasterKey.Builder(context.applicationContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            masterKey = mk
            return mk
        }
    }

    /**
     * @param name nom du fichier de préférences (sans chemin)
     */
    fun get(context: Context, name: String): SharedPreferences {
        val app = context.applicationContext
        return try {
            EncryptedSharedPreferences.create(
                app,
                name,
                master(app),
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Log.w(TAG, "EncryptedSharedPreferences unavailable for $name: ${e.message}")
            app.getSharedPreferences(name + "_plain_fallback", Context.MODE_PRIVATE)
        }
    }
}
