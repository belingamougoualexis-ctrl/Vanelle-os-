package com.vanelle.os

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

/**
 * Téléchargement UNIQUEMENT des modèles d'écoute (openWakeWord).
 * Aucun téléchargement de modèle IA / GGUF.
 * Progression de 0 % → 100 % (mel puis embedding).
 */
class DataDownloadService : Service() {

    companion object {
        private const val TAG = "DataDownload"
        const val CHANNEL_ID = "vanelle_data_download"
        const val NOTIF_ID = 4201
        const val ACTION_PROGRESS = "com.vanelle.os.DATA_DOWNLOAD_PROGRESS"
        const val ACTION_DONE = "com.vanelle.os.DATA_DOWNLOAD_DONE"
        const val ACTION_WAITING = "com.vanelle.os.DATA_DOWNLOAD_WAITING"
        const val EXTRA_PERCENT = "percent"
        const val EXTRA_STATUS = "status"

        /** Conservé pour compat UI — la progression wake va de 0 à 100. */
        const val WAKE_PROGRESS_SHARE = 100

        @Volatile var isRunning = false
            private set

        /** Prêt = modèles d'écoute uniquement (pas d'IA). */
        fun allDataReady(c: Context): Boolean = WakeWordModelManager.isReady(c)

        fun start(c: Context) {
            if (allDataReady(c)) return
            val i = Intent(c, DataDownloadService::class.java)
            ContextCompat.startForegroundService(c, i)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var cancelled = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (allDataReady(this)) {
            stopSelfSafely()
            return START_NOT_STICKY
        }
        startAsForeground(0, "Téléchargement des modèles d'écoute…")
        isRunning = true
        cancelled = false
        registerNetworkWatcher()
        if (job?.isActive != true) {
            job = scope.launch { runDownloadLoop() }
        }
        return START_STICKY
    }

    private suspend fun runDownloadLoop() {
        while (!cancelled && !allDataReady(this)) {
            if (!isNetworkAvailable()) {
                broadcastWaiting("Connexion interrompue…")
                updateNotif(overallPercent(), "Connexion interrompue — reprise auto")
                delay(3000)
                continue
            }

            Log.i(TAG, "Downloading wake-word models only (no GGUF)…")
            broadcastProgress(0, "0 % — modèles d'écoute…")
            updateNotif(0, "0 % — modèles d'écoute…")

            val ok = try {
                WakeWordModelManager.downloadIfNeededWithProgress(this) { pct, status ->
                    val p = pct.coerceIn(0, 100)
                    updateNotif(p, status)
                    broadcastProgress(p, status)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Wake download error: ${e.message}")
                false
            }

            if (cancelled) {
                stopSelfSafely()
                return
            }

            if (ok && allDataReady(this)) {
                broadcastProgress(100, "Modèles d'écoute prêts")
                updateNotif(100, "Modèles d'écoute prêts")
                broadcastDone()
                delay(600)
                stopSelfSafely()
                return
            }

            broadcastWaiting("Nouvelle tentative…")
            updateNotif(overallPercent(), "Nouvelle tentative…")
            delay(4000)
        }

        if (allDataReady(this)) {
            broadcastProgress(100, "Modèles d'écoute prêts")
            updateNotif(100, "Modèles d'écoute prêts")
            broadcastDone()
            delay(400)
        }
        stopSelfSafely()
    }

    private fun overallPercent(): Int {
        if (allDataReady(this)) return 100
        // Sans progression fine en cours : 0 % jusqu'à ce que les deux fichiers soient là
        return 0
    }

    private fun isNetworkAvailable(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(n) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            false
        }
    }

    private fun registerNetworkWatcher() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            networkCallback?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (job?.isActive != true && !allDataReady(this@DataDownloadService)) {
                        job = scope.launch { runDownloadLoop() }
                    }
                }
                override fun onLost(network: Network) {
                    broadcastWaiting("Connexion interrompue — reprise auto")
                }
            }
            networkCallback = cb
            val req = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            cm.registerNetworkCallback(req, cb)
        } catch (_: Exception) {}
    }

    private fun broadcastProgress(pct: Int, status: String) {
        sendBroadcast(Intent(ACTION_PROGRESS).setPackage(packageName).apply {
            putExtra(EXTRA_PERCENT, pct)
            putExtra(EXTRA_STATUS, status)
        })
    }

    private fun broadcastWaiting(msg: String) {
        sendBroadcast(Intent(ACTION_WAITING).setPackage(packageName).apply {
            putExtra(EXTRA_STATUS, msg)
            putExtra(EXTRA_PERCENT, overallPercent())
        })
    }

    private fun broadcastDone() {
        sendBroadcast(Intent(ACTION_DONE).setPackage(packageName))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(
                CHANNEL_ID,
                "Modèles d'écoute",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Téléchargement des modèles d'écoute VanelleOS"
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun startAsForeground(pct: Int, text: String) {
        val notif = buildNotif(pct, text)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun updateNotif(pct: Int, text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotif(pct, text))
    }

    private fun buildNotif(pct: Int, text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VanelleOS · écoute")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct.coerceIn(0, 100), pct <= 0)
            .setContentIntent(open)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .build()
    }

    private fun stopSelfSafely() {
        isRunning = false
        cancelled = true
        try {
            networkCallback?.let {
                val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                cm.unregisterNetworkCallback(it)
            }
        } catch (_: Exception) {}
        networkCallback = null
        job?.cancel()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        cancelled = true
        isRunning = false
        try {
            networkCallback?.let {
                val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                cm.unregisterNetworkCallback(it)
            }
        } catch (_: Exception) {}
        networkCallback = null
        job?.cancel()
        scope.cancel()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        super.onDestroy()
    }
}
