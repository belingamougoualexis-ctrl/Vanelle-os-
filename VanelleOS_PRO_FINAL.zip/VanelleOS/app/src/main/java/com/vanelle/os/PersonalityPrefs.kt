package com.vanelle.os
import android.content.Context

object PersonalityPrefs {
    private fun p(c: Context) = SecurePrefs.get(c, "vanelle_prefs")

    /** calme | energique | coach | pote */
    fun getPersonality(c: Context) = p(c).getString("personality", "pote") ?: "pote"
    fun setPersonality(c: Context, id: String) {
        if (id in listOf("calme", "energique", "coach", "pote"))
            p(c).edit().putString("personality", id).apply()
    }

    fun personalityLabel(id: String) = when (id) {
        "calme" -> "Calme & posée"
        "energique" -> "Énergique"
        "coach" -> "Coach motivante"
        else -> "Pote bienveillante"
    }

    /** Ton unique, neutre — plus de personnalités multiples. */
    fun systemTone(c: Context): String =
        "Tu es Vanelle, assistante claire et naturelle. Réponds en français, de façon directe et utile."

    fun isGuestMode(c: Context) = p(c).getBoolean("guest_mode", false)
    fun setGuestMode(c: Context, on: Boolean) = p(c).edit().putBoolean("guest_mode", on).apply()

    fun preferOffline(c: Context) = p(c).getBoolean("prefer_offline", true)
    fun setPreferOffline(c: Context, on: Boolean) = p(c).edit().putBoolean("prefer_offline", on).apply()
}
