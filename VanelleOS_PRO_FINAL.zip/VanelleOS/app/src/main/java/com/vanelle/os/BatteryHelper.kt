package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
class BatteryHelper(context:Context){
    private val c = context.applicationContext
    fun level():Int{
        val bm=c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val l=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        if(l>0) return l
        val bi=c.registerReceiver(null,IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val raw=bi?.getIntExtra(BatteryManager.EXTRA_LEVEL,0) ?: 0
        val sc=bi?.getIntExtra(BatteryManager.EXTRA_SCALE,100) ?: 100
        return (raw*100)/sc
    }
}
