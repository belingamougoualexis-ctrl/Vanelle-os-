package com.vanelle.os

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ScheduledTask(
    val id: Long,
    val description: String,
    val hour: Int,
    val minute: Int,
    val repeatDaily: Boolean
)

data class RelanceHistoryEntry(
    val description: String,
    val executedAt: Long,
    val result: String
)

class RelanceRepository(c: Context) {
    private val p = SecurePrefs.get(c, "vanelle_relances")

    fun getTasks(): List<ScheduledTask> {
        val arr = JSONArray(p.getString("tasks", "[]") ?: "[]")
        val list = mutableListOf<ScheduledTask>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                ScheduledTask(
                    o.getLong("id"),
                    o.getString("desc"),
                    o.getInt("h"),
                    o.getInt("m"),
                    o.getBoolean("rep")
                )
            )
        }
        return list.sortedBy { it.hour * 60 + it.minute }
    }

    private fun saveTasks(list: List<ScheduledTask>) {
        val arr = JSONArray()
        for (t in list) {
            val o = JSONObject()
            o.put("id", t.id)
            o.put("desc", t.description)
            o.put("h", t.hour)
            o.put("m", t.minute)
            o.put("rep", t.repeatDaily)
            arr.put(o)
        }
        // commit() synchrone pour que la suppression soit visible immédiatement
        p.edit().putString("tasks", arr.toString()).commit()
    }

    fun addTask(description: String, hour: Int, minute: Int, repeatDaily: Boolean): ScheduledTask {
        val t = ScheduledTask(System.currentTimeMillis(), description, hour, minute, repeatDaily)
        val list = getTasks().toMutableList()
        list.add(t)
        saveTasks(list)
        return t
    }

    fun removeTask(id: Long) {
        saveTasks(getTasks().filter { it.id != id })
    }

    fun getTask(id: Long): ScheduledTask? = getTasks().firstOrNull { it.id == id }

    fun addHistory(description: String, executedAt: Long, result: String) {
        val arr = JSONArray(p.getString("history", "[]") ?: "[]")
        val o = JSONObject()
        o.put("desc", description)
        o.put("at", executedAt)
        o.put("res", result)
        arr.put(o)
        val trimmed = if (arr.length() > 100) {
            val na = JSONArray()
            for (i in arr.length() - 100 until arr.length()) na.put(arr.get(i))
            na
        } else arr
        p.edit().putString("history", trimmed.toString()).commit()
    }

    fun getHistory(): List<RelanceHistoryEntry> {
        val arr = JSONArray(p.getString("history", "[]") ?: "[]")
        val list = mutableListOf<RelanceHistoryEntry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                RelanceHistoryEntry(
                    o.getString("desc"),
                    o.getLong("at"),
                    o.optString("res", "")
                )
            )
        }
        return list.reversed()
    }
}
