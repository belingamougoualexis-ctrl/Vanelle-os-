package com.vanelle.os

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Journal d'erreurs réel de l'application.
 * Enregistre : horodatage, type, message, fichier:ligne:méthode (stack app),
 * cause racine, impact estimé, et stack trace complète.
 */
object ErrorJournal {
    private const val TAG = "ErrorJournal"
    private const val PREF = "vanelle_error_journal"
    private const val KEY = "entries"
    private const val MAX = 80
    private const val CRASH_FILE = "last_crash.txt"

    data class Entry(
        val id: Long,
        val timeMs: Long,
        val severity: String,   // FATAL / ERROR / WARN
        val message: String,
        val problem: String,    // description du problème
        val reason: String,     // raison (exception type + message)
        val location: String,   // Fichier.kt:ligne (méthode)
        val impact: String,     // ce que ça casse pour l'utilisateur
        val stack: String
    )

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                record(
                    app,
                    severity = "FATAL",
                    throwable = throwable,
                    problem = "Crash non géré sur le thread « ${thread.name} »",
                    impact = "L'application s'est arrêtée. Relance VanelleOS."
                )
                // Fichier legacy pour compat CrashLogger
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.FRANCE).format(Date())
                app.openFileOutput(CRASH_FILE, Context.MODE_PRIVATE).use {
                    it.write("$stamp\n\n$sw".toByteArray())
                }
            } catch (_: Exception) {}
            previous?.uncaughtException(thread, throwable)
        }
        Log.i(TAG, "installed")
    }

    /**
     * Enregistre une exception capturée (try/catch) avec contexte métier.
     */
    fun capture(
        context: Context,
        throwable: Throwable,
        problem: String,
        impact: String = "Fonctionnalité dégradée ou indisponible."
    ) {
        try {
            record(
                context.applicationContext,
                severity = "ERROR",
                throwable = throwable,
                problem = problem,
                impact = impact
            )
        } catch (_: Exception) {}
    }

    fun warn(context: Context, problem: String, reason: String, impact: String, location: String = "") {
        try {
            val app = context.applicationContext
            val entry = JSONObject()
                .put("id", System.currentTimeMillis())
                .put("time", System.currentTimeMillis())
                .put("severity", "WARN")
                .put("message", problem.take(200))
                .put("problem", problem.take(300))
                .put("reason", reason.take(300))
                .put("location", location.ifBlank { findCallerLocation() })
                .put("impact", impact.take(300))
                .put("stack", "")
            persist(app, entry)
        } catch (_: Exception) {}
    }

    private fun record(
        app: Context,
        severity: String,
        throwable: Throwable,
        problem: String,
        impact: String
    ) {
        val root = rootCause(throwable)
        val location = firstAppFrame(throwable)
        val reason = buildString {
            append(throwable.javaClass.simpleName)
            if (!throwable.message.isNullOrBlank()) append(": ").append(throwable.message)
            if (root != throwable) {
                append(" ← ")
                append(root.javaClass.simpleName)
                if (!root.message.isNullOrBlank()) append(": ").append(root.message)
            }
        }
        val sw = StringWriter()
        throwable.printStackTrace(PrintWriter(sw))
        val entry = JSONObject()
            .put("id", System.currentTimeMillis())
            .put("time", System.currentTimeMillis())
            .put("severity", severity)
            .put("message", (throwable.message ?: problem).take(200))
            .put("problem", problem.take(300))
            .put("reason", reason.take(400))
            .put("location", location)
            .put("impact", impact.take(300))
            .put("stack", sw.toString().take(6000))
        persist(app, entry)
        Log.e(TAG, "[$severity] $location | $problem | $reason")
    }

    private fun persist(app: Context, entry: JSONObject) {
        val p = SecurePrefs.get(app, PREF)
        val arr = JSONArray(p.getString(KEY, "[]"))
        arr.put(entry)
        val trimmed = JSONArray()
        val start = (arr.length() - MAX).coerceAtLeast(0)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        p.edit().putString(KEY, trimmed.toString()).apply()
    }

    fun all(context: Context): List<Entry> {
        return try {
            val arr = JSONArray(SecurePrefs.get(context, PREF).getString(KEY, "[]"))
            val out = ArrayList<Entry>(arr.length())
            for (i in arr.length() - 1 downTo 0) {
                val o = arr.getJSONObject(i)
                out.add(
                    Entry(
                        id = o.optLong("id"),
                        timeMs = o.optLong("time"),
                        severity = o.optString("severity", "ERROR"),
                        message = o.optString("message"),
                        problem = o.optString("problem"),
                        reason = o.optString("reason"),
                        location = o.optString("location"),
                        impact = o.optString("impact"),
                        stack = o.optString("stack")
                    )
                )
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun clear(context: Context) {
        try {
            SecurePrefs.get(context, PREF).edit().remove(KEY).apply()
            context.deleteFile(CRASH_FILE)
        } catch (_: Exception) {}
    }

    fun count(context: Context): Int = try {
        JSONArray(SecurePrefs.get(context, PREF).getString(KEY, "[]")).length()
    } catch (_: Exception) {
        0
    }

    private fun rootCause(t: Throwable): Throwable {
        var c = t
        var guard = 0
        while (c.cause != null && c.cause !== c && guard++ < 12) c = c.cause!!
        return c
    }

    /**
     * Première frame du package com.vanelle.os dans la stack
     * → Fichier.kt:ligne (méthode)
     */
    private fun firstAppFrame(t: Throwable): String {
        val frames = t.stackTrace
        for (f in frames) {
            val cn = f.className ?: continue
            if (!cn.startsWith("com.vanelle.os")) continue
            if (cn.contains("ErrorJournal")) continue
            val file = f.fileName ?: cn.substringAfterLast('.')
            val line = if (f.lineNumber > 0) f.lineNumber else 0
            val method = f.methodName ?: "?"
            return "$file:$line ($method)"
        }
        // Fallback : première frame utile
        val f = frames.firstOrNull() ?: return "inconnu"
        return "${f.fileName ?: "?"}:${f.lineNumber} (${f.methodName})"
    }

    private fun findCallerLocation(): String {
        val st = Throwable().stackTrace
        for (f in st) {
            val cn = f.className ?: continue
            if (!cn.startsWith("com.vanelle.os")) continue
            if (cn.contains("ErrorJournal")) continue
            return "${f.fileName ?: "?"}:${f.lineNumber} (${f.methodName})"
        }
        return "inconnu"
    }

    fun formatTime(ms: Long): String =
        SimpleDateFormat("dd/MM HH:mm:ss", Locale.FRANCE).format(Date(ms))
}
