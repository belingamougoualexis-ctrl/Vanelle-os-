package com.vanelle.os
import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Routine(val id: Long, val name: String, val hour: Int, val minute: Int, val actions: String, val enabled: Boolean)

/**
 * Routines proactives (ex: briefing matin).
 * S'appuie sur AlarmScheduler + ScheduledTaskReceiver.
 */
object RoutineManager {
    private fun prefs(c: Context) = SecurePrefs.get(c, "vanelle_routines")

    fun all(c: Context): List<Routine> {
        val arr = JSONArray(prefs(c).getString("list", "[]"))
        val out = mutableListOf<Routine>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Routine(
                o.getLong("id"), o.getString("name"),
                o.getInt("hour"), o.getInt("minute"),
                o.optString("actions"), o.optBoolean("enabled", true)
            ))
        }
        return out
    }

    fun saveAll(c: Context, list: List<Routine>) {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(JSONObject()
                .put("id", r.id).put("name", r.name)
                .put("hour", r.hour).put("minute", r.minute)
                .put("actions", r.actions).put("enabled", r.enabled))
        }
        prefs(c).edit().putString("list", arr.toString()).apply()
    }

    fun add(c: Context, name: String, hour: Int, minute: Int, actions: String): Routine {
        val r = Routine(System.currentTimeMillis(), name, hour, minute, actions, true)
        val list = all(c).toMutableList()
        list.add(r)
        saveAll(c, list)
        // Planifie via RelanceRepository / AlarmScheduler
        val relance = RelanceRepository(c)
        val task = relance.addTask("routine:${r.id}|$actions", hour, minute, true)
        AlarmScheduler.scheduleNext(c, task)
        ActivityLog.add(c, "routine", "Créée: $name à ${hour}h${minute.toString().padStart(2,'0')}")
        return r
    }

    fun ensureDefaultMorning(c: Context) {
        if (all(c).any { it.name.contains("matin", true) }) return
        add(c, "Briefing matin", 7, 30, "batterie et rappel de la journée")
    }

    fun describe(c: Context): String {
        val list = all(c).filter { it.enabled }
        if (list.isEmpty()) return "Aucune routine active."
        return list.joinToString(". ") {
            "${it.name} à ${it.hour}h${it.minute.toString().padStart(2,'0')}"
        }
    }
}
