package com.vanelle.os

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class VanelleApp : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        CrashLogger.install(this)
        ErrorJournal.install(this)
        // Déchargement TFLite / Llama sous pression mémoire
        ModelMemoryManager.install(this)
        appScope.launch {
            try {
                WakeWordModelManager.downloadIfNeeded(this@VanelleApp)
            } catch (_: Exception) {}
            try {
                NightlyConsolidation.schedule(this@VanelleApp)
            } catch (_: Exception) {}
            // Précharge Llama si le GGUF est déjà téléchargé (évite latence 1ère requête)
            try {
                if (LlamaModelManager.isReady(this@VanelleApp)) {
                    LocalLlamaHelper.get(this@VanelleApp).warmUp()
                }
            } catch (_: Exception) {}
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        ModelMemoryManager.onTrimMemory(level)
    }

    override fun onLowMemory() {
        super.onLowMemory()
        ModelMemoryManager.onLowMemory()
    }
}
