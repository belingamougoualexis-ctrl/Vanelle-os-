package com.vanelle.os

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat

/**
 * Vérifications d'autorisations explicites avant de lancer
 * WakeWordService / DataDownloadService (Android 13/14+).
 */
object ServiceGuards {
    private const val TAG = "ServiceGuards"

    fun hasRecordAudio(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    fun hasPostNotifications(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < 33) return true
        return ContextCompat.checkSelfPermission(
            context, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Démarre le service d'écoute seulement si micro (+ notif recommandée) OK.
     * @return true si le service a été démarré
     */
    fun startWakeWordIfAllowed(context: Context): Boolean {
        if (!WakeWordPrefs.isEnabled(context)) return false
        if (!hasRecordAudio(context)) {
            Log.w(TAG, "WakeWordService: RECORD_AUDIO manquant")
            return false
        }
        // POST_NOTIFICATIONS non bloquant sur certains OEM mais fortement recommandé
        if (!hasPostNotifications(context)) {
            Log.w(TAG, "WakeWordService: POST_NOTIFICATIONS manquant — démarrage quand même (FGS)")
        }
        return try {
            ContextCompat.startForegroundService(
                context,
                Intent(context, WakeWordService::class.java)
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "startWakeWord failed: ${e.message}")
            false
        }
    }

    fun startDataDownloadIfAllowed(context: Context): Boolean {
        if (!hasPostNotifications(context) && Build.VERSION.SDK_INT >= 33) {
            Log.w(TAG, "DataDownload: POST_NOTIFICATIONS manquant")
            // On tente quand même : le FGS dataSync peut afficher une notif système minimale
        }
        return try {
            DataDownloadService.start(context)
            true
        } catch (e: Exception) {
            Log.e(TAG, "startDataDownload failed: ${e.message}")
            false
        }
    }

    fun accessibilityReady(context: Context): Boolean =
        SystemGuards.isAccessibilityEnabled(context)
}
