package com.vanelle.os

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.os.BatteryManager
import android.os.PowerManager

/**
 * Contexte situationnel à partir de capteurs et services système.
 * Lecture ponctuelle : enregistre les capteurs le temps de la mesure puis se désinscrit.
 */
class SpatialContext(context: Context) : SensorEventListener {
    private val context = context.applicationContext
    private val sensorManager = this.context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    @Volatile private var lastAccel = 9.8f
    @Volatile private var lastLight = -1f
    @Volatile private var listening = false

    fun start() {
        if (listening) return
        listening = true
        sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        sensorManager?.getDefaultSensor(Sensor.TYPE_LIGHT)?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    fun stop() {
        if (!listening) return
        listening = false
        try { sensorManager?.unregisterListener(this) } catch (_: Exception) {}
    }

    /** Mesure courte puis désinscription (évite les fuites). */
    fun describe(): String {
        start()
        try {
            Thread.sleep(120)
        } catch (_: Exception) {}
        val parts = listOf(batteryLine(), motionLine(), lightLine(), audioLine(), powerLine())
        stop()
        return "Contexte actuel : " + parts.joinToString(" · ")
    }

    fun suggestedMode(): String {
        val night = lastLight in 0f..8f
        val moving = lastAccel > 12f
        val lowBat = batteryLevel() < 20
        return when {
            lowBat -> "économie"
            night && !moving -> "discret"
            moving -> "mobile"
            else -> "normal"
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                val x = event.values[0]; val y = event.values[1]; val z = event.values[2]
                lastAccel = Math.sqrt((x * x + y * y + z * z).toDouble()).toFloat()
            }
            Sensor.TYPE_LIGHT -> lastLight = event.values[0]
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun batteryLevel(): Int {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val l = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        if (l > 0) return l
        val bi = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val raw = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val sc = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (sc > 0) (raw * 100) / sc else 0
    }

    private fun batteryLine() = "batterie ${batteryLevel()} %"
    private fun motionLine() = when {
        lastAccel > 15f -> "mouvement intense"
        lastAccel > 11f -> "mouvement léger"
        else -> "stable"
    }
    private fun lightLine() = when {
        lastLight < 0f -> "luminosité inconnue"
        lastLight < 5f -> "environnement sombre"
        lastLight < 50f -> "luminosité faible"
        else -> "environnement éclairé"
    }
    private fun audioLine(): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return when (am.ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> "mode silencieux"
            AudioManager.RINGER_MODE_VIBRATE -> "mode vibreur"
            else -> "son activé"
        }
    }
    private fun powerLine(): String {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return if (pm.isInteractive) "écran allumé" else "écran éteint"
    }
}
