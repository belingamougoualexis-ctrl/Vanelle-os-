package com.vanelle.os

import android.content.Context

/**
 * Détection d'émotion / ton (texte aujourd'hui, audio demain).
 * Adapte personnalité + préfixe de réponse + mémorise le dernier mood.
 */
class EmotionEngine(private val context: Context) {
    enum class Mood { CALME, STRESS, JOIE, FATIGUE, URGENCE, FRUSTRATION, NEUTRE }

    private val prefs = SecurePrefs.get(context, "vanelle_emotion")

    fun detect(text: String): Mood {
        val t = text.lowercase()
        val mood = when {
            listOf("urgent", "aide", "secours", "vite", "maintenant", "immédiat", "danger")
                .any { t.contains(it) } -> Mood.URGENCE
            listOf("stress", "anxieux", "angoisse", "panique", "inquiet", "peur")
                .any { t.contains(it) } -> Mood.STRESS
            listOf("énervé", "enerve", "relou", "marre", "fait chier", "agacé", "frustré")
                .any { t.contains(it) } -> Mood.FRUSTRATION
            listOf("fatigué", "fatigue", "épuisé", "dodo", "sommeil", "crevé")
                .any { t.contains(it) } -> Mood.FATIGUE
            listOf("super", "génial", "content", "heureux", "merci beaucoup", "love", "parfait")
                .any { t.contains(it) } -> Mood.JOIE
            listOf("calme", "tranquille", "posé", "cool", "détendu")
                .any { t.contains(it) } -> Mood.CALME
            // Ponctuation / intensité
            t.count { it == '!' } >= 2 -> Mood.URGENCE
            t.count { it == '?' } >= 3 -> Mood.STRESS
            else -> Mood.NEUTRE
        }
        prefs.edit().putString("last_mood", mood.name)
            .putLong("last_mood_ts", System.currentTimeMillis()).apply()
        return mood
    }

    /** Plus de bascule de personnalité — conservé pour compatibilité d'appels. */
    fun adaptPersonality(mood: Mood) {
        // no-op
    }
}
