package com.vanelle.os

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.util.Log
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.nio.channels.FileChannel
import kotlinx.coroutines.*
import java.util.ArrayDeque

/**
 * Pipeline openWakeWord correct (melspectrogram → embedding → classifieur "Cassandra").
 *
 * Architecture officielle openWakeWord :
 *  - Audio 16 kHz / mono / 16-bit PCM
 *  - Chunks de 1280 samples (80 ms)
 *  - Mel : entrée float en plage int16 (PAS normalisé [-1,1]), sortie transformée /10+2
 *  - Embedding : fenêtre glissante de 76 frames mel (32 bins) → vecteur 96-dim
 *  - Stride embedding = 8 frames mel (~80 ms)
 *  - Classifieur : 16 embeddings successifs → score
 *  - Seuil 0.5 + cooldown anti-double détection
 *  - AGC matériel + gain logiciel plafonné
 */
class OpenWakeWordDetector(private val context: Context) {
    companion object {
        private const val TAG = "OpenWakeWord"
        private const val SAMPLE_RATE = 16000
        private const val CHUNK_SAMPLES = 1280 // 80 ms

        // Mel → Embedding
        private const val MEL_BINS = 32
        private const val EMB_WINDOW = 76   // frames mel par embedding
        private const val EMB_STEP = 8      // stride entre embeddings (~80 ms)
        private const val EMB_FEATURES = 96

        // Classifier
        private const val CLS_WINDOW = 16   // embeddings pour le classifieur
        private const val THRESHOLD = 0.50f
        private const val COOLDOWN_MS = 2500L
        private const val ENERGY_FLOOR = 80.0

        // Gain logiciel (repli si AGC matériel absent)
        private const val TARGET_PEAK = 12000f
        private const val MAX_SOFTWARE_GAIN = 5f
    }

    private var melInterp: Interpreter? = null
    private var embInterp: Interpreter? = null
    private var clsInterp: Interpreter? = null

    // Ring buffer des frames mel (chacune = FloatArray[32])
    private val melBuffer = ArrayDeque<FloatArray>(EMB_WINDOW + 16)
    // Ring buffer des embeddings (chacun = FloatArray[96])
    private val embBuffer = ArrayDeque<FloatArray>(CLS_WINDOW + 4)
    // Compteur de frames mel depuis le dernier embedding
    private var melSinceLastEmb = 0

    private var record: AudioRecord? = null
    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    @Volatile private var lastDetectAt = 0L
    private val recentScores = ArrayDeque<Float>(5)
    private var agc: AutomaticGainControl? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var softGain = 1f

    private fun loadModel(file: File): Interpreter? {
        return try {
            val fis = FileInputStream(file)
            val channel = fis.channel
            val buffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
            val interp = Interpreter(buffer)
            try {
                interp.allocateTensors()
            } catch (_: Exception) { /* certains modèles n'en ont pas besoin */ }
            interp
        } catch (e: Exception) {
            Log.e(TAG, "loadModel ${file.name}: ${e.message}")
            null
        }
    }

    /**
     * melspectrogram.tflite a une forme d'entrée dynamique.
     * Sans resize explicite, l'inférence échoue silencieusement sur Android.
     * Cf. openWakeWord GitHub issue #223.
     */
    private fun loadMelModel(file: File): Interpreter? {
        return try {
            val fis = FileInputStream(file)
            val channel = fis.channel
            val buffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
            val interp = Interpreter(buffer)
            try {
                interp.resizeInput(0, intArrayOf(1, CHUNK_SAMPLES))
                interp.allocateTensors()
            } catch (e: Exception) {
                Log.e(TAG, "resizeInput mel failed: ${e.message}")
                interp.close()
                return null
            }
            interp
        } catch (e: Exception) {
            Log.e(TAG, "loadMelModel: ${e.message}")
            null
        }
    }

    private fun loadAssetModel(name: String): Interpreter? {
        return try {
            val afd = context.assets.openFd(name)
            val fis = FileInputStream(afd.fileDescriptor)
            val buffer = fis.channel.map(
                FileChannel.MapMode.READ_ONLY,
                afd.startOffset,
                afd.declaredLength
            )
            val interp = Interpreter(buffer)
            try { interp.allocateTensors() } catch (_: Exception) {}
            interp
        } catch (e: Exception) {
            Log.e(TAG, "loadAssetModel $name: ${e.message}")
            null
        }
    }

    fun prepare(): Boolean {
        if (!WakeWordModelManager.isReady(context)) {
            Log.w(TAG, "prepare: models not ready")
            return false
        }
        if (melInterp == null) melInterp = loadMelModel(WakeWordModelManager.melFile(context))
        if (embInterp == null) embInterp = loadModel(WakeWordModelManager.embFile(context))
        if (clsInterp == null) clsInterp = loadAssetModel("wakeword_classifier.tflite")
        val ok = melInterp != null && embInterp != null && clsInterp != null
        Log.i(TAG, "prepare -> $ok (mel=${melInterp != null} emb=${embInterp != null} cls=${clsInterp != null})")
        return ok
    }

    @Suppress("MissingPermission")
    fun start(onDetected: () -> Unit) {
        stop()
        if (melInterp == null && !prepare()) {
            Log.w(TAG, "start: prepare failed")
            return
        }
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) {
            Log.e(TAG, "getMinBufferSize failed: $minBuf")
            return
        }
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, CHUNK_SAMPLES * 4)
            )
        } catch (e: Exception) {
            Log.e(TAG, "AudioRecord create: ${e.message}")
            null
        } ?: return
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "AudioRecord not initialized")
            try { rec.release() } catch (_: Exception) {}
            return
        }
        record = rec
        // VOICE_RECOGNITION désactive souvent l'AGC matériel → on le réactive si possible
        try {
            if (AutomaticGainControl.isAvailable()) {
                agc = AutomaticGainControl.create(rec.audioSessionId)?.apply { enabled = true }
            }
        } catch (e: Exception) {
            Log.w(TAG, "AGC unavailable: ${e.message}")
        }
        try {
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(rec.audioSessionId)?.apply { enabled = true }
            }
        } catch (e: Exception) {
            Log.w(TAG, "NoiseSuppressor unavailable: ${e.message}")
        }
        try {
            rec.startRecording()
        } catch (e: Exception) {
            Log.e(TAG, "startRecording: ${e.message}")
            try { rec.release() } catch (_: Exception) {}
            record = null
            return
        }
        melBuffer.clear()
        embBuffer.clear()
        melSinceLastEmb = 0
        recentScores.clear()
        softGain = 1f
        Log.i(TAG, "listening started (correct openWakeWord pipeline)")
        job = scope.launch {
            val buf = ShortArray(CHUNK_SAMPLES)
            while (isActive) {
                val n = try {
                    rec.read(buf, 0, CHUNK_SAMPLES)
                } catch (_: Exception) {
                    -1
                }
                if (n < CHUNK_SAMPLES) {
                    // Lecture partielle : on ignore (évite mismatch de forme après resizeInput 1280)
                    if (n <= 0) delay(15)
                    continue
                }
                applySoftwareGain(buf, CHUNK_SAMPLES)
                // Ignore near-silence (réduit faux positifs)
                var energy = 0.0
                for (i in 0 until CHUNK_SAMPLES) energy += kotlin.math.abs(buf[i].toInt())
                if (energy / CHUNK_SAMPLES < ENERGY_FLOOR) continue
                try {
                    processChunk(buf, onDetected)
                } catch (e: Exception) {
                    Log.w(TAG, "inference: ${e.message}")
                }
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        try { agc?.release() } catch (_: Exception) {}
        agc = null
        try { noiseSuppressor?.release() } catch (_: Exception) {}
        noiseSuppressor = null
        try { record?.stop() } catch (_: Exception) {}
        try { record?.release() } catch (_: Exception) {}
        record = null
        melBuffer.clear()
        embBuffer.clear()
        recentScores.clear()
        melSinceLastEmb = 0
    }

    /**
     * Normalisation logicielle en repli (appareils sans AGC matériel).
     * Amène le pic vers TARGET_PEAK, gain lissé et plafonné.
     */
    private fun applySoftwareGain(buf: ShortArray, n: Int) {
        var peak = 1
        for (i in 0 until n) {
            val a = kotlin.math.abs(buf[i].toInt())
            if (a > peak) peak = a
        }
        val desired = (TARGET_PEAK / peak).coerceIn(1f, MAX_SOFTWARE_GAIN)
        softGain = softGain * 0.85f + desired * 0.15f
        if (softGain <= 1.02f) return
        for (i in 0 until n) {
            val amplified = (buf[i] * softGain).toInt().coerceIn(-32768, 32767)
            buf[i] = amplified.toShort()
        }
    }

    /**
     * Pipeline streaming correct :
     * 1. Mel sur le chunk (entrée en plage int16)
     * 2. Transform /10+2
     * 3. Accumulation frames mel → embedding tous les EMB_STEP frames
     * 4. Accumulation 16 embeddings → classifieur
     */
    private suspend fun processChunk(pcm: ShortArray, onDetected: () -> Unit) {
        val melFrames = runMel(pcm) ?: return
        for (frame in melFrames) {
            melBuffer.addLast(frame)
            while (melBuffer.size > EMB_WINDOW + EMB_STEP) {
                melBuffer.removeFirst()
            }
            melSinceLastEmb++
            // Premier embedding dès que 76 frames sont dispo, puis un tous les EMB_STEP frames
            val readyForEmb = melBuffer.size >= EMB_WINDOW &&
                (embBuffer.isEmpty() || melSinceLastEmb >= EMB_STEP)
            if (readyForEmb) {
                melSinceLastEmb = 0
                val emb = runEmbedding() ?: continue
                embBuffer.addLast(emb)
                while (embBuffer.size > CLS_WINDOW) embBuffer.removeFirst()

                if (embBuffer.size == CLS_WINDOW) {
                    val score = runClassifier()
                    recentScores.addLast(score)
                    while (recentScores.size > 3) recentScores.removeFirst()
                    val smoothed = recentScores.average().toFloat()
                    val now = System.currentTimeMillis()
                    if (smoothed > THRESHOLD && now - lastDetectAt > COOLDOWN_MS) {
                        lastDetectAt = now
                        Log.i(TAG, "WAKE DETECTED score=$smoothed (raw=$score)")
                        // Reset partiel pour éviter re-déclenchement immédiat
                        embBuffer.clear()
                        recentScores.clear()
                        withContext(Dispatchers.Main) { onDetected() }
                    }
                }
            }
        }
    }

    /**
     * Mel spectrogram.
     * CRITIQUE : l'entrée doit être en plage int16 (float ≈ -32768..32767),
     * PAS normalisée [-1,1]. Puis transform obligatoire /10 + 2.
     */
    private fun runMel(pcm: ShortArray): List<FloatArray>? {
        val mel = melInterp ?: return null
        // openWakeWord attend float dans la plage int16, pas [-1,1]
        val input = Array(1) { FloatArray(CHUNK_SAMPLES) { i -> pcm[i].toFloat() } }
        val outShape = mel.getOutputTensor(0).shape()
        // Sortie typique : [1, 1, T, 32] ou [1, T, 32]
        val outSize = outShape.fold(1) { a, b -> a * b }
        val output = Array(1) { FloatArray(outSize) }
        try {
            mel.run(input, output)
        } catch (e: Exception) {
            Log.w(TAG, "mel run failed: ${e.message}")
            return null
        }
        val raw = output[0]
        // Nombre de frames temporelles (dernière dim = 32 bins)
        val tFrames = when {
            outShape.size >= 3 && outShape[outShape.size - 1] == MEL_BINS ->
                outShape[outShape.size - 2]
            outShape.size >= 2 && outShape.last() == MEL_BINS ->
                outShape[outShape.size - 2]
            else -> outSize / MEL_BINS
        }
        if (tFrames <= 0) return null
        val frames = ArrayList<FloatArray>(tFrames)
        for (t in 0 until tFrames) {
            val frame = FloatArray(MEL_BINS)
            for (b in 0 until MEL_BINS) {
                val idx = t * MEL_BINS + b
                // Transform officiel openWakeWord
                frame[b] = if (idx < raw.size) raw[idx] / 10f + 2f else 2f
            }
            frames.add(frame)
        }
        return frames
    }

    /**
     * Embedding : prend les 76 dernières frames mel → vecteur 96-dim.
     * Forme d'entrée attendue : [1, 76, 32, 1]
     */
    private fun runEmbedding(): FloatArray? {
        val emb = embInterp ?: return null
        if (melBuffer.size < EMB_WINDOW) return null
        // Construire [1, 76, 32, 1]
        val input = Array(1) {
            Array(EMB_WINDOW) { t ->
                val src = melBuffer.elementAt(melBuffer.size - EMB_WINDOW + t)
                Array(MEL_BINS) { b ->
                    floatArrayOf(src[b])
                }
            }
        }
        val outShape = emb.getOutputTensor(0).shape()
        val outSize = outShape.fold(1) { a, b -> a * b }
        val output = Array(1) { FloatArray(outSize.coerceAtLeast(EMB_FEATURES)) }
        return try {
            emb.run(input, output)
            // Sortie typique [1, 1, 1, 96] ou [1, 96]
            val flat = output[0]
            if (flat.size >= EMB_FEATURES) {
                flat.copyOf(EMB_FEATURES)
            } else {
                FloatArray(EMB_FEATURES) { i -> if (i < flat.size) flat[i] else 0f }
            }
        } catch (e: Exception) {
            Log.w(TAG, "emb run failed: ${e.message}")
            null
        }
    }

    /**
     * Classifieur : [1, 16, 96] → score
     */
    private fun runClassifier(): Float {
        val cls = clsInterp ?: return 0f
        if (embBuffer.size < CLS_WINDOW) return 0f
        return try {
            val input = Array(1) {
                Array(CLS_WINDOW) { i ->
                    embBuffer.elementAt(embBuffer.size - CLS_WINDOW + i)
                }
            }
            val output = Array(1) { FloatArray(1) }
            cls.run(input, output)
            output[0][0]
        } catch (e: Exception) {
            Log.w(TAG, "cls run failed: ${e.message}")
            0f
        }
    }
}
