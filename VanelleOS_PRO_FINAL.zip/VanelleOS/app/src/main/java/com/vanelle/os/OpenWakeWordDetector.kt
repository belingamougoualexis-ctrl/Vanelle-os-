package com.vanelle.os

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.util.Log
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.util.ArrayDeque
import kotlinx.coroutines.*

/**
 * Pipeline openWakeWord streaming correct pour Android / TFLite.
 *
 * Chaîne :
 *   PCM 16 kHz mono int16
 *   → melspectrogram.tflite  (entrée float plage int16, pas [-1,1])
 *   → transform  x/10 + 2
 *   → buffer 76 frames mel × 32 bins
 *   → embedding_model.tflite  [1,76,32,1] → 96-dim
 *   → buffer 16 embeddings
 *   → wakeword_classifier.tflite [1,16,96] → score
 *
 * Entrées/sorties via ByteBuffer (plus fiable que les Array imbriqués sur TFLite Android).
 */
class OpenWakeWordDetector(context: Context) {
    private val context = context.applicationContext

    companion object {
        private const val TAG = "OpenWakeWord"
        private const val SAMPLE_RATE = 16000
        private const val CHUNK_SAMPLES = 1280 // 80 ms

        private const val MEL_BINS = 32
        private const val EMB_WINDOW = 76
        private const val EMB_STEP = 8
        private const val EMB_FEATURES = 96
        private const val CLS_WINDOW = 16

        // Seuil assoupli : le classifieur custom "Cassandra" est souvent moins
        // calibré que les modèles openWakeWord officiels (hey_jarvis ≈ 0.5).
        private const val THRESHOLD = 0.30f
        private const val COOLDOWN_MS = 2000L
        private const val ENERGY_FLOOR = 50.0

        private const val TARGET_PEAK = 14000f
        private const val MAX_SOFTWARE_GAIN = 8f
    }

    private var melInterp: Interpreter? = null
    private var embInterp: Interpreter? = null
    private var clsInterp: Interpreter? = null

    private var melOutBuf: ByteBuffer? = null
    private var melOutSize = 0
    private var melOutShape: IntArray = intArrayOf()

    private var embInBuf: ByteBuffer? = null
    private var embOutBuf: ByteBuffer? = null

    private var clsInBuf: ByteBuffer? = null
    private var clsOutBuf: ByteBuffer? = null

    private val melBuffer = ArrayDeque<FloatArray>(EMB_WINDOW + 32)
    private val embBuffer = ArrayDeque<FloatArray>(CLS_WINDOW + 4)
    private var melSinceLastEmb = 0

    private var record: AudioRecord? = null
    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    @Volatile private var lastDetectAt = 0L
    private val recentScores = ArrayDeque<Float>(5)
    private var agc: AutomaticGainControl? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var softGain = 1f
    private val lifecycleLock = Any()
    private var frameCount = 0L
    private var lastLogAt = 0L

    private fun mapFile(file: File): ByteBuffer {
        val fis = FileInputStream(file)
        val ch = fis.channel
        return ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size())
    }

    private fun loadMelModel(file: File): Interpreter? {
        return try {
            val interp = Interpreter(mapFile(file), Interpreter.Options().apply {
                setNumThreads(2)
            })
            interp.resizeInput(0, intArrayOf(1, CHUNK_SAMPLES))
            interp.allocateTensors()
            val out = interp.getOutputTensor(0)
            melOutShape = out.shape()
            melOutSize = melOutShape.fold(1) { a, b -> a * b }
            melOutBuf = ByteBuffer.allocateDirect(melOutSize * 4).order(ByteOrder.nativeOrder())
            Log.i(TAG, "mel loaded outShape=${melOutShape.contentToString()} size=$melOutSize")
            interp
        } catch (e: Exception) {
            Log.e(TAG, "loadMelModel: ${e.message}")
            null
        }
    }

    private fun loadEmbModel(file: File): Interpreter? {
        return try {
            val interp = Interpreter(mapFile(file), Interpreter.Options().apply {
                setNumThreads(2)
            })
            // Forme fixe attendue par openWakeWord
            try {
                interp.resizeInput(0, intArrayOf(1, EMB_WINDOW, MEL_BINS, 1))
            } catch (_: Exception) { /* déjà fixe */ }
            interp.allocateTensors()
            val inShape = interp.getInputTensor(0).shape()
            val outShape = interp.getOutputTensor(0).shape()
            val inSize = inShape.fold(1) { a, b -> a * b }
            val outSize = outShape.fold(1) { a, b -> a * b }
            embInBuf = ByteBuffer.allocateDirect(inSize * 4).order(ByteOrder.nativeOrder())
            embOutBuf = ByteBuffer.allocateDirect(outSize.coerceAtLeast(EMB_FEATURES) * 4)
                .order(ByteOrder.nativeOrder())
            Log.i(TAG, "emb loaded in=${inShape.contentToString()} out=${outShape.contentToString()}")
            interp
        } catch (e: Exception) {
            Log.e(TAG, "loadEmbModel: ${e.message}")
            null
        }
    }

    private fun loadClsModel(): Interpreter? {
        return try {
            val afd = context.assets.openFd("wakeword_classifier.tflite")
            val fis = FileInputStream(afd.fileDescriptor)
            val buf = fis.channel.map(
                FileChannel.MapMode.READ_ONLY,
                afd.startOffset,
                afd.declaredLength
            )
            val interp = Interpreter(buf, Interpreter.Options().apply {
                setNumThreads(1)
            })
            try {
                interp.resizeInput(0, intArrayOf(1, CLS_WINDOW, EMB_FEATURES))
            } catch (_: Exception) { /* déjà fixe */ }
            interp.allocateTensors()
            val inShape = interp.getInputTensor(0).shape()
            val outShape = interp.getOutputTensor(0).shape()
            val inSize = inShape.fold(1) { a, b -> a * b }
            val outSize = outShape.fold(1) { a, b -> a * b }
            clsInBuf = ByteBuffer.allocateDirect(inSize * 4).order(ByteOrder.nativeOrder())
            clsOutBuf = ByteBuffer.allocateDirect(outSize.coerceAtLeast(1) * 4)
                .order(ByteOrder.nativeOrder())
            Log.i(TAG, "cls loaded in=${inShape.contentToString()} out=${outShape.contentToString()}")
            interp
        } catch (e: Exception) {
            Log.e(TAG, "loadClsModel: ${e.message}")
            null
        }
    }

    fun prepare(): Boolean {
        if (!WakeWordModelManager.isReady(context)) {
            Log.w(TAG, "prepare: models not ready")
            return false
        }
        synchronized(lifecycleLock) {
            if (melInterp == null) melInterp = loadMelModel(WakeWordModelManager.melFile(context))
            if (embInterp == null) embInterp = loadEmbModel(WakeWordModelManager.embFile(context))
            if (clsInterp == null) clsInterp = loadClsModel()
        }
        val ok = melInterp != null && embInterp != null && clsInterp != null
        Log.i(TAG, "prepare -> $ok")
        return ok
    }

    /** Charge les Interpreters TFLite hors UI thread. */
    suspend fun prepareSuspend(): Boolean = withContext(Dispatchers.IO) {
        prepare()
    }

    @Suppress("MissingPermission")
    fun start(onDetected: () -> Unit) {
        stop()
        if (melInterp == null && !prepare()) {
            Log.w(TAG, "start: prepare failed")
            return
        }
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) {
            Log.e(TAG, "getMinBufferSize failed: $minBuf")
            return
        }
        // MIC > VOICE_RECOGNITION : meilleur niveau + AGC constructeur souvent actif
        val sources = intArrayOf(
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.CAMCORDER
        )
        var rec: AudioRecord? = null
        for (src in sources) {
            try {
                val candidate = AudioRecord(
                    src, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, CHUNK_SAMPLES * 4)
                )
                if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                    rec = candidate
                    Log.i(TAG, "AudioRecord OK source=$src")
                    break
                }
                candidate.release()
            } catch (e: Exception) {
                Log.w(TAG, "AudioRecord source=$src failed: ${e.message}")
            }
        }
        if (rec == null) {
            Log.e(TAG, "No usable AudioRecord")
            return
        }
        record = rec
        try {
            if (AutomaticGainControl.isAvailable()) {
                agc = AutomaticGainControl.create(rec.audioSessionId)?.apply { enabled = true }
            }
        } catch (_: Exception) {}
        try {
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(rec.audioSessionId)?.apply { enabled = true }
            }
        } catch (_: Exception) {}
        try {
            rec.startRecording()
        } catch (e: Exception) {
            Log.e(TAG, "startRecording: ${e.message}")
            try { rec.release() } catch (_: Exception) {}
            record = null
            return
        }
        melBuffer.clear()
        embBuffer.clear()
        melSinceLastEmb = 0
        recentScores.clear()
        softGain = 1f
        frameCount = 0
        Log.i(TAG, "listening started")
        job = scope.launch {
            val buf = ShortArray(CHUNK_SAMPLES)
            while (isActive) {
                val n = try {
                    rec.read(buf, 0, CHUNK_SAMPLES)
                } catch (_: Exception) {
                    -1
                }
                if (n < CHUNK_SAMPLES) {
                    if (n <= 0) delay(10)
                    continue
                }
                applySoftwareGain(buf)
                var energy = 0.0
                for (i in 0 until CHUNK_SAMPLES) energy += kotlin.math.abs(buf[i].toInt())
                if (energy / CHUNK_SAMPLES < ENERGY_FLOOR) continue
                try {
                    processChunk(buf, onDetected)
                } catch (e: Exception) {
                    Log.w(TAG, "processChunk: ${e.message}")
                }
            }
        }
    }

    fun stop() {
        synchronized(lifecycleLock) {
            job?.cancel()
            job = null
            try { agc?.release() } catch (_: Exception) {}
            agc = null
            try { noiseSuppressor?.release() } catch (_: Exception) {}
            noiseSuppressor = null
            val rec = record
            record = null
            if (rec != null) {
                try { rec.stop() } catch (_: Exception) {}
                try { rec.release() } catch (_: Exception) {}
            }
            melBuffer.clear()
            embBuffer.clear()
            recentScores.clear()
            melSinceLastEmb = 0
        }
    }

    /**
     * Ferme les Interpreters TFLite et libère les ByteBuffers.
     * À appeler quand le service d'écoute s'arrête ou sous forte pression mémoire.
     */
    fun releaseModels() {
        stop()
        try { melInterp?.close() } catch (_: Exception) {}
        try { embInterp?.close() } catch (_: Exception) {}
        try { clsInterp?.close() } catch (_: Exception) {}
        melInterp = null
        embInterp = null
        clsInterp = null
        melOutBuf = null
        embInBuf = null
        embOutBuf = null
        clsInBuf = null
        clsOutBuf = null
        Log.i(TAG, "TFLite models released")
    }

    private fun applySoftwareGain(buf: ShortArray) {
        var peak = 1
        for (i in 0 until CHUNK_SAMPLES) {
            val a = kotlin.math.abs(buf[i].toInt())
            if (a > peak) peak = a
        }
        val desired = (TARGET_PEAK / peak).coerceIn(1f, MAX_SOFTWARE_GAIN)
        softGain = softGain * 0.85f + desired * 0.15f
        if (softGain <= 1.05f) return
        for (i in 0 until CHUNK_SAMPLES) {
            buf[i] = (buf[i] * softGain).toInt().coerceIn(-32768, 32767).toShort()
        }
    }

    private suspend fun processChunk(pcm: ShortArray, onDetected: () -> Unit) {
        val frames = runMel(pcm) ?: return
        for (frame in frames) {
            melBuffer.addLast(frame)
            while (melBuffer.size > EMB_WINDOW + EMB_STEP * 2) melBuffer.removeFirst()
            melSinceLastEmb++

            val ready = melBuffer.size >= EMB_WINDOW &&
                (embBuffer.isEmpty() || melSinceLastEmb >= EMB_STEP)
            if (!ready) continue

            melSinceLastEmb = 0
            val emb = runEmbedding() ?: continue
            embBuffer.addLast(emb)
            while (embBuffer.size > CLS_WINDOW) embBuffer.removeFirst()
            if (embBuffer.size < CLS_WINDOW) continue

            val score = runClassifier()
            recentScores.addLast(score)
            while (recentScores.size > 3) recentScores.removeFirst()
            val smoothed = recentScores.average().toFloat()
            frameCount++

            val now = System.currentTimeMillis()
            if (now - lastLogAt > 2500) {
                lastLogAt = now
                Log.d(TAG, "score=$smoothed raw=$score melBuf=${melBuffer.size} embBuf=${embBuffer.size} gain=$softGain")
            }

            if (smoothed > THRESHOLD && now - lastDetectAt > COOLDOWN_MS) {
                lastDetectAt = now
                Log.i(TAG, "WAKE DETECTED score=$smoothed")
                embBuffer.clear()
                recentScores.clear()
                withContext(Dispatchers.Main) { onDetected() }
            }
        }
    }

    /**
     * Mel : entrée float en plage int16 (cast short → float, SANS /32768).
     * Sortie aplatie puis découpée en frames de 32, avec transform /10+2.
     */
    private fun runMel(pcm: ShortArray): List<FloatArray>? {
        val mel = melInterp ?: return null
        val outBuf = melOutBuf ?: return null
        val input = Array(1) { FloatArray(CHUNK_SAMPLES) { i -> pcm[i].toFloat() } }
        outBuf.rewind()
        try {
            mel.run(input, outBuf)
        } catch (e: Exception) {
            Log.w(TAG, "mel.run: ${e.message}")
            return null
        }
        outBuf.rewind()
        val raw = FloatArray(melOutSize)
        outBuf.asFloatBuffer().get(raw)

        // Déterminer T (frames temporelles). Formes courantes : [1,1,T,32] [1,T,32] [1,32,T]
        val shape = melOutShape
        val (tFrames, layout) = when {
            shape.size >= 4 && shape[3] == MEL_BINS -> shape[2] to "T_last_bins"
            shape.size >= 4 && shape[2] == MEL_BINS -> shape[3] to "bins_then_T"
            shape.size == 3 && shape[2] == MEL_BINS -> shape[1] to "T_last_bins"
            shape.size == 3 && shape[1] == MEL_BINS -> shape[2] to "bins_then_T"
            else -> (melOutSize / MEL_BINS) to "flat"
        }
        if (tFrames <= 0) return null

        val frames = ArrayList<FloatArray>(tFrames)
        for (t in 0 until tFrames) {
            val frame = FloatArray(MEL_BINS)
            for (b in 0 until MEL_BINS) {
                val idx = when (layout) {
                    "bins_then_T" -> b * tFrames + t
                    else -> t * MEL_BINS + b
                }
                val v = if (idx in raw.indices) raw[idx] else 0f
                frame[b] = v / 10f + 2f
            }
            frames.add(frame)
        }
        return frames
    }

    /** Embedding [1,76,32,1] via ByteBuffer. */
    private fun runEmbedding(): FloatArray? {
        val emb = embInterp ?: return null
        val inBuf = embInBuf ?: return null
        val outBuf = embOutBuf ?: return null
        if (melBuffer.size < EMB_WINDOW) return null

        inBuf.rewind()
        val start = melBuffer.size - EMB_WINDOW
        for (t in 0 until EMB_WINDOW) {
            val src = melBuffer.elementAt(start + t)
            for (b in 0 until MEL_BINS) {
                inBuf.putFloat(src[b])
            }
        }
        inBuf.rewind()
        outBuf.rewind()
        return try {
            emb.run(inBuf, outBuf)
            outBuf.rewind()
            val flat = FloatArray(EMB_FEATURES)
            val fb = outBuf.asFloatBuffer()
            val n = fb.remaining().coerceAtMost(EMB_FEATURES)
            for (i in 0 until n) flat[i] = fb.get()
            flat
        } catch (e: Exception) {
            Log.w(TAG, "emb.run: ${e.message}")
            null
        }
    }

    /** Classifieur [1,16,96] → score. */
    private fun runClassifier(): Float {
        val cls = clsInterp ?: return 0f
        val inBuf = clsInBuf ?: return 0f
        val outBuf = clsOutBuf ?: return 0f
        if (embBuffer.size < CLS_WINDOW) return 0f

        inBuf.rewind()
        val start = embBuffer.size - CLS_WINDOW
        for (i in 0 until CLS_WINDOW) {
            val e = embBuffer.elementAt(start + i)
            for (j in 0 until EMB_FEATURES) {
                inBuf.putFloat(if (j < e.size) e[j] else 0f)
            }
        }
        inBuf.rewind()
        outBuf.rewind()
        return try {
            cls.run(inBuf, outBuf)
            outBuf.rewind()
            outBuf.asFloatBuffer().get()
        } catch (e: Exception) {
            Log.w(TAG, "cls.run: ${e.message}")
            0f
        }
    }
}
