import { cn } from "@/lib/utils";

export function NexusMark({ className, pulse = false }: { className?: string; pulse?: boolean }) {
  return (
    <svg viewBox="0 0 48 48" className={cn("text-accent", className)} aria-hidden="true">
      <circle cx="10" cy="36" r="4" fill="currentColor" className={pulse ? "origin-center animate-[nexus-node_2.8s_ease-in-out_infinite]" : undefined} />
      <circle cx="24" cy="10" r="4" fill="currentColor" className="text-fg" />
      <circle cx="38" cy="36" r="4" fill="currentColor" className={pulse ? "origin-center animate-[nexus-node_2.8s_ease-in-out_infinite]" : undefined} />
      <path
        d="M10 36 L24 10 L38 36"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function NexusWordmark({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <NexusMark className="size-9" />
      <div className="leading-tight">
        <div className="font-display text-[17px] font-semibold tracking-[0.18em] text-fg">NEXUS</div>
        <div className="text-[10px] font-medium tracking-[0.22em] text-muted">NETWORK OF NETWORKS</div>
      </div>
    </div>
  );
}
