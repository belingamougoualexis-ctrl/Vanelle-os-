import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import { Fingerprint, Home, Inbox, Radio } from "lucide-react";
import { NexusMark } from "@/components/brand/logo";
import { StatusPill } from "@/components/app/status-pill";
import { useMesh } from "@/components/app/mesh-provider";
import { useNexus } from "@/lib/nexus/session";
import { cn } from "@/lib/utils";

const TABS = [
  { to: "/app", label: "Accueil", icon: Home },
  { to: "/app/network", label: "Réseau", icon: Radio },
  { to: "/app/inbox", label: "Messages", icon: Inbox },
  { to: "/app/node", label: "Nœud", icon: Fingerprint },
] as const;

export function AppShell() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const session = useNexus((s) => s.session);
  const requests = useNexus((s) => s.requests);
  const mesh = useMesh();

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-3xl flex-col bg-bg">
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-line bg-bg/90 px-4 py-3 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <NexusMark className="size-8" pulse={mesh.joined} />
          <div>
            <div className="font-display text-sm font-semibold tracking-[0.16em] text-fg">NEXUS</div>
            <StatusPill
              state={mesh.joined ? "live" : mesh.enabled ? "warn" : "idle"}
              label={mesh.joined ? `${mesh.connectedCount} pair${mesh.connectedCount > 1 ? "s" : ""}` : mesh.enabled ? "Connexion…" : "Inactif"}
            />
          </div>
        </div>
        <div className="text-right">
          <div className="text-sm text-fg">{session?.username}</div>
          <div className="font-mono text-[11px] text-muted">{session?.nodeId}</div>
        </div>
      </header>

      <main className="flex-1 px-4 pb-28 pt-6">
        <Outlet />
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md">
        <div className="mx-auto grid max-w-3xl grid-cols-4 px-2 py-2">
          {TABS.map((tab) => {
            const active = tab.to === "/app" ? pathname === "/app" : pathname.startsWith(tab.to);
            const Icon = tab.icon;
            const badge = tab.to === "/app/inbox" && requests.length > 0;
            return (
              <Link
                key={tab.to}
                to={tab.to}
                className={cn(
                  "relative flex min-h-12 flex-col items-center justify-center gap-1 rounded-md text-[11px] font-medium transition-colors duration-150",
                  active ? "text-fg" : "text-muted hover:text-fg",
                )}
              >
                <Icon className={cn("size-5", active && "text-accent")} />
                {tab.label}
                {badge ? <span className="absolute right-1/4 top-1 size-1.5 rounded-full bg-accent" /> : null}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
