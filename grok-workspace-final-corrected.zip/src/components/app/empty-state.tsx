import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function EmptyState({
  icon: Icon,
  title,
  detail,
  action,
  className,
}: {
  icon: LucideIcon;
  title: string;
  detail: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col items-start gap-3 rounded-xl border border-dashed border-line bg-surface px-5 py-8", className)}>
      <Icon className="size-5 text-muted" />
      <div>
        <h3 className="font-display text-base font-semibold text-fg">{title}</h3>
        <p className="mt-1 max-w-prose text-sm text-muted">{detail}</p>
      </div>
      {action}
    </div>
  );
}
