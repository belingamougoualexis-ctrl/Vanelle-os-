import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { useP2PRoom, type PeerInfo } from "@/lib/multiplayer";
import { encryptForPeer, decryptFromPeer, signCanonical, verifyCanonical } from "@/lib/nexus/crypto";
import { contactCanonical, isWireMessage, type WireMessage } from "@/lib/nexus/protocol";
import { applyRelayCredits, spendCredits } from "@/lib/nexus/credits";
import { useNexus } from "@/lib/nexus/session";
import type { RemotePeer } from "@/lib/nexus/types";

type MeshContextValue = {
  enabled: boolean;
  joined: boolean;
  error: string | null;
  peers: RemotePeer[];
  connectedCount: number;
  connect: () => void;
  disconnect: () => void;
  sendHello: () => void;
  sendContactRequest: (peerId: string, message: string) => Promise<void>;
  sendText: (peer: RemotePeer, body: string) => Promise<void>;
  sendFile: (peer: RemotePeer, file: File) => Promise<void>;
};

const MeshContext = createContext<MeshContextValue | null>(null);

function sanitizeRoom(code: string): string {
  const cleaned = code.replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 64);
  return cleaned.length >= 2 ? cleaned : "nexus-mesh";
}

function sanitizePeerId(nodeId: string): string {
  const cleaned = nodeId.replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 64);
  return cleaned || "nx-unknown";
}

export function MeshProvider({ children }: { children: React.ReactNode }) {
  const session = useNexus((s) => s.session);
  const settings = useNexus((s) => s.settings);
  const addRequest = useNexus((s) => s.addRequest);
  const addMessage = useNexus((s) => s.addMessage);
  const markDelivered = useNexus((s) => s.markDelivered);
  const pushActivity = useNexus((s) => s.pushActivity);
  const setConnected = useNexus((s) => s.setConnected);
  const contacts = useNexus((s) => s.contacts);

  const [enabled, setEnabled] = useState(false);
  const [meta, setMeta] = useState<Record<string, Pick<RemotePeer, "nodeId" | "address" | "publicKey" | "meshName" | "name">>>({});

  const selfId = session ? sanitizePeerId(session.nodeId) : "nx-pending";
  const room = sanitizeRoom(settings.meshCode);
  const p2p = useP2PRoom({
    room,
    selfId,
    name: session?.username ?? selfId,
    enabled: enabled && Boolean(session),
  });

  const sendRef = useRef(p2p.send);
  sendRef.current = p2p.send;
  const broadcastRef = useRef(p2p.broadcast);
  broadcastRef.current = p2p.broadcast;

  const hello = useCallback(() => {
    if (!session) return;
    const payload: WireMessage = {
      v: 1,
      t: "hello",
      nodeId: session.nodeId,
      name: session.username,
      address: session.address,
      publicKey: session.publicSpkiB64,
      meshName: session.meshName,
    };
    sendRef.current(payload);
  }, [session]);

  useEffect(() => {
    if (!enabled) {
      setConnected(false);
      return;
    }
    if (p2p.joined) {
      setConnected(true);
      hello();
      pushActivity("Mesh actif", `Salon ${room}`);
    }
  }, [enabled, p2p.joined, hello, pushActivity, room, setConnected]);

  useEffect(() => {
    return p2p.onMessage((from, data, channel) => {
      if (channel !== "reliable" || !isWireMessage(data) || !session) return;
      if (data.t === "hello") {
        setMeta((prev) => ({
          ...prev,
          [from]: {
            nodeId: data.nodeId,
            address: data.address,
            publicKey: data.publicKey,
            meshName: data.meshName,
            name: data.name,
          },
        }));
        applyRelayCredits(data.nodeId, 256);
        return;
      }
      if (data.t === "contact_req") {
        void (async () => {
          const canonical = contactCanonical({
            id: data.id,
            fromAlias: data.fromAlias,
            fromAddress: data.fromAddress,
            fromNodeId: data.fromNodeId,
            fromPublicKey: data.fromPublicKey,
            message: data.message,
            createdAt: data.createdAt,
          });
          const ok = await verifyCanonical(data.fromPublicKey, canonical, data.signature);
          if (!ok) return;
          addRequest(data);
          pushActivity("Demande reçue", data.fromAlias);
        })();
        return;
      }
      if (data.t === "msg") {
        const peerKey = meta[from]?.publicKey;
        if (!peerKey) return;
        void (async () => {
          try {
            const body = await decryptFromPeer(session.privateJwk, peerKey, { iv: data.iv, ct: data.ct });
            addMessage({
              id: data.id,
              peerAddress: meta[from]?.address ?? data.from,
              direction: "in",
              body,
              createdAt: data.createdAt,
              status: "delivered",
            });
            applyRelayCredits(from, body.length);
          } catch {
            pushActivity("Message illisible", "Le déchiffrement a échoué.");
          }
        })();
      }
    });
  }, [p2p, session, meta, addRequest, addMessage, pushActivity]);

  useEffect(() => {
    const connected = p2p.peers.filter((p) => p.connectionState === "connected");
    if (connected.length > 0) hello();
  }, [p2p.peers, hello]);

  const sendContactRequest = useCallback(
    async (peerId: string, message: string) => {
      if (!session) throw new Error("Session verrouillée.");
      const id = crypto.randomUUID().replaceAll("-", "").slice(0, 20);
      const createdAt = Date.now();
      const base = {
        id,
        fromAlias: session.username,
        fromAddress: session.address,
        fromNodeId: session.nodeId,
        fromPublicKey: session.publicSpkiB64,
        message,
        createdAt,
      };
      const signature = await signCanonical(session.privateJwk, contactCanonical(base));
      sendRef.current({ v: 1, t: "contact_req", ...base, signature }, peerId);
      pushActivity("Demande envoyée", message || "Demande de contact");
    },
    [session, pushActivity],
  );

  const sendText = useCallback(
    async (peer: RemotePeer, body: string) => {
      if (!session) throw new Error("Session verrouillée.");
      if (!peer.publicKey || !peer.address) throw new Error("Ce pair n'a pas encore publié son identité.");
      if (settings.trustedOnly && !contacts.some((c) => c.address === peer.address)) {
        throw new Error("Mode confiance : seuls les contacts acceptés peuvent recevoir un message.");
      }
      const packed = await encryptForPeer(session.privateJwk, peer.publicKey, body);
      const id = crypto.randomUUID().replaceAll("-", "").slice(0, 20);
      const createdAt = Date.now();
      addMessage({
        id,
        peerAddress: peer.address,
        direction: "out",
        body,
        createdAt,
        status: "sent",
      });
      sendRef.current(
        {
          v: 1,
          t: "msg",
          id,
          from: session.address,
          to: peer.address,
          iv: packed.iv,
          ct: packed.ct,
          createdAt,
        },
        peer.id,
      );
      spendCredits(peer.id, body.length, settings.creditsEnforced);
      markDelivered(id);
    },
    [session, settings, contacts, addMessage, markDelivered],
  );

  const sendFile = useCallback(
    async (peer: RemotePeer, file: File) => {
      if (!session) throw new Error("Session verrouillée.");
      if (!settings.storageEnabled) throw new Error("Le partage de fichiers est désactivé dans les réglages.");
      if (file.size > 8 * 1024 * 1024) throw new Error("Fichier trop volumineux (8 Mio max).");
      const buffer = new Uint8Array(await file.arrayBuffer());
      const hashBuf = await crypto.subtle.digest("SHA-256", buffer);
      const hash = Array.from(new Uint8Array(hashBuf), (b) => b.toString(16).padStart(2, "0")).join("");
      const id = crypto.randomUUID().replaceAll("-", "").slice(0, 16);
      sendRef.current({ v: 1, t: "file_offer", id, hash, name: file.name, size: file.size }, peer.id);
      const chunkSize = 12_000;
      const total = Math.ceil(buffer.length / chunkSize);
      for (let i = 0; i < total; i++) {
        const slice = buffer.subarray(i * chunkSize, (i + 1) * chunkSize);
        let bin = "";
        for (const b of slice) bin += String.fromCharCode(b);
        sendRef.current(
          { v: 1, t: "file_chunk", id, index: i, total, data: btoa(bin) },
          peer.id,
        );
      }
      applyRelayCredits(peer.id, file.size);
      pushActivity("Fichier envoyé", `${file.name} · ${hash.slice(0, 12)}`);
    },
    [session, settings.storageEnabled, pushActivity],
  );

  const peers: RemotePeer[] = useMemo(
    () =>
      p2p.peers.map((peer: PeerInfo) => ({
        ...peer,
        ...meta[peer.id],
        name: meta[peer.id]?.name ?? peer.name,
      })),
    [p2p.peers, meta],
  );

  const value = useMemo<MeshContextValue>(
    () => ({
      enabled,
      joined: p2p.joined,
      error: p2p.error,
      peers,
      connectedCount: peers.filter((p) => p.connectionState === "connected").length,
      connect: () => setEnabled(true),
      disconnect: () => {
        setEnabled(false);
        setConnected(false);
        pushActivity("Mesh arrêté", "Les canaux WebRTC ont été fermés.");
      },
      sendHello: hello,
      sendContactRequest,
      sendText,
      sendFile,
    }),
    [enabled, p2p.joined, p2p.error, peers, hello, sendContactRequest, sendText, sendFile, pushActivity, setConnected],
  );

  return <MeshContext.Provider value={value}>{children}</MeshContext.Provider>;
}

export function useMesh() {
  const ctx = useContext(MeshContext);
  if (!ctx) throw new Error("useMesh must be used within MeshProvider");
  return ctx;
}
