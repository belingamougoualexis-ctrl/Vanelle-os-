import { Check, Copy } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function CopyField({
  value,
  label,
  mono = true,
  className,
}: {
  value: string;
  label?: string;
  mono?: boolean;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className={cn("rounded-lg border border-line bg-raised p-3", className)}>
      {label ? <div className="mb-1 text-[11px] font-medium uppercase tracking-wider text-muted">{label}</div> : null}
      <div className="flex items-start gap-2">
        <p className={cn("min-w-0 flex-1 break-all text-sm text-fg", mono && "font-mono text-[13px]")}>{value}</p>
        <Button type="button" variant="ghost" size="icon" className="size-9 shrink-0" onClick={() => void copy()} aria-label="Copier">
          {copied ? <Check className="size-4 text-accent" /> : <Copy className="size-4" />}
        </Button>
      </div>
    </div>
  );
}
