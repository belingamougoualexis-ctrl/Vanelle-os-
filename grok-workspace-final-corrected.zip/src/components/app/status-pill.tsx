import { cn } from "@/lib/utils";

export function StatusPill({
  state,
  label,
}: {
  state: "live" | "idle" | "warn" | "off";
  label: string;
}) {
  return (
    <span className="inline-flex items-center gap-2 text-xs text-muted">
      <span
        className={cn(
          "size-1.5 rounded-full",
          state === "live" && "bg-accent animate-[nexus-pulse_2.2s_ease-in-out_infinite]",
          state === "idle" && "bg-muted",
          state === "warn" && "bg-warn",
          state === "off" && "bg-danger",
        )}
      />
      {label}
    </span>
  );
}
