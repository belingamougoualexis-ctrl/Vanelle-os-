import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { FileUp, Trash2, UserPlus } from "lucide-react";
import { useMemo, useState } from "react";
import { CopyField } from "@/components/app/copy-field";
import { EmptyState } from "@/components/app/empty-state";
import { useMesh } from "@/components/app/mesh-provider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { isValidOverlay } from "@/lib/nexus/address";
import { putBlob, getBlob, usedBytes } from "@/lib/nexus/content-db";
import { creditBalance } from "@/lib/nexus/credits";
import { encodeStripe, recoverStripe } from "@/lib/nexus/erasure";
import { bytesToHex } from "@/lib/nexus/bytes";
import { loadContentIndex, saveContentIndex, setConsent } from "@/lib/nexus/persist";
import { useNexus } from "@/lib/nexus/session";
import { exportVault } from "@/lib/nexus/vault";
import type { ContentRecord } from "@/lib/nexus/types";

export const Route = createFileRoute("/app/node")({ component: NodePage });

function NodePage() {
  const navigate = useNavigate();
  const session = useNexus((s) => s.session)!;
  const contacts = useNexus((s) => s.contacts);
  const settings = useNexus((s) => s.settings);
  const addContact = useNexus((s) => s.addContact);
  const removeContact = useNexus((s) => s.removeContact);
  const updateSettings = useNexus((s) => s.updateSettings);
  const lock = useNexus((s) => s.lock);
  const pushActivity = useNexus((s) => s.pushActivity);
  const mesh = useMesh();
  const [alias, setAlias] = useState("");
  const [address, setAddress] = useState("");
  const [contactError, setContactError] = useState<string | null>(null);
  const [contents, setContents] = useState<ContentRecord[]>(() => loadContentIndex());
  const [fileError, setFileError] = useState<string | null>(null);
  const [erasureNote, setErasureNote] = useState<string | null>(null);
  const credits = useMemo(() => creditBalance(), [contents, mesh.connectedCount]);

  function add() {
    setContactError(null);
    try {
      if (!isValidOverlay(address)) throw new Error("Adresse overlay invalide.");
      addContact({ alias, address });
      setAlias("");
      setAddress("");
    } catch (err) {
      setContactError(err instanceof Error ? err.message : "Contact impossible.");
    }
  }

  async function importFile(file: File) {
    setFileError(null);
    setErasureNote(null);
    try {
      if (file.size > 8 * 1024 * 1024) throw new Error("Fichier trop volumineux (8 Mio max).");
      const data = new Uint8Array(await file.arrayBuffer());
      const hash = bytesToHex(new Uint8Array(await crypto.subtle.digest("SHA-256", data)));
      const quota = settings.storageQuotaMb * 1024 * 1024;
      const used = await usedBytes();
      if (used + data.byteLength > quota) throw new Error("Quota de stockage dépassé.");
      await putBlob(hash, data.buffer);
      const record: ContentRecord = {
        id: hash.slice(0, 20),
        name: file.name,
        hash,
        size: file.size,
        createdAt: Date.now(),
        pinned: true,
      };
      const next = [record, ...contents.filter((c) => c.hash !== hash)];
      saveContentIndex(next);
      setContents(next);
      const stripe = encodeStripe(data);
      const recovered = recoverStripe(stripe, null, stripe.dataB, stripe.parity);
      const ok = recovered.length === data.length && recovered.every((b, i) => b === data[i]);
      setErasureNote(
        ok
          ? `Intégrité SHA-256 ${hash.slice(0, 12)}… · reconstruction 2+1 vérifiée sans le fragment A.`
          : "Le fichier a été stocké, mais la reconstruction 2+1 a échoué.",
      );
      pushActivity("Contenu importé", file.name);
    } catch (err) {
      setFileError(err instanceof Error ? err.message : "Import impossible.");
    }
  }

  function downloadBackup() {
    const vault = exportVault();
    const blob = new Blob([JSON.stringify(vault, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `nexus-${session.nodeId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="stagger-in space-y-8">
      <header>
        <h1 className="font-display text-[32px] font-semibold tracking-tight">Nœud</h1>
        <p className="mt-1 text-sm text-muted">Identité, contacts, fichiers, participation.</p>
      </header>

      <section className="space-y-3">
        <h2 className="font-display text-lg font-semibold">Identité</h2>
        <CopyField label="Nom" value={session.username} mono={false} />
        <CopyField label="Nœud" value={session.nodeId} />
        <CopyField label="Empreinte" value={session.fingerprint} />
        <CopyField label="Adresse" value={session.address} />
        <div className="grid gap-2 sm:grid-cols-2">
          <Button variant="secondary" onClick={downloadBackup}>
            Exporter l'identité
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              mesh.disconnect();
              lock();
              void navigate({ to: "/" });
            }}
          >
            Verrouiller
          </Button>
        </div>
      </section>

      <section className="space-y-3">
        <h2 className="font-display text-lg font-semibold">Contacts</h2>
        <div className="space-y-2 rounded-xl border border-line bg-surface p-4">
          <label className="block space-y-1.5">
            <Label htmlFor="alias">Alias</Label>
            <Input id="alias" value={alias} onChange={(e) => setAlias(e.target.value)} />
          </label>
          <label className="block space-y-1.5">
            <Label htmlFor="address">Adresse overlay</Label>
            <Input id="address" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="fd00:4e58:5553:…" />
          </label>
          {contactError ? <p className="text-sm text-danger">{contactError}</p> : null}
          <Button variant="secondary" className="w-full" onClick={add}>
            <UserPlus className="size-4" />
            Enregistrer
          </Button>
        </div>
        {contacts.length === 0 ? (
          <EmptyState icon={UserPlus} title="Carnet vide" detail="Les identités overlay sont locales. Aucun compte serveur n'est créé." />
        ) : (
          <ul className="divide-y divide-line overflow-hidden rounded-lg border border-line bg-surface">
            {contacts.map((contact) => (
              <li key={contact.id} className="flex items-center justify-between gap-3 px-4 py-3">
                <div className="min-w-0">
                  <div className="truncate text-sm text-fg">{contact.alias}</div>
                  <div className="truncate font-mono text-[11px] text-muted">{contact.address}</div>
                </div>
                <button type="button" className="p-2 text-muted hover:text-danger" onClick={() => removeContact(contact.id)} aria-label="Supprimer">
                  <Trash2 className="size-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="space-y-3">
        <h2 className="font-display text-lg font-semibold">Fichiers</h2>
        <p className="text-sm text-muted">
          Stockage local adressé par SHA-256, avec contrôle d'intégrité 2+1. Le transfert mesh n'est proposé que si le
          stockage est activé et qu'un pair est connecté.
        </p>
        <label className="flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-line bg-surface px-4 py-6 text-sm text-muted hover:text-fg">
          <FileUp className="size-4" />
          Importer un fichier réel
          <input
            type="file"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void importFile(file);
              e.currentTarget.value = "";
            }}
          />
        </label>
        {fileError ? <p className="text-sm text-danger">{fileError}</p> : null}
        {erasureNote ? <p className="text-sm text-muted">{erasureNote}</p> : null}
        {contents.length === 0 ? null : (
          <ul className="divide-y divide-line overflow-hidden rounded-lg border border-line bg-surface">
            {contents.map((item) => (
              <li key={item.id} className="px-4 py-3">
                <div className="text-sm text-fg">{item.name}</div>
                <div className="font-mono text-[11px] text-muted">
                  {item.hash.slice(0, 20)}… · {Math.ceil(item.size / 1024)} Kio
                </div>
                {settings.storageEnabled && mesh.peers.some((p) => p.connectionState === "connected") ? (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="mt-1 px-0"
                    onClick={async () => {
                      const peer = mesh.peers.find((p) => p.connectionState === "connected");
                      if (!peer) return;
                      const buf = await getBlob(item.hash);
                      if (!buf) return setFileError("Objet introuvable dans le stockage local.");
                      await mesh.sendFile(peer, new File([buf], item.name));
                    }}
                  >
                    Envoyer au premier pair
                  </Button>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="space-y-4">
        <h2 className="font-display text-lg font-semibold">Participation</h2>
        <Toggle
          label="Partage de fichiers"
          detail="Autorise l'envoi de contenus locaux vers un pair connecté."
          checked={settings.storageEnabled}
          onCheckedChange={(v) => updateSettings({ storageEnabled: v })}
        />
        <Toggle
          label="Présence dans le salon"
          detail="Publie votre nom de nœud aux pairs du salon actif."
          checked={settings.presenceSharing}
          onCheckedChange={(v) => updateSettings({ presenceSharing: v })}
        />
        <Toggle
          label="Contacts de confiance uniquement"
          detail="Les messages sortants sont limités au carnet d'adresses."
          checked={settings.trustedOnly}
          onCheckedChange={(v) => updateSettings({ trustedOnly: v })}
        />
        <Toggle
          label="Crédits stricts"
          detail={`Solde actuel : ${credits}. Comptabilité locale des octets, pas une monnaie.`}
          checked={settings.creditsEnforced}
          onCheckedChange={(v) => updateSettings({ creditsEnforced: v })}
        />
      </section>

      <section className="space-y-3 pb-4">
        <Link to="/legal" className="block text-sm text-muted hover:text-fg">
          Conditions et confidentialité
        </Link>
        <button
          type="button"
          className="text-sm text-danger hover:opacity-80"
          onClick={() => {
            mesh.disconnect();
            setConsent(false);
            lock();
            void navigate({ to: "/" });
          }}
        >
          Se déconnecter
        </button>
      </section>
    </div>
  );
}

function Toggle({
  label,
  detail,
  checked,
  onCheckedChange,
}: {
  label: string;
  detail: string;
  checked: boolean;
  onCheckedChange: (value: boolean) => void;
}) {
  return (
    <div className="flex items-start justify-between gap-4 rounded-lg border border-line bg-surface px-4 py-3">
      <div>
        <div className="text-sm text-fg">{label}</div>
        <p className="mt-1 text-xs text-muted">{detail}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}
