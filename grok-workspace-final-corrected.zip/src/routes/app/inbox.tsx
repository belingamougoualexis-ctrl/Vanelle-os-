import { createFileRoute } from "@tanstack/react-router";
import { Inbox } from "lucide-react";
import { useMemo, useState } from "react";
import { EmptyState } from "@/components/app/empty-state";
import { useMesh } from "@/components/app/mesh-provider";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useNexus } from "@/lib/nexus/session";
import type { RemotePeer } from "@/lib/nexus/types";

export const Route = createFileRoute("/app/inbox")({ component: InboxPage });

function InboxPage() {
  const session = useNexus((s) => s.session)!;
  const contacts = useNexus((s) => s.contacts);
  const requests = useNexus((s) => s.requests);
  const messages = useNexus((s) => s.messages);
  const acceptRequest = useNexus((s) => s.acceptRequest);
  const removeRequest = useNexus((s) => s.removeRequest);
  const pushActivity = useNexus((s) => s.pushActivity);
  const mesh = useMesh();
  const [target, setTarget] = useState<string>("");
  const [draft, setDraft] = useState("");
  const [error, setError] = useState<string | null>(null);

  const destinations = useMemo(() => {
    const fromMesh = mesh.peers.filter((p) => p.connectionState === "connected" && p.address);
    const fromContacts = contacts
      .map((c) => mesh.peers.find((p) => p.address === c.address && p.connectionState === "connected"))
      .filter((p): p is RemotePeer => Boolean(p));
    const map = new Map<string, RemotePeer>();
    for (const p of [...fromMesh, ...fromContacts]) map.set(p.id, p);
    return [...map.values()];
  }, [mesh.peers, contacts]);

  const selected = destinations.find((p) => p.id === target) ?? destinations[0];
  const thread = selected?.address
    ? messages.filter((m) => m.peerAddress === selected.address).slice(-40)
    : [];

  async function send() {
    setError(null);
    if (!selected) return setError("Aucun pair connecté pour recevoir ce message.");
    const body = draft.trim();
    if (!body) return;
    try {
      await mesh.sendText(selected, body);
      setDraft("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Envoi impossible.");
    }
  }

  return (
    <div className="stagger-in space-y-6">
      <header>
        <h1 className="font-display text-[32px] font-semibold tracking-tight">Messages</h1>
        <p className="mt-1 text-sm text-muted">Chiffrés par ECDH entre identités NEXUS. Sans pair joignable, rien n'est inventé.</p>
      </header>

      {requests.length > 0 ? (
        <section className="space-y-3">
          <h2 className="font-display text-lg font-semibold">Demandes</h2>
          <ul className="space-y-2">
            {requests.map((req) => (
              <li key={req.id} className="rounded-lg border border-line bg-surface p-4">
                <div className="text-sm font-medium text-fg">{req.fromAlias}</div>
                <div className="mt-1 font-mono text-[11px] text-muted">{req.fromAddress}</div>
                {req.message ? <p className="mt-2 text-sm text-muted">{req.message}</p> : null}
                <div className="mt-3 flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => {
                      acceptRequest(req.id);
                      pushActivity("Contact accepté", req.fromAlias);
                    }}
                  >
                    Accepter
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => removeRequest(req.id)}>
                    Ignorer
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {destinations.length === 0 ? (
        <EmptyState
          icon={Inbox}
          title="Aucun canal ouvert"
          detail="Connectez le mesh, puis écrivez à un pair réellement connecté. Les messages hors ligne restent dans cette boîte s'ils ont déjà été reçus."
        />
      ) : (
        <section className="space-y-3">
          <div className="flex flex-wrap gap-2">
            {destinations.map((peer) => (
              <button
                key={peer.id}
                type="button"
                onClick={() => setTarget(peer.id)}
                className={
                  (selected?.id === peer.id ? "border-accent text-fg" : "border-line text-muted") +
                  " rounded-full border px-3 py-1.5 text-xs"
                }
              >
                {peer.name}
              </button>
            ))}
          </div>
          <div className="min-h-48 space-y-2 rounded-xl border border-line bg-surface p-4">
            {thread.length === 0 ? (
              <p className="text-sm text-muted">Aucun message avec ce pair pour le moment.</p>
            ) : (
              thread.map((msg) => (
                <div key={msg.id} className={msg.direction === "out" ? "text-right" : "text-left"}>
                  <div
                    className={
                      "inline-block max-w-[85%] rounded-lg px-3 py-2 text-sm " +
                      (msg.direction === "out" ? "bg-accent text-accent-fg" : "bg-raised text-fg")
                    }
                  >
                    {msg.body}
                  </div>
                  <div className="mt-1 text-[10px] text-faint">
                    {msg.direction === "out" ? session.username : selected?.name} · {msg.status}
                  </div>
                </div>
              ))
            )}
          </div>
          <Textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Écrire un message réel…"
            rows={3}
          />
          {error ? <p className="text-sm text-danger">{error}</p> : null}
          <Button className="w-full" onClick={() => void send()} disabled={!draft.trim()}>
            Envoyer
          </Button>
        </section>
      )}

      {messages.length > 0 && destinations.length === 0 ? (
        <section className="space-y-2">
          <h2 className="font-display text-lg font-semibold">Historique local</h2>
          <ul className="divide-y divide-line overflow-hidden rounded-lg border border-line bg-surface">
            {messages.slice(-8).reverse().map((msg) => (
              <li key={msg.id} className="px-4 py-3 text-sm">
                <div className="text-fg">{msg.body}</div>
                <div className="text-xs text-muted">
                  {msg.direction === "out" ? "envoyé" : "reçu"} · {msg.status}
                </div>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
