import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CopyField } from "@/components/app/copy-field";
import { useMesh } from "@/components/app/mesh-provider";
import { Button } from "@/components/ui/button";
import { connectionLabel, snapshotNetwork, type NetSnapshot } from "@/lib/nexus/network-info";
import { useNexus } from "@/lib/nexus/session";
import { formatOverlayShort } from "@/lib/nexus/address";

export const Route = createFileRoute("/app/")({ component: HomePage });

function HomePage() {
  const session = useNexus((s) => s.session)!;
  const activity = useNexus((s) => s.activity);
  const mesh = useMesh();
  const [net, setNet] = useState<NetSnapshot | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void snapshotNetwork().then(setNet);
  }, [mesh.joined]);

  const status = net
    ? connectionLabel(net)
    : { headline: "Lecture du réseau…", detail: "Mesure réelle en cours." };

  async function toggle() {
    setBusy(true);
    try {
      if (mesh.enabled) mesh.disconnect();
      else mesh.connect();
      setNet(await snapshotNetwork());
    } finally {
      setBusy(false);
    }
  }

  async function shareAddress() {
    const text = `nexus://contact/${session.address}`;
    if (navigator.share) {
      await navigator.share({ title: "Adresse NEXUS", text }).catch(() => navigator.clipboard.writeText(text));
    } else {
      await navigator.clipboard.writeText(text);
    }
  }

  return (
    <div className="stagger-in space-y-6">
      <header>
        <p className="text-sm text-muted">Bonjour</p>
        <h1 className="font-display text-[32px] font-semibold tracking-tight">{session.username}</h1>
        <p className="mt-1 text-sm text-muted">Votre nœud, sans réglages superflus.</p>
      </header>

      <section className="rounded-xl border border-line bg-surface p-5">
        <p className="text-[11px] font-medium uppercase tracking-wider text-muted">État</p>
        <h2 className="mt-2 font-display text-2xl font-semibold">{mesh.joined ? "Mesh connecté" : status.headline}</h2>
        <p className="mt-1 text-sm text-muted">
          {mesh.joined
            ? `${mesh.connectedCount} pair${mesh.connectedCount > 1 ? "s" : ""} WebRTC · salon ${mesh.peers.length >= 0 ? "actif" : ""}`
            : mesh.error ?? status.detail}
        </p>
        <Button className="mt-5 w-full" onClick={() => void toggle()} disabled={busy}>
          {mesh.enabled ? "Déconnecter" : "Connecter automatiquement"}
        </Button>
        <p className="mt-3 text-xs text-muted">
          NEXUS n'utilise que les chemins réellement disponibles dans ce navigateur.
        </p>
      </section>

      <section className="space-y-3">
        <h2 className="font-display text-lg font-semibold">Adresse personnelle</h2>
        <CopyField label="Overlay NEXUS" value={session.address} />
        <CopyField label="Nom .mesh" value={session.meshName} />
        <Button variant="secondary" className="w-full" onClick={() => void shareAddress()}>
          Partager mon adresse
        </Button>
        <p className="font-mono text-xs text-faint">{formatOverlayShort(session.address)}</p>
      </section>

      <section className="space-y-3">
        <div className="flex items-baseline justify-between">
          <h2 className="font-display text-lg font-semibold">Activité</h2>
          <Link to="/app/network" className="text-xs text-muted hover:text-fg">
            Réseau
          </Link>
        </div>
        {activity.length === 0 ? (
          <p className="rounded-lg border border-line bg-surface px-4 py-5 text-sm text-muted">
            Rien pour l'instant. La connexion, les messages et les fichiers apparaîtront ici.
          </p>
        ) : (
          <ul className="divide-y divide-line overflow-hidden rounded-lg border border-line bg-surface">
            {activity.slice(0, 6).map((event) => (
              <li key={event.id} className="px-4 py-3">
                <div className="text-sm text-fg">{event.title}</div>
                <div className="text-xs text-muted">{event.detail}</div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
