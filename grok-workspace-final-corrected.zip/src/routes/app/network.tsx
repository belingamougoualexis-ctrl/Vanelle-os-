import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { EmptyState } from "@/components/app/empty-state";
import { useMesh } from "@/components/app/mesh-provider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { runHealth, type HealthReport } from "@/lib/nexus/health";
import { useNexus } from "@/lib/nexus/session";
import { Radio } from "lucide-react";

export const Route = createFileRoute("/app/network")({ component: NetworkPage });

function NetworkPage() {
  const mesh = useMesh();
  const settings = useNexus((s) => s.settings);
  const updateSettings = useNexus((s) => s.updateSettings);
  const [code, setCode] = useState(settings.meshCode);
  const [health, setHealth] = useState<HealthReport | null>(null);
  const [healthError, setHealthError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setCode(settings.meshCode);
  }, [settings.meshCode]);

  async function diagnose() {
    setBusy(true);
    setHealthError(null);
    try {
      setHealth(await runHealth({ connectedPeers: mesh.connectedCount }));
    } catch (err) {
      setHealthError(err instanceof Error ? err.message : "Diagnostic impossible.");
    } finally {
      setBusy(false);
    }
  }

  function applyRoom() {
    const next = code.replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 64) || "nexus-mesh";
    updateSettings({ meshCode: next });
    setCode(next);
    if (mesh.enabled) {
      mesh.disconnect();
      window.setTimeout(() => mesh.connect(), 250);
    }
  }

  return (
    <div className="stagger-in space-y-6">
      <header>
        <h1 className="font-display text-[32px] font-semibold tracking-tight">Réseau</h1>
        <p className="mt-1 text-sm text-muted">Chemins réels, pairs WebRTC, diagnostic mesuré.</p>
      </header>

      <section className="rounded-xl border border-line bg-surface p-5">
        <p className="text-[11px] font-medium uppercase tracking-wider text-muted">Chemin</p>
        <h2 className="mt-2 font-display text-xl font-semibold">
          {mesh.joined ? "Canal mesh ouvert" : mesh.enabled ? "Négociation ICE…" : "Mesh arrêté"}
        </h2>
        <p className="mt-1 text-sm text-muted">
          {mesh.error ??
            (mesh.joined
              ? "Le relais n'a servi qu'à la poignée de main. Les données circulent en pair-à-pair."
              : "Appuyez sur Connecter depuis l'accueil pour rejoindre un salon.")}
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <Button variant="secondary" onClick={() => (mesh.enabled ? mesh.disconnect() : mesh.connect())}>
            {mesh.enabled ? "Couper le mesh" : "Ouvrir le mesh"}
          </Button>
          <Button variant="outline" onClick={() => void diagnose()} disabled={busy}>
            {busy ? "Mesure…" : "Vérifier le réseau"}
          </Button>
        </div>
      </section>

      <section className="space-y-3">
        <h2 className="font-display text-lg font-semibold">Salon</h2>
        <p className="text-sm text-muted">
          Un salon public (`nexus-mesh`) permet la découverte. Un code privé limite la visibilité aux personnes qui le
          connaissent.
        </p>
        <label className="block space-y-1.5">
          <Label htmlFor="meshCode">Code de salon</Label>
          <div className="flex gap-2">
            <Input id="meshCode" value={code} onChange={(e) => setCode(e.target.value)} maxLength={64} />
            <Button variant="secondary" onClick={applyRoom}>
              Appliquer
            </Button>
          </div>
        </label>
      </section>

      <section className="space-y-3">
        <h2 className="font-display text-lg font-semibold">Pairs</h2>
        {mesh.peers.length === 0 ? (
          <EmptyState
            icon={Radio}
            title="Aucun pair"
            detail="Personne d'autre n'est actuellement dans ce salon, ou le NAT empêche la connexion directe."
          />
        ) : (
          <ul className="space-y-2">
            {mesh.peers.map((peer) => (
              <li key={peer.id} className="rounded-lg border border-line bg-surface px-4 py-3">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-medium text-fg">{peer.name}</div>
                    <div className="font-mono text-[11px] text-muted">{peer.nodeId ?? peer.id}</div>
                  </div>
                  <span className="text-[11px] uppercase tracking-wide text-muted">{peer.connectionState}</span>
                </div>
                <p className="mt-2 text-xs text-muted">
                  ICE {peer.candidateType ?? "inconnu"}
                  {peer.rttMs != null ? ` · ${peer.rttMs} ms` : ""}
                  {peer.address ? ` · ${peer.address}` : ""}
                </p>
                {peer.connectionState === "connected" ? (
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-3"
                    onClick={() => void mesh.sendContactRequest(peer.id, "Demande de contact NEXUS")}
                  >
                    Demander le contact
                  </Button>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </section>

      {healthError ? <p className="text-sm text-danger">{healthError}</p> : null}
      {health ? (
        <section className="space-y-3">
          <h2 className="font-display text-lg font-semibold">
            Diagnostic · {health.healthy}/{health.checks.length}
          </h2>
          <ul className="divide-y divide-line overflow-hidden rounded-lg border border-line bg-surface">
            {health.checks.map((check) => (
              <li key={check.name} className="flex items-start justify-between gap-4 px-4 py-3">
                <div>
                  <div className="text-sm text-fg">{check.name}</div>
                  <div className="text-xs text-muted">{check.detail}</div>
                </div>
                <span className={check.ok ? "text-xs text-accent" : "text-xs text-danger"}>{check.ok ? "OK" : "ALERTE"}</span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
