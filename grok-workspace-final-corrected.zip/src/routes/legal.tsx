import { createFileRoute, Link } from "@tanstack/react-router";
import { NexusMark } from "@/components/brand/logo";

export const Route = createFileRoute("/legal")({ component: LegalPage });

function LegalPage() {
  return (
    <div className="mx-auto min-h-dvh max-w-2xl px-6 py-12">
      <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted hover:text-fg">
        <NexusMark className="size-6" />
        Retour
      </Link>
      <h1 className="mt-8 font-display text-3xl font-semibold tracking-tight">Conditions et confidentialité</h1>
      <p className="mt-2 text-sm text-muted">NEXUS 2.2.5 · édition navigateur</p>
      <div className="mt-8 space-y-6 text-sm leading-relaxed text-muted">
        <section>
          <h2 className="font-display text-lg font-semibold text-fg">Fonctionnement</h2>
          <p className="mt-2">
            NEXUS fournit une identité cryptographique locale, un carnet d'adresses, une messagerie et un stockage
            adressé par hash. La connexion mesh utilise WebRTC. Un relais de signalisation échange uniquement les
            poignées de main SDP/ICE. Les messages et fichiers circulent ensuite de navigateur à navigateur.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-semibold text-fg">Données</h2>
          <p className="mt-2">
            Le compte, la clé privée chiffrée, les contacts et les messages restent dans le stockage du navigateur.
            Aucun compte cloud n'est requis. Une sauvegarde JSON peut être exportée ; elle reste protégée par votre
            mot de passe.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-semibold text-fg">Participation</h2>
          <p className="mt-2">
            Le mesh, le partage de fichiers et la politique de crédits sont désactivés tant que vous ne les activez
            pas. Les pairs d'un salon public peuvent découvrir votre présence et, via ICE, des adresses IP candidates.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-semibold text-fg">Limites</h2>
          <p className="mt-2">
            NEXUS ne crée ni radio, ni satellite, ni VPN système, ni bande passante. Cette édition navigateur ne
            transporte pas le trafic IP de l'appareil. Une connexion n'existe que si un chemin réseau réel est
            disponible entre les pairs.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-semibold text-fg">Responsabilité</h2>
          <p className="mt-2">
            Vous restez responsable des données que vous transmettez et des salons que vous rejoignez. Aucune
            garantie de disponibilité permanente n'est fournie pour un stockage décentralisé.
          </p>
        </section>
      </div>
    </div>
  );
}
