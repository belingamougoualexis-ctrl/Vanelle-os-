import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Lock, Radio, Shield } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { NexusMark } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { hasConsent, loadVault, setConsent } from "@/lib/nexus/persist";
import { useNexus } from "@/lib/nexus/session";
import { createVault, restoreVault, unlockVault } from "@/lib/nexus/vault";

export const Route = createFileRoute("/")({ component: LandingPage });

type View = "welcome" | "create" | "login" | "restore" | "consent";

function LandingPage() {
  const navigate = useNavigate();
  const hydrate = useNexus((s) => s.hydrate);
  const setSession = useNexus((s) => s.setSession);
  const session = useNexus((s) => s.session);
  const hydrated = useNexus((s) => s.hydrated);
  const [view, setView] = useState<View>("welcome");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const [hasAccount, setHasAccount] = useState(false);

  useEffect(() => {
    hydrate();
    setHasAccount(Boolean(loadVault()));
  }, [hydrate]);

  useEffect(() => {
    if (hydrated && session) {
      if (hasConsent()) void navigate({ to: "/app" });
      else setView("consent");
    }
  }, [hydrated, session, navigate]);

  async function onCreate(form: FormData) {
    setError(null);
    const username = String(form.get("username") ?? "").trim();
    const email = String(form.get("email") ?? "").trim();
    const password = String(form.get("password") ?? "");
    const confirm = String(form.get("confirm") ?? "");
    if (username.length < 2) return setError("Le nom doit contenir au moins 2 caractères.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return setError("Adresse e-mail invalide.");
    if (password.length < 8) return setError("Mot de passe : 8 caractères minimum.");
    if (password !== confirm) return setError("Les mots de passe ne correspondent pas.");
    setPending(true);
    try {
      const unlocked = await createVault({ username, email, password });
      setSession(unlocked);
      setView("consent");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Impossible de créer l'identité.");
    } finally {
      setPending(false);
    }
  }

  async function onLogin(form: FormData) {
    setError(null);
    const email = String(form.get("email") ?? "").trim();
    const password = String(form.get("password") ?? "");
    setPending(true);
    try {
      const unlocked = await unlockVault(email, password);
      setSession(unlocked);
      if (hasConsent()) void navigate({ to: "/app" });
      else setView("consent");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Connexion impossible.");
    } finally {
      setPending(false);
    }
  }

  async function onRestore(file: File, password: string) {
    setError(null);
    setPending(true);
    try {
      const parsed = JSON.parse(await file.text()) as Parameters<typeof restoreVault>[0];
      const unlocked = await restoreVault(parsed, password);
      setSession(unlocked);
      setView("consent");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Restauration impossible.");
    } finally {
      setPending(false);
    }
  }

  if (!hydrated) {
    return <div className="min-h-dvh bg-bg" />;
  }

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[420px] bg-[radial-gradient(ellipse_at_top,rgba(0,201,167,0.08),transparent_60%)]" />
      {view === "welcome" ? <Welcome hasAccount={hasAccount} onCreate={() => setView("create")} onLogin={() => setView("login")} /> : null}
      {view === "create" ? (
        <AuthCard
          title="Créer votre nœud"
          detail="L'identité reste sur cet appareil. Le mot de passe enveloppe la clé privée."
          error={error}
          pending={pending}
          onBack={() => { setError(null); setView("welcome"); }}
          onSubmit={onCreate}
          submitLabel="Créer l'identité"
        >
          <Field name="username" label="Nom" autoComplete="username" />
          <Field name="email" label="E-mail" type="email" autoComplete="email" />
          <Field name="password" label="Mot de passe" type="password" autoComplete="new-password" />
          <Field name="confirm" label="Confirmer" type="password" autoComplete="new-password" />
        </AuthCard>
      ) : null}
      {view === "login" ? (
        <AuthCard
          title="Ouvrir le nœud"
          detail="Déverrouille l'identité NEXUS stockée sur cet appareil."
          error={error}
          pending={pending}
          onBack={() => { setError(null); setView("welcome"); }}
          onSubmit={onLogin}
          submitLabel="Se connecter"
          extra={
            <button type="button" className="text-sm text-muted hover:text-fg" onClick={() => { setError(null); setView("restore"); }}>
              Restaurer une sauvegarde
            </button>
          }
        >
          <Field name="email" label="E-mail" type="email" autoComplete="email" />
          <Field name="password" label="Mot de passe" type="password" autoComplete="current-password" />
        </AuthCard>
      ) : null}
      {view === "restore" ? (
        <RestoreCard
          error={error}
          pending={pending}
          onBack={() => { setError(null); setView("login"); }}
          onRestore={onRestore}
        />
      ) : null}
      {view === "consent" ? (
        <ConsentCard
          onContinue={() => {
            setConsent(true);
            void navigate({ to: "/app" });
          }}
        />
      ) : null}
    </div>
  );
}

function Welcome({ hasAccount, onCreate, onLogin }: { hasAccount: boolean; onCreate: () => void; onLogin: () => void }) {
  return (
    <div className="relative mx-auto flex min-h-dvh w-full max-w-lg flex-col px-6 pb-16 pt-10">
      <header className="stagger-in flex flex-col items-center text-center">
        <NexusMark className="size-16" pulse />
        <p className="mt-6 text-[11px] font-medium tracking-[0.32em] text-muted">NEXUS</p>
        <h1 className="mt-3 font-display text-[34px] font-semibold leading-[1.05] tracking-[-0.03em]">
          Une identité réseau qui vous suit.
        </h1>
        <p className="mt-4 max-w-sm text-[15px] leading-relaxed text-muted">
          Adresse cryptographique, messagerie directe, fichiers vérifiés. Sans compte cloud.
        </p>
        <div className="mt-8 flex w-full flex-col gap-3">
          <Button size="lg" onClick={onCreate}>
            Commencer
            <ArrowRight className="size-4" />
          </Button>
          <Button size="lg" variant="secondary" onClick={onLogin}>
            {hasAccount ? "Ouvrir ce nœud" : "Se connecter"}
          </Button>
        </div>
        <Link to="/legal" className="mt-4 text-xs text-muted hover:text-fg">
          Conditions et confidentialité
        </Link>
      </header>

      <div className="mt-16 space-y-10">
        <Feature
          icon={Shield}
          title="Identité locale"
          detail="Une paire ECDSA P-256 génère votre adresse overlay et votre nom .mesh. La clé privée ne quitte pas l'appareil."
        />
        <Feature
          icon={Radio}
          title="Mesh réel"
          detail="La connexion ouvre des canaux WebRTC. Les messages passent de navigateur à navigateur. Le serveur ne relaie que la poignée de main."
        />
        <Feature
          icon={Lock}
          title="Limites assumées"
          detail="NEXUS n'invente ni radio, ni VPN système, ni bande passante. Il utilise le chemin IP déjà disponible."
        />
      </div>
    </div>
  );
}

function Feature({ icon: Icon, title, detail }: { icon: typeof Shield; title: string; detail: string }) {
  return (
    <section className="flex gap-4">
      <div className="mt-0.5 flex size-10 shrink-0 items-center justify-center rounded-md border border-line bg-surface">
        <Icon className="size-4 text-accent" />
      </div>
      <div>
        <h2 className="font-display text-lg font-semibold">{title}</h2>
        <p className="mt-1 text-sm leading-relaxed text-muted">{detail}</p>
      </div>
    </section>
  );
}

function AuthCard({
  title,
  detail,
  error,
  pending,
  onBack,
  onSubmit,
  submitLabel,
  children,
  extra,
}: {
  title: string;
  detail: string;
  error: string | null;
  pending: boolean;
  onBack: () => void;
  onSubmit: (form: FormData) => void;
  submitLabel: string;
  children: ReactNode;
  extra?: ReactNode;
}) {
  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col justify-center px-6 py-12">
      <button type="button" onClick={onBack} className="mb-8 self-start text-sm text-muted hover:text-fg">
        Retour
      </button>
      <h1 className="font-display text-3xl font-semibold tracking-tight">{title}</h1>
      <p className="mt-2 text-sm text-muted">{detail}</p>
      <form
        className="mt-8 space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          onSubmit(new FormData(e.currentTarget));
        }}
      >
        {children}
        {error ? <p className="text-sm text-danger">{error}</p> : null}
        <Button type="submit" className="w-full" disabled={pending}>
          {pending ? "Traitement…" : submitLabel}
        </Button>
        {extra ? <div className="text-center">{extra}</div> : null}
      </form>
    </div>
  );
}

function Field({ name, label, type = "text", autoComplete }: { name: string; label: string; type?: string; autoComplete?: string }) {
  return (
    <label className="block space-y-1.5">
      <Label htmlFor={name}>{label}</Label>
      <Input id={name} name={name} type={type} autoComplete={autoComplete} required />
    </label>
  );
}

function RestoreCard({
  error,
  pending,
  onBack,
  onRestore,
}: {
  error: string | null;
  pending: boolean;
  onBack: () => void;
  onRestore: (file: File, password: string) => void;
}) {
  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col justify-center px-6 py-12">
      <button type="button" onClick={onBack} className="mb-8 self-start text-sm text-muted hover:text-fg">
        Retour
      </button>
      <h1 className="font-display text-3xl font-semibold tracking-tight">Restaurer</h1>
      <p className="mt-2 text-sm text-muted">Importez un fichier d'identité NEXUS exporté depuis cet appareil ou un autre navigateur.</p>
      <form
        className="mt-8 space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          const form = new FormData(e.currentTarget);
          const file = form.get("file");
          if (!(file instanceof File) || file.size === 0) return;
          onRestore(file, String(form.get("password") ?? ""));
        }}
      >
        <label className="block space-y-1.5">
          <Label htmlFor="file">Fichier .json</Label>
          <Input id="file" name="file" type="file" accept="application/json,.json" required />
        </label>
        <Field name="password" label="Mot de passe" type="password" autoComplete="current-password" />
        {error ? <p className="text-sm text-danger">{error}</p> : null}
        <Button type="submit" className="w-full" disabled={pending}>
          {pending ? "Restauration…" : "Restaurer l'identité"}
        </Button>
      </form>
    </div>
  );
}

function ConsentCard({ onContinue }: { onContinue: () => void }) {
  const [accepted, setAccepted] = useState(false);
  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col justify-center px-6 py-12">
      <h1 className="font-display text-3xl font-semibold tracking-tight">Votre appareil, vos choix.</h1>
      <p className="mt-3 text-sm leading-relaxed text-muted">
        NEXUS reste local par défaut. Le mesh, le stockage et le relais ne s'activent que si vous les allumez.
      </p>
      <ul className="mt-8 space-y-4 text-sm text-muted">
        <li className="rounded-lg border border-line bg-surface p-4">
          <div className="font-medium text-fg">Utiliser NEXUS</div>
          Créer une identité, diagnostiquer le réseau, stocker des fichiers sur cet appareil.
        </li>
        <li className="rounded-lg border border-line bg-surface p-4">
          <div className="font-medium text-fg">Rejoindre un mesh</div>
          Les pairs voient votre adresse IP via ICE. Ne connectez que des salons auxquels vous faites confiance.
        </li>
      </ul>
      <label className="mt-6 flex items-start gap-3 text-sm text-fg">
        <input
          type="checkbox"
          className="mt-1 size-4 accent-accent"
          checked={accepted}
          onChange={(e) => setAccepted(e.target.checked)}
        />
        J'ai lu et j'accepte les conditions de participation NEXUS.
      </label>
      <Button className="mt-6" disabled={!accepted} onClick={onContinue}>
        Continuer
      </Button>
      <Link to="/legal" className="mt-4 text-center text-xs text-muted hover:text-fg">
        Lire les conditions
      </Link>
    </div>
  );
}
