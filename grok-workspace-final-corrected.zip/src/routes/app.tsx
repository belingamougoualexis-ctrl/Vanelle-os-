import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { AppShell } from "@/components/app/shell";
import { MeshProvider } from "@/components/app/mesh-provider";
import { hasConsent } from "@/lib/nexus/persist";
import { useNexus } from "@/lib/nexus/session";

export const Route = createFileRoute("/app")({
  component: AppLayout,
});

function AppLayout() {
  const hydrate = useNexus((s) => s.hydrate);
  const hydrated = useNexus((s) => s.hydrated);
  const session = useNexus((s) => s.session);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  if (!hydrated) return <div className="min-h-dvh bg-bg" />;
  if (!session) return <Navigate to="/" />;
  if (!hasConsent()) return <Navigate to="/" />;

  return (
    <MeshProvider>
      <AppShell />
    </MeshProvider>
  );
}
