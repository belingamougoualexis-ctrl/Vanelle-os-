import type {
  ActivityEvent,
  ChatMessage,
  Contact,
  ContentRecord,
  CreditReceipt,
  NexusSettingsState,
  PeerRequest,
  VaultFile,
} from "./types";
import { DEFAULT_SETTINGS } from "./types";

const KEYS = {
  vault: "nexus.vault",
  settings: "nexus.settings",
  contacts: "nexus.contacts",
  requests: "nexus.requests",
  messages: "nexus.messages",
  activity: "nexus.activity",
  credits: "nexus.credits",
  receipts: "nexus.receipts",
  contents: "nexus.contents",
  names: "nexus.names",
  consent: "nexus.consent",
  tour: "nexus.tour",
  session: "nexus.session",
} as const;

function canUseStorage(): boolean {
  return typeof window !== "undefined" && typeof localStorage !== "undefined";
}

function readJson<T>(key: string, fallback: T): T {
  if (!canUseStorage()) return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown) {
  if (!canUseStorage()) return;
  localStorage.setItem(key, JSON.stringify(value));
}

export function loadVault(): VaultFile | null {
  return readJson<VaultFile | null>(KEYS.vault, null);
}

export function saveVault(vault: VaultFile) {
  writeJson(KEYS.vault, vault);
}

export function clearVault() {
  if (!canUseStorage()) return;
  localStorage.removeItem(KEYS.vault);
}

export function loadSettings(): NexusSettingsState {
  return { ...DEFAULT_SETTINGS, ...readJson<Partial<NexusSettingsState>>(KEYS.settings, {}) };
}

export function saveSettings(settings: NexusSettingsState) {
  writeJson(KEYS.settings, settings);
}

export function loadContacts(): Contact[] {
  return readJson<Contact[]>(KEYS.contacts, []);
}

export function saveContacts(contacts: Contact[]) {
  writeJson(KEYS.contacts, contacts.slice(-500));
}

export function loadRequests(): PeerRequest[] {
  return readJson<PeerRequest[]>(KEYS.requests, []);
}

export function saveRequests(requests: PeerRequest[]) {
  writeJson(KEYS.requests, requests.slice(-200));
}

export function loadMessages(): ChatMessage[] {
  return readJson<ChatMessage[]>(KEYS.messages, []);
}

export function saveMessages(messages: ChatMessage[]) {
  writeJson(KEYS.messages, messages.slice(-1000));
}

export function loadActivity(): ActivityEvent[] {
  return readJson<ActivityEvent[]>(KEYS.activity, []);
}

export function saveActivity(events: ActivityEvent[]) {
  writeJson(KEYS.activity, events.slice(0, 80));
}

export function loadCredits(): { balance: number; relayRemainder: number; useRemainder: number } {
  return readJson(KEYS.credits, { balance: 0, relayRemainder: 0, useRemainder: 0 });
}

export function saveCredits(state: { balance: number; relayRemainder: number; useRemainder: number }) {
  writeJson(KEYS.credits, state);
}

export function loadReceipts(): CreditReceipt[] {
  return readJson<CreditReceipt[]>(KEYS.receipts, []);
}

export function saveReceipts(receipts: CreditReceipt[]) {
  writeJson(KEYS.receipts, receipts.slice(-200));
}

export function loadContentIndex(): ContentRecord[] {
  return readJson<ContentRecord[]>(KEYS.contents, []);
}

export function saveContentIndex(records: ContentRecord[]) {
  writeJson(KEYS.contents, records.slice(-400));
}

export function hasConsent(): boolean {
  return readJson(KEYS.consent, false);
}

export function setConsent(value: boolean) {
  writeJson(KEYS.consent, value);
}

export function tourCompleted(): boolean {
  return readJson(KEYS.tour, false);
}

export function setTourCompleted() {
  writeJson(KEYS.tour, true);
}

export function resetTour() {
  writeJson(KEYS.tour, false);
}

export function saveSessionBlob(blob: string) {
  if (typeof sessionStorage === "undefined") return;
  sessionStorage.setItem(KEYS.session, blob);
}

export function loadSessionBlob(): string | null {
  if (typeof sessionStorage === "undefined") return null;
  return sessionStorage.getItem(KEYS.session);
}

export function clearSessionBlob() {
  if (typeof sessionStorage === "undefined") return;
  sessionStorage.removeItem(KEYS.session);
}
