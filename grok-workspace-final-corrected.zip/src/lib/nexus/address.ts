import { sha256Bytes, toArrayBuffer, utf8 } from "./bytes.ts";

export const ULA_PREFIX = "fd00:4e58:5553";

export function parseIpv6Groups(value: string): number[] | null {
  const raw = value.trim().toLowerCase().split("%")[0] ?? "";
  if (!raw.includes(":")) return null;
  const [head, tail] = raw.split("::");
  const left = head ? head.split(":").filter(Boolean) : [];
  const right = tail !== undefined ? (tail ? tail.split(":").filter(Boolean) : []) : [];
  if (tail === undefined && left.length !== 8) {
    if (raw.split(":").length !== 8) return null;
  }
  const missing = 8 - left.length - right.length;
  if (tail !== undefined && missing < 1 && !(left.length + right.length === 8)) return null;
  if (tail === undefined && left.length !== 8) return null;
  const zeros = tail !== undefined ? Array.from({ length: Math.max(missing, 0) }, () => "0") : [];
  const parts = [...left, ...zeros, ...right];
  if (parts.length !== 8) return null;
  const groups: number[] = [];
  for (const part of parts) {
    if (!/^[0-9a-f]{1,4}$/.test(part)) return null;
    groups.push(parseInt(part, 16));
  }
  return groups;
}

export function canonicalizeIPv6(value: string): string {
  const groups = parseIpv6Groups(value);
  if (!groups) return value.trim().toLowerCase().split("%")[0] ?? value;
  let bestStart = -1;
  let bestLen = 0;
  let curStart = -1;
  let curLen = 0;
  for (let i = 0; i <= 8; i++) {
    if (i < 8 && groups[i] === 0) {
      if (curStart < 0) curStart = i;
      curLen += 1;
    } else {
      if (curLen > bestLen) {
        bestStart = curStart;
        bestLen = curLen;
      }
      curStart = -1;
      curLen = 0;
    }
  }
  const hextets = groups.map((g) => g.toString(16));
  if (bestLen >= 2) {
    const left = hextets.slice(0, bestStart).join(":");
    const right = hextets.slice(bestStart + bestLen).join(":");
    return `${left}::${right}`.replace(/^:$/, "::");
  }
  return hextets.join(":");
}

export function isValidOverlay(value: string): boolean {
  const canonical = canonicalizeIPv6(value);
  const groups = parseIpv6Groups(canonical);
  if (!groups) return false;
  return (
    groups[0] === 0xfd00 &&
    groups[1] === 0x4e58 &&
    groups[2] === 0x5553
  );
}

export async function overlayIpv6FromPublicKey(publicKeyB64: string): Promise<string> {
  const digest = await sha256Bytes(toArrayBuffer(utf8(publicKeyB64)));
  const groups: string[] = [];
  for (let i = 0; i < 5; i++) {
    const value = (digest[i * 2]! << 8) | digest[i * 2 + 1]!;
    groups.push(value.toString(16).padStart(4, "0"));
  }
  return canonicalizeIPv6(`${ULA_PREFIX}:${groups.join(":")}`);
}

export function formatOverlayShort(address: string): string {
  const canonical = canonicalizeIPv6(address);
  if (canonical.length <= 22) return canonical;
  return `${canonical.slice(0, 14)}…${canonical.slice(-8)}`;
}
