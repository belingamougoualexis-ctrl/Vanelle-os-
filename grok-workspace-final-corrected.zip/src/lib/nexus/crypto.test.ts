import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { overlayIpv6FromPublicKey, isValidOverlay } from "./address.ts";
import {
  decryptFromPeer,
  encryptForPeer,
  generateIdentityKeys,
  meshNameFromPublic,
  signCanonical,
  unwrapPayload,
  verifyCanonical,
  wrapPayload,
} from "./crypto.ts";

describe("NEXUS identity crypto", () => {
  it("wraps and unwraps a payload with a password", async () => {
    const packed = await wrapPayload("correct horse", "secret-json");
    const plain = await unwrapPayload("correct horse", packed);
    assert.equal(plain, "secret-json");
    await assert.rejects(() => unwrapPayload("wrong", packed));
  });

  it("signs, verifies, and encrypts between two identities", async () => {
    const a = await generateIdentityKeys();
    const b = await generateIdentityKeys();
    const sig = await signCanonical(a.privateJwk, "hello-nexus");
    assert.equal(await verifyCanonical(a.publicSpkiB64, "hello-nexus", sig), true);
    assert.equal(await verifyCanonical(b.publicSpkiB64, "hello-nexus", sig), false);

    const packed = await encryptForPeer(a.privateJwk, b.publicSpkiB64, "ping");
    const plain = await decryptFromPeer(b.privateJwk, a.publicSpkiB64, packed);
    assert.equal(plain, "ping");

    const address = await overlayIpv6FromPublicKey(a.publicSpkiB64);
    const name = await meshNameFromPublic(a.publicSpkiB64);
    assert.equal(isValidOverlay(address), true);
    assert.match(name, /^[0-9a-f]{24}\.mesh$/);
  });
});
