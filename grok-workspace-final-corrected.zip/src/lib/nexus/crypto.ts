import {
  b64urlToBytes,
  bytesToB64url,
  bytesToHex,
  randomBytes,
  toArrayBuffer,
  utf8,
  sha256Bytes,
} from "./bytes.ts";

const VAULT_PBKDF2_ITERATIONS = 210_000;
const VAULT_SALT_BYTES = 16;
const AES_GCM_IV_BYTES = 12;
const AES_GCM_TAG_BYTES = 16;

function asEcdsaPrivateJwk(privateJwk: JsonWebKey): JsonWebKey {
  const { alg: _alg, key_ops: _ops, ext: _ext, ...rest } = privateJwk;
  return { ...rest, key_ops: ["sign"] };
}

async function importEcdsaPrivate(privateJwk: JsonWebKey): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    "jwk",
    asEcdsaPrivateJwk(privateJwk),
    { name: "ECDSA", namedCurve: "P-256" },
    false,
    ["sign"],
  );
}

export async function generateIdentityKeys(): Promise<{
  privateJwk: JsonWebKey;
  publicJwk: JsonWebKey;
  publicSpkiB64: string;
}> {
  const pair = (await crypto.subtle.generateKey(
    { name: "ECDSA", namedCurve: "P-256" },
    true,
    ["sign", "verify"],
  )) as CryptoKeyPair;

  const [privateJwk, publicJwk, publicSpki] = await Promise.all([
    crypto.subtle.exportKey("jwk", pair.privateKey),
    crypto.subtle.exportKey("jwk", pair.publicKey),
    crypto.subtle.exportKey("spki", pair.publicKey),
  ]);

  return {
    privateJwk,
    publicJwk,
    publicSpkiB64: bytesToB64url(new Uint8Array(publicSpki)),
  };
}

export async function importEcdsaPublicSpki(spkiB64: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    "spki",
    toArrayBuffer(b64urlToBytes(spkiB64)),
    { name: "ECDSA", namedCurve: "P-256" },
    true,
    ["verify"],
  );
}

export async function signCanonical(privateJwk: JsonWebKey, canonical: string): Promise<string> {
  const key = await importEcdsaPrivate(privateJwk);
  const sig = new Uint8Array(
    await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key, toArrayBuffer(utf8(canonical))),
  );
  return bytesToB64url(sig);
}

export async function verifyCanonical(
  publicSpkiB64: string,
  canonical: string,
  signatureB64: string,
): Promise<boolean> {
  try {
    const key = await importEcdsaPublicSpki(publicSpkiB64);
    return crypto.subtle.verify(
      { name: "ECDSA", hash: "SHA-256" },
      key,
      toArrayBuffer(b64urlToBytes(signatureB64)),
      toArrayBuffer(utf8(canonical)),
    );
  } catch {
    return false;
  }
}

export async function ecdhSharedBits(privateJwk: JsonWebKey, peerPublicSpkiB64: string): Promise<Uint8Array> {
  const { alg: _alg, key_ops: _ops, ext: _ext, ...rest } = privateJwk;
  const ecdhPriv = await crypto.subtle.importKey(
    "jwk",
    { ...rest, key_ops: ["deriveBits"] },
    { name: "ECDH", namedCurve: "P-256" },
    false,
    ["deriveBits"],
  );
  const ecdhPub = await crypto.subtle.importKey(
    "spki",
    toArrayBuffer(b64urlToBytes(peerPublicSpkiB64)),
    { name: "ECDH", namedCurve: "P-256" },
    false,
    [],
  );
  return new Uint8Array(
    await crypto.subtle.deriveBits({ name: "ECDH", public: ecdhPub }, ecdhPriv, 256),
  );
}

export async function encryptForPeer(
  privateJwk: JsonWebKey,
  peerPublicSpkiB64: string,
  plaintext: string,
): Promise<{ iv: string; ct: string }> {
  const shared = await ecdhSharedBits(privateJwk, peerPublicSpkiB64);
  const aes = await crypto.subtle.importKey("raw", toArrayBuffer(shared), "AES-GCM", false, ["encrypt"]);
  const iv = randomBytes(AES_GCM_IV_BYTES);
  const ct = new Uint8Array(
    await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: toArrayBuffer(iv) },
      aes,
      toArrayBuffer(utf8(plaintext)),
    ),
  );
  return { iv: bytesToB64url(iv), ct: bytesToB64url(ct) };
}

export async function decryptFromPeer(
  privateJwk: JsonWebKey,
  peerPublicSpkiB64: string,
  packed: { iv: string; ct: string },
): Promise<string> {
  const shared = await ecdhSharedBits(privateJwk, peerPublicSpkiB64);
  const aes = await crypto.subtle.importKey("raw", toArrayBuffer(shared), "AES-GCM", false, ["decrypt"]);
  const iv = b64urlToBytes(packed.iv);
  const ciphertext = b64urlToBytes(packed.ct);
  if (iv.length !== AES_GCM_IV_BYTES) throw new Error("IV AES-GCM invalide.");
  if (ciphertext.length < AES_GCM_TAG_BYTES) throw new Error("Chiffrement AES-GCM invalide.");
  const pt = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: toArrayBuffer(iv) },
    aes,
    toArrayBuffer(ciphertext),
  );
  return new TextDecoder().decode(pt);
}

async function passwordKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
  const material = await crypto.subtle.importKey(
    "raw",
    toArrayBuffer(utf8(password)),
    "PBKDF2",
    false,
    ["deriveKey"],
  );
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: toArrayBuffer(salt),
      iterations: VAULT_PBKDF2_ITERATIONS,
      hash: "SHA-256",
    },
    material,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"],
  );
}

export async function wrapPayload(
  password: string,
  plaintext: string,
): Promise<{ salt: string; iv: string; ct: string }> {
  if (password.length === 0) throw new Error("Mot de passe requis.");
  const salt = randomBytes(VAULT_SALT_BYTES);
  const iv = randomBytes(AES_GCM_IV_BYTES);
  const key = await passwordKey(password, salt);
  const ct = new Uint8Array(
    await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: toArrayBuffer(iv) },
      key,
      toArrayBuffer(utf8(plaintext)),
    ),
  );
  return {
    salt: bytesToB64url(salt),
    iv: bytesToB64url(iv),
    ct: bytesToB64url(ct),
  };
}

export async function unwrapPayload(
  password: string,
  packed: { salt: string; iv: string; ct: string },
): Promise<string> {
  if (password.length === 0) throw new Error("Mot de passe requis.");
  const salt = b64urlToBytes(packed.salt);
  const iv = b64urlToBytes(packed.iv);
  const ciphertext = b64urlToBytes(packed.ct);
  if (salt.length !== VAULT_SALT_BYTES) throw new Error("Sel PBKDF2 invalide.");
  if (iv.length !== AES_GCM_IV_BYTES) throw new Error("IV AES-GCM invalide.");
  if (ciphertext.length < AES_GCM_TAG_BYTES) throw new Error("Chiffrement AES-GCM invalide.");
  const key = await passwordKey(password, salt);
  const plaintext = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: toArrayBuffer(iv) },
    key,
    toArrayBuffer(ciphertext),
  );
  return new TextDecoder().decode(plaintext);
}

export async function fingerprintFromPublic(publicSpkiB64: string): Promise<string> {
  const digest = await sha256Bytes(toArrayBuffer(b64urlToBytes(publicSpkiB64)));
  return bytesToHex(digest).match(/.{1,2}/g)!.join(":").toUpperCase();
}

export async function meshNameFromPublic(publicSpkiB64: string): Promise<string> {
  const digest = await sha256Bytes(toArrayBuffer(b64urlToBytes(publicSpkiB64)));
  return `${bytesToHex(digest.slice(0, 12)).toLowerCase()}.mesh`;
}

export function randomNodeId(): string {
  return `NX-${bytesToHex(randomBytes(8)).toUpperCase()}`;
}
