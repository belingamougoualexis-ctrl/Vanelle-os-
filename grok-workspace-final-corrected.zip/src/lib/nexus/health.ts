import { loadContentIndex, loadSettings, loadVault } from "./persist";
import { snapshotNetwork, type NetSnapshot } from "./network-info";
import { creditBalance } from "./credits";
import { usedBytes } from "./content-db";

export type HealthCheck = {
  name: string;
  ok: boolean;
  detail: string;
};

export type HealthReport = {
  checks: HealthCheck[];
  network: NetSnapshot;
  healthy: number;
  issues: number;
};

export async function runHealth(input?: { nodeId?: string; connectedPeers?: number }): Promise<HealthReport> {
  const network = await snapshotNetwork();
  const settings = loadSettings();
  const vault = loadVault();
  const contents = loadContentIndex();
  const used = typeof indexedDB === "undefined" ? 0 : await usedBytes().catch(() => 0);
  const quota = settings.storageQuotaMb * 1024 * 1024;
  const battery = await batteryPercent();

  const checks: HealthCheck[] = [
    {
      name: "Connectivité",
      ok: network.online,
      detail: network.online ? "navigateur en ligne" : "aucun réseau actif",
    },
    {
      name: "Validation Internet",
      ok: !network.online || network.internet !== "no",
      detail:
        network.internet === "yes"
          ? "requête publique réussie"
          : network.internet === "no"
            ? "endpoint public injoignable"
            : "non confirmée",
    },
    {
      name: "Identité NEXUS",
      ok: Boolean(vault?.identity.nodeId.startsWith("NX-")),
      detail: vault ? `nœud ${vault.identity.nodeId}` : "aucune identité locale",
    },
    {
      name: "Quota stockage",
      ok: used <= quota,
      detail: `${Math.round(used / (1024 * 1024))} MiB utilisés / ${settings.storageQuotaMb} MiB`,
    },
    {
      name: "Contenus locaux",
      ok: true,
      detail: `${contents.length} objet(s) indexé(s)`,
    },
    {
      name: "Crédits",
      ok: true,
      detail: `${creditBalance()} crédit(s) · comptabilité locale, pas une monnaie`,
    },
    {
      name: "Batterie",
      ok: battery === null || battery >= 15,
      detail: battery === null ? "niveau non disponible dans ce navigateur" : `${battery} %`,
    },
    {
      name: "Pairs mesh",
      ok: true,
      detail:
        input?.connectedPeers != null
          ? `${input.connectedPeers} pair(s) WebRTC connecté(s)`
          : "mesh non démarré",
    },
  ];

  return {
    checks,
    network,
    healthy: checks.filter((c) => c.ok).length,
    issues: checks.filter((c) => !c.ok).length,
  };
}

async function batteryPercent(): Promise<number | null> {
  try {
    const nav = navigator as Navigator & { getBattery?: () => Promise<{ level: number }> };
    if (!nav.getBattery) return null;
    const battery = await nav.getBattery();
    return Math.round(battery.level * 100);
  } catch {
    return null;
  }
}
