export type Contact = {
  id: string;
  alias: string;
  address: string;
  publicKey?: string;
  nodeId?: string;
  createdAt: number;
};

export type PeerRequest = {
  id: string;
  fromAlias: string;
  fromAddress: string;
  fromNodeId: string;
  fromPublicKey: string;
  message: string;
  createdAt: number;
  signature: string;
};

export type ChatMessage = {
  id: string;
  peerAddress: string;
  direction: "in" | "out";
  body: string;
  createdAt: number;
  status: "sent" | "queued" | "delivered" | "failed";
};

export type ActivityEvent = {
  id: string;
  at: number;
  title: string;
  detail: string;
};

export type ContentRecord = {
  id: string;
  name: string;
  hash: string;
  size: number;
  createdAt: number;
  pinned: boolean;
};

export type CreditReceipt = {
  id: string;
  kind: "relay" | "use";
  peerId: string;
  bytes: number;
  credits: number;
  at: number;
};

export type NexusSettingsState = {
  transitEnabled: boolean;
  storageEnabled: boolean;
  creditsEnforced: boolean;
  trustedOnly: boolean;
  presenceSharing: boolean;
  storageQuotaMb: number;
  meshCode: string;
};

export const DEFAULT_SETTINGS: NexusSettingsState = {
  transitEnabled: false,
  storageEnabled: false,
  creditsEnforced: false,
  trustedOnly: false,
  presenceSharing: true,
  storageQuotaMb: 256,
  meshCode: "nexus-mesh",
};

export type IdentityRecord = {
  nodeId: string;
  username: string;
  email: string;
  publicSpkiB64: string;
  address: string;
  fingerprint: string;
  meshName: string;
  createdAt: number;
};

export type VaultFile = {
  version: 1;
  identity: Omit<IdentityRecord, "address" | "fingerprint" | "meshName"> & {
    address?: string;
  };
  publicJwk: JsonWebKey;
  wrap: { salt: string; iv: string; ct: string };
};

export type UnlockedSession = IdentityRecord & {
  publicJwk: JsonWebKey;
  privateJwk: JsonWebKey;
};

export type RemotePeer = {
  id: string;
  name: string;
  nodeId?: string;
  address?: string;
  publicKey?: string;
  meshName?: string;
  connectionState: RTCPeerConnectionState;
  candidateType: string | null;
  rttMs: number | null;
};
