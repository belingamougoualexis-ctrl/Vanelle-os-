import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { canonicalizeIPv6, isValidOverlay, overlayIpv6FromPublicKey, parseIpv6Groups } from "./address.ts";

describe("NEXUS overlay address", () => {
  it("canonicalizes uncompressed IPv6", () => {
    assert.equal(
      canonicalizeIPv6("fd00:4e58:5553:0001:0000:0000:0000:0002"),
      "fd00:4e58:5553:1::2",
    );
  });

  it("accepts only the NEXUS ULA prefix", () => {
    assert.equal(isValidOverlay("fd00:4e58:5553:1::2"), true);
    assert.equal(isValidOverlay("2001:db8::1"), false);
    assert.equal(isValidOverlay("not-an-ip"), false);
  });

  it("parses eight groups", () => {
    const groups = parseIpv6Groups("fd00:4e58:5553:1::2");
    assert.ok(groups);
    assert.equal(groups.length, 8);
    assert.equal(groups[0], 0xfd00);
    assert.equal(groups[1], 0x4e58);
    assert.equal(groups[2], 0x5553);
  });

  it("derives a stable overlay from a public key", async () => {
    const first = await overlayIpv6FromPublicKey("test-public-key");
    const second = await overlayIpv6FromPublicKey("test-public-key");
    assert.equal(first, second);
    assert.equal(isValidOverlay(first), true);
  });
});
