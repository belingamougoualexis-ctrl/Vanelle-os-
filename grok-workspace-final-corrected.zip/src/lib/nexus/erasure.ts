/** 2+1 XOR erasure coding. Any one missing shard can reconstruct the original. */

export type Stripe = {
  originalSize: number;
  shardSize: number;
  dataA: Uint8Array;
  dataB: Uint8Array;
  parity: Uint8Array;
};

function xor(a: Uint8Array, b: Uint8Array): Uint8Array {
  if (a.length !== b.length) throw new Error("Fragments incompatibles");
  const out = new Uint8Array(a.length);
  for (let i = 0; i < a.length; i++) out[i] = a[i]! ^ b[i]!;
  return out;
}

export function encodeStripe(input: Uint8Array): Stripe {
  if (input.length === 0) throw new Error("Donnée vide");
  const shardSize = Math.ceil(input.length / 2);
  const dataA = new Uint8Array(shardSize);
  const dataB = new Uint8Array(shardSize);
  dataA.set(input.subarray(0, Math.min(shardSize, input.length)));
  dataB.set(input.subarray(Math.min(shardSize, input.length)));
  return {
    originalSize: input.length,
    shardSize,
    dataA,
    dataB,
    parity: xor(dataA, dataB),
  };
}

export function recoverStripe(
  stripe: Pick<Stripe, "originalSize" | "shardSize">,
  dataA: Uint8Array | null,
  dataB: Uint8Array | null,
  parity: Uint8Array | null,
): Uint8Array {
  const present = [dataA, dataB, parity].filter(Boolean).length;
  if (present < 2) throw new Error("Deux fragments minimum sont nécessaires");
  const a = dataA ?? xor(dataB!, parity!);
  const b = dataB ?? xor(dataA!, parity!);
  const output = new Uint8Array(stripe.originalSize);
  output.set(a.subarray(0, Math.min(a.length, output.length)));
  if (output.length > stripe.shardSize) {
    output.set(b.subarray(0, output.length - stripe.shardSize), stripe.shardSize);
  }
  return output;
}
