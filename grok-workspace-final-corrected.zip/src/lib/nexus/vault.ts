import { overlayIpv6FromPublicKey } from "./address";
import { fingerprintFromPublic, generateIdentityKeys, meshNameFromPublic, randomNodeId, unwrapPayload, wrapPayload } from "./crypto";
import { loadSessionBlob, loadVault, saveSessionBlob, saveVault } from "./persist";
import type { UnlockedSession, VaultFile } from "./types";

export async function createVault(input: {
  username: string;
  email: string;
  password: string;
}): Promise<UnlockedSession> {
  const keys = await generateIdentityKeys();
  const nodeId = randomNodeId();
  const createdAt = Date.now();
  const wrap = await wrapPayload(input.password, JSON.stringify(keys.privateJwk));
  const vault: VaultFile = {
    version: 1,
    identity: {
      nodeId,
      username: input.username.trim(),
      email: input.email.trim().toLowerCase(),
      publicSpkiB64: keys.publicSpkiB64,
      createdAt,
    },
    publicJwk: keys.publicJwk,
    wrap,
  };
  saveVault(vault);
  return hydrateSession(vault, keys.privateJwk);
}

export async function unlockVault(email: string, password: string): Promise<UnlockedSession> {
  const vault = loadVault();
  if (!vault) throw new Error("Aucun compte NEXUS sur cet appareil.");
  if (vault.identity.email !== email.trim().toLowerCase()) {
    throw new Error("Adresse e-mail ou mot de passe incorrect.");
  }
  try {
    const raw = await unwrapPayload(password, vault.wrap);
    const privateJwk = JSON.parse(raw) as JsonWebKey;
    return hydrateSession(vault, privateJwk);
  } catch {
    throw new Error("Adresse e-mail ou mot de passe incorrect.");
  }
}

export async function restoreVault(file: VaultFile, password: string): Promise<UnlockedSession> {
  if (file.version !== 1 || !file.wrap || !file.identity?.email) {
    throw new Error("Fichier d'identité NEXUS invalide.");
  }
  const raw = await unwrapPayload(password, file.wrap);
  const privateJwk = JSON.parse(raw) as JsonWebKey;
  saveVault(file);
  return hydrateSession(file, privateJwk);
}

export function exportVault(): VaultFile {
  const vault = loadVault();
  if (!vault) throw new Error("Aucun compte à exporter.");
  return vault;
}

async function hydrateSession(vault: VaultFile, privateJwk: JsonWebKey): Promise<UnlockedSession> {
  const address = await overlayIpv6FromPublicKey(vault.identity.publicSpkiB64);
  const fingerprint = await fingerprintFromPublic(vault.identity.publicSpkiB64);
  const meshName = await meshNameFromPublic(vault.identity.publicSpkiB64);
  const session: UnlockedSession = {
    nodeId: vault.identity.nodeId,
    username: vault.identity.username,
    email: vault.identity.email,
    publicSpkiB64: vault.identity.publicSpkiB64,
    createdAt: vault.identity.createdAt,
    address,
    fingerprint,
    meshName,
    publicJwk: vault.publicJwk,
    privateJwk,
  };
  saveSessionBlob(JSON.stringify(session));
  return session;
}

export function restoreSessionFromMemory(): UnlockedSession | null {
  const blob = loadSessionBlob();
  if (!blob) return null;
  try {
    return JSON.parse(blob) as UnlockedSession;
  } catch {
    return null;
  }
}
