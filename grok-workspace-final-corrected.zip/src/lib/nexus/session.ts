import { create } from "zustand";
import { canonicalizeIPv6, isValidOverlay } from "./address";
import { applyRelayCredits } from "./credits";
import {
  clearSessionBlob,
  loadActivity,
  loadContacts,
  loadMessages,
  loadRequests,
  loadSettings,
  resetTour,
  saveActivity,
  saveContacts,
  saveMessages,
  saveRequests,
  saveSettings,
  setConsent,
} from "./persist";
import { restoreSessionFromMemory } from "./vault";
import type {
  ActivityEvent,
  ChatMessage,
  Contact,
  NexusSettingsState,
  PeerRequest,
  UnlockedSession,
} from "./types";

type SessionState = {
  hydrated: boolean;
  session: UnlockedSession | null;
  settings: NexusSettingsState;
  contacts: Contact[];
  requests: PeerRequest[];
  messages: ChatMessage[];
  activity: ActivityEvent[];
  connected: boolean;
  hydrate: () => void;
  setSession: (session: UnlockedSession) => void;
  lock: () => void;
  updateSettings: (patch: Partial<NexusSettingsState>) => void;
  addContact: (contact: Omit<Contact, "id" | "createdAt"> & { id?: string }) => Contact;
  removeContact: (id: string) => void;
  addRequest: (request: PeerRequest) => void;
  removeRequest: (id: string) => void;
  addMessage: (message: ChatMessage) => void;
  markDelivered: (id: string) => void;
  pushActivity: (title: string, detail: string) => void;
  setConnected: (value: boolean) => void;
  acceptRequest: (id: string) => Contact | null;
};

function uid(): string {
  return crypto.randomUUID().replaceAll("-", "").slice(0, 20);
}

export const useNexus = create<SessionState>((set, get) => ({
  hydrated: false,
  session: null,
  settings: loadSettings(),
  contacts: [],
  requests: [],
  messages: [],
  activity: [],
  connected: false,
  hydrate: () => {
    set({
      hydrated: true,
      session: restoreSessionFromMemory(),
      settings: loadSettings(),
      contacts: loadContacts(),
      requests: loadRequests(),
      messages: loadMessages(),
      activity: loadActivity(),
    });
  },
  setSession: (session) => set({ session }),
  lock: () => {
    clearSessionBlob();
    set({ session: null, connected: false });
  },
  updateSettings: (patch) => {
    const settings = { ...get().settings, ...patch };
    saveSettings(settings);
    set({ settings });
  },
  addContact: (input) => {
    const address = canonicalizeIPv6(input.address);
    if (!isValidOverlay(address)) throw new Error("Adresse NEXUS invalide.");
    const alias = input.alias.trim().slice(0, 80);
    if (alias.length < 1) throw new Error("Nom du contact requis.");
    const existing = get().contacts.find((c) => c.address === address);
    const contact: Contact = existing
      ? { ...existing, alias, publicKey: input.publicKey ?? existing.publicKey, nodeId: input.nodeId ?? existing.nodeId }
      : {
          id: input.id ?? uid(),
          alias,
          address,
          publicKey: input.publicKey,
          nodeId: input.nodeId,
          createdAt: Date.now(),
        };
    const contacts = existing
      ? get().contacts.map((c) => (c.id === existing.id ? contact : c))
      : [...get().contacts, contact].slice(-500);
    saveContacts(contacts);
    set({ contacts });
    return contact;
  },
  removeContact: (id) => {
    const contacts = get().contacts.filter((c) => c.id !== id);
    saveContacts(contacts);
    set({ contacts });
  },
  addRequest: (request) => {
    if (get().requests.some((r) => r.id === request.id)) return;
    const requests = [request, ...get().requests].slice(0, 200);
    saveRequests(requests);
    set({ requests });
  },
  removeRequest: (id) => {
    const requests = get().requests.filter((r) => r.id !== id);
    saveRequests(requests);
    set({ requests });
  },
  addMessage: (message) => {
    const messages = [...get().messages, message].slice(-1000);
    saveMessages(messages);
    set({ messages });
  },
  markDelivered: (id) => {
    const messages = get().messages.map((m) => (m.id === id ? { ...m, status: "delivered" as const } : m));
    saveMessages(messages);
    set({ messages });
  },
  pushActivity: (title, detail) => {
    const event: ActivityEvent = { id: uid(), at: Date.now(), title, detail };
    const activity = [event, ...get().activity].slice(0, 80);
    saveActivity(activity);
    set({ activity });
  },
  setConnected: (value) => {
    set({ connected: value });
    if (value) applyRelayCredits("mesh", 0);
  },
  acceptRequest: (id) => {
    const request = get().requests.find((r) => r.id === id);
    if (!request) return null;
    const contact = get().addContact({
      alias: request.fromAlias,
      address: request.fromAddress,
      publicKey: request.fromPublicKey,
      nodeId: request.fromNodeId,
    });
    get().removeRequest(id);
    return contact;
  },
}));

export function signOutHard() {
  useNexus.getState().lock();
}

export function resetOnboardingTour() {
  resetTour();
}

export function grantConsent() {
  setConsent(true);
}
