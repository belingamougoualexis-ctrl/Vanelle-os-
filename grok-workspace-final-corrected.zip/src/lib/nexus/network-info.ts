export type NetSnapshot = {
  online: boolean;
  type: string | null;
  downlinkMbps: number | null;
  rttMs: number | null;
  saveData: boolean;
  internet: "yes" | "no" | "unknown";
};

type NetworkConnection = {
  effectiveType?: string;
  type?: string;
  downlink?: number;
  rtt?: number;
  saveData?: boolean;
};

export async function snapshotNetwork(): Promise<NetSnapshot> {
  if (typeof navigator === "undefined") {
    return {
      online: false,
      type: null,
      downlinkMbps: null,
      rttMs: null,
      saveData: false,
      internet: "unknown",
    };
  }

  const online = navigator.onLine;
  const conn = (navigator as Navigator & { connection?: NetworkConnection; mozConnection?: NetworkConnection })
    .connection ?? (navigator as Navigator & { mozConnection?: NetworkConnection }).mozConnection;
  const type = conn?.effectiveType ?? conn?.type ?? null;
  const downlinkMbps = typeof conn?.downlink === "number" ? conn.downlink : null;
  const rttMs = typeof conn?.rtt === "number" ? conn.rtt : null;
  const saveData = Boolean(conn?.saveData);

  let internet: NetSnapshot["internet"] = "unknown";
  if (!online) internet = "no";
  else {
    try {
      await fetch("https://www.gstatic.com/generate_204", {
        method: "GET",
        mode: "no-cors",
        cache: "no-store",
        signal: AbortSignal.timeout(2500),
      });
      internet = "yes";
    } catch {
      internet = "no";
    }
  }

  return { online, type, downlinkMbps, rttMs, saveData, internet };
}

export function connectionLabel(snapshot: NetSnapshot): { headline: string; detail: string } {
  if (!snapshot.online || snapshot.internet === "no") {
    return {
      headline: "Hors connexion",
      detail: "Ce navigateur n'a pas de chemin réseau utilisable pour le moment.",
    };
  }
  if (snapshot.internet === "yes") {
    const type = snapshot.type ? ` · ${snapshot.type}` : "";
    return {
      headline: "Internet vérifié",
      detail: `Une requête réelle vers un endpoint public a réussi${type}.`,
    };
  }
  return {
    headline: "Réseau local",
    detail: "Le navigateur est en ligne, mais Internet n'a pas encore été confirmé.",
  };
}
