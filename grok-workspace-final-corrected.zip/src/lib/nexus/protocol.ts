export type HelloPayload = {
  v: 1;
  t: "hello";
  nodeId: string;
  name: string;
  address: string;
  publicKey: string;
  meshName: string;
};

export type ContactReqPayload = {
  v: 1;
  t: "contact_req";
  id: string;
  fromAlias: string;
  fromAddress: string;
  fromNodeId: string;
  fromPublicKey: string;
  message: string;
  createdAt: number;
  signature: string;
};

export type ContactAckPayload = {
  v: 1;
  t: "contact_ack";
  id: string;
  accept: boolean;
};

export type MsgPayload = {
  v: 1;
  t: "msg";
  id: string;
  from: string;
  to: string;
  iv: string;
  ct: string;
  createdAt: number;
};

export type FileOfferPayload = {
  v: 1;
  t: "file_offer";
  id: string;
  hash: string;
  name: string;
  size: number;
};

export type FileChunkPayload = {
  v: 1;
  t: "file_chunk";
  id: string;
  index: number;
  total: number;
  data: string;
};

export type WireMessage =
  | HelloPayload
  | ContactReqPayload
  | ContactAckPayload
  | MsgPayload
  | FileOfferPayload
  | FileChunkPayload;

export function isWireMessage(value: unknown): value is WireMessage {
  if (!value || typeof value !== "object") return false;
  const row = value as { v?: unknown; t?: unknown };
  return row.v === 1 && typeof row.t === "string";
}

export function contactCanonical(req: Omit<ContactReqPayload, "t" | "v" | "signature">): string {
  return `contact_req|${req.id}|${req.fromNodeId}|${req.fromAddress}|${req.fromAlias}|${req.message}|${req.createdAt}`;
}
