import { loadCredits, loadReceipts, saveCredits, saveReceipts } from "./persist";
import type { CreditReceipt } from "./types";

const BYTES_PER_CREDIT = 1_048_576;

function uid(): string {
  return crypto.randomUUID().replaceAll("-", "").slice(0, 16);
}

export function creditBalance(): number {
  return loadCredits().balance;
}

export function applyRelayCredits(peerId: string, bytes: number): number {
  const state = loadCredits();
  const total = state.relayRemainder + Math.max(0, bytes);
  const credits = Math.floor(total / BYTES_PER_CREDIT);
  const remainder = total - credits * BYTES_PER_CREDIT;
  if (credits <= 0) {
    saveCredits({ ...state, relayRemainder: remainder });
    return state.balance;
  }
  const next = state.balance + credits;
  saveCredits({ ...state, relayRemainder: remainder, balance: next });
  const receipts = loadReceipts();
  const row: CreditReceipt = { id: uid(), kind: "relay", peerId, bytes, credits, at: Date.now() };
  saveReceipts([row, ...receipts]);
  return next;
}

export function spendCredits(peerId: string, bytes: number, enforced: boolean): boolean {
  const safe = Math.max(0, bytes);
  if (safe === 0) return true;
  const state = loadCredits();
  const total = state.useRemainder + safe;
  const credits = Math.floor(total / BYTES_PER_CREDIT);
  const remainder = total - credits * BYTES_PER_CREDIT;
  if (credits <= 0) {
    saveCredits({ ...state, useRemainder: remainder });
    return true;
  }
  if (enforced && state.balance < credits) return false;
  const next = Math.max(0, state.balance - credits);
  saveCredits({ ...state, useRemainder: remainder, balance: next });
  const receipts = loadReceipts();
  saveReceipts([{ id: uid(), kind: "use", peerId, bytes: safe, credits, at: Date.now() }, ...receipts]);
  return true;
}
