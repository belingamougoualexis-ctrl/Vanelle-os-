import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { encodeStripe, recoverStripe } from "./erasure.ts";

describe("2+1 XOR erasure coding", () => {
  it("reconstructs after losing any one shard", () => {
    const input = new TextEncoder().encode("NEXUS overlay payload");
    const stripe = encodeStripe(input);

    const fromParityB = recoverStripe(stripe, null, stripe.dataB, stripe.parity);
    const fromParityA = recoverStripe(stripe, stripe.dataA, null, stripe.parity);
    const fromData = recoverStripe(stripe, stripe.dataA, stripe.dataB, null);

    assert.deepEqual(fromParityB, input);
    assert.deepEqual(fromParityA, input);
    assert.deepEqual(fromData, input);
  });

  it("rejects a single remaining shard", () => {
    const stripe = encodeStripe(new Uint8Array([1, 2, 3, 4]));
    assert.throws(() => recoverStripe(stripe, stripe.dataA, null, null));
  });
});
