/**
 * React binding for P2PRoom. Identity and room id are captured once on mount
 * so re-renders never tear down the mesh. Changing room/name/selfId requires
 * a remount (key the component on them).
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { P2PRoom, type PeerInfo } from "./p2p";

export interface UseP2PRoomOptions {
  room: string;
  selfId: string;
  name?: string;
  enabled?: boolean;
}

export interface P2PRoomHandle {
  selfId: string;
  room: string;
  peers: PeerInfo[];
  joined: boolean;
  error: string | null;
  broadcast: (data: unknown) => void;
  send: (data: unknown, peerId?: string) => void;
  onMessage: (
    fn: (from: string, data: unknown, channel: "state" | "reliable") => void,
  ) => () => void;
}

export function useP2PRoom(options: UseP2PRoomOptions): P2PRoomHandle {
  const { room, selfId, name, enabled = true } = options;
  const [peers, setPeers] = useState<PeerInfo[]>([]);
  const [joined, setJoined] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const roomRef = useRef<P2PRoom | null>(null);
  const listeners = useRef(
    new Set<(from: string, data: unknown, channel: "state" | "reliable") => void>(),
  );

  useEffect(() => {
    if (!enabled) {
      setPeers([]);
      setJoined(false);
      return;
    }
    const p2p = new P2PRoom({
      room,
      selfId,
      name: name ?? selfId,
      onPeersChanged: setPeers,
      onMessage: (from, data, channel) => {
        for (const fn of listeners.current) fn(from, data, channel);
      },
      onConnected: () => {
        setJoined(true);
        setError(null);
      },
    });
    roomRef.current = p2p;
    void p2p.join().catch((err: unknown) => {
      setError(err instanceof Error ? err.message : "Connexion mesh impossible.");
    });
    return () => {
      roomRef.current = null;
      p2p.close();
      setJoined(false);
      setPeers([]);
    };
  }, [room, selfId, name, enabled]);

  const broadcast = useCallback((data: unknown) => roomRef.current?.broadcast(data), []);
  const send = useCallback((data: unknown, peerId?: string) => roomRef.current?.send(data, peerId), []);
  const onMessage = useCallback(
    (fn: (from: string, data: unknown, channel: "state" | "reliable") => void) => {
      listeners.current.add(fn);
      return () => {
        listeners.current.delete(fn);
      };
    },
    [],
  );

  return { selfId, room, peers, joined, error, broadcast, send, onMessage };
}
