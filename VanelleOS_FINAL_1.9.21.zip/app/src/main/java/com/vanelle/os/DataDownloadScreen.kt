package com.vanelle.os

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.core.content.ContextCompat

/**
 * Écran de préparation IA — style futuriste / pro VanelleOS.
 * Fond sombre dégradé, halo rose, mascotte animée, barre fine, typo claire.
 */
object DataDownloadScreen {

    private var root: FrameLayout? = null
    private var progressBar: ProgressBar? = null
    private var pctText: TextView? = null
    private var statusText: TextView? = null
    private var detailText: TextView? = null
    private var hero: ImageView? = null
    private var receiver: BroadcastReceiver? = null
    private val handler = Handler(Looper.getMainLooper())
    private var mascotIndex = 0
    private var mascotRunnable: Runnable? = null
    private var pulseAnim: AnimatorSet? = null
    private var ringAnim: ObjectAnimator? = null

    private val mascotIds = listOf(
        "kawaii", "crystal", "gold", "cyber", "ice", "candy", "pastel", "galaxy", "abyss"
    )

    /** Conseil affiché dès le début du téléchargement de l'IA. */
    private fun wifiAdvice(ctx: android.content.Context): String {
        return if (LlamaModelManager.isOnWifi(ctx)) {
            "Téléchargement de l'IA sur Wi‑Fi…"
        } else {
            "Connecte-toi au Wi‑Fi pour télécharger l'IA (~800 Mo). Évite les données mobiles."
        }
    }

    fun maybeShow(activity: Activity) {
        if (DataDownloadService.isUsable(activity)) return
        DataDownloadService.start(activity)
        if (root != null) return
        attach(activity)
        register(activity)
        startMascotLoop(activity)
        startPulse()
        // Progression globale du téléchargement du modèle IA local.
        val partial = LlamaModelManager.partialBytes(activity)
        val pct = if (partial > 0) {
            ((partial * 100) / LlamaModelManager.EXPECTED_MIN_BYTES).toInt().coerceIn(0, 99)
        } else 0
        updateUi(pct, wifiAdvice(activity))
    }

    fun dismiss(activity: Activity) {
        stopAnims()
        unregister(activity)
        try {
            (root?.parent as? ViewGroup)?.removeView(root)
        } catch (_: Exception) {
        }
        root = null
        progressBar = null
        pctText = null
        statusText = null
        detailText = null
        hero = null
    }

    private fun attach(activity: Activity) {
        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val overlay = FrameLayout(activity).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFFF5F5F5.toInt())
            )
            isClickable = true
            isFocusable = true
            elevation = 48f
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }

        val column = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(32), dp(56), dp(32), dp(40))
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }

        val brand = TextView(activity).apply {
            text = "VANELLE OS"
            setTextColor(0xFF000000.toInt())
            textSize = 13f
            letterSpacing = 0.28f
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }

        val title = TextView(activity).apply {
            text = "Activation de l'IA"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 24f
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
            setPadding(0, dp(10), 0, dp(4))
        }

        val subtitle = TextView(activity).apply {
            text = "Préparation locale · privée · hors-ligne"
            setTextColor(0xFF444444.toInt())
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(36))
        }

        // Halo + anneau
        val halo = View(activity).apply {
            val size = dp(210)
            layoutParams = FrameLayout.LayoutParams(size, size).apply { gravity = Gravity.CENTER }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                colors = intArrayOf(0x55000000, 0x18000000, 0x00000000)
                gradientType = GradientDrawable.RADIAL_GRADIENT
                gradientRadius = size / 2f
            }
            tag = "halo"
        }

        val ring = View(activity).apply {
            val size = dp(188)
            layoutParams = FrameLayout.LayoutParams(size, size).apply { gravity = Gravity.CENTER }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x00000000)
                setStroke(dp(2), 0x66000000)
            }
            tag = "ring"
        }

        val heroFrame = FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(dp(230), dp(230)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
            }
            addView(halo)
            addView(ring)
            val img = ImageView(activity).apply {
                layoutParams = FrameLayout.LayoutParams(dp(150), dp(150)).apply { gravity = Gravity.CENTER }
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
                try {
                    setImageResource(MascotManager.getDrawableId(activity, mascotIds[0]))
                } catch (_: Exception) {
                }
            }
            hero = img
            addView(img)
        }

        statusText = TextView(activity).apply {
            text = "Connecte-toi au Wi‑Fi pour télécharger l'IA (~800 Mo)."
            setTextColor(0xFF000000.toInt())
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(32), 0, dp(16))
        }

        // Barre fine dans un conteneur arrondi
        val barTrack = FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(8)).apply {
                topMargin = dp(4)
            }
            background = GradientDrawable().apply {
                setColor(0x33FFFFFF)
                cornerRadius = dp(8).toFloat()
            }
        }

        progressBar = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            layoutParams = FrameLayout.LayoutParams(-1, -1)
            if (Build.VERSION.SDK_INT >= 21) {
                progressTintList = android.content.res.ColorStateList.valueOf(0xFF000000.toInt())
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0x00000000)
            }
        }
        barTrack.addView(progressBar)

        pctText = TextView(activity).apply {
            text = "0 %"
            setTextColor(0xFF000000.toInt())
            textSize = 28f
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
            setPadding(0, dp(18), 0, dp(4))
        }

        detailText = TextView(activity).apply {
            text = "Wi‑Fi recommandé (~800 Mo). Le modèle reste sur ton téléphone, aucun cloud."
            setTextColor(0xFF444444.toInt())
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(20), dp(12), 0)
        }

        column.addView(brand)
        column.addView(title)
        column.addView(subtitle)
        column.addView(heroFrame)
        column.addView(statusText)
        column.addView(barTrack)
        column.addView(pctText)
        column.addView(detailText)

        // Bouton : continuer en arrière-plan et accéder au reste de l'app
        val bgBtn = TextView(activity).apply {
            text = "Mettre en arrière-plan"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 15f
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(14).toFloat()
                setColor(0xFF000000.toInt())
            }
            setPadding(dp(28), dp(14), dp(28), dp(14))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(28)
            }
            layoutParams = lp
            setOnClickListener {
                // Ferme l'écran, le service continue en foreground
                dismiss(activity)
                try {
                    android.widget.Toast.makeText(
                        activity,
                        "Téléchargement en arrière-plan — tu recevras une notification quand ce sera prêt",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                } catch (_: Exception) {}
            }
        }
        column.addView(bgBtn)

        val bgHint = TextView(activity).apply {
            text = "Vanelle reste verrouillée jusqu'à la fin du téléchargement et du chargement de l'IA."
            setTextColor(0xFF444444.toInt())
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        column.addView(bgHint)

        overlay.addView(column)

        val decor = activity.window.decorView as ViewGroup
        decor.addView(overlay)
        root = overlay
    }

    private fun startMascotLoop(activity: Activity) {
        mascotRunnable?.let { handler.removeCallbacks(it) }
        val r = object : Runnable {
            override fun run() {
                val img = hero ?: return
                mascotIndex = (mascotIndex + 1) % mascotIds.size
                val id = MascotManager.getDrawableId(activity, mascotIds[mascotIndex])
                img.animate().alpha(0.2f).setDuration(280).withEndAction {
                    try {
                        if (id != 0) img.setImageResource(id)
                    } catch (_: Exception) {
                    }
                    img.animate().alpha(1f).setDuration(320).start()
                }.start()
                // Statut fixe : pas de messages fantaisistes au démarrage
                val st = statusText
                if (st != null && (progressBar?.progress ?: 0) < 95) {
                    st.text = "Téléchargement de l'IA — Wi‑Fi recommandé"
                }
                handler.postDelayed(this, 2400)
            }
        }
        mascotRunnable = r
        handler.postDelayed(r, 2000)
    }

    private fun startPulse() {
        val overlay = root ?: return
        val col = overlay.getChildAt(0) as? ViewGroup ?: return
        val heroFrame = col.getChildAt(3) as? ViewGroup ?: return
        val halo = heroFrame.findViewWithTag<View>("halo") ?: return
        val ring = heroFrame.findViewWithTag<View>("ring")

        val a1 = ObjectAnimator.ofFloat(halo, View.SCALE_X, 0.88f, 1.18f).apply {
            duration = 1600; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        val a2 = ObjectAnimator.ofFloat(halo, View.SCALE_Y, 0.88f, 1.18f).apply {
            duration = 1600; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        val a3 = ObjectAnimator.ofFloat(halo, View.ALPHA, 0.4f, 0.85f).apply {
            duration = 1600; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
        }
        pulseAnim = AnimatorSet().apply {
            playTogether(a1, a2, a3)
            start()
        }
        ring?.let {
            ringAnim = ObjectAnimator.ofFloat(it, View.ROTATION, 0f, 360f).apply {
                duration = 12000
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                start()
            }
        }
    }

    private fun stopAnims() {
        mascotRunnable?.let { handler.removeCallbacks(it) }
        mascotRunnable = null
        pulseAnim?.cancel()
        pulseAnim = null
        ringAnim?.cancel()
        ringAnim = null
    }

    private fun updateUi(pct: Int, status: String) {
        val p = pct.coerceIn(0, 100)
        progressBar?.progress = p
        pctText?.text = "$p %"
        statusText?.text = status
        if (p >= 100) {
            detailText?.text = "Vanelle est prête."
        }
    }

    private fun register(activity: Activity) {
        unregister(activity)
        receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                when (intent?.action) {
                    DataDownloadService.ACTION_PROGRESS -> {
                        val p = intent.getIntExtra(DataDownloadService.EXTRA_PERCENT, 0)
                        val s = intent.getStringExtra(DataDownloadService.EXTRA_STATUS)
                            ?: "Mise à jour…"
                        updateUi(p, s)
                    }
                    DataDownloadService.ACTION_WAITING -> {
                        val p = intent.getIntExtra(DataDownloadService.EXTRA_PERCENT, 0)
                        val s = intent.getStringExtra(DataDownloadService.EXTRA_STATUS)
                            ?: "En attente réseau…"
                        updateUi(p, s)
                    }
                    DataDownloadService.ACTION_DONE -> {
                        updateUi(100, "Données prêtes")
                        handler.postDelayed({ dismiss(activity) }, 1100)
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(DataDownloadService.ACTION_PROGRESS)
            addAction(DataDownloadService.ACTION_WAITING)
            addAction(DataDownloadService.ACTION_DONE)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            activity.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            activity.registerReceiver(receiver, filter)
        }
    }

    private fun unregister(activity: Activity) {
        try {
            receiver?.let { activity.unregisterReceiver(it) }
        } catch (_: Exception) {
        }
        receiver = null
    }
}
