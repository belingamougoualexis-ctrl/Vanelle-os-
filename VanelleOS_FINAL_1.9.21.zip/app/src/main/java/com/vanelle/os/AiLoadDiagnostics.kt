package com.vanelle.os
import android.app.ActivityManager
import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Journal persistant des échecs (et succès) de chargement de l'IA locale en mémoire.
 *
 * Objectif : quand la notification « IA — non chargée en mémoire » apparaît, l'utilisateur
 * (ou nous, à distance via un export) doit pouvoir voir immédiatement LA CAUSE réelle
 * (RAM insuffisante, modèle corrompu, bibliothèque absente, timeout, exception...),
 * sans avoir à relancer l'app en espérant reproduire le bug avec un logcat branché.
 *
 * Fonctionne comme WakeWordDiagnostics / CrashLogger : fichier texte dans filesDir,
 * conservé entre les sessions, purgé automatiquement au-delà de MAX_ENTRIES.
 */
object AiLoadDiagnostics {
    private const val FILE_NAME = "ai_load_diagnostics.txt"
    private const val MAX_ENTRIES = 25
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.FRANCE)

    private fun file(ctx: Context): File = File(ctx.applicationContext.filesDir, FILE_NAME)

    private fun deviceInfo(ctx: Context): String {
        return try {
            val am = ctx.applicationContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val totalMb = LlamaModelManager.totalRamMb(ctx)
            val freeMb = mi.availMem / (1024 * 1024)
            val lowRam = am.isLowRamDevice
            "RAM totale=${totalMb}Mo, libre=${freeMb}Mo, appareil bas de gamme=$lowRam, heapClass=${am.memoryClass}/${am.largeMemoryClass}Mo"
        } catch (e: Exception) {
            "info appareil indisponible (${e.message})"
        }
    }

    /** Enregistre un échec de chargement avec sa cause. À appeler dès que la cause est connue. */
    @Synchronized
    fun logFailure(ctx: Context, cause: String, attempt: Int? = null) {
        appendEntry(ctx, "ÉCHEC", cause + (attempt?.let { " (tentative $it)" } ?: ""))
    }

    /** Enregistre un chargement réussi, pour garder l'historique complet (avant/après). */
    @Synchronized
    fun logSuccess(ctx: Context, detail: String) {
        appendEntry(ctx, "OK", detail)
    }

    private fun appendEntry(ctx: Context, kind: String, detail: String) {
        try {
            val stamp = fmt.format(Date())
            val line = "[$stamp] $kind — $detail\n    (${deviceInfo(ctx)})\n"
            val f = file(ctx)
            val existing = if (f.exists()) f.readText() else ""
            val entries = (existing.split("\n\n").filter { it.isNotBlank() } + line)
                .takeLast(MAX_ENTRIES)
            f.writeText(entries.joinToString("\n\n"))
        } catch (_: Exception) {
            // Le diagnostic ne doit jamais faire planter le chargement réel.
        }
    }

    /** Dernière cause d'échec connue (pour affichage court dans l'UI), ou null si aucune. */
    fun lastFailureCause(ctx: Context): String? {
        return try {
            val f = file(ctx)
            if (!f.exists()) return null
            f.readText().split("\n\n")
                .filter { it.isNotBlank() }
                .lastOrNull { it.contains("ÉCHEC") }
                ?.lineSequence()?.firstOrNull()
                ?.substringAfter("ÉCHEC — ")
        } catch (_: Exception) {
            null
        }
    }

    /** Journal complet, du plus ancien au plus récent, pour la vue « Diagnostic IA ». */
    fun readAll(ctx: Context): String {
        return try {
            val f = file(ctx)
            if (f.exists()) f.readText().trim() else "Aucun incident de chargement enregistré."
        } catch (e: Exception) {
            "Journal illisible (${e.message})"
        }
    }

    @Synchronized
    fun clear(ctx: Context) {
        try { file(ctx).delete() } catch (_: Exception) {}
    }
}
