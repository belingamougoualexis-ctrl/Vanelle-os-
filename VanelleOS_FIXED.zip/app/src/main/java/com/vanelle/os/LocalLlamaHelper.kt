package com.vanelle.os

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.yield
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min

/**
 * Wrapper optimisé autour de llamacpp-kotlin (réflexion).
 *
 * Optimisations :
 * - Instance unique process-wide (un seul chargement du modèle)
 * - n_ctx adapté à la RAM (384–1024) pour limiter OOM
 * - Prompt système compact (moins de tokens de préfill)
 * - Contexte utilisateur tronqué
 * - Timeout adaptatif selon la taille de la requête
 * - warmUp() au démarrage de l'app
 * - Mutex pour sérialiser les inférences (un seul contexte natif)
 * - Succès de charge détecté via callback (Long) ET événement Loaded du SharedFlow
 * - Pas de boucle de 10+ tentatives : 2 essais max (ctx optimal puis repli)
 */
class LocalLlamaHelper private constructor(private val appContext: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val events = MutableSharedFlow<Any>(extraBufferCapacity = 512, replay = 0)

    @Volatile private var loaded = false
    @Volatile private var loading = false
    @Volatile private var loadFailedPermanently = false
    @Volatile private var helper: Any? = null
    @Volatile private var resolvedClass: Class<*>? = null
    private val answerMutex = Mutex()
    private val loadMutex = Mutex()

    private fun resolveLlamaClass(): Class<*>? {
        resolvedClass?.let { return it }
        val candidates = listOf(
            "org.nehuatl.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacppkotlin.LlamaHelper",
            "com.ljcamargo.llamacpp.LlamaHelper"
        )
        for (name in candidates) {
            try {
                val c = Class.forName(name)
                resolvedClass = c
                android.util.Log.i("VanelleLlama", "LlamaHelper résolu: $name")
                return c
            } catch (_: ClassNotFoundException) {}
        }
        android.util.Log.e("VanelleLlama", "Aucune classe LlamaHelper trouvée parmi: $candidates")
        return null
    }

    /** Fenêtre de contexte selon la mémoire disponible (moins de RAM → plus rapide / stable). */
    private fun optimalContextLength(): Int {
        // Contextes volontairement modestes = chargement plus rapide et moins d'OOM.
        return try {
            val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memMb = am.largeMemoryClass
            val ramMb = LlamaModelManager.totalRamMb(appContext)
            when {
                ramMb >= 6144 && memMb >= 768 -> 768
                ramMb >= 4096 && memMb >= 512 -> 512
                else -> 256
            }
        } catch (_: Exception) {
            256
        }
    }

    @Volatile private var lastLoadError: String? = null

    fun lastError(): String? = lastLoadError

    private suspend fun ensureLoaded(): Boolean {
        if (loaded && helper != null) return true
        if (loadFailedPermanently) return false
        if (!LlamaModelManager.isReady(appContext)) {
            lastLoadError = "Modèle non téléchargé."
            return false
        }
        return loadMutex.withLock {
            if (loaded && helper != null) return@withLock true
            if (loadFailedPermanently) return@withLock false
            if (loading) {
                // Attendre un chargement concurrent déjà en cours (max 120 s)
                repeat(120) {
                    kotlinx.coroutines.delay(1000)
                    if (loaded && helper != null) return@withLock true
                    if (!loading) return@withLock (loaded && helper != null)
                }
                return@withLock (loaded && helper != null)
            }
            loading = true
            try {
                // Llama est toujours tenté en priorité. Plusieurs contextes
                // permettent de réduire la mémoire KV/cache sur les appareils faibles.
                val contexts = listOf(optimalContextLength(), 192, 128).distinct()
                var ok = false
                for ((attempt, nCtx) in contexts.withIndex()) {
                    if (attempt > 0) {
                        try { System.gc() } catch (_: Exception) {}
                        kotlinx.coroutines.delay(1500)
                    }
                    ok = tryLoadOnce(nCtx, timeoutMs = 120_000L)
                    if (ok) {
                        lastLoadError = null
                        android.util.Log.i("VanelleLlama", "Modèle chargé (n_ctx=$nCtx, tentative=${attempt + 1})")
                        AiLoadDiagnostics.logSuccess(appContext, "chargé avec n_ctx=$nCtx (tentative ${attempt + 1}/${contexts.size})")
                        return@withLock true
                    }
                }
                loadFailedPermanently = true
                if (lastLoadError == null) {
                    lastLoadError = LlamaModelManager.memoryWarning(appContext)
                        ?: "Impossible de charger l'IA en mémoire. Ferme d'autres apps, libère de la RAM, puis rouvre VanelleOS."
                }
                android.util.Log.e("VanelleLlama", "Échec du chargement unique: $lastLoadError")
                AiLoadDiagnostics.logFailure(appContext, lastLoadError ?: "cause inconnue", attempt = contexts.size)
                false
            } catch (e: Exception) {
                android.util.Log.e("VanelleLlama", "ensureLoaded exception", e)
                loadFailedPermanently = true
                lastLoadError = "Erreur de chargement : ${e.message ?: "inconnue"}"
                AiLoadDiagnostics.logFailure(appContext, lastLoadError ?: "exception inconnue")
                false
            } finally {
                loading = false
            }
        }
    }

    private suspend fun tryLoadOnce(nCtx: Int, timeoutMs: Long): Boolean {
        return try {
            val klass = resolveLlamaClass()
            if (klass == null) {
                lastLoadError = "Bibliothèque IA locale absente (variante modern / 64 bits requise)."
                return false
            }
            val ctor = try {
                klass.getConstructor(
                    android.content.ContentResolver::class.java,
                    CoroutineScope::class.java,
                    MutableSharedFlow::class.java
                )
            } catch (e: Exception) {
                android.util.Log.e("VanelleLlama", "Constructeur LlamaHelper introuvable", e)
                lastLoadError = "API LlamaHelper incompatible."
                null
            } ?: return false

            val modelFile = LlamaModelManager.modelFile(appContext)
            if (!modelFile.exists() || modelFile.length() != LlamaModelManager.EXPECTED_MIN_BYTES ||
                !LlamaModelManager.verifyModelIntegrity(appContext)) {
                lastLoadError = "Fichier modèle manquant, tronqué ou corrompu. Le téléchargement sera vérifié avant un nouvel essai."
                android.util.Log.e("VanelleLlama", "Intégrité GGUF invalide: ${modelFile.length()} octets")
                return false
            }

            // URI stable : FileProvider si possible, sinon file://
            val modelUri = try {
                androidx.core.content.FileProvider.getUriForFile(
                    appContext,
                    "${appContext.packageName}.fileprovider",
                    modelFile
                ).toString()
            } catch (_: Exception) {
                Uri.fromFile(modelFile).toString()
            }

            // Libère un peu de heap avant le gros mmap/load natif
            try { System.gc() } catch (_: Exception) {}

            val h = ctor.newInstance(appContext.contentResolver, scope, events)

            // Signature officielle v0.4.0 :
            // load(path, contextLength, mmprojPath?, loaded: (Long) -> Unit)
            val loadMethod = try {
                klass.getMethod(
                    "load",
                    String::class.java,
                    Int::class.javaPrimitiveType,
                    String::class.java,
                    kotlin.jvm.functions.Function1::class.java
                )
            } catch (_: Exception) {
                klass.methods.firstOrNull { m -> m.name == "load" && m.parameterTypes.size >= 2 }
            }
            if (loadMethod == null) {
                lastLoadError = "Méthode load() introuvable dans la bibliothèque IA."
                return false
            }

            val ok = withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    val done = java.util.concurrent.atomic.AtomicBoolean(false)
                    fun complete(success: Boolean) {
                        if (done.compareAndSet(false, true) && cont.isActive) {
                            cont.resume(success)
                        }
                    }

                    val watchJob = scope.launch {
                        try {
                            events.takeWhile { event ->
                                when (event.javaClass.simpleName) {
                                    "Loaded" -> {
                                        complete(true)
                                        false
                                    }
                                    "Error" -> {
                                        android.util.Log.w("VanelleLlama", "LLMEvent.Error: $event")
                                        lastLoadError = "Erreur native lors du chargement du modèle."
                                        complete(false)
                                        false
                                    }
                                    else -> true
                                }
                            }.collect { }
                        } catch (_: Exception) {}
                    }

                    try {
                        val callback = object : kotlin.jvm.functions.Function1<Long, Unit> {
                            override fun invoke(id: Long) {
                                android.util.Log.i("VanelleLlama", "Callback load OK, contextId=$id")
                                complete(true)
                            }
                        }
                        when (loadMethod.parameterTypes.size) {
                            4 -> loadMethod.invoke(h, modelUri, nCtx, null, callback)
                            3 -> {
                                try {
                                    loadMethod.invoke(h, modelUri, nCtx, callback)
                                } catch (_: Exception) {
                                    loadMethod.invoke(h, modelUri, nCtx, null)
                                }
                            }
                            2 -> loadMethod.invoke(h, modelUri, nCtx)
                            else -> loadMethod.invoke(h, modelUri)
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("VanelleLlama", "invoke load failed", e)
                        lastLoadError = "Échec chargement : ${e.message ?: e.javaClass.simpleName}"
                        complete(false)
                    }

                    cont.invokeOnCancellation { watchJob.cancel() }
                }
            } ?: run {
                lastLoadError = "Délai dépassé lors du chargement en mémoire."
                false
            }

            if (ok) {
                helper = h
                loaded = true
                loadFailedPermanently = false
                lastLoadError = null
            } else {
                android.util.Log.w("VanelleLlama", "tryLoadOnce(nCtx=$nCtx): échec — $lastLoadError")
            }
            ok
        } catch (e: Exception) {
            android.util.Log.e("VanelleLlama", "tryLoadOnce(nCtx=$nCtx) exception", e)
            lastLoadError = "Erreur : ${e.message ?: "inconnue"}"
            false
        }
    }

    /**
     * Précharge le modèle. ensureLoaded() gère déjà son propre réessai interne
     * (contexte optimal puis repli) — pas besoin de reboucler par-dessus ici.
     */
    suspend fun warmUp(): Boolean = withContext(Dispatchers.IO) {
        if (!LlamaModelManager.isReady(appContext)) return@withContext false
        if (loaded && helper != null) return@withContext true
        if (loadFailedPermanently) return@withContext false
        ensureLoaded()
    }

    fun isLoaded(): Boolean = loaded && helper != null

    /** Réinitialise le flag d'échec permanent (ex. après redémarrage app ou nouvel essai manuel). */
    fun resetLoadFailure() {
        loadFailedPermanently = false
        lastLoadError = null
    }

    /**
     * @param maxTokensHint limite soft côté collecteur (coupe tôt si réponse déjà longue)
     * @param fastMode prompt encore plus court + timeout réduit (commandes simples)
     */
    suspend fun answer(
        userPrompt: String,
        extraContext: String = "",
        fastMode: Boolean = false,
        maxTokensHint: Int = if (fastMode) 64 else 120
    ): String = answerMutex.withLock {
        if (!ensureLoaded()) return@withLock NOT_READY
        val h = helper ?: return@withLock NOT_READY
        val klass = h.javaClass

        val formatted = buildPrompt(userPrompt, extraContext, fastMode)
        val timeoutMs = adaptiveTimeoutMs(formatted.length, fastMode)

        return@withLock try {
            // Signature officielle (kotlinllamacpp / org.nehuatl.llamacpp.LlamaHelper) :
            //   fun predict(prompt: String, imagePath: String? = null, partialCompletion: Boolean = true)
            // JVM : predict(String, String, boolean) — le 3e argument est un boolean primitif.
            // predict() ne retourne rien : la réponse arrive via le SharedFlow<LLMEvent>
            // (Started / Ongoing(word,tokenCount) / Done / Error).
            // Priorité : signature à 3 args (la vraie), puis 2 args, puis fallback générique.
            val method3Args = try {
                klass.getMethod(
                    "predict",
                    String::class.java,
                    String::class.java,
                    Boolean::class.javaPrimitiveType
                )
            } catch (_: Exception) {
                try {
                    // Certaines builds exposent Boolean boxed au lieu de boolean primitif
                    klass.getMethod(
                        "predict",
                        String::class.java,
                        String::class.java,
                        Boolean::class.java
                    )
                } catch (_: Exception) { null }
            }
            val method2Args = try {
                klass.getMethod("predict", String::class.java, String::class.java)
            } catch (_: Exception) { null }
            val method1Arg = try {
                klass.getMethod("predict", String::class.java)
            } catch (_: Exception) { null }

            val predictMethod = method3Args ?: method2Args ?: method1Arg
                ?: listOf("predict", "generate", "complete", "chat", "ask")
                    .asSequence()
                    .flatMap { name -> klass.methods.asSequence().filter { it.name == name } }
                    .filter { it.parameterTypes.isNotEmpty() && String::class.java.isAssignableFrom(it.parameterTypes[0]) }
                    .sortedByDescending { it.parameterTypes.size } // préférer la version complète
                    .firstOrNull()
                ?: run {
                    val allNames = klass.methods.map { it.name }.distinct().sorted()
                    AiLoadDiagnostics.logFailure(
                        appContext,
                        "Réponse : aucune méthode de génération trouvée sur la bibliothèque IA " +
                            "(predict/generate/complete/chat/ask absentes). Méthodes disponibles : $allNames"
                    )
                    return@withLock NOT_READY
                }

            // Construction robuste des arguments :
            // - arg0 = prompt (String)
            // - imagePath (String?) = null → texte seul
            // - partialCompletion (boolean/Boolean) = true (défaut bibliothèque)
            // Ne jamais passer null à un paramètre primitif (boolean/int/long) → crash « got null ».
            fun buildArgs(method: java.lang.reflect.Method, prompt: String): Array<Any?> {
                val types = method.parameterTypes
                return Array(types.size) { idx ->
                    val type = types[idx]
                    when {
                        idx == 0 -> prompt
                        type == Boolean::class.javaPrimitiveType || type == Boolean::class.java -> true
                        type == Int::class.javaPrimitiveType || type == Integer::class.java -> 0
                        type == Long::class.javaPrimitiveType || type == java.lang.Long::class.java -> 0L
                        type == Float::class.javaPrimitiveType || type == java.lang.Float::class.java -> 0f
                        type == Double::class.javaPrimitiveType || type == java.lang.Double::class.java -> 0.0
                        CharSequence::class.java.isAssignableFrom(type) || type == String::class.java -> null // imagePath
                        else -> null
                    }
                }
            }

            // Best-effort, aligné sur le cycle de vie officiel de la démo (stopPrediction() est
            // appelé après Done/Error) : évite de laisser le moteur natif "en génération" et de
            // casser l'appel suivant.
            fun stopPredictionQuietly() {
                try { klass.getMethod("stopPrediction").invoke(h) } catch (_: Exception) {}
            }

            withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<String> { cont ->
                    val job = scope.launch {
                        try {
                            val sb = StringBuilder(maxTokensHint * 4)
                            var tokenApprox = 0

                            var doneFullText: String? = null
                            val collector = launch {
                                try {
                                    events.takeWhile { event ->
                                        when (event.javaClass.simpleName) {
                                            "Started" -> true
                                            "Ongoing" -> {
                                                val word = extractToken(event)
                                                if (word.isNotEmpty()) {
                                                    sb.append(word)
                                                    tokenApprox++
                                                }
                                                tokenApprox < maxTokensHint && sb.length < maxTokensHint * 8
                                            }
                                            "Done" -> {
                                                // Récupère fullText si les jetons Ongoing n'ont pas été collectés
                                                doneFullText = extractFullText(event)
                                                false
                                            }
                                            "Error" -> {
                                                val msg = extractToken(event).ifEmpty {
                                                    try {
                                                        event.javaClass.getMethod("getMessage").invoke(event)?.toString()
                                                    } catch (_: Exception) { null } ?: "erreur inconnue"
                                                }
                                                AiLoadDiagnostics.logFailure(appContext, "Réponse : événement Error du modèle — $msg")
                                                false
                                            }
                                            else -> {
                                                val word = extractToken(event)
                                                if (word.isNotEmpty()) {
                                                    sb.append(word)
                                                    tokenApprox++
                                                }
                                                tokenApprox < maxTokensHint
                                            }
                                        }
                                    }.collect { }
                                } catch (_: Exception) {}
                            }

                            yield()
                            val args = buildArgs(predictMethod, formatted)
                            android.util.Log.i(
                                "VanelleLlama",
                                "predict via ${predictMethod.name}(${predictMethod.parameterTypes.joinToString { it.simpleName }}) args=${args.map { it?.javaClass?.simpleName ?: "null" }}"
                            )
                            predictMethod.invoke(h, *args)
                            withTimeoutOrNull(timeoutMs) { collector.join() }
                            collector.cancel()
                            stopPredictionQuietly()

                            val text = (sb.toString().ifBlank { doneFullText.orEmpty() })
                                .trim()
                                .removePrefix("assistant")
                                .trim()
                            if (text.isBlank()) {
                                AiLoadDiagnostics.logFailure(
                                    appContext,
                                    "Réponse : aucune sortie exploitable reçue de predict() " +
                                        "(méthode=${predictMethod.name}, args=${predictMethod.parameterCount})."
                                )
                            }
                            if (cont.isActive) {
                                cont.resume(text.ifBlank { NOT_READY })
                            }
                        } catch (e: Exception) {
                            stopPredictionQuietly()
                            val detail = when (e) {
                                is IllegalArgumentException ->
                                    "appel predict() — ${e.message ?: "argument invalide (souvent null passé à un boolean primitif)"}"
                                is java.lang.reflect.InvocationTargetException ->
                                    "predict() a levé : ${e.cause?.message ?: e.message ?: e.javaClass.simpleName}"
                                else ->
                                    "exception pendant la génération — ${e.message ?: e.javaClass.simpleName}"
                            }
                            AiLoadDiagnostics.logFailure(appContext, "Réponse : $detail")
                            if (cont.isActive) cont.resume(NOT_READY)
                        }
                    }
                    cont.invokeOnCancellation { job.cancel(); stopPredictionQuietly() }
                }
            } ?: run {
                stopPredictionQuietly()
                AiLoadDiagnostics.logFailure(appContext, "Réponse : délai dépassé (${timeoutMs}ms) sans réponse du modèle.")
                NOT_READY
            }
        } catch (e: Exception) {
            AiLoadDiagnostics.logFailure(appContext, "Réponse : exception — ${e.message ?: e.javaClass.simpleName}")
            NOT_READY
        }
    }

    private fun extractToken(event: Any): String {
        for (method in listOf("getWord", "getToken", "getText", "getContent", "getMessage")) {
            try {
                val v = event.javaClass.getMethod(method).invoke(event)
                if (v is String && v.isNotEmpty()) return v
            } catch (_: Exception) {}
        }
        try {
            for (f in event.javaClass.declaredFields) {
                f.isAccessible = true
                val v = f.get(event)
                if (v is String && v.isNotEmpty() && v.length < 200) return v
            }
        } catch (_: Exception) {}
        // Kotlin data class properties sometimes only exposed as componentN / fields without getter
        try {
            val comp1 = event.javaClass.getMethod("component1").invoke(event)
            if (comp1 is String && comp1.isNotEmpty()) return comp1
        } catch (_: Exception) {}
        return ""
    }

    /** Pour LLMEvent.Done(fullText, tokenCount, duration) — récupère le texte complet. */
    private fun extractFullText(event: Any): String? {
        for (method in listOf("getFullText", "getText", "getContent", "getMessage", "component1")) {
            try {
                val v = event.javaClass.getMethod(method).invoke(event)
                if (v is String && v.isNotEmpty()) return v
            } catch (_: Exception) {}
        }
        try {
            for (f in event.javaClass.declaredFields) {
                f.isAccessible = true
                val v = f.get(event)
                if (v is String && v.isNotEmpty()) return v
            }
        } catch (_: Exception) {}
        return null
    }

    private fun buildPrompt(userPrompt: String, extraContext: String, fastMode: Boolean): String {
        val system = if (fastMode) {
            "Tu es Vanelle, assistante vocale réelle et locale sur Android. Mission : aider concrètement " +
                "l'utilisateur sur son téléphone. Français, 1-2 phrases, naturel. " +
                "Utilise le prénom de l'utilisateur s'il est dans le contexte. " +
                "Aucune réponse inventée. Si action téléphone : ligne ACTION:TYPE|arg."
        } else {
            "Tu es Vanelle, assistante IA réelle et locale installée sur le téléphone de l'utilisateur. " +
                "Ta mission : comprendre ses intentions, exécuter des actions sur l'appareil, " +
                "lire et analyser l'écran (service d'accessibilité), mémoriser le contexte utile, " +
                "et répondre en français naturel (1-3 phrases). Tu n'es pas une IA cloud : " +
                "tu es présente ici, maintenant, sur cet appareil. " +
                "Si le prénom de l'utilisateur est dans le contexte, utilise-le quand c'est naturel. " +
                "Ne simule rien, ne donne pas d'exemples fictifs, base-toi uniquement sur le contexte et la demande. " +
                "Pour une action téléphone, mets EN PREMIER: " +
                "ACTION:YOUTUBE|requête ou ACTION:OPEN_APP|nom ou ACTION:CALL|nom ou " +
                "ACTION:MESSAGE|nom|texte ou ACTION:SEARCH|requête ou ACTION:MAPS|lieu ou " +
                "ACTION:TIMER|minutes ou ACTION:FLASHLIGHT|on/off ou ACTION:VOLUME|up/down ou " +
                "ACTION:SCREEN_SUMMARY ou ACTION:CLICK|texte. " +
                "Sinon réponds normalement sans ligne ACTION."
        }
        val ctx = extraContext.trim().take(if (fastMode) 180 else 500)
        val user = userPrompt.trim().take(if (fastMode) 200 else 360)

        return buildString(capacity = 2200) {
            append("<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n")
            append(system)
            if (ctx.isNotBlank()) {
                append("\nContexte: ")
                append(ctx)
            }
            append("\n<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n")
            append(user)
            append("\n<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n")
        }
    }

    private fun adaptiveTimeoutMs(promptChars: Int, fastMode: Boolean): Long {
        val base = if (fastMode) 30_000L else 60_000L
        val extra = (promptChars / 8).toLong()
        return min(120_000L, max(base, base + extra))
    }

    companion object {
        const val NOT_READY = "__LLAMA_NOT_READY__"

        @Volatile private var instance: LocalLlamaHelper? = null

        fun get(context: Context): LocalLlamaHelper {
            instance?.let { return it }
            synchronized(this) {
                instance?.let { return it }
                val created = LocalLlamaHelper(context.applicationContext)
                instance = created
                return created
            }
        }
    }
}
