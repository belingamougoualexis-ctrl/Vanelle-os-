package com.vanelle.os
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Mémoire relationnelle : profil, faits, humeurs, contexte de conversation.
 * Stockage chiffré via MemoryVault + prefs structurées.
 */
class RelationalMemory(private val c: Context) {
    private val vault = MemoryVault(c)
    private val prefs = c.getSharedPreferences("vanelle_relational", 0)

    fun setProfileField(key: String, value: String) {
        vault.save("profile_$key", value.trim())
        logEvent("memory", "Profil: $key")
    }

    fun getProfileField(key: String): String? = vault.get("profile_$key")

    fun getProfileSummary(): String {
        val keys = listOf("prenom", "ville", "travail", "humeur", "projet", "preference_ton")
        val parts = keys.mapNotNull { k ->
            getProfileField(k)?.let { v -> if (v.isNotBlank()) "$k: $v" else null }
        }
        return parts.joinToString(". ")
    }

    fun rememberFact(fact: String) {
        val arr = JSONArray(prefs.getString("facts", "[]"))
        arr.put(JSONObject().put("t", System.currentTimeMillis()).put("f", fact.take(300)))
        // garde les 40 derniers
        val trimmed = JSONArray()
        val start = (arr.length() - 40).coerceAtLeast(0)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        prefs.edit().putString("facts", trimmed.toString()).apply()
        try { UserDataSnapshot.save(c) } catch (_: Exception) {}
        vault.save("fact_${System.currentTimeMillis()}", fact.take(300))
        logEvent("memory", "Fait: ${fact.take(80)}")
    }

    fun recentFacts(limit: Int = 8): List<String> {
        val arr = JSONArray(prefs.getString("facts", "[]"))
        val out = mutableListOf<String>()
        for (i in (arr.length() - 1) downTo 0) {
            if (out.size >= limit) break
            out.add(arr.getJSONObject(i).optString("f"))
        }
        return out
    }

    fun setMood(mood: String) {
        setProfileField("humeur", mood)
        prefs.edit().putLong("mood_ts", System.currentTimeMillis()).apply()
    }

    fun displayName(): String =
        getProfileField("prenom")?.takeIf { it.isNotBlank() }?.trim() ?: ""

    /**
     * Texte à faire dire à la mascotte : uniquement le prénom en tête, puis la réponse.
     * Jamais « je m'appelle … ».
     */
    fun withSpokenName(answer: String): String {
        val prenom = displayName()
        var body = answer.trim()
        // Nettoie si le modèle a glissé une formule du type « je m'appelle X »
        body = body.replace(Regex("(?i)je m['']appelle\\s+\\w+[,.]?\\s*"), "")
            .replace(Regex("(?i)enchant[ée]e?[,.]?\\s*"), "")
            .trim()
        if (prenom.isBlank()) return body
        // Évite « Paul, Paul, … »
        val lower = body.lowercase()
        if (lower.startsWith(prenom.lowercase() + ",") || lower.startsWith(prenom.lowercase() + " ")) {
            return body
        }
        return "$prenom, $body"
    }

    fun profilePhotoFile(): File = File(c.filesDir, "profile_photo.jpg")

    fun hasProfilePhoto(): Boolean = profilePhotoFile().let { it.exists() && it.length() > 0 }

    fun saveProfilePhotoFromUri(uri: android.net.Uri): Boolean {
        return try {
            c.contentResolver.openInputStream(uri)?.use { input ->
                profilePhotoFile().outputStream().use { output -> input.copyTo(output) }
            }
            hasProfilePhoto()
        } catch (_: Exception) {
            false
        }
    }

    fun clearProfilePhoto() {
        try { profilePhotoFile().delete() } catch (_: Exception) {}
    }

    /** Contexte injecté dans le prompt IA — profil + faits (sans l'historique dialogue). */
    fun contextForAi(): String {
        if (PersonalityPrefs.isGuestMode(c)) return ""
        val sb = StringBuilder()
        val prenom = displayName()
        if (prenom.isNotBlank()) {
            sb.append("Prénom de l'utilisateur : ").append(prenom).append(". ")
            sb.append("Utilise seulement le prénom ").append(prenom).append(". Ne dis jamais « je m'appelle ». ")
        }
        val profile = getProfileSummary().take(240)
        if (profile.isNotBlank()) sb.append("Profil: ").append(profile).append(". ")
        val facts = recentFacts(8)
        if (facts.isNotEmpty()) {
            sb.append("Faits mémorisés: ").append(facts.joinToString(" | ") { it.take(100) })
        }
        return sb.toString().trim().take(550)
    }

    /**
     * Contexte complet : profil + faits + historique multi-tours.
     * Pour suivre le fil comme ChatGPT (pronoms, « et pour X », liens entre sujets).
     */
    fun fullContextForAi(dialogTurns: Int = 12, maxChars: Int = 1600): String {
        if (PersonalityPrefs.isGuestMode(c)) return ""
        val sb = StringBuilder()
        val profile = contextForAi()
        if (profile.isNotBlank()) sb.append(profile)
        val budget = (maxChars - sb.length).coerceAtLeast(400)
        val dialog = recentDialog(dialogTurns, maxChars = budget)
        if (dialog.isNotBlank()) {
            if (sb.isNotEmpty()) sb.append("\n")
            sb.append("Conversation en cours (garde le fil, relie les sujets, résous les pronoms « ça », « lui », « et pour ») :\n")
            sb.append(dialog)
        }
        return sb.toString().trim().take(maxChars)
    }

    /** Historique de dialogue (multi-tours) pour le cerveau Llama. */
    fun addTurn(role: String, text: String) {
        if (PersonalityPrefs.isGuestMode(c)) return
        val clean = text.trim()
        if (clean.isBlank()) return
        val arr = JSONArray(prefs.getString("dialog", "[]"))
        arr.put(
            JSONObject()
                .put("r", role.take(12))
                .put("t", clean.take(400))
                .put("ts", System.currentTimeMillis())
        )
        // Conserve les 60 derniers tours
        val trimmed = JSONArray()
        val start = (arr.length() - 60).coerceAtLeast(0)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        prefs.edit().putString("dialog", trimmed.toString()).apply()
        try { UserDataSnapshot.save(c) } catch (_: Exception) {}
    }

    /**
     * @param limit nombre de tours (user+assistant)
     * @param maxChars budget caractères (n_ctx limité sur mobile)
     */
    fun recentDialog(limit: Int = 12, maxChars: Int = 1400): String {
        if (PersonalityPrefs.isGuestMode(c)) return ""
        val arr = JSONArray(prefs.getString("dialog", "[]"))
        if (arr.length() == 0) return ""
        val from = (arr.length() - limit).coerceAtLeast(0)
        // Priorise les tours les plus récents dans le budget
        val lines = mutableListOf<String>()
        var used = 0
        for (i in (arr.length() - 1) downTo from) {
            val o = arr.getJSONObject(i)
            val role = if (o.optString("r") == "user") "Utilisateur" else "Vanelle"
            val content = o.optString("t").trim()
            if (content.isBlank()) continue
            val line = "$role: $content"
            if (used + line.length + 1 > maxChars && lines.isNotEmpty()) break
            lines.add(0, line)
            used += line.length + 1
        }
        return lines.joinToString("\n").trim()
    }

    fun clearDialog() {
        prefs.edit().remove("dialog").apply()
    }

    fun clearAll() {
        vault.clear()
        prefs.edit().clear().apply()
        logEvent("memory", "Mémoire effacée")
    }

    private fun logEvent(type: String, detail: String) {
        ActivityLog.add(c, type, detail)
    }
}
