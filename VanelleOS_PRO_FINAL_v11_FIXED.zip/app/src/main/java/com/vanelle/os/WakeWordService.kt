package com.vanelle.os

import android.app.*
import android.content.Intent
import android.os.Bundle
import android.os.IBinder
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class WakeWordService : Service() {
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val detector by lazy { OpenWakeWordDetector(this) }
    private var usingOpenWakeWord = false

    /**
     * Flag manuel : Service n'expose pas isDestroyed
     * (contrairement à LifecycleService / Activity / Fragment).
     * Doit être vérifié avant tout redémarrage d'écoute ou callback asynchrone.
     */
    @Volatile
    private var isServiceDestroyed = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isServiceDestroyed = false
        try {
            val id = "vanelle_wake"
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(
                NotificationChannel(id, "Vanelle", NotificationManager.IMPORTANCE_LOW)
            )
            val n = NotificationCompat.Builder(this, id)
                .setContentTitle("VanelleOS")
                .setContentText("Ecoute active")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
            startForeground(1, n)
            tts = TextToSpeech(this) { status ->
                if (status == TextToSpeech.SUCCESS) tts?.language = Locale.FRANCE
            }
            scope.launch {
                withContext(Dispatchers.IO) {
                    WakeWordModelManager.downloadIfNeeded(this@WakeWordService)
                }
                if (isServiceDestroyed) return@launch
                startBestAvailableListening()
            }
        } catch (_: Exception) {
            stopSelf()
        }
    }

    /**
     * Choisit le meilleur mode d'écoute disponible :
     * openWakeWord (silencieux) si prêt, sinon retry périodique.
     * Aucun SpeechRecognizer ne doit rester actif en arrière-plan
     * (évite second micro + bips système).
     */
    private fun startBestAvailableListening() {
        if (isServiceDestroyed) return
        if (WakeWordModelManager.isReady(this) && detector.prepare()) {
            usingOpenWakeWord = true
            detector.start { onWakeDetected() }
        } else {
            usingOpenWakeWord = false
            scheduleWakeModelRetry()
        }
    }

    /**
     * Déclenchée par le détecteur silencieux :
     * capture UNE seule commande (bip système une seule fois).
     */
    private fun onWakeDetected() {
        if (isServiceDestroyed) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            resumeListening()
            return
        }
        // Libère l'AudioRecord openWakeWord avant la transcription.
        // Jamais deux captures micro simultanées.
        detector.stop()
        try {
            rec?.destroy()
            rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onResults(r: Bundle?) {
                        if (isServiceDestroyed) return
                        val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull() ?: ""
                        if (t.isNotBlank()) handleCommand(t)
                        resumeListening()
                    }

                    override fun onError(e: Int) {
                        if (!isServiceDestroyed) resumeListening()
                    }

                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                    override fun onPartialResults(p: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                }
                try {
                    // Le détecteur openWakeWord reste silencieux.
                    // SpeechRecognizer n'est lancé qu'après le mot d'activation.
                    // Aucun changement du volume système.
                    startListening(intent)
                } catch (_: Exception) {
                    resumeListening()
                }
            }
        } catch (_: Exception) {
            resumeListening()
        }
    }

    private fun scheduleWakeModelRetry() {
        scope.launch {
            delay(1000)
            if (isServiceDestroyed) return@launch
            startBestAvailableListening()
        }
    }

    private fun resumeListening() {
        if (isServiceDestroyed) return
        scope.launch {
            delay(500)
            if (isServiceDestroyed) return@launch
            if (usingOpenWakeWord) {
                detector.start { onWakeDetected() }
            } else {
                scheduleWakeModelRetry()
            }
        }
    }

    private val wakeVariants = listOf(
        "cassandra", "cassandre", "casandra", "cassandras", "kasandra", "cass", "sandra"
    )

    private fun findWakeIndex(text: String): Int {
        val lower = text.lowercase()
        val regex = Regex("[a-zàâäéèêëîïôöùûüç]+")
        for (m in regex.findAll(lower)) {
            val w = m.value
            if (w in wakeVariants ||
                FuzzyMatch.close(w, "cassandra", 2) ||
                FuzzyMatch.close(w, "cassandre", 2)
            ) {
                return m.range.first
            }
        }
        return -1
    }

    private fun wakeWordEnd(text: String, startIdx: Int): Int {
        val lower = text.lowercase()
        val regex = Regex("[a-zàâäéèêëîïôöùûüç]+")
        val m = regex.find(lower, startIdx) ?: return startIdx
        return m.range.last + 1
    }

    /**
     * Utilisée quand la détection acoustique openWakeWord a déjà confirmé
     * le mot d'activation : tout le texte capté est la commande.
     */
    private fun handleCommand(text: String) {
        if (isServiceDestroyed || text.isBlank()) return
        if (TranslateModePrefs.isActive(this)) {
            handleTranslateMode(text)
            return
        }
        // Si le wake word est encore dans la phrase, on le retire
        val idx = findWakeIndex(text)
        val original = if (idx >= 0) {
            val endIdx = wakeWordEnd(text, idx)
            text.substring(endIdx.coerceAtMost(text.length)).trim().ifEmpty { text.trim() }
        } else {
            text.trim()
        }
        dispatchCommand(original, original.lowercase())
    }

    private fun dispatchCommand(originalCmd: String, cmd: String) {
        if (isServiceDestroyed) return
        val parsed = CommandParser.parse(originalCmd)
        if (parsed.intent == CommandIntent.CALL_CONTACT ||
            parsed.intent == CommandIntent.SEND_MESSAGE
        ) {
            try {
                val i = Intent(this@WakeWordService, MainActivity::class.java).apply {
                    putExtra(
                        "confirm_type",
                        if (parsed.intent == CommandIntent.CALL_CONTACT) "call" else "sms"
                    )
                    putExtra("confirm_name", parsed.args["name"] ?: "")
                    putExtra("confirm_message", parsed.args["message"] ?: "")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(i)
            } catch (_: Exception) {
            }
            return
        }
        scope.launch {
            if (isServiceDestroyed) return@launch
            try {
                val i = Intent(this@WakeWordService, MainActivity::class.java).apply {
                    // Conserver la casse / formulation d'origine pour noms de contacts, etc.
                    putExtra("pending_command", originalCmd.ifBlank { cmd })
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(i)
            } catch (_: Exception) {
            }
        }
    }

    private fun handleTranslateMode(text: String) {
        if (isServiceDestroyed) return
        val parsed = CommandParser.parse(text)
        if (parsed.intent == CommandIntent.TRANSLATE_MODE_OFF) {
            TranslateModePrefs.stop(this)
            try {
                tts?.speak("Mode traduction desactive", TextToSpeech.QUEUE_FLUSH, null, "tr_off")
            } catch (_: Exception) {
            }
            return
        }
        val src = TranslateModePrefs.source(this)
        val tgt = TranslateModePrefs.target(this)
        scope.launch {
            if (isServiceDestroyed) return@launch
            val translated = withContext(Dispatchers.IO) {
                TranslateHelper(this@WakeWordService).translateText(text, src, tgt)
            }
            if (isServiceDestroyed) return@launch
            try {
                tts?.language = Locale.forLanguageTag(if (tgt == "zh-CN") "zh" else tgt)
            } catch (_: Exception) {
            }
            try {
                tts?.speak(translated, TextToSpeech.QUEUE_FLUSH, null, "tr_out")
            } catch (_: Exception) {
            }
        }
    }

    private fun restart() {
        scope.launch {
            delay(800)
            if (isServiceDestroyed) return@launch
            startBestAvailableListening()
        }
    }

    override fun onDestroy() {
        isServiceDestroyed = true
        try {
            rec?.destroy()
        } catch (_: Exception) {
        }
        try {
            detector.stop()
        } catch (_: Exception) {
        }
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        scope.cancel()
        super.onDestroy()
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int = START_STICKY
}
