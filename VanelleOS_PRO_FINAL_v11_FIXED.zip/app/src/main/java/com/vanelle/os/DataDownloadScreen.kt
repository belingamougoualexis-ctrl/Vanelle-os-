package com.vanelle.os
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.core.content.ContextCompat

/**
 * Écran d'ouverture / téléchargement ultra soigné :
 * - animation décorative de la mascotte Vanelle
 * - halo animé, barre de progression, textes neutres (« données »)
 * - reste visible tant que le service télécharge ; se retire à la fin
 */
object DataDownloadScreen {

    private var root: FrameLayout? = null
    private var progressBar: ProgressBar? = null
    private var pctText: TextView? = null
    private var statusText: TextView? = null
    private var hero: ImageView? = null
    private var receiver: BroadcastReceiver? = null
    private val handler = Handler(Looper.getMainLooper())
    private var mascotIndex = 0
    private var mascotRunnable: Runnable? = null
    private var pulseAnim: AnimatorSet? = null

    private val mascotIds = listOf(
        "galaxy", "aurora", "gold", "lava", "rose", "obsidian",
        "carbon", "mint", "bronze", "kawaii", "ice", "crystal"
    )

    fun maybeShow(activity: Activity) {
        if (LlamaModelManager.isReady(activity)) return
        // Démarre toujours le service (continue en arrière-plan)
        DataDownloadService.start(activity)
        if (root != null) return
        attach(activity)
        register(activity)
        startMascotLoop(activity)
        startPulse()
        // État initial
        val partial = LlamaModelManager.partialBytes(activity)
        val pct = if (partial > 0)
            ((partial * 100) / LlamaModelManager.EXPECTED_MIN_BYTES).toInt().coerceIn(0, 99)
        else 0
        updateUi(pct, if (pct > 0) "Reprise du téléchargement…" else "Préparation des données…")
    }

    fun dismiss(activity: Activity) {
        stopAnims()
        unregister(activity)
        try {
            (root?.parent as? ViewGroup)?.removeView(root)
        } catch (_: Exception) {}
        root = null
        progressBar = null
        pctText = null
        statusText = null
        hero = null
    }

    private fun attach(activity: Activity) {
        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val overlay = FrameLayout(activity).apply {
            setBackgroundColor(0xFFFAF7FB.toInt())
            isClickable = true
            isFocusable = true
            elevation = 40f
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }

        val column = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(48), dp(28), dp(32))
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }

        val title = TextView(activity).apply {
            text = "VanelleOS"
            setTextColor(0xFFFF2D95.toInt())
            textSize = 26f
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        }

        val subtitle = TextView(activity).apply {
            text = "Préparation de ton assistant"
            setTextColor(0xFF6B6B70.toInt())
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(28))
        }

        // Halo derrière la mascotte
        val halo = View(activity).apply {
            val size = dp(200)
            layoutParams = FrameLayout.LayoutParams(size, size).apply { gravity = Gravity.CENTER }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x33FF2D95)
            }
            tag = "halo"
        }

        val heroFrame = FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(dp(220), dp(220)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
            }
            addView(halo)
            val img = ImageView(activity).apply {
                layoutParams = FrameLayout.LayoutParams(dp(170), dp(170)).apply { gravity = Gravity.CENTER }
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
                try {
                    setImageResource(MascotManager.getDrawableId(activity, mascotIds[0]))
                } catch (_: Exception) {}
            }
            hero = img
            addView(img)
        }

        statusText = TextView(activity).apply {
            text = "Préparation des données…"
            setTextColor(0xFF0A0A0A.toInt())
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, dp(10))
        }

        progressBar = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            layoutParams = LinearLayout.LayoutParams(-1, dp(10)).apply {
                topMargin = dp(4)
            }
            if (Build.VERSION.SDK_INT >= 21) {
                progressTintList = android.content.res.ColorStateList.valueOf(0xFFFF2D95.toInt())
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0x33FF2D95)
            }
        }

        pctText = TextView(activity).apply {
            text = "0 %"
            setTextColor(0xFF8A8A8E.toInt())
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }

        val hint = TextView(activity).apply {
            text = "Installation automatique de l’IA. Le téléchargement reprend automatiquement en cas de coupure."
            setTextColor(0xFF9A9A9E.toInt())
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(24), dp(8), 0)
        }

        column.addView(title)
        column.addView(subtitle)
        column.addView(heroFrame)
        column.addView(statusText)
        column.addView(progressBar)
        column.addView(pctText)
        column.addView(hint)
        overlay.addView(column)

        val decor = activity.window.decorView as ViewGroup
        decor.addView(overlay)
        root = overlay
    }

    private fun startMascotLoop(activity: Activity) {
        mascotRunnable?.let { handler.removeCallbacks(it) }
        val r = object : Runnable {
            override fun run() {
                val img = hero ?: return
                mascotIndex = (mascotIndex + 1) % mascotIds.size
                val id = MascotManager.getDrawableId(activity, mascotIds[mascotIndex])
                // Crossfade simple
                img.animate().alpha(0.25f).setDuration(220).withEndAction {
                    try { if (id != 0) img.setImageResource(id) } catch (_: Exception) {}
                    img.animate().alpha(1f).setDuration(280).start()
                }.start()
                // Légère rotation / scale
                img.animate().rotationBy(6f).setDuration(500).start()
                handler.postDelayed(this, 2200)
            }
        }
        mascotRunnable = r
        handler.postDelayed(r, 1800)
    }

    private fun startPulse() {
        val overlay = root ?: return
        val halo = (overlay.getChildAt(0) as? ViewGroup)?.let { col ->
            // heroFrame is 3rd child (0 title, 1 subtitle, 2 heroFrame)
            (col.getChildAt(2) as? ViewGroup)?.findViewWithTag<View>("halo")
        } ?: return
        val a1 = ObjectAnimator.ofFloat(halo, View.SCALE_X, 0.85f, 1.15f).apply {
            duration = 1400; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        val a2 = ObjectAnimator.ofFloat(halo, View.SCALE_Y, 0.85f, 1.15f).apply {
            duration = 1400; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        val a3 = ObjectAnimator.ofFloat(halo, View.ALPHA, 0.35f, 0.75f).apply {
            duration = 1400; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
        }
        pulseAnim = AnimatorSet().apply {
            playTogether(a1, a2, a3)
            start()
        }
    }

    private fun stopAnims() {
        mascotRunnable?.let { handler.removeCallbacks(it) }
        mascotRunnable = null
        pulseAnim?.cancel()
        pulseAnim = null
    }

    private fun updateUi(pct: Int, status: String) {
        progressBar?.progress = pct.coerceIn(0, 100)
        pctText?.text = "$pct %"
        statusText?.text = status
    }

    private fun register(activity: Activity) {
        unregister(activity)
        receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                when (intent?.action) {
                    DataDownloadService.ACTION_PROGRESS -> {
                        val p = intent.getIntExtra(DataDownloadService.EXTRA_PERCENT, 0)
                        val s = intent.getStringExtra(DataDownloadService.EXTRA_STATUS) ?: "Mise à jour…"
                        updateUi(p, s)
                    }
                    DataDownloadService.ACTION_WAITING -> {
                        val p = intent.getIntExtra(DataDownloadService.EXTRA_PERCENT, 0)
                        val s = intent.getStringExtra(DataDownloadService.EXTRA_STATUS) ?: "En attente…"
                        updateUi(p, s)
                    }
                    DataDownloadService.ACTION_DONE -> {
                        updateUi(100, "Données prêtes")
                        handler.postDelayed({ dismiss(activity) }, 900)
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(DataDownloadService.ACTION_PROGRESS)
            addAction(DataDownloadService.ACTION_WAITING)
            addAction(DataDownloadService.ACTION_DONE)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            activity.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            activity.registerReceiver(receiver, filter)
        }
    }

    private fun unregister(activity: Activity) {
        try { receiver?.let { activity.unregisterReceiver(it) } } catch (_: Exception) {}
        receiver = null
    }
}
