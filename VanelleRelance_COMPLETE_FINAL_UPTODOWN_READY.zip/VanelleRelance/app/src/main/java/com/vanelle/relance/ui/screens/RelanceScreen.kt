package com.vanelle.relance.ui.screens

import android.Manifest
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vanelle.relance.data.Client
import com.vanelle.relance.data.CanalRelance
import com.vanelle.relance.data.ClientViewModel
import com.vanelle.relance.data.StatutDette
import com.vanelle.relance.utils.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

enum class FiltreClient { TOUS, EN_COURS, EN_RETARD, PAYES }
enum class TriClient { ECHEANCE, MONTANT, NOM, RELANCES }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RelanceScreen(viewModel: ClientViewModel = viewModel()) {
    val context = LocalContext.current
    val clients by viewModel.tousLesClients.collectAsState(initial = emptyList())
    var afficherAjout by remember { mutableStateOf(false) }
    var clientAEditer by remember { mutableStateOf<Client?>(null) }
    var recherche by remember { mutableStateOf("") }
    var filtre by remember { mutableStateOf(FiltreClient.TOUS) }
    var tri by remember { mutableStateOf(TriClient.ECHEANCE) }
    var afficherImportContacts by remember { mutableStateOf(false) }
    var clientNegociation by remember { mutableStateOf<Client?>(null) }
    var clientAConfirmerPaye by remember { mutableStateOf<Client?>(null) }
    var clientPourEnvoi by remember { mutableStateOf<Pair<Client, CanalRelance>?>(null) }
    var menuTriOuvert by remember { mutableStateOf(false) }
    var modeCampagne by remember { mutableStateOf(false) }
    var selectionCampagne by remember { mutableStateOf(setOf<Long>()) }

    var permissionADemander by remember { mutableStateOf<String?>(null) }
    var actionApresPermission by remember { mutableStateOf<(() -> Unit)?>(null) }

    val launcherPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { accordee ->
        if (accordee) actionApresPermission?.invoke()
        else Toast.makeText(context, "Permission refusée. Activez-la dans Réglages.", Toast.LENGTH_LONG).show()
        permissionADemander = null
        actionApresPermission = null
    }

    fun demanderPermissionSiBesoin(permission: String, action: () -> Unit) {
        if (PermissionHelper.estAccordee(context, permission)) action()
        else {
            permissionADemander = permission
            actionApresPermission = action
        }
    }

    val clientsFiltres = remember(clients, recherche, filtre, tri) {
        clients
            .filter { client ->
                when (filtre) {
                    FiltreClient.TOUS -> true
                    FiltreClient.EN_COURS -> client.statut == StatutDette.EN_COURS
                    FiltreClient.EN_RETARD -> client.statut == StatutDette.EN_RETARD
                    FiltreClient.PAYES -> client.statut == StatutDette.PAYEE
                }
            }
            .filter { client ->
                if (recherche.isBlank()) true
                else client.nom.contains(recherche, ignoreCase = true) ||
                        client.telephone.contains(recherche.filter { it.isDigit() })
            }
            .let { liste ->
                when (tri) {
                    TriClient.ECHEANCE -> liste.sortedBy { it.dateEcheance }
                    TriClient.MONTANT -> liste.sortedByDescending { it.montant }
                    TriClient.NOM -> liste.sortedBy { it.nom.lowercase(Locale.ROOT) }
                    TriClient.RELANCES -> liste.sortedByDescending { it.nombreRelances }
                }
            }
    }

    val compteurs = remember(clients) {
        mapOf(
            FiltreClient.TOUS to clients.size,
            FiltreClient.EN_COURS to clients.count { it.statut == StatutDette.EN_COURS },
            FiltreClient.EN_RETARD to clients.count { it.statut == StatutDette.EN_RETARD },
            FiltreClient.PAYES to clients.count { it.statut == StatutDette.PAYEE }
        )
    }

    // Envoie le message final (choisi dans DialogueEnvoiMessage : automatique ou personnalisé)
    // sur le canal demandé, avec les mêmes vérifications/permissions qu'avant.
    fun envoyerMessageFinal(client: Client, canal: CanalRelance, message: String) {
        when (canal) {
            CanalRelance.SMS -> {
                demanderPermissionSiBesoin(Manifest.permission.SEND_SMS) {
                    if (SmsHelper.envoyerTexte(context, client, message)) {
                        viewModel.enregistrerRelanceSiAutorisee(client)
                        HistoriqueHelper.enregistrer(context, "SMS", client.nom, "Relance SMS")
                    } else Toast.makeText(context, "Échec de l'envoi du SMS", Toast.LENGTH_SHORT).show()
                }
            }
            CanalRelance.WHATSAPP -> {
                if (!AutomationHelper.serviceActive()) {
                    Toast.makeText(context, "Activez le service d'accessibilité Vanelle dans Paramètres > Accessibilité.", Toast.LENGTH_LONG).show()
                    AutomationHelper.openAccessibilitySettings(context)
                } else if (AutomationHelper.startWhatsApp(context, client, message)) {
                    viewModel.enregistrerRelanceSiAutorisee(client)
                    HistoriqueHelper.enregistrer(context, "WhatsApp", client.nom, "Envoi via accessibilité")
                } else Toast.makeText(context, "WhatsApp non installé ou numéro invalide", Toast.LENGTH_SHORT).show()
            }
            CanalRelance.GMAIL -> {
                if (client.email.isBlank()) {
                    Toast.makeText(context, "Ajoutez l'e-mail du client dans Modifier.", Toast.LENGTH_LONG).show()
                } else if (!AutomationHelper.serviceActive()) {
                    Toast.makeText(context, "Activez le service d'accessibilité Vanelle dans Paramètres > Accessibilité.", Toast.LENGTH_LONG).show()
                    AutomationHelper.openAccessibilitySettings(context)
                } else if (AutomationHelper.startEmail(context, client, client.objetEmail, message)) {
                    viewModel.enregistrerRelanceSiAutorisee(client)
                    HistoriqueHelper.enregistrer(context, "EMAIL", client.nom, "Envoi via accessibilité")
                } else Toast.makeText(context, "Gmail non disponible ou e-mail invalide", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun exporterListe() {
        if (clients.isEmpty()) {
            Toast.makeText(context, "Aucun client à exporter", Toast.LENGTH_SHORT).show()
            return
        }
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
        val sb = StringBuilder()
        sb.appendLine("=== Vanelle Relance — Liste des clients ===")
        sb.appendLine("Exporté le ${dateFormat.format(Date())}")
        sb.appendLine()
        clients.forEach { c ->
            val statut = when (c.statut) {
                StatutDette.PAYEE -> "Payé"
                StatutDette.EN_RETARD -> "En retard"
                StatutDette.EN_COURS -> "En cours"
            }
            sb.appendLine("• ${c.nom}")
            sb.appendLine("  Tél: ${PhoneUtils.formaterAffichage(c.telephone)}")
            sb.appendLine("  Montant: ${"%,.0f".format(c.montant).replace(",", " ")} FCFA")
            sb.appendLine("  Échéance: ${SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(c.dateEcheance))} — $statut")
            if (c.nombreRelances > 0) sb.appendLine("  Relances: ${c.nombreRelances}")
            if (c.note.isNotBlank()) sb.appendLine("  Note: ${c.note}")
            sb.appendLine()
        }
        val totalDu = clients.filter { it.statut != StatutDette.PAYEE }.sumOf { it.montant }
        val totalRecupere = clients.filter { it.statut == StatutDette.PAYEE }.sumOf { it.montant }
        sb.appendLine("────────────────────────")
        sb.appendLine("Total encore dû : ${"%,.0f".format(totalDu).replace(",", " ")} FCFA")
        sb.appendLine("Total récupéré  : ${"%,.0f".format(totalRecupere).replace(",", " ")} FCFA")

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Vanelle Relance — Export clients")
            putExtra(Intent.EXTRA_TEXT, sb.toString())
        }
        context.startActivity(Intent.createChooser(intent, "Partager la liste"))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Relance") },
                actions = {
                    IconButton(onClick = {
                        demanderPermissionSiBesoin(Manifest.permission.READ_CONTACTS) {
                            afficherImportContacts = true
                        }
                    }) {
                        Icon(Icons.Default.Contacts, contentDescription = "Importer un contact")
                    }
                    Box {
                        IconButton(onClick = { menuTriOuvert = true }) {
                            Icon(Icons.Default.Sort, contentDescription = "Trier")
                        }
                        DropdownMenu(expanded = menuTriOuvert, onDismissRequest = { menuTriOuvert = false }) {
                            DropdownMenuItem(text = { Text("Par échéance") }, onClick = { tri = TriClient.ECHEANCE; menuTriOuvert = false })
                            DropdownMenuItem(text = { Text("Par montant") }, onClick = { tri = TriClient.MONTANT; menuTriOuvert = false })
                            DropdownMenuItem(text = { Text("Par nom") }, onClick = { tri = TriClient.NOM; menuTriOuvert = false })
                            DropdownMenuItem(text = { Text("Par nb relances") }, onClick = { tri = TriClient.RELANCES; menuTriOuvert = false })
                        }
                    }
                    IconButton(onClick = {
                        modeCampagne = !modeCampagne
                        if (!modeCampagne) selectionCampagne = emptySet()
                    }) {
                        Icon(Icons.Default.Send, contentDescription = "Campagne de masse")
                    }
                    IconButton(onClick = { exporterListe() }) {
                        Icon(Icons.Default.Share, contentDescription = "Exporter")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { afficherAjout = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ajouter")
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value = recherche,
                onValueChange = { recherche = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                placeholder = { Text("Rechercher un client…") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = {
                    if (recherche.isNotEmpty()) {
                        IconButton(onClick = { recherche = "" }) {
                            Icon(Icons.Default.Clear, "Effacer")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FiltreChip("Tous (${compteurs[FiltreClient.TOUS]})", filtre == FiltreClient.TOUS) { filtre = FiltreClient.TOUS }
                FiltreChip("En cours (${compteurs[FiltreClient.EN_COURS]})", filtre == FiltreClient.EN_COURS) { filtre = FiltreClient.EN_COURS }
                FiltreChip("En retard (${compteurs[FiltreClient.EN_RETARD]})", filtre == FiltreClient.EN_RETARD) { filtre = FiltreClient.EN_RETARD }
                FiltreChip("Payés (${compteurs[FiltreClient.PAYES]})", filtre == FiltreClient.PAYES) { filtre = FiltreClient.PAYES }
            }


            // Barre campagne de masse
            if (modeCampagne) {
                Surface(color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 8.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            "${selectionCampagne.size} sélectionné(s)",
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = {
                            val prefs = PreferencesHelper(context)
                            val cibles = clientsFiltres.filter {
                                it.id in selectionCampagne && it.statut != StatutDette.PAYEE &&
                                    !(it.enAttenteReponse && prefs.pauseRelancesSurReponse)
                            }
                            cibles.forEach { c ->
                                if (SmsHelper.permissionAccordee(context)) {
                                    if (viewModel.peutRelancer(c)) {
                                    if (SmsHelper.envoyer(context, c, c.nombreRelances)) {
                                        viewModel.enregistrerRelanceSiAutorisee(c)
                                        HistoriqueHelper.enregistrer(context, "CAMPAGNE_SMS", c.nom, "Relance masse")
                                    }
                                }
                                }
                            }
                            modeCampagne = false
                            selectionCampagne = emptySet()
                        }) { Text("SMS masse") }
                        TextButton(onClick = {
                            modeCampagne = false
                            selectionCampagne = emptySet()
                        }) { Text("Annuler") }
                    }
                }
            }

            if (clientsFiltres.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            if (recherche.isBlank() && filtre == FiltreClient.TOUS) Icons.Default.Person else Icons.Default.Search,
                            null, Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                        )
                        Spacer(Modifier.height(16.dp))
                        Text(
                            when {
                                recherche.isNotBlank() -> "Aucun résultat pour « $recherche »"
                                filtre != FiltreClient.TOUS -> "Aucun client dans ce filtre"
                                else -> "Aucun client pour l'instant.\nAppuie sur + pour en ajouter un."
                            },
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(clientsFiltres, key = { it.id }) { client ->
                        if (modeCampagne && client.statut != StatutDette.PAYEE) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = client.id in selectionCampagne,
                                    onCheckedChange = { checked ->
                                        selectionCampagne = if (checked) selectionCampagne + client.id
                                        else selectionCampagne - client.id
                                    }
                                )
                                Box(Modifier.weight(1f)) {
                                    CarteClient(
                                        client = client,
                                        onSms = {},
                                        onWhatsApp = {},
                                        onEmail = {},
                                        onAppel = {},
                                        onPaye = {},
                                        onReouvrir = {},
                                        onEditer = {},
                                        onSupprimer = {},
                                        onReprendreRelances = {}
                                    )

                                }
                            }
                        } else {
                        CarteClient(
                            client = client,
                            onSms = { clientPourEnvoi = client to CanalRelance.SMS },
                            onWhatsApp = { clientPourEnvoi = client to CanalRelance.WHATSAPP },
                            onEmail = {
                                if (client.email.isBlank()) {
                                    Toast.makeText(context, "Ajoutez l'e-mail du client dans Modifier.", Toast.LENGTH_LONG).show()
                                } else {
                                    clientPourEnvoi = client to CanalRelance.GMAIL
                                }
                            },
                            onReprendreRelances = { viewModel.reprendreRelances(client) },
                            onAppel = {
                                demanderPermissionSiBesoin(Manifest.permission.CALL_PHONE) {
                                    CallHelper.appeler(context, client)
                                    viewModel.enregistrerRelanceSiAutorisee(client)
                                    HistoriqueHelper.enregistrer(context, "APPEL", client.nom, "Appel de relance")
                                }
                            },
                            onPaye = { clientAConfirmerPaye = client },
                            onReouvrir = { viewModel.marquerEnCours(client) },
                            onEditer = { clientAEditer = client },
                            onSupprimer = { viewModel.supprimer(client) },
                            onNegocier = { clientNegociation = client }
                        )
                        }
                    }
                }
            }
        }
    }


    // Dialogue de négociation (en plus des relances)
    clientNegociation?.let { clientNego ->
        DialogueNegociation(
            client = clientNego,
            onDismiss = { clientNegociation = null },
            onEnvoye = { canal, type ->
                viewModel.enregistrerRelanceSiAutorisee(clientNego)
                HistoriqueHelper.enregistrer(
                    context,
                    "NEGO-$canal",
                    clientNego.nom,
                    "Négociation ${type.name.lowercase()} via $canal"
                )
                clientNegociation = null
            }
        )
    }

    if (afficherAjout) {
        DialogueClient(null, { afficherAjout = false }) { client ->
            // Anti-doublon simple
            val existe = clients.any {
                it.telephone == client.telephone || it.nom.equals(client.nom, ignoreCase = true)
            }
            if (existe) {
                Toast.makeText(context, "Un client similaire existe déjà", Toast.LENGTH_LONG).show()
            }
            if (!existe) {
                viewModel.ajouterEtRelancerImmediatement(client)
                afficherAjout = false
            }
        }
    }

    clientAEditer?.let { client ->
        DialogueClient(client, { clientAEditer = null }) { clientModifie ->
            if (client.id == 0L) {
                viewModel.ajouter(clientModifie.copy(id = 0))
            } else {
                viewModel.mettreAJour(clientModifie)
            }
            clientAEditer = null
        }
    }

    clientAConfirmerPaye?.let { client ->
        DialoguePaiementManuel(
            client = client,
            onDismiss = { clientAConfirmerPaye = null },
            onConfirmer = { montant, paiementTotal ->
                viewModel.marquerPaye(client, montant)
                HistoriqueHelper.enregistrer(
                    context,
                    if (paiementTotal) "PAYE" else "PAIEMENT PARTIEL",
                    client.nom,
                    "Montant ${"%,.0f".format(montant)}"
                )
                if (paiementTotal) {
                    try {
                        context.startActivity(Intent.createChooser(RecuHelper.intentPartage(client), "Partager le reçu"))
                    } catch (_: Exception) { }
                }
                clientAConfirmerPaye = null
            }
        )
    }

    clientPourEnvoi?.let { (client, canal) ->
        DialogueEnvoiMessage(
            client = client,
            canal = canal,
            onDismiss = { clientPourEnvoi = null },
            onEnvoyer = { message ->
                envoyerMessageFinal(client, canal, message)
                clientPourEnvoi = null
            }
        )
    }

    if (afficherImportContacts) {
        DialogueImportContacts(
            onDismiss = { afficherImportContacts = false },
            onPreRemplir = { contact ->
                afficherImportContacts = false
                clientAEditer = Client(
                    nom = contact.nom,
                    telephone = contact.telephone.filter { it.isDigit() },
                    montant = 0.0,
                    dateEcheance = System.currentTimeMillis() + 7L * 24 * 60 * 60 * 1000
                )
            }
        )
    }

    permissionADemander?.let { perm ->
        AlertDialog(
            onDismissRequest = { permissionADemander = null; actionApresPermission = null },
            icon = { Icon(Icons.Default.Security, null) },
            title = { Text("Autorisation ${PermissionHelper.titrePermission(perm)}") },
            text = { Text(PermissionHelper.messageRaison(perm) + "\n\nSans cette autorisation, cette fonctionnalité ne pourra pas fonctionner.") },
            confirmButton = { Button(onClick = { launcherPermission.launch(perm) }) { Text("Autoriser") } },
            dismissButton = {
                TextButton(onClick = { permissionADemander = null; actionApresPermission = null }) { Text("Plus tard") }
            }
        )
    }
}

@Composable
private fun FiltreChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        leadingIcon = if (selected) {{ Icon(Icons.Default.Check, null, Modifier.size(16.dp)) }} else null
    )
}

@Composable
fun CarteClient(
    client: Client,
    onSms: () -> Unit,
    onWhatsApp: () -> Unit,
    onEmail: () -> Unit,
    onAppel: () -> Unit,
    onPaye: () -> Unit,
    onReouvrir: () -> Unit,
    onEditer: () -> Unit,
    onSupprimer: () -> Unit,
    onNegocier: () -> Unit = {},
    onReprendreRelances: () -> Unit = {}
) {
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE) }
    var confirmerSuppression by remember { mutableStateOf(false) }

    val dernierContactTexte = client.dernierContact?.let {
        val jours = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - it)
        when {
            jours == 0L -> "Dernier contact : aujourd'hui"
            jours == 1L -> "Dernier contact : hier"
            else -> "Dernier contact : il y a $jours jours"
        }
    } ?: "Jamais contacté"

    ElevatedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(client.nom, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(PhoneUtils.formaterAffichage(client.telephone), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                BadgeStatut(client.statut)
            }
            // Score de risque intelligent
            val risque = RiskScore.calculer(client)
            if (client.statut != StatutDette.PAYEE) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "Risque ${risque.niveau.label} · ${risque.detail}",
                    style = MaterialTheme.typography.labelSmall,
                    color = RiskScore.couleur(risque.niveau),
                    fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                MoneyFormatter.format(context, client.montant) + " — échéance " + dateFormat.format(Date(client.dateEcheance)),
                style = MaterialTheme.typography.bodyMedium
            )
            if (client.nombreRelances > 0) {
                Text("${client.nombreRelances} relance(s) — $dernierContactTexte", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
            } else {
                Text(dernierContactTexte, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (client.note.isNotBlank()) {
                Text("📝 ${client.note}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (client.montantPaye > 0.01 && client.statut != StatutDette.PAYEE) {
                Text(
                    "Déjà réglé : ${MoneyFormatter.format(context, client.montantPaye)} — reste ${MoneyFormatter.format(context, client.montantRestant)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
            if (client.enAttenteReponse && client.statut != StatutDette.PAYEE) {
                Spacer(Modifier.height(6.dp))
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        Modifier.padding(horizontal = 10.dp, vertical = 8.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PauseCircle, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "A répondu — relances en pause",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = onReprendreRelances) { Text("Reprendre") }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (client.statut != StatutDette.PAYEE) {
                    FilledTonalIconButton(onClick = onSms) { Icon(Icons.Default.Sms, "SMS") }
                    FilledTonalIconButton(onClick = onWhatsApp) { Icon(Icons.Default.Chat, "WhatsApp") }
                    FilledTonalIconButton(onClick = onEmail) { Icon(Icons.Default.Email, "E-mail") }
                    FilledTonalIconButton(onClick = onAppel) { Icon(Icons.Default.Call, "Appeler") }
                    FilledTonalIconButton(onClick = onNegocier) { Icon(Icons.Default.Handshake, "Négocier") }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onPaye) { Text("Payé") }
                } else {
                    TextButton(onClick = onReouvrir) { Text("Réouvrir") }
                    Spacer(Modifier.weight(1f))
                }
                IconButton(onClick = onEditer) { Icon(Icons.Default.Edit, "Modifier") }
                IconButton(onClick = { confirmerSuppression = true }) {
                    Icon(Icons.Default.Delete, "Supprimer", tint = MaterialTheme.colorScheme.error)
                }
            if (client.statut != StatutDette.PAYEE) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "Toutes les relances sont automatiques. Choisissez le canal à la création : WhatsApp, SMS ou Gmail. WhatsApp/Gmail nécessitent le Service d’Accessibilité activé volontairement.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            }
        }
    }

    if (confirmerSuppression) {
        AlertDialog(
            onDismissRequest = { confirmerSuppression = false },
            title = { Text("Supprimer ${client.nom} ?") },
            text = { Text("Cette action est définitive.") },
            confirmButton = {
                TextButton(onClick = { onSupprimer(); confirmerSuppression = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { confirmerSuppression = false }) { Text("Annuler") } }
        )
    }
}

enum class ModeMessage { AUTOMATIQUE, PERSONNALISE }

/**
 * Avant chaque envoi (SMS / WhatsApp / e-mail), l'utilisateur choisit soit le message
 * automatique généré depuis les modèles de Réglages, soit un texte qu'il tape lui-même.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DialogueEnvoiMessage(
    client: Client,
    canal: CanalRelance,
    onDismiss: () -> Unit,
    onEnvoyer: (message: String) -> Unit
) {
    val context = LocalContext.current
    val messageAuto = remember(client) {
        MessageHelper.genererMessageRelance(context, client, client.nombreRelances)
    }
    var mode by remember { mutableStateOf(ModeMessage.AUTOMATIQUE) }
    var texteLibre by remember { mutableStateOf(messageAuto) }

    val nomCanal = when (canal) {
        CanalRelance.SMS -> "SMS"
        CanalRelance.WHATSAPP -> "WhatsApp"
        CanalRelance.GMAIL -> "e-mail"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Envoyer un $nomCanal à ${client.nom}", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()).heightIn(max = 460.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = mode == ModeMessage.AUTOMATIQUE,
                        onClick = { mode = ModeMessage.AUTOMATIQUE },
                        label = { Text("Message automatique") }
                    )
                    FilterChip(
                        selected = mode == ModeMessage.PERSONNALISE,
                        onClick = {
                            if (mode != ModeMessage.PERSONNALISE && texteLibre == messageAuto) {
                                // Pré-remplit avec le message auto pour partir d'une base, éditable librement.
                                texteLibre = messageAuto
                            }
                            mode = ModeMessage.PERSONNALISE
                        },
                        label = { Text("Message personnalisé") }
                    )
                }
                if (mode == ModeMessage.AUTOMATIQUE) {
                    Text("Aperçu du message", style = MaterialTheme.typography.labelMedium)
                    Surface(
                        tonalElevation = 2.dp,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(messageAuto, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                    }
                } else {
                    OutlinedTextField(
                        value = texteLibre,
                        onValueChange = { texteLibre = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Votre message") },
                        minLines = 4,
                        maxLines = 8
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = mode == ModeMessage.AUTOMATIQUE || texteLibre.isNotBlank(),
                onClick = {
                    onEnvoyer(if (mode == ModeMessage.AUTOMATIQUE) messageAuto else texteLibre.trim())
                }
            ) { Text("Envoyer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

enum class ModePaiement { TOTAL, PERSONNALISE }

/**
 * Dialogue de confirmation de paiement : l'utilisateur choisit soit un règlement total,
 * soit il saisit lui-même le montant réellement reçu (paiement partiel possible).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DialoguePaiementManuel(
    client: Client,
    onDismiss: () -> Unit,
    onConfirmer: (montant: Double, paiementTotal: Boolean) -> Unit
) {
    val context = LocalContext.current
    val pudique = remember { PreferencesHelper(context).modePudique }
    var mode by remember { mutableStateOf(ModePaiement.TOTAL) }
    var montantSaisi by remember { mutableStateOf("") }
    var erreur by remember { mutableStateOf<String?>(null) }

    val restant = client.montantRestant

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.CheckCircle, null) },
        title = { Text("Enregistrer un paiement") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    if (pudique) "Confirmer un règlement de ${client.nom} ?"
                    else "Reste dû par ${client.nom} : ${"%,.0f".format(restant).replace(",", " ")} FCFA",
                    style = MaterialTheme.typography.bodyMedium
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = mode == ModePaiement.TOTAL,
                        onClick = { mode = ModePaiement.TOTAL; erreur = null },
                        label = { Text("Paiement total") }
                    )
                    FilterChip(
                        selected = mode == ModePaiement.PERSONNALISE,
                        onClick = { mode = ModePaiement.PERSONNALISE; erreur = null },
                        label = { Text("Montant personnalisé") }
                    )
                }
                if (mode == ModePaiement.PERSONNALISE) {
                    OutlinedTextField(
                        value = montantSaisi,
                        onValueChange = { montantSaisi = it; erreur = null },
                        label = { Text("Montant reçu (FCFA)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    Text(
                        "Si le montant saisi est inférieur au solde, la dette restera ouverte avec le nouveau solde.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                erreur?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(onClick = {
                when (mode) {
                    ModePaiement.TOTAL -> onConfirmer(restant, true)
                    ModePaiement.PERSONNALISE -> {
                        val valeur = montantSaisi.replace(",", ".").replace(" ", "").toDoubleOrNull()
                        when {
                            valeur == null || valeur <= 0 -> erreur = "Indiquez un montant valide."
                            else -> onConfirmer(valeur.coerceAtMost(restant), valeur >= restant - 0.01)
                        }
                    }
                }
            }) { Text("Confirmer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
fun BadgeStatut(statut: StatutDette) {
    val (texte, couleur) = when (statut) {
        StatutDette.PAYEE -> "Payé" to MaterialTheme.colorScheme.primary
        StatutDette.EN_RETARD -> "En retard" to MaterialTheme.colorScheme.error
        StatutDette.EN_COURS -> "En cours" to MaterialTheme.colorScheme.tertiary
    }
    AssistChip(onClick = {}, label = { Text(texte) }, colors = AssistChipDefaults.assistChipColors(labelColor = couleur))
}

@Composable
fun DialogueImportContacts(onDismiss: () -> Unit, onPreRemplir: (ContactSimple) -> Unit) {
    val context = LocalContext.current
    var contacts by remember { mutableStateOf<List<ContactSimple>>(emptyList()) }
    var rechercheContact by remember { mutableStateOf("") }
    var chargement by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        contacts = ContactsHelper.chargerContacts(context)
        chargement = false
    }

    val contactsFiltres = remember(contacts, rechercheContact) {
        if (rechercheContact.isBlank()) contacts
        else contacts.filter {
            it.nom.contains(rechercheContact, ignoreCase = true) ||
                    it.telephone.contains(rechercheContact.filter { c -> c.isDigit() })
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Importer un contact", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(
                    value = rechercheContact,
                    onValueChange = { rechercheContact = it },
                    placeholder = { Text("Rechercher…") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                if (chargement) {
                    Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else if (contactsFiltres.isEmpty()) {
                    Text("Aucun contact trouvé.\nVérifiez la permission Contacts.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    LazyColumn(Modifier.heightIn(max = 350.dp)) {
                        items(contactsFiltres) { contact ->
                            ListItem(
                                headlineContent = { Text(contact.nom) },
                                supportingContent = { Text(contact.telephone) },
                                leadingContent = { Icon(Icons.Default.Person, null) },
                                modifier = Modifier.clickable { onPreRemplir(contact) }
                            )
                            HorizontalDivider()
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DialogueClient(
    clientInitial: Client?,
    onDismiss: () -> Unit,
    onValider: (Client) -> Unit
) {
    val estEdition = clientInitial != null && clientInitial.id != 0L
    val estPreRempli = clientInitial != null && clientInitial.id == 0L

    var nom by remember { mutableStateOf(clientInitial?.nom ?: "") }
    var paysSelectionne by remember {
        mutableStateOf(
            clientInitial?.telephone?.let { tel ->
                PhoneUtils.detecterPays(tel) ?: PhoneUtils.paysParDefaut()
            } ?: PhoneUtils.paysParDefaut()
        )
    }
    var numeroLocal by remember {
        mutableStateOf(
            clientInitial?.telephone?.let { tel ->
                val pays = PhoneUtils.detecterPays(tel)
                if (pays != null && pays.indicatif.isNotEmpty() && tel.startsWith(pays.indicatif)) {
                    tel.removePrefix(pays.indicatif)
                } else tel.filter { it.isDigit() }
            } ?: ""
        )
    }
    var montant by remember {
        mutableStateOf(
            clientInitial?.montant?.takeIf { it > 0 }?.let {
                "%,.0f".format(it).replace(",", " ").replace(" ", "")
            } ?: ""
        )
    }
    var joursEcheance by remember {
        mutableStateOf(
            if (clientInitial != null && clientInitial.id != 0L) {
                val joursRestants = ((clientInitial.dateEcheance - System.currentTimeMillis()) / (24 * 60 * 60 * 1000)).toInt()
                maxOf(0, joursRestants).toString()
            } else "7"
        )
    }
    var note by remember { mutableStateOf(clientInitial?.note ?: "") }
    var email by remember { mutableStateOf(clientInitial?.email ?: "") }
    var objetEmail by remember { mutableStateOf(clientInitial?.objetEmail ?: "Relance de paiement") }
    var heureRelance by remember { mutableStateOf((clientInitial?.heureRelance ?: 9).toString()) }
    var nombreRelancesMax by remember { mutableStateOf((clientInitial?.nombreRelancesMax ?: 0).toString()) }
    var canalRelance by remember { mutableStateOf(clientInitial?.canalRelance ?: CanalRelance.SMS) }
    var detectionPaiementAuto by remember { mutableStateOf(clientInitial?.detectionPaiementAuto ?: true) }
    var menuCanalOuvert by remember { mutableStateOf(false) }
    var menuPaysOuvert by remember { mutableStateOf(false) }
    var erreur by remember { mutableStateOf<String?>(null) }
    var avertissement by remember { mutableStateOf<String?>(null) }
    val contexte = LocalContext.current

    val apercuMessage = remember(nom, montant, joursEcheance, canalRelance) {
        val montantVal = montant.replace(",", ".").replace(" ", "").toDoubleOrNull() ?: 0.0
        val jours = joursEcheance.toLongOrNull() ?: 7L
        val dateEcheancePreview = System.currentTimeMillis() + jours * 24 * 60 * 60 * 1000
        MessageHelper.apercuMessage(
            contexte,
            nom.ifBlank { "Client" },
            montantVal,
            dateEcheancePreview,
            clientInitial?.nombreRelances ?: 0
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when {
                    estEdition -> "Modifier le client"
                    estPreRempli -> "Nouveau client (depuis contact)"
                    else -> "Nouveau client"
                },
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = nom, onValueChange = { nom = it },
                    label = { Text("Nom du client") }, singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Person, null) },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Canal de relance automatique", style = MaterialTheme.typography.labelMedium)
                Box {
                    OutlinedButton(
                        onClick = { menuCanalOuvert = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(when (canalRelance) {
                            CanalRelance.WHATSAPP -> "WhatsApp"
                            CanalRelance.SMS -> "SMS"
                            CanalRelance.GMAIL -> "Gmail"
                        })
                    }
                    DropdownMenu(
                        expanded = menuCanalOuvert,
                        onDismissRequest = { menuCanalOuvert = false }
                    ) {
                        DropdownMenuItem(text = { Text("WhatsApp — envoi automatique") }, onClick = { canalRelance = CanalRelance.WHATSAPP; menuCanalOuvert = false })
                        DropdownMenuItem(text = { Text("SMS — envoi automatique") }, onClick = { canalRelance = CanalRelance.SMS; menuCanalOuvert = false })
                        DropdownMenuItem(text = { Text("Gmail — envoi automatique") }, onClick = { canalRelance = CanalRelance.GMAIL; menuCanalOuvert = false })
                    }
                }
                Text(
                    when (canalRelance) {
                        CanalRelance.WHATSAPP -> "WhatsApp sera envoyé automatiquement après activation du Service d’Accessibilité."
                        CanalRelance.SMS -> "Le SMS sera envoyé automatiquement depuis la SIM du téléphone."
                        CanalRelance.GMAIL -> "Gmail sera envoyé automatiquement après activation du Service d’Accessibilité et si une adresse e-mail est renseignée."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (canalRelance == CanalRelance.GMAIL) {
                    // Canal e-mail : plus besoin du numéro de téléphone, seule l'adresse compte.
                    OutlinedTextField(
                        value = email, onValueChange = { email = it; erreur = null },
                        label = { Text("Adresse e-mail du client") },
                        singleLine = true,
                        isError = email.isBlank(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        leadingIcon = { Icon(Icons.Default.Email, null) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = objetEmail, onValueChange = { objetEmail = it },
                        label = { Text("Objet de l'e-mail") }, singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Subject, null) },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    // Canal SMS/WhatsApp : plus besoin de l'adresse e-mail, seul le numéro compte.
                    Text("Téléphone (format international)", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedCard(
                            modifier = Modifier.clickable { menuPaysOuvert = true }.height(56.dp),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Box(Modifier.fillMaxHeight().padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
                                Text("${paysSelectionne.drapeau} +${paysSelectionne.indicatif.ifEmpty { "?" }}", style = MaterialTheme.typography.bodyLarge)
                            }
                        }
                        DropdownMenu(expanded = menuPaysOuvert, onDismissRequest = { menuPaysOuvert = false }) {
                            PhoneUtils.paysSupportes.forEach { pays ->
                                DropdownMenuItem(
                                    text = { Text("${pays.drapeau}  ${pays.nom}  (+${pays.indicatif.ifEmpty { "…" }})") },
                                    onClick = { paysSelectionne = pays; menuPaysOuvert = false; erreur = null; avertissement = null }
                                )
                            }
                        }
                        OutlinedTextField(
                            value = numeroLocal,
                            onValueChange = { numeroLocal = it; erreur = null; avertissement = null },
                            label = { Text("Numéro") },
                            placeholder = { Text(paysSelectionne.exempleLocal) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                OutlinedTextField(
                    value = montant,
                    onValueChange = { montant = it.filter { c -> c.isDigit() || c == '.' || c == ',' } },
                    label = { Text("Montant dû (FCFA)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    leadingIcon = { Icon(Icons.Default.AttachMoney, null) },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = joursEcheance,
                    onValueChange = { joursEcheance = it.filter { c -> c.isDigit() } },
                    label = { Text(if (estEdition) "Jours restants jusqu'à l'échéance" else "Échéance dans (jours)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    leadingIcon = { Icon(Icons.Default.CalendarToday, null) },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = heureRelance,
                        onValueChange = { v -> heureRelance = v.filter { it.isDigit() }.take(2) },
                        label = { Text("Heure de relance") },
                        placeholder = { Text("0-23h") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        leadingIcon = { Icon(Icons.Default.Schedule, null) },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = nombreRelancesMax,
                        onValueChange = { v -> nombreRelancesMax = v.filter { it.isDigit() } },
                        label = { Text("Nb. de relances") },
                        placeholder = { Text("0 = illimité") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        leadingIcon = { Icon(Icons.Default.Repeat, null) },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = note, onValueChange = { note = it },
                    label = { Text("Note (optionnel)") }, maxLines = 2,
                    leadingIcon = { Icon(Icons.Default.Notes, null) },
                    modifier = Modifier.fillMaxWidth()
                )

                HorizontalDivider()

                Text("Quand ce client paie, comment voulez-vous que ça soit constaté ?", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = detectionPaiementAuto,
                        onClick = { detectionPaiementAuto = true },
                        label = { Text("Automatique") },
                        leadingIcon = { Icon(Icons.Default.AutoAwesome, null) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = !detectionPaiementAuto,
                        onClick = { detectionPaiementAuto = false },
                        label = { Text("Je le ferai moi-même") },
                        leadingIcon = { Icon(Icons.Default.TouchApp, null) },
                        modifier = Modifier.weight(1f)
                    )
                }
                Text(
                    if (detectionPaiementAuto)
                        "Vanelle surveille discrètement vos SMS et notifications de paiement mobile money (sans jamais rien envoyer hors de votre téléphone). Si un message reçu correspond exactement au montant dû et mentionne le nom ou le numéro de ce client, la dette est marquée payée toute seule. En cas de doute (identité ambiguë), rien ne change automatiquement et vous gardez la main."
                    else
                        "Vous marquerez vous-même ce client comme payé, depuis la liste des clients, quand vous le jugerez utile. Vous pourrez changer d'avis à tout moment en modifiant sa fiche.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                HorizontalDivider()

                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Aperçu de la relance qui sera envoyée", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        if (canalRelance == CanalRelance.GMAIL) {
                            Text("Objet : ${objetEmail.ifBlank { "Relance de paiement" }}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                        Text(apercuMessage, style = MaterialTheme.typography.bodySmall)
                    }
                }

                erreur?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                avertissement?.let { Text(it, color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val montantVal = montant.replace(",", ".").replace(" ", "").toDoubleOrNull()
                val jours = joursEcheance.toLongOrNull() ?: 7L
                val numeroComplet = if (canalRelance == CanalRelance.GMAIL) "" else
                    PhoneUtils.construireNumeroInternational(paysSelectionne.indicatif, numeroLocal)

                val errNum = if (canalRelance == CanalRelance.GMAIL) null else PhoneUtils.validerNumero(paysSelectionne, numeroLocal)
                val avert = if (canalRelance == CanalRelance.GMAIL) null else PhoneUtils.avertissementPaysInconnu(paysSelectionne, numeroComplet)

                when {
                    nom.isBlank() -> erreur = "Le nom est obligatoire."
                    errNum != null -> erreur = errNum
                    montantVal == null || montantVal <= 0 -> erreur = "Indiquez un montant valide."
                    canalRelance == CanalRelance.GMAIL && email.isBlank() -> erreur = "L'e-mail est obligatoire pour le canal Gmail."
                    canalRelance == CanalRelance.GMAIL && objetEmail.isBlank() -> erreur = "L'objet de l'e-mail est obligatoire."
                    (heureRelance.toIntOrNull() ?: -1) !in 0..23 -> erreur = "L'heure de relance doit être comprise entre 0 et 23."
                    else -> {
                        if (avert != null) {
                            // On affiche l'avertissement mais on laisse l'utilisateur confirmer en cliquant une 2e fois
                            if (avertissement == null) {
                                avertissement = avert + "\nAppuyez encore sur Ajouter pour confirmer."
                                return@Button
                            }
                        }
                        val dateEcheance = System.currentTimeMillis() + jours * 24 * 60 * 60 * 1000
                        val base = clientInitial ?: Client(nom = "", telephone = "", montant = 0.0, dateEcheance = 0L)
                        onValider(
                            base.copy(
                                nom = nom.trim(),
                                telephone = numeroComplet,
                                montant = montantVal,
                                dateEcheance = dateEcheance,
                                email = email.trim(),
                                note = note.trim(),
                                canalRelance = canalRelance,
                                objetEmail = objetEmail.trim().ifBlank { "Relance de paiement" },
                                heureRelance = heureRelance.toIntOrNull() ?: 9,
                                nombreRelancesMax = nombreRelancesMax.toIntOrNull() ?: 0,
                                detectionPaiementAuto = detectionPaiementAuto
                            )
                        )
                    }
                }
            }) { Text(if (estEdition) "Enregistrer" else "Ajouter") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DialogueNegociation(
    client: Client,
    onDismiss: () -> Unit,
    onEnvoye: (canal: String, type: TypeNegociation) -> Unit
) {
    val context = LocalContext.current
    var typeNego by remember { mutableStateOf(TypeNegociation.DOUCE) }
    var canal by remember { mutableStateOf(CanalRelance.WHATSAPP) }
    var apercu by remember { mutableStateOf("") }

    LaunchedEffect(typeNego, client) {
        apercu = MessageHelper.genererMessageNegociation(context, client, typeNego)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Message de négociation", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Client : ${client.nom}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text("Type de négociation", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = typeNego == TypeNegociation.DOUCE,
                        onClick = { typeNego = TypeNegociation.DOUCE },
                        label = { Text("Amiable") }
                    )
                    FilterChip(
                        selected = typeNego == TypeNegociation.PLAN_PAIEMENT,
                        onClick = { typeNego = TypeNegociation.PLAN_PAIEMENT },
                        label = { Text("Échéancier") }
                    )
                    FilterChip(
                        selected = typeNego == TypeNegociation.OFFRE_FINALE,
                        onClick = { typeNego = TypeNegociation.OFFRE_FINALE },
                        label = { Text("Offre finale") }
                    )
                }
                Text("Canal d'envoi", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = canal == CanalRelance.WHATSAPP,
                        onClick = { canal = CanalRelance.WHATSAPP },
                        label = { Text("WhatsApp") }
                    )
                    FilterChip(
                        selected = canal == CanalRelance.SMS,
                        onClick = { canal = CanalRelance.SMS },
                        label = { Text("SMS") }
                    )
                    FilterChip(
                        selected = canal == CanalRelance.GMAIL,
                        onClick = { canal = CanalRelance.GMAIL },
                        label = { Text("Gmail") }
                    )
                }
                Text("Aperçu du message", style = MaterialTheme.typography.labelMedium)
                Surface(
                    tonalElevation = 2.dp,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        apercu,
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val ok = when (canal) {
                    CanalRelance.SMS -> {
                        if (!SmsHelper.permissionAccordee(context)) {
                            Toast.makeText(context, "Permission SMS requise", Toast.LENGTH_LONG).show()
                            false
                        } else {
                            SmsHelper.envoyerNegociation(context, client, typeNego)
                        }
                    }
                    CanalRelance.WHATSAPP -> {
                        if (!AutomationHelper.serviceActive(context)) {
                            // Ouvre WhatsApp pré-rempli même sans accessibilité (envoi manuel du clic)
                            WhatsAppHelper.envoyerNegociation(context, client, typeNego)
                        } else {
                            val msg = MessageHelper.genererMessageNegociation(context, client, typeNego)
                            if (!AutomationHelper.startWhatsApp(context, client, msg)) {
                                WhatsAppHelper.envoyerNegociation(context, client, typeNego)
                            } else true
                        }
                    }
                    CanalRelance.GMAIL -> {
                        if (client.email.isBlank()) {
                            Toast.makeText(context, "Ajoutez l'e-mail du client", Toast.LENGTH_LONG).show()
                            false
                        } else if (!AutomationHelper.serviceActive(context)) {
                            Toast.makeText(context, "Activez le service d'accessibilité pour Gmail", Toast.LENGTH_LONG).show()
                            AutomationHelper.openAccessibilitySettings(context)
                            false
                        } else {
                            val body = MessageHelper.genererMessageNegociation(context, client, typeNego)
                            AutomationHelper.startEmail(context, client, "Proposition d'arrangement", body)
                        }
                    }
                }
                if (ok) {
                    Toast.makeText(context, "Message de négociation envoyé", Toast.LENGTH_SHORT).show()
                    onEnvoye(canal.name, typeNego)
                } else if (canal != CanalRelance.GMAIL) {
                    Toast.makeText(context, "Échec de l'envoi — vérifiez le numéro / l'app", Toast.LENGTH_LONG).show()
                }
            }) { Text("Envoyer") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}
