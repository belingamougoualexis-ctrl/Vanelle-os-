package com.vanelle.relance.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class Converters {
    @TypeConverter
    fun depuisStatut(statut: StatutDette): String = statut.name

    @TypeConverter
    fun versStatut(valeur: String): StatutDette =
        try {
            StatutDette.valueOf(valeur)
        } catch (e: Exception) {
            StatutDette.EN_COURS
        }
}

@Database(entities = [Client::class], version = 6, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clientDao(): ClientDao

    companion object {
        private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE clients ADD COLUMN email TEXT NOT NULL DEFAULT ''")
            }
        }
        private val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE clients ADD COLUMN canalRelance TEXT NOT NULL DEFAULT 'SMS'")
            }
        }
        private val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE clients ADD COLUMN objetEmail TEXT NOT NULL DEFAULT 'Relance de paiement'")
                db.execSQL("ALTER TABLE clients ADD COLUMN heureRelance INTEGER NOT NULL DEFAULT 9")
                db.execSQL("ALTER TABLE clients ADD COLUMN nombreRelancesMax INTEGER NOT NULL DEFAULT 0")
            }
        }
        private val MIGRATION_4_5 = object : androidx.room.migration.Migration(4, 5) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE clients ADD COLUMN detectionPaiementAuto INTEGER NOT NULL DEFAULT 1")
            }
        }
        private val MIGRATION_5_6 = object : androidx.room.migration.Migration(5, 6) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE clients ADD COLUMN montantPaye REAL NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE clients ADD COLUMN enAttenteReponse INTEGER NOT NULL DEFAULT 0")
            }
        }

        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "vanelle_relance.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6)
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
