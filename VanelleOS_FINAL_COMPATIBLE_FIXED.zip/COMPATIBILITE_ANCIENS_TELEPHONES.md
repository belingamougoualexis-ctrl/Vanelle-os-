# VanelleOS — compatibilité appareils anciens

Cette version corrige l'erreur AAPT `resource color/white not found` et ajoute deux variantes Android :

- `modernRelease` : appareils 64 bits ARM (`arm64-v8a`) et x86_64, avec Llama local.
- `legacyRelease` : appareils 32 bits (`armeabi-v7a` / x86) et appareils Android plus anciens à partir d'Android 6.0, sans moteur Llama natif. Les fonctions Vanelle qui ne nécessitent pas Llama restent disponibles et le code utilise ses mécanismes de secours.

## Pourquoi deux variantes ?

Le moteur `llamacpp-kotlin:0.4.0` du projet actuel fournit des bibliothèques natives 64 bits. Ajouter simplement `armeabi-v7a` dans `abiFilters` ne fabriquerait pas une bibliothèque 32 bits : il faut une vraie `.so` compilée pour cette ABI. La variante legacy évite donc une erreur de chargement JNI sur les téléphones 32 bits.

## Compilation

Depuis la racine du projet :

```bash
./gradlew assembleModernRelease
./gradlew assembleLegacyRelease
```

Les APK se trouvent ensuite sous :

- `app/build/outputs/apk/modern/release/`
- `app/build/outputs/apk/legacy/release/`

Le workflow GitHub Actions existant peut être adapté pour produire les deux variantes.
