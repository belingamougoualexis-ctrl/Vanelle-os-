package com.vanelle.os
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

/**
 * Service de téléchargement des données de l'app.
 * - Modèle IA local (GGUF) dans le même flux
 * - Continue si l'utilisateur quitte l'app (foreground service)
 * - Pause si plus de réseau
 * - Reprend automatiquement au même offset (.part + HTTP Range) pour le GGUF
 */
class DataDownloadService : Service() {

    companion object {
        private const val TAG = "DataDownload"
        const val CHANNEL_ID = "vanelle_data_download"
        const val CHANNEL_DONE_ID = "vanelle_data_ready"
        const val NOTIF_ID = 4201
        const val NOTIF_DONE_ID = 4202
        const val ACTION_PROGRESS = "com.vanelle.os.DATA_DOWNLOAD_PROGRESS"
        const val ACTION_DONE = "com.vanelle.os.DATA_DOWNLOAD_DONE"
        const val ACTION_WAITING = "com.vanelle.os.DATA_DOWNLOAD_WAITING"
        const val EXTRA_PERCENT = "percent"
        const val EXTRA_STATUS = "status"

        @Volatile var isRunning = false
            private set

        fun allDataReady(c: Context): Boolean =
            !LlamaModelManager.isLocalAiSupported() || LlamaModelManager.isReady(c)

        fun start(c: Context) {
            if (allDataReady(c)) return
            val i = Intent(c, DataDownloadService::class.java)
            ContextCompat.startForegroundService(c, i)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var cancelled = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Fichier déjà téléchargé : charger en mémoire si besoin, puis notification
        if (allDataReady(this)) {
            isRunning = true
            startAsForeground(100, "Chargement de l'IA en mémoire…")
            if (job?.isActive != true) {
                job = scope.launch {
                    val alreadyLoaded = try {
                        LocalLlamaHelper.get(applicationContext).isLoaded()
                    } catch (_: Exception) { false }
                    if (alreadyLoaded) {
                        notifyDownloadComplete(loaded = true)
                        delay(400)
                        stopSelfSafely()
                    } else {
                        finishWithMemoryLoad()
                    }
                }
            }
            return START_NOT_STICKY
        }
        startAsForeground(overallPercent(), "Préparation des données…")
        isRunning = true
        cancelled = false
        registerNetworkWatcher()
        if (job?.isActive != true) {
            job = scope.launch { runDownloadLoop() }
        }
        return START_STICKY
    }

    private suspend fun runDownloadLoop() {
        while (!cancelled && !allDataReady(this)) {
            if (!LlamaModelManager.isNetworkAvailable(this)) {
                broadcastWaiting("Connexion interrompue…")
                updateNotif(overallPercent(), "Connexion interrompue — reprise auto")
                delay(3000)
                continue
            }

            // Modèle IA local (GGUF) — gros fichier avec reprise
            if (LlamaModelManager.isReady(this)) {
                finishWithMemoryLoad()
                return
            }

            val result = LlamaModelManager.downloadResumable(
                this,
                wifiOnly = false,
                isCancelled = { cancelled }
            ) { pct, downloaded, total ->
                // Progression directe du téléchargement du GGUF
                val mapped = pct.coerceIn(0, 100)
                val status = if (total > 0) {
                    val mb = downloaded / (1024 * 1024)
                    val totalMb = total / (1024 * 1024)
                    "$mapped % · ${mb} / ${totalMb} Mo"
                } else "$mapped %"
                updateNotif(mapped, status)
                broadcastProgress(mapped, status)
            }

            when (result) {
                "DONE" -> {
                    finishWithMemoryLoad()
                    return
                }
                "CANCELLED" -> {
                    stopSelfSafely()
                    return
                }
                "NO_WIFI", "NO_NETWORK" -> {
                    broadcastWaiting(
                        if (result == "NO_WIFI") "En attente du Wi‑Fi…"
                        else "Connexion interrompue — reprise au même point"
                    )
                    delay(2500)
                }
                else -> {
                    updateNotif(overallPercent(), "Nouvelle tentative…")
                    delay(5000)
                }
            }
        }
        if (allDataReady(this)) {
            finishWithMemoryLoad()
            return
        }
        stopSelfSafely()
    }

    /**
     * Après téléchargement réussi : charge le modèle en mémoire (réessais auto),
     * puis seulement envoie la notification « IA prête ».
     */
    private suspend fun finishWithMemoryLoad() {
        updateNotif(100, "Chargement de l'IA en mémoire…")
        broadcastProgress(100, "Chargement de l'IA en mémoire…")
        var ok = false
        // Réessais jusqu'à succès — le chargement ne doit pas "abandonner" trop tôt
        repeat(12) { attempt ->
            if (ok) return@repeat
            try {
                updateNotif(100, "Chargement de l'IA en mémoire… (${attempt + 1})")
                ok = LocalLlamaHelper.get(applicationContext).warmUp()
            } catch (e: Exception) {
                Log.w(TAG, "warmUp attempt ${attempt + 1}: ${e.message}")
                ok = false
            }
            if (!ok) delay(2000L * (attempt + 1))
        }
        // Dernière vérification
        if (!ok) {
            ok = try {
                LocalLlamaHelper.get(applicationContext).isLoaded()
            } catch (_: Exception) { false }
        }
        updateNotif(100, if (ok) "IA prête" else "IA — finalisation…")
        broadcastDone()
        // Notification uniquement quand chargé en mémoire ; sinon on relance en arrière-plan
        if (ok) {
            notifyDownloadComplete(loaded = true)
            delay(600)
            stopSelfSafely()
        } else {
            // Continue de réessayer en tâche de fond sans "échouer" définitivement
            updateNotif(100, "Chargement de l'IA en cours…")
            scope.launch {
                while (!cancelled) {
                    val success = try {
                        LocalLlamaHelper.get(applicationContext).warmUp()
                    } catch (_: Exception) { false }
                    if (success || try {
                            LocalLlamaHelper.get(applicationContext).isLoaded()
                        } catch (_: Exception) { false }
                    ) {
                        notifyDownloadComplete(loaded = true)
                        delay(500)
                        stopSelfSafely()
                        return@launch
                    }
                    delay(15_000)
                }
            }
        }
    }

    /** Progression globale du téléchargement du modèle IA local. */
    private fun overallPercent(): Int {
        if (allDataReady(this)) return 100
        val p = LlamaModelManager.partialBytes(this)
        if (p <= 0) return 0
        return ((p * 100) / LlamaModelManager.EXPECTED_MIN_BYTES).toInt().coerceIn(0, 99)
    }

    private fun registerNetworkWatcher() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            networkCallback?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (job?.isActive != true && !allDataReady(this@DataDownloadService)) {
                        job = scope.launch { runDownloadLoop() }
                    }
                }
                override fun onLost(network: Network) {
                    broadcastWaiting("Connexion interrompue — reprise auto")
                }
            }
            networkCallback = cb
            val req = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            cm.registerNetworkCallback(req, cb)
        } catch (_: Exception) {}
    }

    private fun broadcastProgress(pct: Int, status: String) {
        sendBroadcast(Intent(ACTION_PROGRESS).setPackage(packageName).apply {
            putExtra(EXTRA_PERCENT, pct)
            putExtra(EXTRA_STATUS, status)
        })
    }

    private fun broadcastWaiting(msg: String) {
        sendBroadcast(Intent(ACTION_WAITING).setPackage(packageName).apply {
            putExtra(EXTRA_STATUS, msg)
            putExtra(EXTRA_PERCENT, overallPercent())
        })
    }

    private fun broadcastDone() {
        sendBroadcast(Intent(ACTION_DONE).setPackage(packageName))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                CHANNEL_ID,
                "Mise à jour des données",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Téléchargement des données de VanelleOS"
                setShowBadge(false)
            }
            nm.createNotificationChannel(ch)
            // Canal haute priorité pour la notification de fin
            val done = NotificationChannel(
                CHANNEL_DONE_ID,
                "IA prête",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notification quand le modèle IA est téléchargé"
                setShowBadge(true)
            }
            nm.createNotificationChannel(done)
        }
    }

    private fun startAsForeground(pct: Int, text: String) {
        val notif = buildNotif(pct, text)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun updateNotif(pct: Int, text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotif(pct, text))
    }

    private fun buildNotif(pct: Int, text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VanelleOS · données")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct.coerceIn(0, 100), pct <= 0)
            .setContentIntent(open)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .build()
    }

    /** Notification finale : envoyée seulement après chargement en mémoire (ou échec clair). */
    private fun notifyDownloadComplete(loaded: Boolean) {
        try {
            createChannel()
            val open = PendingIntent.getActivity(
                this, 1,
                Intent(this, MainActivity::class.java).addFlags(
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                ),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val title = if (loaded) "VanelleOS · IA prête" else "VanelleOS · Téléchargement terminé"
            val text = if (loaded) {
                "L'IA est chargée en mémoire. Vanelle peut t'assister dès maintenant, même hors-ligne."
            } else {
                "Le modèle est téléchargé. Ouvre VanelleOS pour terminer le chargement en mémoire, puis réessaie."
            }
            val notif = NotificationCompat.Builder(this, CHANNEL_DONE_ID)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setAutoCancel(true)
                .setOngoing(false)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(open)
                .setCategory(NotificationCompat.CATEGORY_STATUS)
                .build()
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_DONE_ID, notif)
        } catch (_: Exception) {}
    }

    private fun stopSelfSafely() {
        isRunning = false
        cancelled = true
        try {
            networkCallback?.let {
                val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                cm.unregisterNetworkCallback(it)
            }
        } catch (_: Exception) {}
        networkCallback = null
        job?.cancel()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        cancelled = true
        isRunning = false
        scope.cancel()
        super.onDestroy()
    }
}
