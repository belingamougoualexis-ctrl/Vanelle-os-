package com.vanelle.os

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.yield
import kotlin.coroutines.resume
import kotlin.jvm.functions.Function1
import kotlin.math.max
import kotlin.math.min

/**
 * Wrapper optimisé autour de llamacpp-kotlin (réflexion).
 *
 * Optimisations :
 * - Instance unique process-wide (un seul chargement du modèle)
 * - n_ctx adapté à la RAM (512–1536) au lieu de 2048 fixe
 * - Prompt système compact (moins de tokens de préfill)
 * - Contexte utilisateur tronqué
 * - Timeout adaptatif selon la taille de la requête
 * - warmUp() au démarrage de l'app
 * - Mutex pour sérialiser les inférences (un seul contexte natif)
 */
class LocalLlamaHelper private constructor(private val appContext: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val events = MutableSharedFlow<Any>(extraBufferCapacity = 512, replay = 0)

    @Volatile private var loaded = false
    @Volatile private var loading = false
    @Volatile private var helper: Any? = null
    @Volatile private var resolvedClass: Class<*>? = null
    private val answerMutex = Mutex()
    private val loadMutex = Mutex()

    private fun resolveLlamaClass(): Class<*>? {
        resolvedClass?.let { return it }
        val candidates = listOf(
            "org.nehuatl.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacppkotlin.LlamaHelper",
            "com.ljcamargo.llamacpp.LlamaHelper"
        )
        for (name in candidates) {
            try {
                val c = Class.forName(name)
                resolvedClass = c
                return c
            } catch (_: ClassNotFoundException) {}
        }
        return null
    }

    /** Fenêtre de contexte selon la mémoire disponible (moins de RAM → plus rapide / stable). */
    private fun optimalContextLength(): Int {
        return try {
            val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memMb = am.memoryClass
            when {
                memMb >= 512 -> 1536
                memMb >= 384 -> 1024
                memMb >= 256 -> 768
                else -> 512
            }
        } catch (_: Exception) {
            1024
        }
    }

    private suspend fun ensureLoaded(): Boolean {
        if (loaded && helper != null) return true
        if (!LlamaModelManager.isReady(appContext)) return false

        return loadMutex.withLock {
            if (loaded && helper != null) return@withLock true
            if (loading) {
                // Attendre un chargement concurrent (jusqu'à ~3 min)
                repeat(180) {
                    kotlinx.coroutines.delay(1000)
                    if (loaded && helper != null) return@withLock true
                    if (!loading) return@withLock (loaded && helper != null)
                }
                return@withLock (loaded && helper != null)
            }
            loading = true
            try {
                // Plusieurs tentatives : contexte décroissant si OOM / timeout
                val contexts = listOf(
                    optimalContextLength(),
                    768,
                    512,
                    384,
                    256
                ).distinct()
                for ((attempt, nCtx) in contexts.withIndex()) {
                    val ok = tryLoadOnce(nCtx, timeoutMs = 180_000L + attempt * 30_000L)
                    if (ok) return@withLock true
                    kotlinx.coroutines.delay(500)
                }
                // Dernière chance : recharger après courte pause
                kotlinx.coroutines.delay(1500)
                tryLoadOnce(256, timeoutMs = 240_000L)
            } catch (_: Exception) {
                false
            } finally {
                loading = false
            }
        }
    }

    private suspend fun tryLoadOnce(nCtx: Int, timeoutMs: Long): Boolean {
        return try {
            val klass = resolveLlamaClass() ?: return false
            val ctor = try {
                klass.getConstructor(
                    android.content.ContentResolver::class.java,
                    CoroutineScope::class.java,
                    MutableSharedFlow::class.java
                )
            } catch (_: Exception) {
                null
            } ?: return false
            val h = ctor.newInstance(appContext.contentResolver, scope, events)
            val modelUri = Uri.fromFile(LlamaModelManager.modelFile(appContext)).toString()

            // Signatures load possibles selon la version de la lib
            val loadCandidates = listOf(
                try {
                    klass.getMethod(
                        "load",
                        String::class.java,
                        Int::class.javaPrimitiveType,
                        String::class.java,
                        Function1::class.java
                    )
                } catch (_: Exception) { null },
                try {
                    klass.getMethod("load", String::class.java, Int::class.javaPrimitiveType)
                } catch (_: Exception) { null },
                try {
                    klass.getMethod("load", String::class.java)
                } catch (_: Exception) { null }
            ).filterNotNull()

            if (loadCandidates.isEmpty()) return false

            val ok = withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    try {
                        val callback = object : Function1<Any?, Unit> {
                            override fun invoke(p1: Any?) {
                                if (cont.isActive) cont.resume(true)
                            }
                        }
                        var invoked = false
                        for (method in loadCandidates) {
                            try {
                                when (method.parameterTypes.size) {
                                    4 -> method.invoke(h, modelUri, nCtx, null, callback)
                                    2 -> {
                                        method.invoke(h, modelUri, nCtx)
                                        if (cont.isActive) cont.resume(true)
                                    }
                                    1 -> {
                                        method.invoke(h, modelUri)
                                        if (cont.isActive) cont.resume(true)
                                    }
                                }
                                invoked = true
                                break
                            } catch (_: Exception) { /* essaie signature suivante */ }
                        }
                        if (!invoked && cont.isActive) cont.resume(false)
                    } catch (_: Exception) {
                        if (cont.isActive) cont.resume(false)
                    }
                }
            } ?: false

            if (ok) {
                helper = h
                loaded = true
            }
            ok
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Précharge le modèle — réessaie jusqu'à succès (tant que le fichier GGUF est là).
     * Ne "abandonne" pas après un seul échec.
     */
    suspend fun warmUp(): Boolean = withContext(Dispatchers.IO) {
        if (!LlamaModelManager.isReady(appContext)) return@withContext false
        if (loaded && helper != null) return@withContext true
        // Jusqu'à 8 tentatives globales
        repeat(8) { i ->
            if (ensureLoaded()) return@withContext true
            kotlinx.coroutines.delay(1000L * (i + 1))
        }
        ensureLoaded()
    }

    fun isLoaded(): Boolean = loaded && helper != null

    /**
     * @param maxTokensHint limite soft côté collecteur (coupe tôt si réponse déjà longue)
     * @param fastMode prompt encore plus court + timeout réduit (commandes simples)
     */
    suspend fun answer(
        userPrompt: String,
        extraContext: String = "",
        fastMode: Boolean = false,
        maxTokensHint: Int = if (fastMode) 64 else 120
    ): String = answerMutex.withLock {
        if (!ensureLoaded()) return@withLock NOT_READY
        val h = helper ?: return@withLock NOT_READY
        val klass = h.javaClass

        val formatted = buildPrompt(userPrompt, extraContext, fastMode)
        val timeoutMs = adaptiveTimeoutMs(formatted.length, fastMode)

        return@withLock try {
            // Cherche n'importe quelle méthode predict / generate / complete
            val predictMethod = listOf(
                arrayOf(String::class.java, String::class.java),
                arrayOf(String::class.java)
            ).firstNotNullOfOrNull { types ->
                try { klass.getMethod("predict", *types) } catch (_: Exception) { null }
            } ?: listOf("generate", "complete", "chat", "ask").firstNotNullOfOrNull { name ->
                try { klass.getMethod(name, String::class.java) } catch (_: Exception) { null }
            } ?: return@withLock NOT_READY

            withTimeoutOrNull(timeoutMs) {
                // 1) Essai synchrone : si predict retourne une String, on l'utilise directement
                try {
                    val raw = when (predictMethod.parameterTypes.size) {
                        2 -> predictMethod.invoke(h, formatted, null)
                        else -> predictMethod.invoke(h, formatted)
                    }
                    when (raw) {
                        is String -> {
                            val cleaned = raw.trim()
                                .removePrefix("assistant")
                                .trim()
                            if (cleaned.isNotBlank()) return@withTimeoutOrNull cleaned
                        }
                    }
                } catch (_: Exception) { /* suite : mode flux d'événements */ }

                // 2) Mode streaming via SharedFlow (API llamacpp-kotlin)
                suspendCancellableCoroutine<String> { cont ->
                    val job = scope.launch {
                        try {
                            val sb = StringBuilder(maxTokensHint * 4)
                            var tokenApprox = 0
                            var gotDone = false

                            val collector = launch {
                                try {
                                    events.takeWhile { event ->
                                        val name = event.javaClass.simpleName
                                        when (name) {
                                            "Ongoing" -> {
                                                val word = extractToken(event)
                                                if (word.isNotEmpty()) {
                                                    sb.append(word)
                                                    tokenApprox++
                                                }
                                                tokenApprox < maxTokensHint && sb.length < maxTokensHint * 8
                                            }
                                            "Done" -> {
                                                gotDone = true
                                                // parfois le texte final est dans Done
                                                val finalTxt = extractToken(event)
                                                if (finalTxt.isNotEmpty() && sb.isEmpty()) sb.append(finalTxt)
                                                false
                                            }
                                            "Error" -> {
                                                false
                                            }
                                            else -> {
                                                // Classes inconnues : tenter d'extraire du texte
                                                val word = extractToken(event)
                                                if (word.isNotEmpty()) {
                                                    sb.append(word)
                                                    tokenApprox++
                                                }
                                                tokenApprox < maxTokensHint
                                            }
                                        }
                                    }.collect { }
                                } catch (_: Exception) {}
                            }

                            yield()
                            when (predictMethod.parameterTypes.size) {
                                2 -> predictMethod.invoke(h, formatted, null)
                                else -> predictMethod.invoke(h, formatted)
                            }
                            // Attente bornée de la fin du flux
                            withTimeoutOrNull(timeoutMs) { collector.join() }
                            collector.cancel()

                            val text = sb.toString().trim()
                                .removePrefix("assistant")
                                .trim()
                            if (cont.isActive) {
                                cont.resume(text.ifBlank { NOT_READY })
                            }
                        } catch (_: Exception) {
                            if (cont.isActive) cont.resume(NOT_READY)
                        }
                    }
                    cont.invokeOnCancellation { job.cancel() }
                }
            } ?: NOT_READY
        } catch (_: Exception) {
            NOT_READY
        }
    }

    /** Extrait un token texte d'un événement de streaming (API variables selon la lib). */
    private fun extractToken(event: Any): String {
        for (method in listOf("getWord", "getToken", "getText", "getContent", "getMessage")) {
            try {
                val v = event.javaClass.getMethod(method).invoke(event)
                if (v is String && v.isNotEmpty()) return v
            } catch (_: Exception) {}
        }
        try {
            for (f in event.javaClass.declaredFields) {
                f.isAccessible = true
                val v = f.get(event)
                if (v is String && v.isNotEmpty() && v.length < 200) return v
            }
        } catch (_: Exception) {}
        return ""
    }

    private fun buildPrompt(userPrompt: String, extraContext: String, fastMode: Boolean): String {
        val system = if (fastMode) {
            "Tu es Vanelle, assistante vocale réelle sur Android. Français, 1-2 phrases, naturel. " +
                "Utilise le prénom de l'utilisateur s'il est dans le contexte. " +
                "Aucune réponse inventée ou d'exemple. Si action téléphone : ligne ACTION:TYPE|arg."
        } else {
            "Tu es Vanelle, assistante réelle sur le téléphone. Français naturel, 1-3 phrases. " +
                "Tu comprends les intentions, tu analyses, tu te souviens du contexte fourni. " +
                "Si le prénom de l'utilisateur est dans le contexte, utilise-le quand c'est naturel. " +
                "Ne simule rien, ne donne pas d'exemples fictifs, base-toi sur le contexte et la demande. " +
                "Pour une action téléphone, mets EN PREMIER: " +
                "ACTION:YOUTUBE|requête ou ACTION:OPEN_APP|nom ou ACTION:CALL|nom ou " +
                "ACTION:MESSAGE|nom|texte ou ACTION:SEARCH|requête ou ACTION:MAPS|lieu ou " +
                "ACTION:TIMER|minutes ou ACTION:FLASHLIGHT|on/off ou ACTION:VOLUME|up/down. " +
                "Sinon réponds normalement sans ligne ACTION."
        }
        val ctx = extraContext.trim().take(if (fastMode) 180 else 500)
        val user = userPrompt.trim().take(if (fastMode) 200 else 360)

        return buildString(capacity = 2200) {
            append("<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n")
            append(system)
            if (ctx.isNotBlank()) {
                append("\nContexte: ")
                append(ctx)
            }
            append("\n<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n")
            append(user)
            append("\n<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n")
        }
    }

    private fun adaptiveTimeoutMs(promptChars: Int, fastMode: Boolean): Long {
        // Timeouts réalistes : le 1er appel (chargement KV) est plus lent
        val base = if (fastMode) 25_000L else 45_000L
        val extra = (promptChars / 6).toLong()
        val boost = if (!loaded) 20_000L else 0L
        return min(90_000L, max(base, base + extra + boost))
    }

    companion object {
        const val NOT_READY = "__LLAMA_NOT_READY__"

        @Volatile private var instance: LocalLlamaHelper? = null

        fun get(context: Context): LocalLlamaHelper {
            instance?.let { return it }
            synchronized(this) {
                instance?.let { return it }
                val created = LocalLlamaHelper(context.applicationContext)
                instance = created
                return created
            }
        }
    }
}
