package com.vanelle.os

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/**
 * Overlay de guidage : message flottant + anneau pointant un nœud d'accessibilité précis.
 */
object GuidanceOverlay {
    private val handler = Handler(Looper.getMainLooper())
    private val active = mutableListOf<View>()

    fun canDraw(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 23) Settings.canDrawOverlays(context) else true

    fun show(context: Context, message: String, durationMs: Long = 4000L): String {
        if (!canDraw(context)) {
            return "Permission « afficher par-dessus les apps » requise pour le guidage. Active-la dans Configuration."
        }
        handler.post {
            clear(context)
            val tv = TextView(context).apply {
                text = "➜ ${message.take(120)}"
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 15f
                setPadding(36, 26, 36, 26)
                background = GradientDrawable().apply {
                    setColor(0xE0121212.toInt())
                    cornerRadius = 28f
                }
            }
            addView(context, tv, WindowManager.LayoutParams().apply {
                width = WindowManager.LayoutParams.WRAP_CONTENT
                height = WindowManager.LayoutParams.WRAP_CONTENT
                type = overlayType()
                flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                format = PixelFormat.TRANSLUCENT
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = 160
            }, durationMs)
        }
        return "Guidage affiché : « ${message.take(80)} »."
    }

    /**
     * Pointe un nœud d'accessibilité par son texte visible.
     * Affiche un anneau autour des bounds + label.
     */
    fun pointToNode(context: Context, query: String, durationMs: Long = 5000L): String {
        if (!canDraw(context)) {
            return "Permission overlay requise pour pointer un élément à l'écran."
        }
        val svc = VanelleAccessibilityService.instance
            ?: return "Active le service d'accessibilité dans Configuration pour que je voie les éléments."
        val bounds = svc.findNodeBounds(query)
            ?: return "Aucun élément « $query » trouvé à l'écran. Dis le texte exact visible."

        handler.post {
            clear(context)
            val pad = 12
            val ring = View(context).apply {
                background = GradientDrawable().apply {
                    setStroke(6, 0xFF00A878.toInt())
                    cornerRadius = 18f
                    setColor(0x3300A878)
                }
            }
            val label = TextView(context).apply {
                text = "➜ $query"
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 13f
                setPadding(24, 14, 24, 14)
                background = GradientDrawable().apply {
                    setColor(0xE000A878.toInt())
                    cornerRadius = 20f
                }
            }
            addView(context, ring, WindowManager.LayoutParams().apply {
                width = bounds.width() + pad * 2
                height = bounds.height() + pad * 2
                type = overlayType()
                flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                format = PixelFormat.TRANSLUCENT
                gravity = Gravity.TOP or Gravity.START
                x = bounds.left - pad
                y = bounds.top - pad
            }, durationMs)
            addView(context, label, WindowManager.LayoutParams().apply {
                width = WindowManager.LayoutParams.WRAP_CONTENT
                height = WindowManager.LayoutParams.WRAP_CONTENT
                type = overlayType()
                flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                format = PixelFormat.TRANSLUCENT
                gravity = Gravity.TOP or Gravity.START
                x = bounds.left
                y = (bounds.top - 90).coerceAtLeast(20)
            }, durationMs)
        }
        HapticLanguage.play(context, HapticLanguage.Signal.CONFIRM)
        return "Je pointe « $query » à l'écran (${bounds.width()}×${bounds.height()})."
    }

    fun hide(context: Context) {
        handler.post { clear(context) }
    }

    private fun clear(context: Context) {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        active.toList().forEach {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        active.clear()
    }

    private fun addView(
        context: Context,
        view: View,
        params: WindowManager.LayoutParams,
        durationMs: Long
    ) {
        try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.addView(view, params)
            active += view
            handler.postDelayed({
                try { wm.removeView(view) } catch (_: Exception) {}
                active.remove(view)
            }, durationMs)
        } catch (_: Exception) {}
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
}
