package com.vanelle.os
import android.content.Context
import android.graphics.drawable.GradientDrawable

/** Palette : forêt #0B5D3B · émeraude #00A878 · turquoise #18C7C8 · blanc #FFFFFF · mint #E5F7EF */
object UiKit {
    const val FOREST = 0xFF0B5D3B.toInt()
    const val EMERALD = 0xFF00A878.toInt()
    const val TURQUOISE = 0xFF18C7C8.toInt()
    const val WHITE = 0xFFFFFFFF.toInt()
    const val MINT = 0xFFE5F7EF.toInt()
    const val TEXT_MUTED = 0xFF4A7A62.toInt()
    const val TEXT_DARK = 0xFF0B5D3B.toInt()

    fun card(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(WHITE)
            setStroke((1.5f * d).toInt(), EMERALD)
            cornerRadius = 8f * d
        }
    }
    fun selected(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(MINT)
            setStroke((2f * d).toInt(), EMERALD)
            cornerRadius = 8f * d
        }
    }
    fun pill(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(WHITE)
            setStroke((1.5f * d).toInt(), EMERALD)
            cornerRadius = 20f * d
        }
    }
}
