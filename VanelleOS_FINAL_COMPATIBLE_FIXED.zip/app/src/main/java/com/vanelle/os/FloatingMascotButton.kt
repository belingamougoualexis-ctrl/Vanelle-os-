package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Bouton flottant "mascotte" affiché par-dessus toutes les applis (comme
 * Messenger Chat Heads). Un simple appui déclenche directement la capture
 * de commande vocale. L'utilisateur choisit lui-même le moment en appuyant
 * sur le bouton.
 * Un glissé déplace le bouton ; il se colle au bord le plus proche au lâcher.
 * Un pincement à deux doigts, directement sur le bouton (peu importe l'appli
 * ouverte en dessous), redimensionne le bouton en direct — pas besoin de
 * retourner dans les réglages de l'app.
 */
object FloatingMascotButton {
    private const val PREF_ENABLED = "floating_mascot_button_enabled"
    private const val PREF_SIZE_DP = "floating_mascot_button_size_dp"
    const val MIN_SIZE_DP = 36
    const val MAX_SIZE_DP = 90
    const val DEFAULT_SIZE_DP = 58
    private var buttonView: View? = null
    private var windowManager: WindowManager? = null

    private fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("vanelle_prefs", 0)

    fun isEnabled(c: Context): Boolean = prefs(c).getBoolean(PREF_ENABLED, false)

    fun setEnabled(c: Context, enabled: Boolean) {
        prefs(c).edit().putBoolean(PREF_ENABLED, enabled).apply()
        if (enabled) show(c) else hide(c)
    }

    fun getSizeDp(c: Context): Int = prefs(c).getInt(PREF_SIZE_DP, DEFAULT_SIZE_DP)
        .coerceIn(MIN_SIZE_DP, MAX_SIZE_DP)

    fun setSizeDp(c: Context, sizeDp: Int) {
        prefs(c).edit().putInt(PREF_SIZE_DP, sizeDp.coerceIn(MIN_SIZE_DP, MAX_SIZE_DP)).apply()
        // Applique tout de suite si le bouton est déjà affiché, sans avoir à rouvrir l'app
        if (buttonView != null) refreshIcon(c)
    }

    private fun persistSizeDpSilently(c: Context, sizeDp: Int) {
        prefs(c).edit().putInt(PREF_SIZE_DP, sizeDp.coerceIn(MIN_SIZE_DP, MAX_SIZE_DP)).apply()
    }

    private fun dp(c: Context, v: Int): Int =
        (v * c.resources.displayMetrics.density).toInt()

    fun show(c: Context) {
        if (!OverlayHelper.canDraw(c)) return
        val appCtx = c.applicationContext
        if (buttonView != null) return // déjà affiché

        val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        var currentSizeDp = getSizeDp(appCtx)
        var size = dp(appCtx, currentSizeDp)
        val mascotId = MascotManager.getSelected(appCtx)
        val drawableId = MascotManager.getDrawableId(appCtx, mascotId)

        val button = FrameLayout(appCtx).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFFFFFFFF.toInt())
                setStroke(dp(appCtx, 2), 0xFF00A878.toInt())
            }
            elevation = 16f
            clipToOutline = true
        }
        val img = ImageView(appCtx).apply {
            if (drawableId != 0) setImageResource(drawableId)
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(size, size)
        }
        button.addView(img)

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = dp(appCtx, 12)
        params.y = dp(appCtx, 260)

        // Pincement à deux doigts = redimensionnement en direct, où que soit l'utilisateur.
        val scaleDetector = ScaleGestureDetector(appCtx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val newSizeDp = (currentSizeDp * detector.scaleFactor).roundToInt()
                    .coerceIn(MIN_SIZE_DP, MAX_SIZE_DP)
                if (newSizeDp != currentSizeDp) {
                    currentSizeDp = newSizeDp
                    size = dp(appCtx, currentSizeDp)
                    params.width = size
                    params.height = size
                    img.layoutParams = FrameLayout.LayoutParams(size, size)
                    try { wm.updateViewLayout(button, params) } catch (_: Exception) {}
                }
                return true
            }
        })

        // Distingue un appui (déclenche la commande) d'un glissé (déplace le bouton)
        // ou d'un pincement (redimensionne) : en dessous d'un petit seuil de
        // mouvement à un seul doigt, c'est un tap.
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var resizing = false
        val tapSlop = dp(appCtx, 10)

        button.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            if (ev.pointerCount >= 2) resizing = true

            when (ev.action and MotionEvent.ACTION_MASK) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = ev.rawX
                    touchY = ev.rawY
                    moved = false
                    resizing = false
                    true
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    resizing = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!resizing) {
                        val dx = (ev.rawX - touchX).toInt()
                        val dy = (ev.rawY - touchY).toInt()
                        if (abs(dx) > tapSlop || abs(dy) > tapSlop) moved = true
                        if (moved) {
                            params.x = startX + dx
                            params.y = startY + dy
                            try { wm.updateViewLayout(button, params) } catch (_: Exception) {}
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (resizing) {
                        persistSizeDpSilently(appCtx, currentSizeDp)
                    } else if (!moved) {
                        triggerCapture(appCtx)
                    } else {
                        snapToEdge(appCtx, wm, button, params)
                    }
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(button, params)
            buttonView = button
        } catch (_: Exception) {}
    }

    fun hide(c: Context) {
        val wm = windowManager ?: (c.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager)
        try { buttonView?.let { wm.removeView(it) } } catch (_: Exception) {}
        buttonView = null
    }

    /** À rappeler quand la mascotte sélectionnée change, pour rafraîchir l'icône affichée. */
    fun refreshIcon(c: Context) {
        if (buttonView == null) return
        hide(c)
        show(c)
    }

    private fun snapToEdge(c: Context, wm: WindowManager, view: View, params: WindowManager.LayoutParams) {
        val metrics = c.resources.displayMetrics
        val screenWidth = metrics.widthPixels
        val mid = params.x + view.width / 2
        params.x = if (mid < screenWidth / 2) dp(c, 12) else screenWidth - view.width - dp(c, 12)
        try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
    }

    private fun triggerCapture(c: Context) {
        try {
            val intent = Intent(c, VoiceCaptureActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            c.startActivity(intent)
        } catch (_: Exception) {}
    }
}
