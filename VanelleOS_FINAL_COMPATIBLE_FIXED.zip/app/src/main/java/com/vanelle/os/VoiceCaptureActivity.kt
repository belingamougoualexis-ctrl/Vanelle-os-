package com.vanelle.os

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Capture vocale **sans page noire** : affiche uniquement la mascotte (taille moyenne)
 * au centre. Reconnaissance via SpeechRecognizer (pas d'UI système Google).
 * La bouche s'anime à l'écoute puis à la réponse.
 */
class VoiceCaptureActivity : ComponentActivity() {

    private var finished = false
    private var listening = false
    private var tts: TextToSpeech? = null
    private var speech: SpeechRecognizer? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())

    private var mascotFrame: FrameLayout? = null
    private var mouthView: View? = null
    private var statusLabel: TextView? = null
    private var listenPulse: Runnable? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening()
            else {
                speakAndFinish(
                    "Permission micro refusée. Active le micro dans les réglages pour que Vanelle t'entende."
                )
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        finished = false
        listening = false
        window.setBackgroundDrawableResource(android.R.color.transparent)
        try {
            window.statusBarColor = Color.TRANSPARENT
            window.navigationBarColor = Color.TRANSPARENT
        } catch (_: Exception) {}

        setContentView(buildMascotUi())
        initTts()

        when {
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED -> {
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
            !SpeechRecognizer.isRecognitionAvailable(this) -> {
                speakAndFinish(
                    "Aucun moteur de reconnaissance vocale disponible. Installe Speech Services by Google, puis réessaie."
                )
            }
            else -> startListening()
        }
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    /** UI : fond transparent + mascotte taille moyenne au centre. */
    private fun buildMascotUi(): View {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            layoutParams = FrameLayout.LayoutParams(-1, -1)
            // Toucher hors mascotte = annuler discrètement
            setOnClickListener { cancelQuiet() }
        }

        val size = dp(160) // taille moyenne
        val frame = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(size, size).apply {
                gravity = Gravity.CENTER
            }
        }
        mascotFrame = frame

        val sel = MascotManager.getSelected(this)
        val mid = try { MascotManager.getDrawableId(this, sel) } catch (_: Exception) { 0 }
        val img = ImageView(this).apply {
            if (mid != 0) setImageResource(mid)
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = FrameLayout.LayoutParams(size, size)
        }

        // Bouche sur le visage (~32 % depuis le haut)
        val mouthW = dp(42)
        val mouthH = dp(18)
        val mouth = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(mouthW, mouthH).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                topMargin = (size * 0.32f).toInt()
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF0B5D3B.toInt())
                setStroke(dp(1), 0xFF00A878.toInt())
            }
            pivotX = mouthW / 2f
            pivotY = mouthH / 2f
            scaleX = 0.55f
            scaleY = 0.15f
            visibility = View.VISIBLE
            elevation = 12f
        }
        mouthView = mouth
        frame.addView(img)
        frame.addView(mouth)

        val label = TextView(this).apply {
            text = "Je t'écoute…"
            setTextColor(0xFF00A878.toInt())
            textSize = 14f
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(-2, -2).apply {
                gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
                bottomMargin = dp(48)
            }
        }
        statusLabel = label

        root.addView(frame)
        root.addView(label)
        return root
    }

    private fun initTts() {
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.FRANCE
                VoicePrefs.apply(this@VoiceCaptureActivity, tts)
            }
        }
    }

    private fun startListening() {
        if (finished || listening) return
        listening = true
        statusLabel?.text = "Je t'écoute…"
        startMouthListenPulse()

        try {
            speech?.destroy()
        } catch (_: Exception) {}

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speakAndFinish("Reconnaissance vocale indisponible. Installe Speech Services by Google.")
            return
        }

        speech = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    statusLabel?.text = "Parle maintenant…"
                }
                override fun onBeginningOfSpeech() {
                    statusLabel?.text = "…"
                }
                override fun onRmsChanged(rmsdB: Float) {
                    // Ouverture légère de la bouche selon le volume
                    val m = mouthView ?: return
                    val open = (0.15f + (rmsdB.coerceIn(0f, 10f) / 10f) * 0.85f)
                    m.scaleY = open
                    m.scaleX = 0.55f + open * 0.45f
                }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    statusLabel?.text = "…"
                    stopMouthListenPulse()
                }
                override fun onError(error: Int) {
                    listening = false
                    stopMouthListenPulse()
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            "Je n'ai rien entendu. Appuie à nouveau sur la mascotte et parle clairement."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                            "Permission micro manquante. Autorise le micro dans les réglages."
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "Problème réseau pour la dictée. Vérifie ta connexion et réessaie."
                        else ->
                            "La dictée a échoué. Appuie à nouveau sur la mascotte pour réessayer."
                    }
                    speakAndFinish(msg)
                }
                override fun onResults(results: Bundle?) {
                    listening = false
                    stopMouthListenPulse()
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()
                    if (text.isBlank()) {
                        speakAndFinish("Je n'ai rien entendu. Appuie à nouveau sur la mascotte et parle clairement.")
                    } else {
                        processVoiceCommand(text)
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try {
            speech?.startListening(intent)
        } catch (_: Exception) {
            speakAndFinish("Impossible de démarrer l'écoute. Réessaie dans un instant.")
        }
    }

    private fun startMouthListenPulse() {
        stopMouthListenPulse()
        val m = mouthView ?: return
        m.visibility = View.VISIBLE
        val r = object : Runnable {
            var open = false
            override fun run() {
                if (!listening) return
                open = !open
                m.animate().cancel()
                if (open) {
                    m.animate().scaleX(1.0f).scaleY(0.85f).setDuration(180).start()
                } else {
                    m.animate().scaleX(0.55f).scaleY(0.15f).setDuration(180).start()
                }
                handler.postDelayed(this, 220)
            }
        }
        listenPulse = r
        handler.post(r)
    }

    private fun stopMouthListenPulse() {
        listenPulse?.let { handler.removeCallbacks(it) }
        listenPulse = null
        mouthView?.animate()?.cancel()
        mouthView?.scaleX = 0.55f
        mouthView?.scaleY = 0.15f
    }

    private fun processVoiceCommand(text: String) {
        if (finished) return
        finished = true
        listening = false
        statusLabel?.text = "…"

        val lower = text.lowercase()
        val wantsOpenApp = lower.contains("ouvre vanelle") || lower.contains("ouvre l'app") ||
            lower.contains("ouvre l application") || lower.contains("ouvre l'application") ||
            lower.contains("ouvre vanelleos") || lower.contains("affiche vanelle")

        if (wantsOpenApp) {
            try {
                startActivity(Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                })
            } catch (_: Exception) {}
            finish()
            return
        }

        scope.launch {
            try {
                var res = withContext(Dispatchers.IO) {
                    try {
                        if (LlamaModelManager.isReady(this@VoiceCaptureActivity) &&
                            !LocalLlamaHelper.get(this@VoiceCaptureActivity).isLoaded()
                        ) {
                            LocalLlamaHelper.get(this@VoiceCaptureActivity).warmUp()
                        }
                    } catch (_: Exception) {}
                    CommandInterpreter(this@VoiceCaptureActivity).execute(text)
                }
                if (res.isBlank()) {
                    res = "Je n'ai pas pu répondre. Reformule ta demande, ou vérifie la connexion et les permissions."
                }
                val spokenText = RelationalMemory(this@VoiceCaptureActivity).withSpokenName(res)

                // Ferme cette activité : la réponse s'affiche via overlay (mascotte qui parle)
                if (OverlayHelper.canDraw(this@VoiceCaptureActivity)) {
                    val sel = MascotManager.getSelected(this@VoiceCaptureActivity)
                    val mid = try {
                        MascotManager.getDrawableId(this@VoiceCaptureActivity, sel)
                    } catch (_: Exception) { 0 }
                    OverlayHelper.show(this@VoiceCaptureActivity, mid, text, res)
                    speak(spokenText)
                    finish()
                } else {
                    speak(spokenText)
                    handler.postDelayed({ finish() }, 400)
                }
            } catch (e: Exception) {
                val msg = "Erreur : ${e.message ?: "inconnue"}. Vérifie ta connexion et les permissions, puis réessaie."
                speakAndFinish(msg)
            }
        }
    }

    private fun speakAndFinish(msg: String) {
        finished = true
        listening = false
        stopMouthListenPulse()
        statusLabel?.text = msg.take(40)
        if (OverlayHelper.canDraw(this)) {
            val sel = MascotManager.getSelected(this)
            val mid = try { MascotManager.getDrawableId(this, sel) } catch (_: Exception) { 0 }
            OverlayHelper.show(this, mid, "", msg)
        }
        speak(msg)
        handler.postDelayed({ finish() }, 600)
    }

    private fun speak(text: String) {
        try { VoicePrefs.apply(this, tts) } catch (_: Exception) {}
        val toSay = text.trim().ifBlank {
            "Je n'ai pas pu répondre. Reformule ta demande ou réessaie."
        }
        try {
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {
                    OverlayHelper.startTalking()
                    animateLocalMouthTalking(true)
                }
                override fun onDone(id: String?) {
                    OverlayHelper.stopTalking()
                    animateLocalMouthTalking(false)
                }
                override fun onError(id: String?) {
                    OverlayHelper.stopTalking()
                    animateLocalMouthTalking(false)
                }
                override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                    val chunk = try {
                        if (start >= 0 && end > start && end <= toSay.length) toSay.substring(start, end) else null
                    } catch (_: Exception) { null }
                    OverlayHelper.pulseMouth(chunk)
                    pulseLocalMouth()
                }
            })
            val params = Bundle()
            tts?.speak(toSay, TextToSpeech.QUEUE_FLUSH, params, "vanelle_voice")
        } catch (_: Exception) {
            try { tts?.speak(toSay, TextToSpeech.QUEUE_FLUSH, null, "vanelle_voice") } catch (_: Exception) {}
        }
    }

    private fun animateLocalMouthTalking(on: Boolean) {
        val m = mouthView ?: return
        m.visibility = View.VISIBLE
        if (!on) {
            m.animate().cancel()
            m.scaleX = 0.55f
            m.scaleY = 0.15f
        }
    }

    private fun pulseLocalMouth() {
        val m = mouthView ?: return
        m.visibility = View.VISIBLE
        m.animate().cancel()
        m.animate().scaleX(1.05f).scaleY(1.0f).setDuration(50).withEndAction {
            m.animate().scaleX(0.55f).scaleY(0.18f).setDuration(80).start()
        }.start()
    }

    private fun cancelQuiet() {
        if (finished) return
        finished = true
        listening = false
        try { speech?.cancel() } catch (_: Exception) {}
        stopMouthListenPulse()
        finish()
    }

    override fun onDestroy() {
        listening = false
        stopMouthListenPulse()
        try { speech?.destroy() } catch (_: Exception) {}
        speech = null
        super.onDestroy()
    }
}
