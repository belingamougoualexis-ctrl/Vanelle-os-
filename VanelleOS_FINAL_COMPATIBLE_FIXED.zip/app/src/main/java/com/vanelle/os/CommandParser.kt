package com.vanelle.os
enum class CommandIntent{UNKNOWN,OPEN_APP,CALL_CONTACT,SEND_MESSAGE,SEARCH_WEB,YOUTUBE,TRANSLATE,MEMORY_SAVE,MEMORY_GET,MEMORY_CLEAR,EMERGENCY,BATTERY,RESTAURANT,TOOL,LOST_PHONE,MAPS,ACCESSIBILITY_ACTION,SCHEDULE_TASK,TRANSLATE_MODE_ON,TRANSLATE_MODE_OFF,READ_SCREEN,CLICK_SCREEN,STREAMING,SHOW_MASCOT,SCREEN_SUMMARY,SCREEN_FILL,SHOW_ACTIVITY_LOG,SET_PERSONALITY,CREATE_ROUTINE,LIST_ROUTINES,REMEMBER_FACT,SET_PROFILE,OPEN_CAMERA,OPEN_GALLERY,AGENT_GOAL,EPISODIC_SUMMARY,EPISODIC_CONSOLIDATE,SPATIAL_CONTEXT,HAPTIC_DEMO,DYNAMIC_TOOL,PRIVACY_STATUS,PRIVACY_LOCKDOWN,GUIDANCE_OVERLAY,FORCE_NIGHTLY,POINT_NODE,FLASHLIGHT,VOLUME,RINGER,CLIPBOARD_READ,CLIPBOARD_WRITE,OPEN_URL,SHARE_TEXT,TIMER}
data class ParsedCommand(val intent:CommandIntent,val args:Map<String,String>)
object CommandParser{
    private fun stripAccents(s:String)=s
        .replace(Regex("[éèêë]"),"e").replace(Regex("[àâ]"),"a").replace(Regex("[îï]"),"i")
        .replace(Regex("[ôö]"),"o").replace(Regex("[ùûü]"),"u").replace("ç","c")

    // Mots de politesse/liaison retires en tete de phrase pour accepter des formulations libres
    private val fillers=listOf("tu dois ","tu peux ","peux tu ","pourrais tu ","j'aimerais que tu ","jaimerais que tu ","il faut que tu ","stp ","s'il te plait ","sil te plait ")

    private fun stripFillers(input0:String):String{
        var input=input0
        var changed=true
        while(changed){
            changed=false
            val t=stripAccents(input.lowercase())
            for(f in fillers){
                val fn=stripAccents(f)
                if(t.startsWith(fn)){ input=input.substring(f.length).trim(); changed=true; break }
            }
        }
        return input
    }

    private data class TimeMatch(val hour:Int,val minute:Int,val range:IntRange)
    // Cherche une expression d'heure n'importe ou dans la phrase (8h, 8h30, 12 heures, midi, minuit...)
    private fun findTime(t:String):TimeMatch?{
        // 18h30 / 18h / 9h05
        Regex("(\d{1,2})h(\d{0,2})").find(t)?.let{
            val h=(it.groupValues[1].toIntOrNull()?:8).coerceIn(0,23)
            val m=(it.groupValues[2].ifBlank{"0"}.toIntOrNull()?:0).coerceIn(0,59)
            return TimeMatch(h,m,it.range)
        }
        // 18:30
        Regex("(\d{1,2}):(\d{2})").find(t)?.let{
            val h=(it.groupValues[1].toIntOrNull()?:8).coerceIn(0,23)
            val m=(it.groupValues[2].toIntOrNull()?:0).coerceIn(0,59)
            return TimeMatch(h,m,it.range)
        }
        // 18 heures 30 / 18 heure
        Regex("(\d{1,2})\s*heures?(?:\s+(\d{1,2}))?").find(t)?.let{
            val h=(it.groupValues[1].toIntOrNull()?:8).coerceIn(0,23)
            val m=(it.groupValues.getOrNull(2)?.toIntOrNull()?:0).coerceIn(0,59)
            return TimeMatch(h,m,it.range)
        }
        Regex("\bmidi\b").find(t)?.let{ return TimeMatch(12,0,it.range) }
        Regex("\bminuit\b").find(t)?.let{ return TimeMatch(0,0,it.range) }
        return null
    }

    fun parse(input0:String):ParsedCommand{
        val input=stripFillers(input0.trim())
        val t=stripAccents(input.lowercase())

        
        // --- Actions appareil rapides (prioritaires) ---
        if(t.contains("lampe")||t.contains("torche")||t.contains("flashlight")){
            val on = when {
                t.contains("allume")||t.contains("active")||t.contains("ouvre")||t.contains("on")-> "1"
                t.contains("eteint")||t.contains("éteint")||t.contains("desactive")||t.contains("désactive")||t.contains("off")-> "0"
                else -> ""
            }
            return ParsedCommand(CommandIntent.FLASHLIGHT,mapOf("on" to on))
        }
        if(t.contains("volume")||t.contains("son plus")||t.contains("son moins")||t.contains("coupe le son")||t.contains("mets en sourdine")){
            val dir = when {
                t.contains("plus")||t.contains("augmente")||t.contains("monte")-> "up"
                t.contains("moins")||t.contains("baisse")||t.contains("diminue")-> "down"
                t.contains("coupe")||t.contains("sourdine")||t.contains("mute")-> "mute"
                t.contains("reactive")||t.contains("réactive")||t.contains("unmute")-> "unmute"
                else -> "status"
            }
            return ParsedCommand(CommandIntent.VOLUME,mapOf("dir" to dir))
        }
        if(t.contains("mode silencieux")||t.contains("silencieux")||t.contains("mode vibreur")||t.contains("vibreur")||t.contains("mode son normal")||t.contains("reactive le son")||t.contains("réactive le son")){
            val mode = when {
                t.contains("silencieux")-> "silent"
                t.contains("vibreur")-> "vibrate"
                else -> "normal"
            }
            return ParsedCommand(CommandIntent.RINGER,mapOf("mode" to mode))
        }
        if(t.contains("presse-papiers")||t.contains("presse papiers")||t.contains("clipboard")||t.contains("qu est-ce que j ai copie")||t.contains("qu'est-ce que j'ai copié")||t.contains("lis le presse"))
            return ParsedCommand(CommandIntent.CLIPBOARD_READ,emptyMap())
        if(t.startsWith("copie ")||t.startsWith("copier ")||t.contains("copie dans le presse")||t.contains("mets dans le presse")){
            val text = when {
                t.startsWith("copie ")||t.startsWith("copier ")-> input.substringAfter(" ").trim()
                t.contains(":")-> input.substringAfter(":").trim()
                else -> input.substringAfter("presse").trim()
            }
            return ParsedCommand(CommandIntent.CLIPBOARD_WRITE,mapOf("text" to text))
        }
        if(t.startsWith("ouvre http")||t.startsWith("ouvre www")||t.startsWith("ouvre le site")||t.contains("ouvre l url")||t.contains("ouvre l'url")){
            val url = input.replace(Regex("(?i)ouvre (le site |l['']url |l url )?"),"").trim()
            return ParsedCommand(CommandIntent.OPEN_URL,mapOf("url" to url))
        }
        if(t.startsWith("partage ")||t.startsWith("partager "))
            return ParsedCommand(CommandIntent.SHARE_TEXT,mapOf("text" to input.substringAfter(" ").trim()))
        if(t.contains("minuteur")||t.contains("timer")||Regex("dans (\\d+) ?minutes?").containsMatchIn(t)||Regex("(\\d+) ?minutes? de minuteur").containsMatchIn(t)){
            val m = Regex("(\\d+)").find(t)?.groupValues?.get(1)?.toIntOrNull() ?: 5
            return ParsedCommand(CommandIntent.TIMER,mapOf("minutes" to m.toString()))
        }

        if(t.contains("n'ouvre pas")||t.contains("n ouvre pas")) return ParsedCommand(CommandIntent.UNKNOWN,emptyMap())
        if(Regex("(quitte|arrete|stop)\\s+(le\\s+)?mode\\s+traduction").containsMatchIn(t)||t.contains("stop traduction")) return ParsedCommand(CommandIntent.TRANSLATE_MODE_OFF,emptyMap())
        if(t.contains("mode traduction")){
            val m=Regex("de ([a-z]+) (?:vers|a) ([a-z]+)").find(t)
            if(m!=null){
                val src=TranslateHelper.codeFor(m.groupValues[1]) ?: "auto"
                val tgt=TranslateHelper.codeFor(m.groupValues[2]) ?: "fr"
                return ParsedCommand(CommandIntent.TRANSLATE_MODE_ON,mapOf("source" to src,"target" to tgt))
            }
            return ParsedCommand(CommandIntent.TRANSLATE_MODE_ON,mapOf("source" to "auto","target" to "fr"))
        }
        // Appel de la mascotte par son nom (ex: "Luna", "apparais", "montre-toi")
        if(t=="apparais"||t=="montre toi"||t=="montre-toi"||t.startsWith("viens ")||t.contains("apparait")||t.contains("apparais"))
            return ParsedCommand(CommandIntent.SHOW_MASCOT,emptyMap())
        // --- Nouvelles intentions révolutionnaires ---
        
        // --- Fonctionnalités futuristes ---
        
        
        if(t.startsWith("montre ")&&(t.contains("fleche")||t.contains("flèche")||t.contains("guide")||t.contains("overlay"))||t.contains("guidage")||t.contains("affiche le guide"))
            return ParsedCommand(CommandIntent.GUIDANCE_OVERLAY,mapOf("message" to input.substringAfter("montre ").ifBlank{ input }.trim()))
        if(t.contains("consolidation maintenant")||t.contains("force consolidation")||t.contains("lance consolidation"))
            return ParsedCommand(CommandIntent.FORCE_NIGHTLY,emptyMap())

        
        if(t.startsWith("pointe ")||t.contains("pointe le bouton")||t.contains("montre le bouton")||t.contains("surligne ")) {
            var target = input
            for (prefix in listOf("pointe le bouton ", "pointe ", "montre le bouton ", "surligne ")) {
                val idx = target.lowercase().indexOf(prefix)
                if (idx >= 0) { target = target.substring(idx + prefix.length).trim(); break }
            }
            return ParsedCommand(CommandIntent.POINT_NODE, mapOf("target" to target))
        }

        if(t.contains("pare-feu")||t.contains("confidentialite")||t.contains("confidentialité")||t.contains("vie privee")||t.contains("vie privée")||t.contains("privacy"))
            return ParsedCommand(CommandIntent.PRIVACY_STATUS,emptyMap())
        if(t.contains("lockdown")||t.contains("verrouille tout")||t.contains("mode paranoid")||t.contains("mode paranoïd")||t.contains("bloque tout"))
            return ParsedCommand(CommandIntent.PRIVACY_LOCKDOWN,emptyMap())

        if(t.contains("contexte")&&(t.contains("spatial")||t.contains("situation")||t.contains("environnement")||t.contains("ou suis je")||t.contains("où suis-je")||t.contains("mon contexte")||t.contains("quel est")))
            return ParsedCommand(CommandIntent.SPATIAL_CONTEXT,emptyMap())
        if(t.contains("consolide")||t.contains("consolidation")||(t.contains("memoire")&&t.contains("nuit")))
            return ParsedCommand(CommandIntent.EPISODIC_CONSOLIDATE,emptyMap())
        if(t.contains("resume ma journee")||t.contains("résume ma journée")||t.contains("episodes du jour")||t.contains("épisodes du jour")||t.contains("memoire episodique")||t.contains("mémoire épisodique"))
            return ParsedCommand(CommandIntent.EPISODIC_SUMMARY,emptyMap())
        if(t.contains("vibration")||t.contains("haptique")||t.contains("fais vibrer")||t.contains("langage haptique"))
            return ParsedCommand(CommandIntent.HAPTIC_DEMO,emptyMap())
        if(t.startsWith("cree un outil")||t.startsWith("crée un outil")||t.startsWith("genere un outil")||t.startsWith("génère un outil")||t.contains("outil pour "))
            return ParsedCommand(CommandIntent.DYNAMIC_TOOL,mapOf("request" to input))
        if(t.startsWith("realise ")||t.startsWith("réalise ")||t.startsWith("execute le plan ")||t.startsWith("exécute le plan ")||t.startsWith("agent ")||t.contains("etape par etape")||t.contains("étape par étape")||t.startsWith("prepare mon ")||t.startsWith("prépare mon ")||t.startsWith("organise "))
            return ParsedCommand(CommandIntent.AGENT_GOAL,mapOf("goal" to input))
        if(t.contains("journal")&&(t.contains("activite")||t.contains("activité")||t.contains("historique")||t.contains("qu est-ce que tu as fait")||t.contains("qu'as-tu fait")))
            return ParsedCommand(CommandIntent.SHOW_ACTIVITY_LOG,emptyMap())
        if(t.contains("resume l ecran")||t.contains("résume l'écran")||t.contains("resume l'ecran")||t.contains("qu est-ce que je vois")||t.contains("que vois-tu")||t.contains("lis tout l ecran"))
            return ParsedCommand(CommandIntent.SCREEN_SUMMARY,emptyMap())
        if(t.startsWith("remplis ")||t.contains("remplis le formulaire")||t.contains("complete le champ")||t.contains("complète le champ"))
            return ParsedCommand(CommandIntent.SCREEN_FILL,mapOf("text" to input.substringAfter("avec", input.substringAfter("remplis ").trim()).trim()))
        if(Regex("personnalite|personnalité|sois (calme|energique|énergique|coach|pote)").containsMatchIn(t)){
            val id=when{
                t.contains("calme")-> "calme"
                t.contains("energique")||t.contains("énergique")-> "energique"
                t.contains("coach")-> "coach"
                t.contains("pote")-> "pote"
                else-> "pote"
            }
            return ParsedCommand(CommandIntent.SET_PERSONALITY,mapOf("id" to id))
        }
        if(t.startsWith("retiens que ")||t.startsWith("souviens toi que ")||t.startsWith("rappelle toi que ")){
            val raw=input.substringAfter(" que ").trim()
            val key=raw.substringBefore(" est ").substringBefore(" = ").take(40).trim().lowercase()
            return ParsedCommand(CommandIntent.MEMORY_SAVE,mapOf("key" to key.ifEmpty{"note_${System.currentTimeMillis()}"}, "data" to raw))
        }
        if(t.startsWith("je m appelle ")||t.startsWith("je m'appelle ")||t.startsWith("mon prenom est ")||t.startsWith("mon prénom est ")){
            val name=input.substringAfterLast(" ").trim().ifEmpty{ input.substringAfter("appelle ").trim() }
            return ParsedCommand(CommandIntent.SET_PROFILE,mapOf("key" to "prenom","value" to name))
        }
        if((t.contains("routine")||t.contains("chaque matin")||t.contains("tous les matins")) && (t.contains("programme")||t.contains("crée")||t.contains("cree")||findTime(t)!=null)){
            val tm=findTime(t)
            val h=tm?.hour ?: 7
            val m=tm?.minute ?: 30
            return ParsedCommand(CommandIntent.CREATE_ROUTINE,mapOf("name" to "Routine","hour" to h.toString(),"minute" to m.toString(),"actions" to input))
        }
        if(t.contains("mes routines")||t.contains("liste des routines"))
            return ParsedCommand(CommandIntent.LIST_ROUTINES,emptyMap())
        if(t.contains("ouvre la camera")||t.contains("ouvre la caméra")||t.contains("prends une photo")||t.contains("appareil photo"))
            return ParsedCommand(CommandIntent.OPEN_CAMERA,emptyMap())
        if(t.contains("ouvre la galerie")||(t.contains("galerie")&&t.contains("photo")))
            return ParsedCommand(CommandIntent.OPEN_GALLERY,emptyMap())
        if(t.contains("urgence")||t.contains("sos"))
            return ParsedCommand(CommandIntent.EMERGENCY,emptyMap())
        if(t.contains("retrouve mon telephone")) return ParsedCommand(CommandIntent.LOST_PHONE,emptyMap())
        if(t.contains("efface memoire")||t.contains("efface la memoire")) return ParsedCommand(CommandIntent.MEMORY_CLEAR,emptyMap())
        // "rappelle moi ..." AVEC une heure = relance planifiée (prioritaire)
        // sans heure = rappel mémoire
        if(t.startsWith("rappelle moi ") || t.startsWith("rappelez moi ") || t.startsWith("souviens moi ") ||
           t.contains("rappelle-moi") || t.contains("me rappeler")){
            val tm = findTime(t)
            if(tm != null || t.contains(" demain") || t.contains(" tous les jours") || t.contains(" chaque jour") ||
               t.startsWith("programme ") || t.contains(" a ") && Regex("\d").containsMatchIn(t)){
                // traité plus bas par le bloc SCHEDULE_TASK
            } else {
                val key = input.substringAfter("moi ").trim().ifBlank { input }
                return ParsedCommand(CommandIntent.MEMORY_GET, mapOf("key" to key))
            }
        }

        // Une heure detectee n'importe ou dans la phrase = intention de planifier une relance,
        // quelle que soit la formulation ("programme X a 8h", "tu dois appeler Paul a 12 heure"...)
        val repeatDaily=t.contains("tous les jours")||t.contains("chaque jour")
        val timeMatch=findTime(t)
        val explicitSchedule=t.startsWith("programme ")||t.startsWith("planifie ")||
            t.startsWith("rappelle moi ")||t.contains("rappelle-moi")||t.contains("me rappeler")||
            t.startsWith("souviens moi ")||t.contains("pense a me")||t.contains("pense à me")
        if(timeMatch!=null || explicitSchedule){
            var actionText=input
            if(timeMatch!=null) actionText=actionText.removeRange(timeMatch.range.first,minOf(timeMatch.range.last+1,actionText.length))
            var at=stripAccents(actionText.lowercase())
            if(at.startsWith("programme ")){ actionText=actionText.substring(10); at=stripAccents(actionText.lowercase()) }
            else if(at.startsWith("planifie ")){ actionText=actionText.substring(9); at=stripAccents(actionText.lowercase()) }
            actionText=actionText.replace(Regex("tous les jours",RegexOption.IGNORE_CASE),"").replace(Regex("chaque jour",RegexOption.IGNORE_CASE),"")
            actionText=Regex("\\s+(a|à|vers|pour)\\s*$",RegexOption.IGNORE_CASE).replace(actionText.trimEnd(),"").trim()
            if(actionText.isBlank()) actionText="Rappel"
            val hour=timeMatch?.hour ?: 8
            val minute=timeMatch?.minute ?: 0
            return ParsedCommand(CommandIntent.SCHEDULE_TASK,mapOf("description" to actionText,"hour" to hour.toString(),"minute" to minute.toString(),"repeat" to repeatDaily.toString()))
        }

        return detectImmediate(input,t)
    }

    private fun detectImmediate(input:String,t:String):ParsedCommand{
        if(t.contains("batterie")) return ParsedCommand(CommandIntent.BATTERY,emptyMap())
        if(t.contains("retour")||t.contains("revenir")) return ParsedCommand(CommandIntent.ACCESSIBILITY_ACTION,mapOf("action" to "back"))
        if(t.contains("accueil")||t.contains("home")) return ParsedCommand(CommandIntent.ACCESSIBILITY_ACTION,mapOf("action" to "home"))
        if(t.contains("notification")) return ParsedCommand(CommandIntent.ACCESSIBILITY_ACTION,mapOf("action" to "notifications"))
        if(t.contains("recents")) return ParsedCommand(CommandIntent.ACCESSIBILITY_ACTION,mapOf("action" to "recents"))
        if(t.startsWith("ouvre ")||t.startsWith("lance ")) return ParsedCommand(CommandIntent.OPEN_APP,mapOf("app" to input.substringAfter(" ").trim()))

        Regex("\\bappel(?:le|les|er|ons)?\\s+(.+)").find(t)?.let{ m->
            val name=input.substring(m.groups[1]!!.range.first).trim()
            if(name.isNotBlank()) return ParsedCommand(CommandIntent.CALL_CONTACT,mapOf("name" to name))
        }
        Regex("\\b(?:envoie|envoyer|envoies)\\s+(?:un\\s+)?(?:message|sms)\\s+a\\s+(.+)").find(t)?.let{ m->
            val body=input.substring(m.groups[1]!!.range.first).trim()
            val idx=stripAccents(body.lowercase()).indexOf(" texte ")
            return if(idx>=0) ParsedCommand(CommandIntent.SEND_MESSAGE,mapOf("name" to body.substring(0,idx).trim(),"message" to body.substring(idx+7).trim()))
            else ParsedCommand(CommandIntent.SEND_MESSAGE,mapOf("name" to body,"message" to ""))
        }

        // Recherche : comprendre l'intention et extraire uniquement le sujet.
        // Exemples : "fais la recherche de comment faire les tiramisu",
        // "fais une recherche sur les panneaux solaires", "cherche comment installer WhatsApp".
        val searchPatterns = listOf(
            Regex("^fais(?:\\s+une)?\\s+recherche(?:\\s+sur|\\s+de|\\s+pour)?\\s+(.+)$"),
            Regex("^effectue(?:\\s+une)?\\s+recherche(?:\\s+sur|\\s+de|\\s+pour)?\\s+(.+)$"),
            Regex("^recherche(?:\\s+sur|\\s+de|\\s+pour)?\\s+(.+)$"),
            Regex("^cherche(?:\\s+sur|\\s+pour)?\\s+(.+)$")
        )
        for (pattern in searchPatterns) {
            pattern.find(t)?.let { match ->
                val queryStart = (match.range.last - match.groupValues[1].length + 1).coerceAtLeast(0)
                val query = input.substring(queryStart).trim()
                if (query.isNotBlank()) return ParsedCommand(CommandIntent.SEARCH_WEB, mapOf("query" to query))
            }
        }
        if(t.contains("youtube")) return ParsedCommand(CommandIntent.YOUTUBE,mapOf("query" to Regex("youtube",RegexOption.IGNORE_CASE).replace(input,"").trim()))
        Regex("(?:regarde|ouvre)\\s+(.+?)\\s+sur\\s+(netflix|disney\\+?|disney plus|prime\\s*video|prime)").find(t)?.let{ m->
            val title=input.substring(0,m.groups[1]!!.range.last+1).let{ s-> Regex("(?i)^(regarde|ouvre)\\s+").replace(s,"") }.trim()
            return ParsedCommand(CommandIntent.STREAMING,mapOf("platform" to m.groupValues[2],"title" to title))
        }
        if(t.startsWith("traduis ")) return ParsedCommand(CommandIntent.TRANSLATE,mapOf("text" to input.substring(8).trim()))
        if(t.contains("resto")) return ParsedCommand(CommandIntent.RESTAURANT,mapOf("query" to input))
        if(t.contains("lis l'ecran")||t.contains("lis ecran")||t.contains("que dit l'ecran")||t.contains("qu'est-ce qui est affiche")||t.contains("qu'est ce qui est affiche")) return ParsedCommand(CommandIntent.READ_SCREEN,emptyMap())
        Regex("(?:clique|appuie|clic)\\s+sur\\s+(.+)").find(t)?.let{ m->
            val target=input.substring(m.groups[1]!!.range.first).trim()
            if(target.isNotBlank()) return ParsedCommand(CommandIntent.CLICK_SCREEN,mapOf("target" to target))
        }
        if(t.contains("calculatrice")) return ParsedCommand(CommandIntent.TOOL,mapOf("tool" to input))
        if(t.contains("maps")||t.contains("navigue")) return ParsedCommand(CommandIntent.MAPS,mapOf("query" to input))
        return ParsedCommand(CommandIntent.UNKNOWN,emptyMap())
    }
}
