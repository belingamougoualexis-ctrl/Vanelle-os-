# VanelleOS – règles ProGuard production

-keep class com.vanelle.os.** { *; }
-keepclassmembers class com.vanelle.os.** { *; }

# TensorFlow Lite
-keep class org.tensorflow.** { *; }
-keep class org.tensorflow.lite.** { *; }
-dontwarn org.tensorflow.**
-dontwarn org.tensorflow.lite.**

# Règles de protection des dépendances de l’application
# Sans ces règles, minify peut supprimer les classes natives → crash systématique
-keep class ai.onnxruntime.** { *; }
-keepclassmembers class ai.onnxruntime.** { *; }
-keepclasseswithmembernames class ai.onnxruntime.** { native <methods>; }
-dontwarn ai.onnxruntime.**
-keep class com.microsoft.onnxruntime.** { *; }
-dontwarn com.microsoft.onnxruntime.**

# Llama.cpp Kotlin / JNI
-keep class org.nehuatl.** { *; }
-keep class org.nehuatl.llamacpp.** { *; }
-keepclassmembers class org.nehuatl.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
-dontwarn org.nehuatl.**

# Kotlin / Coroutines
-keepnames class kotlinx.coroutines.** { *; }
-dontwarn kotlinx.coroutines.**
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }

# JSON
-keep class org.json.** { *; }

# AndroidX
-keep class androidx.** { *; }
-dontwarn androidx.**

# Keep enums used in reflection
-keepclassmembers enum * { *; }

# Attributes
-keepattributes Signature, InnerClasses, EnclosingMethod, *Annotation*, Exception
