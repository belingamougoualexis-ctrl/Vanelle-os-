export async function importEcdsaPublicSpki(spkiB64: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    "spki",
    toArrayBuffer(b64urlToBytes(spkiB64)),
    { name: "ECDSA", namedCurve: "P-256" },
    true,
    ["verify"],
  );
}

export async function signCanonical(privateJwk: JsonWebKey, canonical: string): Promise<string> {
  const key = await importEcdsaPrivate(privateJwk);
  const sig = new Uint8Array(
    await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key, toArrayBuffer(utf8(canonical))),
  );
  return bytesToB64url(sig);
}

export async function verifyCanonical(publicSpkiB64: string, canonical: string, signatureB64: string): Promise<boolean> {
  try {
    const key = await importEcdsaPublicSpki(publicSpkiB64);
    return crypto.subtle.verify(
      { name: "ECDSA", hash: "SHA-256" },
      key,
      toArrayBuffer(b64urlToBytes(signatureB64)),
      toArrayBuffer(utf8(canonical)),
    );
  } catch {
    return false;
  }
}

export async function ecdhSharedBits(privateJwk: JsonWebKey, peerPublicSpkiB64: string): Promise<Uint8Array> {
  const { alg: _alg, key_ops: _ops, ...rest } = privateJwk;
  const ecdhPriv = await crypto.subtle.importKey(
    "jwk",
    { ...rest, key_ops: ["deriveBits"] },
    { name: "ECDH", namedCurve: "P-256" },
    false,
    ["deriveBits"],
  );
  const ecdhPub = await crypto.subtle.importKey(
    "spki",
    toArrayBuffer(b64urlToBytes(peerPublicSpkiB64)),
    { name: "ECDH", namedCurve: "P-256" },
    false,
    [],
  );
  return new Uint8Array(
    await crypto.subtle.deriveBits({ name: "ECDH", public: ecdhPub }, ecdhPriv, 256),
  );
}

export async function encryptForPeer(
  privateJwk: JsonWebKey,
  peerPublicSpkiB64: string,
  plaintext: string,
): Promise<{ iv: string; ct: string }> {
  const shared = await ecdhSharedBits(privateJwk, peerPublicSpkiB64);
  const aes = await crypto.subtle.importKey("raw", toArrayBuffer(shared), "AES-GCM", false, ["encrypt"]);
  const iv = randomBytes(12);
  const ct = new Uint8Array(
    await crypto.subtle.encrypt({ name: "AES-GCM", iv: toArrayBuffer(iv) }, aes, toArrayBuffer(utf8(plaintext))),
  );
  return { iv: bytesToB64url(iv), ct: bytesToB64url(ct) };
}

export async function decryptFromPeer(
  privateJwk: JsonWebKey,
  peerPublicSpkiB64: string,
  packed: { iv: string; ct: string },
): Promise<string> {
  const shared = await ecdhSharedBits(privateJwk, peerPublicSpkiB64);
  const aes = await crypto.subtle.importKey("raw", toArrayBuffer(shared), "AES-GCM", false, ["decrypt"]);
  const pt = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: toArrayBuffer(b64urlToBytes(packed.iv)) },
    aes,
    toArrayBuffer(b64urlToBytes(packed.ct)),
  );
  return new TextDecoder().decode(pt);
}