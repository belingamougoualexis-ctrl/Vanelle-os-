package com.vanelle.os
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max

/**
 * Affiche la mascotte par-dessus l'écran avec synchronisation labiale
 * (bouche qui s'ouvre/ferme au rythme de la parole TTS).
 */
object OverlayHelper {
    private var currentView: View? = null
    private var mouthView: View? = null
    private var answerView: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var hideRunnable: Runnable? = null
    private var mouthRunnable: Runnable? = null
    private var mouthAnimator: ValueAnimator? = null
    private var isTalking = false

    // Formes de bouche personnalisées (visèmes simplifiés)
    // scaleY = ouverture, scaleX = largeur des lèvres
    private const val MOUTH_CLOSED_Y = 0.12f
    private const val MOUTH_CLOSED_X = 0.55f
    private const val MOUTH_MID_Y = 0.55f
    private const val MOUTH_MID_X = 0.90f
    private const val MOUTH_OPEN_Y = 1.00f
    private const val MOUTH_OPEN_X = 1.05f
    private const val MOUTH_WIDE_Y = 0.70f   // sourire / "é"
    private const val MOUTH_WIDE_X = 1.25f
    private const val MOUTH_ROUND_Y = 0.85f  // "o" / "ou"
    private const val MOUTH_ROUND_X = 0.70f
    // Compat pour anciens appels
    private const val MOUTH_CLOSED = MOUTH_CLOSED_Y
    private const val MOUTH_MID = MOUTH_MID_Y
    private const val MOUTH_OPEN = MOUTH_OPEN_Y

    fun canDraw(c: Context): Boolean = Settings.canDrawOverlays(c)

    fun requestPermission(c: Context) {
        try {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            c.startActivity(i)
        } catch (_: Exception) {}
    }

    private fun dp(c: Context, v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), c.resources.displayMetrics).toInt()

    fun show(c: Context, mascotDrawableId: Int, question: String, answer: String) {
        showInternal(c, mascotDrawableId, question, answer, autoHideMs = 16_000L)
    }

    fun showMascot(c: Context, mascotDrawableId: Int, greeting: String = "") {
        showInternal(c, mascotDrawableId, "", greeting, autoHideMs = 12_000L)
    }

    /**
     * Démarre la synchro labiale personnalisée.
     * Appelé au début du TTS (onStart).
     */
    fun startTalking() {
        handler.post {
            isTalking = true
            hideRunnable?.let { handler.removeCallbacks(it) }
            mouthRunnable?.let { handler.removeCallbacks(it) }
            mouthAnimator?.cancel()

            val mouth = mouthView ?: return@post
            mouth.visibility = View.VISIBLE
            mouth.scaleX = MOUTH_CLOSED_X
            mouth.scaleY = MOUTH_CLOSED_Y
            mouth.alpha = 0.95f
            // Micro-mouvement d'ouverture au démarrage (plus vivant)
            animateMouthTo(MOUTH_MID_Y, MOUTH_MID_X, 110L)
        }
    }

    /**
     * Impulsion labiale synchronisée avec un segment de parole (onRangeStart TTS).
     * Forme des lèvres adaptée au son (visème simplifié français).
     */
    fun pulseMouth(spokenChunk: String? = null) {
        if (!isTalking) return
        handler.post {
            val mouth = mouthView ?: return@post
            mouth.visibility = View.VISIBLE

            val (targetY, targetX, holdMs) = visemeFor(spokenChunk)
            animateMouthTo(targetY, targetX, durationMs = 55L) {
                // Referme naturellement après l'impulsion
                if (isTalking) {
                    handler.postDelayed({
                        if (isTalking) animateMouthTo(MOUTH_CLOSED_Y + 0.08f, MOUTH_CLOSED_X + 0.12f, 95L)
                    }, holdMs)
                }
            }
        }
    }

    /** Arrête la synchro labiale (TTS terminé ou erreur). */
    fun stopTalking() {
        handler.post {
            isTalking = false
            mouthRunnable?.let { handler.removeCallbacks(it) }
            mouthRunnable = null
            mouthAnimator?.cancel()
            mouthAnimator = null

            val mouth = mouthView
            if (mouth != null) {
                animateMouthTo(MOUTH_CLOSED_Y, MOUTH_CLOSED_X, 140L) {
                    mouth.visibility = View.INVISIBLE
                }
            }

            // Disparition quelques secondes après la fin de la parole
            hideRunnable?.let { handler.removeCallbacks(it) }
            hideRunnable = Runnable {
                try {
                    currentView?.let { v ->
                        val wm = v.context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                        wm.removeView(v)
                    }
                } catch (_: Exception) {}
                currentView = null
                mouthView = null
                answerView = null
            }
            handler.postDelayed(hideRunnable!!, 3500)
        }
    }

    // --- Animation personnalisée des lèvres ---

    private fun animateMouthTo(scaleY: Float, scaleX: Float, durationMs: Long, end: (() -> Unit)? = null) {
        val mouth = mouthView ?: return
        mouthAnimator?.cancel()
        val startY = mouth.scaleY
        val startX = mouth.scaleX
        val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                mouth.scaleY = startY + (scaleY - startY) * t
                mouth.scaleX = startX + (scaleX - startX) * t
                // Légère variation d'opacité selon l'ouverture
                mouth.alpha = 0.55f + 0.45f * mouth.scaleY.coerceIn(0f, 1f)
            }
            doOnEndCompat { end?.invoke() }
        }
        mouthAnimator = anim
        anim.start()
    }

    /** Compat : ancien appel à 1 paramètre (scaleY seul). */
    private fun animateMouthTo(scaleY: Float, durationMs: Long, end: (() -> Unit)? = null) {
        val x = when {
            scaleY >= MOUTH_OPEN_Y * 0.9f -> MOUTH_OPEN_X
            scaleY >= MOUTH_MID_Y -> MOUTH_MID_X
            else -> MOUTH_CLOSED_X
        }
        animateMouthTo(scaleY, x, durationMs, end)
    }

    private fun ValueAnimator.doOnEndCompat(block: () -> Unit) {
        addListener(object : android.animation.Animator.AnimatorListener {
            override fun onAnimationStart(a: android.animation.Animator) {}
            override fun onAnimationCancel(a: android.animation.Animator) {}
            override fun onAnimationRepeat(a: android.animation.Animator) {}
            override fun onAnimationEnd(a: android.animation.Animator) { block() }
        })
    }

    /**
     * Visèmes simplifiés pour le français.
     * Retourne (scaleY, scaleX, holdMs).
     *  - A / À  → grande ouverture
     *  - É / È  → large (sourire)
     *  - O / OU → arrondie
     *  - I / U  → étroite
     *  - B / P / M → fermée
     */
    private fun visemeFor(chunk: String?): Triple<Float, Float, Long> {
        if (chunk.isNullOrBlank()) {
            // Variation aléatoire légère pour rester vivant
            return listOf(
                Triple(MOUTH_MID_Y, MOUTH_MID_X, 70L),
                Triple(MOUTH_OPEN_Y * 0.9f, MOUTH_OPEN_X, 80L),
                Triple(MOUTH_WIDE_Y, MOUTH_WIDE_X, 75L)
            ).random()
        }
        val lower = chunk.lowercase()
        // Priorité aux sons les plus caractéristiques
        when {
            lower.any { it in "bpm" } ->
                return Triple(MOUTH_CLOSED_Y + 0.05f, MOUTH_CLOSED_X, 55L)
            lower.any { it in "oôöùûu" } || lower.contains("ou") || lower.contains("on") ->
                return Triple(MOUTH_ROUND_Y, MOUTH_ROUND_X, 85L)
            lower.any { it in "éèêëe" } || lower.contains("ai") || lower.contains("ei") ->
                return Triple(MOUTH_WIDE_Y, MOUTH_WIDE_X, 75L)
            lower.any { it in "aàâä" } ->
                return Triple(MOUTH_OPEN_Y, MOUTH_OPEN_X, 90L)
            lower.any { it in "iîïy" } ->
                return Triple(MOUTH_MID_Y * 0.7f, MOUTH_CLOSED_X + 0.15f, 65L)
            lower.any { it in "aeiouyàâäéèêëïîôöùûü" } ->
                return Triple(MOUTH_MID_Y + 0.15f, MOUTH_MID_X, 70L)
            else ->
                return Triple(MOUTH_MID_Y * 0.6f, MOUTH_MID_X * 0.85f, 60L)
        }
    }

    private fun showInternal(c: Context, mascotDrawableId: Int, question: String, answer: String, autoHideMs: Long) {
        if (!canDraw(c)) return
        try {
            val appCtx = c.applicationContext
            val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            remove(appCtx)

            val size = dp(appCtx, 150)
            val imgFrame = FrameLayout(appCtx).apply {
                layoutParams = LinearLayout.LayoutParams(size, size)
            }

            val img = ImageView(appCtx).apply {
                if (mascotDrawableId != 0) setImageResource(mascotDrawableId)
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = FrameLayout.LayoutParams(size, size)
            }

            // Bouche personnalisée : ovale rose-foncé sur le visage, pivots centrés pour un scale naturel
            val mouth = View(appCtx).apply {
                val w = dp(appCtx, 40)
                val h = dp(appCtx, 18)
                layoutParams = FrameLayout.LayoutParams(w, h).apply {
                    // Zone du visage (~36–40 % depuis le haut)
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    topMargin = (size * 0.37f).toInt()
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    // Teinte lèvres (rose profond) + léger contour rose Vanelle
                    setColor(0xFF2A1218.toInt())
                    setStroke(dp(appCtx, 1), 0xFFFF2D95.toInt())
                }
                pivotX = w / 2f
                pivotY = h / 2f
                scaleX = MOUTH_CLOSED_X
                scaleY = MOUTH_CLOSED_Y
                visibility = View.INVISIBLE
                elevation = 12f
            }
            mouthView = mouth
            imgFrame.addView(img)
            imgFrame.addView(mouth)

            val nameTv = TextView(appCtx).apply {
                text = MascotManager.getDisplayName(appCtx)
                setTextColor(0xFFFF2D95.toInt())
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(4, 8, 4, 2)
            }

            val qv = TextView(appCtx).apply {
                text = question
                setTextColor(0xFF6B6B70.toInt())
                textSize = 11f
                setPadding(4, 4, 4, 2)
                gravity = Gravity.CENTER
                visibility = if (question.isBlank()) View.GONE else View.VISIBLE
            }

            val av = TextView(appCtx).apply {
                text = answer
                setTextColor(0xFF0A0A0A.toInt())
                textSize = 13f
                setPadding(4, 0, 4, 4)
                gravity = Gravity.CENTER
            }
            answerView = av

            val card = LinearLayout(appCtx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(appCtx, 20), dp(appCtx, 16), dp(appCtx, 20), dp(appCtx, 16))
                background = UiKit.card(appCtx)
                elevation = 14f
                addView(imgFrame)
                addView(nameTv)
                addView(qv)
                addView(av)
                setOnClickListener { remove(appCtx) }
            }

            val type = if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            params.y = dp(appCtx, 72)

            wm.addView(card, params)
            currentView = card

            hideRunnable?.let { handler.removeCallbacks(it) }
            hideRunnable = Runnable { remove(appCtx) }
            handler.postDelayed(hideRunnable!!, autoHideMs)
        } catch (_: Exception) {}
    }

    fun remove(c: Context) {
        try {
            isTalking = false
            mouthRunnable?.let { handler.removeCallbacks(it) }
            mouthRunnable = null
            mouthAnimator?.cancel()
            mouthAnimator = null
            hideRunnable?.let { handler.removeCallbacks(it) }
            hideRunnable = null
            val wm = c.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            currentView?.let { wm.removeView(it) }
        } catch (_: Exception) {}
        currentView = null
        mouthView = null
        answerView = null
    }
}
