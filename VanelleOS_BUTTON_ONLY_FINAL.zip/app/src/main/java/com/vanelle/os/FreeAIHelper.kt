package com.vanelle.os
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Réponses web réelles uniquement (Wikipedia FR + DuckDuckGo).
 * Aucune phrase pré-écrite / simulation.
 */
class FreeAIHelper(private val context: Context) {

    /**
     * Récupère des faits bruts (Wikipédia FR ou résumé DuckDuckGo), sans mise
     * en forme — destiné à servir de contexte à l'IA locale pour qu'elle
     * reformule avec ses propres mots, jamais à être lu tel quel à l'utilisateur.
     */
    suspend fun fetchRawFacts(q0: String): String? = withContext(Dispatchers.IO) {
        val q = q0.trim()
        if (q.isBlank() || !PrivacyFirewall.allowWeb(context)) return@withContext null
        val topic = q
            .replace(
                Regex("(?i)c'est quoi|c est quoi|qu'est-ce que|qui est|dis[- ]moi|explique[- ]moi|parle[- ]moi de|vanelle"),
                ""
            )
            .trim()
            .take(80)
            .ifEmpty { q.take(40) }
        fetchWiki(topic) ?: fetchDDG(topic)
    }

    fun localOnly(@Suppress("UNUSED_PARAMETER") q0: String): String? = null

    suspend fun answer(q0: String): String = withContext(Dispatchers.IO) {
        val q = q0.trim()
        if (q.isBlank()) return@withContext "Je n'ai rien entendu, tu peux répéter ?"
        if (!PrivacyFirewall.allowWeb(context)) {
            return@withContext "Pare-feu confidentialité : accès web bloqué. Active le web dans les réglages privacy ou désactive le lockdown."
        }

        val topic = q
            .replace(
                Regex("(?i)c'est quoi|c est quoi|qu'est-ce que|qui est|dis[- ]moi|explique[- ]moi|parle[- ]moi de|vanelle"),
                ""
            )
            .trim()
            .take(80)
            .ifEmpty { q.take(40) }

        val wiki = fetchWiki(topic)
        if (wiki != null) {
            val t = wiki.trim()
            return@withContext if (t.length > 420) t.take(417).trimEnd() + "…" else t
        }

        val ddg = fetchDDG(topic)
        if (ddg != null) {
            val t = ddg.trim()
            return@withContext if (t.length > 420) t.take(417).trimEnd() + "…" else t
        }

        "Je n'ai pas trouvé d'info fiable et à jour là-dessus. Reformule ou dis « cherche $topic » pour ouvrir une recherche web."
    }

    private fun fetchWiki(t: String): String? = try {
        val u = URL("https://fr.wikipedia.org/api/rest_v1/page/summary/${URLEncoder.encode(t, "UTF-8")}")
        val c = u.openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "VanelleOS/1.0 (assistant vocal; contact: app)")
        c.connectTimeout = 6000
        c.readTimeout = 6000
        if (c.responseCode == 200) {
            val o = JSONObject(c.inputStream.bufferedReader().readText())
            val e = o.optString("extract")
            if (e.isNotBlank()) e else null
        } else null
    } catch (_: Exception) { null }

    private fun fetchDDG(t: String): String? = try {
        val u = URL("https://api.duckduckgo.com/?q=${URLEncoder.encode(t, "UTF-8")}&format=json&no_html=1&skip_disambig=1")
        val c = u.openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "VanelleOS/1.0")
        c.connectTimeout = 6000
        c.readTimeout = 6000
        if (c.responseCode == 200) {
            val o = JSONObject(c.inputStream.bufferedReader().readText())
            val a = o.optString("AbstractText")
            if (a.isNotBlank()) a else null
        } else null
    } catch (_: Exception) { null }
}
