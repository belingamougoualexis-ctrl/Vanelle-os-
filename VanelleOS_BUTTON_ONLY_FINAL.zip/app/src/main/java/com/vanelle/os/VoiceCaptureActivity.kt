package com.vanelle.os

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/**
 * Capture vocale via l'UI système.
 * Réinitialise toujours son état à chaque ouverture (évite "ça ne marche plus après la 1re fois").
 */
class VoiceCaptureActivity : ComponentActivity() {

    private var launched = false
    private var finished = false
    private lateinit var statusView: TextView

    private val speechLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (finished) return@registerForActivityResult
            val text = if (result.resultCode == Activity.RESULT_OK) {
                result.data
                    ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    ?.firstOrNull()
                    ?.trim()
                    .orEmpty()
            } else {
                ""
            }
            if (text.isNotBlank()) {
                sendResultAndFinish(text)
            } else {
                statusView.text = "Rien n'a été entendu.\nAppuie sur Réessayer et parle clairement."
                Toast.makeText(this, "Aucune phrase reconnue", Toast.LENGTH_SHORT).show()
                launched = false
            }
        }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                statusView.text = "Micro autorisé — lancement de la dictée…"
                launched = false
                launchRecognizer()
            } else {
                statusView.text = "Permission micro refusée.\nActive-la pour que Vanelle t'entende."
                Toast.makeText(this, "Autorise le micro pour la reconnaissance vocale", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Toujours repartir propre
        launched = false
        finished = false
        buildUi()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Nouvelle demande vocale pendant que l'écran est encore là
        launched = false
        finished = false
        statusView.text = "Nouvelle écoute…"
        ensurePermissionAndListen()
    }

    override fun onResume() {
        super.onResume()
        if (!finished && !launched) {
            ensurePermissionAndListen()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }

        statusView = TextView(this).apply {
            text = "Préparation de l'écoute…"
            textSize = 18f
            setTextColor(0xFF0A0A0A.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 32)
        }
        root.addView(statusView)

        root.addView(Button(this).apply {
            text = "Réessayer"
            setOnClickListener {
                launched = false
                finished = false
                ensurePermissionAndListen()
            }
        })
        root.addView(Button(this).apply {
            text = "Installer / ouvrir le moteur vocal"
            setOnClickListener { openSpeechEngineHelp() }
        })
        root.addView(Button(this).apply {
            text = "Annuler"
            setOnClickListener { sendResultAndFinish("") }
        })

        setContentView(root)
    }

    private fun ensurePermissionAndListen() {
        when {
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED -> {
                statusView.text = "Autorisation micro requise pour la reconnaissance vocale"
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
            !SpeechRecognizer.isRecognitionAvailable(this) -> {
                statusView.text =
                    "Aucun moteur de reconnaissance vocale détecté.\nInstalle Google ou Speech Services by Google."
                Toast.makeText(this, "Moteur de reconnaissance manquant", Toast.LENGTH_LONG).show()
            }
            else -> {
                statusView.text = "Parle maintenant…"
                launchRecognizer()
            }
        }
    }

    private fun launchRecognizer() {
        if (finished) return
        if (launched) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Vanelle t'écoute — parle maintenant")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        val resolved = intent.resolveActivity(packageManager)
        if (resolved == null) {
            statusView.text =
                "Aucune app ne gère la dictée vocale.\nAppuie sur « Installer / ouvrir le moteur vocal »."
            return
        }
        try {
            launched = true
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            launched = false
            statusView.text = "Erreur : ${e.message}"
            Toast.makeText(this, "Erreur reconnaissance: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun openSpeechEngineHelp() {
        val tries = listOf(
            Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.googlequicksearchbox")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.googlequicksearchbox")),
            Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.tts")),
            Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS)
        )
        for (i in tries) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                return
            } catch (_: Exception) {
            }
        }
        Toast.makeText(this, "Installe Google / Speech Services by Google", Toast.LENGTH_LONG).show()
    }

    private fun sendResultAndFinish(text: String) {
        if (finished) return
        finished = true
        launched = false
        try {
            val intent = Intent(this, MainActivity::class.java).apply {
                putExtra("pending_command", text)
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            startActivity(intent)
        } catch (_: Exception) {
        }
        finish()
    }

    companion object {
    }
}
