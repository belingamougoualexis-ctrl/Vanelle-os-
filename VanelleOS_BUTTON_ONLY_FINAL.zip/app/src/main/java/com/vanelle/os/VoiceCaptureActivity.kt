package com.vanelle.os

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Capture vocale via l'UI système.
 * Exécute la commande et fait parler la mascotte **sans ouvrir** l'interface VanelleOS,
 * sauf si l'utilisateur demande explicitement d'ouvrir l'app.
 */
class VoiceCaptureActivity : ComponentActivity() {

    private var launched = false
    private var finished = false
    private lateinit var statusView: TextView
    private var tts: TextToSpeech? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val speechLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (finished) return@registerForActivityResult
            val text = if (result.resultCode == Activity.RESULT_OK) {
                result.data
                    ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    ?.firstOrNull()
                    ?.trim()
                    .orEmpty()
            } else {
                ""
            }
            if (text.isNotBlank()) {
                processVoiceCommand(text)
            } else {
                statusView.text = "Rien n'a été entendu.\nAppuie sur Réessayer et parle clairement."
                Toast.makeText(this, "Aucune phrase reconnue", Toast.LENGTH_SHORT).show()
                launched = false
            }
        }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                statusView.text = "Micro autorisé — lancement de la dictée…"
                launched = false
                launchRecognizer()
            } else {
                statusView.text = "Permission micro refusée.\nActive-la pour que Vanelle t'entende."
                Toast.makeText(this, "Autorise le micro pour la reconnaissance vocale", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        launched = false
        finished = false
        initTts()
        buildMinimalUi()
        ensurePermissionAndListen()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        launched = false
        finished = false
        ensurePermissionAndListen()
    }

    private fun initTts() {
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.FRANCE
            }
        }
    }

    private fun buildMinimalUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            setBackgroundColor(0xFF0A0A12.toInt())
        }
        statusView = TextView(this).apply {
            text = "Vanelle t'écoute…"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 32)
        }
        root.addView(statusView)
        root.addView(Button(this).apply {
            text = "Réessayer"
            setOnClickListener {
                launched = false
                finished = false
                ensurePermissionAndListen()
            }
        })
        root.addView(Button(this).apply {
            text = "Installer / ouvrir le moteur vocal"
            setOnClickListener { openSpeechEngineHelp() }
        })
        root.addView(Button(this).apply {
            text = "Annuler"
            setOnClickListener { finishQuiet() }
        })
        setContentView(root)
    }

    private fun ensurePermissionAndListen() {
        when {
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED -> {
                statusView.text = "Autorisation micro requise pour la reconnaissance vocale"
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
            !SpeechRecognizer.isRecognitionAvailable(this) -> {
                statusView.text =
                    "Aucun moteur de reconnaissance vocale disponible.\nInstalle Speech Services by Google."
            }
            else -> launchRecognizer()
        }
    }

    private fun launchRecognizer() {
        if (finished || launched) return
        launched = true
        statusView.text = "Parle maintenant…"
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Vanelle t'écoute — parle maintenant")
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            speechLauncher.launch(intent)
        } catch (_: Exception) {
            launched = false
            statusView.text = "Impossible de lancer la dictée."
        }
    }

    private fun openSpeechEngineHelp() {
        val tries = listOf(
            Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.googlequicksearchbox")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.googlequicksearchbox")),
            Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.tts")),
            Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS)
        )
        for (i in tries) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                return
            } catch (_: Exception) {
            }
        }
        Toast.makeText(this, "Installe Google / Speech Services by Google", Toast.LENGTH_LONG).show()
    }

    /**
     * Traite la commande ici : mascotte + TTS sans ouvrir MainActivity,
     * sauf demande explicite d'ouvrir l'app.
     */
    private fun processVoiceCommand(text: String) {
        if (finished) return
        finished = true
        launched = false

        val lower = text.lowercase()
        val wantsOpenApp = lower.contains("ouvre vanelle") || lower.contains("ouvre l'app") ||
            lower.contains("ouvre l application") || lower.contains("ouvre l'application") ||
            lower.contains("ouvre vanelleos") || lower == "vanelle" ||
            lower.contains("affiche vanelle") || lower.contains("ouvre l interface")

        if (wantsOpenApp) {
            try {
                startActivity(Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                })
            } catch (_: Exception) {}
            finish()
            return
        }

        statusView.text = "Vanelle réfléchit…"
        scope.launch {
            try {
                var res = withContext(Dispatchers.IO) {
                    CommandInterpreter(this@VoiceCaptureActivity).execute(text)
                }
                if (res.isBlank()) {
                    res = "Je n'ai pas pu répondre. Reformule ta demande, ou vérifie la connexion et les permissions dans Configuration."
                }
                val prenom = RelationalMemory(this@VoiceCaptureActivity).displayName().trim()
                val spokenText = if (prenom.isNotBlank()) "$prenom, $res" else res

                if (OverlayHelper.canDraw(this@VoiceCaptureActivity)) {
                    val sel = MascotManager.getSelected(this@VoiceCaptureActivity)
                    val mid = try {
                        MascotManager.getDrawableId(this@VoiceCaptureActivity, sel)
                    } catch (_: Exception) { 0 }
                    OverlayHelper.show(this@VoiceCaptureActivity, mid, text, res)
                    speak(spokenText)
                    // Ferme cette activité transparente : l'utilisateur reste où il était
                    finish()
                } else {
                    // Pas d'overlay → on doit ouvrir l'app pour afficher la réponse
                    try {
                        startActivity(Intent(this@VoiceCaptureActivity, MainActivity::class.java).apply {
                            putExtra("pending_command", text)
                            putExtra("pending_result", res)
                            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        })
                    } catch (_: Exception) {}
                    finish()
                }
            } catch (e: Exception) {
                val msg = "Erreur : ${e.message ?: "inconnue"}. Vérifie ta connexion et les permissions dans Configuration, puis réessaie."
                statusView.text = msg
                try {
                    if (OverlayHelper.canDraw(this@VoiceCaptureActivity)) {
                        val sel = MascotManager.getSelected(this@VoiceCaptureActivity)
                        val mid = try {
                            MascotManager.getDrawableId(this@VoiceCaptureActivity, sel)
                        } catch (_: Exception) { 0 }
                        OverlayHelper.show(this@VoiceCaptureActivity, mid, text, msg)
                    }
                    speak(msg)
                } catch (_: Exception) {}
                // Laisse l'utilisateur réessayer
                finished = false
                launched = false
            }
        }
    }

    private fun speak(text: String) {
        val toSay = text.trim().ifBlank {
            "Je n'ai pas pu répondre. Reformule ta demande ou réessaie."
        }
        try {
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) { OverlayHelper.startTalking() }
                override fun onDone(id: String?) { OverlayHelper.stopTalking() }
                override fun onError(id: String?) { OverlayHelper.stopTalking() }
                override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                    val chunk = try {
                        if (start >= 0 && end > start && end <= toSay.length) toSay.substring(start, end) else null
                    } catch (_: Exception) { null }
                    OverlayHelper.pulseMouth(chunk)
                }
            })
            val params = Bundle()
            tts?.speak(toSay, TextToSpeech.QUEUE_FLUSH, params, "vanelle_voice")
        } catch (_: Exception) {
            try { tts?.speak(toSay, TextToSpeech.QUEUE_FLUSH, null, "vanelle_voice") } catch (_: Exception) {}
        }
    }

    private fun finishQuiet() {
        if (finished) {
            finish()
            return
        }
        finished = true
        finish()
    }

    override fun onDestroy() {
        // Ne pas shutdown TTS tout de suite si une phrase est en cours :
        // on laisse le moteur système terminer (lié au process app).
        super.onDestroy()
    }

    companion object
}
