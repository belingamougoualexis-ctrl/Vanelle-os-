package com.vanelle.os
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.View

/**
 * Design system VanelleOS.
 * Base neutre (blanc / noir doux) + un unique accent de marque (violet Vanelle)
 * réservé aux actions principales, exactement comme le font les apps pro
 * (un seul accent = identité forte, pas un arc-en-ciel de couleurs).
 */
object UiKit {
    // Neutres
    const val BLACK = 0xFF0A0A0A.toInt()          // texte principal (noir doux, pas #000 dur)
    const val TEXT_DARK = 0xFF0A0A0A.toInt()
    const val TEXT_MUTED = 0xFF6B7280.toInt()      // texte secondaire
    const val TEXT_FAINT = 0xFF9CA3AF.toInt()      // placeholders / hints
    const val WHITE = 0xFFFFFFFF.toInt()
    const val SURFACE = 0xFFF7F7F9.toInt()         // fond de section / carte neutre
    const val BORDER = 0xFFE5E5EA.toInt()          // liseré fin (remplace les bordures noires épaisses)
    const val BORDER_STRONG = 0xFFD1D1D6.toInt()

    // Accent de marque — violet Vanelle, réservé aux actions principales
    const val ACCENT = 0xFF3B82C6.toInt()
    const val ACCENT_SOFT = 0xFFDCEEF7.toInt()     // fond teinté clair pour badges/pills actifs
    const val ACCENT_DARK = 0xFF2C6494.toInt()

    // Sémantique
    const val SUCCESS = 0xFF10B981.toInt()
    const val SUCCESS_SOFT = 0xFFE7F8F1.toInt()
    const val DANGER = 0xFFDC2626.toInt()
    const val DANGER_SOFT = 0xFFFDECEC.toInt()

    // Anciens alias conservés pour compatibilité avec le code existant
    const val FOREST = BLACK
    const val EMERALD = ACCENT
    const val TURQUOISE = ACCENT_DARK
    const val MINT = ACCENT_SOFT

    private fun Context.dp(v: Float) = v * resources.displayMetrics.density

    /** Carte standard : fond blanc, liseré fin, coins 14dp, légère élévation. */
    fun card(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(WHITE)
        setStroke(ctx.dp(1f).toInt(), BORDER)
        cornerRadius = ctx.dp(14f)
    }

    /** Applique l'ombre douce standard à une vue (à utiliser avec card()). */
    fun elevate(ctx: Context, view: View, dp: Float = 3f) {
        view.elevation = ctx.dp(dp)
        view.translationZ = 0f
    }

    /** Carte sélectionnée / mise en avant : liseré accent + fond teinté. */
    fun selected(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(ACCENT_SOFT)
        setStroke(ctx.dp(1.5f).toInt(), ACCENT)
        cornerRadius = ctx.dp(14f)
    }

    /** Pill neutre (tag, filtre inactif). */
    fun pill(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(WHITE)
        setStroke(ctx.dp(1f).toInt(), BORDER_STRONG)
        cornerRadius = ctx.dp(20f)
    }

    /** Pill accent (tag actif, statut positif). */
    fun pillAccent(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(ACCENT_SOFT)
        cornerRadius = ctx.dp(20f)
    }

    /** Bouton principal plein (CTA) — fond accent, texte blanc. */
    fun buttonPrimary(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(ACCENT)
        cornerRadius = ctx.dp(12f)
    }

    /** Bouton secondaire — contour discret, fond blanc. */
    fun buttonSecondary(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(WHITE)
        setStroke(ctx.dp(1.5f).toInt(), BORDER_STRONG)
        cornerRadius = ctx.dp(12f)
    }

    /** Badge de statut "actif/accordé". */
    fun badgeSuccess(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(SUCCESS_SOFT)
        cornerRadius = ctx.dp(8f)
    }

    /** Badge de statut "refusé/erreur". */
    fun badgeDanger(ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(DANGER_SOFT)
        cornerRadius = ctx.dp(8f)
    }
}
