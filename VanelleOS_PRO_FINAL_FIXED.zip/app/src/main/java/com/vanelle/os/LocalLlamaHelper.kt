package com.vanelle.os
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Wrapper robuste autour de io.github.ljcamargo:llamacpp-kotlin
 * (package confirmé : org.nehuatl.llamacpp.LlamaHelper).
 *
 * Corrections :
 * - Plus de collect infini → plus de hang
 * - Timeout de sécurité
 * - Prompt formaté pour Llama-3.2-Instruct (meilleures réponses)
 * - Chargement unique thread-safe
 */
class LocalLlamaHelper(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val events = MutableSharedFlow<org.nehuatl.llamacpp.LlamaHelper.LLMEvent>(extraBufferCapacity = 256)

    @Volatile private var loaded = false
    @Volatile private var loading = false
    @Volatile private var helper: org.nehuatl.llamacpp.LlamaHelper? = null
    private val answerMutex = Mutex()

    private suspend fun ensureLoaded(): Boolean {
        if (loaded && helper != null) return true
        if (!LlamaModelManager.isReady(context)) return false
        if (loading) {
            repeat(50) {
                kotlinx.coroutines.delay(200)
                if (loaded && helper != null) return true
            }
            return false
        }
        loading = true
        return try {
            val h = org.nehuatl.llamacpp.LlamaHelper(context.contentResolver, scope, events)
            val modelUri = Uri.fromFile(LlamaModelManager.modelFile(context)).toString()
            val ok = withTimeoutOrNull(180_000L) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    try {
                        h.load(path = modelUri, contextLength = 2048) { _ ->
                            if (cont.isActive) cont.resume(true)
                        }
                    } catch (_: Exception) {
                        if (cont.isActive) cont.resume(false)
                    }
                }
            } ?: false
            if (ok) {
                helper = h
                loaded = true
            }
            ok
        } catch (_: Exception) {
            false
        } finally {
            loading = false
        }
    }

    suspend fun answer(userPrompt: String, extraContext: String = ""): String = answerMutex.withLock {
        if (!ensureLoaded()) return@withLock NOT_READY
        val h = helper ?: return@withLock NOT_READY

        // Template chat Llama-3.2-Instruct → réponses naturelles en français
        val formatted = buildString {
            append("<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n")
            append("Tu es Vanelle, l'assistante personnelle de VanelleOS. Tu parles exactement comme un humain intelligent, pas comme un robot.\n")
            append("Tu comprends les intentions, les émotions, les idées implicites et le contexte. Tu anticipes ce que la personne veut vraiment.\n")
            append("Quand on te pose une question : réponds clairement, avec l'essentiel d'abord, comme un pro bienveillant.\n")
            append("Quand on te demande d'agir : confirme en une phrase naturelle ce que tu fais (ex: « D'accord, j'ouvre Maps. »).\n")
            append("Ton : chaleureux, concis (1 à 4 phrases), français courant et correct. Jamais de « En tant qu'IA » ni de listes robotiques.\n")
            append("Si tu ne sais pas : dis-le simplement et propose une piste utile.\n")
            append(PersonalityPrefs.systemTone(context) + "\n")
            if (extraContext.isNotBlank()) {
                append("Contexte utilisateur (à utiliser discrètement) :\n")
                append(extraContext.take(800) + "\n")
            }

            append("<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n")
            append(userPrompt.trim())
            append("\n<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n")
        }

        return@withLock try {
            withTimeoutOrNull(90_000L) {
                suspendCancellableCoroutine<String> { cont ->
                    val job = scope.launch {
                        try {
                            val sb = StringBuilder()
                            h.predict(formatted)

                            // Collecte bornée : s'arrête dès Done ou Error
                            events
                                .takeWhile { event ->
                                    when (event) {
                                        is org.nehuatl.llamacpp.LlamaHelper.LLMEvent.Ongoing -> {
                                            sb.append(event.word)
                                            true
                                        }
                                        is org.nehuatl.llamacpp.LlamaHelper.LLMEvent.Done -> {
                                            false
                                        }
                                        is org.nehuatl.llamacpp.LlamaHelper.LLMEvent.Error -> {
                                            false
                                        }
                                        else -> true
                                    }
                                }
                                .toList() // force la consommation jusqu'à la fin du takeWhile

                            if (cont.isActive) {
                                cont.resume(sb.toString().trim().ifBlank { "..." })
                            }
                        } catch (_: Exception) {
                            if (cont.isActive) cont.resume(NOT_READY)
                        }
                    }
                    cont.invokeOnCancellation { job.cancel() }
                }
            } ?: NOT_READY
        } catch (_: Exception) {
            NOT_READY
        }
    }

    companion object {
        const val NOT_READY = "__LLAMA_NOT_READY__"
    }
}
