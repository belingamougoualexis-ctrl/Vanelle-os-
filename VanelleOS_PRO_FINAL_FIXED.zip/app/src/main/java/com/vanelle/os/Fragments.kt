package com.vanelle.os
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.webkit.WebView
import android.webkit.WebSettings
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
class MascotFragment:Fragment(){
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val root=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(28,28,28,28); setBackgroundColor(0xFFFFFFFF.toInt())}

        // Grande prévisualisation
        val hero=ImageView(ctx).apply{
            layoutParams=LinearLayout.LayoutParams(-1,480).apply{bottomMargin=16}
            scaleType=ImageView.ScaleType.FIT_CENTER
            background=UiKit.card(ctx)
            adjustViewBounds=true
        }
        var sel=MascotManager.getSelected(ctx)
        fun refreshHero(){
            try{ hero.setImageResource(MascotManager.getDrawableId(ctx,sel)) }catch(_:Exception){}
        }
        refreshHero()

        // Nom personnalisé
        val nameTitle=TextView(ctx).apply{
            text="NOM DE TA MASCOTTE"
            setTextColor(0xFF8A8A8E.toInt()); textSize=11f; letterSpacing=0.1f
            setPadding(4,8,0,8)
        }
        val nameRow=LinearLayout(ctx).apply{
            orientation=LinearLayout.HORIZONTAL
            setPadding(16,8,16,8)
            background=UiKit.card(ctx)
        }
        val nameEdit=EditText(ctx).apply{
            hint="Ex: Luna, Buddy, Pixel..."
            setText(MascotManager.getCustomName(ctx))
            setTextColor(0xFF0A0A0A.toInt())
            setHintTextColor(0xFFAAAAAA.toInt())
            textSize=14f
            background=null
            layoutParams=LinearLayout.LayoutParams(0,-2,1f)
            maxLines=1
            isSingleLine=true
        }
        val saveBtn=Button(ctx).apply{
            text="Enregistrer"
            textSize=11f
            background=UiKit.pill(ctx)
            setTextColor(0xFFFF2D95.toInt())
            setOnClickListener{
                val n=nameEdit.text?.toString()?.trim() ?: ""
                MascotManager.setCustomName(ctx,n)
                Toast.makeText(ctx, if(n.isBlank()) "Nom réinitialisé" else "Nom enregistré : $n", Toast.LENGTH_SHORT).show()
            }
        }
        nameRow.addView(nameEdit); nameRow.addView(saveBtn)

        val nameHint=TextView(ctx).apply{
            text="Dis simplement son nom pour la faire apparaître à l'écran (ex: « Luna »). Permission « afficher par-dessus les apps » requise."
            setTextColor(0xFF8A8A8E.toInt()); textSize=10.5f
            setPadding(6,10,6,16)
        }

        // Grille horizontale de styles
        val styleTitle=TextView(ctx).apply{
            text="CHOISIS UN STYLE"
            setTextColor(0xFF8A8A8E.toInt()); textSize=11f; letterSpacing=0.1f
            setPadding(4,4,0,10)
        }
        val scroll=HorizontalScrollView(ctx).apply{isHorizontalScrollBarEnabled=false}
        val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        for((id,name) in MascotManager.mascots){
            val card=LinearLayout(ctx).apply{
                orientation=LinearLayout.VERTICAL
                setPadding(10,10,10,10)
                layoutParams=LinearLayout.LayoutParams(150,170).apply{setMargins(0,0,12,0)}
                background=if(id==sel) UiKit.selected(ctx) else UiKit.card(ctx)
            }
            val iv=ImageView(ctx).apply{
                try{ setImageResource(MascotManager.getDrawableId(ctx,id)) }catch(_:Exception){}
                scaleType=ImageView.ScaleType.FIT_CENTER
                layoutParams=LinearLayout.LayoutParams(-1,110)
                adjustViewBounds=true
            }
            val tv=TextView(ctx).apply{
                text=name
                setTextColor(if(id==sel) 0xFFFF2D95.toInt() else 0xFF0A0A0A.toInt())
                textSize=10f; letterSpacing=0.04f
                setPadding(0,8,0,0)
                gravity=android.view.Gravity.CENTER
                typeface=android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL)
            }
            card.addView(iv); card.addView(tv)
            card.setOnClickListener{
                sel=id
                MascotManager.setSelected(ctx,id)
                refreshHero()
                for(j in 0 until row.childCount){
                    val ch=row.getChildAt(j) as LinearLayout
                    ch.background=UiKit.card(ctx)
                    (ch.getChildAt(1) as TextView).setTextColor(0xFF0A0A0A.toInt())
                }
                card.background=UiKit.selected(ctx)
                tv.setTextColor(0xFFFF2D95.toInt())
            }
            row.addView(card)
        }
        scroll.addView(row)

        // Bouton test apparition
        val testBtn=Button(ctx).apply{
            text="Faire apparaître maintenant"
            textSize=12f
            background=UiKit.pill(ctx)
            setTextColor(0xFFFF2D95.toInt())
            layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=20}
            setOnClickListener{
                if(!OverlayHelper.canDraw(ctx)){
                    Toast.makeText(ctx,"Active d'abord « afficher par-dessus les apps » dans Configuration",Toast.LENGTH_LONG).show()
                    OverlayHelper.requestPermission(ctx)
                    return@setOnClickListener
                }
                val mid=MascotManager.getDrawableId(ctx,MascotManager.getSelected(ctx))
                val name=MascotManager.getDisplayName(ctx)
                OverlayHelper.showMascot(ctx,mid,"Salut, je suis $name !")
            }
        }

        root.addView(hero)
        root.addView(nameTitle)
        root.addView(nameRow)
        root.addView(nameHint)
        root.addView(styleTitle)
        root.addView(scroll)
        root.addView(testBtn)
        return root
    }
}
class ConfigFragment:Fragment(){
    private val refreshers=mutableListOf<()->Unit>()
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext(); refreshers.clear()
        val sv=ScrollView(ctx).apply{setBackgroundColor(0xFFFFFFFF.toInt())}
        val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(32,40,32,40)}

        fun sectionTitle(t:String)=TextView(ctx).apply{text=t; setTextColor(0xFF8A8A8E.toInt()); textSize=11f; letterSpacing=0.1f; setPadding(4,0,0,10)}
        fun spacer(h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,h)}

        // --- Assistant vocal ---
        col.addView(sectionTitle("ASSISTANT VOCAL"))
        val wakeRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,22,24,22); background=UiKit.card(ctx)}
        val wakeStatus=TextView(ctx).apply{text=if(WakeWordPrefs.isEnabled(ctx)) "Active" else "Inactive"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; setPadding(20,0,0,0)}
        val wakeSwitch=Switch(ctx).apply{
            isChecked=WakeWordPrefs.isEnabled(ctx)
            setOnCheckedChangeListener{ btn,checked->
                if(checked && ContextCompat.checkSelfPermission(ctx,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(ctx,"Autorise d'abord le microphone ci-dessous",Toast.LENGTH_LONG).show()
                    btn.isChecked=false; return@setOnCheckedChangeListener
                }
                WakeWordPrefs.setEnabled(ctx,checked); wakeStatus.text=if(checked) "Active" else "Inactive"
                if(checked) ContextCompat.startForegroundService(ctx,Intent(ctx,WakeWordService::class.java))
                else ctx.stopService(Intent(ctx,WakeWordService::class.java))
            }
        }
        wakeRow.addView(wakeSwitch); wakeRow.addView(wakeStatus)
        col.addView(wakeRow)
        val hintText=TextView(ctx).apply{text="Mot d'activation : dis \"Cassandra\" suivi de ta demande, par exemple \"Cassandra, ouvre calculatrice\""; setTextColor(0xFF8A8A8E.toInt()); textSize=10.5f; setPadding(6,8,6,0)}
        col.addView(hintText)
        col.addView(spacer(28))

        // --- Autorisations ---
        col.addView(sectionTitle("AUTORISATIONS"))

        fun permRow(label:String, permission:String, consequence:String):View{
            val col2=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
            val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
            val labelView=TextView(ctx).apply{text=label; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
            val statusView=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
            val manageBtn=Button(ctx).apply{
                text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
                setOnClickListener{
                    val intent=Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply{ data=Uri.fromParts("package",ctx.packageName,null) }
                    startActivity(intent)
                }
            }
            val consLabel=TextView(ctx).apply{text="Si refuse : $consequence"; setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,8,0,0)}
            fun refresh(){
                val granted=ContextCompat.checkSelfPermission(ctx,permission)==PackageManager.PERMISSION_GRANTED
                statusView.text=if(granted) "Accordee" else "Non accordee"
                statusView.setTextColor(if(granted) 0xFF16A34A.toInt() else 0xFFEF4444.toInt())
            }
            refresh(); refreshers.add(::refresh)
            row.addView(labelView); row.addView(statusView); row.addView(manageBtn)
            col2.addView(row); col2.addView(consLabel)
            return col2
        }

        col.addView(permRow("Microphone (ecoute vocale)", Manifest.permission.RECORD_AUDIO, "impossible d'utiliser les commandes vocales"))
        col.addView(spacer(2))
        col.addView(permRow("Contacts (appel par nom)", Manifest.permission.READ_CONTACTS, "impossible de trouver un contact par son nom"))
        col.addView(spacer(2))
        col.addView(permRow("Appel telephonique", Manifest.permission.CALL_PHONE, "les demandes d'appel resteront sans effet, meme apres confirmation"))
        col.addView(spacer(2))
        col.addView(permRow("Envoi de SMS", Manifest.permission.SEND_SMS, "les demandes d'envoi de message resteront sans effet, meme apres confirmation"))
        col.addView(spacer(2))
        if(Build.VERSION.SDK_INT>=33){
            col.addView(permRow("Notifications", Manifest.permission.POST_NOTIFICATIONS, "la notification d'ecoute active et les rappels de relances ne s'afficheront pas"))
            col.addView(spacer(2))
        }

        // Accessibilite (mecanisme different : reglage systeme, pas une permission classique)
        val accCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val accRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val accLabel=TextView(ctx).apply{text="Service d'accessibilite (actions systeme)"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val accStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val accBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            setOnClickListener{ startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        fun refreshAcc(){
            val exp="${ctx.packageName}/${VanelleAccessibilityService::class.java.canonicalName}"
            val en=Settings.Secure.getString(ctx.contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            var granted=false
            if(en!=null){ val split=TextUtils.SimpleStringSplitter(':'); split.setString(en); while(split.hasNext()){ if(split.next().equals(exp,true)){ granted=true; break } } }
            accStatus.text=if(granted) "Accordee" else "Non accordee"
            accStatus.setTextColor(if(granted) 0xFF16A34A.toInt() else 0xFFEF4444.toInt())
        }
        refreshAcc(); refreshers.add(::refreshAcc)
        accRow.addView(accLabel); accRow.addView(accStatus); accRow.addView(accBtn)
        val accCons=TextView(ctx).apply{text="Si refuse : les commandes retour/accueil/notifications/recents ne fonctionneront pas"; setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,8,0,0)}
        accCol.addView(accRow); accCol.addView(accCons)
        col.addView(accCol); col.addView(spacer(2))

        // Alarmes exactes (necessaire pour l'onglet Relances)
        val alarmCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val alarmRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val alarmLabel=TextView(ctx).apply{text="Alarmes exactes (relances a l'heure precise)"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val alarmStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val alarmBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            setOnClickListener{ if(Build.VERSION.SDK_INT>=31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:${ctx.packageName}"))) }
        }
        fun refreshAlarm(){
            val granted=AlarmScheduler.canScheduleExact(ctx)
            alarmStatus.text=if(granted) "Accordee" else "Non accordee"
            alarmStatus.setTextColor(if(granted) 0xFF16A34A.toInt() else 0xFFEF4444.toInt())
        }
        refreshAlarm(); refreshers.add(::refreshAlarm)
        alarmRow.addView(alarmLabel); alarmRow.addView(alarmStatus); alarmRow.addView(alarmBtn)
        val alarmCons=TextView(ctx).apply{text="Si refuse : les relances programmees peuvent se declencher en retard, plus jamais a l'heure exacte"; setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,8,0,0)}
        alarmCol.addView(alarmRow); alarmCol.addView(alarmCons)
        col.addView(alarmCol); col.addView(spacer(2))

        // Affichage par-dessus les autres apps (mascotte sur l'ecran principal)
        val overlayCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val overlayRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val overlayLabel=TextView(ctx).apply{text="Affichage sur l'ecran principal"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val overlayStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val overlayBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            setOnClickListener{ OverlayHelper.requestPermission(ctx) }
        }
        fun refreshOverlay(){
            val granted=OverlayHelper.canDraw(ctx)
            overlayStatus.text=if(granted) "Accordee" else "Non accordee"
            overlayStatus.setTextColor(if(granted) 0xFF16A34A.toInt() else 0xFFEF4444.toInt())
        }
        refreshOverlay(); refreshers.add(::refreshOverlay)
        overlayRow.addView(overlayLabel); overlayRow.addView(overlayStatus); overlayRow.addView(overlayBtn)
        val overlayCons=TextView(ctx).apply{text="Si refuse : la mascotte repond seulement dans une fenetre de l'app, pas par-dessus ton ecran habituel"; setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,8,0,0)}
        overlayCol.addView(overlayRow); overlayCol.addView(overlayCons)
        col.addView(overlayCol); col.addView(spacer(28))

        // --- Données de l'application (téléchargement avec barre de progression) ---
        col.addView(sectionTitle("DONNÉES DE L'APPLICATION"))
        val aiCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val aiRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val aiLabel=TextView(ctx).apply{textSize=13f; setTextColor(0xFF0A0A0A.toInt()); layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val aiBtn=Button(ctx).apply{ text="Mettre à jour"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt()) }
        val aiProgress=android.widget.ProgressBar(ctx,null,android.R.attr.progressBarStyleHorizontal).apply{
            max=100; progress=0; visibility=View.GONE; isIndeterminate=false
            layoutParams=LinearLayout.LayoutParams(-1, (8*resources.displayMetrics.density).toInt()).apply{ topMargin=16 }
            if(android.os.Build.VERSION.SDK_INT>=21){
                progressTintList=android.content.res.ColorStateList.valueOf(0xFFFF2D95.toInt())
                progressBackgroundTintList=android.content.res.ColorStateList.valueOf(0x33FF2D95)
            }
        }
        val aiPct=TextView(ctx).apply{
            textSize=11f; setTextColor(0xFF8A8A8E.toInt()); visibility=View.GONE
            setPadding(0,8,0,0)
        }
        fun refreshAi(){
            val ready=LlamaModelManager.isReady(ctx)
            aiLabel.text=if(ready) "Données prêtes" else "Mise à jour des données requise (Wi-Fi recommandé, ~800 Mo)"
            aiBtn.isEnabled=!ready
            aiBtn.text=if(ready) "À jour" else "Mettre à jour"
            if(ready){
                aiProgress.visibility=View.GONE
                aiPct.visibility=View.GONE
            }
        }
        aiBtn.setOnClickListener{
            if(!LlamaModelManager.isOnWifi(ctx)){
                Toast.makeText(ctx,"Connecte-toi en Wi-Fi pour mettre à jour les données",Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            aiBtn.isEnabled=false
            aiBtn.text="..."
            aiProgress.visibility=View.VISIBLE
            aiProgress.progress=0
            aiPct.visibility=View.VISIBLE
            aiPct.text="0 % — mise à jour en cours..."
            // Service foreground = continue si on quitte l'app + reprise réseau
            DataDownloadService.start(ctx)
            DataDownloadScreen.maybeShow(requireActivity())
            Toast.makeText(ctx,"Téléchargement démarré (continue en arrière-plan)",Toast.LENGTH_SHORT).show()
            // L'UI se met à jour via le service ; on rafraîchit périodiquement
            lifecycleScope.launch{
                while(isAdded && !LlamaModelManager.isReady(ctx)){
                    kotlinx.coroutines.delay(1500)
                    val part=LlamaModelManager.partialBytes(ctx)
                    if(part>0){
                        val pct=((part*100)/LlamaModelManager.EXPECTED_MIN_BYTES).toInt().coerceIn(0,99)
                        aiProgress.visibility=View.VISIBLE
                        aiPct.visibility=View.VISIBLE
                        aiProgress.progress=pct
                        aiPct.text="$pct % — en cours..."
                        aiBtn.text="$pct %"
                    }
                    if(!DataDownloadService.isRunning && !LlamaModelManager.isReady(ctx)){
                        // relance si le service s'est arrêté prématurément
                        DataDownloadService.start(ctx)
                    }
                }
                refreshAi()
                Toast.makeText(ctx,"Données prêtes",Toast.LENGTH_SHORT).show()
            }
        }
        refreshAi(); refreshers.add(::refreshAi)
        aiRow.addView(aiLabel); aiRow.addView(aiBtn)
        aiCol.addView(aiRow)
        aiCol.addView(aiProgress)
        aiCol.addView(aiPct)
        val aiCons=TextView(ctx).apply{text="Les données avancées améliorent les réponses. Sans elles, une recherche web gratuite est utilisée."; setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,8,0,0)}
        aiCol.addView(aiCons)
        col.addView(aiCol); col.addView(spacer(28))

        // --- Mot d'activation acoustique (openWakeWord) ---
        col.addView(sectionTitle("MOT D'ACTIVATION"))
        val wwCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val wwLabel=TextView(ctx).apply{textSize=13f; setTextColor(0xFF0A0A0A.toInt())}
        fun refreshWw(){
            wwLabel.text=if(WakeWordModelManager.isReady(ctx)) "Détection acoustique active (écoute silencieuse de « Cassandra »)" else "Préparation de la détection en cours (automatique)..."
        }
        refreshWw(); refreshers.add(::refreshWw)
        wwCol.addView(wwLabel)
        col.addView(wwCol); col.addView(spacer(28))

        // --- Mode traduction (activation vocale uniquement, statut affiche ici) ---
        col.addView(sectionTitle("MODE TRADUCTION"))
        val trRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,20,24,20); background=UiKit.card(ctx)}
        val trActive=TranslateModePrefs.isActive(ctx)
        val trLabel=TextView(ctx).apply{
            text=if(trActive) "Actif : ${TranslateModePrefs.source(ctx)} vers ${TranslateModePrefs.target(ctx)}" else "Dis : Cassandra mode traduction de telle langue vers telle langue"
            setTextColor(0xFF0A0A0A.toInt()); textSize=12f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)
        }
        val trStatus=TextView(ctx).apply{text=if(trActive) "Actif" else "Inactif"; textSize=11f; setTextColor(if(trActive) 0xFF16A34A.toInt() else 0xFF8A8A8E.toInt())}
        trRow.addView(trLabel); trRow.addView(trStatus)
        col.addView(trRow); col.addView(spacer(28))
        refreshers.add{
            val active=TranslateModePrefs.isActive(ctx)
            trLabel.text=if(active) "Actif : ${TranslateModePrefs.source(ctx)} vers ${TranslateModePrefs.target(ctx)}" else "Dis : Cassandra mode traduction de telle langue vers telle langue"
            trStatus.text=if(active) "Actif" else "Inactif"
            trStatus.setTextColor(if(active) 0xFF16A34A.toInt() else 0xFF8A8A8E.toInt())
        }

        // --- Memoire ---
        col.addView(sectionTitle("MEMOIRE"))
        val clearRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,20,24,20); background=UiKit.card(ctx)}
        val clearLabel=TextView(ctx).apply{text="Effacer tous les souvenirs enregistres"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val clearBtn=Button(ctx).apply{
            text="Effacer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFEF4444.toInt())
            setOnClickListener{
                AlertDialog.Builder(ctx).setTitle("Effacer la memoire")
                    .setMessage("Cette action supprime definitivement tous les souvenirs enregistres. Continuer ?")
                    .setPositiveButton("Effacer"){_,_-> MemoryVault(ctx).clear(); Toast.makeText(ctx,"Memoire effacee",Toast.LENGTH_SHORT).show() }
                    .setNegativeButton("Annuler",null).show()
            }
        }
        clearRow.addView(clearLabel); clearRow.addView(clearBtn)
        col.addView(clearRow); col.addView(spacer(28))

        // --- Legal ---
        col.addView(sectionTitle("LEGAL"))
        val legalCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        fun showLegal(title:String, body:String){
            val tv=TextView(ctx).apply{
                text=body; setTextColor(0xFF0A0A0A.toInt()); textSize=12f
                setPadding(24,16,24,16); setTextIsSelectable(true)
            }
            val scr=ScrollView(ctx).apply{addView(tv)}
            AlertDialog.Builder(ctx).setTitle(title).setView(scr).setPositiveButton("Fermer",null).show()
        }
        val privacyBtn=Button(ctx).apply{
            text="Politique de confidentialite"; textSize=12f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            setOnClickListener{ showLegal(LegalTexts.PRIVACY_TITLE, LegalTexts.PRIVACY) }
        }
        val termsBtn=Button(ctx).apply{
            text="Conditions d'utilisation"; textSize=12f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=12}
            setOnClickListener{ showLegal(LegalTexts.TERMS_TITLE, LegalTexts.TERMS) }
        }
        legalCol.addView(privacyBtn); legalCol.addView(termsBtn)
        col.addView(legalCol); col.addView(spacer(28))

        // --- Journal de plantage ---
        val lastCrash=CrashLogger.readLast(ctx)
        if(lastCrash!=null){
            col.addView(sectionTitle("DERNIER PLANTAGE DETECTE"))
            val crashRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,20,24,20); background=UiKit.card(ctx)}
            val crashLabel=TextView(ctx).apply{text="Un rapport est disponible"; setTextColor(0xFFEF4444.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
            val viewBtn=Button(ctx).apply{
                text="Voir"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
                setOnClickListener{
                    val tv=TextView(ctx).apply{text=lastCrash; setTextColor(0xFF0A0A0A.toInt()); textSize=10f; setPadding(20,20,20,20); setTextIsSelectable(true)}
                    val scr=ScrollView(ctx).apply{addView(tv)}
                    AlertDialog.Builder(ctx).setTitle("Rapport de plantage").setView(scr)
                        .setPositiveButton("Fermer",null)
                        .setNegativeButton("Effacer"){_,_-> CrashLogger.clear(ctx); Toast.makeText(ctx,"Journal efface",Toast.LENGTH_SHORT).show() }
                        .show()
                }
            }
            crashRow.addView(crashLabel); crashRow.addView(viewBtn)
            col.addView(crashRow)
        }

        // --- Légal ---
        col.addView(spacer(28))
        
        // --- Expérience & confiance ---
        col.addView(sectionTitle("PERSONNALITÉ"))
        val persCol = LinearLayout(ctx).apply{ orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx) }
        val persLabel = TextView(ctx).apply{
            text = "Style : ${PersonalityPrefs.personalityLabel(PersonalityPrefs.getPersonality(ctx))}"
            setTextColor(0xFF0A0A0A.toInt()); textSize=13f
        }
        val persRow = LinearLayout(ctx).apply{ orientation=LinearLayout.HORIZONTAL }
        for((id,label) in listOf("pote" to "Pote","calme" to "Calme","energique" to "Énergie","coach" to "Coach")){
            val b = Button(ctx).apply{
                text=label; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
                setOnClickListener{
                    PersonalityPrefs.setPersonality(ctx,id)
                    persLabel.text="Style : ${PersonalityPrefs.personalityLabel(id)}"
                    Toast.makeText(ctx,"Personnalité : $label",Toast.LENGTH_SHORT).show()
                }
            }
            persRow.addView(b)
        }
        persCol.addView(persLabel); persCol.addView(persRow)
        col.addView(persCol); col.addView(spacer(20))

        col.addView(sectionTitle("CONFIDENTIALITÉ & CONTRÔLE"))
        val trustCol = LinearLayout(ctx).apply{ orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx) }
        val guestRow = LinearLayout(ctx).apply{ orientation=LinearLayout.HORIZONTAL }
        val guestLabel = TextView(ctx).apply{
            text="Mode invité (ne rien mémoriser)"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f
            layoutParams=LinearLayout.LayoutParams(0,-2,1f)
        }
        val guestSw = Switch(ctx).apply{
            isChecked=PersonalityPrefs.isGuestMode(ctx)
            setOnCheckedChangeListener{ _, checked ->
                PersonalityPrefs.setGuestMode(ctx, checked)
                Toast.makeText(ctx, if(checked) "Mode invité ON" else "Mode invité OFF", Toast.LENGTH_SHORT).show()
            }
        }
        guestRow.addView(guestLabel); guestRow.addView(guestSw)
        trustCol.addView(guestRow)

        val offRow = LinearLayout(ctx).apply{ orientation=LinearLayout.HORIZONTAL; setPadding(0,12,0,0) }
        val offLabel = TextView(ctx).apply{
            text="Préférer le hors-ligne"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f
            layoutParams=LinearLayout.LayoutParams(0,-2,1f)
        }
        val offSw = Switch(ctx).apply{
            isChecked=PersonalityPrefs.preferOffline(ctx)
            setOnCheckedChangeListener{ _, checked -> PersonalityPrefs.setPreferOffline(ctx, checked) }
        }
        offRow.addView(offLabel); offRow.addView(offSw)
        trustCol.addView(offRow)

        val logBtn = Button(ctx).apply{
            text="Voir le journal d'activité"; textSize=12f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            layoutParams=LinearLayout.LayoutParams(-1,-2).apply{ topMargin=12 }
            setOnClickListener{
                val lines = ActivityLog.all(ctx).take(15)
                val msg = if(lines.isEmpty()) "Aucune activité pour l'instant."
                else lines.joinToString("\n"){ ActivityLog.formatLine(it.first,it.second,it.third) }
                AlertDialog.Builder(ctx).setTitle("Journal").setMessage(msg).setPositiveButton("OK",null)
                    .setNeutralButton("Effacer"){ _,_ -> ActivityLog.clear(ctx); Toast.makeText(ctx,"Journal effacé",Toast.LENGTH_SHORT).show() }
                    .show()
            }
        }
        val clearMemBtn = Button(ctx).apply{
            text="Effacer toute la mémoire"; textSize=12f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            layoutParams=LinearLayout.LayoutParams(-1,-2).apply{ topMargin=8 }
            setOnClickListener{
                AlertDialog.Builder(ctx).setTitle("Effacer la mémoire ?")
                    .setMessage("Profil, faits et notes seront supprimés.")
                    .setPositiveButton("Effacer"){ _,_ ->
                        MemoryVault(ctx).clear()
                        Toast.makeText(ctx,"Mémoire effacée",Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Annuler",null).show()
            }
        }
        trustCol.addView(logBtn); trustCol.addView(clearMemBtn)
        col.addView(trustCol); col.addView(spacer(20))

        col.addView(sectionTitle("ROUTINES"))
        val rouCol = LinearLayout(ctx).apply{ orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx) }
        val rouTxt = TextView(ctx).apply{
            text=RoutineManager.describe(ctx); setTextColor(0xFF0A0A0A.toInt()); textSize=12f
        }
        val rouBtn = Button(ctx).apply{
            text="Activer briefing matin 7h30"; textSize=12f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            layoutParams=LinearLayout.LayoutParams(-1,-2).apply{ topMargin=10 }
            setOnClickListener{
                RoutineManager.ensureDefaultMorning(ctx)
                rouTxt.text=RoutineManager.describe(ctx)
                Toast.makeText(ctx,"Routine matin activée",Toast.LENGTH_SHORT).show()
            }
        }
        rouCol.addView(rouTxt); rouCol.addView(rouBtn)
        col.addView(rouCol); col.addView(spacer(20))

        col.addView(sectionTitle("LÉGAL"))
        fun openLegalAsset(title:String, assetFile:String){
            try{
                val html = ctx.assets.open(assetFile).bufferedReader().use{ it.readText() }
                val wv = WebView(ctx).apply{
                    settings.javaScriptEnabled = false
                    settings.loadWithOverviewMode = true
                    settings.useWideViewPort = true
                    loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                }
                val pad = (12 * resources.displayMetrics.density).toInt()
                val container = FrameLayout(ctx).apply{
                    setPadding(pad, pad, pad, pad)
                    addView(wv, FrameLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.65f).toInt()))
                }
                AlertDialog.Builder(ctx)
                    .setTitle(title)
                    .setView(container)
                    .setPositiveButton("Fermer", null)
                    .show()
            }catch(e:Exception){
                Toast.makeText(ctx, "Document indisponible", Toast.LENGTH_SHORT).show()
            }
        }
        val legalCol = LinearLayout(ctx).apply{
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            background = UiKit.card(ctx)
        }
        val privacyBtn = Button(ctx).apply{
            text = "Politique de confidentialité"
            textSize = 12f
            background = UiKit.pill(ctx)
            setTextColor(0xFFFF2D95.toInt())
            setOnClickListener{ openLegalAsset("Politique de confidentialité", "privacy_policy.html") }
        }
        val termsBtn = Button(ctx).apply{
            text = "Conditions d'utilisation"
            textSize = 12f
            background = UiKit.pill(ctx)
            setTextColor(0xFFFF2D95.toInt())
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply{ topMargin = 10 }
            setOnClickListener{ openLegalAsset("Conditions d'utilisation", "terms_of_use.html") }
        }
        legalCol.addView(privacyBtn)
        legalCol.addView(termsBtn)
        col.addView(legalCol)
        col.addView(spacer(20))

        sv.addView(col); return sv
    }
    override fun onResume(){ super.onResume(); refreshers.forEach{ it() } }
}
class FeaturesFragment:Fragment(){
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val sv=ScrollView(ctx).apply{setBackgroundColor(0xFFFFFFFF.toInt())}
        val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(28,32,28,32)}
        fun spacer(h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,h)}
        val items=listOf(
            Triple("Ouvrir une application","Cassandra, ouvre Spotify","La musique s'ouvre directement, sans que tu aies a chercher l'icone."),
            Triple("Appeler un contact","Cassandra, appelle Paul","Une fenetre de confirmation apparait avant l'appel reel, pour eviter les erreurs de reconnaissance vocale."),
            Triple("Envoyer un message","Cassandra, envoie un message a Paul texte j'arrive dans 10 minutes","Meme principe : confirmation affichee, puis le SMS part reellement une fois validee."),
            Triple("Recherche web","Cassandra, cherche recette de tiramisu","Google s'ouvre avec les resultats de la recherche."),
            Triple("YouTube","Cassandra, YouTube dernier clip de Stromae","YouTube s'ouvre avec la recherche correspondante."),
            Triple("Traduction rapide","Cassandra, traduis bonjour comment vas-tu","La traduction en francais est prononcee et affichee immediatement, sans ouvrir de navigateur."),
            Triple("Mode traduction en direct","Cassandra, mode traduction de l'anglais vers le francais","Des lors, chaque phrase captee est traduite et prononcee automatiquement, sans redire Cassandra a chaque fois, jusqu'a Cassandra quitte mode traduction."),
            Triple("Memoire personnelle","Cassandra, retiens que mon code wifi est 1234, puis plus tard : Vanelle, rappelle-moi mon code wifi","L'information est stockee de facon chiffree, puis retrouvee sur simple demande."),
            Triple("Urgence","Cassandra, urgence","L'ecran d'appel au 112 s'ouvre immediatement, sans confirmation ni delai."),
            Triple("Telephone perdu","Cassandra, retrouve mon telephone","Une alarme sonore et vibrante se declenche, meme si le telephone est en silencieux."),
            Triple("Navigation","Cassandra, navigue vers la Tour Eiffel","Maps s'ouvre avec l'itineraire pret a suivre."),
            Triple("Calculatrice","Cassandra, calculatrice","L'application calculatrice du telephone s'ouvre directement."),
            Triple("Batterie","Cassandra, batterie","Cassandra repond a voix haute, par exemple : Batterie 67 pourcent."),
            Triple("Relance programmee","Cassandra, tu dois appeler Paul a 12 heures  (formulation libre, pas besoin de dire exactement programme)","Une alarme reelle est creee et visible dans l'onglet Relances ; a l'heure dite, l'action se declenche seule, sans demander de confirmation."),
            Triple("Retour / Accueil","Cassandra, retour  ou  Vanelle, accueil","Simule le bouton retour ou accueil d'Android (necessite le service d'accessibilite active dans Configuration)."),
            Triple("Lire l'ecran","Cassandra, lis l'ecran","Cassandra lit le texte actuellement affiche a l'ecran (necessite le service d'accessibilite)."),
            Triple("Cliquer sur l'ecran","Cassandra, clique sur Valider","Cassandra cherche un bouton ou un texte correspondant a l'ecran et appuie dessus (necessite le service d'accessibilite)."),
            Triple("Resume d'ecran","Cassandra, resume l'ecran","Le texte visible est lu puis resume (accessibilite requise)."),
            Triple("Copilote ecran","Cassandra, remplis avec mon adresse 12 rue de Paris","Saisit le texte dans le champ actif a l'ecran (accessibilite requise)."),
            Triple("Memoire relationnelle","Cassandra, je m'appelle Alex / Cassandra, retiens que je prepare un examen","Profil et faits memorises pour des reponses plus humaines."),
            Triple("Personnalite","Cassandra, sois coach","Change le ton : calme, energique, coach ou pote."),
            Triple("Mode invite","Cassandra, mode invite","N'enregistre aucun souvenir pendant la session."),
            Triple("Journal","Cassandra, journal d'activite","Recapitulatif de ce que Vanelle a fait recemment."),
            Triple("Routines","Cassandra, programme une routine chaque matin a 7 heures 30","Declenche un briefing recurrent."),
            Triple("Camera","Cassandra, ouvre la camera","Ouvre l'appareil photo pour une capture."),
            Triple("Actions enchainees","Cassandra, ouvre Spotify et cherche restaurant italien et appelle Paul","Chaque action reconnue est executee dans l'ordre. Limite honnete : seules les actions que Cassandra sait deja faire peuvent etre enchainees ; elle ne reserve pas de billets ni ne commande de VTC, aucune app tierce ne le permet sans compte/API payante.")
        )
        for((name,example,result) in items){
            val card=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(22,20,22,20); background=UiKit.card(ctx)}
            val title=TextView(ctx).apply{text=name; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; typeface=android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL)}
            val ex=TextView(ctx).apply{text="Exemple : \u00ab $example \u00bb"; setTextColor(0xFFFF2D95.toInt()); textSize=11.5f; setPadding(0,8,0,4)}
            val res=TextView(ctx).apply{text=result; setTextColor(0xFF6B6B70.toInt()); textSize=11f}
            card.addView(title); card.addView(ex); card.addView(res)
            col.addView(card); col.addView(spacer(10))
        }
        sv.addView(col); return sv
    }
}
class RelanceFragment:Fragment(){
    private val fmt=java.text.SimpleDateFormat("dd/MM HH:mm",java.util.Locale.FRANCE)
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val sv=ScrollView(ctx).apply{setBackgroundColor(0xFFFFFFFF.toInt())}
        val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(32,40,32,40)}
        fun sectionTitle(t:String)=TextView(ctx).apply{text=t; setTextColor(0xFF8A8A8E.toInt()); textSize=11f; letterSpacing=0.1f; setPadding(4,0,0,10)}
        fun spacer(h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,h)}
        val repo=RelanceRepository(ctx)

        col.addView(sectionTitle("A VENIR"))
        val tasks=repo.getTasks()
        if(tasks.isEmpty()) col.addView(TextView(ctx).apply{text="Aucune relance programmee. Dis : Vanelle programme <action> a <heure>h<minutes>"; setTextColor(0xFF6B6B70.toInt()); textSize=12f; setPadding(24,16,24,16)})
        for(task in tasks){
            val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
            val label=TextView(ctx).apply{
                text="${task.description}\n${task.hour.toString().padStart(2,'0')}h${task.minute.toString().padStart(2,'0')}${if(task.repeatDaily) " - tous les jours" else " - une fois"}"
                setTextColor(0xFF0A0A0A.toInt()); textSize=12f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)
            }
            val delBtn=Button(ctx).apply{
                text="Supprimer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFEF4444.toInt())
                setOnClickListener{
                    AlarmScheduler.cancel(ctx,task.id); repo.removeTask(task.id)
                    parentFragmentManager.beginTransaction().detach(this@RelanceFragment).attach(this@RelanceFragment).commit()
                }
            }
            row.addView(label); row.addView(delBtn)
            col.addView(row); col.addView(spacer(2))
        }
        col.addView(spacer(28))

        col.addView(sectionTitle("HISTORIQUE"))
        val history=repo.getHistory()
        if(history.isEmpty()) col.addView(TextView(ctx).apply{text="Aucune relance executee pour le moment."; setTextColor(0xFF6B6B70.toInt()); textSize=12f; setPadding(24,16,24,16)})
        for(h in history.take(30)){
            val row=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,16,24,16); background=UiKit.card(ctx)}
            val labelTop=TextView(ctx).apply{text=h.description; setTextColor(0xFF0A0A0A.toInt()); textSize=12f}
            val labelBottom=TextView(ctx).apply{text="${fmt.format(java.util.Date(h.executedAt))} - ${h.result}"; setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,4,0,0)}
            row.addView(labelTop); row.addView(labelBottom)
            col.addView(row); col.addView(spacer(2))
        }
        sv.addView(col); return sv
    }
}
