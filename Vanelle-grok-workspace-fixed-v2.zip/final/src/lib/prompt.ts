import type { AI } from "./types";

export function buildSystemPrompt(ai: AI): string {
  const teaching = ai.training.map((t) => `- [${t.category}] ${t.question} → ${t.answer}`).join("\n");
  const documents = ai.files
    .map((f) => `[${f.name}]\n${f.note.slice(0, 1200)}`)
    .join("\n\n");
  const traitsList = (ai.traits ?? []).map((t) => t.trim()).filter(Boolean);
  const traitsLine = traitsList.length
    ? `Traits de personnalité à incarner : ${traitsList.join(", ")}.`
    : "";

  const linked = ai.apis
    .filter((a) => (a.linkedTraits ?? []).length > 0)
    .map((a) => {
      const labels = (a.linkedTraits ?? [])
        .map((i) => ai.traits[i]?.trim())
        .filter(Boolean);
      return `- ${a.name} liée aux traits : ${labels.join(", ") || a.linkedTraits?.join(", ")}`;
    });

  const fallbackRule =
    "Si une question porte sur un sujet que tu n'as pas appris (absent des " +
    "notions et documents ci-dessous) et qui n'est pas une connaissance " +
    "générale fiable, dis-le clairement — par exemple « Je n'ai pas encore " +
    "appris ça, vous pouvez me l'enseigner depuis l'onglet Apprentissage » — " +
    "plutôt que d'inventer une réponse.";

  return [
    `Tu es ${ai.name}, une IA créée dans Vanelle Atelier.`,
    ai.description ? `Rôle : ${ai.description}` : "",
    ai.style ? `Style : ${ai.style}` : "",
    traitsLine,
    linked.length ? `APIs rattachées aux traits :\n${linked.join("\n")}` : "",
    ai.systemPrompt,
    fallbackRule,
    "Réponds dans la langue de l'utilisateur, de préférence en français si le message l'est.",
    "N'invente jamais de données d'API. N'affiche jamais de clés, tokens ou secrets.",
    teaching ? `Notions apprises :\n${teaching}` : "Notions apprises : aucune pour l'instant.",
    documents ? `Documents fournis :\n${documents}` : "",
  ]
    .filter(Boolean)
    .join("\n\n");
}

export type ApiToolDef = {
  id: string;
  name: string;
  description: string;
  protocol: string;
  method: string;
  endpoint: string;
  authentication: string;
};

export function listApisForTools(ai: AI): ApiToolDef[] {
  return ai.apis.map((api) => ({
    id: api.id,
    name: api.name,
    description: api.description,
    protocol: api.protocol ?? "rest",
    method: api.method,
    endpoint: api.endpoint,
    authentication: api.authType || "none",
  }));
}
