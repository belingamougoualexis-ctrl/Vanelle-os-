type EmbeddingResponse = { data?: Array<{ embedding?: number[] }> };

let cachedModel: string | null = null;

async function findEmbeddingModel(apiKey: string): Promise<string> {
  if (cachedModel) return cachedModel;
  const res = await fetch("https://api.x.ai/v1/models", {
    headers: { Authorization: `Bearer ${apiKey}` },
  });
  if (!res.ok) throw new Error(`Impossible de lister les modèles xAI (${res.status}).`);
  const body = (await res.json()) as { data?: Array<{ id?: string; type?: string }> };
  const candidates = (body.data ?? []).map((m) => m.id).filter((id): id is string => !!id);
  const configured = process.env.XAI_EMBEDDING_MODEL?.trim();
  if (configured && candidates.includes(configured)) return (cachedModel = configured);
  const found = candidates.find((id) => /embed/i.test(id));
  if (!found) throw new Error("Aucun modèle d'embedding xAI n'est disponible pour cette clé API.");
  return (cachedModel = found);
}

export async function embedTexts(texts: string[]): Promise<number[][]> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) throw new Error("XAI_API_KEY manquante.");
  if (!texts.length) return [];
  const model = await findEmbeddingModel(apiKey);
  const res = await fetch("https://api.x.ai/v1/embeddings", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model, input: texts }),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`xAI embeddings error ${res.status}${text ? `: ${text.slice(0, 240)}` : ""}`);
  }
  const body = (await res.json()) as EmbeddingResponse;
  const vectors = (body.data ?? []).map((x) => x.embedding);
  if (vectors.length !== texts.length || vectors.some((v) => !v?.length)) {
    throw new Error("Réponse d'embedding xAI incomplète.");
  }
  return vectors as number[][];
}

function cosine(a: number[], b: number[]) {
  let dot = 0, aa = 0, bb = 0;
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) { dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i]; }
  return aa && bb ? dot / (Math.sqrt(aa) * Math.sqrt(bb)) : 0;
}

export async function semanticContext(query: string, documents: Array<{ name: string; note: string }>, topK = 4) {
  const usable = documents.filter((d) => d.note?.trim()).slice(0, 32);
  if (!usable.length || !query.trim()) return "";
  const vectors = await embedTexts([query, ...usable.map((d) => `${d.name}\n${d.note.slice(0, 8000)}`)]);
  const q = vectors[0];
  return usable
    .map((d, i) => ({ d, score: cosine(q, vectors[i + 1]) }))
    .sort((a, b) => b.score - a.score)
    .slice(0, topK)
    .filter((x) => x.score > 0)
    .map((x) => `[${x.d.name}]\n${x.d.note.slice(0, 3000)}`)
    .join("\n\n");
}
