import { useEffect, useRef, useState } from "react";
import { downloadBlob, ingestFiles } from "@/lib/files";
import JSZip from "jszip";
import type { ChatEvent } from "@/lib/chat-events";
import { useVanelleStore } from "@/lib/store";
import type { AI, Message, UserApi, VFile } from "@/lib/types";
import { fmtSize, makeId } from "@/lib/utils";
import { Menu, Paperclip, SendHorizontal, X } from "lucide-react";
import { toast } from "sonner";
import { ApiEditor } from "./api-editor";
import { Btn, ErrorBanner, Field, Muted } from "./ui";

type MenuPanel = "main" | "knowledge" | "info" | "apis" | "addApi";

export function ChatView({
  ai,
  back,
  onSave,
}: {
  ai: AI;
  back: () => void;
  onSave: (next: AI) => void;
}) {
  const chats = useVanelleStore((s) => s.chats);
  const saveChat = useVanelleStore((s) => s.saveChat);
  const secrets = useVanelleStore((s) => s.secrets);
  const attachApi = useVanelleStore((s) => s.attachApi);
  const [messages, setMessages] = useState<Message[]>(() => chats[ai.id] ?? []);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [menuPanel, setMenuPanel] = useState<MenuPanel>("main");
  const listRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    setMessages(chats[ai.id] ?? []);
  }, [ai.id, chats]);

  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, busy, status]);

  const closeMenu = () => {
    setMenuOpen(false);
    setMenuPanel("main");
  };

  const persist = (next: Message[]) => {
    setMessages(next);
    saveChat(ai.id, next);
  };

  const pickFiles = async (list: FileList | null) => {
    if (!list?.length) return;
    setError("");
    try {
      const { added, errors } = await ingestFiles(list);
      if (errors.length) setError(errors.join(" "));
      if (added.length) {
        onSave({ ...ai, files: [...ai.files, ...added] });
        setStatus(
          `${added.length} fichier(s) ajouté(s) aux connaissances. L'ancien contenu est conservé.`,
        );
        toast.success("Connaissances mises à jour");
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "L'ajout du fichier a échoué.");
    }
  };

  const send = async (opts?: {
    extraUser?: string;
    confirmed?: {
      apiId: string;
      method?: string;
      query?: Record<string, string>;
      body?: unknown;
    };
  }) => {
    const text = (opts?.extraUser ?? draft).trim();
    if ((!text && !opts?.confirmed) || busy) return;

    const next = [...messages];
    if (text) {
      const userMsg: Message = { id: makeId(), role: "user", text, ts: Date.now() };
      next.push(userMsg);
    }
    persist(next);
    setDraft("");
    setBusy(true);
    setError("");
    setStatus("Génération en cours…");

    const controller = new AbortController();
    abortRef.current = controller;
    const botId = makeId();
    let botText = "";

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ai: { ...ai, files: ai.files.map(({ dataUrl: _d, ...f }) => f) },
          messages: next.map(({ pendingConfirm: _p, ...m }) => m),
          secrets,
          confirmed: opts?.confirmed,
        }),
        signal: controller.signal,
      });
      if (!res.ok || !res.body) {
        const t = await res.text().catch(() => "");
        throw new Error(t || `Erreur ${res.status}`);
      }
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      let pending: Message["pendingConfirm"];
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        const parts = buf.split("\n\n");
        buf = parts.pop() ?? "";
        for (const part of parts) {
          const line = part.split("\n").find((l) => l.startsWith("data: "));
          if (!line) continue;
          let event: ChatEvent;
          try {
            event = JSON.parse(line.slice(6)) as ChatEvent;
          } catch {
            continue;
          }
          if (event.type === "delta") {
            botText += event.text;
            setStatus("");
            setMessages([
              ...next,
              { id: botId, role: "assistant", text: botText, ts: Date.now(), pendingConfirm: pending },
            ]);
          } else if (event.type === "tool") {
            setStatus(`API « ${event.name} » ${event.ok ? "OK" : "échec"}…`);
          } else if (event.type === "confirm") {
            pending = {
              apiId: event.apiId,
              apiName: event.apiName,
              method: event.method,
              query: event.query,
              body: event.body,
            };
          } else if (event.type === "error") {
            setError(event.message);
            setStatus("");
          }
        }
      }
      const all = [
        ...next,
        {
          id: botId,
          role: "assistant" as const,
          text: botText.trim() || (error ? "" : "Réponse vide."),
          ts: Date.now(),
          pendingConfirm: pending,
        },
      ].filter((m) => m.role !== "assistant" || m.text || m.pendingConfirm);
      persist(all);
      setStatus("");
    } catch (e) {
      if ((e as { name?: string }).name === "AbortError") {
        setStatus("");
        return;
      }
      const reason = e instanceof Error ? e.message : "Échec du moteur IA.";
      setError(
        /timeout|timed out|deadline/i.test(reason)
          ? "Le modèle met plus de temps que prévu. Réessayez : le moteur reste actif."
          : reason,
      );
      setStatus("");
    } finally {
      setBusy(false);
      abortRef.current = null;
    }
  };

  const exportChat = async () => {
    const zip = new JSZip();
    zip.file("manifest.json", JSON.stringify({ app: "Vanelle", type: "chat", version: 2, exportedAt: new Date().toISOString() }, null, 2));
    zip.file("ai.json", JSON.stringify({ id: ai.id, name: ai.name }, null, 2));
    zip.file("messages.json", JSON.stringify(messages, null, 2));
    const blob = await zip.generateAsync({ type: "blob" });
    const fileName = `vanelle-chat-${ai.name.replace(/\s+/g, "-").toLowerCase()}-${Date.now()}.zip`;
    downloadBlob(fileName, blob);
    toast.success("Chat exporté en ZIP");
    closeMenu();
  };

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col bg-bg">
      <header className="bg-header px-4 py-3.5 text-white">
        <div className="flex items-center justify-between gap-3">
          <button type="button" className="min-h-10 font-extrabold" onClick={back}>
            ‹ Retour
          </button>
          <p className="truncate font-display text-[15px] font-extrabold tracking-wide">{ai.name}</p>
          <button
            type="button"
            className="flex size-10 items-center justify-center"
            aria-label="Menu du chat"
            onClick={() => {
              setMenuPanel("main");
              setMenuOpen(true);
            }}
          >
            <Menu className="size-5" strokeWidth={2.4} />
          </button>
        </div>
      </header>

      {(error || status) && (
        <div className="bg-bg px-3 pt-2">
          {error ? <ErrorBanner message={error} onDismiss={() => setError("")} /> : null}
          {status && !error ? <p className="mb-1.5 text-[13px] text-muted">{status}</p> : null}
        </div>
      )}

      <div ref={listRef} className="vanelle-scroll min-h-0 flex-1 overflow-y-auto p-3">
        {messages.length === 0 ? (
          <div className="max-w-[86%] rounded-lg border border-line bg-surface p-3">
            <p className="text-[14px] leading-relaxed text-ink">
              Bonjour, je suis {ai.name}. Posez votre question. Utilisez ＋ pour joindre des fichiers
              ou images (max 3 Go chacun) — les connaissances s'ajoutent sans effacer l'existant. Menu
              en haut à droite pour connecter des API, voir les connaissances et plus.
            </p>
          </div>
        ) : (
          messages.map((item) => (
            <div
              key={item.id}
              className={`mb-2.5 max-w-[86%] rounded-lg p-3 ${
                item.role === "user"
                  ? "ml-auto bg-accent-soft"
                  : "border border-line bg-surface"
              }`}
            >
              <p className="whitespace-pre-wrap text-[14px] leading-relaxed text-ink">{item.text}</p>
              {item.pendingConfirm ? (
                <div className="mt-2 rounded-md border border-line bg-surface-alt p-2.5">
                  <p className="text-[12px] font-bold text-ink">
                    Confirmer {item.pendingConfirm.method} · {item.pendingConfirm.apiName} ?
                  </p>
                  <div className="mt-2 flex gap-2">
                    <Btn
                      className="h-9 min-h-9 px-3 text-[12px]"
                      onClick={() =>
                        void send({
                          extraUser: `Oui, je confirme l'appel ${item.pendingConfirm!.method} vers ${item.pendingConfirm!.apiName}.`,
                          confirmed: item.pendingConfirm,
                        })
                      }
                    >
                      Confirmer
                    </Btn>
                    <Btn ghost className="h-9 min-h-9 px-3 text-[12px]" onClick={() => persist(messages.map((m) => (m.id === item.id ? { ...m, pendingConfirm: undefined } : m)))}>
                      Annuler
                    </Btn>
                  </div>
                </div>
              ) : null}
            </div>
          ))
        )}
        {busy && !messages.some((m) => m.role === "assistant" && m.id.startsWith("tmp")) ? (
          <p className="px-1 text-[12px] text-muted">Vanelle réfléchit…</p>
        ) : null}
      </div>

      {ai.files.length > 0 ? (
        <p className="bg-surface px-3 pb-1 text-[11px] text-muted">
          {ai.files.length} fichier(s) en connaissances · max 3 Go / fichier
        </p>
      ) : null}

      <div className="flex items-end gap-1.5 border-t border-line bg-surface p-2.5">
        <input
          ref={fileRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => {
            const files = e.target.files;
            e.target.value = "";
            void pickFiles(files);
          }}
        />
        <button
          type="button"
          className="flex size-11 shrink-0 items-center justify-center rounded-[9px] border-[1.5px] border-accent bg-accent-soft text-accent"
          aria-label="Ajouter un fichier ou une image"
          onClick={() => fileRef.current?.click()}
        >
          <Paperclip className="size-4" strokeWidth={2.4} />
        </button>
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              void send();
            }
          }}
          rows={1}
          placeholder="Écrivez votre message…"
          className="max-h-[120px] min-h-11 flex-1 resize-none rounded-md border border-input-line bg-surface px-3 py-2.5 text-[14px] outline-none focus:border-accent focus:ring-2 focus:ring-accent/20"
        />
        <button
          type="button"
          className="flex size-11 shrink-0 items-center justify-center rounded-[9px] bg-accent text-white disabled:opacity-50"
          disabled={busy || !draft.trim()}
          onClick={() => void send()}
          aria-label="Envoyer"
        >
          <SendHorizontal className="size-4" strokeWidth={2.4} />
        </button>
      </div>

      {menuOpen ? (
        <div
          className="fixed inset-0 z-40 flex items-end justify-center bg-black/45"
          onClick={closeMenu}
        >
          <div
            className="max-h-[78%] w-full max-w-[480px] overflow-y-auto rounded-t-xl bg-surface pb-5 pt-2"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mx-auto mb-1.5 h-1 w-10 rounded-full bg-[#ddd]" />
            {menuPanel === "main" && (
              <>
                <p className="px-[18px] py-2.5 text-[15px] font-extrabold">Menu · {ai.name}</p>
                <MenuRow
                  title="Connecter une API"
                  sub={`${ai.apis.length} API · en ajouter une ou plusieurs`}
                  onClick={() => setMenuPanel("apis")}
                />
                <MenuRow
                  title="Voir les connaissances"
                  sub={`${ai.training.length} notion(s) · ${ai.files.length} fichier(s)`}
                  onClick={() => setMenuPanel("knowledge")}
                />
                <MenuRow
                  title="Effacer la conversation"
                  sub="Supprime uniquement l'historique de ce chat"
                  danger
                  onClick={() => {
                    persist([]);
                    closeMenu();
                    setStatus("Conversation effacée.");
                    toast.success("Conversation effacée");
                  }}
                />
                <MenuRow
                  title="Infos de l'IA"
                  sub="Style, tokens, température, prompt, traits"
                  onClick={() => setMenuPanel("info")}
                />
                <MenuRow
                  title="Ajouter un fichier"
                  sub="Même action que le trombone · max 3 Go / fichier"
                  onClick={() => {
                    closeMenu();
                    fileRef.current?.click();
                  }}
                />
                <MenuRow
                  title="Exporter ce chat"
                  sub={`${messages.length} message(s) · JSON`}
                  onClick={exportChat}
                />
                <MenuRow title="Fermer" sub="" muted onClick={closeMenu} />
              </>
            )}

            {menuPanel === "apis" && (
              <>
                <PanelHead title="API connectées" onBack={() => setMenuPanel("main")} />
                <div className="px-[18px] pb-3">
                  {ai.apis.length === 0 ? (
                    <Muted>Aucune API. Ajoutez-en une ou plusieurs ci-dessous.</Muted>
                  ) : (
                    ai.apis.map((a) => <ApiCard key={a.id} api={a} />)
                  )}
                  <Btn className="mt-2 w-full" onClick={() => setMenuPanel("addApi")}>
                    Ajouter une API
                  </Btn>
                </div>
              </>
            )}

            {menuPanel === "addApi" && (
              <>
                <PanelHead title="Nouvelle API" onBack={() => setMenuPanel("apis")} />
                <div className="px-[18px] pb-3">
                  <ApiEditor
                    compact
                    onAdd={(api, secret) => {
                      attachApi(ai.id, api, secret);
                      toast.success(`${api.name} connectée`);
                      setMenuPanel("apis");
                    }}
                  />
                </div>
              </>
            )}

            {menuPanel === "knowledge" && (
              <>
                <PanelHead title="Connaissances" onBack={() => setMenuPanel("main")} />
                <div className="px-[18px] pb-3">
                  <p className="mb-1.5 text-[11px] font-bold text-muted">
                    Notions ({ai.training.length})
                  </p>
                  {ai.training.length === 0 ? (
                    <Muted>Aucune notion enseignée.</Muted>
                  ) : (
                    ai.training.map((t) => (
                      <div key={t.id} className="mb-2 rounded-md border border-line bg-surface-alt p-3">
                        <p className="text-[13px] font-bold">{t.question}</p>
                        <p className="text-[13px] text-muted">{t.answer}</p>
                      </div>
                    ))
                  )}
                  <p className="mb-1.5 mt-2.5 text-[11px] font-bold text-muted">
                    Fichiers ({ai.files.length})
                  </p>
                  {ai.files.length === 0 ? (
                    <Muted>Aucun fichier.</Muted>
                  ) : (
                    ai.files.map((f: VFile) => (
                      <div key={f.id} className="mb-2 rounded-md border border-line bg-surface-alt p-3">
                        <p className="text-[13px] font-bold">
                          {f.name} · {fmtSize(f.size)}
                        </p>
                        <p className="text-[13px] text-muted">{f.note.slice(0, 160)}</p>
                      </div>
                    ))
                  )}
                </div>
              </>
            )}

            {menuPanel === "info" && (
              <>
                <PanelHead title="Infos de l'IA" onBack={() => setMenuPanel("main")} />
                <div className="px-[18px] pb-3">
                  <InfoCard label="Nom" value={ai.name} />
                  <InfoCard label="Style" value={ai.style || "—"} />
                  <InfoCard
                    label="Traits de personnalité"
                    value={(ai.traits ?? []).map((t) => t.trim()).filter(Boolean).join(" · ") || "—"}
                  />
                  <InfoCard label="Max tokens" value={String(ai.maxTokens)} />
                  <InfoCard label="Température" value={String(ai.temperature)} />
                  <InfoCard
                    label="System prompt"
                    value={
                      ai.systemPrompt?.trim() ||
                      "(vide — notions & fichiers servent de contexte)"
                    }
                  />
                  <InfoCard label="Description" value={ai.description || "—"} />
                  <InfoCard label="API" value={`${ai.apis.length} connectée(s)`} />
                </div>
              </>
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function MenuRow({
  title,
  sub,
  onClick,
  danger,
  muted,
}: {
  title: string;
  sub: string;
  onClick: () => void;
  danger?: boolean;
  muted?: boolean;
}) {
  return (
    <button
      type="button"
      className="w-full border-t border-line px-[18px] py-3.5 text-left"
      onClick={onClick}
    >
      <p
        className={`text-[15px] font-bold ${danger ? "text-danger" : muted ? "text-muted" : "text-ink"}`}
      >
        {title}
      </p>
      {sub ? <p className="mt-0.5 text-[12px] leading-snug text-muted">{sub}</p> : null}
    </button>
  );
}

function PanelHead({ title, onBack }: { title: string; onBack: () => void }) {
  return (
    <div className="flex items-center gap-3 px-[18px] py-2">
      <button type="button" className="font-extrabold text-accent" onClick={onBack}>
        ‹ Retour
      </button>
      <p className="flex-1 text-[15px] font-extrabold">{title}</p>
      <X className="size-4 text-muted" aria-hidden />
    </div>
  );
}

function InfoCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="mb-2 rounded-md border border-line bg-surface-alt p-3">
      <p className="mb-0.5 text-[11px] font-bold text-muted">{label}</p>
      <p className="whitespace-pre-wrap text-[13px] font-bold leading-snug text-ink">{value}</p>
    </div>
  );
}

function ApiCard({ api }: { api: UserApi }) {
  return (
    <div className="mb-2 rounded-md border border-line bg-surface-alt p-3">
      <p className="text-[13px] font-bold">{api.name}</p>
      <p className="text-[12px] text-muted">
        {api.method} · {api.endpoint}
      </p>
    </div>
  );
}
