package com.vanelle.os

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Process
import android.util.Log
import org.tensorflow.lite.Interpreter
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.channels.FileChannel
import java.util.ArrayDeque
import kotlinx.coroutines.*

/**
 * Android streaming implementation of the openWakeWord pipeline.
 *
 * Pipeline (matching the official openWakeWord feature flow):
 *   16 kHz / mono / signed 16-bit PCM
 *       -> mel spectrogram
 *       -> 76 x 32 mel window, advanced every 80 ms
 *       -> 96-dim embedding
 *       -> last 16 embeddings
 *       -> custom wake-word classifier
 *
 * Important: the mel output is transformed with `x / 10 + 2`, as in the
 * official openWakeWord implementation. Do not normalize PCM to [-1, 1]
 * before the mel model; the feature extractor expects int16 PCM semantics.
 *
 * Android-specific:
 *   - AudioRecord runs in a foreground microphone service.
 *   - Inference runs off the main thread.
 *   - TFLite XNNPACK is disabled for the dynamic mel model; the input is
 *     explicitly resized to [1, 1280] before allocateTensors().
 *   - Audio frames are accumulated so partial AudioRecord reads cannot
 *     corrupt the 80 ms feature cadence.
 */
class OpenWakeWordDetector(private val context: Context) {

    companion object {
        private const val TAG = "OpenWakeWord"
        private const val SAMPLE_RATE = 16_000
        private const val CHUNK_SAMPLES = 1_280 // 80 ms
        private const val MEL_BINS = 32
        private const val EMB_WINDOW = 76
        private const val EMB_STEP = 8
        private const val EMB_DIM = 96
        private const val CLASSIFIER_WINDOW = 16

        // Seuil stabilisé : moins de faux déclenchements, micro plus prévisible.
        private const val THRESHOLD = 0.45f
        private const val CONFIRM_FRAMES = 3
        // Réarme très vite après une détection
        private const val COOLDOWN_MS = 1_500L

        private const val RAW_HISTORY_SAMPLES = SAMPLE_RATE * 10
        private const val MEL_HISTORY_FRAMES = 10 * 97
        
        // A very low-energy frame is ignored only for diagnostics; the PCM is
        // never amplified or otherwise altered before openWakeWord inference.
        private const val ENERGY_FLOOR = 8.0

        private const val FALLBACK_EMB_WINDOW = 76
        private const val FALLBACK_MEL_BINS = 32
    }

    private var melSession: OrtSession? = null
    private val ortEnvironment: OrtEnvironment by lazy { OrtEnvironment.getEnvironment() }
    private var embInterp: Interpreter? = null
    private var clsInterp: Interpreter? = null

    private var record: AudioRecord? = null
    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val rawDataBuffer = ArrayDeque<Short>(RAW_HISTORY_SAMPLES)
    private val melBuffer = ArrayDeque<FloatArray>()
    private val featureBuffer = ArrayDeque<FloatArray>()
    private var pendingAudio = ShortArray(0)

    private var embFrameWindow = EMB_WINDOW
    private var embMelBins = MEL_BINS
    private var embOutDim = EMB_DIM

    @Volatile private var lastDetectAt = 0L
    private var wakeScoreStreak = 0
    private var lastErrorLoggedAt = 0L
    private var lastErrorLoggedMsg = ""

    private fun options() = Interpreter.Options()

    private fun mapModel(file: File): ByteBuffer {
        FileInputStream(file).use { fis ->
            val channel = fis.channel
            return channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
        }
    }

    private fun loadModel(file: File): Interpreter? {
        return try {
            if (!file.exists() || file.length() < 50_000L) return null
            Interpreter(mapModel(file), options()).also {
                try { it.allocateTensors() } catch (_: Throwable) {}
            }
        } catch (e: Exception) {
            Log.e(TAG, "loadModel(${file.name}): ${e.message}", e)
            null
        }
    }

    private fun loadMelModel(file: File): OrtSession? {
        return try {
            if (!file.exists() || file.length() < 100_000L) return null
            val options = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(1)
                setInterOpNumThreads(1)
            }
            ortEnvironment.createSession(file.absolutePath, options)
        } catch (e: Exception) {
            Log.e(TAG, "loadMelModel(ONNX): ${e.message}", e)
            WakeWordDiagnostics.log(
                context, TAG,
                "ERREUR chargement mel ONNX: ${e.message ?: e.javaClass.simpleName}"
            )
            null
        }
    }

    private fun loadClassifier(): Interpreter? {
        return try {
            val afd = context.assets.openFd("wakeword_classifier.tflite")
            FileInputStream(afd.fileDescriptor).use { fis ->
                val buffer = fis.channel.map(
                    FileChannel.MapMode.READ_ONLY,
                    afd.startOffset,
                    afd.declaredLength
                )
                Interpreter(buffer, options()).also {
                    try { it.allocateTensors() } catch (_: Throwable) {}
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "loadClassifier: ${e.message}", e)
            null
        }
    }

    fun prepare(): Boolean {
        if (!WakeWordModelManager.isReady(context)) return false

        closeInterpreters()

        melSession = loadMelModel(WakeWordModelManager.melFile(context))
        embInterp = loadModel(WakeWordModelManager.embFile(context))
        clsInterp = loadClassifier()

        if (melSession == null || embInterp == null || clsInterp == null) {
            closeInterpreters()
            WakeWordDiagnostics.log(
                context, TAG,
                "prepare ÉCHEC: mel=${melSession != null}, embedding=${embInterp != null}, classifier=${clsInterp != null}"
            )
            return false
        }

        try {
            val input = embInterp!!.getInputTensor(0)
            var shape = input.shape()
            if (shape.size != 4 || shape[1] <= 0 || shape[2] <= 0) {
                embInterp!!.resizeInput(0, intArrayOf(1, EMB_WINDOW, MEL_BINS, 1), true)
                embInterp!!.allocateTensors()
                shape = embInterp!!.getInputTensor(0).shape()
            }
            embFrameWindow = if (shape.size >= 2 && shape[1] > 0) shape[1] else FALLBACK_EMB_WINDOW
            embMelBins = if (shape.size >= 3 && shape[2] > 0) shape[2] else FALLBACK_MEL_BINS

            val outShape = embInterp!!.getOutputTensor(0).shape()
            embOutDim = outShape.fold(1) { acc, d -> if (d > 0) acc * d else acc }
            if (embOutDim <= 0) embOutDim = EMB_DIM

            val clsInput = clsInterp!!.getInputTensor(0)
            val clsShape = clsInput.shape()
            if (clsShape.size < 3 || clsShape.any { it <= 0 }) {
                clsInterp!!.resizeInput(0, intArrayOf(1, CLASSIFIER_WINDOW, embOutDim), true)
                clsInterp!!.allocateTensors()
            }

            WakeWordDiagnostics.log(
                context, TAG,
                "prepare OK: mel=ONNX(input=${melSession!!.inputInfo.keys.firstOrNull() ?: "?"}), " +
                    "embedding=${shape.toList()} -> $embOutDim, " +
                    "classifier=${clsInterp!!.getInputTensor(0).shape().toList()}"
            )
            return true
        } catch (e: Exception) {
            Log.e(TAG, "prepare shapes: ${e.message}", e)
            WakeWordDiagnostics.log(context, TAG, "ERREUR formes TFLite: ${e.message}")
            closeInterpreters()
            return false
        }
    }

    @Suppress("MissingPermission")
    fun start(onDetected: () -> Unit) {
        stop()

        if (!prepare()) {
            WakeWordDiagnostics.log(context, TAG, "start annulé: modèles/interpréteurs indisponibles")
            return
        }

        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            WakeWordDiagnostics.log(context, TAG, "AudioRecord incompatible: minBuffer=$minBuffer")
            return
        }

        val bufferSize = maxOf(
            minBuffer,
            CHUNK_SAMPLES * 4 * 2 // enough room for scheduling jitter
        )

        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
        } catch (e: Exception) {
            WakeWordDiagnostics.log(context, TAG, "ERREUR création AudioRecord: ${e.message}")
            return
        }

        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            WakeWordDiagnostics.log(context, TAG, "AudioRecord STATE_UNINITIALIZED")
            return
        }

        record = rec
        try {
            rec.startRecording()
        } catch (e: Exception) {
            rec.release()
            record = null
            WakeWordDiagnostics.log(context, TAG, "ERREUR startRecording: ${e.message}")
            return
        }

        resetStreamingState()

        job = scope.launch {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)

            val readBuffer = ShortArray(CHUNK_SAMPLES * 2)

            while (isActive) {
                val n = try {
                    rec.read(readBuffer, 0, readBuffer.size, AudioRecord.READ_BLOCKING)
                } catch (e: Exception) {
                    logInferenceError("AudioRecord.read: ${e.message}")
                    -1
                }

                if (n <= 0) {
                    delay(5)
                    continue
                }

                appendPending(readBuffer, n)

                while (pendingAudio.size >= CHUNK_SAMPLES && isActive) {
                    val chunk = pendingAudio.copyOfRange(0, CHUNK_SAMPLES)
                    pendingAudio = pendingAudio.copyOfRange(CHUNK_SAMPLES, pendingAudio.size)

                    processChunk(chunk, onDetected)
                }
            }
        }

        WakeWordDiagnostics.log(
            context, TAG,
            "écoute démarrée: PCM 16kHz mono int16, chunks=$CHUNK_SAMPLES, emb=$embFrameWindow x $embMelBins"
        )
    }

    private fun appendPending(src: ShortArray, count: Int) {
        if (count <= 0) return
        val merged = ShortArray(pendingAudio.size + count)
        pendingAudio.copyInto(merged)
        src.copyInto(merged, pendingAudio.size, 0, count)
        pendingAudio = merged
    }

    private fun processChunk(chunk: ShortArray, onDetected: () -> Unit) {
        // openWakeWord's streaming feature extractor keeps raw audio history and,
        // for every 80 ms update, computes the mel spectrogram over the current
        // 80 ms chunk plus 30 ms of left context (1280 + 480 samples when enough
        // history exists). This is important: sending only 1280 samples changes
        // the mel frame count and no longer matches the official streaming path.
        rawDataBuffer.addAll(chunk.asList())
        val melInputSamples = minOf(rawDataBuffer.size, CHUNK_SAMPLES + 160 * 3)
        val raw = lastShorts(rawDataBuffer, melInputSamples)
        val melFrames = runMel(raw) ?: return

        for (frame in melFrames) melBuffer.addLast(frame)
        while (melBuffer.size > MEL_HISTORY_FRAMES) melBuffer.removeFirst()

        // One new embedding is produced per 80 ms update in the official
        // streaming implementation. The initial mel buffer is prefilled with
        // 76 frames so startup can produce the first embedding immediately.
        if (melBuffer.size >= embFrameWindow) {
            val window = lastDequeItems(melBuffer, embFrameWindow)
            val emb = runEmbedding(window) ?: return
            featureBuffer.addLast(emb)
            while (featureBuffer.size > 120) featureBuffer.removeFirst()

            if (featureBuffer.size >= CLASSIFIER_WINDOW) {
                val score = runClassifier(lastDequeItems(featureBuffer, CLASSIFIER_WINDOW)) ?: return
                // Confirmation multi-frames : évite un pic isolé (bruit) tout en restant sensible
                if (score >= THRESHOLD) {
                    wakeScoreStreak++
                } else {
                    wakeScoreStreak = 0
                }
                if (wakeScoreStreak >= CONFIRM_FRAMES) {
                    val now = System.currentTimeMillis()
                    if (now - lastDetectAt >= COOLDOWN_MS) {
                        lastDetectAt = now
                        wakeScoreStreak = 0
                        Log.i(TAG, "WAKE DETECTED score=$score")
                        WakeWordDiagnostics.log(context, TAG, "MOT D'ACTIVATION DÉTECTÉ score=$score")
                        resetAfterDetection()
                        scope.launch(Dispatchers.Main.immediate) { onDetected() }
                    }
                }
            }
        }
    }

    private fun lastShorts(deque: ArrayDeque<Short>, count: Int): ShortArray {
        val n = minOf(count, deque.size)
        val out = ShortArray(n)
        var skip = deque.size - n
        var i = 0
        for (v in deque) {
            if (skip > 0) {
                skip--
            } else {
                out[i++] = v
            }
        }
        return out
    }

    private fun runMel(pcm: ShortArray): List<FloatArray>? {
        val session = melSession ?: return null
        return try {
            require(pcm.isNotEmpty()) { "mel input vide" }

            // Official openWakeWord: int16 PCM → float32, then after inference x/10 + 2
            val inputName = session.inputInfo.keys.firstOrNull()
                ?: throw IllegalStateException("mel ONNX: aucun input")

            // Convert PCM to float32 + define shape [1, N]
            val audioData = FloatArray(pcm.size) { i -> pcm[i].toFloat() }
            val shape = longArrayOf(1L, audioData.size.toLong())

            // Correct tensor creation (never call createTensor without OrtEnvironment)
            val tensor = OnnxTensor.createTensor(
                ortEnvironment,
                FloatBuffer.wrap(audioData),
                shape
            )

            tensor.use {
                session.run(mapOf(inputName to tensor)).use { results ->
                    val output = results[0] as OnnxTensor

                    // Extraction robuste : floatBuffer d'abord (indépendant du rang),
                    // puis fallback via flatten de .value (évite ClassCastException
                    // quand la sortie est [1, T, 32] au lieu de [T, 32]).
                    val values: FloatArray
                    val outShape = output.info.shape
                    val buffer = output.floatBuffer
                    if (buffer != null) {
                        buffer.rewind()
                        values = FloatArray(buffer.remaining())
                        buffer.get(values)
                    } else {
                        val flat = mutableListOf<Float>()
                        fun flatten(obj: Any?) {
                            when (obj) {
                                is FloatArray -> obj.forEach { flat.add(it) }
                                is Array<*> -> obj.forEach { flatten(it) }
                                is Float -> flat.add(obj)
                            }
                        }
                        flatten(output.value)
                        values = flat.toFloatArray()
                    }

                    // Official openWakeWord post-processing
                    for (i in values.indices) values[i] = values[i] / 10f + 2f

                    val bins = (outShape.lastOrNull()?.toInt() ?: MEL_BINS).coerceAtLeast(1)
                    if (values.isEmpty() || values.size % bins != 0) {
                        throw IllegalStateException(
                            "mel ONNX sortie invalide: shape=${outShape.contentToString()} count=${values.size}"
                        )
                    }
                    val frames = values.size / bins
                    ArrayList<FloatArray>(frames).also { out ->
                        for (f in 0 until frames) {
                            out.add(FloatArray(bins) { b -> values[f * bins + b] })
                        }
                    }
                }
            }
        } catch (e: Exception) {
            logInferenceError("mel ONNX: ${e.message}")
            null
        }
    }

    private fun runEmbedding(window: List<FloatArray>): FloatArray? {
        val interp = embInterp ?: return null
        return try {
            val flatCount = embFrameWindow * embMelBins
            val inBuf = ByteBuffer.allocateDirect(flatCount * 4)
                .order(ByteOrder.nativeOrder())

            for (t in 0 until embFrameWindow) {
                val frame = window[t]
                for (b in 0 until embMelBins) {
                    inBuf.putFloat(if (b < frame.size) frame[b] else 0f)
                }
            }
            inBuf.rewind()

            val outCount = interp.getOutputTensor(0).shape()
                .fold(1) { a, b -> if (b > 0) a * b else a }
            val outBuf = ByteBuffer.allocateDirect(outCount * 4)
                .order(ByteOrder.nativeOrder())

            interp.run(inBuf, outBuf)
            outBuf.rewind()
            val out = FloatArray(outCount)
            outBuf.asFloatBuffer().get(out)

            if (out.size == EMB_DIM) out
            else if (out.size >= EMB_DIM) out.copyOf(EMB_DIM)
            else out.copyOf(EMB_DIM)
        } catch (e: Exception) {
            logInferenceError("embedding: ${e.message}")
            null
        }
    }

    /**
     * Returns the newest [count] items without relying on Kotlin collection
     * extensions that are not available for java.util.ArrayDeque on all
     * Android/Kotlin toolchain combinations.
     */
    private fun lastDequeItems(
        deque: ArrayDeque<FloatArray>,
        count: Int
    ): List<FloatArray> {
        val n = minOf(count, deque.size)
        if (n <= 0) return emptyList()
        val result = ArrayList<FloatArray>(n)
        var skipped = deque.size - n
        for (item in deque) {
            if (skipped > 0) {
                skipped--
            } else {
                result.add(item)
            }
        }
        return result
    }

    private fun lastListItems(list: List<FloatArray>, count: Int): List<FloatArray> {
        val from = maxOf(0, list.size - count)
        return list.subList(from, list.size)
    }

    private fun runClassifier(features: List<FloatArray>): Float? {
        val interp = clsInterp ?: return null
        return try {
            val inBuf = ByteBuffer.allocateDirect(CLASSIFIER_WINDOW * embOutDim * 4)
                .order(ByteOrder.nativeOrder())

            for (frame in lastListItems(features, CLASSIFIER_WINDOW)) {
                for (i in 0 until embOutDim) {
                    inBuf.putFloat(if (i < frame.size) frame[i] else 0f)
                }
            }
            inBuf.rewind()

            val outShape = interp.getOutputTensor(0).shape()
            val outCount = outShape.fold(1) { a, b -> if (b > 0) a * b else a }
            val outBuf = ByteBuffer.allocateDirect(outCount * 4)
                .order(ByteOrder.nativeOrder())

            interp.run(inBuf, outBuf)
            outBuf.rewind()
            val scores = FloatArray(outCount)
            outBuf.asFloatBuffer().get(scores)
            scores.firstOrNull()?.coerceIn(0f, 1f)
        } catch (e: Exception) {
            logInferenceError("classifier: ${e.message}")
            null
        }
    }

    private fun resetStreamingState() {
        wakeScoreStreak = 0
        rawDataBuffer.clear()
        melBuffer.clear()
        featureBuffer.clear()
        pendingAudio = ShortArray(0)

        // Official openWakeWord initializes this feature history with a
        // 76x32 mel context. This avoids feeding an incomplete embedding
        // during startup.
        repeat(EMB_WINDOW) {
            melBuffer.addLast(FloatArray(MEL_BINS) { 1f })
        }
    }

    private fun resetAfterDetection() {
        // Equivalent to openWakeWord's reset(): prevent the previous
        // activation's residual features from immediately retriggering.
        resetStreamingState()
    }

    private fun logInferenceError(message: String) {
        val now = System.currentTimeMillis()
        if (message != lastErrorLoggedMsg || now - lastErrorLoggedAt > 5_000L) {
            lastErrorLoggedMsg = message
            lastErrorLoggedAt = now
            Log.w(TAG, message)
            WakeWordDiagnostics.log(context, TAG, "ERREUR: $message")
        }
    }

    fun stop() {
        job?.cancel()
        job = null

        try { record?.stop() } catch (_: Exception) {}
        try { record?.release() } catch (_: Exception) {}
        record = null

        resetStreamingState()
        closeInterpreters()
    }

    private fun closeInterpreters() {
        try { melSession?.close() } catch (_: Exception) {}
        try { embInterp?.close() } catch (_: Exception) {}
        try { clsInterp?.close() } catch (_: Exception) {}
        melSession = null
        embInterp = null
        clsInterp = null
    }
}
