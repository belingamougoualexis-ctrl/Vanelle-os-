package com.vanelle.app
import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlin.math.max
object ModelDownloader{
data class ModelSpec(val id:String,val url:String,val fileName:String,val sha256:String,val minSize:Long,val label:String)
data class Progress(val spec:ModelSpec,val downloaded:Long,val total:Long,val status:String){val fraction:Double get()=if(total>0)(downloaded.toDouble()/total).coerceIn(0.0,1.0)else 0.0}
val LLM=ModelSpec("llm","https://huggingface.co/jc-builds/SmolLM2-360M-Instruct-Q4_K_M-GGUF/resolve/main/SmolLM2-360M-Instruct.Q4_K_M.gguf","vanelle-smollm2-360m-q4_k_m.gguf","ade7aee1e5bd7c3b8f1fedafc61a1a0be31e8afa64e006607cd202323e2ccce0",260_000_000,"Modèle IA")
val EMBEDDING=ModelSpec("embedding","https://huggingface.co/nomic-ai/nomic-embed-text-v1.5-GGUF/resolve/main/nomic-embed-text-v1.5.Q4_K_M.gguf","vanelle-nomic-embed-text-v1.5-q4_k_m.gguf","d4e388894e09cf3816e8b0896d81d265b55e7a9fff9ab03fe8bf4ef5e11295ac",80_000_000,"Modèle d'embeddings")
fun file(c:Context,s:ModelSpec)=File(c.filesDir,s.fileName)
fun isReady(c:Context,s:ModelSpec)=file(c,s).let{it.exists()&&it.length()>=s.minSize&&sha256(it)==s.sha256}
@Synchronized fun downloadBlocking(c:Context,s:ModelSpec,onProgress:((Progress)->Unit)?=null):File{val dest=file(c,s);if(isReady(c,s)){onProgress?.invoke(Progress(s,dest.length(),dest.length(),"ready"));return dest};val part=File(c.filesDir,"${s.fileName}.part");var downloaded=if(part.exists())part.length()else 0L;var attempts=0;while(true){try{return transfer(c,s,dest,part,downloaded,onProgress)}catch(e:IOException){attempts++;downloaded=if(part.exists())part.length()else 0L;if(attempts>=5)throw e;Thread.sleep((1000L shl(attempts-1)).coerceAtMost(15000L))}}}
private fun transfer(c:Context,s:ModelSpec,dest:File,part:File,start:Long,onProgress:((Progress)->Unit)):File{var downloaded=start;var url=URL(s.url);var conn:HttpURLConnection?=null;try{var code:Int;var hops=0;while(true){conn?.disconnect();conn=url.openConnection()as HttpURLConnection;conn.instanceFollowRedirects=false;conn.connectTimeout=45000;conn.readTimeout=300000;conn.setRequestProperty("User-Agent","Vanelle/1.0 Android");if(downloaded>0)conn.setRequestProperty("Range","bytes=$downloaded-");code=conn.responseCode;if(code in 300..399&&hops<8){url=URL(url,conn.getHeaderField("Location")?:throw IOException("Redirection sans destination"));hops++;continue};break};if(code==416&&part.exists()&&part.length()>=s.minSize&&sha256(part)==s.sha256)return finalize(part,dest,s,onProgress);if(code==200&&downloaded>0){part.delete();downloaded=0;conn.disconnect();conn=url.openConnection()as HttpURLConnection;conn.connectTimeout=45000;conn.readTimeout=300000;conn.setRequestProperty("User-Agent","Vanelle/1.0 Android");code=conn.responseCode};if(code!=200&&code!=206)throw IOException("HTTP $code");val len=conn.contentLengthLong;val total=if(code==206&&len>0)downloaded+len else max(len,downloaded);onProgress(Progress(s,downloaded,total,"downloading"));conn.inputStream.use{input->FileOutputStream(part,code==206&&downloaded>0).use{out->val b=ByteArray(65536);while(true){val n=input.read(b);if(n<0)break;out.write(b,0,n);downloaded+=n;onProgress(Progress(s,downloaded,total,"downloading"))};out.fd.sync()}};if(part.length()<s.minSize||sha256(part)!=s.sha256){part.delete();throw IOException("SHA-256 invalide pour ${s.label}")};return finalize(part,dest,s,onProgress)}finally{conn?.disconnect()}}
private fun finalize(part:File,dest:File,s:ModelSpec,onProgress:(Progress)->Unit):File{if(!part.renameTo(dest)){part.copyTo(dest,true);part.delete()};onProgress(Progress(s,dest.length(),dest.length(),"ready"));return dest}
private fun sha256(f:File):String{val d=MessageDigest.getInstance("SHA-256");FileInputStream(f).use{i->val b=ByteArray(65536);while(true){val n=i.read(b);if(n<0)break;d.update(b,0,n)}};return d.digest().joinToString(""){String.format("%02x",it)}}}
