package com.vanelle.app
import android.content.Context
import androidx.core.content.FileProvider
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.nehuatl.llamacpp.LlamaHelper
class LlamaEngine(private val context:Context){companion object{const val CONTEXT_SIZE=2048};private val scope=CoroutineScope(SupervisorJob()+Dispatchers.IO);private val events=MutableSharedFlow<LlamaHelper.LLMEvent>(extraBufferCapacity=128);private val helper=LlamaHelper(context.contentResolver,scope,events);private val mutex=Mutex();@Volatile var ready=false;private var load:CompletableDeferred<Unit>?=null;private var gen:CompletableDeferred<String>?=null;private val out=StringBuilder();init{scope.launch{events.collect{e->when(e){is LlamaHelper.LLMEvent.Loaded->{ready=true;load?.complete(Unit)};is LlamaHelper.LLMEvent.Started->out.clear();is LlamaHelper.LLMEvent.Ongoing->out.append(e.word);is LlamaHelper.LLMEvent.Done->{gen?.complete(e.fullText.ifBlank{out.toString()})};is LlamaHelper.LLMEvent.Error->{ready=false;val x=IllegalStateException(e.message);load?.completeExceptionally(x);gen?.completeExceptionally(x)}}}}};suspend fun ensureLoaded(){mutex.withLock{if(ready)return;val f=ModelDownloader.downloadBlocking(context,ModelDownloader.LLM);val d=CompletableDeferred<Unit>();load=d;val uri=FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",f);context.grantUriPermission(context.packageName,uri,android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);helper.load(uri.toString(),CONTEXT_SIZE,null){_ ->};d.await();load=null}};suspend fun generate(prompt:String,maxTokens:Int,temp:Float):String{if(!ready)ensureLoaded();mutex.withLock{val d=CompletableDeferred<String>();gen=d;helper.predict(prompt,null,true);val r=d.await();gen=null;return r.replace("<|im_end|>","").replace("<|endoftext|>","").replace("<|im_start|>assistant","").trim()}};fun buildPrompt(m:List<Pair<String,String>>)=buildString{m.forEach{append("<|im_start|>").append(it.first).append('\n').append(it.second).append("<|im_end|>\n")};append("<|im_start|>assistant\n")}}
