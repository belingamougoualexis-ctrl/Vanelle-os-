package com.vanelle.app
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.core.app.ActivityCompat
import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.fabricEnabled
import com.facebook.react.defaults.DefaultReactActivityDelegate
class MainActivity:ReactActivity(){override fun getMainComponentName()="Vanelle";override fun createReactActivityDelegate():ReactActivityDelegate=DefaultReactActivityDelegate(this,mainComponentName,fabricEnabled);override fun onCreate(b:Bundle?){super.onCreate(b);ModelDownloadService.start(this);if(Build.VERSION.SDK_INT>=33&&ActivityCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),7001)}}
