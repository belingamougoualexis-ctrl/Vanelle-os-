package com.vanelle.app
import android.content.Context
import java.io.File
class EmbeddingEngine(private val context:Context){val modelFile:File get()=ModelDownloader.file(context,ModelDownloader.EMBEDDING);fun isReady()=ModelDownloader.isReady(context,ModelDownloader.EMBEDDING);fun ensureDownloaded(onProgress:((ModelDownloader.Progress)->Unit)?=null)=ModelDownloader.downloadBlocking(context,ModelDownloader.EMBEDDING,onProgress)}
