package com.vanelle.os
import android.content.Context

object DateTimePrefs {
    private fun p(c: Context) = c.getSharedPreferences("vanelle_prefs", 0)

    /** N'affiche l'invite date/heure qu'une seule fois. */
    fun wasPrompted(c: Context): Boolean = p(c).getBoolean("datetime_prompted", false)

    fun setPrompted(c: Context) {
        p(c).edit().putBoolean("datetime_prompted", true).apply()
    }
}
