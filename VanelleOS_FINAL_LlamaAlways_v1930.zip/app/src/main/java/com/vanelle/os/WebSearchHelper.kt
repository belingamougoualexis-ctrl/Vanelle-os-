package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.net.Uri
class WebSearchHelper(private val c:Context){
    fun search(q:String):Boolean {
        return try {
            val query = QueryCleaner.subject(q).ifBlank { q.trim() }
            if (query.isBlank()) return false
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://duckduckgo.com/?q=${Uri.encode(query)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            c.startActivity(i)
            true
        } catch (_: Exception) {
            false
        }
    }
}
