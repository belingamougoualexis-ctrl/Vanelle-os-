package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.net.Uri
class MapsHelper(private val c:Context){
    fun open(q:String):String {
        val query = QueryCleaner.subject(q).ifBlank { q.trim() }
        if (query.isBlank()) return "Destination manquante pour ouvrir la carte."
        return try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(query)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            c.startActivity(i)
            "J'ouvre la carte pour « $query »."
        } catch (_: Exception) {
            try {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/${Uri.encode(query)}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                c.startActivity(i)
                "J'ouvre Google Maps dans le navigateur pour « $query »."
            } catch (_: Exception) {
                "Je n'ai pas pu ouvrir les cartes. Vérifie qu'une application de cartes ou un navigateur est installé."
            }
        }
    }
}
