package com.vanelle.os

import android.content.Context
import android.content.Intent
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class YouTubeHelper(private val c: Context) {

    /**
     * Ouvre YouTube avec une requête déjà nettoyée.
     * Pour « dernier son / dernière chanson de X », tente d'abord de résoudre
     * le vrai titre via le web, puis cherche ce titre (+ artiste) sur YouTube.
     */
    suspend fun searchSmart(rawQuery: String): String = withContext(Dispatchers.IO) {
        val q0 = rawQuery.trim()
        if (q0.isBlank()) return@withContext "Que veux-tu chercher sur YouTube ?"

        val resolved = resolveLatestTrackQuery(q0)
        openSearch(resolved)
    }

    /** Version synchrone (compat) : ouvre tel quel sans résolution réseau. */
    fun search(q: String): String {
        if (q.isBlank()) return "Que veux-tu chercher sur YouTube ?"
        return openSearch(cleanQuery(q))
    }

    private fun openSearch(q: String): String {
        val query = q.ifBlank { "musique" }
        return try {
            val i = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                // Préfère l'app YouTube si installée
                setPackage("com.google.android.youtube")
            }
            try {
                c.startActivity(i)
            } catch (_: Exception) {
                // Fallback navigateur
                val web = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
                ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                c.startActivity(web)
            }
            "YouTube est ouvert avec la recherche « $query »."
        } catch (_: Exception) {
            "Je n'ai pas pu ouvrir YouTube. Vérifie qu'une application navigateur ou YouTube est installée."
        }
    }

    /**
     * Détecte « dernier son / dernière chanson / dernier titre / dernier clip de ARTISTE »
     * et renvoie une requête YouTube plus précise (titre trouvé + artiste), sinon une
     * requête nettoyée « ARTISTE dernier titre officiel ».
     */
    private fun resolveLatestTrackQuery(q: String): String {
        val cleaned = cleanQuery(q)
        val latestPatterns = listOf(
            Regex(
                "(?i)(?:le\\s+|la\\s+|du\\s+|de\\s+)?(?:dernier|derniere|dernière|nouveau|nouvelle)\\s+" +
                    "(?:son|titre|chanson|single|clip|morceau|album|feat|featuring)\\s+(?:de\\s+|d'|du\\s+)?(.+)",
            ),
            Regex(
                "(?i)(?:dernier|derniere|dernière|nouveau|nouvelle)\\s+" +
                    "(?:son|titre|chanson|single|clip)\\s+(.+)",
            ),
        )
        var artist: String? = null
        for (re in latestPatterns) {
            val m = re.find(cleaned)
            if (m != null) {
                artist = m.groupValues[1].trim()
                    .replace(Regex("(?i)\\b(officiel|official|audio|lyrics|paroles)\\b"), "")
                    .trim()
                break
            }
        }
        if (artist.isNullOrBlank()) {
            // Pas un « dernier son » → requête nettoyée seule
            return cleaned
        }

        // Essaie de trouver le vrai titre via DuckDuckGo / Wikipedia-style snippet
        val title = lookupLatestTitle(artist)
        return if (!title.isNullOrBlank()) {
            "$title $artist"
        } else {
            // Fallback YouTube : requête qui marche bien sur YT
            "$artist dernier titre officiel"
        }
    }

    private fun lookupLatestTitle(artist: String): String? {
        if (!PrivacyFirewall.allowWeb(c)) return null
        // Requête orientée résultats récents
        val q = "dernier titre $artist 2024 OR 2025 OR 2026"
        // 1) DuckDuckGo Instant Answer
        try {
            val u = URL(
                "https://api.duckduckgo.com/?q=${URLEncoder.encode(q, "UTF-8")}&format=json&no_html=1&skip_disambig=1"
            )
            val conn = u.openConnection() as HttpURLConnection
            conn.setRequestProperty("User-Agent", "VanelleOS/1.0")
            conn.connectTimeout = 4500
            conn.readTimeout = 4500
            if (conn.responseCode == 200) {
                val o = JSONObject(conn.inputStream.bufferedReader().readText())
                val abs = o.optString("AbstractText")
                val heading = o.optString("Heading")
                val fromAbs = extractTitleCandidate(abs, artist)
                if (!fromAbs.isNullOrBlank()) return fromAbs
                val fromHead = extractTitleCandidate(heading, artist)
                if (!fromHead.isNullOrBlank()) return fromHead
            }
        } catch (_: Exception) {}

        // 2) Wikipedia FR summary de l'artiste (parfois liste les derniers titres)
        try {
            val topic = artist.trim().take(60)
            val u = URL(
                "https://fr.wikipedia.org/api/rest_v1/page/summary/${URLEncoder.encode(topic, "UTF-8")}"
            )
            val conn = u.openConnection() as HttpURLConnection
            conn.setRequestProperty("User-Agent", "VanelleOS/1.0")
            conn.connectTimeout = 4500
            conn.readTimeout = 4500
            if (conn.responseCode == 200) {
                val o = JSONObject(conn.inputStream.bufferedReader().readText())
                val extract = o.optString("extract")
                val t = extractTitleCandidate(extract, artist)
                if (!t.isNullOrBlank()) return t
            }
        } catch (_: Exception) {}

        return null
    }

    /** Heuristique légère pour tirer un titre de chanson d'un texte court. */
    private fun extractTitleCandidate(text: String?, artist: String): String? {
        if (text.isNullOrBlank()) return null
        val a = artist.lowercase()
        // « "Titre" » ou « « Titre » »
        Regex("[\"«“]([^\"»”]{2,60})[\"»”]").findAll(text).forEach { m ->
            val cand = m.groupValues[1].trim()
            if (cand.length >= 2 && !cand.lowercase().contains(a) &&
                !cand.lowercase().contains("wikipedia")
            ) return cand
        }
        // « dernier single X » / « titre X sorti »
        Regex(
            "(?i)(?:single|titre|chanson|morceau)\\s+[«\"]?([A-Za-zÀ-ÿ0-9][^.,(]{1,50})",
        ).find(text)?.let {
            val cand = it.groupValues[1].trim().trim('«', '»', '"', '“', '”')
            if (cand.length in 2..50) return cand
        }
        return null
    }

    companion object {
        /** Délègue au nettoyeur dynamique partagé (tous domaines). */
        fun cleanQuery(input: String): String = QueryCleaner.subject(input)
    }
}
