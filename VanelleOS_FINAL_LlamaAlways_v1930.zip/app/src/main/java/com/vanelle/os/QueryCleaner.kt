package com.vanelle.os

/**
 * Extraction dynamique du sujet utile dans une phrase de commande.
 * Aucune requête pré-écrite : on retire uniquement les formules de commande
 * et le nom de la destination (YouTube, Maps, Google…), le reste est calculé
 * au moment même à partir de ce que l'utilisateur a dit.
 */
object QueryCleaner {

    /** Verbes / formules de commande en tête de phrase. */
    private val leadingCommand = Regex(
        "(?i)^(fais|effectue|lance|ouvre|regarde|met|mets|joue|play|montre|affiche|" +
            "cherche|chercher|recherche|search|trouve|trouver|navigue|aller|" +
            "va|go|dis|donne|explique|parle)\\s+" +
            "(moi\\s+)?(la\\s+|une\\s+|le\\s+|un\\s+|les\\s+|des\\s+|du\\s+|de\\s+)?"
    )

    private val recherchePrefix = Regex(
        "(?i)^(recherche|chercher|cherche|search|trouve)\\s+" +
            "(sur|de|du|des|pour|le|la|les|un|une|à|a)?\\s*"
    )

    private val platforms = Regex(
        "(?i)\\b(sur\\s+)?(" +
            "youtube|you\\s*tube|yt|" +
            "google|bing|duckduckgo|" +
            "le\\s+web|internet|le\\s+net|" +
            "maps|google\\s*maps|plan|" +
            "netflix|disney\\+?|disney\\s*plus|prime\\s*video|prime|" +
            "spotify|deezer|apple\\s*music|" +
            "whatsapp|instagram|tiktok|facebook|twitter|x\\.com" +
            ")\\b"
    )

    private val trailingJunk = Regex("(?i)[,.!?;:]+$")

    private val leadingArticle = Regex("(?i)^(?:du|de|des|le|la|les|un|une|au|aux|sur|pour|à|a)\\s+")

    /**
     * Retourne uniquement le sujet utile.
     * Ex. « fais la recherche du dernier son de dadju sur youtube »
     *   → « dernier son de dadju »
     * Ex. « ouvre maps et cherche un resto italien près de moi »
     *   → « resto italien près de moi »
     */
    fun subject(raw: String): String {
        var q = raw.trim()
        if (q.isEmpty()) return q

        q = leadingCommand.replace(q, "")
        q = recherchePrefix.replace(q, "")
        q = platforms.replace(q, "")
        // Coupe les connecteurs orphelins laissés par le retrait de plateforme
        q = Regex("(?i)\\s+(sur|avec|via|dans)\\s*$").replace(q, "")
        q = q.replace(Regex("\\s+"), " ").trim()
        q = trailingJunk.replace(q, "").trim()
        q = leadingArticle.replace(q, "").trim()
        return q
    }

    /** Sujet + détection destination (youtube / web / maps / streaming / none). */
    data class Routed(
        val subject: String,
        val dest: Dest
    )

    enum class Dest {
        YOUTUBE, WEB, MAPS, STREAMING, NONE
    }

    fun route(raw: String): Routed {
        val t = stripAccents(raw.lowercase())
        val sub = subject(raw)

        // Priorité : destination explicite dans la phrase, sinon indices de domaine.
        val dest = when {
            t.contains("youtube") || t.contains("you tube") ||
                Regex("\\byt\\b").containsMatchIn(t) ||
                t.contains("spotify") || t.contains("deezer") ||
                t.contains("apple music") -> Dest.YOUTUBE

            t.contains("maps") || t.contains("google maps") || t.contains("navigue") ||
                t.contains("itineraire") || t.contains("itinéraire") ||
                t.contains("route vers") || t.contains("comment aller") ||
                t.contains("emmene moi") || t.contains("emmène moi") ||
                t.contains("ou se trouve") || t.contains("où se trouve") -> Dest.MAPS

            t.contains("netflix") || t.contains("disney") || t.contains("prime video") -> Dest.STREAMING

            t.contains("google") || t.contains("duckduckgo") || t.contains("bing") ||
                t.contains("sur internet") || t.contains("sur le web") ||
                t.contains("sur le net") -> Dest.WEB

            // Verbes de recherche génériques → web, sauf si indice musique/lieu plus fort
            (t.contains("recherche") || t.contains("cherche") || t.contains("trouve moi") ||
                t.contains("c'est quoi") || t.contains("c est quoi") || t.contains("qui est") ||
                t.contains("explique") || t.contains("wikipedia")) &&
                !Regex("\\b(son|chanson|clip|musique|resto|restaurant|pharmacie|gare)\\b").containsMatchIn(t) ->
                Dest.WEB

            // Musique / vidéo
            Regex("\\b(son|chanson|titre|clip|musique|album|single|concert|clip officiel|mv)\\b")
                .containsMatchIn(t) -> Dest.YOUTUBE

            // Lieux / services de proximité
            Regex(
                "\\b(resto|restaurant|cafe|café|hotel|hôtel|pharmacie|hopital|hôpital|" +
                    "gare|aeroport|aéroport|boulangerie|supermarche|supermarché|station|essence|" +
                    "pres de moi|près de moi|a cote|à côté)\\b"
            ).containsMatchIn(t) -> Dest.MAPS

            else -> Dest.NONE
        }

        return Routed(sub, dest)
    }

    private fun stripAccents(s: String): String {
        val n = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD)
        return n.replace(Regex("\\p{Mn}+"), "")
    }
}
