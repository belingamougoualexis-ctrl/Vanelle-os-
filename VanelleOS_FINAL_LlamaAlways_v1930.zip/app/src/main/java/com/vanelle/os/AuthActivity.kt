package com.vanelle.os

import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding

/**
 * Écran inscription / connexion local (style Supabase, 100 % on-device).
 */
class AuthActivity : AppCompatActivity() {

    private var modeRegister = true
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private lateinit var nameField: EditText
    private lateinit var emailField: EditText
    private lateinit var passField: EditText
    private lateinit var primaryBtn: Button
    private lateinit var switchBtn: TextView
    private lateinit var errorTxt: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (LocalAuth.isLoggedIn(this)) {
            goMain()
            return
        }
        // Si un compte existe déjà → écran connexion par défaut
        modeRegister = !LocalAuth.hasAccount(this)
        buildUi()
        applyMode()
    }

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun buildUi() {
        val density = resources.displayMetrics.density
        val root = ScrollView(this).apply {
            setBackgroundColor(0xFFFFFFFF.toInt())
            isFillViewport = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(56), dp(28), dp(40))
            gravity = Gravity.CENTER_HORIZONTAL
        }

        // Logo / titre
        val brand = TextView(this).apply {
            text = "VanelleOS"
            setTextColor(0xFF000000.toInt())
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        col.addView(brand)

        title = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, dp(6))
        }
        col.addView(title)

        subtitle = TextView(this).apply {
            setTextColor(0xFFF5F5F5.toInt())
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(28))
        }
        col.addView(subtitle)

        fun field(hint: String, password: Boolean = false): EditText {
            return EditText(this).apply {
                this.hint = hint
                setHintTextColor(0xFF888888.toInt())
                setTextColor(0xFF000000.toInt())
                textSize = 15f
                setPadding(dp(16), dp(14), dp(16), dp(14))
                background = GradientDrawable().apply {
                    setColor(0xFFFFFFFF.toInt())
                    setStroke((1.2f * density).toInt(), 0xFF000000.toInt())
                    cornerRadius = 12f * density
                }
                if (password) {
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                } else {
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                }
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(12)
                }
            }
        }

        nameField = field("Prénom / pseudo").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PERSON_NAME
        }
        emailField = field("E-mail")
        passField = field("Mot de passe", password = true)

        col.addView(nameField)
        col.addView(emailField)
        col.addView(passField)

        errorTxt = TextView(this).apply {
            setTextColor(0xFFEF4444.toInt())
            textSize = 12.5f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(10))
            visibility = android.view.View.GONE
        }
        col.addView(errorTxt)

        primaryBtn = Button(this).apply {
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                setColor(0xFF000000.toInt())
                cornerRadius = 14f * density
            }
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = dp(8)
            }
            setOnClickListener { submit() }
        }
        col.addView(primaryBtn)

        switchBtn = TextView(this).apply {
            setTextColor(0xFF444444.toInt())
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
            setOnClickListener {
                modeRegister = !modeRegister
                errorTxt.visibility = android.view.View.GONE
                applyMode()
            }
        }
        col.addView(switchBtn)

        val localNote = TextView(this).apply {
            text = "100 % local — rien n'est envoyé sur un serveur"
            setTextColor(0xFF444444.toInt())
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, dp(32), 0, 0)
        }
        col.addView(localNote)

        root.addView(col)
        setContentView(root)
    }

    private fun applyMode() {
        if (modeRegister) {
            title.text = "Créer un compte"
            subtitle.text = "Inscription locale sur cet appareil"
            nameField.visibility = android.view.View.VISIBLE
            primaryBtn.text = "S'inscrire"
            switchBtn.text = "Déjà un compte ? Se connecter"
        } else {
            title.text = "Connexion"
            subtitle.text = "Accède à ton espace VanelleOS"
            nameField.visibility = android.view.View.GONE
            primaryBtn.text = "Se connecter"
            switchBtn.text = "Pas encore de compte ? S'inscrire"
        }
    }

    private fun submit() {
        errorTxt.visibility = android.view.View.GONE
        val email = emailField.text?.toString().orEmpty()
        val pass = passField.text?.toString().orEmpty()
        val err = if (modeRegister) {
            LocalAuth.register(this, email, pass, nameField.text?.toString().orEmpty())
        } else {
            LocalAuth.login(this, email, pass)
        }
        if (err != null) {
            errorTxt.text = err
            errorTxt.visibility = android.view.View.VISIBLE
            return
        }
        goMain()
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        })
        finish()
    }
}
