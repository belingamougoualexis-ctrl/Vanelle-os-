package com.vanelle.os

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/**
 * Personnalisation de la voix IA (TTS système) :
 * débit, hauteur, voix française installée sur l'appareil.
 */
object VoicePrefs {
    private const val PREFS = "vanelle_voice"
    private const val KEY_RATE = "speech_rate"   // 0.5 – 2.0
    private const val KEY_PITCH = "pitch"        // 0.5 – 2.0
    private const val KEY_VOICE = "voice_name"   // Voice.name or ""

    private fun p(c: Context) = c.getSharedPreferences(PREFS, 0)

    fun getRate(c: Context): Float = p(c).getFloat(KEY_RATE, 1.0f).coerceIn(0.5f, 2.0f)
    fun getPitch(c: Context): Float = p(c).getFloat(KEY_PITCH, 1.05f).coerceIn(0.5f, 2.0f)
    fun getVoiceName(c: Context): String = p(c).getString(KEY_VOICE, "") ?: ""

    fun setRate(c: Context, v: Float) {
        p(c).edit().putFloat(KEY_RATE, v.coerceIn(0.5f, 2.0f)).apply()
    }
    fun setPitch(c: Context, v: Float) {
        p(c).edit().putFloat(KEY_PITCH, v.coerceIn(0.5f, 2.0f)).apply()
    }
    fun setVoiceName(c: Context, name: String) {
        p(c).edit().putString(KEY_VOICE, name).apply()
    }

    /** Applique débit, hauteur et voix FR préférée sur une instance TTS. */
    fun apply(c: Context, tts: TextToSpeech?) {
        if (tts == null) return
        try {
            tts.language = Locale.FRANCE
            tts.setSpeechRate(getRate(c))
            tts.setPitch(getPitch(c))
            val wanted = getVoiceName(c)
            if (wanted.isNotBlank()) {
                val match = tts.voices?.firstOrNull { it.name == wanted }
                if (match != null) tts.voice = match
            } else {
                // Première voix française de qualité si possible
                val fr = tts.voices
                    ?.filter { v ->
                        val loc = v.locale ?: return@filter false
                        loc.language.equals("fr", true)
                    }
                    ?.sortedByDescending { qualityScore(it) }
                    ?.firstOrNull()
                if (fr != null) tts.voice = fr
            }
        } catch (_: Exception) {}
    }

    private fun qualityScore(v: Voice): Int {
        // Qualité plus élevée = mieux ; évite les voix réseau si possible
        var s = when (v.quality) {
            Voice.QUALITY_VERY_HIGH -> 40
            Voice.QUALITY_HIGH -> 30
            Voice.QUALITY_NORMAL -> 20
            else -> 10
        }
        if (!v.isNetworkConnectionRequired) s += 15
        if (v.locale?.country.equals("FR", true)) s += 5
        return s
    }

    /** Liste des voix françaises disponibles (pour l'UI). */
    fun listFrenchVoices(tts: TextToSpeech?): List<Voice> {
        if (tts == null) return emptyList()
        return try {
            tts.voices
                ?.filter { v ->
                    val loc = v.locale ?: return@filter false
                    loc.language.equals("fr", true)
                }
                ?.sortedByDescending { qualityScore(it) }
                ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun labelFor(v: Voice): String {
        val q = when (v.quality) {
            Voice.QUALITY_VERY_HIGH -> "très haute"
            Voice.QUALITY_HIGH -> "haute"
            Voice.QUALITY_NORMAL -> "normale"
            else -> "basique"
        }
        val net = if (v.isNetworkConnectionRequired) " · réseau" else " · hors-ligne"
        val name = v.name.substringAfterLast(":").ifBlank { v.name }
        return "${v.locale?.displayName ?: "Français"} · $q$net · $name"
    }
}
