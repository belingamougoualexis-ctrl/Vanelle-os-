package com.vanelle.os

object LegalTexts {
    const val PRIVACY_TITLE = "Politique de confidentialité"

    val PRIVACY = """
VanelleOS — Politique de confidentialité
Derniere mise a jour : aout 2026

1. Responsable
VanelleOS est une application mobile d'assistance vocale. En utilisant l'application, vous acceptez la presente politique.

2. Donnees collectees
L'application peut acceder, uniquement avec votre autorisation explicite, a :
• Le microphone (commandes vocales déclenchées par le bouton)
• Les contacts (appels et SMS par nom)
• L'envoi d'appels et de SMS (apres confirmation)
• L'affichage par-dessus d'autres applications (mascotte)
• Le service d'accessibilite (actions systeme, lecture d'ecran)
• L'etat du reseau (Wi-Fi pour telechargements)

3. Traitement local
• Les modeles d'intelligence artificielle telecharges fonctionnent en local sur votre appareil.
• Les commandes vocales sont traitées en temps réel et ne sont pas stockées de façon permanente.
• La memoire personnelle (notes que vous demandez de retenir) est chiffree sur l'appareil.

4. Donnees envoyees en ligne
• Telechargement des modeles (Wi-Fi recommande) depuis des serveurs tiers (ex. Hugging Face, GitHub).
• Recherches web / Wikipedia / traduction : uniquement le texte de votre requete est envoye au service concerne.
• Aucune publicite tierce, aucun reseau publicitaire integre.

5. Partage
Nous ne vendons pas vos donnees. Aucun compte utilisateur n'est requis. Les permissions systeme sont sous votre controle et peuvent etre revoquees dans les reglages Android.

6. Conservation
Les fichiers modeles et preferences restent sur l'appareil jusqu'a desinstallation ou suppression manuelle.

7. Securite
Communications reseau en HTTPS. Memoire sensible chiffree (AndroidX Security).

8. Vos droits
Vous pouvez a tout moment retirer les permissions, effacer la memoire dans l'application, ou desinstaller VanelleOS.

9. Contact
Pour toute question relative a la confidentialite, contactez l'editeur de l'application via la fiche de publication sur le store ou le canal de support indique lors de la publication.
""".trimIndent()

    const val TERMS_TITLE = "Conditions d'utilisation"

    val TERMS = """
VanelleOS — Conditions d'utilisation
Derniere mise a jour : aout 2026

1. Acceptation
En installant ou utilisant VanelleOS, vous acceptez les presentes conditions. Si vous n'acceptez pas, n'utilisez pas l'application.

2. Description du service
VanelleOS est un assistant vocal qui peut :
• Repondre a des questions (modele local et/ou recherche web)
• Executer des actions sur le telephone (ouvrir des apps, appeler, SMS, alarmes, etc.) apres interpretation de vos commandes
• Afficher une mascotte et lire les reponses a voix haute

3. Permissions et responsabilite de l'utilisateur
Vous etes responsable des autorisations accordees (microphone, contacts, SMS, accessibilite, overlay).
Les actions sensibles (appel, SMS) demandent une confirmation avant execution.
Vous restez responsable de l'usage que vous faites des actions declenchees.

4. Exactitude
Les reponses de l'IA peuvent etre incompletees ou incorrectes. Verifiez les informations importantes. VanelleOS ne remplace pas un conseil medical, juridique ou financier professionnel.

5. Urgences
La fonction urgence ouvre le composeur vers le 112 (ou equivalent). Elle ne garantit pas une mise en relation automatique avec les secours.

6. Propriete intellectuelle
L'application, son interface et ses elements graphiques sont proteges. Les modeles d'IA tiers restent soumis a leurs licences respectives (ex. Llama).

7. Disponibilite
Le service est fourni « en l'etat ». Certaines fonctions dependent du reseau, du materiel, ou de permissions systeme.

8. Limitation de responsabilite
Dans les limites autorisees par la loi, l'editeur ne saurait etre tenu responsable des dommages indirects, pertes de donnees ou actions executees suite a une mauvaise reconnaissance vocale, sous reserve des droits imperatifs du consommateur.

9. Modifications
Ces conditions peuvent etre mises a jour. La version en vigueur est celle affichee dans l'application.

10. Loi applicable
Sous reserve des regles imperatives de protection des consommateurs de votre pays de residence.
""".trimIndent()
}
