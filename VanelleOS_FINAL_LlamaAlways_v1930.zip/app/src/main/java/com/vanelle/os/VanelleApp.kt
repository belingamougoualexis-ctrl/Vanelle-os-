package com.vanelle.os

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class VanelleApp : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        CrashLogger.install(this)
        // Restaure mémoire / relances si Auto Backup a ramené le snapshot
        try { UserDataSnapshot.restoreIfNeeded(this) } catch (_: Exception) {}
        appScope.launch {
            try {
                NightlyConsolidation.schedule(this@VanelleApp)
            } catch (_: Exception) {}
            try { UserDataSnapshot.save(this@VanelleApp) } catch (_: Exception) {}
            // Précharge Llama si le GGUF est déjà téléchargé
            try {
                if (LlamaModelManager.isReady(this@VanelleApp)) {
                    LocalLlamaHelper.get(this@VanelleApp).warmUp()
                }
            } catch (_: Exception) {}
        }
    }
}
