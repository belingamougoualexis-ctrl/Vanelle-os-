package com.vanelle.os

import android.app.backup.BackupManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Instantané des données utilisateur + export/import pour changer de téléphone.
 * - Auto Backup Google (même compte) après activation système
 * - Fichier JSON partageable (WhatsApp, Drive, e-mail…) pour un autre appareil
 */
object UserDataSnapshot {

    private const val FILE = "vanelle_user_snapshot.json"
    private const val PREF_BACKUP_PROMPTED = "backup_prompted_v1"

    private fun file(c: Context) = File(c.filesDir, FILE)

    fun save(c: Context) {
        try {
            val o = buildJson(c)
            file(c).writeText(o.toString())
            // Signale à Android qu'il faut inclure ces données au prochain backup cloud
            try { BackupManager(c).dataChanged() } catch (_: Exception) {}
        } catch (_: Exception) {}
    }

    private fun buildJson(c: Context): JSONObject {
        val o = JSONObject()
        o.put("version", 2)
        o.put("app", "VanelleOS")
        o.put("savedAt", System.currentTimeMillis())

        val rel = c.getSharedPreferences("vanelle_relational", 0)
        o.put("relational", JSONObject().apply {
            put("facts", rel.getString("facts", "[]"))
            put("dialog", rel.getString("dialog", "[]"))
            put("mood_ts", rel.getLong("mood_ts", 0L))
        })

        val relance = c.getSharedPreferences("vanelle_relances", 0)
        o.put("relances", JSONObject().apply {
            put("tasks", relance.getString("tasks", "[]"))
            put("history", relance.getString("history", "[]"))
        })

        val prefs = c.getSharedPreferences("vanelle_prefs", 0)
        o.put("prefs", JSONObject().apply {
            for ((k, v) in prefs.all) {
                when (v) {
                    is String -> put(k, v)
                    is Boolean -> put(k, v)
                    is Int -> put(k, v)
                    is Long -> put(k, v)
                    is Float -> put(k, v.toDouble())
                }
            }
        })

        // Identité affichable (pas le mot de passe)
        try {
            val user = LocalAuth.currentUser(c)
            if (user != null) {
                o.put("account", JSONObject().apply {
                    put("email", user.email)
                    put("display_name", user.displayName)
                })
            } else {
                val fallback = c.getSharedPreferences("vanelle_local_auth_fallback", 0)
                o.put("account", JSONObject().apply {
                    put("email", fallback.getString("email", "") ?: "")
                    put("display_name", fallback.getString("display_name", "") ?: "")
                })
            }
        } catch (_: Exception) {}

        return o
    }

    fun restoreIfNeeded(c: Context) {
        try {
            val f = file(c)
            if (!f.exists()) return
            applyJson(c, JSONObject(f.readText()), onlyIfEmpty = true)
        } catch (_: Exception) {}
    }

    /** Restaure depuis un fichier choisi (changement de téléphone). */
    fun importFromUri(c: Context, uri: Uri): String {
        return try {
            val text = c.contentResolver.openInputStream(uri)?.use { ins ->
                BufferedReader(InputStreamReader(ins)).readText()
            } ?: return "Impossible de lire le fichier."
            val o = JSONObject(text)
            if (o.optString("app") != "VanelleOS" && !o.has("relational")) {
                return "Ce fichier n'est pas une sauvegarde VanelleOS."
            }
            applyJson(c, o, onlyIfEmpty = false)
            save(c)
            "Données restaurées. Mémoire, relances et préférences sont de retour."
        } catch (e: Exception) {
            "Import impossible : ${e.message ?: "fichier invalide"}."
        }
    }

    private fun applyJson(c: Context, o: JSONObject, onlyIfEmpty: Boolean) {
        val rel = c.getSharedPreferences("vanelle_relational", 0)
        val r = o.optJSONObject("relational")
        if (r != null && (!onlyIfEmpty || rel.getString("facts", "[]") == "[]")) {
            rel.edit()
                .putString("facts", r.optString("facts", "[]"))
                .putString("dialog", r.optString("dialog", "[]"))
                .putLong("mood_ts", r.optLong("mood_ts", 0L))
                .apply()
        }

        val relance = c.getSharedPreferences("vanelle_relances", 0)
        val rl = o.optJSONObject("relances")
        if (rl != null && (!onlyIfEmpty || relance.getString("tasks", "[]") == "[]")) {
            relance.edit()
                .putString("tasks", rl.optString("tasks", "[]"))
                .putString("history", rl.optString("history", "[]"))
                .apply()
        }

        val prefs = c.getSharedPreferences("vanelle_prefs", 0)
        val p = o.optJSONObject("prefs")
        if (p != null && (!onlyIfEmpty || prefs.all.isEmpty())) {
            val ed = prefs.edit()
            val keys = p.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                when (val v = p.get(k)) {
                    is String -> ed.putString(k, v)
                    is Boolean -> ed.putBoolean(k, v)
                    is Int -> ed.putInt(k, v)
                    is Long -> ed.putLong(k, v)
                    is Double -> ed.putFloat(k, v.toFloat())
                }
            }
            ed.apply()
        }
    }

    /**
     * Exporte vers un fichier partageable (Drive, e-mail, autre téléphone).
     * Retourne le File créé dans le cache, prêt pour ACTION_SEND.
     */
    fun createShareFile(c: Context): File {
        save(c)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        val out = File(c.cacheDir, "VanelleOS_sauvegarde_$stamp.json")
        out.writeText(buildJson(c).toString(2))
        return out
    }

    fun shareIntent(c: Context): Intent {
        val f = createShareFile(c)
        val uri = androidx.core.content.FileProvider.getUriForFile(
            c, "${c.packageName}.fileprovider", f
        )
        return Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Sauvegarde VanelleOS")
            putExtra(
                Intent.EXTRA_TEXT,
                "Sauvegarde VanelleOS — importe ce fichier dans Configuration → Importer mes données sur ton nouvel appareil."
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    /** Ouvre les réglages de sauvegarde système / Google. */
    fun openSystemBackupSettings(c: Context) {
        val intents = listOf(
            Intent(Settings.ACTION_PRIVACY_SETTINGS),
            Intent(Settings.ACTION_SYNC_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
        // Tentative ciblée Android 12+
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                c.startActivity(
                    Intent("android.settings.BACKUP_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            } catch (_: Exception) {}
        }
        for (i in intents) {
            try {
                c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: Exception) {}
        }
    }

    fun wasBackupPrompted(c: Context): Boolean =
        c.getSharedPreferences("vanelle_prefs", 0).getBoolean(PREF_BACKUP_PROMPTED, false)

    fun setBackupPrompted(c: Context) {
        c.getSharedPreferences("vanelle_prefs", 0).edit()
            .putBoolean(PREF_BACKUP_PROMPTED, true).apply()
    }
}
