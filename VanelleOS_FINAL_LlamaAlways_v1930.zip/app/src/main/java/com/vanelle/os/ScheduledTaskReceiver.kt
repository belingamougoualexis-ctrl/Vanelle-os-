package com.vanelle.os
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

class ScheduledTaskReceiver:BroadcastReceiver(){
    override fun onReceive(context:Context,intent:Intent){
        val taskId=intent.getLongExtra("task_id",-1L)
        if(taskId==-1L) return
        val pending=goAsync()
        CoroutineScope(Dispatchers.IO).launch{
            try{
                val repo=RelanceRepository(context)
                val task=repo.getTask(taskId)
                if(task!=null){
                    // Les routines encodent "routine:<id>|<actions>" dans la description
                    // (voir RoutineManager.add) : on retire ce prefixe technique avant
                    // toute annonce ou execution, sinon l'utilisateur l'entendrait/le verrait.
                    val spoken=if(task.description.startsWith("routine:")) task.description.substringAfter("|",task.description) else task.description
                    val parsed=CommandParser.parse(spoken)
                    val res:String
                    if(parsed.intent==CommandIntent.UNKNOWN){
                        // Pas une action reconnue (appel/sms/app...) -> simple rappel annonce, pas de recherche web inutile
                        announce(context,spoken)
                        res="Rappel annonce"
                    }else{
                        // Action reconnue (appel, sms, ouverture d'app...) : executee directement,
                        // sans demande de confirmation -> uniquement les relances fonctionnent ainsi.
                        res=CommandInterpreter(context).execute(spoken)
                    }
                    repo.addHistory(spoken,System.currentTimeMillis(),res)
                    if(task.repeatDaily) AlarmScheduler.scheduleNext(context,task) else repo.removeTask(taskId)
                }
            }catch(_:Exception){
            }finally{ pending.finish() }
        }
    }

    private suspend fun announce(context:Context,text:String){
        try{
            val id="vanelle_relance"
            val nm=context.getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(NotificationChannel(id,"Relances",NotificationManager.IMPORTANCE_HIGH))
            val n=NotificationCompat.Builder(context,id).setContentTitle("Relance VanelleOS").setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
            nm?.notify(text.hashCode(),n)
        }catch(_:Exception){}
        try{
            var tts:TextToSpeech?=null
            tts=TextToSpeech(context){ status->
                if(status==TextToSpeech.SUCCESS){
                    tts?.language=Locale.FRANCE
                    VoicePrefs.apply(context, tts)
                    tts?.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
                        override fun onStart(id:String?){}
                        override fun onDone(id:String?){ tts?.shutdown() }
                        override fun onError(id:String?){ tts?.shutdown() }
                    })
                    tts?.speak(text,TextToSpeech.QUEUE_FLUSH,null,"relance_${System.currentTimeMillis()}")
                }
            }
            delay(6000)
        }catch(_:Exception){}
    }
}
