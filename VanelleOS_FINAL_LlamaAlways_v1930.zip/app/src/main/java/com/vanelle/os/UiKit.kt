package com.vanelle.os
import android.content.Context
import android.graphics.drawable.GradientDrawable

/** Palette VanelleOS : blanc / noir (écriture noire sur fond blanc). */
object UiKit {
    const val FOREST = 0xFF000000.toInt()
    const val EMERALD = 0xFF000000.toInt()
    const val TURQUOISE = 0xFF222222.toInt()
    const val WHITE = 0xFFFFFFFF.toInt()
    const val MINT = 0xFFF5F5F5.toInt()
    const val TEXT_MUTED = 0xFF444444.toInt()
    const val TEXT_DARK = 0xFF000000.toInt()
    const val BLACK = 0xFF000000.toInt()

    fun card(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(WHITE)
            setStroke((1.5f * d).toInt(), BLACK)
            cornerRadius = 8f * d
        }
    }
    fun selected(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(MINT)
            setStroke((2f * d).toInt(), BLACK)
            cornerRadius = 8f * d
        }
    }
    fun pill(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(WHITE)
            setStroke((1.5f * d).toInt(), BLACK)
            cornerRadius = 20f * d
        }
    }
}
