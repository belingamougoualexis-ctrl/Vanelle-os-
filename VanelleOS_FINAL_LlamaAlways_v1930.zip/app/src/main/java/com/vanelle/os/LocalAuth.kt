package com.vanelle.os

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Authentification locale style « Supabase » : inscription / connexion
 * entièrement sur l'appareil (EncryptedSharedPreferences).
 * Aucun serveur, aucun réseau requis.
 */
object LocalAuth {

    private const val PREFS = "vanelle_local_auth"
    private const val KEY_EMAIL = "email"
    private const val KEY_SALT = "salt"
    private const val KEY_HASH = "hash"
    private const val KEY_DISPLAY = "display_name"
    private const val KEY_SESSION = "session_active"
    private const val ITERATIONS = 120_000
    private const val KEY_LEN = 256

    data class User(val email: String, val displayName: String)

    private fun prefs(c: Context) = try {
        val master = MasterKey.Builder(c)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            c,
            PREFS,
            master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (_: Exception) {
        // Fallback non chiffré si le keystore est indisponible (émulateurs rares)
        c.getSharedPreferences(PREFS + "_fallback", Context.MODE_PRIVATE)
    }

    fun hasAccount(c: Context): Boolean {
        val p = prefs(c)
        return !p.getString(KEY_EMAIL, null).isNullOrBlank() &&
            !p.getString(KEY_HASH, null).isNullOrBlank()
    }

    fun isLoggedIn(c: Context): Boolean =
        hasAccount(c) && prefs(c).getBoolean(KEY_SESSION, false)

    fun currentUser(c: Context): User? {
        if (!isLoggedIn(c)) return null
        val p = prefs(c)
        val email = p.getString(KEY_EMAIL, null) ?: return null
        val name = p.getString(KEY_DISPLAY, null) ?: email.substringBefore("@")
        return User(email, name)
    }

    /**
     * Crée le compte local. Un seul compte par appareil (style profil local).
     * @return null si OK, sinon message d'erreur
     */
    fun register(c: Context, email: String, password: String, displayName: String): String? {
        val e = email.trim().lowercase()
        val name = displayName.trim().ifBlank { e.substringBefore("@") }
        if (!isValidEmail(e)) return "Adresse e-mail invalide"
        if (password.length < 6) return "Mot de passe trop court (6 caractères min.)"
        if (hasAccount(c)) return "Un compte existe déjà sur cet appareil. Connecte-toi."

        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = hashPassword(password, salt)
        prefs(c).edit()
            .putString(KEY_EMAIL, e)
            .putString(KEY_DISPLAY, name)
            .putString(KEY_SALT, salt.toHex())
            .putString(KEY_HASH, hash.toHex())
            .putBoolean(KEY_SESSION, true)
            .apply()
        try { UserDataSnapshot.save(c) } catch (_: Exception) {}
        return null
    }

    /**
     * Connexion.
     * @return null si OK, sinon message d'erreur
     */
    fun login(c: Context, email: String, password: String): String? {
        if (!hasAccount(c)) return "Aucun compte sur cet appareil. Inscris-toi d'abord."
        val p = prefs(c)
        val storedEmail = p.getString(KEY_EMAIL, "") ?: ""
        if (email.trim().lowercase() != storedEmail) return "E-mail ou mot de passe incorrect"
        val saltHex = p.getString(KEY_SALT, null) ?: return "Compte corrompu"
        val hashHex = p.getString(KEY_HASH, null) ?: return "Compte corrompu"
        val salt = saltHex.fromHex()
        val expected = hashHex.fromHex()
        val actual = hashPassword(password, salt)
        if (!actual.contentEquals(expected)) return "E-mail ou mot de passe incorrect"
        p.edit().putBoolean(KEY_SESSION, true).apply()
        try { UserDataSnapshot.save(c) } catch (_: Exception) {}
        return null
    }

    fun logout(c: Context) {
        prefs(c).edit().putBoolean(KEY_SESSION, false).apply()
    }

    /** Supprime le compte local (données d'auth uniquement). */
    fun deleteAccount(c: Context) {
        prefs(c).edit().clear().apply()
    }

    private fun isValidEmail(e: String): Boolean =
        e.contains("@") && e.substringAfter("@").contains(".") && e.length >= 5

    private fun hashPassword(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LEN)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return factory.generateSecret(spec).encoded
    }

    private fun ByteArray.toHex(): String =
        joinToString("") { b -> "%02x".format(b) }

    private fun String.fromHex(): ByteArray {
        val len = length
        val out = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            out[i / 2] = ((this[i].digitToInt(16) shl 4) + this[i + 1].digitToInt(16)).toByte()
            i += 2
        }
        return out
    }
}
