package com.vanelle.os

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Process
import android.util.Log
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.util.ArrayDeque
import kotlinx.coroutines.*

/**
 * Android streaming implementation of the openWakeWord pipeline.
 *
 * Pipeline (matching the official openWakeWord feature flow):
 *   16 kHz / mono / signed 16-bit PCM
 *       -> mel spectrogram
 *       -> 76 x 32 mel window, advanced every 80 ms
 *       -> 96-dim embedding
 *       -> last 16 embeddings
 *       -> custom wake-word classifier
 *
 * Important: the mel output is transformed with `x / 10 + 2`, as in the
 * official openWakeWord implementation. Do not normalize PCM to [-1, 1]
 * before the mel model; the feature extractor expects int16 PCM semantics.
 *
 * Android-specific:
 *   - AudioRecord runs in a foreground microphone service.
 *   - Inference runs off the main thread.
 *   - TFLite XNNPACK is disabled for the dynamic mel model; the input is
 *     explicitly resized to [1, 1280] before allocateTensors().
 *   - Audio frames are accumulated so partial AudioRecord reads cannot
 *     corrupt the 80 ms feature cadence.
 */
class OpenWakeWordDetector(private val context: Context) {

    companion object {
        private const val TAG = "OpenWakeWord"
        private const val SAMPLE_RATE = 16_000
        private const val CHUNK_SAMPLES = 1_280 // 80 ms
        private const val MEL_BINS = 32
        private const val EMB_WINDOW = 76
        private const val EMB_STEP = 8
        private const val EMB_DIM = 96
        private const val CLASSIFIER_WINDOW = 16

        // The classifier is a custom model; 0.5 is the openWakeWord-style
        // starting point. It can be changed after measuring real false-positive
        // / false-negative rates, but should not be lowered just to compensate
        // for a broken feature pipeline.
        private const val THRESHOLD = 0.50f
        private const val COOLDOWN_MS = 2_000L

        // The official streaming implementation keeps enough raw history to
        // recompute the mel window with the required left context.
        private const val RAW_HISTORY_SAMPLES = SAMPLE_RATE * 10
        private const val MEL_HISTORY_FRAMES = 10 * 97
        private const val MEL_LEFT_CONTEXT_SAMPLES = 480

        // A very low-energy frame is ignored only for diagnostics; the PCM is
        // never amplified or otherwise altered before openWakeWord inference.
        private const val ENERGY_FLOOR = 8.0

        private const val FALLBACK_EMB_WINDOW = 76
        private const val FALLBACK_MEL_BINS = 32
    }

    private var melInterp: Interpreter? = null
    private var embInterp: Interpreter? = null
    private var clsInterp: Interpreter? = null

    private var record: AudioRecord? = null
    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val rawDataBuffer = ArrayDeque<Short>(RAW_HISTORY_SAMPLES)
    private val melBuffer = ArrayDeque<FloatArray>()
    private val featureBuffer = ArrayDeque<FloatArray>()
    private var pendingAudio = ShortArray(0)

    private var embFrameWindow = EMB_WINDOW
    private var embMelBins = MEL_BINS
    private var embOutDim = EMB_DIM

    @Volatile private var lastDetectAt = 0L
    private var lastErrorLoggedAt = 0L
    private var lastErrorLoggedMsg = ""

    private fun options() = Interpreter.Options().apply {
        // openWakeWord's mel TFLite model can have a dynamic input shape.
        // Android's delegate may try to allocate the dynamic graph too early.
        try { setUseXNNPACK(false) } catch (_: Throwable) {}
    }

    private fun mapModel(file: File): ByteBuffer {
        FileInputStream(file).use { fis ->
            val channel = fis.channel
            return channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
        }
    }

    private fun loadModel(file: File): Interpreter? {
        return try {
            if (!file.exists() || file.length() < 50_000L) return null
            Interpreter(mapModel(file), options()).also {
                try { it.allocateTensors() } catch (_: Throwable) {}
            }
        } catch (e: Exception) {
            Log.e(TAG, "loadModel(${file.name}): ${e.message}", e)
            null
        }
    }

    private fun loadMelModel(file: File): Interpreter? {
        return try {
            if (!file.exists()) return null
            val interp = Interpreter(mapModel(file), options())
            // Android must resize the dynamic mel model before allocation.
            // We use a fixed 1760-sample streaming window (1280 new samples +
            // 480 samples of left context) so the interpreter shape never
            // changes during the listening loop.
            interp.resizeInput(0, intArrayOf(1, CHUNK_SAMPLES + MEL_LEFT_CONTEXT_SAMPLES), true)
            interp.allocateTensors()
            interp
        } catch (e: Exception) {
            Log.e(TAG, "loadMelModel: ${e.message}", e)
            WakeWordDiagnostics.log(
                context, TAG,
                "ERREUR chargement mel/resize [1,1280]: ${e.message ?: e.javaClass.simpleName}"
            )
            null
        }
    }

    private fun loadClassifier(): Interpreter? {
        return try {
            val afd = context.assets.openFd("wakeword_classifier.tflite")
            FileInputStream(afd.fileDescriptor).use { fis ->
                val buffer = fis.channel.map(
                    FileChannel.MapMode.READ_ONLY,
                    afd.startOffset,
                    afd.declaredLength
                )
                Interpreter(buffer, options()).also {
                    try { it.allocateTensors() } catch (_: Throwable) {}
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "loadClassifier: ${e.message}", e)
            null
        }
    }

    fun prepare(): Boolean {
        if (!WakeWordModelManager.isReady(context)) return false

        closeInterpreters()

        melInterp = loadMelModel(WakeWordModelManager.melFile(context))
        embInterp = loadModel(WakeWordModelManager.embFile(context))
        clsInterp = loadClassifier()

        if (melInterp == null || embInterp == null || clsInterp == null) {
            closeInterpreters()
            WakeWordDiagnostics.log(
                context, TAG,
                "prepare ÉCHEC: mel=${melInterp != null}, embedding=${embInterp != null}, classifier=${clsInterp != null}"
            )
            return false
        }

        try {
            val input = embInterp!!.getInputTensor(0)
            var shape = input.shape()
            if (shape.size != 4 || shape[1] <= 0 || shape[2] <= 0) {
                embInterp!!.resizeInput(0, intArrayOf(1, EMB_WINDOW, MEL_BINS, 1), true)
                embInterp!!.allocateTensors()
                shape = embInterp!!.getInputTensor(0).shape()
            }
            embFrameWindow = if (shape.size >= 2 && shape[1] > 0) shape[1] else FALLBACK_EMB_WINDOW
            embMelBins = if (shape.size >= 3 && shape[2] > 0) shape[2] else FALLBACK_MEL_BINS

            val outShape = embInterp!!.getOutputTensor(0).shape()
            embOutDim = outShape.fold(1) { acc, d -> if (d > 0) acc * d else acc }
            if (embOutDim <= 0) embOutDim = EMB_DIM

            val clsInput = clsInterp!!.getInputTensor(0)
            val clsShape = clsInput.shape()
            if (clsShape.size < 3 || clsShape.any { it <= 0 }) {
                clsInterp!!.resizeInput(0, intArrayOf(1, CLASSIFIER_WINDOW, embOutDim), true)
                clsInterp!!.allocateTensors()
            }

            WakeWordDiagnostics.log(
                context, TAG,
                "prepare OK: mel=[1,1760], embedding=${shape.toList()} -> $embOutDim, classifier=${clsInterp!!.getInputTensor(0).shape().toList()}"
            )
            return true
        } catch (e: Exception) {
            Log.e(TAG, "prepare shapes: ${e.message}", e)
            WakeWordDiagnostics.log(context, TAG, "ERREUR formes TFLite: ${e.message}")
            closeInterpreters()
            return false
        }
    }

    @Suppress("MissingPermission")
    fun start(onDetected: () -> Unit) {
        stop()

        if (!prepare()) {
            WakeWordDiagnostics.log(context, TAG, "start annulé: modèles/interpréteurs indisponibles")
            return
        }

        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            WakeWordDiagnostics.log(context, TAG, "AudioRecord incompatible: minBuffer=$minBuffer")
            return
        }

        val bufferSize = maxOf(
            minBuffer,
            CHUNK_SAMPLES * 4 * 2 // enough room for scheduling jitter
        )

        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
        } catch (e: Exception) {
            WakeWordDiagnostics.log(context, TAG, "ERREUR création AudioRecord: ${e.message}")
            return
        }

        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            WakeWordDiagnostics.log(context, TAG, "AudioRecord STATE_UNINITIALIZED")
            return
        }

        record = rec
        try {
            rec.startRecording()
        } catch (e: Exception) {
            rec.release()
            record = null
            WakeWordDiagnostics.log(context, TAG, "ERREUR startRecording: ${e.message}")
            return
        }

        resetStreamingState()

        job = scope.launch {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)

            val readBuffer = ShortArray(CHUNK_SAMPLES * 2)

            while (isActive) {
                val n = try {
                    rec.read(readBuffer, 0, readBuffer.size, AudioRecord.READ_BLOCKING)
                } catch (e: Exception) {
                    logInferenceError("AudioRecord.read: ${e.message}")
                    -1
                }

                if (n <= 0) {
                    delay(5)
                    continue
                }

                appendPending(readBuffer, n)

                while (pendingAudio.size >= CHUNK_SAMPLES && isActive) {
                    val chunk = pendingAudio.copyOfRange(0, CHUNK_SAMPLES)
                    pendingAudio = pendingAudio.copyOfRange(CHUNK_SAMPLES, pendingAudio.size)

                    processChunk(chunk, onDetected)
                }
            }
        }

        WakeWordDiagnostics.log(
            context, TAG,
            "écoute démarrée: PCM 16kHz mono int16, chunks=$CHUNK_SAMPLES, emb=$embFrameWindow x $embMelBins"
        )
    }

    private fun appendPending(src: ShortArray, count: Int) {
        if (count <= 0) return
        val merged = ShortArray(pendingAudio.size + count)
        pendingAudio.copyInto(merged)
        src.copyInto(merged, pendingAudio.size, 0, count)
        pendingAudio = merged
    }

    private fun processChunk(chunk: ShortArray, onDetected: () -> Unit) {
        rawDataBuffer.addAll(chunk.toList())
        while (rawDataBuffer.size > RAW_HISTORY_SAMPLES) rawDataBuffer.removeFirst()

        val melInputSize = CHUNK_SAMPLES + MEL_LEFT_CONTEXT_SAMPLES
        val raw = ShortArray(melInputSize)
        // Match the streaming left context while keeping a stable TFLite
        // input shape on Android. At startup, missing context is silence.
        val available = minOf(rawDataBuffer.size, melInputSize)
        val skip = rawDataBuffer.size - available
        val destinationStart = melInputSize - available
        rawDataBuffer.forEachIndexed { i, v ->
            if (i >= skip) raw[destinationStart + (i - skip)] = v
        }

        // The official feature pipeline computes the mel spectrum from the
        // newest chunk plus left context, then appends those frames.
        val melFrames = runMel(raw) ?: return
        for (frame in melFrames) {
            melBuffer.addLast(frame)
        }
        while (melBuffer.size > MEL_HISTORY_FRAMES) melBuffer.removeFirst()

        // The official streaming implementation advances the embedding window
        // by 8 mel frames (80 ms) while keeping the mel history intact. This
        // produces one new 96-D embedding for each 80 ms audio update.
        if (melBuffer.size >= embFrameWindow) {
            val window = melBuffer.takeLast(embFrameWindow)
            val emb = runEmbedding(window) ?: return
            featureBuffer.addLast(emb)
            while (featureBuffer.size > 120) featureBuffer.removeFirst()

            if (featureBuffer.size >= CLASSIFIER_WINDOW) {
                val score = runClassifier(featureBuffer.takeLast(CLASSIFIER_WINDOW)) ?: return
                if (score >= THRESHOLD) {
                    val now = System.currentTimeMillis()
                    if (now - lastDetectAt >= COOLDOWN_MS) {
                        lastDetectAt = now
                        Log.i(TAG, "WAKE DETECTED score=$score")
                        WakeWordDiagnostics.log(
                            context, TAG,
                            "MOT D'ACTIVATION DÉTECTÉ score=$score"
                        )
                        resetAfterDetection()
                        scope.launch(Dispatchers.Main.immediate) { onDetected() }
                    }
                }
            }
        }
    }

    private fun runMel(pcm: ShortArray): List<FloatArray>? {
        val interp = melInterp ?: return null
        return try {
            val inputTensor = interp.getInputTensor(0)
            val expected = inputTensor.shape().fold(1) { a, b -> a * b }
            if (expected != pcm.size) {
                // The official model is fixed to 1280 for streaming. If the
                // model reports another size, do not silently feed a corrupt frame.
                WakeWordDiagnostics.log(
                    context, TAG,
                    "mel input inattendu: ${inputTensor.shape().toList()} pour ${pcm.size} samples"
                )
                return null
            }

            val inBuf = ByteBuffer.allocateDirect(pcm.size * 2)
                .order(ByteOrder.nativeOrder())
            for (v in pcm) inBuf.putShort(v)
            inBuf.rewind()

            val outTensor = interp.getOutputTensor(0)
            val outShape = outTensor.shape()
            val count = outShape.fold(1) { a, b -> a * b }
            val outBuf = ByteBuffer.allocateDirect(count * 4)
                .order(ByteOrder.nativeOrder())

            interp.run(inBuf, outBuf)
            outBuf.rewind()
            val values = FloatArray(count)
            outBuf.asFloatBuffer().get(values)

            // Match openWakeWord's preprocessing exactly.
            for (i in values.indices) values[i] = values[i] / 10f + 2f

            val bins = if (outShape.isNotEmpty()) outShape.last() else MEL_BINS
            if (bins <= 0 || count % bins != 0) return null

            val frames = count / bins
            val result = ArrayList<FloatArray>(frames)
            for (f in 0 until frames) {
                result.add(FloatArray(bins) { b -> values[f * bins + b] })
            }
            result
        } catch (e: Exception) {
            logInferenceError("mel: ${e.message}")
            null
        }
    }

    private fun runEmbedding(window: List<FloatArray>): FloatArray? {
        val interp = embInterp ?: return null
        return try {
            val flatCount = embFrameWindow * embMelBins
            val inBuf = ByteBuffer.allocateDirect(flatCount * 4)
                .order(ByteOrder.nativeOrder())

            for (t in 0 until embFrameWindow) {
                val frame = window[t]
                for (b in 0 until embMelBins) {
                    inBuf.putFloat(if (b < frame.size) frame[b] else 0f)
                }
            }
            inBuf.rewind()

            val outCount = interp.getOutputTensor(0).shape()
                .fold(1) { a, b -> if (b > 0) a * b else a }
            val outBuf = ByteBuffer.allocateDirect(outCount * 4)
                .order(ByteOrder.nativeOrder())

            interp.run(inBuf, outBuf)
            outBuf.rewind()
            val out = FloatArray(outCount)
            outBuf.asFloatBuffer().get(out)

            if (out.size == EMB_DIM) out
            else if (out.size >= EMB_DIM) out.copyOf(EMB_DIM)
            else out.copyOf(EMB_DIM)
        } catch (e: Exception) {
            logInferenceError("embedding: ${e.message}")
            null
        }
    }

    private fun runClassifier(features: List<FloatArray>): Float? {
        val interp = clsInterp ?: return null
        return try {
            val inBuf = ByteBuffer.allocateDirect(CLASSIFIER_WINDOW * embOutDim * 4)
                .order(ByteOrder.nativeOrder())

            for (frame in features.takeLast(CLASSIFIER_WINDOW)) {
                for (i in 0 until embOutDim) {
                    inBuf.putFloat(if (i < frame.size) frame[i] else 0f)
                }
            }
            inBuf.rewind()

            val outShape = interp.getOutputTensor(0).shape()
            val outCount = outShape.fold(1) { a, b -> if (b > 0) a * b else a }
            val outBuf = ByteBuffer.allocateDirect(outCount * 4)
                .order(ByteOrder.nativeOrder())

            interp.run(inBuf, outBuf)
            outBuf.rewind()
            val scores = FloatArray(outCount)
            outBuf.asFloatBuffer().get(scores)
            scores.firstOrNull()?.coerceIn(0f, 1f)
        } catch (e: Exception) {
            logInferenceError("classifier: ${e.message}")
            null
        }
    }

    private fun resetStreamingState() {
        rawDataBuffer.clear()
        melBuffer.clear()
        featureBuffer.clear()
        pendingAudio = ShortArray(0)

        // Official openWakeWord initializes this feature history with a
        // 76x32 mel context. This avoids feeding an incomplete embedding
        // during startup.
        repeat(EMB_WINDOW) {
            melBuffer.addLast(FloatArray(MEL_BINS) { 1f })
        }
    }

    private fun resetAfterDetection() {
        // Equivalent to openWakeWord's reset(): prevent the previous
        // activation's residual features from immediately retriggering.
        resetStreamingState()
    }

    private fun logInferenceError(message: String) {
        val now = System.currentTimeMillis()
        if (message != lastErrorLoggedMsg || now - lastErrorLoggedAt > 5_000L) {
            lastErrorLoggedMsg = message
            lastErrorLoggedAt = now
            Log.w(TAG, message)
            WakeWordDiagnostics.log(context, TAG, "ERREUR: $message")
        }
    }

    fun stop() {
        job?.cancel()
        job = null

        try { record?.stop() } catch (_: Exception) {}
        try { record?.release() } catch (_: Exception) {}
        record = null

        resetStreamingState()
        closeInterpreters()
    }

    private fun closeInterpreters() {
        try { melInterp?.close() } catch (_: Exception) {}
        try { embInterp?.close() } catch (_: Exception) {}
        try { clsInterp?.close() } catch (_: Exception) {}
        melInterp = null
        embInterp = null
        clsInterp = null
    }
}
