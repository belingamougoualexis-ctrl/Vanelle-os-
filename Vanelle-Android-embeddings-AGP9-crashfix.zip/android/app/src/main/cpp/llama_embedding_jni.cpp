#include <jni.h>
#include <android/log.h>
#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <algorithm>
#include <mutex>
#include <string>
#include <vector>

#include "llama.h"

namespace {
constexpr const char * TAG = "VanelleEmbedding";

struct EmbeddingContext {
    llama_model * model = nullptr;
    llama_context * ctx = nullptr;
    int32_t dimension = 0;
    std::mutex mutex;
};

void throwJava(JNIEnv * env, const char * message) {
    jclass ex = env->FindClass("java/lang/IllegalStateException");
    if (ex != nullptr) {
        env->ThrowNew(ex, message);
    }
}

void freeContext(EmbeddingContext * engine) {
    if (engine == nullptr) return;
    if (engine->ctx != nullptr) {
        llama_free(engine->ctx);
        engine->ctx = nullptr;
    }
    if (engine->model != nullptr) {
        llama_model_free(engine->model);
        engine->model = nullptr;
    }
}

std::vector<llama_token> tokenize(const llama_vocab * vocab, const std::string & text) {
    int32_t capacity = static_cast<int32_t>(text.size()) + 16;
    std::vector<llama_token> tokens(static_cast<size_t>(capacity));

    int32_t count = llama_tokenize(
        vocab,
        text.c_str(),
        static_cast<int32_t>(text.size()),
        tokens.data(),
        capacity,
        true,
        false
    );

    if (count < 0) {
        capacity = -count;
        tokens.resize(static_cast<size_t>(capacity));
        count = llama_tokenize(
            vocab,
            text.c_str(),
            static_cast<int32_t>(text.size()),
            tokens.data(),
            capacity,
            true,
            false
        );
    }

    if (count <= 0) {
        throw std::runtime_error("llama.cpp n'a produit aucun token pour le texte fourni.");
    }

    tokens.resize(static_cast<size_t>(count));
    return tokens;
}

} // namespace

extern "C" JNIEXPORT jlong JNICALL
Java_com_vanelle_app_EmbeddingEngine_nativeCreate(
    JNIEnv * env,
    jobject,
    jstring modelPath,
    jint contextSize,
    jint threads
) {
    const char * pathChars = env->GetStringUTFChars(modelPath, nullptr);
    if (pathChars == nullptr) return 0;
    const std::string path(pathChars);
    env->ReleaseStringUTFChars(modelPath, pathChars);

    auto * engine = new EmbeddingContext();

    llama_backend_init();

    llama_model_params modelParams = llama_model_default_params();
    modelParams.n_gpu_layers = 0;

    engine->model = llama_model_load_from_file(path.c_str(), modelParams);
    if (engine->model == nullptr) {
        delete engine;
        throwJava(env, "Impossible de charger le modèle Nomic GGUF avec llama.cpp.");
        return 0;
    }

    const llama_vocab * vocab = llama_model_get_vocab(engine->model);
    if (vocab == nullptr) {
        freeContext(engine);
        delete engine;
        throwJava(env, "Vocabulaire du modèle d'embedding introuvable.");
        return 0;
    }

    const int32_t trainContext = llama_model_n_ctx_train(engine->model);
    const uint32_t requestedContext = static_cast<uint32_t>(contextSize > 0 ? contextSize : 2048);
    const uint32_t actualContext = trainContext > 0
        ? std::min<uint32_t>(requestedContext, static_cast<uint32_t>(trainContext))
        : requestedContext;

    llama_context_params ctxParams = llama_context_default_params();
    ctxParams.n_ctx = actualContext;
    ctxParams.n_batch = actualContext;
    ctxParams.n_ubatch = actualContext;
    ctxParams.n_seq_max = 1;
    ctxParams.n_threads = threads > 0 ? threads : 2;
    ctxParams.n_threads_batch = threads > 0 ? threads : 2;
    ctxParams.pooling_type = LLAMA_POOLING_TYPE_MEAN;
    ctxParams.attention_type = LLAMA_ATTENTION_TYPE_NON_CAUSAL;
    ctxParams.embeddings = true;

    engine->ctx = llama_init_from_model(engine->model, ctxParams);
    if (engine->ctx == nullptr) {
        freeContext(engine);
        delete engine;
        throwJava(env, "Impossible de créer le contexte llama.cpp pour les embeddings.");
        return 0;
    }

    engine->dimension = llama_model_n_embd(engine->model);
    if (engine->dimension <= 0) {
        freeContext(engine);
        delete engine;
        throwJava(env, "Dimension d'embedding invalide.");
        return 0;
    }

    return reinterpret_cast<jlong>(engine);
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_vanelle_app_EmbeddingEngine_nativeEmbed(
    JNIEnv * env,
    jobject,
    jlong handle,
    jstring text
) {
    auto * engine = reinterpret_cast<EmbeddingContext *>(handle);
    if (engine == nullptr || engine->ctx == nullptr || engine->model == nullptr) {
        throwJava(env, "Moteur d'embedding non initialisé.");
        return nullptr;
    }

    const char * textChars = env->GetStringUTFChars(text, nullptr);
    if (textChars == nullptr) return nullptr;
    const std::string input(textChars);
    env->ReleaseStringUTFChars(text, textChars);

    if (input.empty()) {
        throwJava(env, "Le texte à encoder ne peut pas être vide.");
        return nullptr;
    }

    std::lock_guard<std::mutex> lock(engine->mutex);

    try {
        const llama_vocab * vocab = llama_model_get_vocab(engine->model);
        auto tokens = tokenize(vocab, input);

        const uint32_t nCtx = llama_n_ctx(engine->ctx);
        if (tokens.size() > nCtx) {
            throw std::runtime_error("Le texte dépasse la fenêtre de contexte du modèle d'embedding.");
        }

        llama_memory_clear(llama_get_memory(engine->ctx), true);

        llama_batch batch = llama_batch_init(
            static_cast<int32_t>(tokens.size()),
            0,
            1
        );

        for (size_t i = 0; i < tokens.size(); ++i) {
            batch.token[i] = tokens[i];
            batch.pos[i] = static_cast<llama_pos>(i);
            batch.n_seq_id[i] = 1;
            batch.seq_id[i][0] = 0;
            batch.logits[i] = 1;
        }

        const int32_t rc = llama_decode(engine->ctx, batch);
        if (rc < 0) {
            llama_batch_free(batch);
            throw std::runtime_error("llama_decode() a échoué pendant le calcul de l'embedding.");
        }

        const float * vector = llama_get_embeddings_seq(engine->ctx, 0);
        if (vector == nullptr) {
            llama_batch_free(batch);
            throw std::runtime_error("llama.cpp n'a pas retourné le vecteur d'embedding.");
        }

        jfloatArray result = env->NewFloatArray(engine->dimension);
        if (result == nullptr) {
            llama_batch_free(batch);
            return nullptr;
        }

        std::vector<float> normalized(static_cast<size_t>(engine->dimension));
        double sumSquares = 0.0;
        for (int32_t i = 0; i < engine->dimension; ++i) {
            const float value = vector[i];
            if (!std::isfinite(value)) {
                llama_batch_free(batch);
                throw std::runtime_error("Le modèle a produit une valeur non finie dans l'embedding.");
            }
            sumSquares += static_cast<double>(value) * static_cast<double>(value);
        }

        const double norm = std::sqrt(sumSquares);
        if (!(norm > 0.0) || !std::isfinite(norm)) {
            llama_batch_free(batch);
            throw std::runtime_error("Norme d'embedding invalide.");
        }

        for (int32_t i = 0; i < engine->dimension; ++i) {
            normalized[static_cast<size_t>(i)] = static_cast<float>(vector[i] / norm);
        }

        env->SetFloatArrayRegion(result, 0, engine->dimension, normalized.data());
        llama_batch_free(batch);
        return result;
    } catch (const std::exception & e) {
        __android_log_print(ANDROID_LOG_ERROR, TAG, "%s", e.what());
        throwJava(env, e.what());
        return nullptr;
    }
}

extern "C" JNIEXPORT jint JNICALL
Java_com_vanelle_app_EmbeddingEngine_nativeDimension(
    JNIEnv *,
    jobject,
    jlong handle
) {
    auto * engine = reinterpret_cast<EmbeddingContext *>(handle);
    return engine == nullptr ? 0 : engine->dimension;
}

extern "C" JNIEXPORT void JNICALL
Java_com_vanelle_app_EmbeddingEngine_nativeDestroy(
    JNIEnv *,
    jobject,
    jlong handle
) {
    auto * engine = reinterpret_cast<EmbeddingContext *>(handle);
    if (engine == nullptr) return;
    freeContext(engine);
    delete engine;
}
