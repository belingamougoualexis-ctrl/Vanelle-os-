This directory is populated at build time by scripts/prepare-bundled-models.sh with:
- smollm2-360m-instruct-q4_k_m.gguf (itlwas/SmolLM2-360M-Instruct-Q4_K_M-GGUF)
- nomic-embed-text-v1.5.Q4_K_M.gguf (nomic-ai/nomic-embed-text-v1.5-GGUF, official repo)

Both files are downloaded and SHA-256-verified once, at build time, by the CI
workflow. They are then packaged inside the APK's assets. At first app launch
ModelAssets.kt copies them from assets to app-private storage (local file copy
only — no network call), so the app never downloads anything after install.
