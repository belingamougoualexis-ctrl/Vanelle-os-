package com.vanelle.app

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Headers.Companion.toHeaders
import okio.ByteString.Companion.decodeBase64
import java.security.KeyStore
import android.util.Base64
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager
import java.io.IOException
import java.util.concurrent.TimeUnit
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext

/** Native transport for protocols that browser-style fetch cannot faithfully implement. */
class UniversalApiTransport(private val vault: ApiSecretVault) {
    companion object {
        /** Limite Vanelle : chaque donnée envoyée (corps de requête ou fichier) est plafonnée à 3 Go. */
        const val MAX_PAYLOAD_BYTES: Long = 3L * 1024 * 1024 * 1024
    }
    private fun checkSize(label: String, size: Long) {
        require(size <= MAX_PAYLOAD_BYTES) { "$label dépasse la limite de 3 Go autorisée par Vanelle (${size} octets)." }
    }
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    private val sockets = mutableMapOf<String, WebSocket>()
    private val streams = mutableMapOf<String, Call>()
    private val eventQueues = mutableMapOf<String, java.util.concurrent.ConcurrentLinkedQueue<String>>()

    fun request(method: String, url: String, headers: Map<String,String>, body: ByteArray?, contentType: String?, timeoutMs: Long): Triple<Int, Map<String,String>, ByteArray> {
        require(url.startsWith("https://")) { "Vanelle exige HTTPS." }
        body?.let { checkSize("Le corps de la requête", it.size.toLong()) }
        val requestBody = body?.toRequestBody(contentType?.toMediaTypeOrNull())
        val builder = Request.Builder().url(url).method(method.uppercase(), requestBody)
        headers.forEach { (k,v) -> builder.header(k,v) }
        val local = client.newBuilder().callTimeout(timeoutMs, TimeUnit.MILLISECONDS).build()
        local.newCall(builder.build()).execute().use { response ->
            val map = response.headers.toMultimap().mapValues { it.value.joinToString(",") }
            return Triple(response.code, map, response.body?.bytes() ?: ByteArray(0))
        }
    }

    fun mtlsRequest(ref:String, method:String, url:String, headers:Map<String,String>, body:ByteArray?, contentType:String?): Triple<Int,Map<String,String>,ByteArray> {
        require(url.startsWith("https://")) { "mTLS exige HTTPS." }
        val packed = vault.get("mtls:$ref") ?: error("Identité mTLS introuvable.")
        val json = org.json.JSONObject(packed); val p12=Base64.decode(json.getString("p12"),Base64.NO_WRAP); val password=json.getString("password").toCharArray()
        val ks=KeyStore.getInstance("PKCS12").apply { load(p12.inputStream(), password) }
        val kmf=KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()).apply { init(ks,password) }
        val ssl=SSLContext.getInstance("TLS").apply { init(kmf.keyManagers,null,null) }
        val tm=(TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()).apply { init(null as KeyStore?) }).trustManagers.filterIsInstance<X509TrustManager>().first()
        val mtlsClient=client.newBuilder().sslSocketFactory(ssl.socketFactory,tm).build()
        val reqBody=body?.toRequestBody(contentType?.toMediaTypeOrNull()); val b=Request.Builder().url(url).method(method.uppercase(),reqBody); headers.forEach{(k,v)->b.header(k,v)}
        mtlsClient.newCall(b.build()).execute().use { r -> return Triple(r.code,r.headers.toMultimap().mapValues{it.value.joinToString(",")},r.body?.bytes() ?: ByteArray(0)) }
    }

    fun openWebSocket(id: String, url: String, headers: Map<String,String>, listener: WebSocketListener): Boolean {
        require(url.startsWith("wss://")) { "WebSocket Internet doit utiliser wss://." }
        val builder = Request.Builder().url(url)
        headers.forEach { (k,v) -> builder.header(k,v) }
        sockets[id]?.cancel()
        eventQueues[id] = java.util.concurrent.ConcurrentLinkedQueue()
        sockets[id] = client.newWebSocket(builder.build(), listener)
        return true
    }
    fun sendWebSocket(id: String, text: String?, base64: String?): Boolean {
        val ws = sockets[id] ?: return false
        return if (text != null) ws.send(text) else ws.send((base64 ?: "").decodeBase64() ?: return false)
    }
    fun readEvents(id:String,max:Int=20):List<String>{ val q=eventQueues[id] ?: return emptyList(); val out=mutableListOf<String>(); repeat(max.coerceIn(1,100)){ q.poll()?.let{out.add(it)} ?: return@repeat }; return out }
    fun closeWebSocket(id: String) { sockets.remove(id)?.close(1000, "closed"); eventQueues.remove(id) }

    fun openSse(id: String, url: String, headers: Map<String,String>, onEvent: (String)->Unit, onError: (Throwable)->Unit) {
        require(url.startsWith("https://")) { "SSE Internet doit utiliser HTTPS." }
        val req = Request.Builder().url(url).header("Accept", "text/event-stream").apply { headers.forEach { (k,v)->header(k,v) } }.build()
        val call = client.newCall(req)
        streams[id] = call
        eventQueues[id] = java.util.concurrent.ConcurrentLinkedQueue()
        call.enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) { streams.remove(id); onError(e) }
            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) { streams.remove(id); response.close(); onError(IOException("HTTP ${response.code}")); return }
                response.use {
                    val source = it.body?.charStream()?.buffered() ?: run { onError(IOException("SSE body vide")); return }
                    val event = StringBuilder()
                    while (!call.isCanceled()) {
                        val line = source.readLine() ?: break
                        if (line.isEmpty()) { if (event.isNotEmpty()) { val data=event.toString(); eventQueues[id]?.offer(data); onEvent(data); event.setLength(0) } }
                        else if (line.startsWith("data:")) event.append(line.substringAfter("data:").trimStart()).append('\n')
                    }
                }
                streams.remove(id)
            }
        })
    }
    fun readSseEvents(id:String,max:Int=20):List<String>{ val q=eventQueues[id] ?: return emptyList(); val out=mutableListOf<String>(); repeat(max.coerceIn(1,100)){ q.poll()?.let{out.add(it)} ?: return@repeat }; return out }
    fun closeSse(id: String) { streams.remove(id)?.cancel(); eventQueues.remove(id) }

    fun multipart(url: String, headers: Map<String,String>, fields: Map<String,String>, files: List<Triple<String,String,ByteArray>>): Triple<Int, Map<String,String>, ByteArray> {
        files.forEach { (name, filename, bytes) -> checkSize("Le fichier \"$filename\"", bytes.size.toLong()) }
        val totalSize = files.sumOf { it.third.size.toLong() }
        checkSize("Le total des fichiers envoyés", totalSize)
        val form = MultipartBody.Builder().setType(MultipartBody.FORM)
        fields.forEach { (k,v) -> form.addFormDataPart(k,v) }
        files.forEach { (name, filename, bytes) -> form.addFormDataPart(name, filename, bytes.toRequestBody("application/octet-stream".toMediaType())) }
        val req = Request.Builder().url(url).headers(headers.toHeaders()).post(form.build()).build()
        client.newCall(req).execute().use { r -> return Triple(r.code, r.headers.toMultimap().mapValues { it.value.joinToString(",") }, r.body?.bytes() ?: ByteArray(0)) }
    }
}
