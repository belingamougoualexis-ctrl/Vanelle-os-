package com.vanelle.app

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.nehuatl.llamacpp.LlamaHelper

/**
 * Thin wrapper around llamacpp-kotlin 0.4.0 [LlamaHelper].
 * Temperature / maxTokens are accepted for API compatibility with the JS bridge;
 * the current binding's public predict() API does not expose sampling controls.
 */
class LlamaEngine(private val context: Context) {

    companion object {
        const val CONTEXT_SIZE = 2048
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val events = MutableSharedFlow<LlamaHelper.LLMEvent>(extraBufferCapacity = 128)
    private val helper = LlamaHelper(context.contentResolver, scope, events)
    private val mutex = Mutex()

    @Volatile
    var ready: Boolean = false
        private set

    private var loadDeferred: CompletableDeferred<Unit>? = null
    private var genDeferred: CompletableDeferred<String>? = null
    private val out = StringBuilder()

    init {
        scope.launch {
            events.collect { event ->
                when (event) {
                    is LlamaHelper.LLMEvent.Loaded -> {
                        ready = true
                        loadDeferred?.complete(Unit)
                    }
                    is LlamaHelper.LLMEvent.Started -> out.clear()
                    is LlamaHelper.LLMEvent.Ongoing -> out.append(event.word)
                    is LlamaHelper.LLMEvent.Done -> {
                        val text = event.fullText.ifBlank { out.toString() }
                        genDeferred?.complete(text)
                    }
                    is LlamaHelper.LLMEvent.Error -> {
                        ready = false
                        val err = IllegalStateException(event.message)
                        loadDeferred?.completeExceptionally(err)
                        genDeferred?.completeExceptionally(err)
                    }
                }
            }
        }
    }

    suspend fun ensureLoaded() {
        mutex.withLock {
            if (ready) return
            val file = ModelAssets.ensureInstalled(context, ModelAssets.LLM)
            val deferred = CompletableDeferred<Unit>()
            loadDeferred = deferred
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            context.grantUriPermission(
                context.packageName,
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            helper.load(uri.toString(), CONTEXT_SIZE, null) { _ -> }
            deferred.await()
            loadDeferred = null
        }
    }

    suspend fun generate(prompt: String, maxTokens: Int, temperature: Float): String {
        if (!ready) {
            ensureLoaded()
        }
        return mutex.withLock {
            val deferred = CompletableDeferred<String>()
            genDeferred = deferred
            // llamacpp-kotlin 0.4.0 public API: predict(prompt, imagePath?, partialCompletion?)
            // maxTokens / temperature are intentionally unused until the binding exposes them.
            helper.predict(prompt)
            val result = deferred.await()
            genDeferred = null
            result
                .replace("<|im_end|>", "")
                .replace("<|endoftext|>", "")
                .replace("<|im_start|>assistant", "")
                .trim()
        }
    }

    /**
     * Builds a ChatML-style prompt for SmolLM2-Instruct.
     * Optional [systemPrompt] is prepended as a system turn.
     */
    fun buildPrompt(
        messages: List<Pair<String, String>>,
        systemPrompt: String? = null
    ): String = buildString {
        val system = systemPrompt?.trim().orEmpty()
        if (system.isNotEmpty()) {
            append("<|im_start|>system\n")
            append(system)
            append("<|im_end|>\n")
        }
        for ((role, content) in messages) {
            append("<|im_start|>")
            append(role)
            append('\n')
            append(content)
            append("<|im_end|>\n")
        }
        append("<|im_start|>assistant\n")
    }
}
