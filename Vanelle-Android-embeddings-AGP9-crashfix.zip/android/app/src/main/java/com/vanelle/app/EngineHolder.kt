package com.vanelle.app

import android.content.Context

/**
 * Un seul LlamaEngine pour toute l'application, créé sur le contexte applicatif.
 * MainApplication l'utilise pour précharger le modèle en mémoire dès l'ouverture
 * de l'app ; VanelleNativeModule réutilise la même instance pour le chat, donc
 * le modèle n'est jamais chargé deux fois et le préchargement profite bien au
 * premier message envoyé par l'utilisateur.
 */
object EngineHolder {
    @Volatile
    private var instance: LlamaEngine? = null

    fun get(context: Context): LlamaEngine =
        instance ?: synchronized(this) {
            instance ?: LlamaEngine(context.applicationContext).also { instance = it }
        }
}
