package com.vanelle.app

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Models are shipped with the application at build time.
 * No model download is performed at runtime.
 */
object ModelAssets {

    data class ModelSpec(
        val id: String,
        val assetName: String,
        val fileName: String,
        val sha256: String,
        val minSize: Long,
        val label: String
    )

    val LLM = ModelSpec(
        id = "llm",
        assetName = "models/smollm2-360m-instruct-q4_k_m.gguf",
        fileName = "vanelle-smollm2-360m-q4_k_m.gguf",
        sha256 = "ac42744fb524f4f28c7854824d6a16ac7a1a4f46b2e6292f856c6901b2e2f578",
        minSize = 260_000_000L,
        label = "Modèle IA"
    )

    val EMBEDDING = ModelSpec(
        id = "embedding",
        assetName = "models/nomic-embed-text-v1.5.Q4_K_M.gguf",
        fileName = "vanelle-nomic-embed-text-v1.5-q4_k_m.gguf",
        sha256 = "d4e388894e09cf3816e8b0896d81d265b55e7a9fff9ab03fe8bf4ef5e11295ac",
        minSize = 80_000_000L,
        label = "Modèle d'embeddings"
    )

    private val verified = ConcurrentHashMap<String, Boolean>()

    fun file(context: Context, spec: ModelSpec): File =
        File(context.filesDir, spec.fileName)

    @Synchronized
    fun ensureInstalled(context: Context, spec: ModelSpec): File {
        val destination = file(context, spec)
        if (isReady(context, spec)) return destination

        // Copy packaged asset once into app-private storage so llama.cpp can open
        // a normal file descriptor / FileProvider URI.
        val tmp = File(context.filesDir, "${spec.fileName}.tmp")
        if (tmp.exists()) tmp.delete()

        context.assets.open(spec.assetName).use { input ->
            FileOutputStream(tmp).use { output ->
                input.copyTo(output, 1024 * 1024)
                output.fd.sync()
            }
        }

        require(tmp.length() >= spec.minSize) {
            "Asset ${spec.label} incomplet (${tmp.length()} octets)"
        }
        require(sha256(tmp) == spec.sha256) {
            "SHA-256 invalide pour ${spec.label}"
        }
        if (!tmp.renameTo(destination)) {
            tmp.copyTo(destination, overwrite = true)
            tmp.delete()
        }
        verified[spec.id] = true
        return destination
    }

    fun isReady(context: Context, spec: ModelSpec): Boolean {
        if (verified[spec.id] == true) return true
        val f = file(context, spec)
        val ok = f.exists() && f.length() >= spec.minSize && sha256(f) == spec.sha256
        if (ok) verified[spec.id] = true
        return ok
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
