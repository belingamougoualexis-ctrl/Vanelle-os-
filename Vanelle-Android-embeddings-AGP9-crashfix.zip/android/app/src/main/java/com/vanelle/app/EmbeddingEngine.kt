package com.vanelle.app

import android.content.Context
import java.io.File

/**
 * Real on-device embedding engine backed by llama.cpp's C API.
 *
 * The Nomic model is an encoder/embedding model, not a chat model.  We keep a
 * separate native context from LlamaEngine so the two models can evolve
 * independently.  Text is prefixed according to Nomic's retrieval contract:
 * search_query for questions and search_document for indexed knowledge.
 */
class EmbeddingEngine(private val context: Context) : AutoCloseable {
    companion object {
        private const val CONTEXT_SIZE = 2048
        private const val DEFAULT_THREADS = 2

        @Volatile
        private var nativeLibraryLoaded = false

        private fun ensureNativeLibraryLoaded() {
            if (nativeLibraryLoaded) return
            synchronized(this) {
                if (nativeLibraryLoaded) return
                System.loadLibrary("vanelle_embedding")
                nativeLibraryLoaded = true
            }
        }
    }

    private val lock = Any()
    private var nativeHandle: Long = 0L

    val isLoaded: Boolean
        get() = synchronized(lock) { nativeHandle != 0L }

    val modelFile: File
        get() = ModelAssets.file(context, ModelAssets.EMBEDDING)

    fun isReady(): Boolean = ModelAssets.isReady(context, ModelAssets.EMBEDDING)

    fun ensureInstalled(): File = ModelAssets.ensureInstalled(context, ModelAssets.EMBEDDING)

    fun ensureLoaded() {
        synchronized(lock) {
            ensureNativeLibraryLoaded()
            if (nativeHandle != 0L) return

            val file = ensureInstalled()
            val threads = Runtime.getRuntime().availableProcessors()
                .coerceIn(1, 4)
                .coerceAtLeast(DEFAULT_THREADS)

            nativeHandle = nativeCreate(file.absolutePath, CONTEXT_SIZE, threads)
            if (nativeHandle == 0L) {
                throw IllegalStateException("Impossible d'initialiser le moteur d'embeddings local.")
            }
        }
    }

    fun embedQuery(text: String): FloatArray = embed("search_query: ", text)

    fun embedDocument(text: String): FloatArray = embed("search_document: ", text)

    fun dimension(): Int {
        ensureLoaded()
        return synchronized(lock) { nativeDimension(nativeHandle) }
    }

    private fun embed(prefix: String, text: String): FloatArray {
        val clean = text.trim()
        require(clean.isNotEmpty()) { "Le texte à encoder ne peut pas être vide." }
        ensureLoaded()

        return synchronized(lock) {
            val vector = nativeEmbed(nativeHandle, prefix + clean)
            if (vector.isEmpty()) {
                throw IllegalStateException("Le moteur d'embeddings n'a retourné aucun vecteur.")
            }
            vector
        }
    }

    override fun close() {
        synchronized(lock) {
            if (nativeHandle != 0L) {
                nativeDestroy(nativeHandle)
                nativeHandle = 0L
            }
        }
    }

    private external fun nativeCreate(
        modelPath: String,
        contextSize: Int,
        threads: Int,
    ): Long

    private external fun nativeEmbed(handle: Long, text: String): FloatArray

    private external fun nativeDimension(handle: Long): Int

    private external fun nativeDestroy(handle: Long)
}
