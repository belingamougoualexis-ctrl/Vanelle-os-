# Vanelle — adaptation 2026

## Design
- Direction: premium AI product, obsidian + ivory + electric violet + champagne.
- Typography hierarchy uses Android system sans families so the APK remains dependency-free and does not gain a font binary just for the UI.
- The visual reference uses Satoshi/Manrope-style proportions; current source uses Android sans-serif for build-safe portability.
- Rounded 18px cards, restrained shadows, strong hierarchy, compact navigation, accessible semantic colors.

## API
- Android declares INTERNET and ACCESS_NETWORK_STATE.
- Cleartext HTTP is disabled explicitly.
- Configured API endpoints can be tested from the API tab with real HTTPS GET calls.
- Timeout: 12 seconds.
- The UI reports actual HTTP status, latency and a bounded response preview.
- Arbitrary third-party APIs may still require their own authentication, headers, OAuth, request body or signature rules; those cannot be guessed from an endpoint URL.

## Important honesty point
The existing project did not previously execute configured APIs: it only stored endpoint metadata. This version adds a real generic HTTPS test path, but it does not claim that every third-party API is plug-and-play.

## Universal API gateway layer
The API layer is now protocol-agnostic at the request level: configurable HTTPS REST calls support GET/POST/PUT/PATCH/DELETE, query parameters, arbitrary headers, JSON or raw body, API-key/Bearer/Basic authentication, timeouts, retry with exponential backoff + jitter, Retry-After handling, response headers and JSON/text decoding. A GraphQL helper is included.

This is deliberately not described as “every API on Earth works automatically”: APIs with custom signing, OAuth device flows, mTLS, proprietary binary protocols, WebSockets/SSE, special multipart uploads or vendor-specific workflows still need an adapter. The architecture makes those adapters possible without rewriting the chat engine. Android's security guidance recommends encrypted transport and appropriate authentication; cleartext is disabled. citeturn0search1turn0search4
