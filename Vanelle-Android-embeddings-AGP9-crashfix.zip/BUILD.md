# Compiler Vanelle (Android)

```bash
npm install
cd android && ./gradlew assembleDebug
# APK → android/app/build/outputs/apk/debug/app-debug.apk
```

Requirements: Node.js >= 22.13, JDK 17, Android SDK/Build Tools compatible with React Native 0.87.
