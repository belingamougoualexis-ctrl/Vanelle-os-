# Vanelle — Universal API / secrets architecture

## Secrets
- API keys, Bearer tokens, Basic passwords and signing secrets are stored in an Android Keystore-backed AES-GCM vault.
- AsyncStorage contains only a `secretRef`, never the credential value after migration.
- AI `.zip` exports deliberately omit both `apiKey` and `secretRef`; importing an older package with `apiKey` migrates the value into the vault through `saveAI`.
- A client-side/mobile secret can be protected at rest, but cannot be made mathematically invisible to a compromised/rooted device or to code executing with the same app privileges. High-value provider secrets should therefore live on a backend proxy.

## Protocol coverage
- REST/HTTP(S): JSON, text, binary bodies, query parameters, headers, retries and status handling.
- GraphQL: standard POST helper.
- OAuth 2.0 for native apps: external browser + PKCE + `vanelle://oauth` callback. Provider-specific parameters can be added through `extraParams`.
- WebSocket: native OkHttp `wss://` text and binary messages with events.
- SSE: native streaming reader with event/error callbacks.
- Multipart: native multipart/form-data fields and binary file parts.
- mTLS: PKCS#12 identity imported into the encrypted vault and used by a native TLS client.
- HMAC signatures: native HMAC-SHA256/HMAC-SHA512 signing against a caller-supplied canonical request string.
- Binary protocols: native transport accepts and returns base64 bytes, so protobuf/CBOR/custom framed payloads can be layered without converting them to UTF-8.
- Custom/proprietary protocols: represented as adapter metadata; arbitrary vendor signing/canonicalization still requires a provider-specific adapter because there is no universal signature format.

## Security rules
- HTTPS/WSS are enforced for Internet endpoints.
- No API credential is included in portable AI exports.
- Side-effectful calls should require explicit user confirmation when later connected to autonomous model tool-calling.

## AI tool execution layer — 2026 hardening

Vanelle's local model now has an explicit tool contract for configured APIs. The model can request a REST/GraphQL-style request or the native WebSocket/SSE actions exposed by the Android bridge. Credentials remain outside the prompt and are resolved from the native vault by reference only.

Side-effecting HTTP methods are not executed by the model without user confirmation. Missing OAuth authorization is surfaced as `AUTH_REQUIRED` rather than being simulated. mTLS, multipart and binary transports are routed to native transport instead of being silently downgraded to browser fetch.

The transport layer also buffers WebSocket/SSE events so the AI tool layer can retrieve recent events without exposing secrets to JavaScript.
