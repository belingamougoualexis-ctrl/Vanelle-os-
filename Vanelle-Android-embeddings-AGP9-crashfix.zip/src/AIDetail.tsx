import React, { useState } from 'react';
import { Platform, ScrollView, Share, Text, TextInput, ToastAndroid, View } from 'react-native';
import { deleteAI, getChat, saveAI } from './storage';
import { CATEGORIES, type AI, type Training, type UserApi, type VFile } from './types';
import { Btn, Card, ErrorBanner, Pill, Row, S, Step, SuccessBanner, Tag } from './ui';
import { Chat } from './Chat';
import { buildAIZip } from './aiPackage';
import { callConfiguredApi, summarizeApiData, type ApiAuth } from './apiClient';

const makeId = () => `${Date.now()}-${Math.random().toString(36).slice(2)}`;
const MAX_FILE_BYTES = 3 * 1024 * 1024 * 1024; // 3 Go par fichier

type SubTab = 'vue' | 'apprentissage' | 'fichiers' | 'api' | 'tester';

export function AIDetail({
  ai: initial,
  onBack,
  onChanged,
}: {
  ai: AI;
  onBack: () => void;
  onChanged: () => void;
}) {
  const [ai, setAI] = useState<AI>(initial);
  const [tab, setTab] = useState<SubTab>('vue');

  const save = async (next: AI) => {
    setAI(next);
    await saveAI(next);
    onChanged();
  };

  if (tab === 'tester') {
    return (
      <Chat
        ai={ai}
        back={() => setTab('vue')}
        onUpdateAI={async (next) => {
          await save(next);
        }}
      />
    );
  }

  return (
    <View style={S.root}>
      <View style={S.header}>
        <Text style={S.brand}>« {ai.name} »</Text>
        <Text style={{ color: '#E9C98A', fontSize: 11, marginTop: 4 }}>
          {ai.description || 'Pas encore de description.'}
        </Text>
      </View>
      <View style={{ paddingHorizontal: 16, paddingTop: 12, backgroundColor: '#fff' }}>
        <View style={S.pillRow}>
          <Pill label="Vue d'ensemble" active={tab === 'vue'} onPress={() => setTab('vue')} />
          <Pill
            label="Apprentissage"
            active={tab === 'apprentissage'}
            onPress={() => setTab('apprentissage')}
          />
          <Pill label="Fichiers" active={tab === 'fichiers'} onPress={() => setTab('fichiers')} />
          <Pill label="API" active={tab === 'api'} onPress={() => setTab('api')} />
          <Pill label="Chat" active={false} onPress={() => setTab('tester')} />
        </View>
      </View>
      <ScrollView style={S.body}>
        {tab === 'vue' && (
          <TabVue ai={ai} onSave={save} onDeleted={onBack} onTest={() => setTab('tester')} />
        )}
        {tab === 'apprentissage' && <TabApprentissage ai={ai} onSave={save} />}
        {tab === 'fichiers' && <TabFichiers ai={ai} onSave={save} />}
        {tab === 'api' && <TabApi ai={ai} onSave={save} />}
      </ScrollView>
    </View>
  );
}

function TabVue({
  ai,
  onSave,
  onDeleted,
  onTest,
}: {
  ai: AI;
  onSave: (ai: AI) => Promise<void>;
  onDeleted: () => void;
  onTest: () => void;
}) {
  const [name, setName] = useState(ai.name);
  const [description, setDescription] = useState(ai.description);
  const [style, setStyle] = useState(ai.style);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState('');
  const [exportNote, setExportNote] = useState('');
  const [trait1, setTrait1] = useState(ai.traits?.[0] ?? '');
  const [trait2, setTrait2] = useState(ai.traits?.[1] ?? '');
  const [trait3, setTrait3] = useState(ai.traits?.[2] ?? '');
  const [systemPrompt, setSystemPrompt] = useState(ai.systemPrompt ?? '');
  const [personaSaved, setPersonaSaved] = useState(false);

  const exportZip = async () => {
    setExportError('');
    setExportNote('');
    setExporting(true);
    try {
      const chat = await getChat(ai.id);
      const base64 = await buildAIZip(ai, chat);
      const fileName = `${ai.name.replace(/\s+/g, '-').toLowerCase()}-vanelle-ia.zip`;
      try {
        const RNFS = (await import('react-native-fs')).default;
        const dest = (RNFS.DownloadDirectoryPath || RNFS.DocumentDirectoryPath) + '/' + fileName;
        await RNFS.writeFile(dest, base64, 'base64');
        if (Platform.OS === 'android') {
          ToastAndroid.show('IA exportée : ' + fileName, ToastAndroid.LONG);
        }
        setExportNote(`IA exportée en .zip : ${dest} (notions, fichiers, API, prompt, chat de test).`);
      } catch (fsErr) {
        await Share.share({ url: `data:application/zip;base64,${base64}`, title: fileName });
        setExportNote(
          `Écriture directe impossible (${
            fsErr instanceof Error ? fsErr.message : 'erreur'
          }), partage système proposé à la place.`
        );
      }
    } catch (e) {
      setExportError(e instanceof Error ? e.message : "L'export du .zip a échoué.");
    } finally {
      setExporting(false);
    }
  };

  return (
    <View>
      {exportError ? <ErrorBanner message={exportError} onDismiss={() => setExportError('')} /> : null}
      {exportNote && !exportError ? <SuccessBanner message={exportNote} /> : null}
      <Card>
        <Text style={{ fontWeight: '800', fontSize: 15, marginBottom: 4 }}>Fiche d'identité</Text>
        <Text style={S.label}>Nom de l'IA</Text>
        <TextInput style={S.input} value={name} onChangeText={setName} />
        <Text style={S.label}>Description</Text>
        <TextInput
          style={[S.input, { minHeight: 70, textAlignVertical: 'top' }]}
          value={description}
          onChangeText={setDescription}
          multiline
        />
        <Text style={S.label}>Style de base</Text>
        <TextInput style={S.input} value={style} onChangeText={setStyle} />
        <Btn
          label="Enregistrer la fiche"
          style={{ marginTop: 12 }}
          disabled={!name.trim()}
          onPress={() =>
            void onSave({
              ...ai,
              name: name.trim() || ai.name,
              description: description.trim(),
              style,
            })
          }
        />
        <Btn
          label={confirmingDelete ? 'Confirmer la suppression' : 'Supprimer cette IA'}
          ghost
          style={{ marginTop: 8 }}
          onPress={() => {
            if (!confirmingDelete) {
              setConfirmingDelete(true);
              return;
            }
            void deleteAI(ai.id).then(onDeleted);
          }}
        />
      </Card>

      <Card>
        <Text style={{ fontWeight: '800', fontSize: 15, marginBottom: 4 }}>
          Personnalité — 3 traits
        </Text>
        <Text style={S.muted}>
          Ces 3 traits décrivent le caractère de l'IA et sont injectés dans son prompt
          système à chaque message, au même titre que le texte libre ci-dessous.
        </Text>
        <Text style={S.label}>Trait 1</Text>
        <TextInput
          style={S.input}
          value={trait1}
          onChangeText={setTrait1}
          placeholder="Ex. Chaleureuse"
        />
        <Text style={S.label}>Trait 2</Text>
        <TextInput
          style={S.input}
          value={trait2}
          onChangeText={setTrait2}
          placeholder="Ex. Directe"
        />
        <Text style={S.label}>Trait 3</Text>
        <TextInput
          style={S.input}
          value={trait3}
          onChangeText={setTrait3}
          placeholder="Ex. Curieuse"
        />
        <Text style={S.label}>Prompt système</Text>
        <Text style={S.muted}>
          Instructions libres qui s'ajoutent aux traits pour cadrer le comportement de
          l'IA — modifiable à tout moment.
        </Text>
        <TextInput
          style={[S.input, { minHeight: 100, textAlignVertical: 'top' }]}
          value={systemPrompt}
          onChangeText={setSystemPrompt}
          multiline
          placeholder="Ex. Tu es l'assistante de la boutique, réponds toujours en français, reste concise."
        />
        {personaSaved ? <SuccessBanner message="Personnalité et prompt système enregistrés." /> : null}
        <Btn
          label="Enregistrer la personnalité"
          style={{ marginTop: 12 }}
          onPress={() => {
            void onSave({
              ...ai,
              traits: [trait1.trim(), trait2.trim(), trait3.trim()],
              systemPrompt,
            });
            setPersonaSaved(true);
          }}
        />
      </Card>

      <Card>
        <Text style={{ fontWeight: '800', fontSize: 15 }}>Résumé</Text>
        <Row k="Notions enseignées" v={String(ai.training.length)} />
        <Row k="Fichiers analysés" v={String(ai.files.length)} />
        <Row k="API connectées" v={String(ai.apis.length)} />
        <View style={[S.rowBetween, { paddingVertical: 10 }]}>
          <Text style={{ fontSize: 13 }}>Statut</Text>
          <Tag on={ai.deployed}>{ai.deployed ? 'déployée' : 'brouillon'}</Tag>
        </View>
        <Btn
          label="Marquer déployée"
          ghost
          style={{ marginTop: 8 }}
          onPress={() => void onSave({ ...ai, deployed: true, deployedAt: Date.now() })}
        />
      </Card>

      <Card>
        <Text style={{ fontWeight: '800', fontSize: 15 }}>Exporter cette IA</Text>
        <Text style={S.muted}>
          Un .zip contenant tout ce qui fait cette IA : identité, style, prompt système,
          notions enseignées, fichiers connaissances, API documentées et l'historique du
          chat de test. Réimportable pour continuer l'apprentissage ailleurs.
        </Text>
        <Btn
          label={exporting ? 'Préparation du .zip…' : 'Exporter en .zip'}
          ghost
          style={{ marginTop: 10 }}
          disabled={exporting}
          onPress={() => void exportZip()}
        />
      </Card>

      <Btn label="Ouvrir le chat de test" style={{ marginTop: 4, marginBottom: 24 }} onPress={onTest} />
    </View>
  );
}

function TabApprentissage({
  ai,
  onSave,
}: {
  ai: AI;
  onSave: (ai: AI) => Promise<void>;
}) {
  const [category, setCategory] = useState<string>(CATEGORIES[0]);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');

  return (
    <View>
      <Card>
        <Step n={1}>Enseigner une notion</Step>
        <Text style={S.muted}>
          Ces paires question/réponse sont injectées dans le prompt système à chaque message.
        </Text>
        <Text style={S.label}>Catégorie</Text>
        <View style={S.pillRow}>
          {CATEGORIES.map((c) => (
            <Pill key={c} label={c} active={category === c} onPress={() => setCategory(c)} />
          ))}
        </View>
        <Text style={S.label}>Question / situation</Text>
        <TextInput
          style={S.input}
          value={question}
          onChangeText={setQuestion}
          placeholder="Ex. Comment te présenter ?"
        />
        <Text style={S.label}>Réponse attendue</Text>
        <TextInput
          style={[S.input, { minHeight: 70, textAlignVertical: 'top' }]}
          value={answer}
          onChangeText={setAnswer}
          multiline
          placeholder="Ex. Je suis un assistant concis et bienveillant."
        />
        <Btn
          label="Ajouter la notion"
          style={{ marginTop: 12 }}
          disabled={!question.trim() || !answer.trim()}
          onPress={() => {
            const t: Training = {
              id: makeId(),
              category,
              question: question.trim(),
              answer: answer.trim(),
              ts: Date.now(),
            };
            void onSave({ ...ai, training: [...ai.training, t] });
            setQuestion('');
            setAnswer('');
          }}
        />
      </Card>

      <Card>
        <Text style={{ fontWeight: '800', fontSize: 15 }}>
          Notions enregistrées ({ai.training.length})
        </Text>
        {ai.training.length === 0 ? (
          <Text style={S.muted}>Rien pour l'instant — commencez par son identité.</Text>
        ) : (
          CATEGORIES.map((c) => {
            const items = ai.training.filter((t) => t.category === c);
            if (!items.length) return null;
            return (
              <View key={c}>
                <Text
                  style={{
                    fontSize: 12,
                    fontWeight: '700',
                    color: '#6d6d73',
                    marginTop: 10,
                  }}
                >
                  {c}
                </Text>
                {items.map((t) => (
                  <View key={t.id} style={S.divider}>
                    <Text style={{ fontSize: 13, fontWeight: '700' }}>{t.question}</Text>
                    <Text style={S.muted}>{t.answer}</Text>
                    <Btn
                      label="Retirer"
                      ghost
                      style={{ marginTop: 6, alignSelf: 'flex-start', paddingHorizontal: 14 }}
                      onPress={() =>
                        void onSave({
                          ...ai,
                          training: ai.training.filter((x) => x.id !== t.id),
                        })
                      }
                    />
                  </View>
                ))}
              </View>
            );
          })
        )}
      </Card>
    </View>
  );
}

const TEXT_EXTENSIONS = ['.txt', '.md', '.csv', '.json', '.html', '.htm', '.js', '.css'];
const IMAGE_EXTENSIONS = ['.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp'];

function fmtSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} o`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} Ko`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} Mo`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} Go`;
}

function TabFichiers({ ai, onSave }: { ai: AI; onSave: (ai: AI) => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');

  const upload = async () => {
    setBusy(true);
    setStatus('');
    setError('');
    try {
      const { pick } = await import('@react-native-documents/picker');
      const RNFS = (await import('react-native-fs')).default;
      const results = await pick({ allowMultiSelection: true });
      const added: VFile[] = [];

      for (const doc of results) {
        const size = doc.size ?? 0;
        if (size > MAX_FILE_BYTES) {
          setError(
            `« ${doc.name || 'fichier'} » dépasse 3 Go (${fmtSize(size)}). Chaque fichier doit peser au maximum 3 Go — la limite s’applique fichier par fichier, pas au total.`
          );
          continue;
        }

        const lower = (doc.name || '').toLowerCase();
        const isText = TEXT_EXTENSIONS.some((ext) => lower.endsWith(ext));
        const isImage = IMAGE_EXTENSIONS.some((ext) => lower.endsWith(ext));
        let note = 'Fichier binaire — contenu non extrait automatiquement.';
        if (isImage) {
          note = 'Image jointe — disponible comme référence de connaissance.';
        } else if (isText) {
          try {
            note = (await RNFS.readFile(doc.uri, 'utf8')).slice(0, 8000);
          } catch {
            note = 'Ce fichier a été ajouté mais son contenu n’a pas pu être lu.';
          }
        }

        added.push({
          id: makeId(),
          name: doc.name || 'fichier',
          note,
          size,
          addedAt: Date.now(),
        });
      }

      if (added.length) {
        // Append : les connaissances s’ajoutent, l’ancien ne se désinstalle pas
        await onSave({ ...ai, files: [...ai.files, ...added] });
        setStatus(
          `${added.length} fichier(s) ajouté(s) — le chat s'en sert désormais. Anciennes données conservées.`
        );
      }
    } catch (e) {
      const code = (e as { code?: string } | null)?.code;
      if (code !== 'OPERATION_CANCELED' && code !== 'DOCUMENT_PICKER_CANCELED') {
        const reason =
          e instanceof Error ? e.message : "L'ajout du fichier a échoué.";
        setError(reason);
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <View>
      {error ? <ErrorBanner message={error} onDismiss={() => setError('')} /> : null}
      {status ? <SuccessBanner message={status} /> : null}

      <Card>
        <Step n={1}>Ajouter des données</Step>
        <Text style={S.muted}>
          TXT, MD, CSV, JSON, HTML, JS, CSS : le contenu est extrait et vraiment utilisé par le
          chat. Images et autres formats sont conservés comme référence. Limite : 3 Go par
          fichier (pas sur le total). Chaque ajout s’empile — rien n’est écrasé sauf si vous
          retirez explicitement un fichier.
        </Text>
        <Btn
          label={busy ? 'Lecture…' : 'Uploader un fichier'}
          style={{ marginTop: 12 }}
          disabled={busy}
          onPress={() => void upload()}
        />
      </Card>

      <Card>
        <Text style={{ fontWeight: '800', fontSize: 15 }}>
          Fichiers analysés ({ai.files.length})
        </Text>
        {ai.files.length === 0 ? (
          <Text style={S.muted}>Aucun fichier pour l'instant.</Text>
        ) : (
          ai.files.map((f) => (
            <View key={f.id} style={S.divider}>
              <Text style={{ fontSize: 13, fontWeight: '700' }}>{f.name}</Text>
              <Text style={[S.muted, { fontSize: 11 }]}>{fmtSize(f.size)}</Text>
              <Text style={S.muted}>{f.note.slice(0, 140)}</Text>
              <Btn
                label="Retirer"
                ghost
                style={{ marginTop: 6, alignSelf: 'flex-start', paddingHorizontal: 14 }}
                onPress={() =>
                  void onSave({ ...ai, files: ai.files.filter((x) => x.id !== f.id) })
                }
              />
            </View>
          ))
        )}
      </Card>
    </View>
  );
}

function TabApi({ ai, onSave }: { ai: AI; onSave: (ai: AI) => Promise<void> }) {
  const [name, setName] = useState('');
  const [endpoint, setEndpoint] = useState('');
  const [method, setMethod] = useState<UserApi['method']>('GET');
  const [protocol, setProtocol] = useState<NonNullable<UserApi['protocol']>>('rest');
  const [description, setDescription] = useState('');
  const [authType, setAuthType] = useState<'none' | 'apiKey' | 'bearer' | 'basic'>('none');
  const [secret, setSecret] = useState('');
  const [username, setUsername] = useState('');
  const [headersText, setHeadersText] = useState('');
  const [queryText, setQueryText] = useState('');
  const [bodyText, setBodyText] = useState('');
  const [testing, setTesting] = useState<string | null>(null);
  const [testResult, setTestResult] = useState('');
  const [testError, setTestError] = useState('');

  const testApi = async (api: UserApi) => {
    setTesting(api.id);
    setTestResult('');
    setTestError('');
    try {
      const auth: ApiAuth = api.authType === 'apiKey' ? { type: 'apiKey', secretRef: api.secretRef, key: api.apiKey, header: api.authHeader || 'X-API-Key' } : api.authType === 'bearer' ? { type: 'bearer', secretRef: api.secretRef, token: api.apiKey } : api.authType === 'basic' ? { type: 'basic', username: api.username || '', secretRef: api.secretRef, password: api.apiKey } : { type: 'none' };
      let query: Record<string, string> | undefined;
      let headers: Record<string, string> | undefined;
      try { query = api.queryParams; headers = api.requestHeaders; } catch {}
      const result = await callConfiguredApi({ endpoint: api.endpoint, method: api.method, auth, query, headers, body: api.body, timeoutMs: api.timeoutMs || 15000, retries: api.retries ?? 2, retryNonIdempotent: api.retryNonIdempotent });
      const preview = summarizeApiData(result.data);
      if (!result.ok) {
        throw new Error(`HTTP ${result.status} ${result.statusText || ''}`.trim());
      }
      setTestResult(`Connexion OK · HTTP ${result.status} · ${result.elapsedMs} ms\n${preview}`);
    } catch (e) {
      setTestError(e instanceof Error ? e.message : 'Échec de l’appel API.');
    } finally {
      setTesting(null);
    }
  };

  return (
    <View>
      {testError ? <ErrorBanner message={testError} onDismiss={() => setTestError('')} /> : null}
      {testResult ? <SuccessBanner message={testResult} /> : null}
      <Card>
        <Text style={{ fontWeight: '800', fontSize: 15 }}>Connecter une API</Text>
        <Text style={S.muted}>
          Les identifiants sont chiffrés localement avec Android Keystore et ne sont plus conservés dans le profil JSON de l’IA. Le transport natif prend aussi en charge les protocoles avancés.
          Vanelle affiche le code HTTP, le temps de réponse et un aperçu de la réponse.
          OAuth/PKCE, mTLS, signatures, WebSocket, SSE, multipart et binaire disposent de points d’extension natifs. Les flows propriétaires restent configurables par paramètres ou adaptateur.
        </Text>
        <Text style={S.label}>Nom</Text>
        <TextInput style={S.input} value={name} onChangeText={setName} placeholder="Ex. Stock produits" />
        <Text style={S.label}>Endpoint</Text>
        <TextInput
          style={S.input}
          value={endpoint}
          onChangeText={setEndpoint}
          placeholder="https://api.exemple.com/stock"
          autoCapitalize="none"
        />
        <Text style={S.label}>Méthode</Text>
        <View style={S.pillRow}>{(['GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS'] as UserApi['method'][]).map(x => <Pill key={x} label={x} active={method===x} onPress={() => setMethod(x)} />)}</View>
        <Text style={S.label}>Protocole</Text>
        <View style={S.pillRow}>{(['rest','graphql','sse','websocket','multipart','binary','mtls','custom'] as const).map(x => <Pill key={x} label={x} active={protocol===x} onPress={() => setProtocol(x)} />)}</View>
        <Text style={S.label}>Description</Text>
        <TextInput style={S.input} value={description} onChangeText={setDescription} />
        <Text style={S.label}>Authentification</Text>
        <View style={S.pillRow}>
          {(['none','apiKey','bearer','basic'] as const).map((x) => (
            <Pill key={x} label={x === 'none' ? 'Aucune' : x === 'apiKey' ? 'API Key' : x === 'bearer' ? 'Bearer' : 'Basic'} active={authType === x} onPress={() => setAuthType(x)} />
          ))}
        </View>
        {authType === 'apiKey' ? <><Text style={S.label}>Nom du header</Text><TextInput style={S.input} value={username} onChangeText={setUsername} placeholder="X-API-Key" autoCapitalize="none" /><Text style={S.label}>Clé</Text><TextInput style={S.input} value={secret} onChangeText={setSecret} secureTextEntry /></> : null}
        {authType === 'bearer' ? <><Text style={S.label}>Token Bearer</Text><TextInput style={S.input} value={secret} onChangeText={setSecret} secureTextEntry /></> : null}
        {authType === 'basic' ? <><Text style={S.label}>Utilisateur</Text><TextInput style={S.input} value={username} onChangeText={setUsername} autoCapitalize="none" /><Text style={S.label}>Mot de passe</Text><TextInput style={S.input} value={secret} onChangeText={setSecret} secureTextEntry /></> : null}
        <Text style={S.label}>Headers JSON (optionnel)</Text>
        <TextInput style={[S.input,{minHeight:60,textAlignVertical:'top'}]} value={headersText} onChangeText={setHeadersText} placeholder='{"Accept":"application/json"}' multiline />
        <Text style={S.label}>Paramètres query JSON (optionnel)</Text>
        <TextInput style={[S.input,{minHeight:60,textAlignVertical:'top'}]} value={queryText} onChangeText={setQueryText} placeholder='{"page":"1"}' multiline />
        <Text style={S.label}>Body JSON (POST/PUT/PATCH, optionnel)</Text>
        <TextInput style={[S.input,{minHeight:70,textAlignVertical:'top'}]} value={bodyText} onChangeText={setBodyText} placeholder='{"message":"Bonjour"}' multiline />
        <Btn
          label="Ajouter l'API"
          style={{ marginTop: 12 }}
          disabled={!name.trim() || !endpoint.trim()}
          onPress={() => {
            const api: UserApi = {
              id: makeId(),
              name: name.trim(),
              endpoint: endpoint.trim(),
              method,
              protocol,
              description: description.trim(),
              apiKey: secret || undefined,
              authType,
              authHeader: authType === 'apiKey' ? (username.trim() || 'X-API-Key') : undefined,
              username: authType === 'basic' ? username.trim() : undefined,
              requestHeaders: (() => { try { return headersText.trim() ? JSON.parse(headersText) : undefined; } catch { return undefined; } })(),
              queryParams: (() => { try { return queryText.trim() ? JSON.parse(queryText) : undefined; } catch { return undefined; } })(),
              body: bodyText.trim() || undefined,
              timeoutMs: 15000,
              retries: 2,
              retryNonIdempotent: false,
              ts: Date.now(),
            };
            void onSave({ ...ai, apis: [...ai.apis, api] });
            setName('');
            setEndpoint('');
            setDescription('');
            setSecret('');
          }}
        />
      </Card>

      <Card>
        <Text style={{ fontWeight: '800', fontSize: 15 }}>
          Intégrations API ({ai.apis.length})
        </Text>
        {ai.apis.length === 0 ? (
          <Text style={S.muted}>Aucune API configurée.</Text>
        ) : (
          ai.apis.map((a) => (
            <View key={a.id} style={S.divider}>
              <Text style={{ fontSize: 13, fontWeight: '700' }}>{a.name}</Text>
              <Text style={S.muted}>
                {a.endpoint} · {a.method}
              </Text>
              {a.description ? <Text style={S.muted}>{a.description}</Text> : null}
              <View style={{ flexDirection: 'row', gap: 8, marginTop: 6 }}>
                <Btn
                  label={testing === a.id ? 'Test…' : 'Tester'}
                  ghost
                  style={{ marginTop: 0, alignSelf: 'flex-start', paddingHorizontal: 14 }}
                  disabled={testing === a.id}
                  onPress={() => void testApi(a)}
                />
                <Btn
                  label="Retirer"
                  ghost
                  style={{ marginTop: 0, alignSelf: 'flex-start', paddingHorizontal: 14 }}
                  onPress={() =>
                    void onSave({ ...ai, apis: ai.apis.filter((x) => x.id !== a.id) })
                  }
                />
              </View>
            </View>
          ))
        )}
      </Card>
    </View>
  );
}
