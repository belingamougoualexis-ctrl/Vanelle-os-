import React, { useEffect, useState } from 'react';
import {
  FlatList,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  Share,
  StatusBar,
  Text,
  TextInput,
  ToastAndroid,
  View,
} from 'react-native';
import { AIDetail } from './AIDetail';
import { deleteAI, getAIs, getChat, getProfile, saveAI, saveChat, saveProfile } from './storage';
import type { AI, Profile } from './types';
import { blankProfile } from './types';
import { Btn, Card, Empty, ErrorBanner, PageHead, S, SuccessBanner, Tag } from './ui';
import { parseAIZip } from './aiPackage';
import { VanelleNative } from './native';

const makeId = () => `${Date.now()}-${Math.random().toString(36).slice(2)}`;

const blankAI = (name: string, description: string, style: string): AI => ({
  id: makeId(),
  name,
  description,
  style,
  traits: ['', '', ''],
  systemPrompt: '',
  maxTokens: 700,
  temperature: 0.4,
  createdAt: Date.now(),
  training: [],
  files: [],
  apis: [],
  deployed: false,
});

type Tab = 'create' | 'ais' | 'dashboard' | 'account';
type ModelState = 'checking' | 'loading' | 'ready' | 'unavailable';

export default function App() {
  const [tab, setTab] = useState<Tab>('create');
  const [ais, setAis] = useState<AI[]>([]);
  const [selected, setSelected] = useState<AI | null>(null);
  const [modelState, setModelState] = useState<ModelState>('checking');

  const refresh = async () => {
    const list = await getAIs();
    setAis(list.sort((a, b) => b.createdAt - a.createdAt));
  };

  useEffect(() => {
    void refresh();
  }, []);

  useEffect(() => {
    // Notification de début / de fin du chargement du modèle en mémoire.
    // Le préchargement démarre déjà côté natif dès l'ouverture de l'app
    // (MainApplication) ; ce contrôle sert à informer l'utilisateur de
    // l'avancement et à couvrir le cas où il arriverait avant la fin.
    let cancelled = false;
    (async () => {
      if (!VanelleNative) {
        if (!cancelled) setModelState('unavailable');
        return;
      }
      try {
        const status = await VanelleNative.getModelStatus();
        if (cancelled) return;
        if (status.llmLoaded) {
          setModelState('ready');
          return;
        }
        setModelState('loading');
        if (Platform.OS === 'android') {
          ToastAndroid.show('Chargement de l’IA en mémoire…', ToastAndroid.SHORT);
        }
        await VanelleNative.preloadModel();
        if (cancelled) return;
        setModelState('ready');
        if (Platform.OS === 'android') {
          ToastAndroid.show('IA prête ✅', ToastAndroid.SHORT);
        }
      } catch {
        if (!cancelled) setModelState('unavailable');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (selected) {
    return (
      <AIDetail
        ai={selected}
        onBack={() => {
          setSelected(null);
          void refresh();
        }}
        onChanged={() => {
          void refresh();
          void getAIs().then((list) => {
            const fresh = list.find((x) => x.id === selected.id);
            if (fresh) setSelected(fresh);
          });
        }}
      />
    );
  }

  return (
    <SafeAreaView style={S.root}>
      <StatusBar barStyle="light-content" backgroundColor="#17171a" />
      <View style={S.header}>
        <Text style={S.brand}>VANELLE</Text>
        <Text style={S.sub}>ATELIER IA</Text>
        {modelState === 'loading' ? (
          <Text style={{ color: '#E9C98A', fontSize: 10, marginTop: 6 }}>
            ⏳ Chargement de l’IA en mémoire…
          </Text>
        ) : null}
        {modelState === 'unavailable' ? (
          <Text style={{ color: '#f2b3ab', fontSize: 10, marginTop: 6 }}>
            ⚠ Moteur IA indisponible sur cet appareil.
          </Text>
        ) : null}
      </View>
      <View style={S.body}>
        {tab === 'create' && (
          <Create
            onCreated={async (ai) => {
              await saveAI(ai);
              await refresh();
              setSelected(ai);
            }}
          />
        )}
        {tab === 'ais' && (
          <AIs
            ais={ais}
            open={setSelected}
            remove={async (id) => {
              await deleteAI(id);
              await refresh();
            }}
          />
        )}
        {tab === 'dashboard' && <Dashboard ais={ais} open={setSelected} />}
        {tab === 'account' && <Account ais={ais} onImported={refresh} />}
      </View>
      <View style={S.nav}>
        <Nav label="Créer" active={tab === 'create'} onPress={() => setTab('create')} />
        <Nav label="Mes IA" active={tab === 'ais'} onPress={() => setTab('ais')} />
        <Nav label="Tableau" active={tab === 'dashboard'} onPress={() => setTab('dashboard')} />
        <Nav label="Compte" active={tab === 'account'} onPress={() => setTab('account')} />
      </View>
    </SafeAreaView>
  );
}

function Nav({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Pressable style={S.navItem} onPress={onPress}>
      <Text style={[S.navText, active && S.navActive]}>{label}</Text>
    </Pressable>
  );
}

function Create({
  onCreated,
}: {
  onCreated: (ai: AI) => Promise<void>;
}) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [style, setStyle] = useState('Généraliste');
  const [busy, setBusy] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importError, setImportError] = useState('');
  const [importNote, setImportNote] = useState('');

  const importZip = async () => {
    setImportError('');
    setImportNote('');
    setImporting(true);
    try {
      const { pick } = await import('@react-native-documents/picker');
      const RNFS = (await import('react-native-fs')).default;
      const [doc] = await pick({ allowMultiSelection: false });
      if (!doc?.name?.toLowerCase().endsWith('.zip')) {
        throw new Error('Choisissez un fichier .zip exporté depuis Vanelle.');
      }
      const base64 = await RNFS.readFile(doc.uri, 'base64');
      const { ai, chat } = await parseAIZip(base64, makeId);
      await onCreated(ai);
      if (chat.length) await saveChat(ai.id, chat);
      setImportNote(`IA importée avec ${ai.training.length} notion(s) et ${ai.files.length} fichier(s). Retrouvez-la dans l'onglet « Mes IA ».`);
    } catch (e) {
      const code = (e as { code?: string } | null)?.code;
      if (code !== 'OPERATION_CANCELED' && code !== 'DOCUMENT_PICKER_CANCELED') {
        setImportError(e instanceof Error ? e.message : "L'import du .zip a échoué.");
      }
    } finally {
      setImporting(false);
    }
  };

  return (
    <ScrollView>
      <PageHead eyebrow="Étape 0" title="Créer une nouvelle IA">
        Donnez-lui un nom et un point de départ, puis enseignez-lui ce qu'elle doit savoir —
        notions, fichiers, API — depuis sa fiche.
      </PageHead>
      {importError ? <ErrorBanner message={importError} onDismiss={() => setImportError('')} /> : null}
      {importNote && !importError ? <SuccessBanner message={importNote} /> : null}
      <Card>
        <Text style={{ fontWeight: '800', fontSize: 15 }}>Importer une IA (.zip)</Text>
        <Text style={S.muted}>
          Reprenez une IA exportée depuis Vanelle — son apprentissage continue là où vous
          l'avez laissé.
        </Text>
        <Btn
          label={importing ? 'Import en cours…' : 'Choisir un .zip'}
          ghost
          style={{ marginTop: 10 }}
          disabled={importing}
          onPress={() => void importZip()}
        />
      </Card>
      <Card>
        <Text style={S.label}>Nom</Text>
        <TextInput style={S.input} value={name} onChangeText={setName} placeholder="Ex. Solutions Pro" />
        <Text style={S.label}>Description</Text>
        <TextInput
          style={[S.input, { minHeight: 80, textAlignVertical: 'top' }]}
          value={description}
          onChangeText={setDescription}
          multiline
          placeholder="En une phrase, à quoi sert cette IA ?"
        />
        <Text style={S.label}>Style</Text>
        <TextInput style={S.input} value={style} onChangeText={setStyle} />
        <Btn
          label={busy ? 'Création…' : "Commencer l'apprentissage"}
          disabled={busy || !name.trim()}
          onPress={async () => {
            setBusy(true);
            try {
              await onCreated(blankAI(name.trim(), description.trim(), style));
            } finally {
              setBusy(false);
            }
          }}
        />
      </Card>
    </ScrollView>
  );
}

function AIs({
  ais,
  open,
  remove,
}: {
  ais: AI[];
  open: (ai: AI) => void;
  remove: (id: string) => Promise<void>;
}) {
  const [confirming, setConfirming] = useState<string | null>(null);

  return (
    <FlatList
      data={ais}
      keyExtractor={(item) => item.id}
      ListHeaderComponent={<PageHead eyebrow="Atelier" title="Mes IA">{`${ais.length} IA en cours de construction.`}</PageHead>}
      ListEmptyComponent={<Empty>Vous n'avez encore créé aucune IA.</Empty>}
      renderItem={({ item }) => (
        <Pressable style={S.card} onPress={() => open(item)}>
          <View style={S.rowBetween}>
            <Text style={{ fontWeight: '800', fontSize: 14.5 }}>{item.name}</Text>
            <Tag on={item.deployed}>{item.deployed ? 'déployée' : 'en cours'}</Tag>
          </View>
          <Text style={S.muted}>{item.description || 'Pas encore de description.'}</Text>
          <Text style={[S.muted, { marginTop: 4, fontSize: 11 }]}>
            {item.files.length} fichier(s) · {item.training.length} notion(s) · {item.apis.length} API
          </Text>
          <Pressable
            style={[S.button, S.buttonGhost, { marginTop: 10 }]}
            onPress={() => {
              if (confirming !== item.id) {
                setConfirming(item.id);
                return;
              }
              setConfirming(null);
              void remove(item.id);
            }}
          >
            <Text style={{ fontWeight: '800' }}>
              {confirming === item.id ? 'Confirmer la suppression' : 'Supprimer'}
            </Text>
          </Pressable>
        </Pressable>
      )}
    />
  );
}

function Dashboard({ ais, open }: { ais: AI[]; open: (ai: AI) => void }) {
  const totalTraining = ais.reduce((s, a) => s + a.training.length, 0);
  const totalFiles = ais.reduce((s, a) => s + a.files.length, 0);
  const totalApis = ais.reduce((s, a) => s + a.apis.length, 0);
  const deployed = ais.filter((a) => a.deployed).length;

  const stats: Array<{ num: number; lbl: string }> = [
    { num: ais.length, lbl: 'IA créées' },
    { num: deployed, lbl: 'déployées' },
    { num: totalTraining, lbl: 'notions enseignées' },
    { num: totalFiles, lbl: 'fichiers analysés' },
    { num: totalApis, lbl: 'API connectées' },
  ];

  return (
    <ScrollView>
      <PageHead eyebrow="Vue d'ensemble" title="Tableau de bord">
        L'état de tout ce que vous construisez ici.
      </PageHead>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        {stats.map((s) => (
          <View key={s.lbl} style={S.statBox}>
            <Text style={S.statNum}>{s.num}</Text>
            <Text style={S.statLbl}>{s.lbl}</Text>
          </View>
        ))}
      </View>
      <Card>
        <Text style={{ fontWeight: '800', fontSize: 15 }}>Progression par IA</Text>
        {ais.length === 0 ? (
          <Text style={S.muted}>Rien à afficher pour l'instant.</Text>
        ) : (
          ais.map((ai) => (
            <Pressable key={ai.id} style={S.divider} onPress={() => open(ai)}>
              <Text style={{ fontWeight: '700' }}>{ai.name}</Text>
              <Text style={[S.muted, { fontSize: 11.5 }]}>
                {ai.training.length} notions · {ai.files.length} fichiers · {ai.apis.length} API
              </Text>
            </Pressable>
          ))
        )}
      </Card>
    </ScrollView>
  );
}

function Account({ ais, onImported }: { ais: AI[]; onImported: () => Promise<void> }) {
  const [profile, setProfile] = useState<Profile>(blankProfile());
  const [importText, setImportText] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    void getProfile().then(setProfile);
  }, []);

  const exportAll = async () => {
    setError('');
    setNote('');
    setExporting(true);
    if (Platform.OS === 'android') {
      ToastAndroid.show('Préparation de l’export…', ToastAndroid.SHORT);
    }
    try {
      // Export complet : profil + chaque IA (systemPrompt, maxTokens, temperature,
      // training, files notes, apis) + historiques de chat
      const chats: Record<string, unknown> = {};
      for (const ai of ais) {
        chats[ai.id] = await getChat(ai.id);
      }
      const payloadObj = {
        version: 2,
        exportedAt: new Date().toISOString(),
        profile,
        ais,
        chats,
      };
      const payload = JSON.stringify(payloadObj, null, 2);
      const fileName = `vanelle-sauvegarde-${Date.now()}.json`;

      try {
        const RNFS = (await import('react-native-fs')).default;
        const dest =
          (RNFS.DownloadDirectoryPath || RNFS.DocumentDirectoryPath) + '/' + fileName;
        if (Platform.OS === 'android') {
          ToastAndroid.show('Téléchargement en cours…', ToastAndroid.SHORT);
        }
        await RNFS.writeFile(dest, payload, 'utf8');
        if (Platform.OS === 'android') {
          ToastAndroid.show('Téléchargement terminé : ' + fileName, ToastAndroid.LONG);
        }
        setNote(
          `Export terminé. Fichier enregistré : ${dest}\nContient profil, ${ais.length} IA (prompt, tokens, température, notions, fichiers, API) et chats.`
        );
        // Propose aussi le partage système
        try {
          await Share.share({
            message: payload,
            title: fileName,
          });
        } catch {
          /* partage optionnel */
        }
      } catch (fsErr) {
        // Fallback partage seul
        await Share.share({ message: payload, title: fileName });
        setNote(
          `Export partagé (écriture fichier impossible : ${
            fsErr instanceof Error ? fsErr.message : 'erreur'
          }). Données complètes incluses.`
        );
      }
    } catch (e) {
      const reason = e instanceof Error ? e.message : "L'export a échoué.";
      setError(reason);
    } finally {
      setExporting(false);
    }
  };

  const importAll = async () => {
    setError('');
    setNote('');
    try {
      const data = JSON.parse(importText) as {
        profile?: Profile;
        ais?: AI[];
        chats?: Record<string, unknown>;
      };
      if (data.profile) {
        const next = { ...blankProfile(), ...data.profile };
        await saveProfile(next);
        setProfile(next);
      }
      if (Array.isArray(data.ais)) {
        for (const ai of data.ais) await saveAI(ai);
      }
      // chats : restaurés si présents (best-effort via storage API)
      if (data.chats && typeof data.chats === 'object') {
        const { saveChat } = await import('./storage');
        for (const [id, msgs] of Object.entries(data.chats)) {
          if (Array.isArray(msgs)) {
            await saveChat(id, msgs as import('./types').Message[]);
          }
        }
      }
      await onImported();
      setImportText('');
      setNote('Sauvegarde importée (profil, IA, API, fichiers, notions, chats).');
    } catch (e) {
      const reason =
        e instanceof Error
          ? e.message
          : "Ce texte n'a pas pu être lu comme sauvegarde JSON.";
      setError(reason);
    }
  };

  return (
    <ScrollView>
      <PageHead eyebrow="Compte" title="Compte">
        Vos IA restent sur cet appareil.
      </PageHead>

      {error ? <ErrorBanner message={error} onDismiss={() => setError('')} /> : null}
      {note && !error ? <SuccessBanner message={note} /> : null}

      <Card>
        <Text style={{ fontWeight: '800', fontSize: 15 }}>Profil</Text>
        <Text style={S.label}>Votre nom ou pseudo</Text>
        <TextInput
          style={S.input}
          value={profile.pseudo}
          onChangeText={(v) => setProfile({ ...profile, pseudo: v })}
          placeholder="Ex. Camille"
        />
        <Btn label="Enregistrer" style={{ marginTop: 10 }} onPress={() => void saveProfile(profile)} />
      </Card>

      <Card>
        <Text style={{ fontWeight: '800', fontSize: 15 }}>Sauvegarde complète</Text>
        <Text style={S.muted}>
          L’export inclut tout : profil, chaque IA (systemPrompt, maxTokens, temperature, style),
          notions d’apprentissage, fichiers (notes/extraits), API, et historiques de chat.
          À l’import, les données s’ajoutent / mettent à jour sans tout effacer.
        </Text>
        <Btn
          label={exporting ? 'Export en cours…' : 'Exporter toutes mes données'}
          ghost
          style={{ marginTop: 10 }}
          disabled={exporting}
          onPress={() => void exportAll()}
        />
        <Text style={S.label}>Coller une sauvegarde (.json)</Text>
        <TextInput
          style={[S.input, { minHeight: 80, textAlignVertical: 'top' }]}
          value={importText}
          onChangeText={setImportText}
          multiline
          placeholder="{ ...contenu du fichier vanelle-sauvegarde.json... }"
        />
        <Btn
          label="Importer"
          ghost
          style={{ marginTop: 8 }}
          disabled={!importText.trim()}
          onPress={() => void importAll()}
        />
      </Card>
    </ScrollView>
  );
}
