export type Message = {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  ts: number;
};

export const CATEGORIES = [
  'Identité',
  'Personnalité',
  'Connaissances',
  'Compétences',
  'Règles',
] as const;
export type Category = (typeof CATEGORIES)[number];

export type Training = {
  id: string;
  category: Category | string;
  question: string;
  answer: string;
  ts: number;
};

export type VFile = {
  id: string;
  name: string;
  note: string;
  size: number;
  addedAt: number;
};

export type UserApi = {
  id: string;
  name: string;
  endpoint: string;
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | 'HEAD' | 'OPTIONS';
  description: string;
  /** Legacy field; migrated to Android Keystore vault and removed from persisted AI data. */
  apiKey?: string;
  secretRef?: string;
  protocol?: 'rest' | 'graphql' | 'sse' | 'websocket' | 'multipart' | 'binary' | 'mtls' | 'custom';
  oauth?: { authorizationUrl?: string; tokenUrl?: string; clientId?: string; scopes?: string[]; redirectUri?: string; usePKCE?: boolean; extraParams?: Record<string,string>; accessTokenRef?: string; refreshTokenRef?: string; tokenAuthMethod?: 'client_secret_basic'|'client_secret_post'|'none'; };
  /** Optional provider-specific request recipe. Secrets are referenced by secretRef only. */
  adapter?: { name?: string; canonicalTemplate?: string; signatureHeader?: string; signaturePrefix?: string; contentType?: string; binaryEncoding?: 'base64'; }; 
  mtlsRef?: string;
  signature?: { algorithm: 'hmac-sha256' | 'hmac-sha512' | 'sha256'; secretRef?: string; header?: string; prefix?: string; };
  customProtocol?: string;
  authType?: 'none' | 'apiKey' | 'bearer' | 'basic';
  authHeader?: string;
  username?: string;
  requestHeaders?: Record<string, string>;
  queryParams?: Record<string, string>;
  body?: string;
  timeoutMs?: number;
  retries?: number;
  retryNonIdempotent?: boolean;
  ts: number;
};

export type AI = {
  id: string;
  name: string;
  description: string;
  style: string;
  /** Les 3 traits de personnalité qui façonnent la voix de l'IA (injectés dans le prompt système). */
  traits: [string, string, string];
  systemPrompt: string;
  maxTokens: number;
  temperature: number;
  createdAt: number;
  training: Training[];
  files: VFile[];
  apis: UserApi[];
  deployed: boolean;
  deployedAt?: number;
};

export type Profile = {
  pseudo: string;
};

export const blankProfile = (): Profile => ({ pseudo: '' });
