import { VanelleNative } from './native';

export type ApiAuth =
  | { type: 'none' }
  | { type: 'apiKey'; key?: string; secretRef?: string; header?: string }
  | { type: 'bearer'; token?: string; secretRef?: string }
  | { type: 'basic'; username: string; password?: string; secretRef?: string };
export type ApiRequest = {
  endpoint:string; method?:'GET'|'POST'|'PUT'|'PATCH'|'DELETE'|'HEAD'|'OPTIONS'; headers?:Record<string,string>;
  query?:Record<string,string|number|boolean|null|undefined>; body?:unknown; auth?:ApiAuth; timeoutMs?:number; retries?:number; retryNonIdempotent?:boolean;
};
export type ApiCallResult={ok:boolean;status:number;statusText:string;headers:Record<string,string>;data:unknown;raw:string;elapsedMs:number;attempts:number};
const DEFAULT_TIMEOUT_MS=15_000, DEFAULT_RETRIES=2, RETRYABLE_STATUS=new Set([408,425,429,500,502,503,504]);
function parseBody(raw:string):unknown{if(!raw)return null;try{return JSON.parse(raw)}catch{return raw}}
export function validateApiEndpoint(endpoint:string):string{let u:URL;try{u=new URL(endpoint.trim())}catch{throw new Error('Endpoint invalide. Utilisez une URL complète.')}if(u.protocol!=='https:')throw new Error('Vanelle exige HTTPS pour les API Internet.');return u.toString()}
function buildUrl(endpoint:string,query?:ApiRequest['query']):string{const u=new URL(validateApiEndpoint(endpoint));if(query)for(const[k,v]of Object.entries(query))if(v!==undefined&&v!==null)u.searchParams.set(k,String(v));return u.toString()}
function authHeaders(auth:ApiAuth|undefined):Record<string,string>{if(!auth||auth.type==='none')return{};if(auth.type==='apiKey'&&auth.key!==undefined)return{[auth.header||'X-API-Key']:auth.key};if(auth.type==='bearer'&&auth.token!==undefined)return{Authorization:`Bearer ${auth.token}`};if(auth.type==='basic'&&auth.password!==undefined){const encoded=typeof btoa==='function'?btoa(`${auth.username}:${auth.password}`):'';if(!encoded)throw new Error('Authentification Basic indisponible.');return{Authorization:`Basic ${encoded}`}}return{}}
function retryDelay(a:number){return Math.min(5000,400*2**(a-1))+Math.floor(Math.random()*250)}
const sleep=(ms:number)=>new Promise<void>((resolve)=>setTimeout(resolve,ms));
function utf8Base64(s:string){const bytes=unescape(encodeURIComponent(s));return typeof btoa==='function'?btoa(bytes):''}
async function nativeSecure(cfg:ApiRequest,secretRef:string,authType:string,authHeader?:string,username?:string):Promise<ApiCallResult>{
  if(!VanelleNative)throw new Error('Le module réseau sécurisé Android est indisponible.');
  const u=buildUrl(cfg.endpoint,cfg.query); const headers:Record<string,string>={Accept:'application/json, text/plain, */*',...(cfg.headers||{})};
  let bodyBase64:string|undefined; if(cfg.body!==undefined&&cfg.method!=='GET'&&cfg.method!=='HEAD') bodyBase64=utf8Base64(typeof cfg.body==='string'?cfg.body:JSON.stringify(cfg.body));
  const started=Date.now(); const r=await VanelleNative.secureApiRequest(u,cfg.method||'GET',JSON.stringify(headers),bodyBase64,secretRef,authType,authHeader,username);
  const rawBytes=globalThis.atob?globalThis.atob(r.bodyBase64):''; let raw=''; for(let i=0;i<rawBytes.length;i++)raw+=String.fromCharCode(rawBytes.charCodeAt(i));
  return{ok:r.status>=200&&r.status<300,status:r.status,statusText:'',headers:r.headers,data:parseBody(raw),raw,elapsedMs:Date.now()-started,attempts:1};
}
export async function callConfiguredApi(request:ApiRequest|string,legacyMethod:ApiRequest['method']='GET',legacyBody?:unknown,legacyTimeout=DEFAULT_TIMEOUT_MS):Promise<ApiCallResult>{
  const cfg:ApiRequest=typeof request==='string'?{endpoint:request,method:legacyMethod,body:legacyBody,timeoutMs:legacyTimeout}:request;
  const a=cfg.auth; const secureRef=a&&a.type!=='none'?a.secretRef:undefined;
  if(secureRef){ if(a!.type==='apiKey'||a!.type==='bearer'||a!.type==='basic') return nativeSecure(cfg,secureRef,a!.type,a!.type==='apiKey'?a!.header:undefined,a!.type==='basic'?a!.username:undefined); }
  const method=cfg.method||'GET',url=buildUrl(cfg.endpoint,cfg.query),retries=Math.max(0,cfg.retries??DEFAULT_RETRIES),canRetry=method==='GET'||method==='HEAD'||method==='OPTIONS'||!!cfg.retryNonIdempotent,maxAttempts=canRetry?retries+1:1;let lastError:unknown;const startedAll=Date.now();
  for(let attempt=1;attempt<=maxAttempts;attempt++){const c=new AbortController(),timeout=setTimeout(()=>c.abort(),cfg.timeoutMs??DEFAULT_TIMEOUT_MS);try{const headers={Accept:'application/json, text/plain, */*',...authHeaders(a),...(cfg.headers||{})};let body:string|undefined;if(cfg.body!==undefined&&method!=='GET'&&method!=='HEAD'){body=typeof cfg.body==='string'?cfg.body:JSON.stringify(cfg.body);if(!Object.keys(headers).some(k=>k.toLowerCase()==='content-type'))headers['Content-Type']='application/json'}const response=await fetch(url,{method,headers,body,signal:c.signal});const raw=await response.text();const rh:Record<string,string>={};response.headers.forEach((v,k)=>rh[k]=v);const result={ok:response.ok,status:response.status,statusText:response.statusText,headers:rh,data:parseBody(raw),raw,elapsedMs:Date.now()-startedAll,attempts:attempt};if(response.ok||!canRetry||!RETRYABLE_STATUS.has(response.status)||attempt>=maxAttempts)return result;const ra=Number(rh['retry-after']);await sleep(Number.isFinite(ra)?Math.min(30000,ra*1000):retryDelay(attempt))}catch(e){lastError=e;if(attempt>=maxAttempts)break;await sleep(retryDelay(attempt))}finally{clearTimeout(timeout)}}if((lastError as any)?.name==='AbortError')throw new Error(`L'API n'a pas répondu dans ${Math.round((cfg.timeoutMs??DEFAULT_TIMEOUT_MS)/1000)} s.`);throw new Error(`Impossible de joindre l'API après ${maxAttempts} tentative(s). ${lastError instanceof Error?lastError.message:''}`.trim())}
export function callGraphQL(endpoint:string,query:string,variables?:Record<string,unknown>,auth?:ApiAuth){return callConfiguredApi({endpoint,method:'POST',auth,body:{query,variables},retries:1})}
export function summarizeApiData(data:unknown){if(data===null)return'Réponse vide.';if(typeof data==='string')return data.slice(0,1000);try{return JSON.stringify(data,null,2).slice(0,1800)}catch{return'Réponse reçue mais impossible à afficher.'}}
