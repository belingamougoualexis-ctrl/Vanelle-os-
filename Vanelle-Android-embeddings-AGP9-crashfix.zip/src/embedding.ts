import { VanelleNative } from './native';

export type EmbeddingMode = 'query' | 'document';

/**
 * Public JS helper for Vanelle's real on-device Nomic embedding engine.
 * It never falls back to a fake vector or a cloud API.
 */
export async function embedText(text: string, mode: EmbeddingMode = 'query'): Promise<number[]> {
  if (!VanelleNative) {
    throw new Error('Le moteur natif Vanelle n’est pas disponible sur cette plateforme.');
  }
  const value = text.trim();
  if (!value) throw new Error('Le texte à encoder ne peut pas être vide.');
  return VanelleNative.embedText(value, mode);
}

export async function embeddingDimension(): Promise<number> {
  if (!VanelleNative) {
    throw new Error('Le moteur natif Vanelle n’est pas disponible sur cette plateforme.');
  }
  return VanelleNative.embeddingDimension();
}
