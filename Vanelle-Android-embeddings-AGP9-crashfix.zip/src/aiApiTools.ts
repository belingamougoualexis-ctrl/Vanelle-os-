import type { AI, UserApi } from './types';
import { callConfiguredApi, summarizeApiData } from './apiClient';
import { executeAdvancedApiAction } from './universalApi';

export type ApiToolCall = {
  apiId: string;
  method?: UserApi['method'];
  query?: Record<string, string | number | boolean | null>;
  body?: unknown;
  action?: 'request'|'websocket_open'|'websocket_send'|'websocket_close'|'sse_open'|'sse_close';
  id?: string;
  text?: string;
  base64?: string;
  authorization?: boolean;
};

const SAFE_METHODS = new Set<UserApi['method']>(['GET', 'HEAD', 'OPTIONS']);

export function buildApiToolInstructions(ai: AI): string {
  const available = ai.apis.map((api) => ({
    id: api.id, name: api.name, description: api.description, protocol: api.protocol ?? 'rest',
    method: api.method, endpoint: api.endpoint,
    actions: api.protocol==='websocket' ? ['websocket_open','websocket_send','websocket_close'] : api.protocol==='sse' ? ['sse_open','sse_close'] : ['request'],
    authentication: api.oauth?.accessTokenRef ? 'oauth-bearer-vault' : (api.authType || 'none'),
    secret: 'NE JAMAIS DEMANDER NI AFFICHER LE SECRET',
  }));
  if (!available.length) return '';
  return [
    'OUTILS API VANELLE — CONTRAT D’EXÉCUTION',
    'Tu peux utiliser uniquement les outils explicitement listés ci-dessous.',
    'Ne fabrique jamais une clé, un token, un endpoint, un statut ou une donnée.',
    'Pour une requête, réponds UNIQUEMENT avec BEGIN_VANELLE_API puis JSON puis END_VANELLE_API.',
    'Format requête: {"apiId":"ID","action":"request","method":"GET","query":{},"body":null}',
    'WebSocket: action websocket_open/websocket_send/websocket_close avec id et text ou base64.',
    'SSE: action sse_open/sse_close avec id.',
    'GET/HEAD/OPTIONS sont exécutables automatiquement. POST/PUT/PATCH/DELETE nécessitent confirmation.',
    'mTLS, multipart et binaire doivent utiliser leur protocole déclaré; ne les transforme jamais en REST arbitraire.',
    'OAuth: si aucun access token valide n’est disponible, retourne AUTH_REQUIRED; ne demande jamais à l’utilisateur de coller un secret dans le chat.',
    'Après un résultat d’outil, réponds uniquement avec les données réellement reçues et distingue clairement erreur réseau, HTTP et absence de données.',
    `APIs DISPONIBLES:\n${JSON.stringify(available, null, 2)}`,
  ].join('\n');
}

export function parseApiToolCall(text: string): ApiToolCall | null {
  const match = text.match(/BEGIN_VANELLE_API\s*([\s\S]*?)\s*END_VANELLE_API/i);
  if (!match) return null;
  try {
    const value = JSON.parse(match[1]);
    if (!value || typeof value.apiId !== 'string') return null;
    return value as ApiToolCall;
  } catch {
    return null;
  }
}

export async function executeApiTool(ai: AI, call: ApiToolCall): Promise<string> {
  const api = ai.apis.find((x) => x.id === call.apiId);
  if (!api) throw new Error('API demandée introuvable dans cette IA.');
  const action = call.action || 'request';
  if (action === 'oauth_start') {
    if (!api.oauth?.authorizationUrl || !api.oauth.clientId) return 'AUTH_REQUIRED: cette API OAuth n’a pas de configuration d’autorisation complète.';
    return 'AUTH_REQUIRED: une autorisation OAuth interactive est nécessaire. L’interface Vanelle doit lancer le navigateur et obtenir le consentement de l’utilisateur avant de poursuivre.';
  }
  if (action !== 'request') {
    const result = await executeAdvancedApiAction(api, {type: action as any, id: call.id, text: call.text, base64: call.base64});
    return `API_RESULT\n${JSON.stringify(result ?? true).slice(0,4000)}`;
  }
  const method = call.method ?? api.method;
  if (!SAFE_METHODS.has(method)) {
    return `CONFIRMATION_REQUISE: l’appel ${method} vers « ${api.name} » peut modifier des données. Je dois obtenir votre confirmation avant de l’exécuter.`;
  }
  const result = await executeAdvancedApiAction(api, {type:'request', method, query:call.query, body:call.body});
  if (result && 'status' in result) {
    const r:any=result;
    return `API_RESULT\nHTTP ${r.status}${r.statusText ? ` ${r.statusText}` : ''}\n${summarizeApiData(r.data ?? r)}`;
  }
  return `API_RESULT\n${summarizeApiData(result)}`;
}
