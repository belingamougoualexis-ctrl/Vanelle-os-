import React, { useEffect, useRef } from 'react';
import {
  Animated,
  Pressable,
  StyleSheet,
  Text,
  Vibration,
  View,
} from 'react-native';

export const colors = {
  bg: '#F7F6F2',
  header: '#0B0B10',
  accent: '#7C5CFF',
  accentSoft: '#EEE9FF',
  accentWarm: '#E9C98A',
  ink: '#111117',
  inkSoft: '#6B6B76',
  line: '#E5E3DE',
  inputLine: '#D8D5CF',
  white: '#FFFFFF',
  surface: '#FFFFFF',
  surfaceAlt: '#F1F0EC',
  danger: '#B42318',
  dangerBg: '#FEF0EE',
  dangerBorder: '#F5C2BC',
  success: '#176B4D',
  successBg: '#EAF7F0',
};

export const S = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { backgroundColor: colors.header, padding: 18 },
  brand: { color: '#fff', fontFamily: 'sans-serif', fontWeight: '800', fontSize: 17, letterSpacing: 1.4 },
  sub: { color: colors.accentWarm, fontFamily: 'sans-serif-medium', fontSize: 9, letterSpacing: 1.8 },
  body: { flex: 1, padding: 16 },
  title: { fontFamily: 'sans-serif', fontSize: 25, fontWeight: '800', color: colors.ink, marginBottom: 5, letterSpacing: -0.35 },
  eyebrow: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.5,
    color: colors.accent,
    fontFamily: 'sans-serif-medium',
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  muted: { color: colors.inkSoft, fontFamily: 'sans-serif', fontSize: 13, lineHeight: 19 },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: colors.line,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOpacity: 0.045,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
    elevation: 2,
  },
  label: {
    fontSize: 12,
    fontWeight: '700',
    color: '#505057',
    marginTop: 10,
    marginBottom: 6,
  },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: colors.inputLine,
    borderRadius: 12,
    paddingHorizontal: 13,
    paddingVertical: 12,
    color: colors.ink,
  },
  button: {
    backgroundColor: colors.accent,
    borderRadius: 13,
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 12,
  },
  buttonGhost: {
    backgroundColor: '#e9e9e4',
  },
  buttonText: { color: '#fff', fontFamily: 'sans-serif-medium', fontWeight: '800', letterSpacing: 0.1 },
  buttonTextGhost: { color: colors.ink },
  nav: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: colors.line,
    backgroundColor: '#fff',
  },
  navItem: { flex: 1, alignItems: 'center', paddingVertical: 12 },
  navText: { fontSize: 10.5, fontWeight: '700', color: '#77777d' },
  navActive: { color: colors.accent, fontWeight: '800' },
  status: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 12,
    padding: 12,
    marginBottom: 14,
  },
  row: { flexDirection: 'row', alignItems: 'center' },
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.accent,
    marginRight: 8,
  },
  pillRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 8 },
  pill: {
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1.5,
    borderColor: colors.line,
    backgroundColor: '#fff',
  },
  pillActive: { backgroundColor: colors.accent, borderColor: colors.accent },
  pillText: { fontSize: 11.5, fontWeight: '700', color: colors.ink },
  pillTextActive: { color: '#fff' },
  tag: {
    borderRadius: 20,
    paddingHorizontal: 8,
    paddingVertical: 3,
    backgroundColor: '#eee',
  },
  tagOn: { backgroundColor: colors.accentSoft },
  tagText: { fontSize: 10.5, fontWeight: '700', color: colors.inkSoft },
  tagTextOn: { color: colors.accent },
  statBox: {
    flexGrow: 1,
    flexBasis: '30%',
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    marginRight: 8,
  },
  statNum: { fontSize: 26, fontWeight: '800', color: colors.accent },
  statLbl: { fontSize: 11, fontWeight: '700', color: colors.inkSoft, marginTop: 2 },
  divider: { borderBottomWidth: 1, borderBottomColor: colors.line, paddingVertical: 10 },
  errorBanner: {
    backgroundColor: colors.dangerBg,
    borderWidth: 1.5,
    borderColor: colors.dangerBorder,
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
  },
  errorText: {
    color: colors.danger,
    fontSize: 13,
    fontWeight: '700',
    lineHeight: 18,
  },
  successBanner: {
    backgroundColor: colors.accentSoft,
    borderWidth: 1,
    borderColor: '#c5e0a0',
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
  },
  successText: {
    color: '#3d5c0a',
    fontSize: 13,
    fontWeight: '700',
    lineHeight: 18,
  },
});

/** Message d'erreur rouge qui vibre — raison claire pour l'utilisateur. */
export function ErrorBanner({
  message,
  onDismiss,
}: {
  message: string;
  onDismiss?: () => void;
}) {
  const shake = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!message) return;
    Vibration.vibrate([0, 40, 40, 40, 40, 60]);
    Animated.sequence([
      Animated.timing(shake, { toValue: 8, duration: 45, useNativeDriver: true }),
      Animated.timing(shake, { toValue: -8, duration: 45, useNativeDriver: true }),
      Animated.timing(shake, { toValue: 6, duration: 40, useNativeDriver: true }),
      Animated.timing(shake, { toValue: -6, duration: 40, useNativeDriver: true }),
      Animated.timing(shake, { toValue: 0, duration: 35, useNativeDriver: true }),
    ]).start();
  }, [message, shake]);

  if (!message) return null;

  return (
    <Animated.View style={[S.errorBanner, { transform: [{ translateX: shake }] }]}>
      <Pressable onPress={onDismiss}>
        <Text style={S.errorText}>{message}</Text>
        {onDismiss ? (
          <Text style={[S.errorText, { marginTop: 4, fontWeight: '500', fontSize: 11 }]}>
            Appuyez pour fermer
          </Text>
        ) : null}
      </Pressable>
    </Animated.View>
  );
}

export function SuccessBanner({ message }: { message: string }) {
  if (!message) return null;
  return (
    <View style={S.successBanner}>
      <Text style={S.successText}>{message}</Text>
    </View>
  );
}

export function Card({ children, style }: { children: React.ReactNode; style?: object }) {
  return <View style={[S.card, style]}>{children}</View>;
}

export function PageHead({
  eyebrow,
  title,
  children,
}: {
  eyebrow: string;
  title: string;
  children?: React.ReactNode;
}) {
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={S.eyebrow}>{eyebrow}</Text>
      <Text style={S.title}>{title}</Text>
      {children ? <Text style={S.muted}>{children}</Text> : null}
    </View>
  );
}

export function Tag({ on, children }: { on: boolean; children: React.ReactNode }) {
  return (
    <View style={[S.tag, on && S.tagOn]}>
      <Text style={[S.tagText, on && S.tagTextOn]}>{children}</Text>
    </View>
  );
}

export function Pill({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable style={[S.pill, active && S.pillActive]} onPress={onPress}>
      <Text style={[S.pillText, active && S.pillTextActive]}>{label}</Text>
    </Pressable>
  );
}

export function Btn({
  label,
  onPress,
  ghost,
  disabled,
  style,
}: {
  label: string;
  onPress: () => void;
  ghost?: boolean;
  disabled?: boolean;
  style?: object;
}) {
  return (
    <Pressable
      style={[S.button, ghost && S.buttonGhost, disabled && { opacity: 0.6 }, style]}
      disabled={disabled}
      onPress={onPress}
    >
      <Text style={[S.buttonText, ghost && S.buttonTextGhost]}>{label}</Text>
    </Pressable>
  );
}

export function Row({ k, v }: { k: string; v: string }) {
  return (
    <View style={[S.rowBetween, S.divider]}>
      <Text style={{ fontSize: 13, color: colors.ink }}>{k}</Text>
      <Text style={{ fontSize: 13, fontWeight: '800', color: colors.ink }}>{v}</Text>
    </View>
  );
}

export function Step({ n, children }: { n: number; children: React.ReactNode }) {
  return (
    <View style={[S.row, { marginTop: 2, marginBottom: 8 }]}>
      <View
        style={{
          width: 20,
          height: 20,
          borderRadius: 10,
          backgroundColor: colors.accent,
          alignItems: 'center',
          justifyContent: 'center',
          marginRight: 8,
        }}
      >
        <Text style={{ color: '#fff', fontSize: 11, fontWeight: '800' }}>{n}</Text>
      </View>
      <Text style={{ fontSize: 15, fontWeight: '800', color: colors.ink }}>{children}</Text>
    </View>
  );
}

export function Empty({ children }: { children: React.ReactNode }) {
  return (
    <Card>
      <Text style={S.muted}>{children}</Text>
    </Card>
  );
}
