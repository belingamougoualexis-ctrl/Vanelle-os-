import { Linking } from 'react-native';
import { VanelleNative, VanelleNativeEvents } from './native';
import { callConfiguredApi } from './apiClient';

export async function createPkce(){
  if(!VanelleNative) throw new Error('Module natif Android indisponible.');
  const verifier=await VanelleNative.createPkceVerifier();
  const challenge=await VanelleNative.pkceChallenge(verifier);
  return{verifier,challenge};
}
export async function startOAuth(cfg:{authorizationUrl:string;clientId:string;redirectUri?:string;scopes?:string[];extraParams?:Record<string,string>}){
  const pkce=await createPkce(); const state=pkce.verifier.slice(0,32);
  const u=new URL(cfg.authorizationUrl); u.searchParams.set('response_type','code'); u.searchParams.set('client_id',cfg.clientId); u.searchParams.set('redirect_uri',cfg.redirectUri||'vanelle://oauth'); u.searchParams.set('scope',(cfg.scopes||[]).join(' ')); u.searchParams.set('state',state); u.searchParams.set('code_challenge',pkce.challenge); u.searchParams.set('code_challenge_method','S256'); Object.entries(cfg.extraParams||{}).forEach(([k,v])=>u.searchParams.set(k,v));
  if(VanelleNative) await VanelleNative.startOAuth(u.toString()); else await Linking.openURL(u.toString()); return{state,verifier:pkce.verifier};
}
export function onOAuthRedirect(cb:(url:string)=>void){return VanelleNativeEvents?.addListener('vanelle.oauth.redirect',(e:{url:string})=>cb(e.url))||{remove(){}}}

export function parseOAuthRedirect(url:string){
  const u=new URL(url);
  const error=u.searchParams.get('error');
  if(error) throw new Error(`OAuth a échoué : ${error}${u.searchParams.get('error_description') ? ` — ${u.searchParams.get('error_description')}` : ''}`);
  const code=u.searchParams.get('code');
  const state=u.searchParams.get('state');
  if(!code) throw new Error('Réponse OAuth invalide : code d’autorisation absent.');
  return {code,state};
}
export async function exchangeCode(tokenUrl:string,clientId:string,code:string,verifier:string,redirectUri='vanelle://oauth'){
  return callConfiguredApi({endpoint:tokenUrl,method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'authorization_code',client_id:clientId,code,code_verifier:verifier,redirect_uri:redirectUri}).toString(),retries:0});
}
