import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AI, Message, Profile } from './types';
import { blankProfile } from './types';
import { VanelleNative } from './native';

const AIS_KEY = '@vanelle/ais';
const PROFILE_KEY = '@vanelle/profile';
const chatKey = (id: string) => `@vanelle/chat/${id}`;

// Complète les champs manquants pour les IA enregistrées avant l'ajout
// de l'apprentissage / des fichiers / des API — aucune donnée perdue.
function migrate(ai: Partial<AI> & { id: string; name: string }): AI {
  return {
    id: ai.id,
    name: ai.name,
    description: ai.description ?? '',
    style: ai.style ?? 'Généraliste',
    traits: (ai.traits && ai.traits.length === 3 ? ai.traits : ['', '', '']) as [string, string, string],
    systemPrompt: ai.systemPrompt ?? '',
    maxTokens: ai.maxTokens ?? 700,
    temperature: ai.temperature ?? 0.4,
    createdAt: ai.createdAt ?? Date.now(),
    training: ai.training ?? [],
    files: ai.files ?? [],
    apis: ai.apis ?? [],
    deployed: ai.deployed ?? false,
    deployedAt: ai.deployedAt,
  };
}

export async function getAIs(): Promise<AI[]> {
  const raw = await AsyncStorage.getItem(AIS_KEY);
  if (!raw) return [];
  try {
    const list = (JSON.parse(raw) as Array<Partial<AI> & { id: string; name: string }>).map(migrate);
    let changed = false;
    for (const ai of list) {
      for (const api of ai.apis) {
        if (api.apiKey && VanelleNative) {
          const ref = api.secretRef || `api:${ai.id}:${api.id}`;
          await VanelleNative.vaultPut(ref, api.apiKey);
          api.secretRef = ref;
          delete api.apiKey;
          changed = true;
        }
      }
    }
    if (changed) await AsyncStorage.setItem(AIS_KEY, JSON.stringify(list));
    return list;
  } catch { return []; }
}

export async function getAI(id: string): Promise<AI | undefined> {
  const list = await getAIs();
  return list.find((x) => x.id === id);
}

export async function saveAI(ai: AI): Promise<void> {
  const safe = { ...ai, apis: await Promise.all(ai.apis.map(async (api) => {
    if (api.apiKey && VanelleNative) {
      const ref = api.secretRef || `api:${ai.id}:${api.id}`;
      await VanelleNative.vaultPut(ref, api.apiKey);
      const { apiKey: _discarded, ...withoutSecret } = api;
      return { ...withoutSecret, secretRef: ref };
    }
    return api;
  })) };
  const list = await getAIs();
  const next = list.some((x) => x.id === safe.id) ? list.map((x) => x.id === safe.id ? safe : x) : [safe, ...list];
  await AsyncStorage.setItem(AIS_KEY, JSON.stringify(next));
}

export async function deleteAI(id: string): Promise<void> {
  const list = await getAIs();
  await AsyncStorage.setItem(
    AIS_KEY,
    JSON.stringify(list.filter((x) => x.id !== id))
  );
  const removed = list.find((x) => x.id === id);
  if (removed && VanelleNative) {
    for (const api of removed.apis) if (api.secretRef) await VanelleNative.vaultDelete(api.secretRef);
  }
  await AsyncStorage.removeItem(chatKey(id));
}

export async function getChat(id: string): Promise<Message[]> {
  const raw = await AsyncStorage.getItem(chatKey(id));
  if (!raw) return [];
  try {
    return JSON.parse(raw) as Message[];
  } catch {
    return [];
  }
}

export async function saveChat(id: string, messages: Message[]): Promise<void> {
  await AsyncStorage.setItem(chatKey(id), JSON.stringify(messages));
}

export async function getProfile(): Promise<Profile> {
  const raw = await AsyncStorage.getItem(PROFILE_KEY);
  if (!raw) return blankProfile();
  try {
    return { ...blankProfile(), ...(JSON.parse(raw) as Profile) };
  } catch {
    return blankProfile();
  }
}

export async function saveProfile(profile: Profile): Promise<void> {
  await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
}
