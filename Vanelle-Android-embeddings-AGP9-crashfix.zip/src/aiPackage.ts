import JSZip from 'jszip';
import type { AI, Message } from './types';

/**
 * Format du .zip exporté pour une IA Vanelle :
 *  - manifest.json      → métadonnées du paquet (version, date, nom de l'app)
 *  - ai.json             → fiche complète de l'IA (identité, style, systemPrompt,
 *                          maxTokens, temperature, apis, statut de déploiement)
 *  - training.json       → toutes les notions question/réponse (apprentissage)
 *  - files/manifest.json → liste des fichiers connaissances (nom, taille, date)
 *  - files/<id>.txt      → contenu texte extrait de chaque fichier connaissance
 *                          (les fichiers binaires/images gardent seulement leur note)
 *  - chat-history.json   → historique de conversation de test, pour reprendre le fil
 *
 * Choix volontaire : tout ce dont l'IA a besoin pour continuer à apprendre et à
 * répondre est inclus, mais rien d'exécutable — l'import ne fait que relire du JSON
 * et du texte, il ne réinstalle aucun code.
 */

const PACKAGE_VERSION = 1;

export async function buildAIZip(ai: AI, chat: Message[]): Promise<string> {
  const zip = new JSZip();

  zip.file(
    'manifest.json',
    JSON.stringify(
      {
        app: 'Vanelle',
        packageVersion: PACKAGE_VERSION,
        exportedAt: new Date().toISOString(),
      },
      null,
      2
    )
  );

  zip.file(
    'ai.json',
    JSON.stringify(
      {
        id: ai.id,
        name: ai.name,
        description: ai.description,
        style: ai.style,
        traits: ai.traits,
        systemPrompt: ai.systemPrompt,
        maxTokens: ai.maxTokens,
        temperature: ai.temperature,
        createdAt: ai.createdAt,
        deployed: ai.deployed,
        deployedAt: ai.deployedAt,
        // Never export credentials in a portable .zip. The endpoint configuration is portable;
        // secrets must be re-entered on the destination device/backend.
        apis: ai.apis.map(({ apiKey: _secret, secretRef: _secretRef, ...api }) => api),
      },
      null,
      2
    )
  );

  zip.file('training.json', JSON.stringify(ai.training, null, 2));

  const filesFolder = zip.folder('files');
  if (filesFolder) {
    filesFolder.file(
      'manifest.json',
      JSON.stringify(
        ai.files.map((f) => ({
          id: f.id,
          name: f.name,
          size: f.size,
          addedAt: f.addedAt,
        })),
        null,
        2
      )
    );
    for (const f of ai.files) {
      filesFolder.file(`${f.id}.txt`, f.note);
    }
  }

  zip.file('chat-history.json', JSON.stringify(chat, null, 2));

  return zip.generateAsync({ type: 'base64' });
}

export type ImportedAIPackage = {
  ai: AI;
  chat: Message[];
};

/**
 * Relit un .zip exporté par buildAIZip et reconstitue une AI complète, prête à
 * être enregistrée avec un nouvel id (pour ne jamais écraser une IA existante
 * du même nom par accident) afin que l'utilisateur puisse continuer à
 * l'entraîner directement après import.
 */
export async function parseAIZip(
  base64: string,
  makeId: () => string
): Promise<ImportedAIPackage> {
  const zip = await JSZip.loadAsync(base64, { base64: true });

  const readJSON = async <T,>(path: string, fallback: T): Promise<T> => {
    const entry = zip.file(path);
    if (!entry) return fallback;
    const text = await entry.async('string');
    try {
      return JSON.parse(text) as T;
    } catch {
      return fallback;
    }
  };

  const aiJson = await readJSON<Partial<AI> & { name?: string }>('ai.json', {});
  if (!aiJson.name || !aiJson.name.trim()) {
    throw new Error("Ce .zip ne contient pas d'IA Vanelle valide (ai.json manquant).");
  }

  const training = await readJSON('training.json', []);
  const filesManifest = await readJSON<
    Array<{ id: string; name: string; size: number; addedAt: number }>
  >('files/manifest.json', []);

  const files = await Promise.all(
    filesManifest.map(async (f) => {
      const entry = zip.file(`files/${f.id}.txt`);
      const note = entry ? await entry.async('string') : '';
      return { id: f.id, name: f.name, size: f.size, addedAt: f.addedAt, note };
    })
  );

  const chat = await readJSON<Message[]>('chat-history.json', []);

  const ai: AI = {
    id: makeId(),
    name: aiJson.name.trim(),
    description: aiJson.description ?? '',
    style: aiJson.style ?? 'Généraliste',
    traits: (aiJson.traits && aiJson.traits.length === 3 ? aiJson.traits : ['', '', '']) as [string, string, string],
    systemPrompt: aiJson.systemPrompt ?? '',
    maxTokens: aiJson.maxTokens ?? 700,
    temperature: aiJson.temperature ?? 0.4,
    createdAt: Date.now(),
    training,
    files,
    apis: aiJson.apis ?? [],
    deployed: false,
  };

  return { ai, chat };
}
