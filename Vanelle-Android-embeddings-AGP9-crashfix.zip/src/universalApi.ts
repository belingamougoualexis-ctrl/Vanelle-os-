import { VanelleNative, VanelleNativeEvents } from './native';
export async function signHmac(secretRef:string,algorithm:'hmac-sha256'|'hmac-sha512',canonical:string){if(!VanelleNative)throw new Error('Module natif indisponible.');return VanelleNative.signHmac(secretRef,algorithm,canonical)}
export async function multipartRequest(url:string,headers:Record<string,string>,fields:Record<string,string>,files:Array<{name:string;filename:string;base64:string}>){if(!VanelleNative)throw new Error('Module natif indisponible.');return VanelleNative.multipartRequest(url,JSON.stringify(headers),JSON.stringify(fields),JSON.stringify(files))}
export function onWebSocket(event:'open'|'message'|'binary'|'closing'|'error',cb:(payload:any)=>void){return VanelleNativeEvents?.addListener(`vanelle.websocket.${event}`,cb)||{remove(){}}}
export function onSse(event:'event'|'error',cb:(payload:any)=>void){return VanelleNativeEvents?.addListener(`vanelle.sse.${event}`,cb)||{remove(){}}}


export type AdvancedApiAction =
  | { type:'request'; method?:string; query?:Record<string,unknown>; body?:unknown; headers?:Record<string,string> }
  | { type:'websocket_open'|'websocket_send'|'websocket_close'|'sse_open'|'sse_close'; id?:string; text?:string; base64?:string };

export async function executeAdvancedApiAction(api:any, action:AdvancedApiAction){
  const protocol=api.protocol || 'rest';
  const id=action.id || `vanelle-${api.id}`;
  const headers={...(api.requestHeaders||{}),...(action.type==='request' ? (action.headers||{}) : {})};
  if(protocol==='websocket'){
    if(action.type==='websocket_open') return VanelleNative?.openWebSocket(id,api.endpoint,JSON.stringify(headers));
    if(action.type==='websocket_send') return VanelleNative?.sendWebSocket(id,action.text||null,action.base64||null);
    if(action.type==='websocket_close'){ VanelleNative?.closeWebSocket(id); return true; }
  }
  if(protocol==='sse'){
    if(action.type==='sse_open') return VanelleNative?.openSse(id,api.endpoint,JSON.stringify(headers));
    if(action.type==='sse_close'){ VanelleNative?.closeSse(id); return true; }
  }
  if(action.type!=='request') throw new Error(`Action ${action.type} incompatible avec le protocole ${protocol}.`);
  if(protocol==='multipart') return VanelleNative?.multipartRequest(api.endpoint,JSON.stringify(headers),JSON.stringify(action.body?.fields||{}),JSON.stringify(action.body?.files||[]));
  if(protocol==='mtls') { const b=typeof action.body==='string' ? action.body : action.body==null ? null : (globalThis.btoa ? globalThis.btoa(unescape(encodeURIComponent(JSON.stringify(action.body)))) : null); return VanelleNative?.mtlsRequest(api.mtlsRef||api.id,api.endpoint,action.method||api.method,JSON.stringify(headers),b); }
  if(api.signature?.secretRef && api.signature.algorithm.startsWith('hmac')) { const canonical=api.adapter?.canonicalTemplate ? api.adapter.canonicalTemplate.replace('{method}',String(action.method||api.method)).replace('{url}',api.endpoint).replace('{body}',typeof action.body==='string'?action.body:JSON.stringify(action.body??'')) : `${String(action.method||api.method).toUpperCase()}\n${api.endpoint}\n${typeof action.body==='string'?action.body:JSON.stringify(action.body??'')}`; const sig=await signHmac(api.signature.secretRef,api.signature.algorithm as any,canonical); headers[api.signature.header||'X-Vanelle-Signature']=(api.signature.prefix||'')+sig; } return callConfiguredApi({endpoint:api.endpoint,method:(action.method||api.method) as any,headers,query:(action.query||api.queryParams) as any,body:action.body ?? api.body,timeoutMs:api.timeoutMs,retries:api.retries,auth: api.oauth?.accessTokenRef ? {type:'bearer',secretRef:api.oauth.accessTokenRef} : api.secretRef ? ({type:api.authType||'apiKey',secretRef:api.secretRef,header:api.authHeader,username:api.username} as any) : {type:'none'}});
}
