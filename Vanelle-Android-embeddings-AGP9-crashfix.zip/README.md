# Vanelle

Vanelle is a bare React Native Android application with a native llama.cpp bridge.

## Requirements
- Node.js >= 22.13
- JDK 17 recommended
- Android SDK/Build Tools compatible with React Native 0.87
- Run `npm install`, then `npm run android`

## Models
- SmolLM2-360M-Instruct Q4_K_M
- Nomic Embed Text v1.5 Q4_K_M
