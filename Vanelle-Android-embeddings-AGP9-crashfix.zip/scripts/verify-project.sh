#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

test -f package.json
test -f android/settings.gradle
test -f android/build.gradle
test -f android/app/build.gradle
test -x android/gradlew
node -e "const p=require('./package.json'); if(p.dependencies?.['react-native']!=='0.87.0') throw new Error('react-native must be 0.87.0')"
if [ -d node_modules ]; then
  test -d node_modules/@react-native/gradle-plugin
  test -d node_modules/react-native
fi
printf '%s\n' 'Vanelle project layout/configuration: OK'
