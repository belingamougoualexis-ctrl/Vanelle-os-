#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [ ! -d node_modules/@react-native/gradle-plugin ]; then
  npm install --include=dev --no-audit --no-fund
fi
test -d node_modules/@react-native/gradle-plugin
echo "React Native Gradle plugin: OK"
