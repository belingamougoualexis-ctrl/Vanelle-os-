#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

test -f android/app/src/main/cpp/CMakeLists.txt
test -f android/app/src/main/cpp/llama_embedding_jni.cpp
test -f android/app/src/main/java/com/vanelle/app/EmbeddingEngine.kt
test -f android/app/src/main/java/com/vanelle/app/EmbeddingHolder.kt

grep -q 'llama_model_load_from_file' android/app/src/main/cpp/llama_embedding_jni.cpp
grep -q 'llama_decode' android/app/src/main/cpp/llama_embedding_jni.cpp
grep -q 'llama_get_embeddings_seq' android/app/src/main/cpp/llama_embedding_jni.cpp
grep -q 'LLAMA_POOLING_TYPE_MEAN' android/app/src/main/cpp/llama_embedding_jni.cpp
grep -q 'LLAMA_ATTENTION_TYPE_NON_CAUSAL' android/app/src/main/cpp/llama_embedding_jni.cpp
grep -q 'System.loadLibrary("vanelle_embedding")' android/app/src/main/java/com/vanelle/app/EmbeddingEngine.kt
grep -q 'nativeEmbed' android/app/src/main/java/com/vanelle/app/EmbeddingEngine.kt
grep -q 'embedText' android/app/src/main/java/com/vanelle/app/VanelleNativeModule.kt
grep -q 'embeddingLoaded' android/app/src/main/java/com/vanelle/app/VanelleNativeModule.kt

echo 'Vanelle local embedding bridge: static verification OK'
