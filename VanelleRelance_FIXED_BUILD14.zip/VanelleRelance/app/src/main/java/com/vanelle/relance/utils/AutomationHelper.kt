package com.vanelle.relance.utils

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils
import com.vanelle.relance.automation.VanelleAccessibilityService
import com.vanelle.relance.data.Client

object AutomationHelper {

    /**
     * Vérifie si le service d'accessibilité Vanelle est activé
     * (instance connectée OU présent dans les services système activés).
     * Passer le Context pour une détection fiable via les réglages système.
     */
    @JvmOverloads
    fun serviceActive(context: Context? = null): Boolean {
        if (VanelleAccessibilityService.instance != null) return true
        if (context == null) return false
        return isAccessibilityServiceEnabled(context)
    }

    private fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expected = ComponentName(context, VanelleAccessibilityService::class.java)
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            val component = ComponentName.unflattenFromString(splitter.next())
            if (component != null && component == expected) return true
        }
        return false
    }

    fun openAccessibilitySettings(context: Context) {
        context.startActivity(
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    fun startWhatsApp(context: Context, client: Client, message: String): Boolean {
        if (client.telephone.filter(Char::isDigit).length < 8) return false
        val service = VanelleAccessibilityService.instance ?: return false
        return try {
            service.queueWhatsApp(context, client, message)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun startEmail(context: Context, client: Client, subject: String, body: String): Boolean {
        if (client.email.isBlank()) return false
        val service = VanelleAccessibilityService.instance ?: return false
        return try {
            service.queueEmail(context, client, subject, body)
            true
        } catch (_: Exception) {
            false
        }
    }
}
