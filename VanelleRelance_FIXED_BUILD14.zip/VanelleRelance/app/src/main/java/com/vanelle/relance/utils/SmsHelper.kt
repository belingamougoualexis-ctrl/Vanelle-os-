package com.vanelle.relance.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.vanelle.relance.data.Client

enum class TypeNegociation {
    DOUCE,          // Discussion amiable
    PLAN_PAIEMENT,  // Échéancier
    OFFRE_FINALE    // Dernière offre / arrangement
}

object MessageHelper {

    fun genererMessageRelance(
        context: Context,
        client: Client,
        nombreRelancesPrecedentes: Int
    ): String {
        val prefs = PreferencesHelper(context)
        val dateFormat = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.FRANCE)
        val dateStr = dateFormat.format(java.util.Date(client.dateEcheance))
        val montantStr = "%,.0f".format(client.montant).replace(",", " ")

        val template = when {
            nombreRelancesPrecedentes == 0 -> prefs.messageRelance1
            nombreRelancesPrecedentes < 3 -> prefs.messageRelance2
            else -> prefs.messageRelance3
        }

        return appliquerPlaceholders(template, client.nom, montantStr, dateStr)
    }

    fun genererMessageNegociation(
        context: Context,
        client: Client,
        type: TypeNegociation
    ): String {
        val prefs = PreferencesHelper(context)
        val dateFormat = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.FRANCE)
        val dateStr = dateFormat.format(java.util.Date(client.dateEcheance))
        val montantStr = "%,.0f".format(client.montant).replace(",", " ")

        val template = when (type) {
            TypeNegociation.DOUCE -> prefs.messageNegoDouce
            TypeNegociation.PLAN_PAIEMENT -> prefs.messageNegoPlan
            TypeNegociation.OFFRE_FINALE -> prefs.messageNegoOffre
        }

        return appliquerPlaceholders(template, client.nom, montantStr, dateStr)
    }

    private fun appliquerPlaceholders(template: String, nom: String, montant: String, date: String): String =
        template
            .replace("{nom}", nom)
            .replace("{montant}", montant)
            .replace("{date}", date)
}

object SmsHelper {

    fun permissionAccordee(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) ==
            PackageManager.PERMISSION_GRANTED

    @Suppress("DEPRECATION")
    private fun smsManager(context: Context): SmsManager {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(SmsManager::class.java)
        } else {
            SmsManager.getDefault()
        }
    }

    fun envoyer(context: Context, client: Client, nombreRelancesPrecedentes: Int): Boolean {
        val message = MessageHelper.genererMessageRelance(context, client, nombreRelancesPrecedentes)
        return envoyerTexte(context, client, message)
    }

    fun envoyerNegociation(context: Context, client: Client, type: TypeNegociation): Boolean {
        val message = MessageHelper.genererMessageNegociation(context, client, type)
        return envoyerTexte(context, client, message)
    }

    fun envoyerTexte(context: Context, client: Client, message: String): Boolean {
        if (!permissionAccordee(context)) return false
        val numero = client.telephone.filter { it.isDigit() }
        if (numero.length < 8) return false
        return try {
            val smsManager = smsManager(context)
            val parts = smsManager.divideMessage(message)
            smsManager.sendMultipartTextMessage(numero, null, parts, null, null)
            true
        } catch (e: Exception) {
            false
        }
    }
}
