package com.vanelle.relance.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class ClientViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getInstance(application).clientDao()

    val tousLesClients = dao.getTous()
    val clientsEnRetard = dao.getEnRetard()
    val totalDu = dao.getTotalDu()
    val totalRecupere = dao.getTotalRecupere()

    fun clientsOublies() = dao.getOublies(
        System.currentTimeMillis() - TimeUnit.DAYS.toMillis(21)
    )

    fun ajouter(client: Client) = viewModelScope.launch {
        dao.inserer(client)
    }

    fun mettreAJour(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client)
    }

    fun supprimer(client: Client) = viewModelScope.launch {
        dao.supprimer(client)
    }

    fun marquerPaye(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client.copy(statut = StatutDette.PAYEE))
    }

    /** Remet une dette payée en « En cours » */
    fun marquerEnCours(client: Client) = viewModelScope.launch {
        dao.mettreAJour(client.copy(statut = StatutDette.EN_COURS))
    }


    /** Les relances sont immédiates/automatiques : aucun délai minimum n'est appliqué. */
    fun peutRelancer(client: Client, maintenant: Long = System.currentTimeMillis()): Boolean = true

    /** Enregistre toute relance sans blocage temporel. */
    fun enregistrerRelanceSiAutorisee(client: Client) = viewModelScope.launch {
        val actuel = dao.getParId(client.id) ?: return@launch
        dao.mettreAJour(
            actuel.copy(
                nombreRelances = actuel.nombreRelances + 1,
                dernierContact = System.currentTimeMillis()
            )
        )
    }

    fun enregistrerRelance(client: Client) = viewModelScope.launch {
        dao.mettreAJour(
            client.copy(
                nombreRelances = client.nombreRelances + 1,
                dernierContact = System.currentTimeMillis()
            )
        )
    }
}
