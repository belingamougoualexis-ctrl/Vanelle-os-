package com.vanelle.relance.utils

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.vanelle.relance.data.Client
import java.net.URLEncoder

object WhatsAppHelper {

    /**
     * Ouvre WhatsApp avec le message de relance pré-rempli.
     */
    fun envoyer(context: Context, client: Client, nombreRelancesPrecedentes: Int): Boolean {
        val message = MessageHelper.genererMessageRelance(context, client, nombreRelancesPrecedentes)
        return envoyerTexte(context, client, message)
    }

    /**
     * Ouvre WhatsApp avec un message de négociation.
     */
    fun envoyerNegociation(context: Context, client: Client, type: TypeNegociation): Boolean {
        val message = MessageHelper.genererMessageNegociation(context, client, type)
        return envoyerTexte(context, client, message)
    }

    fun envoyerTexte(context: Context, client: Client, message: String): Boolean {
        val numeroPropre = client.telephone.filter { it.isDigit() }
        if (numeroPropre.length < 8) return false
        val texteEncode = URLEncoder.encode(message, "UTF-8")
        val uri = Uri.parse("https://wa.me/$numeroPropre?text=$texteEncode")

        return try {
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        }
    }
}
