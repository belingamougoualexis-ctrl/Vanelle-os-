package com.vanelle.relance.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.net.Uri
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.vanelle.relance.data.Client
import java.net.URLEncoder
import java.util.ArrayDeque

/**
 * Automatisation volontaire de l'action d'envoi dans les apps tierces.
 * L'utilisateur doit activer ce service lui-même dans Paramètres > Accessibilité.
 */
class VanelleAccessibilityService : AccessibilityService() {

    private data class Task(val type: String, val client: Client, val message: String, val subject: String = "")
    private val queue = ArrayDeque<Task>()
    private var activeTask: Task? = null
    private var clickInProgress = false
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var pollAttempts = 0
    private val pollRunnable = object : Runnable {
        override fun run() {
            val task = activeTask ?: return
            if (tryClickSend(task)) return
            pollAttempts++
            if (pollAttempts >= MAX_POLL_ATTEMPTS) {
                onTaskTimedOut(task)
            } else {
                handler.postDelayed(this, POLL_INTERVAL_MS)
            }
        }
    }

    companion object {
        const val ACTION_SEND_WHATSAPP = "com.vanelle.relance.SEND_WHATSAPP"
        const val ACTION_SEND_EMAIL = "com.vanelle.relance.SEND_EMAIL"
        private const val POLL_INTERVAL_MS = 400L
        private const val MAX_POLL_ATTEMPTS = 25 // ~10 secondes au total
        @Volatile var instance: VanelleAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val task = activeTask ?: return
        val packageName = event?.packageName?.toString() ?: return
        val expectedPackages = if (task.type == ACTION_SEND_WHATSAPP) setOf("com.whatsapp", "com.whatsapp.w4b") else setOf("com.google.android.gm")
        if (packageName !in expectedPackages) return
        tryClickSend(task)
    }

    /**
     * Tente de trouver et cliquer le bouton d'envoi. Retourne true si le clic a été déclenché.
     * Appelée à la fois par les événements d'accessibilité ET par le polling de secours,
     * pour ne jamais rester bloqué en silence si aucun événement pertinent n'arrive.
     */
    private fun tryClickSend(task: Task): Boolean {
        if (clickInProgress) return true
        val root = rootInActiveWindow ?: return false
        val labels = listOf("Envoyer", "Send", "Envoyer le message", "Send message", "Envoyer l'e-mail")
        val send = findClickable(root, labels) ?: findByViewId(root, listOf("send")) ?: return false
        clickInProgress = true
        handler.removeCallbacks(pollRunnable)
        if (send.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            finishTask()
        } else {
            dispatchTap(send)
        }
        return true
    }

    private fun onTaskTimedOut(task: Task) {
        android.widget.Toast.makeText(
            this,
            "Vanelle n'a pas pu envoyer automatiquement le message à ${task.client.nom}. Terminez l'envoi manuellement (bouton Envoyer), la relance suivante attend en file.",
            android.widget.Toast.LENGTH_LONG
        ).show()
        activeTask = null
        clickInProgress = false
        startNext(this)
    }

    override fun onInterrupt() {}

    fun queueWhatsApp(context: android.content.Context, client: Client, message: String) {
        queue.add(Task(ACTION_SEND_WHATSAPP, client, message))
        if (activeTask == null) startNext(context)
    }

    fun queueEmail(context: android.content.Context, client: Client, subject: String, body: String) {
        queue.add(Task(ACTION_SEND_EMAIL, client, body, subject))
        if (activeTask == null) startNext(context)
    }

    private fun startNext(context: android.content.Context) {
        if (queue.isEmpty()) {
            activeTask = null
            clickInProgress = false
            return
        }
        val task = queue.removeFirst()
        activeTask = task
        clickInProgress = false
        pollAttempts = 0
        try {
            if (task.type == ACTION_SEND_WHATSAPP) {
                val phone = task.client.telephone.filter(Char::isDigit)
                val uri = Uri.parse("https://wa.me/$phone?text=${URLEncoder.encode(task.message, "UTF-8")}")
                context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("com.whatsapp")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            } else {
                context.startActivity(Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:${Uri.encode(task.client.email)}")
                    putExtra(Intent.EXTRA_SUBJECT, task.subject)
                    putExtra(Intent.EXTRA_TEXT, task.message)
                    setPackage("com.google.android.gm")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }
            // Filet de secours : on ne dépend pas uniquement des événements d'accessibilité,
            // on vérifie nous-mêmes toutes les 400ms pendant ~10s si le bouton d'envoi est apparu.
            handler.postDelayed(pollRunnable, POLL_INTERVAL_MS)
        } catch (_: Exception) {
            activeTask = null
            android.os.Handler(mainLooper).postDelayed({ startNext(context) }, 500)
        }
    }

    private fun finishTask() {
        activeTask = null
        clickInProgress = false
        android.os.Handler(mainLooper).postDelayed({ startNext(this) }, 900)
    }

    private fun dispatchTap(node: AccessibilityNodeInfo) {
        val bounds = android.graphics.Rect()
        node.getBoundsInScreen(bounds)
        if (bounds.isEmpty) { clickInProgress = false; return }
        val path = Path().apply { moveTo(bounds.exactCenterX(), bounds.exactCenterY()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { finishTask() }
            override fun onCancelled(gestureDescription: GestureDescription?) { clickInProgress = false }
        }, null)
    }

    private fun findClickable(root: AccessibilityNodeInfo, labels: List<String>): AccessibilityNodeInfo? {
        for (label in labels) {
            root.findAccessibilityNodeInfosByText(label).firstOrNull { it.isVisibleToUser && it.isEnabled }?.let { return it }
        }
        return findByContentDescription(root, labels)
    }

    private fun findByContentDescription(root: AccessibilityNodeInfo, labels: List<String>): AccessibilityNodeInfo? {
        val desc = root.contentDescription?.toString()?.lowercase() ?: ""
        if (root.isVisibleToUser && root.isEnabled && labels.any { desc.contains(it.lowercase()) }) return root
        for (i in 0 until root.childCount) {
            root.getChild(i)?.let { child -> findByContentDescription(child, labels)?.let { return it } }
        }
        return null
    }

    /**
     * Recherche par id de vue (ex: "send") en repli du texte/description, car les boutons
     * icône (souvent le cas du bouton Envoyer de Gmail) n'exposent pas toujours de texte
     * accessible identique d'une version à l'autre — l'id de ressource, lui, est stable.
     */
    private fun findByViewId(root: AccessibilityNodeInfo, idKeywords: List<String>): AccessibilityNodeInfo? {
        val id = root.viewIdResourceName?.lowercase() ?: ""
        if (root.isVisibleToUser && root.isEnabled && idKeywords.any { id.contains(it) }) return root
        for (i in 0 until root.childCount) {
            root.getChild(i)?.let { child -> findByViewId(child, idKeywords)?.let { return it } }
        }
        return null
    }
}
