package com.nexus.network

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.graphics.BitmapFactory
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.net.wifi.p2p.WifiP2pDevice
import java.net.InetAddress
import java.io.File
import java.security.MessageDigest
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var networkText: TextView
    private lateinit var nodeText: TextView
    private lateinit var peersText: TextView
    private lateinit var gatewayText: TextView
    private lateinit var routeText: TextView
    private lateinit var p2pText: TextView
    private lateinit var transportText: TextView
    private lateinit var physicalText: TextView
    private lateinit var creditsText: TextView
    private lateinit var storageText: TextView
    private lateinit var vpnButton: Button
    private lateinit var gatewayButton: Button
    private lateinit var transitButton: Button
    private lateinit var bootstrapText: TextView
    private lateinit var trustText: TextView
    private lateinit var discovery: NsdController
    private lateinit var p2p: WifiDirectController
    private var gatewayEnabled = false
    private var transitEnabled = false
    private val peerRows = mutableListOf<NsdController.Peer>()
    private val p2pRows = mutableListOf<WifiP2pDevice>()

    private lateinit var screen: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var subtitleText: TextView
    private var activeTab = 0
    private var pendingDeepLinkAddress: String? = null
    private val navButtons = mutableListOf<Button>()
    private lateinit var homeConnectButton: Button
    private lateinit var homeAddressCard: View
    private lateinit var moreButton: Button
    private var guidedTour: GuidedTour? = null
    private var pendingPresenceScope: NexusPresence.Scope? = null
    private val prefs by lazy { getSharedPreferences("nexus_account", MODE_PRIVATE) }

    private val blue = 0xFF2563EB.toInt()
    private val text = 0xFF111827.toInt()
    private val secondary = 0xFF667085.toInt()
    private val bg = 0xFFF7F9FC.toInt()
    private val cardBg = 0xFFFFFFFF.toInt()
    private val border = 0xFFE5E7EB.toInt()
    private val error = 0xFFDC2626.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "NEXUS"
        gatewayEnabled = NexusSettings.gatewayEnabled(this)
        transitEnabled = NexusSettings.transitEnabled(this)
        discovery = NsdController(this)
        p2p = WifiDirectController(this)
        pendingDeepLinkAddress = NexusShareLink.addressFrom(intent?.data)
        if (!hasAccount()) showAuth() else if (prefs.getBoolean("signed_out", false)) showAuth() else if (!hasConsent()) showParticipationGate() else continueToApp()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingDeepLinkAddress = NexusShareLink.addressFrom(intent?.data)
        if (::body.isInitialized && pendingDeepLinkAddress != null) {
            val address = pendingDeepLinkAddress
            pendingDeepLinkAddress = null
            contactByAddress(address.orEmpty())
        }
    }

    override fun onResume() {
        super.onResume()
        if (::body.isInitialized && hasAccount() && hasConsent()) {
            refreshNetwork(); refreshAll()
        }
    }

    override fun onDestroy() {
        if (::discovery.isInitialized) discovery.close()
        if (::p2p.isInitialized) p2p.stop()
        super.onDestroy()
    }

    private fun hasAccount() = prefs.getBoolean("account_created", false)
    private fun hasConsent() = prefs.getBoolean("participation_consent", false)

    private fun showAuth() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(28), dp(32), dp(28), dp(32)); setBackgroundColor(bg)
        }
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        root.addView(nexusLogoView(180))
        root.addView(label("NEXUS", 34, true, text))
        root.addView(label("Réseau de réseaux.", 14, false, secondary))
        root.addView(space(28))
        root.addView(panel("Une identité simple pour accéder à ton réseau NEXUS.", "Le compte local protège l'accès à l'appareil. Les fonctions réseau restent soumises aux autorisations Android et à tes choix de participation."))
        root.addView(space(18))
        val create = primaryButton("Créer mon compte") { showCreateAccount() }
        root.addView(create)
        root.addView(secondaryButton("Se connecter") { showLogin() })
        root.addView(label("Le compte reste sur ce téléphone. NEXUS ne prétend pas avoir un compte sur un serveur en ligne.", 12, false, secondary))
        root.addView(secondaryButton("Conditions et confidentialité") { showLegal() })
    }

    private fun showCreateAccount() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(10), dp(22), 0) }
        val name = field("Nom d'utilisateur", InputType.TYPE_CLASS_TEXT)
        val email = field("Adresse e-mail", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val pass = field("Mot de passe", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        val confirm = field("Confirmer le mot de passe", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        box.addView(name); box.addView(email); box.addView(pass); box.addView(confirm)
        AlertDialog.Builder(this).setTitle("Créer ton compte NEXUS").setView(box)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Continuer") { _, _ ->
                val n=name.text.toString().trim(); val e=email.text.toString().trim(); val p=pass.text.toString(); val c=confirm.text.toString()
                if (n.length < 2 || !android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches() || p.length < 8 || p != c) {
                    Toast.makeText(this, "Vérifie le nom, l'e-mail et un mot de passe d'au moins 8 caractères.", Toast.LENGTH_LONG).show()
                } else {
                                        prefs.edit().putBoolean("account_created",true).putBoolean("signed_out",false).putString("username",n).putString("email",e).remove("password_hash").apply()
                    NexusSecureStore.put(this, "account_password_hash", passwordHash(p, e))
                    showParticipationGate()
                }
            }.show()
    }

    private fun showLogin() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(22),dp(10),dp(22),0) }
        val email=field("Adresse e-mail",InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val pass=field("Mot de passe",InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        box.addView(email); box.addView(pass)
        AlertDialog.Builder(this).setTitle("Se connecter à NEXUS").setView(box)
            .setNegativeButton("Annuler",null)
            .setPositiveButton("Se connecter") { _,_ ->
                val savedEmail=prefs.getString("email","") ?: ""
                val stored = NexusSecureStore.get(this, "account_password_hash") ?: prefs.getString("password_hash","") ?: ""
                val candidate=passwordHash(pass.text.toString(), savedEmail)
                val legacy=sha256(pass.text.toString())
                val ok=email.text.toString().trim().equals(savedEmail,true) && (NexusCrypto.constantTimeEquals(candidate, stored) || NexusCrypto.constantTimeEquals(legacy, stored))
                if(ok) {
                    prefs.edit().putBoolean("signed_out",false).remove("password_hash").apply()
                    if (!NexusCrypto.constantTimeEquals(candidate, stored)) NexusSecureStore.put(this, "account_password_hash", candidate)
                    if(hasConsent()) continueToApp() else showParticipationGate()
                } else Toast.makeText(this,"Adresse e-mail ou mot de passe incorrect.",Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun showParticipationGate() {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(28),dp(32),dp(28),dp(32)); setBackgroundColor(bg) }
        val scroll=ScrollView(this); scroll.addView(root); setContentView(scroll)
        root.addView(label("Ton appareil, tes choix.",30,true,text))
        root.addView(label("Avant d'activer le réseau, NEXUS te demande ton accord explicite.",16,false,secondary))
        root.addView(space(20))
        root.addView(panel("Utiliser NEXUS", "Connecter l'appareil aux réseaux disponibles et utiliser les capacités réseau autorisées par Android."))
        root.addView(panel("Partager des ressources", "Le relais, le stockage et le calcul sont séparés. Rien n'est activé sans ton choix."))
        val check=android.widget.CheckBox(this).apply { text="J'ai lu et j'accepte les conditions de participation NEXUS"; setTextColor(this@MainActivity.text); textSize=14f }
        root.addView(check)
        val continueButton=primaryButton("Continuer") { prefs.edit().putBoolean("participation_consent",true).apply(); continueToApp() }
        continueButton.isEnabled=false; check.setOnCheckedChangeListener { _,checked -> continueButton.isEnabled=checked }
        root.addView(continueButton)
        root.addView(secondaryButton("Lire les conditions et la confidentialité") { showLegal() })
        root.addView(secondaryButton("Quitter", { finish() }))
    }

    private fun showApp() {
        gatewayEnabled=NexusSettings.gatewayEnabled(this); transitEnabled=NexusSettings.transitEnabled(this)
        buildShell(); startNodeService(); startDiscovery(); refreshAll()
        maybeStartGuidedTour()
        pendingDeepLinkAddress?.let { address -> pendingDeepLinkAddress = null; contactByAddress(address) }
    }

    private fun buildShell() {
        screen=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val top=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(3),dp(14),dp(2)); setBackgroundColor(cardBg) }
        top.addView(nexusLogoView(34))
        val row=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        val brand=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
        titleText=label("NEXUS",17,true,text); subtitleText=label("Network of Networks",9,false,secondary)
        brand.addView(titleText); brand.addView(subtitleText); row.addView(brand)
        moreButton = textButton("+") { showMoreMenu() }; row.addView(moreButton)
        top.addView(row); screen.addView(top)
        val scroll=ScrollView(this); body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(12),dp(18),dp(88)) }; scroll.addView(body); screen.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(dp(6),dp(6),dp(6),dp(10)); setBackgroundColor(cardBg) }
        navButtons.clear(); listOf("Accueil","Réseau","Ressources","Services","Profil").forEachIndexed { i,n -> val b=navButton(n,i); navButtons.add(b); nav.addView(b) }
        screen.addView(nav)
        setContentView(screen); renderTab(0)
    }

    private fun renderTab(index:Int) {
        activeTab=index; body.removeAllViews(); navButtons.forEachIndexed { i,b -> b.setTextColor(if(i==activeTab) blue else secondary) }
        when(index){0->renderHome();1->renderNetwork();2->renderResources();3->renderServices();4->renderProfile()}
    }

    private fun renderHome() {
        body.addView(label("Bonjour ${prefs.getString("username","NEXUS")}",28,true,text))
        body.addView(label("NEXUS s’occupe du réseau pour toi.",14,false,secondary))
        body.addView(space(12))
        val state=NetworkInspector.snapshot(this)
        val headline=if(state.validated) "Internet vérifié" else if(state.connected) "Réseau connecté" else "Hors connexion"
        val detail=if(state.validated) "Android confirme une connexion Internet. NEXUS vérifie ensuite ses propres chemins." else if(state.connected) "Internet n’est pas vérifié pour le moment." else "Connecte le téléphone à un réseau pour utiliser NEXUS."
        body.addView(statusCard(headline,detail))
        body.addView(space(6))
        homeConnectButton = primaryButton("Connecter automatiquement") { connectAutomatically() }; body.addView(homeConnectButton)
        body.addView(label("NEXUS choisit automatiquement le chemin réellement disponible. Aucun réglage technique n’est nécessaire.",12,false,secondary))
        body.addView(section("Mon adresse NEXUS", true))
        homeAddressCard = cardView(label(NexusAddress.overlayIpv6(this), 15, false, text), "Adresse personnelle"); body.addView(homeAddressCard)
        body.addView(secondaryButton("Partager mon adresse") { shareNexusAddress() })
        body.addView(secondaryButton("Contacter une adresse NEXUS") { contactByAddress() })
        body.addView(secondaryButton("Demandes de connexion (${NexusPeerRequests.pending(this).size})") { showIncomingRequests() })
        body.addView(secondaryButton("Trouver des nœuds NEXUS") { showNexusDiscovery() })
        body.addView(section("État",true))
        networkText=label("",14,false,secondary); body.addView(cardView(networkText))
        statusText=label("",14,false,secondary); body.addView(cardView(statusText,"Activité"))
        body.addView(secondaryButton("Autres fonctions") { showMoreMenu() })
    }

    private fun renderNetwork() {
        body.addView(label("Réseau",28,true,text))
        body.addView(label("Le mode normal est automatique. Les réglages techniques sont dans Réglages.",14,false,secondary))
        networkText=label("",14,false,secondary); body.addView(cardView(networkText,"Connexion actuelle"))
        routeText=label("",14,false,secondary); body.addView(cardView(routeText,"Chemin NEXUS"))
        body.addView(primaryButton("Réparer la connexion") { recoverNetworkPath() })
        body.addView(secondaryButton("Reconnecter") { connectAutomatically() })
        body.addView(section("Aide au réseau",true))
        body.addView(label("Ton téléphone peut aider d’autres appareils seulement avec ton accord.",12,false,secondary))
        body.addView(secondaryButton("Réglages") { showNetworkAdvanced() })
        body.addView(secondaryButton("Vérifier le réseau") { showDiagnostics() })
        updateButtons(); refreshNetwork(); refreshNode(); refreshGateway(); refreshRoute()
    }

    private fun renderResources() {
        body.addView(label("Ressources",28,true,text))
        body.addView(label("Tu contrôles ce que ton téléphone partage.",14,false,secondary))
        creditsText=label("",14,false,secondary); body.addView(cardView(creditsText,"Participation"))
        storageText=label("",14,false,secondary); body.addView(cardView(storageText,"Stockage"))
        body.addView(primaryButton("Importer un contenu") { chooseContentFile() })
        body.addView(secondaryButton("Partager / limiter mes ressources") { editResourcePolicies() })
        body.addView(secondaryButton("Autres réglages") { showMoreMenu() })
        refreshResources()
    }

    private fun renderServices() {
        body.addView(label("Services",28,true,text))
        body.addView(label("Seules les fonctions et données réellement disponibles sont utilisées.",14,false,secondary))
        val health=NexusRuntime.localHealth(this)
        val healthText = "Nœud ${health["node"]}\nBases locales : ${health["databases"]} • contenus : ${health["pinned"]} • crédits : ${health["credits"]}"
        body.addView(cardView(label(healthText,14,false,text),"État local"))
        body.addView(primaryButton("Envoyer un message") { sendMessageToPeer() })
        body.addView(secondaryButton("Synchroniser une base") { syncDatabaseWithPeer() })
        body.addView(secondaryButton("Récupérer un contenu") { fetchContentFromNetwork() })
        body.addView(secondaryButton("Réparer automatiquement") { runAutoRepair() })
    }

    private fun renderProfile() {
        body.addView(label("Profil",28,true,text)); body.addView(label("Ton identité et tes choix.",14,false,secondary))
        val user=prefs.getString("username","NEXUS"); val email=prefs.getString("email","")
        body.addView(cardView(label("$user\n$email",15,false,text),"Compte"))
        body.addView(cardView(label("${NexusIdentity.nodeId(this)}\n${NexusAddress.overlayIpv6(this)}\nEmpreinte ${NexusIdentity.publicKeyFingerprint(this)}",13,false,text),"Identité NEXUS"))
        body.addView(primaryButton("Partager mon identité réseau") { shareNexusAddress() })
        body.addView(secondaryButton("Contacts et demandes") { showContacts() })
        body.addView(secondaryButton("Sécurité et participation") { showParticipationSettings() })
        body.addView(secondaryButton("Réglages avancés") { showNetworkAdvanced() })
        trustText=label("",13,false,secondary); body.addView(cardView(trustText,"Sécurité"))
        bootstrapText=label("",13,false,secondary); body.addView(cardView(bootstrapText,"Points d'entrée"))
        body.addView(secondaryButton("Se déconnecter") { prefs.edit().putBoolean("signed_out",true).apply(); stopVpnService(); showAuth() })
        refreshSecurity()
    }

    private fun serviceCard(title:String,detail:String){ body.addView(cardView(label("$title\n$detail",14,false,text))) }

    private fun showLegal(){
        val msg = "NEXUS ${NexusConfig.VERSION}\n\n" +
            "Fonctionnement : NEXUS utilise les interfaces réseau réellement exposées par Android. Certaines fonctions nécessitent un réseau local, Internet, un pair compatible ou un accessoire externe compatible.\n\n" +
            "Participation : le relais, le stockage distribué et la réplication sont contrôlés localement et peuvent être désactivés. Le transit d'un appareil est désactivé par défaut et aucun téléphone tiers n'utilise cette connexion comme relais sans activation explicite. Les appareils qui n'exécutent pas NEXUS ne sont pas relayés automatiquement.\n\n" +
            "Confidentialité : cette version ne nécessite pas de compte cloud pour le fonctionnement réseau local. Les identifiants du compte local restent sur l'appareil. Les contenus et bases que l'utilisateur choisit de répliquer peuvent être transmis à des pairs explicitement autorisés.\n\n" +
            "Sécurité : les services NEXUS utilisent une authentification réseau et un canal chiffré. Le calcul distribué accepte uniquement des opérations intégrées et déterministes ; aucun code arbitraire distant n'est exécuté.\n\n" +
            "Adresses : l'adresse NEXUS overlay est dérivée cryptographiquement de l'identité de l'installation et est conçue pour éviter les collisions. Une adresse IP publique n'est toutefois pas forcément unique : un opérateur peut partager la même IP entre plusieurs clients via NAT/CGNAT. Garantir une IP publique distincte par utilisateur exige des sorties réseau distinctes.\n\n" +
            "Limites : NEXUS ne crée ni bande passante, ni radio, ni satellite, ni fibre. Aucune promesse de disponibilité permanente ne doit être interprétée pour un stockage décentralisé.\n\n" +
            "Droit et usage : l'utilisateur reste responsable des données qu'il transmet et des autorisations nécessaires aux réseaux ou matériels utilisés."
        AlertDialog.Builder(this).setTitle("Conditions & confidentialité").setMessage(msg).setPositiveButton("Fermer",null).show()
    }

    private fun showMoreMenu(){ AlertDialog.Builder(this).setTitle("NEXUS").setItems(arrayOf("Vérifier le réseau","Sécurité","Revoir le tutoriel","À propos")){_,w->when(w){0->showDiagnostics();1->showSecurity();2->{ GuidedTour.reset(this); maybeStartGuidedTour(true) };3->showAbout()}}.show() }

    private fun maybeStartGuidedTour(force: Boolean = false) {
        if (!::screen.isInitialized || !::homeConnectButton.isInitialized || !::homeAddressCard.isInitialized) return
        if (!force && !GuidedTour.shouldShow(this)) return
        screen.post {
            val targets = listOf(
                GuidedTour.Step(homeConnectButton, "Connexion automatique", "NEXUS choisit le chemin réseau réellement disponible. Rien n'est lancé pendant ce guide."),
                GuidedTour.Step(homeAddressCard, "Ton adresse NEXUS", "Cette adresse identifie ton appareil sur le réseau. Partage-la pour que l'on puisse te contacter."),
                GuidedTour.Step(navButtons[1], "Réseau", "Consulte les appareils détectés, le chemin utilisé et l'état de la connexion.", runAction = true),
                GuidedTour.Step(navButtons[2], "Ressources", "Choisis ce que ton téléphone partage. Rien n'est activé sans ton accord.", runAction = true),
                GuidedTour.Step(moreButton, "Menu", "Le bouton + ouvre la vérification du réseau, la sécurité, ce guide et les informations sur NEXUS.")
            )
            guidedTour?.let { if (it.isRunning()) return@post }
            guidedTour = GuidedTour(this, screen, targets).also { it.start() }
        }
    }
    private fun showDiagnostics(){ val s=NetworkInspector.snapshot(this); AlertDialog.Builder(this).setTitle("Diagnostic réel").setMessage("Connecté : ${s.connected}\nInternet validé : ${s.validated}\nTransport : ${s.transport}\nInterface : ${s.interfaceName}\nIPv4 : ${s.ipv4}\nIPv6 : ${s.ipv6}\n\nAucune métrique non mesurée n'est inventée.").setPositiveButton("OK",null).show() }
    private fun showAbout(){ AlertDialog.Builder(this).setTitle("NEXUS ${NexusConfig.VERSION}").setMessage("Réseau des réseaux : routage distribué, relais sur accord, plusieurs transports, stockage distribué et reprise en cas de panne. NEXUS ne crée pas une liaison physique inexistante.").setPositiveButton("OK",null).show() }
    private fun writeDatabaseValue(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),0)}
        val db=field("Base (ex. app)",InputType.TYPE_CLASS_TEXT); val key=field("Clé",InputType.TYPE_CLASS_TEXT); val value=EditText(this).apply{hint="Valeur";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE;minLines=3;gravity=Gravity.TOP}
        box.addView(db);box.addView(key);box.addView(value)
        AlertDialog.Builder(this).setTitle("Base NEXUS locale").setView(box).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer"){_,_->
            runCatching{NexusDatabase.put(this,db.text.toString().trim(),key.text.toString().trim(),value.text.toString())}.onSuccess{Toast.makeText(this,"Donnée écrite. hash ${it.hash.take(12)}…",Toast.LENGTH_LONG).show()}.onFailure{Toast.makeText(this,"Écriture refusée : ${it.message}",Toast.LENGTH_LONG).show()}
        }.show()
    }

    private fun readDatabaseValue(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),0)}
        val db=field("Base",InputType.TYPE_CLASS_TEXT); val key=field("Clé",InputType.TYPE_CLASS_TEXT);box.addView(db);box.addView(key)
        AlertDialog.Builder(this).setTitle("Lire une donnée").setView(box).setNegativeButton("Fermer",null).setPositiveButton("Lire"){_,_->
            val r=NexusDatabase.get(this,db.text.toString().trim(),key.text.toString().trim());
            AlertDialog.Builder(this).setTitle("Résultat").setMessage(r?.let{"${it.value}\n\nversion=${it.version}\nnœud=${it.nodeId}\nhash=${it.hash}"}?:"Clé absente").setPositiveButton("OK",null).show()
        }.show()
    }

    private fun pickServicePeer(action:(NsdController.Peer)->Unit){
        val peers=peerRows.filter{it.host.isNotBlank()&&NexusTrustStore.isAllowed(this,it.name)}
        if(peers.isEmpty()){Toast.makeText(this,"Aucun nœud de service réellement joignable.",Toast.LENGTH_LONG).show();return}
        AlertDialog.Builder(this).setTitle("Choisir un nœud").setItems(peers.map{"${it.name} • ${it.host}"}.toTypedArray()){_,i->action(peers[i])}.show()
    }

    private fun syncDatabaseWithPeer(){
        val dbInput=field("Base à synchroniser",InputType.TYPE_CLASS_TEXT)
        AlertDialog.Builder(this)
            .setTitle("Synchroniser une base")
            .setView(dbInput)
            .setNegativeButton("Annuler",null)
            .setPositiveButton("Choisir le nœud"){_,_->
                val db=dbInput.text.toString().trim()
                pickServicePeer { peer ->
                    thread(start=true,name="nexus-db-sync") {
                        val remote=NexusServiceProtocol.listRemote(this,peer.host,db)
                        val merged=remote.getOrElse{emptyList()}.count { record -> NexusDatabase.merge(this,record) }
                        runOnUiThread {
                            val state=if(remote.isSuccess) "terminée" else "échouée"
                            Toast.makeText(this,"Synchronisation $state • $merged donnée(s) intégrée(s).",Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }.show()
    }

    private fun nexusLogoView(heightDp: Int): ImageView = ImageView(this).apply {
        val bitmap = BitmapFactory.decodeResource(resources, resources.getIdentifier("nexus_logo", "drawable", packageName))
        setImageBitmap(bitmap)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        adjustViewBounds = true
        contentDescription = "Logo NEXUS"
        setPadding(0, dp(2), 0, dp(4))
        layoutParams = LinearLayout.LayoutParams(-1, dp(heightDp))
    }

    private fun showNexusDiscovery() {
        val values = NexusPresence.Scope.entries.toTypedArray()
        val labels = values.map { it.label }.toTypedArray()
        var selected = values.indexOfFirst { it.radiusKm == NexusSettings.presenceScope(this) }.coerceAtLeast(0)
        val sharing = android.widget.Switch(this).apply {
            text = if (NexusSettings.presenceSharingEnabled(this@MainActivity)) "Mon NEXUS est visible dans les recherches" else "Mon NEXUS n’est pas visible dans les recherches"
            isChecked = NexusSettings.presenceSharingEnabled(this@MainActivity)
            setTextColor(this@MainActivity.text)
            textSize = 14f
            setOnCheckedChangeListener { _, checked ->
                NexusSettings.setPresenceSharingEnabled(this@MainActivity, checked)
                text = if (checked) "Mon NEXUS est visible dans les recherches" else "Mon NEXUS n’est pas visible dans les recherches"
                ensureNodeService()
                Toast.makeText(this@MainActivity, if (checked) "Visibilité NEXUS activée." else "Visibilité NEXUS désactivée.", Toast.LENGTH_SHORT).show()
            }
        }
        val note = label(
            "À 10 ou 100 km, NEXUS cherche des nœuds qui ont publié une zone approximative. Après la découverte, il essaie d’abord une connexion directe par Internet : aucun téléphone NEXUS n’a besoin d’être placé entre les deux. Un NAT/CGNAT ou un pare-feu peut toutefois empêcher la liaison directe. Lorsque la visibilité est activée, une fiche signée est publiée : nom, pays, zone approximative de plusieurs kilomètres et adresses IP publiques de l’appareil.",
            12, false, secondary
        )
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(switcherSpacer())
        val radio = android.widget.RadioGroup(this).apply {
            orientation = android.widget.RadioGroup.VERTICAL
            values.forEachIndexed { index, scope ->
                addView(android.widget.RadioButton(this@MainActivity).apply {
                    id = View.generateViewId()
                    text = scope.label
                    textSize = 15f
                    setTextColor(this@MainActivity.text)
                    setOnClickListener {
                        selected = index
                        NexusSettings.setPresenceScope(this@MainActivity, scope.radiusKm)
                    }
                })
            }
        }
        radio.getChildAt(selected)?.id?.takeIf { it != View.NO_ID }?.let { radio.check(it) }
        box.addView(label("Choisis la portée de recherche.", 15, true, text))
        box.addView(radio)
        box.addView(switcherSpacer())
        box.addView(sharing)
        box.addView(note)
        AlertDialog.Builder(this)
            .setTitle("Nœuds NEXUS autour de toi")
            .setView(box)
            .setNegativeButton("Fermer", null)
            .setPositiveButton("Rechercher") { _, _ ->
                val scope = values.getOrNull(selected) ?: NexusPresence.Scope.NEARBY
                NexusSettings.setPresenceScope(this, scope.radiusKm)
                if (scope == NexusPresence.Scope.TEN_KM || scope == NexusPresence.Scope.HUNDRED_KM) {
                    if (!NexusPresence.hasLocationPermission(this)) requestPresenceLocation(scope) else runPresenceSearch(scope)
                } else runPresenceSearch(scope)
            }.show()
    }

    private fun switcherSpacer() = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(8)) }

    private fun requestPresenceLocation(scope: NexusPresence.Scope) {
        pendingPresenceScope = scope
        // Approximate location is sufficient: only a coarse cell is ever published.
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.ACCESS_COARSE_LOCATION else Manifest.permission.ACCESS_FINE_LOCATION
        requestPermissions(arrayOf(permission), 702)
    }

    private fun runPresenceSearch(scope: NexusPresence.Scope) {
        Toast.makeText(this, "Recherche réelle des nœuds NEXUS…", Toast.LENGTH_SHORT).show()
        thread(start = true, name = "nexus-presence-search") {
            val result = if (scope == NexusPresence.Scope.NEARBY) {
                val local = NexusPresenceDirectory.localNearby(this, peerRows)
                NexusPresenceDirectory.Result(local, 0)
            } else NexusPresenceDirectory.search(this, discovery, scope)
            runOnUiThread { showPresenceResults(scope, result) }
        }
    }

    private fun showPresenceResults(scope: NexusPresence.Scope, result: NexusPresenceDirectory.Result) {
        if (result.records.isEmpty()) {
            val reason = when {
                scope == NexusPresence.Scope.NEARBY -> "Aucun autre nœud NEXUS découvert sur les liaisons de proximité."
                result.sources == 0 -> "Aucun point d’entrée NEXUS joignable. Pour une recherche à distance, ajoute un point d’entrée distant dans les réglages."
                scope == NexusPresence.Scope.TEN_KM || scope == NexusPresence.Scope.HUNDRED_KM -> "Aucun nœud visible dans cette zone. La distance est calculée à partir de zones géographiques approximatives, jamais d’une position exacte."
                else -> "Aucun nœud visible depuis les points d’entrée actuellement joignables."
            }
            AlertDialog.Builder(this).setTitle(scope.label).setMessage(reason).setPositiveButton("OK", null).show()
            return
        }
        val location = NexusPresence.currentLocation(this)
        val lines = result.records.map { record ->
            val distance = when (scope) {
                NexusPresence.Scope.TEN_KM -> location?.let { origin -> NexusPresence.parseCell(record.fineCell, 0.05)?.center()?.let { c -> "≈ ${NexusPresence.distanceKm(origin.latitude, origin.longitude, c.first, c.second).toInt()} km" } } ?: "distance indisponible"
                NexusPresence.Scope.HUNDRED_KM -> location?.let { origin -> NexusPresence.parseCell(record.regionCell, 0.25)?.center()?.let { c -> "≈ ${NexusPresence.distanceKm(origin.latitude, origin.longitude, c.first, c.second).toInt()} km" } } ?: "distance indisponible"
                NexusPresence.Scope.COUNTRY -> "pays ${record.countryCode.ifBlank { "inconnu" }}"
                NexusPresence.Scope.WORLD -> record.countryCode.takeIf { it.isNotBlank() }?.let { "pays $it" } ?: "pays inconnu"
                NexusPresence.Scope.NEARBY -> "proche"
            }
            "${record.displayName}\n$distance • ${if (record.endpoints.isNotEmpty()) "liaison directe tentable" else "adresse à résoudre"}\n${record.address}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("${scope.label} • ${result.records.size} nœud(s)")
            .setItems(lines) { _, which -> contactPresence(result.records[which]) }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun contactPresence(record: NexusPresence.Record) {
        val label = "${record.displayName} • ${record.countryCode.ifBlank { "pays inconnu" }}\n${record.address}"
        AlertDialog.Builder(this)
            .setTitle("Contacter ce nœud")
            .setMessage("$label\n\nNEXUS essaie d’abord les endpoints publics annoncés pour une connexion directe. Aucun utilisateur NEXUS n’est requis comme relais si cette liaison directe fonctionne.")
            .setNegativeButton("Fermer", null)
            .setPositiveButton("Envoyer une demande") { _, _ ->
                val message = field("Message de demande", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE).apply { minLines = 2 }
                AlertDialog.Builder(this).setTitle("Message").setView(message)
                    .setNegativeButton("Annuler", null)
                    .setPositiveButton("Envoyer") { _, _ ->
                        val body = message.text.toString().trim()
                        if (body.isBlank()) {
                            Toast.makeText(this, "Le message ne peut pas être vide.", Toast.LENGTH_LONG).show()
                            return@setPositiveButton
                        }
                        ensureNodeService()
                        thread(start = true, name = "nexus-presence-contact") {
                            var direct = false
                            for (endpoint in record.endpoints) {
                                val parsed = parseEndpoint(endpoint) ?: continue
                                direct = runCatching {
                                    NxpProtocol.sendConnectionRequestByEndpoint(this, parsed.first, parsed.second, body, prefs.getString("username", "NEXUS") ?: "NEXUS")
                                }.getOrDefault(false)
                                if (direct) break
                            }
                            if (!direct && record.address.isNotBlank() && NexusAddress.isValidOverlay(record.address)) {
                                runCatching {
                                    val request = NexusPeerRequests.create(this, record.address, body, prefs.getString("username", "NEXUS") ?: "NEXUS")
                                    NexusPeerRequests.publish(this, request, discovery.peersSnapshot()).publishedTo > 0
                                }.onSuccess { direct = it }
                            }
                            runOnUiThread {
                                Toast.makeText(this, if (direct) "Demande envoyée." else "Aucun chemin direct ou relayé n’a pu être confirmé.", Toast.LENGTH_LONG).show()
                            }
                        }
                    }.show()
            }.show()
    }

    private fun parseEndpoint(endpoint: String): Pair<String, Int>? = runCatching {
        val value = endpoint.trim().replace(" ", "")
        val host = if (value.startsWith("[")) value.substringAfter('[').substringBefore(']') else value.substringBeforeLast(':')
        val port = value.substringAfterLast(':').toInt()
        require(host.isNotBlank() && port in 1..65535)
        val ip = InetAddress.getByName(host)
        require(!ip.isLoopbackAddress && !ip.isLinkLocalAddress)
        host to port
    }.getOrNull()

    private fun showContacts() {
        val contacts = NexusContacts.list(this)
        val actions = arrayOf("Ajouter un contact")
        val labels = contacts.map { "${it.alias} • ${it.address}" }.toMutableList()
        labels.addAll(0, actions.toList())
        AlertDialog.Builder(this)
            .setTitle("Contacts NEXUS")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == 0) addContact() else showContactActions(contacts[which - 1])
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun addContact() {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(8),dp(20),0)}
        val alias=field("Nom du contact",InputType.TYPE_CLASS_TEXT)
        val address=field("Adresse NEXUS IPv6",InputType.TYPE_CLASS_TEXT)
        box.addView(alias); box.addView(address)
        AlertDialog.Builder(this).setTitle("Ajouter un contact NEXUS").setView(box)
            .setNegativeButton("Annuler",null)
            .setPositiveButton("Enregistrer"){_,_->
                runCatching{NexusContacts.add(this,alias.text.toString(),address.text.toString())}
                    .onSuccess{Toast.makeText(this,"Contact enregistré.",Toast.LENGTH_SHORT).show()}
                    .onFailure{Toast.makeText(this,"Contact refusé : ${it.message}",Toast.LENGTH_LONG).show()}
            }.show()
    }

    private fun showContactActions(contact:NexusContacts.Contact){
        AlertDialog.Builder(this).setTitle(contact.alias).setMessage(contact.address)
            .setItems(arrayOf("Envoyer une demande","Supprimer le contact")){_,which->
                if(which==0) contactByAddress(contact.address, contact.alias)
                else if(NexusContacts.remove(this,contact.id)) { Toast.makeText(this,"Contact supprimé.",Toast.LENGTH_SHORT).show(); refreshAll() }
            }.setNegativeButton("Fermer",null).show()
    }

    private fun contactByAddress(prefillAddress:String = "", prefillAlias:String = "") {
        val address = field("Adresse NEXUS IPv6 ou IP publique", InputType.TYPE_CLASS_TEXT).apply { setText(prefillAddress) }
        val message = EditText(this).apply {
            hint = if (prefillAlias.isBlank()) "Message de demande" else "Message pour $prefillAlias"
            minLines = 3
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(address); box.addView(space(8)); box.addView(message)
        AlertDialog.Builder(this)
            .setTitle("Contacter une adresse")
            .setMessage("Adresse NEXUS : routage via le réseau NEXUS. IP publique : tentative directe authentifiée sur le port ${NexusConfig.NODE_PORT}. Le destinataire doit accepter la demande.")
            .setView(box)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Envoyer la demande") { _, _ ->
                val target = address.text.toString().trim()
                val body = message.text.toString().trim()
                if (body.isBlank()) {
                    Toast.makeText(this, "Le message ne peut pas être vide.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val nexusTarget = runCatching { NexusAddress.canonicalize(target) }.getOrNull().takeIf { NexusAddress.isValidOverlay(it ?: "") }
                val directIp = parsePublicIpLiteral(target)
                if (nexusTarget == null && directIp == null) {
                    Toast.makeText(this, "Entre une adresse NEXUS fd00:… ou une IP publique réelle.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                ensureNodeService()
                thread(start = true, name = "nexus-address-request") {
                    if (nexusTarget != null) {
                        runCatching {
                            val request = NexusPeerRequests.create(this, nexusTarget, body, prefs.getString("username", "NEXUS") ?: "NEXUS")
                            val result = NexusPeerRequests.publish(this, request, discovery.peersSnapshot())
                            runOnUiThread {
                                val text = if (result.publishedTo > 0)
                                    "Demande envoyée par ${result.publishedTo} chemin(s) réel(s)."
                                else
                                    "Demande conservée localement : aucun chemin NEXUS joignable n'est disponible actuellement."
                                Toast.makeText(this, text, Toast.LENGTH_LONG).show()
                            }
                        }.onFailure { e -> runOnUiThread { Toast.makeText(this, "Envoi refusé : ${e.message ?: "erreur inconnue"}", Toast.LENGTH_LONG).show() } }
                    } else {
                        val sent = runCatching {
                            NxpProtocol.sendConnectionRequestByEndpoint(
                                this, directIp!!, NexusConfig.NODE_PORT, body,
                                prefs.getString("username", "NEXUS") ?: "NEXUS"
                            )
                        }.getOrDefault(false)
                        runOnUiThread {
                            val text = if (sent) "Demande envoyée directement après authentification du nœud distant."
                            else "IP joignable non confirmée : aucun envoi n'a été déclaré réussi."
                            Toast.makeText(this, text, Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }.show()
    }

    private fun parsePublicIpLiteral(value: String): String? {
        val raw = value.trim().removePrefix("[").substringBefore("]").trim()
        if (raw.isEmpty()) return null
        val validChars = raw.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' || it == ':' || it == '.' || it == '%' }
        if (!validChars) return null
        return runCatching {
            val addr = InetAddress.getByName(raw)
            if (addr.isAnyLocalAddress || addr.isLoopbackAddress || addr.isLinkLocalAddress || addr.isSiteLocalAddress || addr.isMulticastAddress) return@runCatching null
            addr.hostAddress?.takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    private fun showIncomingRequests() {
        ensureNodeService()
        thread(start = true, name = "nexus-request-pull-ui") {
            NexusPeerRequests.pull(this, discovery.peersSnapshot())
            val pending = NexusPeerRequests.pending(this)
            runOnUiThread {
                if (pending.isEmpty()) {
                    AlertDialog.Builder(this).setTitle("Demandes de connexion").setMessage("Aucune demande en attente.").setPositiveButton("Fermer", null).show()
                    return@runOnUiThread
                }
                val labels = pending.map { "${it.senderName} • ${it.senderAddress}\n${it.body}" }.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("Demandes de connexion (${pending.size})")
                    .setItems(labels) { _, index -> showRequestDecision(pending[index]) }
                    .setPositiveButton("Fermer", null)
                    .show()
            }
        }
    }

    private fun showRequestDecision(request: NexusPeerRequests.Request) {
        AlertDialog.Builder(this)
            .setTitle("Demande de ${request.senderName}")
            .setMessage("Adresse : ${request.senderAddress}\n\n${request.body}")
            .setNegativeButton("Refuser") { _, _ -> NexusPeerRequests.decline(this, request.id); refreshAll() }
            .setPositiveButton("Accepter") { _, _ ->
                val accepted = NexusPeerRequests.accept(this, request.id)
                if (accepted != null) {
                    NexusTrustStore.observe(this, request.senderNodeId, request.senderPublicKey)
                    Toast.makeText(this, "Demande acceptée. Le message a été enregistré dans ta messagerie locale.", Toast.LENGTH_LONG).show()
                }
                refreshAll()
            }.show()
    }

    private fun shareNexusAddress() {
        val own = NexusAddress.overlayIpv6(this)
        val globals = NexusAddress.realGlobalAddresses()
        val text = buildString {
            append("Adresse NEXUS : ").append(own).append("\n")
            append("Port NXP : ").append(NexusConfig.NODE_PORT).append("\n")
            if (globals.isNotEmpty()) append("IP directement routable détectée : ").append(globals.joinToString(", ")).append("\n")
            append("Lien : ").append(NexusShareLink.forAddress(own)).append("\n")
            append("Une demande doit être acceptée par le destinataire.")
        }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Partager l'adresse NEXUS"))
    }

    private fun shareNexusContactLink() {
        val link = NexusShareLink.forAddress(NexusAddress.overlayIpv6(this))
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, link) }, "Partager le lien NEXUS"))
    }

    private fun showNexusName() {
        thread(start = true, name = "nexus-name-publish") {
            val name = NexusNaming.own(this, NexusAddress.advertisedAddresses(this))
            val peers = discovery.peersSnapshot().filter { it.host.isNotBlank() && NexusTrustStore.isAllowed(this, it.name) }.take(8)
            val published = peers.count { peer ->
                val record = NexusDht(NexusIdentity.nodeId(this)).signed(this, name.name, NexusNaming.wire(name), name.expiresAt - System.currentTimeMillis())
                NxpProtocol.pushDhtRecord(peer.host, peer.port, record) { NetworkKeyManager.accepted(this) }
            }
            runOnUiThread {
                AlertDialog.Builder(this).setTitle("Nom décentralisé .mesh")
                    .setMessage("Nom : ${name.name}\nAdresse : ${NexusAddress.overlayIpv6(this)}\n\nPublication DHT réelle : $published pair(s) confirmés.\nCe nom n'est pas un nom DNS public classique : il est signé par ton identité NEXUS.")
                    .setNegativeButton("Fermer", null)
                    .setPositiveButton("Partager") { _, _ -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT, name.name) }, "Partager le nom NEXUS")) }
                    .show()
            }
        }
    }

    private fun traceNexusAddress() {
        val input = field("Adresse NEXUS ou nom .mesh", InputType.TYPE_CLASS_TEXT)
        AlertDialog.Builder(this).setTitle("Tracer une destination")
            .setMessage("Le diagnostic utilise uniquement les enregistrements et mesures réellement reçus.")
            .setView(input).setNegativeButton("Annuler", null)
            .setPositiveButton("Tracer") { _, _ ->
                val target = input.text.toString().trim()
                thread(start = true, name = "nexus-trace") {
                    val peers = discovery.peersSnapshot()
                    val addressRecord = NexusAddressBook.resolve(this, target, peers)
                    val nameRecord = if (target.endsWith(".mesh", true)) NexusNaming.resolveDistributed(this, target, peers) else null
                    val overlay = addressRecord?.address ?: nameRecord?.addresses?.firstOrNull { NexusAddress.isValidOverlay(it) }
                    val endpoints = addressRecord?.endpoints.orEmpty().ifEmpty { nameRecord?.addresses.orEmpty().filter { it.startsWith("[") } }
                    if (overlay == null && nameRecord == null) {
                        runOnUiThread { Toast.makeText(this, "Destination non résolue par les pairs disponibles.", Toast.LENGTH_LONG).show() }
                        return@thread
                    }
                    val title = nameRecord?.name ?: overlay.orEmpty()
                    val sb = StringBuilder().append("Destination : ").append(title).append("\n")
                    if (!overlay.isNullOrBlank()) sb.append("Adresse NEXUS : ").append(overlay).append("\n")
                    if (nameRecord != null) sb.append("Identité : ").append(nameRecord.nodeId).append("\n")
                    if (endpoints.isEmpty()) sb.append("Aucun endpoint global signé n'est publié actuellement.\n")
                    val seen = endpoints.distinct()
                    seen.forEach { endpoint ->
                        val host = endpoint.substringAfter('[').substringBefore(']')
                        val port = endpoint.substringAfter("]:").toIntOrNull() ?: NexusConfig.NODE_PORT
                        val caps = runCatching { NxpProtocol.probeCapabilities(host, port) { NetworkKeyManager.accepted(this) } }.getOrNull()
                        if (caps == null) sb.append("\n").append(endpoint).append(" → non joignable/authentifié actuellement")
                        else sb.append("\n").append(endpoint).append(" → identité=").append(caps.authenticatedIdentity)
                            .append(", latence=").append(String.format(Locale.US, "%.1f", caps.latencyMs)).append(" ms")
                            .append(", perte=").append(String.format(Locale.US, "%.1f", caps.packetLossPct)).append("%")
                            .append(", chemin=").append(caps.gatewayPath.joinToString(" → ").ifBlank { "direct" })
                    }
                    runOnUiThread { AlertDialog.Builder(this).setTitle("Trace réelle").setMessage(sb.toString()).setPositiveButton("OK", null).show() }
                }
            }.show()
    }

    private fun probePublicIp() {
        val input = field("IP publique réelle", InputType.TYPE_CLASS_TEXT)
        AlertDialog.Builder(this).setTitle("Vérifier une IP")
            .setMessage("NEXUS authentifie d'abord le nœud sur le port ${NexusConfig.NODE_PORT}. Aucune réussite n'est affichée sans handshake réel.")
            .setView(input).setNegativeButton("Annuler", null)
            .setPositiveButton("Vérifier") { _, _ ->
                val host = parsePublicIpLiteral(input.text.toString())
                if (host == null) { Toast.makeText(this, "IP publique invalide ou non routable.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                thread(start = true, name = "nexus-ip-probe") {
                    val result = runCatching { NxpProtocol.probeCapabilities(host, NexusConfig.NODE_PORT) { NetworkKeyManager.accepted(this) } }
                    runOnUiThread {
                        result.onSuccess { caps ->
                            val address = NexusAddress.overlayIpv6FromPublicKey(caps.identityPublicKey)
                            AlertDialog.Builder(this).setTitle("Nœud authentifié")
                                .setMessage("Adresse NEXUS : $address\nNœud : ${caps.nodeId}\nIdentité authentifiée : ${caps.authenticatedIdentity}\nLatence réelle : ${String.format(Locale.US, "%.1f", caps.latencyMs)} ms\nPerte réelle : ${String.format(Locale.US, "%.1f", caps.packetLossPct)}%")
                                .setPositiveButton("Contacter") { _, _ -> contactByAddress(address) }.show()
                        }.onFailure { Toast.makeText(this, "IP non confirmée : ${it.message ?: "nœud inaccessible"}", Toast.LENGTH_LONG).show() }
                    }
                }
            }.show()
    }

    private fun recoverNetworkPath() {
        startNodeService(); startDiscovery(); startVpnConsentFlow()
        Toast.makeText(this, "Recherche et basculement vers des chemins réels en cours.", Toast.LENGTH_LONG).show()
        thread(start = true, name = "nexus-route-recovery") {
            val snapshot = peerRows.toList()
            val successes = snapshot.count { peer -> NxpProtocol.measurePeer(peer.host, peer.port) { NetworkKeyManager.accepted(this) }.isSuccess }
            runOnUiThread { refreshAll(); Toast.makeText(this, "Récupération réseau : $successes/${snapshot.size} pair(s) répondent actuellement.", Toast.LENGTH_LONG).show() }
        }
    }

    private fun showOfflineMailbox() {
        val all = NexusPeerRequests.localInbox(this)
        if (all.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Boîte hors ligne").setMessage("Aucune demande persistée. Les nouvelles demandes sont stockées localement lorsqu'elles sont réellement reçues.").setPositiveButton("Fermer", null).show()
            return
        }
        val body = all.joinToString("\n\n") { r ->
            val state = when {
                NexusPeerRequests.pending(this).any { it.id == r.id } -> "EN ATTENTE"
                NexusPeerRequests.accepted(this).any { it.id == r.id } -> "ACCEPTÉE"
                else -> "REFUSÉE"
            }
            "[$state] ${r.senderName} • ${r.senderAddress}\n${r.body}"
        }
        AlertDialog.Builder(this).setTitle("Boîte hors ligne").setMessage(body).setPositiveButton("Fermer", null).show()
    }

    private fun ensureNodeService() {
        val intent = Intent(this, NexusNodeService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun sendMessageToPeer(){
        val peers=peerRows.filter{it.host.isNotBlank() && NexusTrustStore.isAllowed(this,it.name)};if(peers.isEmpty()){Toast.makeText(this,"Aucun nœud disponible pour la messagerie.",Toast.LENGTH_LONG).show();return}
        AlertDialog.Builder(this).setTitle("Choisir le destinataire").setItems(peers.map{it.name}.toTypedArray()){_,i->
            val peer=peers[i];val input=EditText(this).apply{hint="Message";minLines=3;gravity=Gravity.TOP;inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE}
            AlertDialog.Builder(this).setTitle("Message vers ${peer.name}").setView(input).setNegativeButton("Annuler",null).setPositiveButton("Envoyer"){_,_->thread(start=true,name="nexus-message"){val r=NexusServiceProtocol.sendMessage(this,peer.host,peer.name,input.text.toString());runOnUiThread{Toast.makeText(this,if(r.isSuccess)"Message envoyé réellement à ${peer.name}." else "Échec : ${r.exceptionOrNull()?.message}",Toast.LENGTH_LONG).show()}}}.show()
        }.show()
    }

    private fun pullMessagesFromPeer(){ pickServicePeer{peer->thread(start=true,name="nexus-message-pull"){val r=NexusServiceProtocol.pullMessages(this,peer.host);runOnUiThread{val msg=r.getOrDefault(emptyList());AlertDialog.Builder(this).setTitle("Messages depuis ${peer.name}").setMessage(if(msg.isEmpty())"Aucun message disponible." else msg.joinToString("\n\n"){"${it.sender} • ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(it.createdAt))}\n${it.body}"}).setPositiveButton("OK",null).show()}}} }

    private fun runLocalCompute(){
        val input=EditText(this).apply{hint="Texte ou données à traiter";minLines=4;gravity=Gravity.TOP;inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE}
        val ops=NexusCompute.operations.toTypedArray();AlertDialog.Builder(this).setTitle("Calcul local").setSingleChoiceItems(ops,0,null).setView(input).setNegativeButton("Annuler",null).setPositiveButton("Exécuter"){dialog,_->
            val list=(dialog as AlertDialog).listView; val op=ops.getOrElse(list.checkedItemPosition){ops.first()}; val bytes=input.text.toString().toByteArray(Charsets.UTF_8); runCatching{NexusCompute.execute(this,NexusCompute.Task("local-${System.nanoTime()}",op,bytes))}.onSuccess{Toast.makeText(this,"Calcul local terminé • ${op}\n${it.output.joinToString(""){"%02x".format(it.toInt() and 0xff)}}",Toast.LENGTH_LONG).show()}.onFailure{Toast.makeText(this,"Calcul refusé : ${it.message}",Toast.LENGTH_LONG).show()}
        }.show()
    }

    private fun runRemoteCompute(){
        val peers=peerRows.filter{it.host.isNotBlank()&&NexusTrustStore.isAllowed(this,it.name)};if(peers.isEmpty()){Toast.makeText(this,"Aucun nœud de calcul joignable.",Toast.LENGTH_LONG).show();return}
        val input=EditText(this).apply{hint="Données à calculer";minLines=3;gravity=Gravity.TOP;inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE};val ops=NexusCompute.operations.toTypedArray()
        AlertDialog.Builder(this).setTitle("Calcul distribué").setSingleChoiceItems(ops,0,null).setView(input).setNegativeButton("Annuler",null).setPositiveButton("Choisir le nœud"){dialog,_-> val op=ops.getOrElse((dialog as AlertDialog).listView.checkedItemPosition){ops.first()}; val data=input.text.toString().toByteArray(Charsets.UTF_8); AlertDialog.Builder(this).setTitle("Nœud de calcul").setItems(peers.map{it.name}.toTypedArray()){_,i->val peer=peers[i];thread(start=true,name="nexus-compute"){val task=NexusCompute.Task("task-${System.nanoTime()}",op,data);val r=NexusServiceProtocol.compute(this,peer.host,task);runOnUiThread{Toast.makeText(this,r.fold({"Calcul réel terminé par ${it.provider} • résultat=${it.output.joinToString(""){"%02x".format(it.toInt() and 0xff)}}"},{"Échec : ${it.message}"}),Toast.LENGTH_LONG).show()}}}.show()}.show()
    }

    private fun fetchContentFromNetwork(){
        val hash=field("SHA-256 du contenu (64 hex)",InputType.TYPE_CLASS_TEXT)
        AlertDialog.Builder(this).setTitle("Récupération distribuée").setView(hash).setNegativeButton("Annuler",null).setPositiveButton("Choisir la destination"){_,_->
            val clean=hash.text.toString().trim();if(!clean.matches(Regex("[0-9a-fA-F]{64}"))){Toast.makeText(this,"Hash SHA-256 invalide.",Toast.LENGTH_LONG).show();return@setPositiveButton}
            val out=EditText(this).apply{hint="Nom du fichier local";setSingleLine(true)}
            AlertDialog.Builder(this).setTitle("Fichier de sortie").setView(out).setNegativeButton("Annuler",null).setPositiveButton("Récupérer"){_,_->thread(start=true,name="nexus-content-fetch"){val file=File(filesDir,out.text.toString().ifBlank{"nexus-$clean.bin"});val r=NexusContentClient.fetchFromAny(this,clean.lowercase(Locale.US),peerRows,file);runOnUiThread{Toast.makeText(this,r.fold({"Contenu récupéré : ${it.absolutePath}"},{"Échec : ${it.message}"}),Toast.LENGTH_LONG).show()}}}.show()
        }.show()
    }

    private fun runAutoRepair(){Toast.makeText(this,"Vérification et récupération réelles en cours…",Toast.LENGTH_LONG).show();thread(start=true,name="nexus-auto-repair-ui"){val peers=peerRows.toList();val r=NexusAutoRepair(this){peers}.runOnce();runOnUiThread{Toast.makeText(this,"Auto-réparation : ${r.checked} vérifié(s), ${r.repaired} réparé(s), ${r.failed} non récupérable(s).",Toast.LENGTH_LONG).show()}}}

    private fun showResourceOffer(){val o=NexusResourceMarket.localOffer(this);AlertDialog.Builder(this).setTitle("Ressources réellement disponibles").setMessage("CPU : ${o.cpuCores} cœurs\nRAM libre : ${o.ramMb} Mo\nStockage libre : ${o.storageFreeMb} Mo\nRelais configuré : ${String.format(Locale.US,"%.1f",o.relayMbps)} Mb/s\nCalcul autorisé : ${o.computeOps.joinToString(", ")}\n\nCes valeurs sont lues sur cet appareil au moment de l'affichage.").setPositiveButton("OK",null).show()}

    private fun toggleDatabaseReplication(){val next=!NexusSettings.databaseReplicationEnabled(this);NexusSettings.setDatabaseReplicationEnabled(this,next);Toast.makeText(this,"Réplication des bases ${if(next)"activée" else "désactivée"}.",Toast.LENGTH_LONG).show()}

    private fun showEdgeCache(){
        val stats=NexusEdgeCache.stats(this)
        val msg="Entrées : ${stats.entries}\nTaille : ${stats.bytes/(1024*1024)} MiB\nQuota : ${stats.quotaBytes/(1024*1024)} MiB\n\nLe cache edge accélère les récupérations locales par contenu. Il reste dans le cache privé Android et peut être supprimé par le système."
        AlertDialog.Builder(this).setTitle("Cache edge / CDN local").setMessage(msg)
            .setNegativeButton("Fermer",null)
            .setPositiveButton("Configurer") { _, _ ->
                val input=EditText(this).apply{inputType=InputType.TYPE_CLASS_NUMBER;setSingleLine(true);setText((NexusSettings.edgeCacheQuotaBytes(this@MainActivity)/(1024*1024)).toString());hint="MiB"}
                AlertDialog.Builder(this).setTitle("Quota cache edge").setMessage("64 à 10240 MiB, uniquement sur cet appareil.").setView(input).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer"){_,_->input.text.toString().toLongOrNull()?.let{NexusSettings.setEdgeCacheQuotaMb(this,it);NexusEdgeCache.evictToQuota(this);showEdgeCache()}}.show()
            }.setNeutralButton("Vider le cache"){_,_->NexusEdgeCache.clear(this);Toast.makeText(this,"Cache edge vidé.",Toast.LENGTH_SHORT).show()}.show()
    }

    private fun syncUniversalDatabase(){
        val dbInput=field("Base à synchroniser",InputType.TYPE_CLASS_TEXT)
        AlertDialog.Builder(this).setTitle("Synchronisation universelle").setMessage("Les enregistrements distants sont fusionnés selon la résolution déterministe de NEXUS, puis les enregistrements issus de ce nœud sont renvoyés au pair.").setView(dbInput).setNegativeButton("Annuler",null).setPositiveButton("Choisir le nœud"){_,_->
            val db=dbInput.text.toString().trim(); if(db.isBlank()){Toast.makeText(this,"Nom de base requis.",Toast.LENGTH_SHORT).show();return@setPositiveButton}
            pickServicePeer { peer ->
                thread(start=true,name="nexus-universal-sync"){
                    val r=NexusUniversalSync.sync(this,peer.host,peer.name,db)
                    runOnUiThread{Toast.makeText(this,r.fold({"Sync ${it.database} ↔ ${it.remoteNode} terminée • +${it.merged} fusion(s), ${it.pushed} poussée(s)"},{"Synchronisation échouée : ${it.message}"}),Toast.LENGTH_LONG).show()}
                }
            }
        }.show()
    }

    private fun chooseErasureFile(){
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            addCategory(Intent.CATEGORY_OPENABLE)
            type="application/octet-stream"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false)
        }
        startActivityForResult(intent,813)
    }

    private fun processErasureFile(uri:android.net.Uri){
        thread(start=true,name="nexus-erasure-file") {
            runCatching {
                val bytes=contentResolver.openInputStream(uri)?.use { input ->
                    val out=java.io.ByteArrayOutputStream()
                    val buffer=ByteArray(64*1024)
                    var total=0
                    while(true){
                        val n=input.read(buffer)
                        if(n<0) break
                        total+=n
                        require(total <= 64*1024*1024) { "Fichier trop volumineux pour ce traitement local (maximum 64 MiB)." }
                        out.write(buffer,0,n)
                    }
                    out.toByteArray()
                } ?: error("Impossible de lire le fichier sélectionné")
                require(bytes.isNotEmpty()) { "Le fichier est vide." }
                val stripe=NexusErasureCoding.encode(bytes)
                val recovered=NexusErasureCoding.recover(stripe,null,stripe.dataB,stripe.parity)
                check(bytes.contentEquals(recovered)) { "La vérification de récupération a échoué." }
                runOnUiThread {
                    AlertDialog.Builder(this).setTitle("Tolérance aux pertes 2+1")
                        .setMessage("Fichier réel traité localement.\n\n2 fragments de données + 1 parité XOR.\nTaille : ${stripe.originalSize} octets\nFragment : ${stripe.shardSize} octets\nVérification de récupération : réussie.")
                        .setPositiveButton("OK",null).show()
                }
            }.onFailure { e ->
                runOnUiThread { Toast.makeText(this,"Codage refusé : ${e.message ?: "erreur de lecture"}",Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun showFullHealth(){
        val report=NexusHealth.run(this)
        AlertDialog.Builder(this).setTitle("Diagnostic NEXUS").setMessage("Contrôles valides : ${report.healthyCount}/${report.checks.size}\n\n${report.text()}").setPositiveButton("Réparer les contenus"){_,_->runAutoRepair()}.setNegativeButton("Fermer",null).show()
    }

    private fun showDeveloperInfo(){
        val msg="Port service : ${NexusConfig.SERVICE_PORT}\n" +
            "URI runtime : nexus://<nœud>/<service>/<chemin>\n" +
            "Opérations calcul : ${NexusCompute.operations.joinToString(", ")}\n" +
            "Base : réplication LWW avec horloge logique et hash de contenu.\n" +
            "Sync : fusion déterministe + digest SHA-256.\n" +
            "Cache local : les données récentes restent sur cet appareil.\n" +
            "Erasure coding : 2+1 XOR, récupération d'une perte.\n" +
            "Capacités : jetons signés, limités à un sujet, une ressource et une durée.\n" +
            "Messagerie : boîte distribuée par nœud.\n" +
            "Les outils distants ne peuvent pas exécuter du code arbitraire sur ton téléphone."
        AlertDialog.Builder(this).setTitle("Outils développeur NEXUS").setMessage(msg).setPositiveButton("OK",null).show()
    }
    private fun showCapability(){
        val subject=NexusIdentity.nodeId(this)
        val token=NexusCapabilities.issue(this,subject,"storage.read","content/*",60_000L)
        val encoded=NexusCapabilities.encode(token)
        val verified=runCatching{NexusCapabilities.verify(NexusCapabilities.decode(encoded),subject,"storage.read","content/*")}.getOrDefault(false)
        AlertDialog.Builder(this).setTitle("Capacité d'accès").setMessage("Sujet : $subject\nCapacité : ${token.capability}\nRessource : ${token.resource}\nExpiration : ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(token.expiresAt))}\n\nVérification cryptographique locale : ${if(verified)"valide" else "invalide"}\n\nCes jetons limitent une opération à un sujet, une ressource et une durée. Ils ne donnent pas un accès illimité au téléphone.").setPositiveButton("OK",null).show()
    }

    private fun showDevices(){
        val msg="Cet appareil\nID : ${NexusIdentity.nodeId(this)}\n\n" +
            "Les pairs réellement découverts apparaissent dans Réseau. NEXUS n’annonce pas de compte multi-appareils qui n’existe pas."
        AlertDialog.Builder(this).setTitle("Appareils et sessions").setMessage(msg).setPositiveButton("Voir le réseau"){_,_->renderTab(1)}.setNegativeButton("Fermer",null).show()
    }
    private fun showParticipationSettings(){
        val items=arrayOf("Aider d’autres appareils","Partager du stockage","Contrôler les crédits","Aider seulement quand le téléphone charge","Autoriser le partage sur réseau mobile","Limiter aux appareils autorisés")
        val checked=booleanArrayOf(transitEnabled,NexusSettings.storageRelayEnabled(this),NexusSettings.creditsEnforced(this),NexusSettings.relayChargingOnly(this),NexusSettings.allowMeteredRelay(this),NexusSettings.trustedOnly(this))
        AlertDialog.Builder(this).setTitle("Participation et permissions").setMultiChoiceItems(items,checked){_,which,isChecked->
            when(which){
                0->{transitEnabled=isChecked; NexusSettings.setTransit(this,isChecked); sendAction(NexusConfig.ACTION_TRANSIT,isChecked)}
                1->NexusSettings.setStorageRelayEnabled(this,isChecked)
                2->NexusSettings.setCreditsEnforced(this,isChecked)
                3->NexusSettings.setRelayChargingOnly(this,isChecked)
                4->NexusSettings.setAllowMeteredRelay(this,isChecked)
                5->NexusSettings.setTrustedOnly(this,isChecked)
            }
            refreshResources(); refreshSecurity()
        }.setPositiveButton("Fermer",null).show()
    }
    private fun showSecurity(){
        val message = "Identité : ${NexusIdentity.publicKeyFingerprint(this)}\n\n" +
            "Confiance renforcée : ${NexusSettings.trustedOnly(this)}\n" +
            "Empreinte de la clé réseau : ${NetworkKeyManager.fingerprint(NexusIdentity.networkKey(this))}\n\n" +
            "Pour relier deux appareils éloignés, ils doivent rejoindre le même réseau NEXUS et disposer d'un chemin IP réel (Internet ou relais accessible). La proximité physique n'est pas requise."
        AlertDialog.Builder(this)
            .setTitle("Sécurité et réseau privé")
            .setMessage(message)
            .setPositiveButton("Gérer la confiance"){_,_->manageTrustedPeers()}
            .setNeutralButton("Partager le code"){_,_->shareNetworkInvite()}
            .setNegativeButton("Fermer",null)
            .show()
    }

    private fun shareNetworkInvite(){
        val invite = "NEXUS-PRIVATE-1:${NexusIdentity.networkKey(this)}"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, invite)
        }
        startActivity(Intent.createChooser(intent, "Partager le code du réseau NEXUS"))
    }

    private fun joinNetworkInvite(){
        val input = EditText(this).apply {
            hint = "NEXUS-PRIVATE-1:NXK-..."
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle("Rejoindre un réseau privé")
            .setMessage("Entre le code d'invitation reçu d'une personne de confiance. Le code donne accès au réseau privé correspondant ; ne le publie pas.")
            .setView(input)
            .setNegativeButton("Annuler",null)
            .setPositiveButton("Rejoindre"){_,_->
                val raw = input.text.toString().trim()
                val prefix = "NEXUS-PRIVATE-1:"
                val key = if (raw.startsWith(prefix)) raw.removePrefix(prefix).trim() else raw.trim()
                if (!NetworkKeyManager.isPlausibleKey(key)) {
                    Toast.makeText(this,"Code de réseau invalide.",Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                runCatching { NexusIdentity.setNetworkKey(this,key) }
                    .onSuccess {
                        discovery.probeAll()
                        refreshSecurity()
                        Toast.makeText(this,"Réseau privé rejoint. Un point d'entrée distant peut être nécessaire hors du réseau local.",Toast.LENGTH_LONG).show()
                    }
                    .onFailure { Toast.makeText(this, "Code refusé : ${it.message}", Toast.LENGTH_LONG).show() }
            }
            .show()
    }
    private fun editResourcePolicies(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(8),dp(20),0)}
        val battery=EditText(this).apply{inputType=InputType.TYPE_CLASS_NUMBER;setSingleLine(true);setText(NexusSettings.minRelayBattery(this@MainActivity).toString());hint="% batterie minimum"}
        val storage=EditText(this).apply{inputType=InputType.TYPE_CLASS_NUMBER;setSingleLine(true);setText((NexusSettings.storageQuotaBytes(this@MainActivity)/(1024L*1024L)).toString());hint="Mo de stockage"}
        box.addView(label("Batterie minimum pour relayer",14,true,text)); box.addView(battery)
        box.addView(label("Quota de stockage distribué",14,true,text)); box.addView(storage)
        box.addView(label("Les quotas sont locaux à cet appareil. NEXUS ne prétend pas fournir un stockage permanent si l'appareil est éteint, réinitialisé ou retiré.",12,false,secondary))
        AlertDialog.Builder(this).setTitle("Batterie, données et stockage").setView(box).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer"){_,_->
            battery.text.toString().toIntOrNull()?.let{NexusSettings.setMinRelayBattery(this,it)}
            storage.text.toString().toLongOrNull()?.let{NexusSettings.setStorageQuotaMb(this,it)}
            refreshResources()
        }.show()
    }

    private fun showNetworkAdvanced(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(8),dp(20),0)}
        box.addView(primaryButton("Partager ma connexion : ${if(gatewayEnabled)"activé" else "arrêté"}"){toggleGateway()})
        box.addView(secondaryButton("Aider les autres appareils : ${if(transitEnabled)"activé" else "arrêté"}"){toggleTransit()})
        vpnButton=secondaryButton(if (NexusVpnRegistry.isActive()) "Arrêter le TUN NEXUS" else "Démarrer le TUN NEXUS") { if (NexusVpnRegistry.isActive()) stopVpnService() else startVpnConsentFlow() }; box.addView(vpnButton)
        box.addView(secondaryButton("Tester Internet pour de vrai"){testGateway()})
        box.addView(secondaryButton("Ajouter un point d’entrée"){addRemoteBootstrap()})
        box.addView(secondaryButton("Rejoindre un réseau privé"){joinNetworkInvite()})
        AlertDialog.Builder(this).setTitle("Réglages réseau").setView(box).setPositiveButton("Fermer",null).show()
    }

    private fun navButton(name:String,index:Int)=Button(this).apply{ text=name; textSize=12f; isAllCaps=false; setTextColor(if(index==activeTab)blue else secondary); background=null; layoutParams=LinearLayout.LayoutParams(0,dp(54),1f); setOnClickListener{renderTab(index)} }
    private fun primaryButton(t:String,on:()->Unit)=Button(this).apply{text=t;isAllCaps=false;textSize=15f;setTextColor(cardBg);setBackgroundColor(blue);minHeight=dp(50);setOnClickListener{on()}}
    private fun secondaryButton(t:String,on:()->Unit)=Button(this).apply{text=t;isAllCaps=false;textSize=14f;setTextColor(blue);setBackgroundColor(cardBg);minHeight=dp(48);setOnClickListener{on()}}
    private fun textButton(t:String,on:()->Unit)=Button(this).apply{text=t;textSize=24f;isAllCaps=false;background=null;setTextColor(this@MainActivity.text);contentDescription="Menu";setOnClickListener{on()}}
    private fun panel(title:String,detail:String)=cardView(label("$title\n$detail",14,false,text))
    private fun statusCard(title:String,detail:String)=cardView(label("$title\n$detail",16,true,text))
    private fun cardView(v:View,title:String?=null,accent:Int?=null):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(15),dp(16),dp(15)); setBackgroundColor(cardBg)
        if(accent!=null){ addView(View(this@MainActivity).apply{setBackgroundColor(accent);layoutParams=LinearLayout.LayoutParams(dp(4),dp(28)).apply{gravity=Gravity.START}}) }
        if(title!=null)addView(label(title,15,true,text)); addView(v)
        layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(6))}
    }
    private fun section(t:String,visible:Boolean):TextView=label(t,18,true,text)
    private fun field(h:String,type:Int)=EditText(this).apply{hint=h;inputType=type;setSingleLine(true);setPadding(dp(8),dp(10),dp(8),dp(10))}
    private fun space(d:Int)=View(this).apply{layoutParams=LinearLayout.LayoutParams(1,dp(d))}
    private fun sha256(s:String):String=MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){String.format("%02x",it)}
    private fun passwordHash(password:String,email:String):String{
        val salt=("NEXUS|"+email.trim().lowercase(Locale.US)).toByteArray()
        val spec=javax.crypto.spec.PBEKeySpec(password.toCharArray(),salt,120_000,256)
        val bytes=javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return bytes.joinToString(""){String.format("%02x",it)}
    }

    private fun startNodeService() {
        NexusSettings.setGateway(this, gatewayEnabled)
        NexusSettings.setTransit(this, transitEnabled)
        val intent = Intent(this, NexusNodeService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        if (::statusText.isInitialized) statusText.text = "NEXUS est démarré. Les réglages choisis sont appliqués."
    }

    private fun toggleGateway() {
        gatewayEnabled = !gatewayEnabled
        NexusSettings.setGateway(this, gatewayEnabled)
        sendAction(NexusConfig.ACTION_GATEWAY, gatewayEnabled)
        updateButtons()
        refreshGateway()
        refreshRoute()
    }

    private fun toggleTransit() {
        transitEnabled = !transitEnabled
        NexusSettings.setTransit(this, transitEnabled)
        sendAction(NexusConfig.ACTION_TRANSIT, transitEnabled)
        updateButtons()
        refreshRoute()
    }

    private fun sendAction(action: String, enabled: Boolean) {
        val intent = Intent(this, NexusNodeService::class.java).apply {
            this.action = action
            putExtra(NexusConfig.EXTRA_ENABLED, enabled)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun startDiscovery() {
        discovery.onChanged = { peers ->
            runOnUiThread {
                peerRows.clear()
                peerRows.addAll(peers.filter { it.name != NexusIdentity.nodeId(this) })
                updatePeersText()
                refreshRoute()
            }
        }
        runCatching { discovery.startDiscovery() }
        p2p.onDevicesChanged = { devices ->
            runOnUiThread {
                p2pRows.clear()
                p2pRows.addAll(devices)
                updateP2pText()
                discovery.refreshP2pEndpoints()
                refreshRoute()
            }
        }
        p2p.onStatus = { message ->
            runOnUiThread { p2pText.text = message }
        }
        p2p.start()
    }

    private fun refreshAll() {
        if (::networkText.isInitialized) refreshNetwork()
        if (::physicalText.isInitialized) refreshPhysicalBackhaul()
        if (::nodeText.isInitialized) refreshNode()
        if (::gatewayText.isInitialized) refreshGateway()
        if (::routeText.isInitialized) refreshRoute()
        if (::peersText.isInitialized) updatePeersText()
        if (::p2pText.isInitialized) updateP2pText()
        if (::vpnButton.isInitialized) updateVpnButton()
        if (::creditsText.isInitialized && ::storageText.isInitialized) refreshResources()
        if (::trustText.isInitialized && ::bootstrapText.isInitialized) refreshSecurity()
    }

    private fun refreshNetwork() {
        if (!::networkText.isInitialized) return
        val snapshot = NetworkInspector.snapshot(this)
        val validation = when {
            snapshot.validated -> "Internet validé par Android"
            snapshot.connected -> "Réseau connecté, Internet non validé"
            else -> "Aucun réseau actif détecté"
        }
        networkText.text = "État: $validation\nTransport: ${snapshot.transport}\nInterface: ${snapshot.interfaceName}\nIPv4 locale: ${snapshot.ipv4}\nIPv6 locale: ${snapshot.ipv6}" +
            (snapshot.linkSpeedMbps?.let { "\nDébit de lien annoncé: $it Mbps" } ?: "")
        if (::transportText.isInitialized) transportText.text = NexusTransportManager(this).humanSummary()
        if (!::statusText.isInitialized) return
        statusText.text = if (snapshot.validated) {
            "Internet vérifié par Android. Aucun débit inventé."
        } else {
            "Internet non vérifié. Aucun accès n’est déclaré comme disponible."
        }
    }

    private fun refreshPhysicalBackhaul() {
        if (!::physicalText.isInitialized) return
        val detector = NexusPhysicalBackhaul(this)
        physicalText.text = detector.globalCapabilitySummary() + "\n" + detector.physicalSummary()
    }

    private fun refreshNode() {
        val name = NexusNaming.own(this, NexusAddress.advertisedAddresses(this)).name
        if (!::nodeText.isInitialized) return
        nodeText.text = "ID: ${NexusIdentity.nodeId(this)}\nAdresse NEXUS: ${NexusAddress.overlayIpv6(this)}\nNom décentralisé: $name\nEmpreinte identité: ${NexusIdentity.publicKeyFingerprint(this)}\nIPv6 directement routable: ${NexusAddress.realGlobalAddresses().filter { it.contains(':') }.ifEmpty { listOf("aucune") }.joinToString(", ")}\nNXP: ${NexusConfig.NODE_PORT}\nSOCKS5 local: ${NexusConfig.SOCKS_PORT}\nRelais: ${NexusConfig.RELAY_PORT}\nContenu: ${NexusConfig.CONTENT_PORT}\nPartage APK: ${NexusConfig.APP_SHARE_PORT}\nService: ${NexusConfig.SERVICE_TYPE}"
    }

    private fun refreshGateway() {
        if (!::gatewayText.isInitialized) return
        val validated = NetworkInspector.snapshot(this).validated
        gatewayText.text = if (gatewayEnabled) {
            val state = if (validated) "Activée et Internet vérifié" else "Activée, mais Internet non vérifié"
            "$state\nSOCKS5: ${NexusConfig.SOCKS_PORT}\nIdentité locale: nexus\nClé réseau : empreinte ${NetworkKeyManager.fingerprint(NexusIdentity.networkKey(this))}"
        } else {
            "Partage Internet arrêté. Le téléphone ne partage rien sans ton accord."
        }
    }

    private fun refreshRoute() {
        if (!::routeText.isInitialized) return
        val router = MeshRouter(NexusIdentity.nodeId(this), { discovery.peersSnapshot() }) { peer -> NexusTrustStore.reputation(this, peer.name) }
        routeText.text = router.summary(gatewayEnabled && NetworkInspector.snapshot(this).validated, transitEnabled)
    }

    private fun updateButtons() {
        if (!::gatewayButton.isInitialized || !::transitButton.isInitialized) return
        gatewayButton.text = if (gatewayEnabled) "Arrêter le partage Internet" else "Partager ma connexion Internet"
        transitButton.text = if (transitEnabled) "Arrêter l’aide au réseau" else "Aider le réseau avec ce téléphone"
    }

    private fun updatePeersText() {
        if (!::peersText.isInitialized) return
        if (peerRows.isEmpty()) {
            peersText.text = "Aucun autre nœud NEXUS découvert sur la liaison locale."
            return
        }
        peersText.text = peerRows.joinToString("\n\n") { peer ->
            val distance = if (peer.gatewayDistance == Int.MAX_VALUE) "∞" else peer.gatewayDistance.toString()
            val path = peer.gatewayPath.takeIf { it.isNotEmpty() }?.joinToString(" → ") ?: "chemin en découverte"
            "${peer.name}\n${peer.host}:${peer.port}\npasserelle=${peer.gateway} • transit=${peer.relay}\ndistance annoncée=$distance • chemin=$path • ${if (peer.latencyMs.isFinite()) String.format(Locale.US, "%.1f ms", peer.latencyMs) else "latence inconnue"}"
        }
    }

    private fun updateP2pText() {
        if (!::p2pText.isInitialized) return
        if (p2pRows.isEmpty()) {
            p2pText.text = "Aucun appareil Wi‑Fi Direct découvert. Active le Wi‑Fi Direct et les appareils à proximité dans Android."
            return
        }
        val body = p2pRows.joinToString("\n") { it.deviceName.ifBlank { it.deviceAddress } }
        p2pText.text = "$body\n\nAppuie sur un appareil pour demander une connexion P2P."
        // A compact row of buttons keeps the screen usable on phones without requiring RecyclerView.
        val parent = p2pText.parent as? LinearLayout ?: return
        parent.childrenButtons().forEach { parent.removeView(it) }
        p2pRows.forEach { device ->
            parent.addView(Button(this).apply {
                text = "Connecter • ${device.deviceName.ifBlank { device.deviceAddress }}"
                setOnClickListener {
                    p2p.connect(device)
                    Toast.makeText(this@MainActivity, "Connexion Wi‑Fi Direct demandée.", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }

    private fun LinearLayout.childrenButtons(): List<Button> =
        (0 until childCount).map { getChildAt(it) }.filterIsInstance<Button>()

    private fun showLongDistanceDiagnostic() {
        val peers = peerRows.toList()
        thread(start = true, name = "nexus-long-distance-diagnostic") {
            val snapshot = NetworkInspector.snapshot(this)
            val transports = NexusTransportManager(this).transports()
            val globalIpv6 = NexusAddress.realGlobalAddresses().filter { it.contains(':') }
            val bootstrapCount = NexusSettings.bootstrapPeers(this).size
            val relayPeers = peers.count { it.relay && NexusTrustStore.isAllowed(this, it.name) }
            val stun = NexusNatTraversal { NexusVpnRegistry.protect(it) }.discover()
            val modes = mutableListOf<String>()
            if (globalIpv6.isNotEmpty()) modes += "IPv6 globale directe"
            if (stun.reachable) modes += "Connexion directe détectée par le test NAT"
            if (peers.any { it.host.isNotBlank() }) modes += "Liaison NEXUS directe via pair connu"
            if (relayPeers > 0) modes += "Relais NEXUS multi-saut"
            if (bootstrapCount > 0) modes += "Boîte aux lettres DHT longue distance"
            if (modes.isEmpty()) modes += "Aucun chemin distant réellement disponible"
            val report = "Connectivité Android : ${if (snapshot.validated) "Internet validé" else "Internet non vérifié"}\n" +
                "Backhauls validés : ${transports.count { it.validated }}\n" +
                "IPv6 globale détectée : ${if (globalIpv6.isEmpty()) "aucune" else globalIpv6.joinToString(", ")}\n" +
                "Test de connexion directe : ${if (stun.reachable) "réussi (${stun.server})" else "non disponible"}\n" +
                "Pairs connus : ${peers.size} • relais : $relayPeers\n" +
                "Points d'entrée configurés : $bootstrapCount\n\n" +
                "Chemins réels actuellement possibles :\n${modes.joinToString("\n")}"
            runOnUiThread { AlertDialog.Builder(this).setTitle("Diagnostic longue distance").setMessage(report).setPositiveButton("Fermer", null).show() }
        }
    }

    private fun refreshResources() {
        if (!::creditsText.isInitialized || !::storageText.isInitialized) return
        creditsText.text = "Crédits : ${NexusCredits.balance(this)} • contrôle=${if (NexusSettings.creditsEnforced(this)) "actif" else "inactif"}\nAide au réseau : ${if (transitEnabled) "active" else "inactive"}\nLimite de partage : ${String.format(Locale.US, "%.1f", NexusSettings.relayLimitMbps(this))} Mb/s • limite par jour : ${NexusSettings.relayDailyLimitBytes(this) / (1024L * 1024L)} Mo"
        storageText.text = "Stockage partagé : ${if (NexusSettings.storageRelayEnabled(this)) "actif" else "inactif"}\nDonnées conservées : ${NexusContentStore.allPinned(this).size}"
    }

    private fun addRemoteBootstrap() {
        val input = EditText(this).apply {
            hint = "hôte:45454 ou nexus://hôte:45454"
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Point d’entrée distant")
            .setMessage("Ajoute uniquement un nœud NEXUS que tu connais ou qu’une organisation de résilience t’a fourni. NEXUS ne crée pas de serveur mondial automatiquement.")
            .setView(input)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Ajouter") { _, _ ->
                val value = input.text.toString().trim()
                val endpoint = parseBootstrap(value)
                if (endpoint == null) {
                    Toast.makeText(this, "Point d’entrée invalide. Utilise hôte:port ou nexus://hôte:port.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val canonical = "${endpoint.first}:${endpoint.second}"
                val existing = NexusSettings.bootstrapPeers(this)
                if (existing.none { it.equals(canonical, ignoreCase = true) || it.equals(value, ignoreCase = true) }) {
                    NexusSettings.setBootstrapPeers(this, existing + canonical)
                    discovery.addRemotePeer(endpoint.first, endpoint.second)
                    refreshSecurity()
                    Toast.makeText(this, "Point d’entrée enregistré : $canonical", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Ce point d’entrée est déjà enregistré.", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    private fun parseBootstrap(value: String): Pair<String, Int>? = NexusInterop.parse(value)?.let { it.host to it.port }

    private fun manageTrustedPeers() {
        val peers = peerRows.distinctBy { it.name }.sortedBy { it.name }
        if (peers.isEmpty()) {
            Toast.makeText(this, "Aucun nœud découvert à autoriser.", Toast.LENGTH_SHORT).show()
            return
        }
        val current = NexusSettings.trustedPeerIds(this).toMutableSet()
        val names = peers.map { it.name }.toTypedArray()
        val checked = peers.map { current.contains(it.name) }.toBooleanArray()
        AlertDialog.Builder(this)
            .setTitle("Nœuds autorisés")
            .setMultiChoiceItems(names, checked) { _, which, isChecked ->
                val node = peers[which].name
                if (isChecked) current.add(node) else current.remove(node)
            }
            .setNegativeButton("Fermer", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                NexusSettings.setTrustedPeerIds(this, current)
                refreshSecurity()
                discovery.probeAll()
            }.show()
    }

    private fun refreshSecurity() {
        val trusted = NexusSettings.trustedPeerIds(this).size
        if (!::trustText.isInitialized || !::bootstrapText.isInitialized) return
        trustText.text = "Accès : ${if (NexusSettings.trustedOnly(this)) "appareils autorisés uniquement" else "ouvert avec vérification"} • appareils autorisés=$trusted"
        bootstrapText.text = NexusSettings.bootstrapPeers(this).let { peers ->
            if (peers.isEmpty()) "Points d'entrée distants : aucun (découverte locale uniquement)"
            else "Points d'entrée distants : ${peers.joinToString(" • ")}"
        }
    }

    private fun editRelayLimit() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            setText(String.format(Locale.US, "%.1f", NexusSettings.relayLimitMbps(this@MainActivity)))
            hint = "Mb/s"
        }
        AlertDialog.Builder(this)
            .setTitle("Limite de débit de transit")
            .setMessage("Cette limite s’applique au trafic relayé en arrière-plan.")
            .setView(input)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                val value = input.text.toString().replace(',', '.').toDoubleOrNull()
                if (value != null) NexusSettings.setRelayLimitMbps(this, value)
                refreshResources()
            }.show()
    }

    private fun editRelayQuota() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setText((NexusSettings.relayDailyLimitBytes(this@MainActivity) / (1024L * 1024L)).toString())
            hint = "Mo / jour"
        }
        AlertDialog.Builder(this)
            .setTitle("Quota journalier de transit")
            .setMessage("0 = sans quota journalier. Le contrôle de débit et la batterie restent actifs.")
            .setView(input)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                val value = input.text.toString().toLongOrNull()
                if (value != null) NexusSettings.setRelayDailyLimitMb(this, value)
                refreshResources()
            }.show()
    }

    private fun connectAutomatically() {
        startNodeService()
        startDiscovery()
        startVpnConsentFlow()
        updateButtons()
        Toast.makeText(this, "NEXUS cherche un vrai chemin. Rien n’est déclaré disponible sans vérification.", Toast.LENGTH_LONG).show()
    }

    private fun editReplicationFactor() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setText(NexusSettings.replicationFactor(this@MainActivity).toString())
            hint = "1 à 8 pairs"
        }
        AlertDialog.Builder(this)
            .setTitle("Facteur de réplication")
            .setMessage("NEXUS réplique automatiquement les contenus épinglés vers ce nombre maximum de pairs relais autorisés.")
            .setView(input)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                input.text.toString().toIntOrNull()?.let { NexusSettings.setReplicationFactor(this, it) }
                refreshResources()
            }.show()
    }

    private fun choosePeerForApk() {
        val peers = peerRows.filter { it.host.isNotBlank() }
        if (peers.isEmpty()) { Toast.makeText(this, "Aucun nœud NEXUS joignable.", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Envoyer NEXUS à")
            .setItems(peers.map { it.name }.toTypedArray()) { _, which ->
                val peer = peers[which]
                Toast.makeText(this, "Transfert APK vers ${peer.name}…", Toast.LENGTH_SHORT).show()
                thread(start=true,name="nexus-apk-send") {
                    val result=NexusAppTransferClient.send(this, peer.host)
                    runOnUiThread { Toast.makeText(this, result.fold({ "APK reçu par ${peer.name}" }, { "Échec : ${it.message ?: "transfert"}" }), Toast.LENGTH_LONG).show() }
                }
            }.show()
    }

    private fun chooseContentFile() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 812)
    }

    private fun importContent(uri: android.net.Uri) {
        thread(start=true,name="nexus-content-import") {
            val temp=File(cacheDir,"nexus-import-${System.nanoTime()}")
            runCatching { contentResolver.openInputStream(uri).use { input -> requireNotNull(input); temp.outputStream().use { out -> input.copyTo(out) } }; val name=queryDisplayName(uri) ?: "contenu"; val manifest=NexusContentStore.putFile(this,temp,name); val peers=peerRows.filter { it.host.isNotBlank() && it.relay }; peers.take(3).forEach { NexusContentClient.push(it.host,this,manifest.hash) }; temp.delete(); manifest }
                .onSuccess { m -> runOnUiThread { refreshResources(); Toast.makeText(this,"Contenu ${m.hash.take(12)}… stocké localement et réplication proposée aux pairs.",Toast.LENGTH_LONG).show() } }
                .onFailure { e -> temp.delete(); runOnUiThread { Toast.makeText(this,"Import impossible : ${e.message ?: "erreur"}",Toast.LENGTH_LONG).show() } }
        }
    }

    private fun queryDisplayName(uri: android.net.Uri): String? = contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

    private fun testGateway() {
        if (!gatewayEnabled) {
            Toast.makeText(this, "Active d’abord la passerelle.", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Test Internet réel…", Toast.LENGTH_SHORT).show()
        thread(start = true, name = "nexus-gateway-test") {
            val result = GatewayTester.test(this)
            runOnUiThread { Toast.makeText(this, result.detail, Toast.LENGTH_LONG).show() }
        }
    }

    private fun testPeers() {
        if (peerRows.isEmpty()) {
            Toast.makeText(this, "Aucun nœud à tester.", Toast.LENGTH_SHORT).show()
            return
        }
        val snapshot = peerRows.toList()
        thread(start = true, name = "nexus-peer-test") {
            val results = snapshot.map { peer ->
                runCatching {
                    val result = NxpProtocol.measurePeer(peer.host, peer.port) { NetworkKeyManager.accepted(this) }.getOrThrow()
                    discovery.updateCapabilities(
                        peer.name, peer.gateway, peer.relay, peer.gatewayDistance, peer.gatewayPath,
                        result.latencyMs, result.packetLossPct, peer.bandwidthMbps, success = true
                    )
                    "${peer.name}: ${String.format(Locale.US, "%.1f", result.latencyMs)} ms • perte ${String.format(Locale.US, "%.1f", result.packetLossPct)}%"
                }.getOrElse { "${peer.name}: échec (${it.message ?: "erreur réseau"})" }
            }
            runOnUiThread { peersText.text = results.joinToString("\n") }
        }
    }

    private fun measurePeerBandwidth() {
        if (peerRows.isEmpty()) {
            Toast.makeText(this, "Aucun nœud à mesurer.", Toast.LENGTH_SHORT).show()
            return
        }
        val snapshot = peerRows.toList()
        Toast.makeText(this, "Mesure réelle du débit (256 KiB par sens et par nœud)…", Toast.LENGTH_SHORT).show()
        thread(start = true, name = "nexus-bandwidth-test") {
            val results = snapshot.map { peer ->
                runCatching {
                    val result = NxpProtocol.measureBandwidth(peer.host, peer.port, { NetworkKeyManager.accepted(this) }).getOrThrow()
                    peer.bandwidthMbps = (result.downloadMbps + result.uploadMbps) / 2.0
                    discovery.updateCapabilities(
                        peer.name, peer.gateway, peer.relay, peer.gatewayDistance, peer.gatewayPath, peer.latencyMs,
                        peer.packetLossPct, peer.bandwidthMbps, success = true
                    )
                    "${peer.name}: ↓ ${String.format(Locale.US, "%.1f", result.downloadMbps)} Mb/s • ↑ ${String.format(Locale.US, "%.1f", result.uploadMbps)} Mb/s"
                }.getOrElse { "${peer.name}: débit indisponible (${it.message ?: "erreur réseau"})" }
            }
            runOnUiThread { updatePeersText(); Toast.makeText(this, results.joinToString("\n"), Toast.LENGTH_LONG).show() }
        }
    }

    private fun updateVpnButton() {
        if (!::vpnButton.isInitialized) return
        if (NexusVpnRegistry.isActive()) {
            vpnButton.text = "Arrêter le TUN NEXUS"
            vpnButton.setOnClickListener { stopVpnService() }
        } else {
            vpnButton.text = "Démarrer le TUN NEXUS"
            vpnButton.setOnClickListener { startVpnConsentFlow() }
        }
    }

    private fun startVpnConsentFlow() {
        val prepare = VpnService.prepare(this)
        if (prepare != null) {
            startActivityForResult(prepare, 811)
        } else {
            startVpnService()
        }
    }

    private fun startVpnService() {
        val intent = Intent(this, NexusVpnService::class.java).apply { action = NexusConfig.ACTION_VPN }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        if (::vpnButton.isInitialized) {
            vpnButton.text = "Arrêter le TUN NEXUS"
            vpnButton.setOnClickListener { stopVpnService() }
        }
    }

    private fun stopVpnService() {
        startService(Intent(this, NexusVpnService::class.java).apply { action = NexusConfig.ACTION_VPN_STOP })
        if (::vpnButton.isInitialized) {
            vpnButton.text = "Démarrer le TUN NEXUS"
            vpnButton.setOnClickListener { startVpnConsentFlow() }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 811 && resultCode == RESULT_OK) startVpnService()
        if (requestCode == 814) finishPermissionsGate()
        if (requestCode == 812 && resultCode == RESULT_OK && data?.data != null) importContent(data.data!!)
        if (requestCode == 813 && resultCode == RESULT_OK && data?.data != null) processErasureFile(data.data!!)
    }

    private fun permissionsDone() = prefs.getBoolean("permissions_explained", false)

    private fun continueToApp() { if (permissionsDone()) showApp() else showPermissionsGate() }

    private fun runtimePermissions(): List<String> = buildList {
        if (Build.VERSION.SDK_INT >= 33) {
            add(Manifest.permission.NEARBY_WIFI_DEVICES)
            // NEXUS presence discovery uses a coarse geographic cell. Android 13+
            // still requires an explicit location permission for this real feature.
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            add(Manifest.permission.BLUETOOTH_SCAN)
            add(Manifest.permission.BLUETOOTH_CONNECT)
            add(Manifest.permission.BLUETOOTH_ADVERTISE)
        }
    }

    private fun missingRuntimePermissions() = runtimePermissions().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

    private fun permissionExplanations(): List<Pair<String, String>> = buildList {
        if (Build.VERSION.SDK_INT >= 33) {
            add("Appareils Wi-Fi à proximité" to "Découvrir et connecter les téléphones proches en Wi-Fi Direct. Elle n'est pas utilisée pour obtenir ta position.")
            add("Notifications" to "Afficher la notification permanente qu'Android exige tant que le service NEXUS tourne en arrière-plan.")
        } else {
            add("Localisation" to "Android l'exige jusqu'à sa version 12L pour rechercher les appareils Wi-Fi proches. NEXUS ne l'utilise pas pour te localiser.")
        }
        if (Build.VERSION.SDK_INT >= 31) {
            add("Appareils Bluetooth à proximité" to "Rechercher, annoncer et se connecter aux appareils NEXUS proches par Bluetooth.")
        }
        add("VPN Android" to "Android affichera sa propre fenêtre de confirmation. Accepter ne démarre aucun VPN : le TUN NEXUS ne démarre que si tu le demandes.")
        add("Autorisations automatiques" to "Internet, état du réseau, état et changement du Wi-Fi et du réseau, service au premier plan. Accordées à l'installation, sans fenêtre, pour la connexion réseau et le maintien du service.")
    }

    private fun showPermissionsGate() {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(28),dp(32),dp(28),dp(32)); setBackgroundColor(bg) }
        val scroll=ScrollView(this); scroll.addView(root); setContentView(scroll)
        root.addView(label("Autorisations",30,true,text))
        root.addView(label("NEXUS demande ici, une seule fois, les autorisations dont il a besoin, avec la raison de chacune. Tu peux refuser : les fonctions qui en dépendent seront limitées, et tu pourras les accorder plus tard dans les réglages Android.",16,false,secondary))
        root.addView(space(20))
        permissionExplanations().forEach { (t,d) -> root.addView(panel(t,d)) }
        root.addView(space(12))
        root.addView(primaryButton("Continuer et autoriser") { requestStartupPermissions() })
        root.addView(secondaryButton("Continuer sans autoriser") { finishPermissionsGate() })
    }

    private fun requestStartupPermissions() {
        val missing = missingRuntimePermissions()
        if (missing.isEmpty()) askVpnAuthorization() else requestPermissions(missing.toTypedArray(), 700)
    }

    private fun askVpnAuthorization() {
        val prepare = VpnService.prepare(this)
        if (prepare == null) { finishPermissionsGate(); return }
        AlertDialog.Builder(this).setTitle("Autorisation VPN")
            .setMessage("Android va demander la permission de créer une interface VPN locale. NEXUS l'utilise uniquement pour le TUN NEXUS, que tu démarres toi-même. Rien n'est démarré en acceptant.")
            .setCancelable(false)
            .setPositiveButton("Continuer") { _, _ -> startActivityForResult(prepare, 814) }
            .setNegativeButton("Plus tard") { _, _ -> finishPermissionsGate() }
            .show()
    }

    private fun finishPermissionsGate() {
        prefs.edit().putBoolean("permissions_explained", true).apply()
        showApp()
        p2p.start()
        refreshNetwork()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 700) askVpnAuthorization()
        if (requestCode == 702) {
            val scope = pendingPresenceScope
            pendingPresenceScope = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && scope != null) runPresenceSearch(scope)
            else Toast.makeText(this, "La recherche par distance a besoin de la localisation approximative du téléphone.", Toast.LENGTH_LONG).show()
        }
    }

    private fun label(text: String, size: Int, bold: Boolean, color: Int): TextView =
        label(text, size, bold).apply { setTextColor(color) }

    private fun label(text: String, size: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(0xFF0B0D12.toInt())
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        setPadding(0, dp(4), 0, dp(8))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
