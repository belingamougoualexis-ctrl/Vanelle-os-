package com.nexus.network

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * Didacticiel guidé réutilisable. Les cibles sont de vraies vues de l'application ;
 * aucune interface factice n'est créée.
 *
 * Forme de la zone éclairée : cercle pour une cible compacte (icône, onglet), rectangle arrondi
 * pour une cible large (bouton pleine largeur, carte), afin que le halo épouse toujours l'élément.
 */
class GuidedTour(
    private val activity: Activity,
    private val host: ViewGroup,
    private val steps: List<Step>,
    /** Emplacement de la mascotte : une vue (ImageView, LottieAnimationView...) sans changer le reste de l'API. */
    private val mascotFactory: ((Context) -> View)? = null
) {
    /**
     * @param runAction si vrai, toucher la zone éclairée exécute aussi l'action réelle de la cible
     * (utile pour une navigation). Faux par défaut : le guide ne déclenche jamais une action à l'insu de l'utilisateur.
     */
    data class Step(
        val target: View,
        val title: String,
        val message: String,
        val mascotName: String = "Conseil NEXUS",
        val runAction: Boolean = false
    )

    companion object {
        private const val PREFS = "nexus_onboarding"
        private const val COMPLETED = "guided_tour_completed"
        private const val SKIPPED = "guided_tour_skipped"

        fun shouldShow(context: Context): Boolean {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return !p.getBoolean(COMPLETED, false) && !p.getBoolean(SKIPPED, false)
        }

        fun reset(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove(COMPLETED).remove(SKIPPED).apply()
        }
    }

    // Palette alignée sur l'application : fond clair, texte 111827, bleu 2563EB.
    private val cardColor = Color.WHITE
    private val borderColor = Color.rgb(229, 231, 235)
    private val textPrimary = Color.rgb(17, 24, 39)
    private val textSecondary = Color.rgb(71, 85, 105)
    private val textMuted = Color.rgb(102, 112, 133)
    private val accent = Color.rgb(37, 99, 235)
    private val haloColor = Color.rgb(147, 197, 253)

    private lateinit var overlay: FrameLayout
    private lateinit var card: View
    private lateinit var tail: View
    private lateinit var nextButton: Button
    private lateinit var spotlight: SpotlightView
    private lateinit var title: TextView
    private lateinit var message: TextView
    private lateinit var role: TextView
    private lateinit var counter: TextView
    private lateinit var progress: LinearLayout
    private var index = 0
    private var currentRect = RectF()
    private var currentCorner = 0f
    private var running = false

    fun isRunning(): Boolean = running

    fun start() {
        if (running || steps.isEmpty() || !shouldShow(activity)) return
        running = true
        overlay = FrameLayout(activity).apply { setBackgroundColor(Color.TRANSPARENT) }
        spotlight = SpotlightView(activity).also { overlay.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        card = buildCard()
        val cardWidth = min(dp(340), activity.resources.displayMetrics.widthPixels - dp(24))
        overlay.addView(card, FrameLayout.LayoutParams(cardWidth, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        })
        // Pointe de la bulle, orientée vers l'élément ciblé.
        tail = View(activity).apply {
            background = GradientDrawable().apply { setColor(cardColor); cornerRadius = dp(3).toFloat() }
            rotation = 45f
            visibility = View.INVISIBLE
        }
        overlay.addView(tail, FrameLayout.LayoutParams(dp(16), dp(16)).apply { gravity = Gravity.TOP or Gravity.START })
        host.addView(overlay, ViewGroup.LayoutParams(-1, -1))
        overlay.post { showStep(0, false) }
    }

    private fun buildCard(): View {
        val card = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(12))
            background = GradientDrawable().apply {
                setColor(cardColor); cornerRadius = dp(20).toFloat(); setStroke(dp(1), borderColor)
            }
            elevation = dp(16).toFloat()
        }
        val head = LinearLayout(activity).apply { gravity = Gravity.CENTER_VERTICAL }
        val mascot: View = mascotFactory?.invoke(activity) ?: ImageView(activity).apply {
            setImageResource(com.nexus.network.R.drawable.nexus_mascot)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Mascotte NEXUS"
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(14).toFloat())
                }
            }
            background = GradientDrawable().apply { setColor(Color.rgb(2, 6, 23)); cornerRadius = dp(14).toFloat() }
        }
        head.addView(mascot, LinearLayout.LayoutParams(dp(56), dp(56)))
        val identity = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        role = TextView(activity).apply {
            textSize = 11f; setTextColor(accent); letterSpacing = 0.1f; typeface = Typeface.DEFAULT_BOLD
        }
        identity.addView(role)
        title = TextView(activity).apply {
            textSize = 18f; setTextColor(textPrimary); typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(2), 0, 0)
        }
        identity.addView(title)
        head.addView(identity, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14) })
        card.addView(head)
        message = TextView(activity).apply {
            textSize = 14f; setTextColor(textSecondary); setLineSpacing(0f, 1.25f); setPadding(0, dp(14), 0, dp(14))
        }
        card.addView(message)
        progress = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        card.addView(progress, LinearLayout.LayoutParams(-1, dp(4)))
        val footer = LinearLayout(activity).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        counter = TextView(activity).apply { textSize = 12f; setTextColor(textMuted) }
        footer.addView(counter, LinearLayout.LayoutParams(0, -2, 1f))
        val skip = Button(activity).apply {
            text = "Passer"; isAllCaps = false; textSize = 14f; setTextColor(textMuted); background = null
            minWidth = 0; minimumWidth = 0; setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener { finish(skipped = true) }
        }
        nextButton = Button(activity).apply {
            isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            minWidth = 0; minimumWidth = 0; setPadding(dp(22), 0, dp(22), 0)
            background = GradientDrawable().apply { setColor(accent); cornerRadius = dp(10).toFloat() }
            setOnClickListener { nextStep() }
        }
        footer.addView(skip, LinearLayout.LayoutParams(-2, dp(46)))
        footer.addView(nextButton, LinearLayout.LayoutParams(-2, dp(46)).apply { leftMargin = dp(6) })
        card.addView(footer, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        return card
    }

    private fun updateProgress() {
        progress.removeAllViews()
        for (i in steps.indices) {
            val seg = View(activity).apply {
                background = GradientDrawable().apply {
                    setColor(if (i <= index) accent else borderColor); cornerRadius = dp(2).toFloat()
                }
            }
            progress.addView(seg, LinearLayout.LayoutParams(0, -1, 1f).apply { if (i > 0) leftMargin = dp(4) })
        }
    }

    private fun showStep(newIndex: Int, animate: Boolean, attempt: Int = 0) {
        index = newIndex
        val step = steps[index]
        val target = step.target
        if (!target.isShown || target.width == 0 || target.height == 0) {
            // Cible absente (écran reconstruit) : étape suivante au lieu d'une boucle infinie.
            if (attempt >= 25) {
                if (index >= steps.lastIndex) finish(false) else showStep(index + 1, animate, 0)
                return
            }
            overlay.postDelayed({ showStep(newIndex, animate, attempt + 1) }, 80)
            return
        }
        val (rect, corner) = shapeFor(target)
        if (animate && !currentRect.isEmpty) {
            val fromRect = RectF(currentRect); val fromCorner = currentCorner
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 320L; interpolator = DecelerateInterpolator()
                addUpdateListener { a ->
                    val t = a.animatedValue as Float
                    currentRect = lerp(fromRect, rect, t)
                    currentCorner = fromCorner + (corner - fromCorner) * t
                    spotlight.setTarget(currentRect, currentCorner)
                }
                start()
            }
        } else {
            currentRect = rect; currentCorner = corner
            spotlight.setTarget(rect, corner)
        }
        title.text = step.title
        role.text = step.mascotName.uppercase()
        message.text = step.message
        counter.text = "Étape ${index + 1} sur ${steps.size}"
        updateProgress()
        nextButton.text = if (index >= steps.lastIndex) "J'ai compris" else "Suivant"
        positionCard(rect)
    }

    private fun positionCard(rect: RectF) {
        card.post {
            val h = card.height; val w = card.width
            val margin = dp(18)
            val below = rect.bottom + margin + h <= overlay.height
            val top = if (below) rect.bottom + margin else max(dp(16).toFloat(), rect.top - h - margin)
            val lp = card.layoutParams as FrameLayout.LayoutParams
            lp.topMargin = top.toInt()
            card.layoutParams = lp
            val overlaps = top < rect.bottom && top + h > rect.top
            val cardLeft = (overlay.width - w) / 2f
            val tailSize = dp(16)
            val tx = (rect.centerX() - tailSize / 2f).coerceIn(cardLeft + dp(28), cardLeft + w - dp(28) - tailSize)
            val ty = if (below) top - tailSize / 2f else top + h - tailSize / 2f
            val tlp = tail.layoutParams as FrameLayout.LayoutParams
            tlp.leftMargin = tx.toInt(); tlp.topMargin = ty.toInt()
            tail.layoutParams = tlp
            tail.visibility = if (overlaps) View.INVISIBLE else View.VISIBLE
        }
    }

    private fun nextStep() {
        if (index >= steps.lastIndex) finish(false) else showStep(index + 1, true)
    }

    private fun finish(skipped: Boolean) {
        if (!running) return
        activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(if (skipped) SKIPPED else COMPLETED, true).apply()
        (overlay.parent as? ViewGroup)?.removeView(overlay)
        running = false
    }

    /** Cercle pour une cible compacte, rectangle arrondi pour une cible large. */
    private fun shapeFor(view: View): Pair<RectF, Float> {
        val t = IntArray(2); val r = IntArray(2)
        view.getLocationOnScreen(t); overlay.getLocationOnScreen(r)
        val left = (t[0] - r[0]).toFloat(); val top = (t[1] - r[1]).toFloat()
        val w = view.width.toFloat(); val h = view.height.toFloat()
        val pad = dp(8).toFloat()
        return if (w / h <= 2.2f) {
            val side = max(w, h) + 2 * pad
            val cx = left + w / 2f; val cy = top + h / 2f
            RectF(cx - side / 2f, cy - side / 2f, cx + side / 2f, cy + side / 2f) to side / 2f
        } else {
            RectF(left - pad, top - pad, left + w + pad, top + h + pad) to dp(16).toFloat()
        }
    }

    private fun lerp(a: RectF, b: RectF, t: Float) = RectF(
        a.left + (b.left - a.left) * t, a.top + (b.top - a.top) * t,
        a.right + (b.right - a.right) * t, a.bottom + (b.bottom - a.bottom) * t
    )

    private fun dp(v: Int) = (v * activity.resources.displayMetrics.density).toInt()

    private inner class SpotlightView(context: Context) : View(context) {
        private val dim = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(178, 0, 0, 0) }
        private val clear = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = android.graphics.PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(3).toFloat(); color = haloColor }
        private val pulse = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(3).toFloat(); color = haloColor }
        private var target = RectF()
        private var corner = 0f
        private var phase = 0f
        private val tick = object : Runnable { override fun run() { phase = (phase + .025f) % 1f; invalidate(); postDelayed(this, 32) } }
        init { setLayerType(LAYER_TYPE_SOFTWARE, null) }
        override fun onAttachedToWindow() { super.onAttachedToWindow(); removeCallbacks(tick); post(tick) }
        override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }
        fun setTarget(rect: RectF, cornerRadius: Float) { target = RectF(rect); corner = cornerRadius; invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
            if (target.isEmpty) return
            canvas.drawRoundRect(target, corner, corner, clear)
            canvas.drawRoundRect(target, corner, corner, ring)
            val grow = dp(6) + dp(10) * phase
            val outer = RectF(target).apply { inset(-grow, -grow) }
            pulse.alpha = (200 * (1f - phase)).toInt().coerceIn(0, 255)
            canvas.drawRoundRect(outer, corner + grow, corner + grow, pulse)
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_UP && target.contains(event.x, event.y)) {
                val step = steps[index]
                if (step.runAction && step.target.hasOnClickListeners()) step.target.performClick()
                nextStep()
                performClick()
            }
            return true
        }
        override fun performClick(): Boolean { super.performClick(); return true }
    }
}
