package com.nexus.network

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.concurrent.Executors

object NexusAppTransfer {
    fun localApk(context: Context): File {
        val source = File(context.applicationInfo.sourceDir)
        val dir = File(context.cacheDir, "nexus-share").apply { mkdirs() }
        val apk = File(dir, "NEXUS-${NexusConfig.VERSION}.apk")
        if (!apk.exists() || apk.length() != source.length()) source.copyTo(apk, overwrite=true)
        return apk
    }

    fun shareIntent(context: Context): Intent {
        val apk = localApk(context)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", apk)
        return Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun openInstaller(context: Context, apk: File): Boolean {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", apk)
        return runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            true
        }.getOrDefault(false)
    }
}

class NexusAppTransferServer(private val context: Context) {
    private val pool=Executors.newCachedThreadPool{r->Thread(r,"nexus-app-share-${System.nanoTime()}").apply{isDaemon=true}}
    @Volatile private var running=false
    private var server:ServerSocket?=null

    fun start(){if(running)return;running=true;pool.execute{runCatching{ServerSocket().use{s->s.reuseAddress=true;s.bind(InetSocketAddress("0.0.0.0",NexusConfig.APP_SHARE_PORT));server=s;while(running)pool.execute{handle(s.accept())}}}}}
    fun stop(){running=false;runCatching{server?.close()};server=null;pool.shutdownNow()}

    private fun handle(socket:Socket){socket.use{s->s.soTimeout=30_000;val input=BufferedInputStream(s.getInputStream());val out=BufferedOutputStream(s.getOutputStream());val hello=readLine(input)?:return;val f=fields(hello);if(!hello.startsWith("NEXUS-APP/1 HELLO"))return;val nonce=f["nonce"]?:return;val node=NexusCrypto.decode(f["node"]?:return);val key=NetworkKeyManager.accepted(context).firstOrNull{k->NexusCrypto.constantTimeEquals(NexusCrypto.hmacHex(k,"v=1&type=hello&node=$node&nonce=$nonce"),f["auth"].orEmpty())}?:return;line(out,"NEXUS-APP/1 OK node=${NexusCrypto.encode(NexusIdentity.nodeId(context))} nonce=$nonce auth=${NexusCrypto.hmacHex(key,"v=1&type=ok&node=${NexusIdentity.nodeId(context)}&nonce=$nonce")}");val command=readLine(input)?:return;if(!command.startsWith("SEND "))return;val p=command.split(' ');if(p.size!=4)return;val size=p[1].toLongOrNull()?.takeIf{it in 1..200L*1024*1024}?:return;val hash=p[2];val name=NexusCrypto.decode(p[3]);if(!hash.matches(Regex("[0-9a-f]{64}")))return;val dir=File(context.getExternalFilesDir("received"),"NEXUS").apply{mkdirs()};val temp=File(dir,".${System.nanoTime()}.part");temp.outputStream().use{fileOut->val buffer=ByteArray(64*1024);var remaining=size;while(remaining>0){val n=input.read(buffer,0,minOf(buffer.size,remaining.toInt()));if(n<0)return;fileOut.write(buffer,0,n);remaining-=n}};if(sha256(temp)!=hash){temp.delete();line(out,"REFUSED bad-hash");return};val safe=name.replace(Regex("[^a-zA-Z0-9._-]"),"_").take(120);val dest=File(dir,"${System.currentTimeMillis()}-$safe");temp.renameTo(dest);line(out,"RECEIVED ${NexusCrypto.encode(dest.name)}")} }
    private fun sha256(f:File):String{val d=MessageDigest.getInstance("SHA-256");f.inputStream().use{i->val b=ByteArray(64*1024);while(true){val n=i.read(b);if(n<0)break;if(n>0)d.update(b,0,n)}};return d.digest().joinToString(""){ "%02x".format(it.toInt() and 0xff)}}
    private fun fields(l:String):Map<String,String> = l.split(' ').drop(2).mapNotNull{t->val i=t.indexOf('=');if(i>0)t.substring(0,i) to t.substring(i+1) else null}.toMap()
    private fun line(o:BufferedOutputStream,v:String){o.write(v.toByteArray(Charsets.US_ASCII));o.write('\n'.code);o.flush()}
    private fun readLine(i:BufferedInputStream):String?{val b=ByteArray(8192);var n=0;while(n<b.size){val x=i.read();if(x<0)return if(n==0)null else String(b,0,n,Charsets.US_ASCII);if(x=='\n'.code)return String(b,0,n,Charsets.US_ASCII);if(x!='\r'.code)b[n++]=x.toByte()};error("Ligne APK trop longue")}
}

object NexusAppTransferClient {
    fun send(context: Context, host: String, apk: File = NexusAppTransfer.localApk(context)): Result<Boolean> = runCatching {
        val socket=Socket();check(NexusVpnRegistry.protect(socket));socket.connect(InetSocketAddress(host,NexusConfig.APP_SHARE_PORT),10_000);socket.use{s->s.soTimeout=30_000;val input=BufferedInputStream(s.getInputStream());val out=BufferedOutputStream(s.getOutputStream());val nonce=NexusCrypto.nonce(18);val auth=NexusCrypto.hmacHex(NexusIdentity.networkKey(context),"v=1&type=hello&node=${NexusIdentity.nodeId(context)}&nonce=$nonce");line(out,"NEXUS-APP/1 HELLO v=1 node=${NexusCrypto.encode(NexusIdentity.nodeId(context))} nonce=$nonce auth=$auth");val ok=readLine(input)?:error("Réponse APK absente");check(ok.startsWith("NEXUS-APP/1 OK"));val hash=sha256(apk);line(out,"SEND ${apk.length()} $hash ${NexusCrypto.encode(apk.name)}");apk.inputStream().use{fileIn->val b=ByteArray(64*1024);while(true){val n=fileIn.read(b);if(n<0)break;if(n>0){out.write(b,0,n);out.flush()}}};(readLine(input)?:"").startsWith("RECEIVED")
    }
    private fun sha256(f:File):String{val d=MessageDigest.getInstance("SHA-256");f.inputStream().use{i->val b=ByteArray(64*1024);while(true){val n=i.read(b);if(n<0)break;if(n>0)d.update(b,0,n)}};return d.digest().joinToString(""){ "%02x".format(it.toInt() and 0xff)}}
    private fun line(o:BufferedOutputStream,v:String){o.write(v.toByteArray(Charsets.US_ASCII));o.write('\n'.code);o.flush()}
    private fun readLine(i:BufferedInputStream):String?{val b=ByteArray(8192);var n=0;while(n<b.size){val x=i.read();if(x<0)return if(n==0)null else String(b,0,n,Charsets.US_ASCII);if(x=='\n'.code)return String(b,0,n,Charsets.US_ASCII);if(x!='\r'.code)b[n++]=x.toByte()};error("Ligne APK trop longue")}
}
