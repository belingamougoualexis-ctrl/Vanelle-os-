# NEXUS — Politique de confidentialité

Version de l'application : 2.2.5

## Données de compte local

Cette version peut créer un compte local sur l'appareil. Le nom d'utilisateur, l'adresse e-mail saisie et l'empreinte du mot de passe sont conservés dans le stockage local de l'application pour permettre l'accès local à l'interface.

## Identité NEXUS

NEXUS utilise une identité cryptographique de nœud. Cette identité sert au routage, à l'authentification des pairs et à la signature des informations publiées par le nœud.

## Données de réseau

Pour fonctionner, NEXUS peut lire l'état des interfaces réseau et les informations nécessaires aux connexions réseau autorisées par Android. NEXUS ne doit pas inventer des caractéristiques de réseau qui ne sont pas mesurées ou fournies par le système.

## Données répliquées

Lorsque l'utilisateur active la réplication, les bases et contenus sélectionnés peuvent être transmis à des pairs compatibles et autorisés. Les messages distribués peuvent également être conservés localement sur le nœud destinataire.

## Visibilité et localisation (découverte de nœuds)

La visibilité dans les recherches NEXUS est désactivée par défaut. Tant que tu ne l'actives pas, aucune fiche de présence n'est publiée.

Si tu l'actives, l'appareil publie une fiche signée contenant : son adresse et son identifiant NEXUS, sa clé publique, son nom NEXUS, un code pays à deux lettres (réseau ou langue du système), une zone géographique approximative et les adresses IP publiques de l'appareil (huit au maximum). La fiche expire automatiquement.

La zone approximative est une case de grille d'environ 5 km et une case d'environ 28 km de côté ; la position exacte n'est ni publiée ni conservée. Elle est calculée à partir de l'autorisation de localisation Android, demandée pour une recherche à 10 ou 100 km ou pour publier ta zone. Si tu refuses cette autorisation, la recherche par distance et la zone publiée ne sont pas disponibles.

Les recherches « Mon pays » et « Monde » n'utilisent pas ta position.

## Analytique et publicité

Cette version ne dépend d'aucun SDK d'analytique ou de publicité pour son fonctionnement.

## Sécurité

Les services NEXUS utilisent une authentification réseau et un canal chiffré. La sécurité dépend également de la configuration de l'appareil, d'Android, des réseaux utilisés et des clés présentes sur les nœuds.

## Conservation et suppression

Les données locales sont supprimées selon les actions de l'utilisateur ou les mécanismes de nettoyage propres à chaque service. Les copies répliquées sur d'autres nœuds doivent être gérées sur ces nœuds conformément aux politiques du réseau.
