# NEXUS 2.2.5 — audit statique (session du 29 septembre 2026)

Environnement : pas de compilateur Kotlin, pas de Gradle, pas de SDK Android, pas d'émulateur, réseau sortant désactivé. Aucun appareil physique.

## Réellement exécuté
- Contrôle statique du projet (`tools/nexus-v1_2-static-qa.sh`) : OK, 84 fichiers Kotlin et 6 XML, avant et après corrections.
- Analyse syntaxique de tous les XML de `app/src/main` : 6 fichiers valides.
- Recherche d'emojis dans les sources Kotlin/XML : 0.
- Recherche de marqueurs de simulation (simulat, fake, dummy, placeholder, mock) : deux commentaires qui affirment le contraire ("rather than faked", "does not fake"), aucun code concerné.
- Recherche de journaux (Log.*, println, printStackTrace) et de secrets codés en dur : aucun.
- Présence de chaque script de la CI dans `tools/` : 18 sur 18.

## Corrigé (vérifié par lecture du diff, non compilé)
1. Onglet Services : le bouton "Réparer automatiquement" apparaissait deux fois. Un seul conservé.
2. Build : le plugin `org.jetbrains.kotlin.android` est appliqué avec AGP 9.3.1. Depuis AGP 9.0 c'est une erreur de configuration (Kotlin intégré). Plugin retiré des deux fichiers Gradle, bloc `kotlinOptions` retiré (`compileOptions` reste à 17).
3. Build : coordonnée invalide `androidx.test:ext:junit:1.3.0` remplacée par `androidx.test.ext:junit:1.3.0` ; le bloc `dependencies` était imbriqué dans `android {}`, déplacé au niveau du module.
4. Confidentialité : `PRIVACY.md` (version 2.0.0) ne mentionnait ni localisation ni fiche de présence. Section ajoutée d'après le code de `NexusPresence.kt`, version passée à 2.2.5.
5. Interface : le texte de la fenêtre "Nœuds NEXUS autour de toi" indique maintenant ce que la fiche publiée contient (dont les adresses IP publiques).
6. Nettoyage : dossier vide `res/mipmap-hdpi` supprimé ; `TEST-REPORT-2.2.5.md` (titre 2.2.4, tests non rejoués) renommé `TEST-REPORT-2.2.4-reprise.md`.

## Non exécutable ici (BLOCKED)
- Build debug/release, APK, signature.
- Les 17 autres auto-tests `tools/*.sh` (compilation Kotlin requise).
- Tests instrumentés `androidTest`, parcours utilisateur, persistance après redémarrage, cas extrêmes, performances, compatibilité d'écrans.
- Existence des versions AGP 9.3.1, Gradle 9.5.0, `androidx.core:core-ktx:1.18.0`, compileSdk 37.

## Restant à décider ou corriger
- Environ 25 fonctions privées de `MainActivity` sans appelant (trace d'adresse, nom .mesh, boîte hors ligne, test d'IP publique, calcul distant, erasure coding, etc.). Le README les présente comme exposées dans l'interface : soit les rebrancher, soit les supprimer avec le texte du README.
- `GuidedTourBuilder.kt` : aucun appelant.
- `passwordHash` : sel PBKDF2 déterministe dérivé de l'e-mail, pas aléatoire par compte.
- Version release : `isMinifyEnabled = false`, aucune configuration de signature.
- Serveurs SOCKS5, contenu et relais liés à 0.0.0.0 (passerelle désactivée par défaut ; authentification par mot de passe ou HMAC lue dans le code, non testée).
- `docs/archive` (40 fichiers) et `tools/test-stubs` : à archiver hors du dépôt livré si voulu.
