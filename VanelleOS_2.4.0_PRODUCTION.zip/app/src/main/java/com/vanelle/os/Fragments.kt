package com.vanelle.os
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.Toast
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.content.ClipData
import android.content.ClipboardManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.webkit.WebView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
class MascotFragment:Fragment(){
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val root=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(28,28,28,28); setBackgroundColor(UiKit.WHITE)}

        // Grande prévisualisation
        val hero=ImageView(ctx).apply{
            layoutParams=LinearLayout.LayoutParams(-1,480).apply{bottomMargin=16}
            scaleType=ImageView.ScaleType.FIT_CENTER
            background=UiKit.card(ctx)
            adjustViewBounds=true
        }
        var sel=MascotManager.getSelected(ctx)
        fun refreshHero(){
            try{ hero.setImageResource(MascotManager.getDrawableId(ctx,sel)) }catch(_:Exception){}
        }
        refreshHero()

        // Nom personnalisé
        val nameTitle=TextView(ctx).apply{
            text="NOM DE TA MASCOTTE"
            setTextColor(UiKit.TEXT_MUTED); textSize=11f; letterSpacing=0.1f
            setPadding(4,8,0,8)
        }
        val nameRow=LinearLayout(ctx).apply{
            orientation=LinearLayout.HORIZONTAL
            setPadding(16,8,16,8)
            background=UiKit.card(ctx)
        }
        val nameEdit=EditText(ctx).apply{
            hint="Ex: Luna, Buddy, Pixel..."
            setText(MascotManager.getCustomName(ctx))
            setTextColor(UiKit.BLACK)
            setHintTextColor(UiKit.TEXT_MUTED)
            textSize=14f
            background=null
            layoutParams=LinearLayout.LayoutParams(0,-2,1f)
            maxLines=1
            isSingleLine=true
        }
        val saveBtn=Button(ctx).apply{
            text="Enregistrer"
            textSize=11f
            background=UiKit.pill(ctx)
            setTextColor(UiKit.BLACK)
            setOnClickListener{
                val n=nameEdit.text?.toString()?.trim() ?: ""
                MascotManager.setCustomName(ctx,n)
                Toast.makeText(ctx, if(n.isBlank()) "Nom réinitialisé" else "Nom enregistré : $n", Toast.LENGTH_SHORT).show()
            }
        }
        nameRow.addView(nameEdit); nameRow.addView(saveBtn)

        val nameHint=TextView(ctx).apply{
            text="Clique sur la mascotte flottante pour activer le micro."
            setTextColor(UiKit.TEXT_MUTED); textSize=10.5f
            setPadding(6,10,6,16)
        }

        // Grille horizontale de styles
        val styleTitle=TextView(ctx).apply{
            text="CHOISIS UN STYLE"
            setTextColor(UiKit.TEXT_MUTED); textSize=11f; letterSpacing=0.1f
            setPadding(4,4,0,10)
        }
        val scroll=HorizontalScrollView(ctx).apply{isHorizontalScrollBarEnabled=false}
        val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        for((id,name) in MascotManager.mascots){
            val card=LinearLayout(ctx).apply{
                orientation=LinearLayout.VERTICAL
                setPadding(10,10,10,10)
                // Plus haut pour voir le corps entier (pas de coupe)
                layoutParams=LinearLayout.LayoutParams(150,200).apply{setMargins(0,0,12,0)}
                background=if(id==sel) UiKit.selected(ctx) else UiKit.card(ctx)
            }
            val iv=ImageView(ctx).apply{
                try{ setImageResource(MascotManager.getDrawableId(ctx,id)) }catch(_:Exception){}
                scaleType=ImageView.ScaleType.FIT_CENTER
                layoutParams=LinearLayout.LayoutParams(-1,150)
                adjustViewBounds=true
            }
            val tv=TextView(ctx).apply{
                text=name
                setTextColor(if(id==sel) UiKit.BLACK else UiKit.BLACK)
                textSize=10f; letterSpacing=0.04f
                setPadding(0,8,0,0)
                gravity=android.view.Gravity.CENTER
                typeface=android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL)
            }
            card.addView(iv); card.addView(tv)
            card.setOnClickListener{
                sel=id
                MascotManager.setSelected(ctx,id)
                FloatingMascotButton.refreshIcon(ctx)
                refreshHero()
                for(j in 0 until row.childCount){
                    val ch=row.getChildAt(j) as LinearLayout
                    ch.background=UiKit.card(ctx)
                    (ch.getChildAt(1) as TextView).setTextColor(UiKit.BLACK)
                }
                card.background=UiKit.selected(ctx)
                tv.setTextColor(UiKit.BLACK)
            }
            row.addView(card)
        }
        scroll.addView(row)

        // Bouton test apparition
        val testBtn=Button(ctx).apply{
            text="Faire apparaître maintenant"
            textSize=12f
            background=UiKit.pill(ctx)
            setTextColor(UiKit.BLACK)
            layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=20}
            setOnClickListener{
                if(!DataDownloadService.isUsable(ctx)){
                    Toast.makeText(ctx,"L'IA doit être téléchargée et chargée en mémoire avant d'afficher la mascotte.",Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if(!OverlayHelper.canDraw(ctx)){
                    Toast.makeText(ctx,"Active d'abord « afficher par-dessus les apps » dans Configuration",Toast.LENGTH_LONG).show()
                    OverlayHelper.requestPermission(ctx)
                    return@setOnClickListener
                }
                val mid=MascotManager.getDrawableId(ctx,MascotManager.getSelected(ctx))
                val name=MascotManager.getDisplayName(ctx)
                OverlayHelper.showMascot(ctx,mid,"")
            }
        }

        root.addView(hero)
        root.addView(nameTitle)
        root.addView(nameRow)
        root.addView(nameHint)
        root.addView(styleTitle)
        root.addView(scroll)
        root.addView(testBtn)
        return root
    }
}
class ConfigFragment:Fragment(){
    private val refreshers=mutableListOf<()->Unit>()
    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        val msg = UserDataSnapshot.importFromUri(requireContext(), uri)
        Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show()
    }
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext(); refreshers.clear()
        val sv=ScrollView(ctx).apply{setBackgroundColor(UiKit.WHITE)}
        val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(32,40,32,40)}

        fun sectionTitle(t:String)=TextView(ctx).apply{text=t; setTextColor(UiKit.TEXT_MUTED); textSize=11f; letterSpacing=0.1f; setPadding(4,0,0,10)}
        fun spacer(h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,h)}

        // --- Assistant vocal ---
        col.addView(sectionTitle("ASSISTANT VOCAL"))
        val voiceInfo=TextView(ctx).apply{
            text="Clique sur la mascotte flottante pour activer le micro."
            setTextColor(UiKit.TEXT_MUTED); textSize=12f; setPadding(24,18,24,18); background=UiKit.card(ctx)
        }
        col.addView(voiceInfo); col.addView(spacer(28))

        // Diagnostic retire — ecran plus simple

        // --- Autorisations ---
        col.addView(sectionTitle("AUTORISATIONS"))

        // Aide commune : Android 13+ bloque certaines autorisations (accessibilité, SMS...)
        // pour les apps installées hors Play Store tant qu'on n'a pas explicitement débloqué
        // les « paramètres restreints » dans l'écran Infos de l'application.
        fun showRestrictedSettingsHelp(extra: String = "") {
            AlertDialog.Builder(ctx)
                .setTitle("Autorisation bloquée par Android")
                .setMessage(
                    "Depuis Android 13, une app installée hors Play Store (comme Vanelle OS) " +
                    "doit d'abord être débloquée manuellement avant de pouvoir accorder certaines " +
                    "autorisations sensibles.$extra\n\n" +
                    "Dans l'écran qui va s'ouvrir :\n" +
                    "1. Touche le menu ⋮ en haut à droite\n" +
                    "2. Choisis « Autoriser les paramètres restreints »\n" +
                    "3. Reviens ici et réessaie d'accorder l'autorisation"
                )
                .setPositiveButton("Ouvrir les réglages de l'appli") { _, _ ->
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply { data = Uri.fromParts("package", ctx.packageName, null) }
                    startActivity(intent)
                }
                .setNegativeButton("Annuler", null)
                .show()
        }

        fun permRow(label:String, permission:String, consequence:String, restrictedHint:Boolean=false):View{
            val col2=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
            val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
            val labelView=TextView(ctx).apply{text=label; setTextColor(UiKit.BLACK); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
            val statusView=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
            val manageBtn=Button(ctx).apply{
                text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(UiKit.BLACK)
                setOnClickListener{
                    val granted=ContextCompat.checkSelfPermission(ctx,permission)==PackageManager.PERMISSION_GRANTED
                    if(restrictedHint && !granted && Build.VERSION.SDK_INT>=33){
                        showRestrictedSettingsHelp(
                            " C'est la cause la plus fréquente quand l'envoi de SMS reste " +
                            "\u00ab non accordée \u00bb même après avoir accepté la demande."
                        )
                    } else {
                        val intent=Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply{ data=Uri.fromParts("package",ctx.packageName,null) }
                        startActivity(intent)
                    }
                }
            }
            val consLabel=TextView(ctx).apply{text="Si refuse : $consequence"; setTextColor(UiKit.TEXT_MUTED); textSize=10f; setPadding(0,8,0,0)}
            fun refresh(){
                val granted=ContextCompat.checkSelfPermission(ctx,permission)==PackageManager.PERMISSION_GRANTED
                statusView.text=if(granted) "Accordee" else "Non accordee"
                statusView.setTextColor(if(granted) UiKit.BLACK else UiKit.DANGER)
            }
            refresh(); refreshers.add(::refresh)
            row.addView(labelView); row.addView(statusView); row.addView(manageBtn)
            col2.addView(row); col2.addView(consLabel)
            return col2
        }

        col.addView(permRow("Microphone (ecoute vocale)", Manifest.permission.RECORD_AUDIO, "impossible d'utiliser les commandes vocales"))
        col.addView(spacer(2))
        col.addView(permRow("Contacts (appel par nom)", Manifest.permission.READ_CONTACTS, "impossible de trouver un contact par son nom"))
        col.addView(spacer(2))
        col.addView(permRow("Appel telephonique", Manifest.permission.CALL_PHONE, "les demandes d'appel resteront sans effet, meme apres confirmation"))
        col.addView(spacer(2))
        col.addView(permRow("Envoi de SMS", Manifest.permission.SEND_SMS, "les demandes d'envoi de message resteront sans effet, meme apres confirmation", restrictedHint=true))
        col.addView(spacer(2))
        if(Build.VERSION.SDK_INT>=33){
            col.addView(permRow("Notifications", Manifest.permission.POST_NOTIFICATIONS, "la notification d'ecoute active et les rappels de relances ne s'afficheront pas"))
            col.addView(spacer(2))
        }

        // Accessibilite (mecanisme different : reglage systeme, pas une permission classique)
        val accCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val accRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val accLabel=TextView(ctx).apply{text="Service d'accessibilite (actions systeme)"; setTextColor(UiKit.BLACK); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val accStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val accBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            setOnClickListener{
                val exp="${ctx.packageName}/${VanelleAccessibilityService::class.java.canonicalName}"
                val en=Settings.Secure.getString(ctx.contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                var granted=false
                if(en!=null){ val split=TextUtils.SimpleStringSplitter(':'); split.setString(en); while(split.hasNext()){ if(split.next().equals(exp,true)){ granted=true; break } } }
                if(!granted && Build.VERSION.SDK_INT>=33){
                    showRestrictedSettingsHelp(
                        " C'est la cause la plus fréquente quand le service d'accessibilité " +
                        "reste grisé ou refuse de s'activer."
                    )
                } else {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
        }
        fun refreshAcc(){
            val exp="${ctx.packageName}/${VanelleAccessibilityService::class.java.canonicalName}"
            val en=Settings.Secure.getString(ctx.contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            var granted=false
            if(en!=null){ val split=TextUtils.SimpleStringSplitter(':'); split.setString(en); while(split.hasNext()){ if(split.next().equals(exp,true)){ granted=true; break } } }
            accStatus.text=if(granted) "Accordee" else "Non accordee"
            accStatus.setTextColor(if(granted) UiKit.BLACK else UiKit.DANGER)
        }
        refreshAcc(); refreshers.add(::refreshAcc)
        accRow.addView(accLabel); accRow.addView(accStatus); accRow.addView(accBtn)
        val accCons=TextView(ctx).apply{text="Si refuse : les commandes retour/accueil/notifications/recents ne fonctionneront pas"; setTextColor(UiKit.TEXT_MUTED); textSize=10f; setPadding(0,8,0,0)}
        accCol.addView(accRow); accCol.addView(accCons)
        col.addView(accCol); col.addView(spacer(2))

        // Alarmes exactes (necessaire pour l'onglet Relances)
        val alarmCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val alarmRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val alarmLabel=TextView(ctx).apply{text="Alarmes exactes (relances a l'heure precise)"; setTextColor(UiKit.BLACK); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val alarmStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val alarmBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            setOnClickListener{ if(Build.VERSION.SDK_INT>=31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:${ctx.packageName}"))) }
        }
        fun refreshAlarm(){
            val granted=AlarmScheduler.canScheduleExact(ctx)
            alarmStatus.text=if(granted) "Accordee" else "Non accordee"
            alarmStatus.setTextColor(if(granted) UiKit.BLACK else UiKit.DANGER)
        }
        refreshAlarm(); refreshers.add(::refreshAlarm)
        alarmRow.addView(alarmLabel); alarmRow.addView(alarmStatus); alarmRow.addView(alarmBtn)
        val alarmCons=TextView(ctx).apply{text="Si refuse : les relances programmees peuvent se declencher en retard, plus jamais a l'heure exacte"; setTextColor(UiKit.TEXT_MUTED); textSize=10f; setPadding(0,8,0,0)}
        alarmCol.addView(alarmRow); alarmCol.addView(alarmCons)
        col.addView(alarmCol); col.addView(spacer(2))

        // Affichage par-dessus les autres apps (mascotte sur l'ecran principal)
        val overlayCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val overlayRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val overlayLabel=TextView(ctx).apply{text="Affichage sur l'ecran principal"; setTextColor(UiKit.BLACK); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val overlayStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val overlayBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            setOnClickListener{ OverlayHelper.requestPermission(ctx) }
        }
        fun refreshOverlay(){
            val granted=OverlayHelper.canDraw(ctx)
            overlayStatus.text=if(granted) "Accordee" else "Non accordee"
            overlayStatus.setTextColor(if(granted) UiKit.BLACK else UiKit.DANGER)
        }
        refreshOverlay(); refreshers.add(::refreshOverlay)
        overlayRow.addView(overlayLabel); overlayRow.addView(overlayStatus); overlayRow.addView(overlayBtn)
        val overlayCons=TextView(ctx).apply{text="Si refuse : la mascotte repond seulement dans une fenetre de l'app, pas par-dessus ton ecran habituel"; setTextColor(UiKit.TEXT_MUTED); textSize=10f; setPadding(0,8,0,0)}
        overlayCol.addView(overlayRow); overlayCol.addView(overlayCons)
        col.addView(overlayCol); col.addView(spacer(28))

        // --- Mode traduction : activation vocale uniquement ---
        col.addView(sectionTitle("MODE TRADUCTION"))
        val trRow=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,20,24,20); background=UiKit.card(ctx)}
        val trLabel=TextView(ctx).apply{
            text="Mode traduction vocale : Vanelle écoute, traduit et lit à voix haute.\n• Source = langue que tu parles\n• Cible = langue de sortie\n• Activer / Arrêter = démarre ou stoppe le mode\n25+ langues via le moteur système / réseau (si autorisé)."
            setTextColor(UiKit.BLACK); textSize=12f
        }
        val trStatus=TextView(ctx).apply{
            text=if(TranslateModePrefs.isActive(ctx))
                "Actif : ${TranslateHelper.labelFor(TranslateModePrefs.source(ctx))} → ${TranslateHelper.labelFor(TranslateModePrefs.target(ctx))}"
            else "Inactif"
            textSize=11f; setTextColor(UiKit.TEXT_MUTED); setPadding(0,10,0,0)
        }
        val langLabels = TranslateHelper.UI_LANGUAGES.map { it.first }.toTypedArray()
        val langCodes = TranslateHelper.UI_LANGUAGES.map { it.second }
        fun pickLang(title: String, currentCode: String, onPick: (String) -> Unit) {
            val idx = langCodes.indexOfFirst { it.equals(currentCode, true) }.coerceAtLeast(0)
            AlertDialog.Builder(ctx).setTitle(title)
                .setSingleChoiceItems(langLabels, idx) { d, which ->
                    onPick(langCodes[which])
                    d.dismiss()
                }
                .setNegativeButton("Annuler", null).show()
        }
        val trBtns = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 10, 0, 0) }
        val srcBtn = Button(ctx).apply {
            text = "Langue source"; textSize = 10f; background = UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 6 }
            setOnClickListener {
                pickLang("Langue source", TranslateModePrefs.source(ctx)) { code ->
                    val t = TranslateModePrefs.target(ctx)
                    if (TranslateModePrefs.isActive(ctx)) TranslateModePrefs.start(ctx, code, t)
                    else { TranslateModePrefs.start(ctx, code, t); TranslateModePrefs.stop(ctx) }
                    trStatus.text = "Source : ${TranslateHelper.labelFor(code)}"
                }
            }
        }
        val tgtBtn = Button(ctx).apply {
            text = "Langue cible"; textSize = 10f; background = UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 6 }
            setOnClickListener {
                pickLang("Langue cible", TranslateModePrefs.target(ctx)) { code ->
                    val s = TranslateModePrefs.source(ctx)
                    if (TranslateModePrefs.isActive(ctx)) TranslateModePrefs.start(ctx, s, code)
                    else { TranslateModePrefs.start(ctx, s, code); TranslateModePrefs.stop(ctx) }
                    trStatus.text = "Cible : ${TranslateHelper.labelFor(code)}"
                }
            }
        }
        val toggleTr = Button(ctx).apply {
            text = if (TranslateModePrefs.isActive(ctx)) "Arrêter" else "Activer"
            textSize = 10f; background = UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener {
                if (TranslateModePrefs.isActive(ctx)) {
                    TranslateModePrefs.stop(ctx)
                    text = "Activer"
                    trStatus.text = "Inactif"
                } else {
                    TranslateModePrefs.start(ctx, TranslateModePrefs.source(ctx), TranslateModePrefs.target(ctx).let { if (it == "auto") "fr" else it })
                    text = "Arrêter"
                    trStatus.text = "Actif : ${TranslateHelper.labelFor(TranslateModePrefs.source(ctx))} → ${TranslateHelper.labelFor(TranslateModePrefs.target(ctx))}"
                }
            }
        }
        trBtns.addView(srcBtn); trBtns.addView(tgtBtn); trBtns.addView(toggleTr)
        trRow.addView(trLabel); trRow.addView(trStatus)
        col.addView(trRow); col.addView(trBtns); col.addView(spacer(28))
        refreshers.add{
            val active=TranslateModePrefs.isActive(ctx)
            trStatus.text=if(active)
                "Actif : ${TranslateHelper.labelFor(TranslateModePrefs.source(ctx))} → ${TranslateHelper.labelFor(TranslateModePrefs.target(ctx))}"
            else "Inactif"
            toggleTr.text = if (active) "Arrêter" else "Activer"
        }

        col.addView(spacer(28))

        // --- Bouton mascotte flottant (déclenchement manuel, plus fiable que le mot de réveil) ---
        col.addView(sectionTitle("VOIX DE L'IA"))
        val voiceCard = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            background = UiKit.card(ctx)
        }
        val voiceHint = TextView(ctx).apply {
            text = "Débit, hauteur et voix française du moteur TTS de ton téléphone."
            setTextColor(UiKit.TEXT_MUTED); textSize = 11f; setPadding(0, 0, 0, 12)
        }
        voiceCard.addView(voiceHint)

        // Débit
        val rateLabel = TextView(ctx).apply {
            text = "Débit : ${"%.1f".format(VoicePrefs.getRate(ctx))}"
            setTextColor(UiKit.BLACK); textSize = 13f
        }
        val rateBar = SeekBar(ctx).apply {
            max = 15 // 0.5 .. 2.0 step 0.1
            progress = ((VoicePrefs.getRate(ctx) - 0.5f) * 10f).toInt().coerceIn(0, 15)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val r = 0.5f + p / 10f
                    rateLabel.text = "Débit : ${"%.1f".format(r)}"
                    if (fromUser) VoicePrefs.setRate(ctx, r)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        voiceCard.addView(rateLabel); voiceCard.addView(rateBar)

        // Hauteur
        val pitchLabel = TextView(ctx).apply {
            text = "Hauteur : ${"%.1f".format(VoicePrefs.getPitch(ctx))}"
            setTextColor(UiKit.BLACK); textSize = 13f; setPadding(0, 12, 0, 0)
        }
        val pitchBar = SeekBar(ctx).apply {
            max = 15
            progress = ((VoicePrefs.getPitch(ctx) - 0.5f) * 10f).toInt().coerceIn(0, 15)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val r = 0.5f + p / 10f
                    pitchLabel.text = "Hauteur : ${"%.1f".format(r)}"
                    if (fromUser) VoicePrefs.setPitch(ctx, r)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        voiceCard.addView(pitchLabel); voiceCard.addView(pitchBar)

        // Voix installées
        val voiceListLabel = TextView(ctx).apply {
            text = "Voix française : chargement…"
            setTextColor(UiKit.BLACK); textSize = 13f; setPadding(0, 14, 0, 6)
        }
        voiceCard.addView(voiceListLabel)
        val voiceButtons = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
        }
        voiceCard.addView(voiceButtons)

        // TTS temporaire pour lister + tester
        var previewTts: TextToSpeech? = null
        previewTts = TextToSpeech(ctx.applicationContext) { status ->
            if (status != TextToSpeech.SUCCESS) {
                voiceListLabel.text = "Voix : moteur TTS indisponible"
                return@TextToSpeech
            }
            VoicePrefs.apply(ctx, previewTts)
            val voices = VoicePrefs.listFrenchVoices(previewTts)
            val current = VoicePrefs.getVoiceName(ctx)
            if (voices.isEmpty()) {
                voiceListLabel.text = "Aucune voix FR listée — la voix système par défaut sera utilisée."
            } else {
                voiceListLabel.text = "Choisis une voix (${voices.size} disponible(s)) :"
                voiceButtons.removeAllViews()
                // Option défaut
                val defBtn = Button(ctx).apply {
                    text = if (current.isBlank()) "• Défaut système" else "Défaut système"
                    textSize = 11f; background = UiKit.pill(ctx); setTextColor(UiKit.BLACK)
                    setOnClickListener {
                        VoicePrefs.setVoiceName(ctx, "")
                        VoicePrefs.apply(ctx, previewTts)
                        previewTts?.speak("Bonjour, je suis Vanelle.", TextToSpeech.QUEUE_FLUSH, null, "preview")
                        Toast.makeText(ctx, "Voix par défaut", Toast.LENGTH_SHORT).show()
                    }
                }
                voiceButtons.addView(defBtn)
                for (v in voices.take(8)) {
                    val label = VoicePrefs.labelFor(v)
                    val selected = v.name == current
                    val b = Button(ctx).apply {
                        text = if (selected) "• $label" else label
                        textSize = 10f; background = UiKit.pill(ctx)
                        setTextColor(if (selected) UiKit.BLACK else UiKit.BLACK)
                        setOnClickListener {
                            VoicePrefs.setVoiceName(ctx, v.name)
                            VoicePrefs.apply(ctx, previewTts)
                            previewTts?.speak("Bonjour, je suis Vanelle.", TextToSpeech.QUEUE_FLUSH, null, "preview")
                            Toast.makeText(ctx, "Voix sélectionnée", Toast.LENGTH_SHORT).show()
                        }
                    }
                    voiceButtons.addView(b)
                }
            }
        }

        val testBtn = Button(ctx).apply {
            text = "Tester la voix"
            textSize = 12f; background = UiKit.pill(ctx); setTextColor(UiKit.BLACK)
            setOnClickListener {
                try {
                    if (previewTts == null) {
                        Toast.makeText(ctx, "Moteur TTS en cours de chargement…", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    VoicePrefs.apply(ctx, previewTts)
                    val prenom = RelationalMemory(ctx).displayName()
                    val sample = if (prenom.isNotBlank()) "$prenom, bonjour, je suis Vanelle."
                    else "Bonjour, je suis Vanelle."
                    previewTts?.speak(sample, TextToSpeech.QUEUE_FLUSH, null, "preview")
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Test impossible : ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
        voiceCard.addView(testBtn)
        col.addView(voiceCard); col.addView(spacer(28))

        col.addView(sectionTitle("BOUTON MASCOTTE"))
        val floatRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,20,24,20); background=UiKit.card(ctx)}
        val floatLabel=TextView(ctx).apply{
            text="Mascotte flottante : clique dessus pour activer le micro"
            setTextColor(UiKit.BLACK); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)
        }
        val floatSw=Switch(ctx).apply{
            isChecked = FloatingMascotButton.isEnabled(ctx)
            setOnCheckedChangeListener{ sw, checked ->
                if (checked && !OverlayHelper.canDraw(ctx)) {
                    sw.isChecked = false
                    AlertDialog.Builder(ctx)
                        .setTitle("Autorisation nécessaire")
                        .setMessage("Pour afficher le bouton par-dessus les autres applis, autorise Vanelle OS dans les réglages système qui vont s'ouvrir.")
                        .setPositiveButton("Ouvrir les réglages"){_,_-> OverlayHelper.requestPermission(ctx) }
                        .setNegativeButton("Annuler",null)
                        .show()
                    return@setOnCheckedChangeListener
                }
                FloatingMascotButton.setEnabled(ctx, checked)
                Toast.makeText(ctx, if(checked) "Bouton mascotte activé" else "Bouton mascotte désactivé", Toast.LENGTH_SHORT).show()
            }
        }
        floatRow.addView(floatLabel); floatRow.addView(floatSw)
        col.addView(floatRow)

        // Curseur de taille (réagit tout de suite si le bouton est déjà affiché)
        val sizeCol = LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,16,24,16); background=UiKit.card(ctx)}
        val sizeLabel = TextView(ctx).apply{
            text = "Taille du bouton : ${FloatingMascotButton.getSizeDp(ctx)} dp"
            setTextColor(UiKit.BLACK); textSize=13f
        }
        val sizeBar = SeekBar(ctx).apply{
            max = FloatingMascotButton.MAX_SIZE_DP - FloatingMascotButton.MIN_SIZE_DP
            progress = FloatingMascotButton.getSizeDp(ctx) - FloatingMascotButton.MIN_SIZE_DP
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean){
                    val sizeDp = FloatingMascotButton.MIN_SIZE_DP + p
                    sizeLabel.text = "Taille du bouton : $sizeDp dp"
                    if (fromUser) FloatingMascotButton.setSizeDp(ctx, sizeDp)
                }
                override fun onStartTrackingTouch(sb: SeekBar?){}
                override fun onStopTrackingTouch(sb: SeekBar?){}
            })
        }
        sizeCol.addView(sizeLabel); sizeCol.addView(sizeBar)
        col.addView(sizeCol); col.addView(spacer(28))

        // --- Sauvegarde / changement de téléphone ---
        col.addView(sectionTitle("SAUVEGARDE & CHANGEMENT DE TELEPHONE"))
        val backupInfo = TextView(ctx).apply {
            text = "Active la sauvegarde Google pour retrouver mémoire, relances et préférences après réinstallation. Pour un autre téléphone : exporte le fichier puis importe-le ici."
            setTextColor(UiKit.TEXT_MUTED); textSize = 12f; setPadding(24, 18, 24, 12); background = UiKit.card(ctx)
        }
        col.addView(backupInfo); col.addView(spacer(8))

        val sysBackupBtn = Button(ctx).apply {
            text = "Activer la sauvegarde systeme"
            textSize = 12f
            background = UiKit.pill(ctx)
            setTextColor(UiKit.BLACK)
            setOnClickListener {
                try { UserDataSnapshot.save(ctx) } catch (_: Exception) {}
                val landedOnToggle = UserDataSnapshot.openSystemBackupSettings(ctx)
                if (landedOnToggle) {
                    Toast.makeText(ctx, "Active le bouton \u00ab Sauvegarder sur Google Drive \u00bb en haut de l'écran", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(ctx, "Depuis les réglages : Système puis Sauvegarde, et active \u00ab Sauvegarder sur Google Drive \u00bb", Toast.LENGTH_LONG).show()
                }
            }
        }
        col.addView(sysBackupBtn); col.addView(spacer(8))

        val exportBtn = Button(ctx).apply {
            text = "Exporter mes donnees"
            textSize = 12f
            background = UiKit.pill(ctx)
            setTextColor(UiKit.BLACK)
            setOnClickListener {
                try {
                    val intent = UserDataSnapshot.shareIntent(ctx)
                    startActivity(Intent.createChooser(intent, "Exporter la sauvegarde VanelleOS"))
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Export impossible : ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        col.addView(exportBtn); col.addView(spacer(8))

        val importBtn = Button(ctx).apply {
            text = "Importer mes donnees"
            textSize = 12f
            background = UiKit.pill(ctx)
            setTextColor(UiKit.BLACK)
            setOnClickListener {
                try {
                    importLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Import impossible : ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        col.addView(importBtn); col.addView(spacer(28))

        sv.addView(col); return sv
    }
    override fun onResume(){ super.onResume(); refreshers.forEach{ it() } }
}


/**
 * Catalogue des fonctions REELLES uniquement (handlers implementes).
 * Section Sans IA = executable pendant telechargement modele.
 */

/**
 * Catalogue des fonctions reelles — exemples clairs a dire a la mascotte.
 * Pas de boutons Tester : la voix (mascotte) execute, meme sans IA chargee.
 */
class FeaturesFragment : Fragment() {
    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val d = ctx.resources.displayMetrics.density
        val sv = ScrollView(ctx).apply { setBackgroundColor(UiKit.WHITE) }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((22 * d).toInt(), (24 * d).toInt(), (22 * d).toInt(), (28 * d).toInt())
        }
        fun spacer(h: Int) = View(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(-1, (h * d).toInt())
        }
        fun h(title: String) = TextView(ctx).apply {
            text = title
            setTextColor(0xFF0A0A0A.toInt())
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, (8 * d).toInt(), 0, (10 * d).toInt())
        }

        val aiReady = try { DataDownloadService.isUsable(ctx) } catch (_: Exception) { false }
        val banner = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * d).toInt(), (14 * d).toInt(), (16 * d).toInt(), (14 * d).toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(if (aiReady) 0xFFECFDF5.toInt() else 0xFFFFF7ED.toInt())
                cornerRadius = 12f * d
            }
        }
        banner.addView(TextView(ctx).apply {
            text = if (aiReady) "IA prete" else "IA pas encore prete"
            setTextColor(if (aiReady) 0xFF065F46.toInt() else 0xFF9A3412.toInt())
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        banner.addView(TextView(ctx).apply {
            text = if (aiReady)
                "Parle a la mascotte pour n'importe quelle fonction."
            else
                "Parle a la mascotte pour les actions Sans IA. " +
                    "Si tu demandes du chat libre, elle te dira que l'IA n'est pas prete."
            setTextColor(UiKit.TEXT_MUTED)
            textSize = 12f
            setPadding(0, (6 * d).toInt(), 0, 0)
        })
        col.addView(banner)
        col.addView(spacer(14))

        data class Feat(val title: String, val examples: String, val detail: String)

        val offline = listOf(
            Feat("Batterie", "« Batterie »  ·  « Quel est mon niveau de batterie »", "Annonce le pourcentage de charge"),
            Feat("Lampe torche", "« Allume la lampe »  ·  « Eteins la lampe »", "Active / coupe le flash"),
            Feat("Volume", "« Monte le volume »  ·  « Baisse le volume »", "Regle le volume multimedia"),
            Feat("Mode sonnerie", "« Mode silencieux »  ·  « Mode vibreur »  ·  « Reactive le son »", "Sonnerie / vibreur / normal"),
            Feat("Ouvrir une app", "« Ouvre Spotify »  ·  « Ouvre la calculatrice »  ·  « Ouvre WhatsApp »", "Lance l'application par son nom"),
            Feat("Camera", "« Ouvre la camera »  ·  « Prends une photo »", "Ouvre l'appareil photo"),
            Feat("Galerie", "« Ouvre la galerie »  ·  « Montre mes photos »", "Ouvre la galerie photos"),
            Feat("YouTube", "« YouTube Stromae »  ·  « YouTube musique calme »", "Ouvre YouTube avec la recherche"),
            Feat("Maps / Navigation", "« Navigue vers Paris »  ·  « Maps Tour Eiffel »", "Ouvre Google Maps"),
            Feat("Recherche web", "« Cherche meteo demain »  ·  « Cherche actualites France »", "Ouvre le navigateur"),
            Feat("Lien web", "« Ouvre https://wikipedia.org »", "Ouvre une URL"),
            Feat("Appeler", "« Appelle Maman »  ·  « Appelle Paul »", "Confirmation puis appel (permission)"),
            Feat("SMS", "« Envoie un message a Paul texte j'arrive »", "SMS apres confirmation (permission)"),
            Feat("Urgence", "« Urgence »", "Compose le 112"),
            Feat("Telephone perdu", "« Retrouve mon telephone »", "Alarme forte + vibration"),
            Feat("Presse-papiers", "« Lis le presse-papiers »", "Lit le texte copie"),
            Feat("Minuteur", "« Minuteur 5 minutes »  ·  « Timer 10 minutes »", "Lance un minuteur systeme"),
            Feat("Partager", "« Partage le texte bonjour a tous »", "Menu de partage Android"),
            Feat("Traduction (reseau)", "« Traduis hello how are you »", "Traduction en ligne, sans modele local"),
            Feat("Memoire — sauver", "« Retiens que mon code wifi est abcd1234 »", "Note stockee sur le telephone"),
            Feat("Memoire — rappeler", "« Rappelle-moi mon code wifi »", "Relit une note sauvee"),
            Feat("Retour / Accueil", "« Retour »  ·  « Accueil »", "Accessibilite Vanelle requise"),
            Feat("Lire l'ecran", "« Lis l'ecran »", "Lit le texte visible (accessibilite)"),
            Feat("Journal", "« Journal d'activite »", "Dernieres actions Vanelle"),
            Feat("Confidentialite", "« Statut confidentialite »", "Etat du pare-feu privacy")
        )

        val withAi = listOf(
            Feat("Conversation libre", "« Explique la photosynthese »  ·  « Donne-moi 3 idees de diner »", "Chat naturel avec le modele"),
            Feat("Resume d'ecran", "« Resume l'ecran »", "Accessibilite + modele local"),
            Feat("Mode traduction continu", "« Mode traduction anglais vers francais »", "Chaque phrase est traduite jusqu'a arret"),
            Feat("Relance", "« Rappelle-moi d'appeler Paul a 18h30 »", "Voir aussi l'onglet Relances")
        )

        fun addCard(feat: Feat) {
            val card = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((16 * d).toInt(), (14 * d).toInt(), (16 * d).toInt(), (14 * d).toInt())
                background = UiKit.card(ctx)
            }
            card.addView(TextView(ctx).apply {
                text = feat.title
                setTextColor(0xFF0A0A0A.toInt())
                textSize = 13.5f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            card.addView(TextView(ctx).apply {
                text = "Dis a la mascotte :\n${feat.examples}"
                setTextColor(0xFF111827.toInt())
                textSize = 12.5f
                setPadding(0, (8 * d).toInt(), 0, 0)
                setLineSpacing(0f, 1.15f)
            })
            card.addView(TextView(ctx).apply {
                text = feat.detail
                setTextColor(UiKit.TEXT_MUTED)
                textSize = 11.5f
                setPadding(0, (6 * d).toInt(), 0, 0)
            })
            col.addView(card)
            col.addView(spacer(8))
        }

        col.addView(h("Sans IA — parle a la mascotte"))
        col.addView(TextView(ctx).apply {
            text = "Disponible meme pendant le telechargement du modele."
            setTextColor(UiKit.TEXT_MUTED)
            textSize = 11.5f
            setPadding(0, 0, 0, (8 * d).toInt())
        })
        for (x in offline) addCard(x)

        col.addView(spacer(8))
        col.addView(h("Avec IA — modele charge"))
        col.addView(TextView(ctx).apply {
            text = "Si le modele n'est pas pret, la mascotte le dira en une phrase courte."
            setTextColor(UiKit.TEXT_MUTED)
            textSize = 11.5f
            setPadding(0, 0, 0, (8 * d).toInt())
        })
        for (x in withAi) addCard(x)

        sv.addView(col)
        return sv
    }
}

class RelanceFragment:Fragment(){
    private var rebuildUi: (() -> Unit)? = null

    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val root=FrameLayout(ctx).apply{setBackgroundColor(UiKit.WHITE)}
        fun rebuild(){
            root.removeAllViews()
            val sv=ScrollView(ctx).apply{setBackgroundColor(UiKit.WHITE)}
            val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(28,32,28,32)}
            fun sectionTitle(t:String)=TextView(ctx).apply{text=t; setTextColor(UiKit.TEXT_MUTED); textSize=11f; letterSpacing=0.1f; setPadding(4,0,0,10)}
            fun spacer(h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,h)}
            val fmt=java.text.SimpleDateFormat("dd/MM HH:mm",java.util.Locale.FRANCE)
            val repo=RelanceRepository(ctx)

            col.addView(sectionTitle("A VENIR"))
            val tasks=repo.getTasks()
            if(tasks.isEmpty()) col.addView(TextView(ctx).apply{text="Aucune relance programmee. Dis : Rappelle-moi d'appeler Paul a 18h30"; setTextColor(UiKit.TEXT_MUTED); textSize=12f; setPadding(24,16,24,16)})
            for(task in tasks){
                val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
                val displayDesc=if(task.description.startsWith("routine:")) task.description.substringAfter("|",task.description) else task.description
                val label=TextView(ctx).apply{
                    text="$displayDesc\n${task.hour.toString().padStart(2,'0')}h${task.minute.toString().padStart(2,'0')}${if(task.repeatDaily) " - tous les jours" else " - une fois"}"
                    setTextColor(UiKit.BLACK); textSize=12f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)
                }
                val delBtn=Button(ctx).apply{
                    text="Supprimer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(UiKit.DANGER)
                    setOnClickListener{
                        try {
                            AlarmScheduler.cancel(ctx, task.id)
                            repo.removeTask(task.id)
                            android.widget.Toast.makeText(ctx, "Relance supprimee", android.widget.Toast.LENGTH_SHORT).show()
                        } catch (_:Exception) {}
                        rebuild()
                    }
                }
                row.addView(label); row.addView(delBtn)
                col.addView(row); col.addView(spacer(8))
            }
            col.addView(spacer(28))

            col.addView(sectionTitle("HISTORIQUE"))
            val history=repo.getHistory()
            if(history.isEmpty()) col.addView(TextView(ctx).apply{text="Aucune relance executee pour le moment."; setTextColor(UiKit.TEXT_MUTED); textSize=12f; setPadding(24,16,24,16)})
            for(h in history.take(30)){
                val row=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,16,24,16); background=UiKit.card(ctx)}
                val labelTop=TextView(ctx).apply{text=h.description; setTextColor(UiKit.BLACK); textSize=12f}
                val labelBottom=TextView(ctx).apply{text="${fmt.format(java.util.Date(h.executedAt))} - ${h.result}"; setTextColor(UiKit.TEXT_MUTED); textSize=10f; setPadding(0,4,0,0)}
                row.addView(labelTop); row.addView(labelBottom)
                col.addView(row); col.addView(spacer(8))
            }
            sv.addView(col)
            root.addView(sv)
        }
        rebuildUi = { rebuild() }
        rebuild()
        return root
    }
    override fun onResume(){
        super.onResume()
        rebuildUi?.invoke()
    }
}

/**
 * Chat texte avec Vanelle — même historique que la mascotte vocale.
 */
/**
 * Conversation : chat actif + historique organisé (dossiers, tags, recherche).
 */
/**
 * Conversation — interface type chat moderne (fil + saisie bas).
 */
/**
 * Conversation — interface type Grok :
 * fond clair, messages assistant à gauche, utilisateur à droite,
 * grande zone de saisie en bas, historique accessible.
 */
class ChatFragment : Fragment() {
    private var listCol: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var titleView: TextView? = null
    private var inputBar: View? = null
    private var modeHistory = false

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val d = ctx.resources.displayMetrics.density

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0A0A0A.toInt()) // comme Grok dark chrome outer — on force light content
        }
        // Conteneur principal style Grok light
        val shell = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(UiKit.WHITE)
            layoutParams = LinearLayout.LayoutParams(-1, -1)
        }

        // Top bar minimal
        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((16 * d).toInt(), (14 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
            gravity = android.view.Gravity.CENTER_VERTICAL
            setBackgroundColor(UiKit.WHITE)
        }
        val title = TextView(ctx).apply {
            text = "Vanelle"
            setTextColor(UiKit.TEXT_DARK)
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        titleView = title
        fun chip(label: String, onClick: () -> Unit) = TextView(ctx).apply {
            text = label
            setTextColor(UiKit.TEXT_MUTED)
            textSize = 13f
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
            setOnClickListener { onClick() }
        }
        val hist = chip("Historique") {
            modeHistory = !modeHistory
            refresh(ctx)
        }
        val neu = chip("Nouveau") {
            ChatHistory.newThread(ctx)
            modeHistory = false
            refresh(ctx)
        }
        top.addView(title); top.addView(hist); top.addView(neu)
        shell.addView(top)
        // thin divider
        shell.addView(View(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(-1, (1 * d).toInt())
            setBackgroundColor(0xFFE5E7EB.toInt())
        })

        val sv = ScrollView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            isFillViewport = true
            setBackgroundColor(UiKit.WHITE)
            isVerticalScrollBarEnabled = false
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((18 * d).toInt(), (16 * d).toInt(), (18 * d).toInt(), (24 * d).toInt())
        }
        listCol = col
        scroll = sv
        sv.addView(col)
        shell.addView(sv)

        // Input area — full width rounded like Grok
        val bottom = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (16 * d).toInt())
            setBackgroundColor(UiKit.WHITE)
        }
        inputBar = bottom
        val inputWrap = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.BOTTOM
            setPadding((4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFFF4F4F5.toInt())
                cornerRadius = 28f * d
                setStroke((1 * d).toInt(), 0xFFE4E4E7.toInt())
            }
        }
        val input = EditText(ctx).apply {
            hint = "Message Vanelle"
            setTextColor(0xFF18181B.toInt())
            setHintTextColor(0xFFA1A1AA.toInt())
            textSize = 15f
            minLines = 1
            maxLines = 6
            background = null
            setPadding((18 * d).toInt(), (14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val send = TextView(ctx).apply {
            text = "↑"
            gravity = android.view.Gravity.CENTER
            setTextColor(UiKit.WHITE)
            textSize = 16f
            val sz = (36 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                marginEnd = (6 * d).toInt()
                bottomMargin = (4 * d).toInt()
            }
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(UiKit.ACCENT)
            }
        }
        val stop = TextView(ctx).apply {
            text = "■"
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFFD32F2F.toInt())
            textSize = 14f
            visibility = View.GONE
            val sz = (36 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                marginEnd = (6 * d).toInt()
                bottomMargin = (4 * d).toInt()
            }
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xFFFEE2E2.toInt())
            }
            setOnClickListener { LocalLlamaHelper.get(ctx).stopGeneration() }
        }
        fun doSend() {
            if (modeHistory) return
            val msg = input.text?.toString()?.trim().orEmpty()
            if (msg.isBlank()) return
            input.setText("")
            appendBubble(ctx, col, "user", msg)
            scrollToBottom()
            send.isEnabled = false
            send.visibility = View.GONE
            stop.visibility = View.VISIBLE
            viewLifecycleOwner.lifecycleScope.launch {
                val res = try {
                    CommandInterpreter(ctx).execute(msg)
                } catch (e: Exception) {
                    "Erreur : ${e.message ?: "inconnue"}"
                }
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    appendBubble(ctx, col, "assistant", res)
                    scrollToBottom()
                    send.isEnabled = true
                    send.visibility = View.VISIBLE
                    stop.visibility = View.GONE
                    updateTitle(ctx)
                }
            }
        }
        send.setOnClickListener { doSend() }
        inputWrap.addView(input)
        inputWrap.addView(send)
        inputWrap.addView(stop)
        bottom.addView(inputWrap)
        bottom.addView(TextView(ctx).apply {
            text = "Vanelle · privé sur cet appareil quand le mode local est utilisé"
            setTextColor(UiKit.TEXT_FAINT)
            textSize = 10f
            gravity = android.view.Gravity.CENTER
            setPadding(0, (8 * d).toInt(), 0, 0)
        })
        shell.addView(bottom)

        root.addView(shell)
        refresh(ctx)
        return root
    }

    override fun onResume() {
        super.onResume()
        refresh(requireContext())
    }

    private fun updateTitle(ctx: android.content.Context) {
        val th = ChatHistory.thread(ctx, ChatHistory.activeId(ctx))
        val name = th?.title?.take(36)?.ifBlank { null }
        titleView?.text = name ?: "Vanelle"
    }

    private fun refresh(ctx: android.content.Context) {
        val col = listCol ?: return
        col.removeAllViews()
        inputBar?.visibility = if (modeHistory) View.GONE else View.VISIBLE
        if (modeHistory) {
            titleView?.text = "Historique"
            showHistory(ctx, col)
            return
        }
        updateTitle(ctx)
        val msgs = ChatHistory.messages(ctx)
        if (msgs.isEmpty()) {
            val empty = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER_HORIZONTAL
                setPadding(24, 120, 24, 24)
            }
            empty.addView(TextView(ctx).apply {
                text = "Vanelle"
                setTextColor(UiKit.TEXT_DARK)
                textSize = 30f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = android.view.Gravity.CENTER
            })
            empty.addView(TextView(ctx).apply {
                text = "Que veux-tu faire aujourd’hui ?"
                setTextColor(UiKit.TEXT_MUTED)
                textSize = 16f
                gravity = android.view.Gravity.CENTER
                setPadding(0, 12, 0, 0)
            })
            col.addView(empty)
        } else {
            for (m in msgs) appendBubble(ctx, col, m.role, m.text)
        }
        scrollToBottom()
    }

    private fun showHistory(ctx: android.content.Context, col: LinearLayout) {
        val d = ctx.resources.displayMetrics.density
        val search = EditText(ctx).apply {
            hint = "Rechercher dans l'historique"
            setTextColor(0xFF18181B.toInt())
            setHintTextColor(0xFFA1A1AA.toInt())
            textSize = 14f
            setPadding((16 * d).toInt(), (12 * d).toInt(), (16 * d).toInt(), (12 * d).toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFFF4F4F5.toInt())
                cornerRadius = 16f * d
            }
        }
        col.addView(search)
        val host = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        col.addView(host)
        fun rebuild() {
            host.removeAllViews()
            val q = search.text?.toString().orEmpty()
            val threads = if (q.isNotBlank()) ChatHistory.search(ctx, q) else ChatHistory.allThreads(ctx)
            if (threads.isEmpty()) {
                host.addView(TextView(ctx).apply {
                    text = "Aucune conversation"
                    setTextColor(0xFFA1A1AA.toInt())
                    setPadding(8, 24, 8, 8)
                })
                return
            }
            for (th in threads) {
                val row = TextView(ctx).apply {
                    text = th.title.ifBlank { "Sans titre" } + "\n" + "${th.folder} · ${th.messages.size} msg"
                    setTextColor(0xFF18181B.toInt())
                    textSize = 14f
                    setPadding((14 * d).toInt(), (14 * d).toInt(), (14 * d).toInt(), (14 * d).toInt())
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(0xFFFAFAFA.toInt())
                        cornerRadius = 12f * d
                    }
                    setOnClickListener {
                        ChatHistory.setActive(ctx, th.id)
                        modeHistory = false
                        refresh(ctx)
                    }
                }
                host.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = (8 * d).toInt() })
            }
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { rebuild() }
        })
        rebuild()
    }

    private fun appendBubble(ctx: android.content.Context, col: LinearLayout, role: String, text: String) {
        val d = ctx.resources.displayMetrics.density
        val isUser = role.equals("user", true)
        if (isUser) {
            val bubble = TextView(ctx).apply {
                this.text = text
                setTextColor(UiKit.WHITE)
                textSize = 15f
                setPadding((16 * d).toInt(), (12 * d).toInt(), (16 * d).toInt(), (12 * d).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(0xFF18181B.toInt())
                    cornerRadius = 20f * d
                }
            }
            val wrap = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.END
                setPadding((48 * d).toInt(), (6 * d).toInt(), 0, (6 * d).toInt())
                addView(bubble, LinearLayout.LayoutParams(-2, -2))
            }
            col.addView(wrap)
        } else {
            // Grok-style: plain text block, no heavy bubble
            val block = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, (10 * d).toInt(), (24 * d).toInt(), (10 * d).toInt())
            }
            block.addView(TextView(ctx).apply {
                this.text = "Vanelle"
                setTextColor(0xFF71717A.toInt())
                textSize = 12f
                setPadding(0, 0, 0, (4 * d).toInt())
            })
            block.addView(TextView(ctx).apply {
                this.text = text
                setTextColor(UiKit.TEXT_DARK)
                textSize = 15.5f
                setLineSpacing(0f, 1.25f)
                setTextIsSelectable(true)
            })
            val actions = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, (4 * d).toInt(), 0, 0)
            }
            fun action(label: String, click: () -> Unit): TextView = TextView(ctx).apply {
                this.text = label
                setTextColor(UiKit.TEXT_MUTED)
                textSize = 11.5f
                setPadding((8 * d).toInt(), (5 * d).toInt(), (8 * d).toInt(), (5 * d).toInt())
                background = UiKit.pill(ctx)
                setOnClickListener { click() }
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = (6 * d).toInt() }
            }
            actions.addView(action("Copier") {
                val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Vanelle", text))
                Toast.makeText(ctx, "Réponse copiée", Toast.LENGTH_SHORT).show()
            })
            actions.addView(action("Régénérer") { retryLastMessage() })
            actions.addView(action("Partager") {
                val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(android.content.Intent.EXTRA_TEXT, text)
                }
                ctx.startActivity(android.content.Intent.createChooser(send, "Partager la réponse"))
            })
            actions.addView(action("Supprimer") {
                ChatHistory.removeLastAssistant(ctx)
                refresh(ctx)
            })
            block.addView(actions)
            col.addView(block)
        }
    }

    private fun retryLastMessage() {
        val ctx = requireContext()
        val messages = ChatHistory.messages(ctx)
        val lastUser = messages.lastOrNull { it.role.equals("user", true) } ?: return
        ChatHistory.removeLastAssistant(ctx)
        refresh(ctx)
        if (listCol == null) return
        val msg = lastUser.text
        viewLifecycleOwner.lifecycleScope.launch {
            val result = try { CommandInterpreter(ctx).execute(msg) } catch (e: Exception) {
                "Erreur : ${e.message ?: "inconnue"}"
            }
            withContext(kotlinx.coroutines.Dispatchers.Main) {
                refresh(ctx)
            }
        }
    }

    private fun scrollToBottom() {
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }
}
