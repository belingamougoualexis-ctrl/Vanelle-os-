package com.vanelle.os

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager

/** Configuration IA adaptative : aucun appareil ne reçoit une charge fixe. */
object AIConfiguration {
    data class Profile(
        val ramTotalMb: Long,
        val ramAvailableMb: Long,
        val nCtx: Int,
        val threads: Int,
        val maxOutputTokens: Int,
        val contextChars: Int,
        val thermalLimited: Boolean,
        val tier: String,
        val recommendedBatch: Int,
        val recommendedUbatch: Int,
        val maxPromptChars: Int
    )

    fun profile(c: Context): Profile {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val total = info.totalMem / MB
        val available = info.availMem / MB
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val thermalLimited = isThermalLimited(c)

        // On choisit le contexte sur la RAM physique ET la RAM actuellement disponible.
        val baseCtx = when {
            total >= 12288 && available >= 4500 -> 4096
            total >= 8192 && available >= 3200 -> 3072
            total >= 6144 && available >= 2400 -> 2048
            total >= 4096 && available >= 1500 -> 1024
            total >= 3072 && available >= 900 -> 768
            else -> 512
        }
        val nCtx = if (thermalLimited) (baseCtx / 2).coerceAtLeast(512) else baseCtx
        val threads = (cores - 1).coerceAtLeast(1).coerceAtMost(8)
        val safeThreads = if (thermalLimited) (threads - 1).coerceAtLeast(1) else threads
        val output = when {
            nCtx >= 4096 -> 512
            nCtx >= 3072 -> 448
            nCtx >= 2048 -> 384
            nCtx >= 1024 -> 256
            else -> 160
        }
        // Le prompt doit laisser de la place au système, à la mémoire et à la sortie.
        // ~3 caractères/token est volontairement prudent pour le français/multilingue.
        val chars = (nCtx * 3).coerceIn(1000, 12000)
        val recommendedBatch = when {
            nCtx >= 4096 -> 512
            nCtx >= 2048 -> 384
            nCtx >= 1024 -> 256
            else -> 128
        }
        val recommendedUbatch = (recommendedBatch / 2).coerceAtLeast(64)
        val tier = when {
            nCtx >= 4096 -> "MAX"
            nCtx >= 2048 -> "HIGH"
            nCtx >= 1024 -> "STANDARD"
            nCtx >= 768 -> "BALANCED"
            else -> "SAFE"
        }
        val maxPromptChars = (chars - (output * 4) - 1300).coerceAtLeast(450)
        return Profile(
            total, available, nCtx, safeThreads, output, chars, thermalLimited, tier,
            recommendedBatch, recommendedUbatch, maxPromptChars
        )
    }

    fun status(c: Context): String {
        val p = profile(c)
        return "IA ${p.tier} · contexte ${p.nCtx} · ${p.threads} threads · batch ${p.recommendedBatch} · RAM ${p.ramAvailableMb} Mo libres" +
            if (p.thermalLimited) " · mode thermique" else ""
    }

    private fun isThermalLimited(c: Context): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE
        } catch (_: Exception) { false }
    }

    private const val MB = 1024L * 1024L
}
