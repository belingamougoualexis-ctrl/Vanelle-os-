# VanelleOS 2.4.0 — Production readiness

## Inclus
- Configuration IA adaptative RAM/CPU/thermique.
- Contexte 512–4096 selon ressources disponibles.
- Threads natifs alignés sur le profil appareil.
- Fallback de contexte lors du chargement.
- Mémoire conversationnelle et historique persistants.
- Arrêt de génération.
- Interface Conversation modernisée et cohérente avec le Design System.
- Gestion interne des incidents sans écran de diagnostic exposé à l’utilisateur.
- Compatibilité variante `modern` 64-bit et `legacy` sans moteur Llama.

## Validation obligatoire avant publication
1. `assembleModernRelease` et `assembleLegacyRelease` sur une machine Android/CI disposant du SDK.
2. Installer les APK/AAB sur Android 10–15+.
3. Tester 4/6/8/12 Go RAM.
4. Vérifier téléchargement, SHA-256, chargement, génération, arrêt et reprise et reprise.
5. Tester rotation, arrière-plan, verrouillage, faible RAM et température élevée.
6. Vérifier toutes les permissions et les obligations de distribution du store choisi.
7. Faire un test release avec R8/minification activée.

## Limite honnête
La signature de publication et la compilation Android finale nécessitent un SDK/Gradle Android et des appareils réels. Le projet est préparé pour cette étape ; la publication doit être précédée d’une compilation release et de tests matériels.
