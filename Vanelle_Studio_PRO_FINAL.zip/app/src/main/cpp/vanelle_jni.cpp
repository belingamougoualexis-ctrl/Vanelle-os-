#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <cmath>
#include <mutex>
#include <string>
#include <vector>
#include <unistd.h>
#include "llama.h"

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "Vanelle", __VA_ARGS__)

static std::mutex g_mutex;
static llama_model * g_model = nullptr;
static llama_context * g_ctx = nullptr;
static llama_sampler * g_sampler = nullptr;
static llama_model * g_emb_model = nullptr;
static llama_context * g_emb_ctx = nullptr;

static void free_chat() {
    if (g_sampler) { llama_sampler_free(g_sampler); g_sampler = nullptr; }
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}
static void free_embedding() {
    if (g_emb_ctx) { llama_free(g_emb_ctx); g_emb_ctx = nullptr; }
    if (g_emb_model) { llama_model_free(g_emb_model); g_emb_model = nullptr; }
}
static std::vector<llama_token> tokenize(const llama_vocab * vocab, const std::string & text, bool add_bos) {
    int32_t n = llama_tokenize(vocab, text.c_str(), (int32_t)text.size(), nullptr, 0, add_bos, true);
    if (n < 0) n = -n;
    std::vector<llama_token> tokens((size_t)n);
    int32_t written = llama_tokenize(vocab, text.c_str(), (int32_t)text.size(), tokens.data(), n, add_bos, true);
    if (written < 0) return {};
    tokens.resize((size_t)written);
    return tokens;
}
static std::string piece(const llama_vocab * vocab, llama_token token) {
    int32_t n = llama_token_to_piece(vocab, token, nullptr, 0, 0, false);
    if (n <= 0) return {};
    std::string out((size_t)n, '\0');
    int32_t written = llama_token_to_piece(vocab, token, out.data(), n, 0, false);
    if (written < 0) return {};
    out.resize((size_t)written);
    return out;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_vanelle_android_NativeVanelleBridge_load(JNIEnv * env, jobject, jstring jpath, jint contextSize) {
    std::lock_guard<std::mutex> lock(g_mutex);
    const char * path = env->GetStringUTFChars(jpath, nullptr);
    std::string modelPath(path ? path : "");
    env->ReleaseStringUTFChars(jpath, path);
    if (modelPath.empty()) return 2;
    free_chat();
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    g_model = llama_model_load_from_file(modelPath.c_str(), mp);
    if (!g_model) { LOGE("Unable to load GGUF model"); return 3; }
    const int cores = (int)sysconf(_SC_NPROCESSORS_ONLN);
    const int threads = std::max(1, std::min(8, cores > 2 ? cores - 1 : cores));
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t)std::clamp(contextSize, 1024, 4096);
    cp.n_batch = std::min<uint32_t>(512, cp.n_ctx);
    cp.n_ubatch = std::min<uint32_t>(256, cp.n_batch);
    cp.n_threads = threads;
    cp.n_threads_batch = threads;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) { free_chat(); return 4; }
    auto sp = llama_sampler_chain_default_params();
    g_sampler = llama_sampler_chain_init(sp);
    if (!g_sampler) { free_chat(); return 5; }
    llama_sampler_chain_add(g_sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_top_p(0.90f, 1));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_temp(0.35f));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_dist(1234567));
    return 0;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_vanelle_android_NativeVanelleBridge_generate(JNIEnv * env, jobject, jstring jprompt, jint maxTokens) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model || !g_ctx || !g_sampler) return env->NewStringUTF("");
    const char * p = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt(p ? p : "");
    env->ReleaseStringUTFChars(jprompt, p);
    const llama_vocab * vocab = llama_model_get_vocab(g_model);
    auto tokens = tokenize(vocab, prompt, true);
    if (tokens.empty()) return env->NewStringUTF("");
    // Prompt trop long (system + historique) → garder la fin plutôt que renvoyer vide
    {
        const size_t n_ctx = (size_t)llama_n_ctx(g_ctx);
        const size_t reserve = 64; // place pour la génération
        if (n_ctx > reserve && tokens.size() >= n_ctx - reserve) {
            const size_t keep = n_ctx - reserve;
            tokens.erase(tokens.begin(), tokens.end() - (long)keep);
        }
    }
    llama_memory_clear(llama_get_memory(g_ctx), true);
    llama_sampler_reset(g_sampler);
    llama_batch batch = llama_batch_init((int)std::max<size_t>(tokens.size(), 256), 0, 1);
    for (size_t i = 0; i < tokens.size(); ++i) {
        batch.token[i] = tokens[i]; batch.pos[i] = (llama_pos)i;
        batch.n_seq_id[i] = 1; batch.seq_id[i][0] = 0; batch.logits[i] = (i + 1 == tokens.size());
    }
    batch.n_tokens = (int32_t)tokens.size();
    if (llama_decode(g_ctx, batch) != 0) { llama_batch_free(batch); return env->NewStringUTF(""); }
    std::string result;
    const int limit = std::clamp((int)maxTokens, 32, 768);
    for (int i = 0; i < limit; ++i) {
        llama_token id = llama_sampler_sample(g_sampler, g_ctx, batch.n_tokens - 1);
        if (llama_vocab_is_eog(vocab, id)) break;
        result += piece(vocab, id);
        llama_sampler_accept(g_sampler, id);
        batch.token[0] = id; batch.pos[0] = (llama_pos)(tokens.size() + i);
        batch.n_seq_id[0] = 1; batch.seq_id[0][0] = 0; batch.logits[0] = true; batch.n_tokens = 1;
        if (llama_decode(g_ctx, batch) != 0) break;
    }
    llama_batch_free(batch);
    return env->NewStringUTF(result.c_str());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_vanelle_android_NativeVanelleBridge_loadEmbedding(JNIEnv * env, jobject, jstring jpath) {
    std::lock_guard<std::mutex> lock(g_mutex);
    const char * path = env->GetStringUTFChars(jpath, nullptr);
    std::string modelPath(path ? path : "");
    env->ReleaseStringUTFChars(jpath, path);
    if (modelPath.empty()) return 2;
    free_embedding();
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    g_emb_model = llama_model_load_from_file(modelPath.c_str(), mp);
    if (!g_emb_model) return 3;
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = 384;
    cp.n_batch = 384;
    cp.n_ubatch = 384;
    cp.embeddings = true;
    cp.pooling_type = LLAMA_POOLING_TYPE_MEAN;
    const int cores = (int)sysconf(_SC_NPROCESSORS_ONLN);
    cp.n_threads = std::max(1, std::min(4, cores));
    cp.n_threads_batch = cp.n_threads;
    g_emb_ctx = llama_init_from_model(g_emb_model, cp);
    if (!g_emb_ctx) { free_embedding(); return 4; }
    return 0;
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_vanelle_android_NativeVanelleBridge_embed(JNIEnv * env, jobject, jstring jtext) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_emb_model || !g_emb_ctx) return env->NewFloatArray(0);
    const char * p = env->GetStringUTFChars(jtext, nullptr);
    std::string text(p ? p : "");
    env->ReleaseStringUTFChars(jtext, p);
    const llama_vocab * vocab = llama_model_get_vocab(g_emb_model);
    auto tokens = tokenize(vocab, text, true);
    if (tokens.empty()) return env->NewFloatArray(0);
    {
        const size_t n_ctx = (size_t)llama_n_ctx(g_emb_ctx);
        if (n_ctx > 0 && tokens.size() > n_ctx) {
            tokens.erase(tokens.begin(), tokens.end() - (long)n_ctx);
        }
    }
    llama_memory_clear(llama_get_memory(g_emb_ctx), true);
    llama_batch batch = llama_batch_init((int)tokens.size(), 0, 1);
    for (size_t i = 0; i < tokens.size(); ++i) {
        batch.token[i] = tokens[i]; batch.pos[i] = (llama_pos)i;
        batch.n_seq_id[i] = 1; batch.seq_id[i][0] = 0; batch.logits[i] = true;
    }
    batch.n_tokens = (int32_t)tokens.size();
    if (llama_decode(g_emb_ctx, batch) != 0) { llama_batch_free(batch); return env->NewFloatArray(0); }
    const float * emb = llama_get_embeddings_seq(g_emb_ctx, 0);
    const int n = (int)llama_model_n_embd_out(g_emb_model);
    if (!emb || n <= 0) { llama_batch_free(batch); return env->NewFloatArray(0); }
    std::vector<float> out((size_t)n);
    float norm = 0.f;
    for (int i=0;i<n;++i) norm += emb[i]*emb[i];
    norm = std::sqrt(std::max(norm, 1e-12f));
    for (int i=0;i<n;++i) out[i]=emb[i]/norm;
    llama_batch_free(batch);
    jfloatArray arr = env->NewFloatArray(n);
    env->SetFloatArrayRegion(arr, 0, n, out.data());
    return arr;
}

extern "C" JNIEXPORT void JNICALL
Java_com_vanelle_android_NativeVanelleBridge_unload(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    free_chat();
}
extern "C" JNIEXPORT void JNICALL
Java_com_vanelle_android_NativeVanelleBridge_unloadEmbedding(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    free_embedding();
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_vanelle_android_NativeVanelleBridge_info(JNIEnv * env, jobject) {
    return env->NewStringUTF(llama_print_system_info());
}
