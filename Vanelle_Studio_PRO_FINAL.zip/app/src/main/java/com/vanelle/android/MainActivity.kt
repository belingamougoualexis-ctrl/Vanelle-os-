package com.vanelle.android

import android.Manifest
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences(DownloadModelWorker.PREFS, Context.MODE_PRIVATE) }
    private val secret by lazy { SecretStore(this) }
    @Volatile private var nativeLoaded = false
    @Volatile private var modelLoading = false
    @Volatile private var embeddingLoaded = false
    private var pendingZipAiId: String? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val ioExecutor = Executors.newSingleThreadExecutor()

    private val modelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input)
                val safeName = (uri.lastPathSegment?.substringAfterLast('/') ?: "imported.gguf").replace(Regex("[^A-Za-z0-9._-]"), "_")
                val target = File(filesDir, "models/imported-$safeName")
                target.parentFile?.mkdirs()
                target.outputStream().use { output -> input.copyTo(output, bufferSize = 1024 * 1024) }
                require(isGgufMagic(target)) { "Not GGUF" }
                // Décharger l'ancien modèle en mémoire avant de basculer
                if (nativeLoaded) {
                    try { NativeVanelleBridge.unload() } catch (_: Throwable) {}
                    nativeLoaded = false
                }
                prefs.edit()
                    .putBoolean("model_downloaded", true)
                    .putString("model_path", target.absolutePath)
                    .putString("model_status", "downloaded")
                    .putInt("model_progress", 100)
                    .apply()
                Toast.makeText(this, "Modèle local ajouté. Vanelle peut maintenant l'utiliser.", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) { Toast.makeText(this, "Impossible d'importer le modèle.", Toast.LENGTH_LONG).show() }
    }

    /** ZIP données (jusqu'à 3 Go) : streaming natif ZipInputStream, pas de chargement mémoire total. */
    private val dataZipPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val aiId = pendingZipAiId; pendingZipAiId = null
        if (uri == null || aiId.isNullOrBlank()) return@registerForActivityResult
        Toast.makeText(this, "Analyse du ZIP en cours…", Toast.LENGTH_SHORT).show()
        ioExecutor.execute {
            try {
                val filesJson = processDataZip(uri)
                runOnUiThread {
                    val payload = JSONObject().put("aiId", aiId).put("files", filesJson).toString()
                    val js = "window.VanelleNativeZipResult && window.VanelleNativeZipResult(" +
                        JSONObject.quote(payload) + ");"
                    web.evaluateJavascript(js, null)
                    Toast.makeText(this, "ZIP analysé (${filesJson.length()} fichier(s)).", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Impossible d'analyser ce ZIP.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // Permission de stockage requise uniquement sur Android 9 (API 28) pour écrire dans Téléchargements.
    private var pendingSave: Triple<String, String, String>? = null
    private val storagePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val save = pendingSave; pendingSave = null
        if (granted && save != null) {
            val (name, mime, data) = save
            val result = writeToDownloads(name, mime, data)
            if (result == "saved") Toast.makeText(this, "\"$name\" enregistré dans Téléchargements.", Toast.LENGTH_LONG).show()
            else Toast.makeText(this, "Impossible d'enregistrer le fichier.", Toast.LENGTH_LONG).show()
        } else if (!granted) {
            Toast.makeText(this, "Permission refusée : le fichier n'a pas pu être enregistré.", Toast.LENGTH_LONG).show()
        }
    }

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        // Peu importe la réponse : le téléchargement a déjà démarré / continue.
    }

    /** Sélecteur de fichiers pour <input type="file"> du WebView (uploads). */
    private val webFilePicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val cb = filePathCallback
        filePathCallback = null
        if (cb == null) return@registerForActivityResult
        if (uris.isNullOrEmpty()) {
            cb.onReceiveValue(null)
            return@registerForActivityResult
        }
        // Permission de lecture temporaire pour que le WebView lise les content://
        for (uri in uris) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Certains providers n'autorisent pas le persistable ; l'accès one-shot reste OK
            } catch (_: Exception) {}
        }
        cb.onReceiveValue(uris.toTypedArray())
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DownloadNotifications.ensureChannel(this)

        // Téléchargement immédiat en arrière-plan — aucun écran de consentement.
        startModelDownload()

        // Permission notifications (Android 13+) pour afficher la progression ; non bloquant.
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            // Nécessaire pour que <input type="file"> et content:// fonctionnent
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.mediaPlaybackRequiresUserGesture = false
            // IndexedDB + localStorage fiables
            try { settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT } catch (_: Exception) {}
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    // Annule un callback précédent non consommé
                    this@MainActivity.filePathCallback?.onReceiveValue(null)
                    this@MainActivity.filePathCallback = filePathCallback
                    val accept = fileChooserParams?.acceptTypes
                        ?.filter { it.isNotBlank() }
                        ?.toTypedArray()
                        ?.ifEmpty { null }
                        ?: arrayOf("*/*")
                    return try {
                        webFilePicker.launch(accept)
                        true
                    } catch (_: Exception) {
                        this@MainActivity.filePathCallback = null
                        filePathCallback?.onReceiveValue(null)
                        false
                    }
                }
                override fun onJsAlert(view: WebView?, url: String?, message: String?, result: android.webkit.JsResult?): Boolean {
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage(message)
                        .setPositiveButton("OK") { _, _ -> result?.confirm() }
                        .setOnCancelListener { result?.cancel() }
                        .show()
                    return true
                }
                override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: android.webkit.JsResult?): Boolean {
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage(message)
                        .setPositiveButton("OK") { _, _ -> result?.confirm() }
                        .setNegativeButton("Annuler") { _, _ -> result?.cancel() }
                        .setOnCancelListener { result?.cancel() }
                        .show()
                    return true
                }
                override fun onJsPrompt(view: WebView?, url: String?, message: String?, defaultValue: String?, result: android.webkit.JsPromptResult?): Boolean {
                    val input = EditText(this@MainActivity).apply { setText(defaultValue ?: "") }
                    val pad = (16 * resources.displayMetrics.density).toInt()
                    val wrap = LinearLayout(this@MainActivity).apply {
                        setPadding(pad, pad / 2, pad, 0)
                        addView(input)
                    }
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage(message)
                        .setView(wrap)
                        .setPositiveButton("OK") { _, _ -> result?.confirm(input.text.toString()) }
                        .setNegativeButton("Annuler") { _, _ -> result?.cancel() }
                        .setOnCancelListener { result?.cancel() }
                        .show()
                    return true
                }
            }
            addJavascriptInterface(NativeVanelle(this@MainActivity), "AndroidVanelle")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    fun openDataZipPicker(aiId: String) {
        pendingZipAiId = aiId
        dataZipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
    }

    /**
     * Streaming ZIP natif : lit entrée par entrée sans charger le ZIP entier en RAM.
     * Supporte jusqu'à 3 Go. Extrait uniquement les textes (txt/md/csv/json/html/js/css).
     */
    private fun processDataZip(uri: Uri): JSONArray {
        val out = JSONArray()
        val textExts = setOf("txt", "md", "csv", "json", "html", "js", "css")
        val maxEntryChars = 5 * 1024 * 1024
        contentResolver.openInputStream(uri).use { raw ->
            requireNotNull(raw)
            ZipInputStream(raw).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val name = entry.name.substringAfterLast('/')
                        val ext = name.substringAfterLast('.', "").lowercase()
                        if (ext in textExts) {
                            // Lecture directe sur ZipInputStream (évite BufferedReader qui
                            // peut laisser des octets et casser nextEntry).
                            val baos = java.io.ByteArrayOutputStream()
                            val buf = ByteArray(8192)
                            var total = 0
                            while (true) {
                                val n = zis.read(buf)
                                if (n < 0) break
                                if (total >= maxEntryChars) {
                                    // drain rest of entry
                                    continue
                                }
                                val room = maxEntryChars - total
                                val take = minOf(n, room)
                                baos.write(buf, 0, take)
                                total += take
                            }
                            val text = baos.toString(Charsets.UTF_8.name())
                                .replace(Regex("[\\t ]+"), " ")
                                .replace(Regex("\\n{3,}"), "\n\n")
                                .trim()
                            if (text.isNotEmpty()) {
                                val chunks = JSONArray()
                                var start = 0
                                val size = 900
                                val overlap = 120
                                while (start < text.length) {
                                    var end = minOf(text.length, start + size)
                                    if (end < text.length) {
                                        val cut = text.lastIndexOf(' ', end)
                                        if (cut > start + size * 6 / 10) end = cut
                                    }
                                    val piece = text.substring(start, end).trim()
                                    if (piece.isNotEmpty()) {
                                        chunks.put(JSONObject().put("id", UUID.randomUUID().toString()).put("text", piece))
                                    }
                                    if (end >= text.length) break
                                    start = maxOf(end - overlap, start + 1)
                                }
                                out.put(
                                    JSONObject()
                                        .put("id", UUID.randomUUID().toString())
                                        .put("nom", entry.name)
                                        .put("taille", entry.size.coerceAtLeast(0))
                                        .put("type", ext)
                                        .put("resume", text.take(600))
                                        .put("chunks", chunks)
                                        .put("source", name)
                                        .put("ts", System.currentTimeMillis())
                                )
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
        return out
    }

    fun activateLocalModel(): String {
        val path = modelFile()
        if (path.exists()) {
            // Fichier sur disque → charger en mémoire si pas déjà fait
            return if (ensureModelInMemory()) "ready" else "downloaded"
        }
        startModelDownload()
        return "downloading"
    }

    /** Charge le GGUF en RAM (llama.cpp) une seule fois. Thread-safe. */
    fun ensureModelInMemory(): Boolean {
        if (nativeLoaded) return true
        val path = modelFile()
        if (!path.exists()) return false

        var iAmLoader = false
        synchronized(this) {
            if (nativeLoaded) return true
            if (modelLoading) {
                iAmLoader = false
            } else {
                modelLoading = true
                iAmLoader = true
            }
        }

        if (!iAmLoader) {
            // Un autre thread charge déjà : attendre jusqu'à 90 s
            val deadline = System.currentTimeMillis() + 90_000L
            while (modelLoading && System.currentTimeMillis() < deadline) {
                try { Thread.sleep(150) } catch (_: InterruptedException) { break }
            }
            return nativeLoaded
        }

        return try {
            prefs.edit().putString("model_status", "loading_memory").apply()
            val rc = NativeVanelleBridge.load(path.absolutePath, adaptiveContext())
            if (rc == 0) {
                nativeLoaded = true
                prefs.edit()
                    .putBoolean("model_downloaded", true)
                    .putString("model_path", path.absolutePath)
                    .putString("model_status", "ready")
                    .putInt("model_progress", 100)
                    .apply()
                true
            } else {
                prefs.edit().putString("model_status", "load_failed").apply()
                false
            }
        } catch (_: Throwable) {
            prefs.edit().putString("model_status", "load_failed").apply()
            false
        } finally {
            synchronized(this) { modelLoading = false }
        }
    }

    fun ensureEmbeddingInMemory(): Boolean {
        if (embeddingLoaded) return true
        val path = prefs.getString("embedding_path", null)?.let(::File)
            ?: File(filesDir, "models/${DownloadEmbeddingWorker.EMBEDDING_FILE}")
        if (!path.exists()) return false
        return try {
            val rc = NativeVanelleBridge.loadEmbedding(path.absolutePath)
            if (rc == 0) {
                embeddingLoaded = true
                prefs.edit().putBoolean("embedding_loaded", true).putString("embedding_path", path.absolutePath).apply()
                true
            } else {
                embeddingLoaded = false
                prefs.edit().putBoolean("embedding_loaded", false).apply()
                false
            }
        } catch (_: Throwable) {
            embeddingLoaded = false
            false
        }
    }

    /** Compatible API 28+ (readNBytes est API 33). */
    private fun isGgufMagic(file: File): Boolean {
        return try {
            file.inputStream().use { input ->
                val b = ByteArray(4)
                var off = 0
                while (off < 4) {
                    val n = input.read(b, off, 4 - off)
                    if (n <= 0) break
                    off += n
                }
                off == 4 && b[0] == 'G'.code.toByte() && b[1] == 'G'.code.toByte() &&
                    b[2] == 'U'.code.toByte() && b[3] == 'F'.code.toByte()
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun modelFile(): File =
        prefs.getString("model_path", null)?.let(::File)
            ?: File(filesDir, "models/${DownloadModelWorker.MODEL_FILE}")

    private fun startModelDownload() {
        val modelPath = modelFile()
        val embPath = File(filesDir, "models/${DownloadEmbeddingWorker.EMBEDDING_FILE}")
        val modelOk = modelPath.exists() && prefs.getBoolean("model_downloaded", false)
        val embOk = embPath.exists() && prefs.getBoolean("embedding_downloaded", false)

        // Déjà tout téléchargé → charger en mémoire, ne pas relancer WorkManager
        if (modelOk && embOk) {
            ensureModelInMemory()
            ensureEmbeddingInMemory()
            return
        }

        val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        if (!modelOk) {
            // Si un ancien fichier existe mais n'est pas marqué OK, forcer un nouveau work
            val policy = try {
                val infos = WorkManager.getInstance(this).getWorkInfosForUniqueWork("vanelle-model").get(2, TimeUnit.SECONDS)
                val active = infos.any {
                    it.state == androidx.work.WorkInfo.State.RUNNING ||
                        it.state == androidx.work.WorkInfo.State.ENQUEUED ||
                        it.state == androidx.work.WorkInfo.State.BLOCKED
                }
                val bad = infos.any {
                    it.state == androidx.work.WorkInfo.State.FAILED ||
                        it.state == androidx.work.WorkInfo.State.CANCELLED
                }
                val status = prefs.getString("model_status", "")
                val force = status == "checksum_error" || status == "error" || status == "load_failed"
                when {
                    force || bad -> ExistingWorkPolicy.REPLACE
                    active -> ExistingWorkPolicy.KEEP
                    else -> ExistingWorkPolicy.REPLACE // SUCCEEDED but fichier manquant → relancer
                }
            } catch (_: Exception) {
                ExistingWorkPolicy.REPLACE
            }
            val request = OneTimeWorkRequestBuilder<DownloadModelWorker>()
                .setConstraints(net)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
                .build()
            WorkManager.getInstance(this).enqueueUniqueWork("vanelle-model", policy, request)
            val part = File(filesDir, "models/${DownloadModelWorker.MODEL_FILE}.part")
            if (!part.exists() && !prefs.getBoolean("model_downloaded", false)) {
                prefs.edit().putInt("model_progress", 0).putString("model_status", "starting").apply()
            }
        } else {
            ensureModelInMemory()
        }
        if (!embOk) {
            val embeddingRequest = OneTimeWorkRequestBuilder<DownloadEmbeddingWorker>()
                .setConstraints(net)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
                .build()
            WorkManager.getInstance(this).enqueueUniqueWork("vanelle-embedding", ExistingWorkPolicy.KEEP, embeddingRequest)
        } else {
            ensureEmbeddingInMemory()
        }
    }

    fun modelState(): String {
        val path = modelFile()
        if (nativeLoaded) return "ready"
        if (path.exists() && (prefs.getBoolean("model_downloaded", false) || path.length() > 100_000_000L)) {
            return "downloaded"
        }
        val status = prefs.getString("model_status", null)
        if (status == "network_interrupted") return "network_interrupted"
        return try {
            val infos = WorkManager.getInstance(this).getWorkInfosForUniqueWork("vanelle-model").get(2, TimeUnit.SECONDS)
            val running = infos.any { !it.state.isFinished }
            when {
                running -> "downloading"
                path.exists() -> "downloaded"
                else -> "missing"
            }
        } catch (_: Exception) {
            if (path.exists()) "downloaded" else "missing"
        }
    }

    fun modelProgress(): Int {
        return try {
            if (prefs.getBoolean("model_downloaded", false)) 100
            else {
                val infos = WorkManager.getInstance(this).getWorkInfosForUniqueWork("vanelle-model").get(2, TimeUnit.SECONDS)
                val fromWork = infos.firstOrNull()?.progress?.getInt("progress", -1) ?: -1
                if (fromWork >= 0) fromWork else prefs.getInt("model_progress", 0)
            }
        } catch (_: Exception) {
            prefs.getInt("model_progress", 0)
        }
    }

    /** Statut détaillé pour l'UI (downloading / network_interrupted / ready / …). */
    fun modelStatusDetail(): String = prefs.getString("model_status", modelState()) ?: modelState()

    fun generateLocal(prompt: String, maxTokens: Int): String {
        if (!ensureModelInMemory()) return ""
        return NativeVanelleBridge.generate(prompt, maxTokens)
    }

    fun nativeSystemInfo(): String = NativeVanelleBridge.info()

    fun embeddingState(): String {
        val path = prefs.getString("embedding_path", null)?.let(::File) ?: File(filesDir, "models/${DownloadEmbeddingWorker.EMBEDDING_FILE}")
        if (!path.exists()) {
            return try {
                val infos = WorkManager.getInstance(this).getWorkInfosForUniqueWork("vanelle-embedding").get(2, TimeUnit.SECONDS)
                if (infos.any { !it.state.isFinished }) "downloading" else "missing"
            } catch (_: Exception) { "missing" }
        }
        if (embeddingLoaded) return "ready"
        return "downloaded"
    }

    fun activateEmbedding(): String {
        val path = prefs.getString("embedding_path", null)?.let(::File)
            ?: File(filesDir, "models/${DownloadEmbeddingWorker.EMBEDDING_FILE}")
        if (path.exists()) {
            return if (ensureEmbeddingInMemory()) "ready" else "downloaded"
        }
        startModelDownload()
        return "downloading"
    }

    fun embed(text: String): String {
        if (!ensureEmbeddingInMemory()) return ""
        return NativeVanelleBridge.embed(text).joinToString(",")
    }

    fun openModelPicker() { modelPicker.launch(arrayOf("application/octet-stream", "application/*")) }

    /**
     * Enregistre un fichier (reçu en base64 depuis le JS, car le WebView Android ne gère pas
     * les téléchargements de blob: déclenchés par <a download>) dans le dossier Téléchargements
     * public de l'appareil. Retourne "saved", "permission_pending" ou "error".
     */
    fun saveFile(filename: String, mimeType: String, base64Data: String): String {
        val safeName = filename.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "vanelle-export.bin" }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSave = Triple(safeName, mimeType, base64Data)
            runOnUiThread { storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) }
            return "permission_pending"
        }
        return writeToDownloads(safeName, mimeType, base64Data)
    }

    private fun writeToDownloads(filename: String, mimeType: String, base64Data: String): String {
        return try {
            val bytes = android.util.Base64.decode(base64Data, android.util.Base64.DEFAULT)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, filename)
                    put(MediaStore.Downloads.MIME_TYPE, mimeType)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return "error"
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return "error"
                values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
                "saved"
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                var target = File(dir, filename)
                if (target.exists()) {
                    val base = filename.substringBeforeLast('.', filename)
                    val ext = filename.substringAfterLast('.', "")
                    target = File(dir, "$base-${System.currentTimeMillis()}${if (ext.isNotBlank()) ".$ext" else ""}")
                }
                target.outputStream().use { it.write(bytes) }
                "saved"
            }
        } catch (_: Exception) {
            "error"
        }
    }

    fun saveRemote(endpoint: String, model: String, apiKey: String): String {
        val ep = endpoint.trim().trimEnd('/')
        val md = model.trim()
        if (ep.isBlank() || md.isBlank()) return "invalid"
        if (!ep.startsWith("https://", ignoreCase = true)) return "invalid_https"
        prefs.edit()
            .putString("remote_endpoint", ep)
            .putString("remote_model", md)
            .apply()
        secret.put("remote_key", apiKey)
        return "saved"
    }

    fun remoteState(): String =
        if (prefs.getString("remote_endpoint", null).isNullOrBlank()) "not_configured" else "configured"

    fun remoteEndpoint(): String = prefs.getString("remote_endpoint", "") ?: ""
    fun remoteModel(): String = prefs.getString("remote_model", "") ?: ""

    fun generateRemote(prompt: String, maxTokens: Int): String {
        // Compat : un seul message utilisateur
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", prompt))
        return generateRemoteMessages(messages, maxTokens)
    }

    /** messagesJson = JSON array [{role, content}, ...] */
    fun generateRemoteChat(messagesJson: String, maxTokens: Int): String {
        return try {
            val messages = JSONArray(messagesJson)
            generateRemoteMessages(messages, maxTokens)
        } catch (_: Exception) {
            ""
        }
    }

    private fun generateRemoteMessages(messages: JSONArray, maxTokens: Int): String {
        val endpoint = prefs.getString("remote_endpoint", null) ?: return ""
        val model = prefs.getString("remote_model", null) ?: return ""
        val key = secret.get("remote_key") ?: ""
        return try {
            val base = endpoint.trimEnd('/')
            val urlStr = when {
                base.endsWith("/chat/completions") -> base
                base.endsWith("/v1") -> "$base/chat/completions"
                else -> "$base/chat/completions"
            }
            val url = URL(urlStr)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 120_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                if (key.isNotBlank()) setRequestProperty("Authorization", "Bearer $key")
            }
            val body = JSONObject().apply {
                put("model", model)
                put("messages", messages)
                put("temperature", 0.35)
                put("max_tokens", maxTokens.coerceIn(32, 1024))
            }.toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val response = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: return ""
            if (code !in 200..299) return ""
            JSONObject(response).optJSONArray("choices")
                ?.optJSONObject(0)
                ?.optJSONObject("message")
                ?.optString("content", "")
                ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    private fun adaptiveContext(): Int {
        // maxMemory() Android = limite heap (souvent 256–512 Mo), pas la RAM totale.
        val heapMb = Runtime.getRuntime().maxMemory() / (1024L * 1024L)
        val memClass = try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            am.largeMemoryClass // Mo approximatifs disponibles pour largeHeap
        } catch (_: Exception) {
            heapMb.toInt()
        }
        return when {
            memClass >= 512 || heapMb >= 400 -> 4096
            memClass >= 384 || heapMb >= 300 -> 3072
            else -> 2048
        }
    }

    override fun onDestroy() {
        if (nativeLoaded) {
            try { NativeVanelleBridge.unload() } catch (_: Throwable) {}
            nativeLoaded = false
        }
        if (embeddingLoaded) {
            try { NativeVanelleBridge.unloadEmbedding() } catch (_: Throwable) {}
            embeddingLoaded = false
        }
        prefs.edit().putBoolean("embedding_loaded", false).apply()
        try { ioExecutor.shutdownNow() } catch (_: Exception) {}
        // Évite fuite WebView (callbacks + JS interface)
        try {
            if (::web.isInitialized) {
                web.loadUrl("about:blank")
                web.stopLoading()
                web.clearHistory()
                web.removeAllViews()
                web.destroy()
            }
        } catch (_: Exception) {}
        super.onDestroy()
    }
}
