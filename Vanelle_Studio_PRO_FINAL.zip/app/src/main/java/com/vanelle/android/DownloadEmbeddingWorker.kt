package com.vanelle.android

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Télécharge le modèle d'embeddings avec reprise HTTP Range, notification
 * foreground et gestion des interruptions réseau.
 */
class DownloadEmbeddingWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            setForeground(
                DownloadNotifications.foregroundInfo(
                    applicationContext,
                    DownloadNotifications.EMBED_NOTIF_ID,
                    "Vanelle — embeddings",
                    0,
                    indeterminate = true
                )
            )
            downloadWithRetries()
            applicationContext.getSharedPreferences(DownloadModelWorker.PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("embedding_downloaded", true)
                .putString("embedding_path", File(applicationContext.filesDir, "models/$EMBEDDING_FILE").absolutePath)
                .putString("embedding_status", "ready")
                .apply()
            setForeground(
                DownloadNotifications.foregroundInfo(
                    applicationContext,
                    DownloadNotifications.EMBED_NOTIF_ID,
                    "Vanelle — embeddings",
                    100
                )
            )
            Result.success()
        } catch (e: Exception) {
            val status = if (DownloadModelWorker.isNetworkError(e)) "network_interrupted" else "error"
            applicationContext.getSharedPreferences(DownloadModelWorker.PREFS, Context.MODE_PRIVATE).edit()
                .putString("embedding_status", status)
                .apply()
            Result.retry()
        }
    }

    private suspend fun downloadWithRetries() {
        var lastError: Exception? = null
        for (attempt in 1..MAX_INTERNAL_ATTEMPTS) {
            try {
                downloadOnce()
                return
            } catch (e: Exception) {
                lastError = e
                if (!DownloadModelWorker.isNetworkError(e) || attempt == MAX_INTERNAL_ATTEMPTS) throw e
                kotlinx.coroutines.delay(1500L * attempt)
            }
        }
        throw lastError ?: IllegalStateException("download-failed")
    }

    private suspend fun downloadOnce() {
        val dir = File(applicationContext.filesDir, "models").apply { mkdirs() }
        val target = File(dir, EMBEDDING_FILE)
        val part = File(dir, "$EMBEDDING_FILE.part")
        var existing = if (part.exists()) part.length() else 0L
        var conn = open(existing)
        if (existing > 0 && conn.responseCode == HttpURLConnection.HTTP_OK) {
            conn.disconnect(); part.delete(); existing = 0L; conn = open(0)
        }
        if (conn.responseCode !in listOf(200, 206)) {
            val code = conn.responseCode
            conn.disconnect()
            throw IOException("HTTP $code")
        }
        val append = existing > 0 && conn.responseCode == 206
        val total = if (conn.responseCode == 206) existing + conn.contentLengthLong else conn.contentLengthLong
        var done = existing
        try {
            conn.inputStream.use { input ->
                FileOutputStream(part, append).use { out ->
                    val b = ByteArray(512 * 1024)
                    while (true) {
                        val n = try {
                            input.read(b)
                        } catch (e: Exception) {
                            out.flush()
                            persistProgress(done, total, "network_interrupted")
                            throw e
                        }
                        if (n < 0) break
                        out.write(b, 0, n)
                        done += n
                        val p = if (total > 0) ((done * 100L) / total).toInt().coerceIn(0, 100) else 0
                        setProgress(workDataOf("progress" to p, "bytes" to done, "total" to total))
                        if (p % 2 == 0 || done == total) {
                            persistProgress(done, total, "downloading")
                            setForeground(
                                DownloadNotifications.foregroundInfo(
                                    applicationContext,
                                    DownloadNotifications.EMBED_NOTIF_ID,
                                    "Vanelle — embeddings",
                                    p
                                )
                            )
                        }
                    }
                    out.flush()
                }
            }
        } finally {
            try { conn.disconnect() } catch (_: Exception) {}
        }
        if (total > 0 && done != total) {
            persistProgress(done, total, "network_interrupted")
            throw IOException("incomplete: $done/$total")
        }
        val magic = part.inputStream().use { it.readNBytes(4) }
        if (!magic.contentEquals(byteArrayOf('G'.code.toByte(), 'G'.code.toByte(), 'U'.code.toByte(), 'F'.code.toByte()))) {
            part.delete(); throw IllegalStateException("invalid-gguf")
        }
        if (part.length() < 10L * 1024L * 1024L) {
            part.delete(); throw IllegalStateException("invalid-size")
        }
        if (sha256(part) != EMBEDDING_SHA256) {
            part.delete(); throw IllegalStateException("checksum")
        }
        if (!part.renameTo(target)) throw IllegalStateException("rename")
    }

    private fun persistProgress(done: Long, total: Long, status: String) {
        val pct = if (total > 0) ((done * 100L) / total).toInt().coerceIn(0, 100) else 0
        applicationContext.getSharedPreferences(DownloadModelWorker.PREFS, Context.MODE_PRIVATE).edit()
            .putInt("embedding_progress", pct)
            .putString("embedding_status", status)
            .apply()
    }

    private fun sha256(file: File): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val b = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(b)
                if (n < 0) break
                md.update(b, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun open(range: Long): HttpURLConnection =
        (URL(EMBEDDING_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("Connection", "close")
            if (range > 0) setRequestProperty("Range", "bytes=$range-")
        }

    companion object {
        const val EMBEDDING_FILE = "Vanelle-all-MiniLM-L6-v2-Q4_K_M.gguf"
        const val EMBEDDING_SHA256 = "2ec4cee28a27a9c973d5f5230930d6ef6e52694bd2bc71be26a9bef5b1d755e6"
        const val EMBEDDING_URL =
            "https://huggingface.co/second-state/All-MiniLM-L6-v2-Embedding-GGUF/resolve/main/all-MiniLM-L6-v2-Q4_K_M.gguf?download=true"
        private const val MAX_INTERNAL_ATTEMPTS = 4
    }
}
