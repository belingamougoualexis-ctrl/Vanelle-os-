package com.vanelle.android

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.security.MessageDigest

/**
 * Télécharge le modèle conversationnel avec reprise HTTP Range, notification
 * foreground et gestion des interruptions réseau.
 */
class DownloadModelWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            setForeground(
                DownloadNotifications.foregroundInfo(
                    applicationContext,
                    DownloadNotifications.MODEL_NOTIF_ID,
                    "Vanelle — moteur IA",
                    0,
                    indeterminate = true
                )
            )
            downloadWithRetries(
                MODEL_URL,
                File(applicationContext.filesDir, "models/$MODEL_FILE"),
                MODEL_SHA256,
                "model"
            )
            applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("model_downloaded", true)
                .putInt("model_progress", 100)
                .putString("model_status", "ready")
                .putString("model_path", File(applicationContext.filesDir, "models/$MODEL_FILE").absolutePath)
                .apply()
            setForeground(
                DownloadNotifications.foregroundInfo(
                    applicationContext,
                    DownloadNotifications.MODEL_NOTIF_ID,
                    "Vanelle — moteur IA",
                    100
                )
            )
            Result.success()
        } catch (e: Exception) {
            val status = if (isNetworkError(e)) "network_interrupted" else "error"
            applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("model_status", status)
                .apply()
            Result.retry()
        }
    }

    private suspend fun downloadWithRetries(url: String, target: File, expectedSha: String?, key: String) {
        var lastError: Exception? = null
        for (attempt in 1..MAX_INTERNAL_ATTEMPTS) {
            try {
                download(url, target, expectedSha, key)
                return
            } catch (e: Exception) {
                lastError = e
                if (!isNetworkError(e) || attempt == MAX_INTERNAL_ATTEMPTS) throw e
                kotlinx.coroutines.delay(1500L * attempt)
            }
        }
        throw lastError ?: IllegalStateException("download-failed")
    }

    private suspend fun download(url: String, target: File, expectedSha: String?, key: String) {
        target.parentFile?.mkdirs()
        val part = File(target.parentFile, target.name + ".part")
        var existing = if (part.exists()) part.length() else 0L
        var conn = open(url, existing)
        if (existing > 0 && conn.responseCode == HttpURLConnection.HTTP_OK) {
            conn.disconnect()
            part.delete()
            existing = 0L
            conn = open(url, 0L)
        }
        if (conn.responseCode !in listOf(HttpURLConnection.HTTP_OK, HttpURLConnection.HTTP_PARTIAL)) {
            val code = conn.responseCode
            conn.disconnect()
            throw IOException("HTTP $code")
        }
        val append = existing > 0 && conn.responseCode == HttpURLConnection.HTTP_PARTIAL
        val total = if (conn.responseCode == HttpURLConnection.HTTP_PARTIAL) {
            existing + conn.contentLengthLong
        } else {
            conn.contentLengthLong
        }
        var done = existing
        try {
            conn.inputStream.use { input ->
                FileOutputStream(part, append).use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    while (true) {
                        val n = try {
                            input.read(buffer)
                        } catch (e: Exception) {
                            output.flush()
                            persistProgress(done, total, "network_interrupted")
                            throw e
                        }
                        if (n < 0) break
                        output.write(buffer, 0, n)
                        done += n
                        val pct = if (total > 0) ((done * 100L) / total).toInt().coerceIn(0, 100) else 0
                        setProgress(workDataOf("progress" to pct, "bytes" to done, "total" to total, "key" to key))
                        if (pct % 2 == 0 || done == total) {
                            persistProgress(done, total, "downloading")
                            setForeground(
                                DownloadNotifications.foregroundInfo(
                                    applicationContext,
                                    DownloadNotifications.MODEL_NOTIF_ID,
                                    "Vanelle — moteur IA",
                                    pct
                                )
                            )
                        }
                    }
                    output.flush()
                }
            }
        } finally {
            try { conn.disconnect() } catch (_: Exception) {}
        }
        if (total > 0 && done != total) {
            persistProgress(done, total, "network_interrupted")
            throw IOException("incomplete: $done/$total")
        }
        if (expectedSha != null && sha256(part) != expectedSha.lowercase()) {
            part.delete()
            throw IllegalStateException("checksum")
        }
        if (!part.renameTo(target)) {
            part.delete()
            throw IllegalStateException("rename")
        }
    }

    private fun persistProgress(done: Long, total: Long, status: String) {
        val pct = if (total > 0) ((done * 100L) / total).toInt().coerceIn(0, 100) else 0
        applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("model_progress", pct)
            .putLong("model_bytes", done)
            .putLong("model_total", total)
            .putString("model_status", status)
            .apply()
    }

    private fun open(url: String, range: Long): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("Connection", "close")
            if (range > 0) setRequestProperty("Range", "bytes=$range-")
        }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val b = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(b)
                if (n < 0) break
                md.update(b, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    companion object {
        const val PREFS = "vanelle_model"
        const val MODEL_FILE = "Vanelle-Qwen2.5-0.5B-Instruct-Q4_K_M.gguf"
        const val MODEL_URL =
            "https://huggingface.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/Qwen2.5-0.5B-Instruct-Q4_K_M.gguf?download=true"
        const val MODEL_SHA256 = "fa4d41b65761ed565cac6b5f62e35135d050408b033114a128ab308c02b2e83a"
        private const val MAX_INTERNAL_ATTEMPTS = 4

        fun isNetworkError(e: Throwable): Boolean {
            var t: Throwable? = e
            while (t != null) {
                when (t) {
                    is UnknownHostException,
                    is SocketTimeoutException,
                    is SocketException,
                    is IOException -> {
                        val msg = (t.message ?: "").lowercase()
                        if (msg.contains("checksum") || msg.contains("rename")) return false
                        return true
                    }
                }
                t = t.cause
            }
            return false
        }
    }
}
