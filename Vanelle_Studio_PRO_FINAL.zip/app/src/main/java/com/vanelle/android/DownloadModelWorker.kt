package com.vanelle.android

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.security.MessageDigest

/**
 * Télécharge Qwen2.5-0.5B-Instruct Q4_K_M (~398 Mo) depuis Hugging Face.
 *
 * SHA-256 officiel (HF LFS / x-linked-etag, sept. 2024+) :
 * 6eb923e7d26e9cea28811e1a8e852009b21242fb157b26149d3b188f3a8c8653
 * Taille : 397808192 octets
 */
class DownloadModelWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            val target = File(applicationContext.filesDir, "models/$MODEL_FILE")
            if (isValidModel(target)) {
                markSuccess(target)
                return Result.success()
            }
            // Fichier corrompu / ancien hash → supprimer et retélécharger
            if (target.exists()) target.delete()
            val part = File(target.parentFile, target.name + ".part")
            // Si .part a une taille absurde par rapport à la taille attendue, repartir de 0
            if (part.exists() && part.length() > MODEL_SIZE_BYTES + 1024L) part.delete()

            safeSetForeground(
                DownloadNotifications.foregroundInfo(
                    applicationContext,
                    DownloadNotifications.MODEL_NOTIF_ID,
                    "Vanelle — moteur IA",
                    0,
                    indeterminate = true
                )
            )
            downloadWithRetries(MODEL_URL, target)
            if (!isValidModel(target)) {
                target.delete()
                throw IllegalStateException("checksum")
            }
            markSuccess(target)
            safeSetForeground(
                DownloadNotifications.foregroundInfo(
                    applicationContext,
                    DownloadNotifications.MODEL_NOTIF_ID,
                    "Vanelle — moteur IA",
                    100
                )
            )
            Result.success()
        } catch (e: Exception) {
            val status = when {
                e.message?.contains("checksum") == true -> "checksum_error"
                isNetworkError(e) -> "network_interrupted"
                else -> "error"
            }
            applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("model_status", status)
                .putString("model_last_error", e.message ?: e.javaClass.simpleName)
                .apply()
            // Ne pas boucler à l'infini sur checksum / erreur logique
            if (isNetworkError(e)) Result.retry() else Result.failure()
        }
    }

    private fun isValidModel(file: File): Boolean {
        if (!file.exists()) return false
        if (file.length() < MODEL_SIZE_BYTES - 1024L || file.length() > MODEL_SIZE_BYTES + 1024L) return false
        if (!isGguf(file)) return false
        return sha256(file) == MODEL_SHA256
    }

    private fun markSuccess(target: File) {
        applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("model_downloaded", true)
            .putInt("model_progress", 100)
            .putString("model_status", "downloaded")
            .putString("model_path", target.absolutePath)
            .remove("model_last_error")
            .apply()
    }

    private suspend fun downloadWithRetries(url: String, target: File) {
        var lastError: Exception? = null
        for (attempt in 1..MAX_INTERNAL_ATTEMPTS) {
            try {
                download(url, target)
                return
            } catch (e: Exception) {
                lastError = e
                if (!isNetworkError(e) || attempt == MAX_INTERNAL_ATTEMPTS) throw e
                kotlinx.coroutines.delay(2000L * attempt)
            }
        }
        throw lastError ?: IllegalStateException("download-failed")
    }

    private suspend fun download(url: String, target: File) {
        target.parentFile?.mkdirs()
        val part = File(target.parentFile, target.name + ".part")
        var existing = if (part.exists()) part.length() else 0L
        // Si reprise dépasse la taille connue, repartir à 0
        if (existing > MODEL_SIZE_BYTES) {
            part.delete()
            existing = 0L
        }
        var conn = open(url, existing)
        // Serveur ignore Range → 200 : recommencer
        if (existing > 0 && conn.responseCode == HttpURLConnection.HTTP_OK) {
            conn.disconnect()
            part.delete()
            existing = 0L
            conn = open(url, 0L)
        }
        if (conn.responseCode !in listOf(HttpURLConnection.HTTP_OK, HttpURLConnection.HTTP_PARTIAL)) {
            val code = conn.responseCode
            conn.disconnect()
            throw IOException("HTTP $code")
        }
        val append = existing > 0 && conn.responseCode == HttpURLConnection.HTTP_PARTIAL
        // contentLengthLong peut être -1 sur certains CDN ; utiliser taille connue HF
        val declared = conn.contentLengthLong
        val total = when {
            conn.responseCode == HttpURLConnection.HTTP_PARTIAL && declared > 0 -> existing + declared
            declared > 0 -> declared
            else -> MODEL_SIZE_BYTES
        }
        var done = existing
        try {
            conn.inputStream.use { input ->
                FileOutputStream(part, append).use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    while (true) {
                        val n = try {
                            input.read(buffer)
                        } catch (e: Exception) {
                            output.flush()
                            persistProgress(done, total, "network_interrupted")
                            throw e
                        }
                        if (n < 0) break
                        output.write(buffer, 0, n)
                        done += n
                        val pct = if (total > 0) ((done * 100L) / total).toInt().coerceIn(0, 100) else 0
                        setProgress(workDataOf("progress" to pct, "bytes" to done, "total" to total, "key" to "model"))
                        if (pct % 2 == 0 || done >= total) {
                            persistProgress(done, total, "downloading")
                            safeSetForeground(
                                DownloadNotifications.foregroundInfo(
                                    applicationContext,
                                    DownloadNotifications.MODEL_NOTIF_ID,
                                    "Vanelle — moteur IA",
                                    pct
                                )
                            )
                        }
                    }
                    output.flush()
                }
            }
        } finally {
            try { conn.disconnect() } catch (_: Exception) {}
        }
        // Tolérance : si le CDN n'a pas envoyé Content-Length exact
        if (done < MODEL_SIZE_BYTES - 1024L) {
            persistProgress(done, total, "network_interrupted")
            throw IOException("incomplete: $done/$MODEL_SIZE_BYTES")
        }
        if (sha256(part) != MODEL_SHA256) {
            part.delete()
            throw IllegalStateException("checksum")
        }
        if (target.exists()) target.delete()
        if (!part.renameTo(target)) {
            part.copyTo(target, overwrite = true)
            part.delete()
            if (!target.exists()) throw IllegalStateException("rename")
        }
    }

    private fun persistProgress(done: Long, total: Long, status: String) {
        val pct = if (total > 0) ((done * 100L) / total).toInt().coerceIn(0, 100) else 0
        applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("model_progress", pct)
            .putLong("model_bytes", done)
            .putLong("model_total", total)
            .putString("model_status", status)
            .apply()
    }

    private fun open(url: String, range: Long): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 120_000
            instanceFollowRedirects = true
            // User-Agent requis par certains CDN Hugging Face
            setRequestProperty("User-Agent", "VanelleAndroid/1.0 (Android; llama.cpp)")
            setRequestProperty("Accept", "*/*")
            if (range > 0) setRequestProperty("Range", "bytes=$range-")
        }


    private fun readMagic4(file: File): ByteArray {
        file.inputStream().use { input ->
            val b = ByteArray(4)
            var off = 0
            while (off < 4) {
                val n = input.read(b, off, 4 - off)
                if (n <= 0) break
                off += n
            }
            return if (off == 4) b else ByteArray(0)
        }
    }

    private fun isGguf(file: File): Boolean {
        val m = readMagic4(file)
        return m.size == 4 && m[0] == 'G'.code.toByte() && m[1] == 'G'.code.toByte() &&
            m[2] == 'U'.code.toByte() && m[3] == 'F'.code.toByte()
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val b = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(b)
                if (n < 0) break
                md.update(b, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    companion object {
        const val PREFS = "vanelle_model"
        const val MODEL_FILE = "Vanelle-Qwen2.5-0.5B-Instruct-Q4_K_M.gguf"
        /** URL resolve Hugging Face (suit les redirections CDN / Xet). */
        const val MODEL_URL =
            "https://huggingface.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/Qwen2.5-0.5B-Instruct-Q4_K_M.gguf"
        /** SHA-256 LFS officiel (x-linked-etag Hugging Face). */
        const val MODEL_SHA256 = "6eb923e7d26e9cea28811e1a8e852009b21242fb157b26149d3b188f3a8c8653"
        const val MODEL_SIZE_BYTES = 397_808_192L
        private const val MAX_INTERNAL_ATTEMPTS = 5

        fun isNetworkError(e: Throwable): Boolean {
            var t: Throwable? = e
            while (t != null) {
                when (t) {
                    is UnknownHostException,
                    is SocketTimeoutException,
                    is SocketException -> return true
                    is IOException -> {
                        val msg = (t.message ?: "").lowercase()
                        if (msg.contains("checksum") || msg.contains("rename")) return false
                        return true
                    }
                    is IllegalStateException -> {
                        val msg = (t.message ?: "").lowercase()
                        if (msg.contains("checksum")) return false
                    }
                }
                t = t.cause
            }
            return false
        }
    }
}
