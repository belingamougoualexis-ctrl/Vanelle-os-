package com.vanelle.android

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.ForegroundInfo

object DownloadNotifications {
    const val CHANNEL_ID = "vanelle_downloads"
    const val MODEL_NOTIF_ID = 4101
    const val EMBED_NOTIF_ID = 4102

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val mgr = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (mgr.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Téléchargements Vanelle",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Progression du téléchargement du moteur Vanelle"
            setShowBadge(false)
        }
        mgr.createNotificationChannel(channel)
    }

    fun foregroundInfo(
        context: Context,
        notificationId: Int,
        title: String,
        progress: Int,
        indeterminate: Boolean = false
    ): ForegroundInfo {
        ensureChannel(context)
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(
                when {
                    indeterminate -> "Préparation…"
                    progress >= 100 -> "Terminé"
                    else -> "Téléchargement $progress %"
                }
            )
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOnlyAlertOnce(true)
            .setOngoing(progress < 100)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
        if (!indeterminate) {
            builder.setProgress(100, progress.coerceIn(0, 100), false)
        } else {
            builder.setProgress(0, 0, true)
        }
        val notification = builder.build()
        // Type dataSync requis Android 14+ ; constante compileSdk 34+, valeur ignorée en dessous.
        return if (Build.VERSION.SDK_INT >= 29) {
            @Suppress("InlinedApi")
            ForegroundInfo(
                notificationId,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            ForegroundInfo(notificationId, notification)
        }
    }
}

/**
 * setForeground peut lever une exception (permission notification refusée,
 * type de service non déclaré, etc.). On ne doit pas faire échouer le download pour ça.
 */
suspend fun androidx.work.CoroutineWorker.safeSetForeground(info: ForegroundInfo) {
    try {
        setForeground(info)
    } catch (_: Exception) {
        // ignore — le téléchargement continue sans notification
    }
}
