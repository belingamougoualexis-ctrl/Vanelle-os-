# Vanelle — Android natif, llama.cpp + RAG local

## Fonctionnalités

- inference LLM **réelle** avec llama.cpp natif Android/ARM64
- modèle conversationnel Qwen2.5-0.5B-Instruct Q4_K_M (~398 MB)
- téléchargement **immédiat à l'ouverture** (aucun consentement bloquant), WorkManager + notification foreground
- reprise HTTP Range + retries + backoff exponentiel en cas de coupure réseau
- vérification SHA-256 des modèles
- embeddings natifs all-MiniLM-L6-v2 Q4_K_M (~21.3 MB)
- ETL : extraction, nettoyage, chunking, embeddings, index local, cosine RAG
- mémoire persistante IndexedDB
- import GGUF compatible (magic GGUF)
- ZIP données jusqu'à **3 Go** via streaming natif (`ZipInputStream`)
- ZIP légers via JSZip dans le WebView
- moteur distant OpenAI-compatible, clé Android Keystore
- mode hors ligne après téléchargement
- GitHub Actions pour APK ARM64 release

## Ouverture de l'app

1. `startModelDownload()` est appelé **immédiatement** dans `onCreate`
2. Permission `POST_NOTIFICATIONS` demandée ensuite (non bloquante) pour afficher la barre de progression
3. Aucun écran de consentement

## Compilation

```bash
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
```

llama.cpp pin : `b10516`.
