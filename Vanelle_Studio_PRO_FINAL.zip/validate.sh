#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
node --check "$ROOT/app/src/main/assets/app.js"
test -f "$ROOT/app/src/main/cpp/vanelle_jni.cpp"
test -f "$ROOT/app/src/main/java/com/vanelle/android/NativeVanelle.kt"
test -f "$ROOT/app/src/main/java/com/vanelle/android/DownloadModelWorker.kt"
test -f "$ROOT/app/src/main/java/com/vanelle/android/DownloadEmbeddingWorker.kt"
grep -q 'Qwen2.5-0.5B-Instruct-Q4_K_M' "$ROOT/app/src/main/java/com/vanelle/android/DownloadModelWorker.kt"
grep -q 'all-MiniLM-L6-v2-Q4_K_M' "$ROOT/app/src/main/java/com/vanelle/android/DownloadEmbeddingWorker.kt"
grep -q 'llama_model_load_from_file' "$ROOT/app/src/main/cpp/vanelle_jni.cpp"
grep -q 'llama_get_embeddings_seq' "$ROOT/app/src/main/cpp/vanelle_jni.cpp"
if grep -RniE 'webllm|@mlc-ai|transformers@|CreateMLCEngine|q4f16_1-MLC' "$ROOT/app/src/main"; then
  echo 'ERROR: stale web inference references found'; exit 1
fi
python3 - <<PY2
from pathlib import Path
root=Path(r'''$ROOT''')
text_ext={'.kt','.kts','.cpp','.h','.cmake','.xml','.json','.js','.css','.html','.sh','.md','.properties','.gradle'}
for f in root.rglob('*'):
    if f.is_file() and f.suffix.lower() in text_ext and b'\x00' in f.read_bytes():
        raise SystemExit(f'ERROR: NUL byte found in {f}')
PY2
grep -q 'https://huggingface.co/second-state/All-MiniLM-L6-v2-Embedding-GGUF' "$ROOT/app/src/main/java/com/vanelle/android/DownloadEmbeddingWorker.kt"
grep -q '2ec4cee28a27a9c973d5f5230930d6ef6e52694bd2bc71be26a9bef5b1d755e6' "$ROOT/app/src/main/java/com/vanelle/android/DownloadEmbeddingWorker.kt"
if grep -RniE 'cdnjs.cloudflare.com|My Own AI|MY OWN AI|webllm|@mlc-ai|CreateMLCEngine|q4f16_1-MLC' "$ROOT/app/src/main"; then echo 'ERROR: stale external/runtime references found'; exit 1; fi
echo 'Vanelle source validation: OK'
