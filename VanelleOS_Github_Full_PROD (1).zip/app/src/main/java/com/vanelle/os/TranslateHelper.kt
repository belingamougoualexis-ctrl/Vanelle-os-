package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.net.Uri
class TranslateHelper(private val c:Context){
    fun translate(t:String)= try{ val u="https://translate.google.com/?sl=auto&tl=auto&text=${Uri.encode(t)}&op=translate"; val i=Intent(Intent.ACTION_VIEW,Uri.parse(u)).apply{ addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }; c.startActivity(i); true }catch(_:Exception){ false }
}
