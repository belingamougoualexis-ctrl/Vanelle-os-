package com.vanelle.os
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
class ContactsRepository(private val context:Context){
    fun call(name:String):String{
        if(name.isBlank()) return "Nom requis"
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED) return "Permission contacts requise"
        var num:String?=null
        val safe=name.replace("\\","\\\\").replace("%","\%").replace("_","\_")
        val cur=try{ context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),"${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ? ESCAPE '\\'",arrayOf("%$safe%"),null) }catch(_:Exception){ null }
        cur?.use{ if(it.moveToFirst()){ val idx=it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER); if(idx>=0) num=it.getString(idx) } }
        if(num.isNullOrBlank()) return "Contact introuvable"
        return try{ val i=Intent(Intent.ACTION_DIAL,Uri.fromParts("tel",num,null)).apply{ addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }; context.startActivity(i); "Appel ouvert" }catch(_:Exception){ "Impossible" }
    }
}
