package com.vanelle.os
import android.app.*
import android.content.Intent
import android.os.IBinder
import android.speech.*
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
class WakeWordService:Service(){
    private var rec:SpeechRecognizer?=null
    private val scope=CoroutineScope(Dispatchers.Main+SupervisorJob())
    override fun onBind(i:Intent?):IBinder?=null
    override fun onCreate(){
        super.onCreate()
        val id="vanelle_wake"
        val nm=getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(id,"Vanelle",NotificationManager.IMPORTANCE_LOW))
        val n=NotificationCompat.Builder(this,id).setContentTitle("VanelleOS").setContentText("Ecoute active").setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        startForeground(1,n)
        listen()
    }
    private fun listen(){
        if(!SpeechRecognizer.isRecognitionAvailable(this)) return
        rec?.destroy()
        rec=SpeechRecognizer.createSpeechRecognizer(this).apply{
            setRecognitionListener(object:RecognitionListener{
                override fun onResults(r:Bundle?){ val t=r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""; handle(t); restart() }
                override fun onError(e:Int){ restart() }
                override fun onReadyForSpeech(p:Bundle?){}
                override fun onBeginningOfSpeech(){}
                override fun onRmsChanged(v:Float){}
                override fun onBufferReceived(b:ByteArray?){}
                override fun onEndOfSpeech(){}
                override fun onEvent(t:Int,p:Bundle?){}
                override fun onPartialResults(p:Bundle?){}
            })
            val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE,"fr-FR")
            }
            try{ startListening(intent) }catch(_:Exception){}
        }
    }
    private fun handle(text:String){
        val lower=text.lowercase()
        if(!lower.contains("vanelle")) return
        val cmd=lower.substringAfter("vanelle").trim().ifEmpty{ lower }
        scope.launch{
            val res=CommandInterpreter(this@WakeWordService).execute(cmd)
            try{
                val i=Intent(this@WakeWordService,MainActivity::class.java).apply{
                    putExtra("voice_text",cmd); putExtra("voice_result",res)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(i)
            }catch(_:Exception){}
        }
    }
    private fun restart(){ scope.launch{ delay(800); listen() } }
    override fun onDestroy(){ rec?.destroy(); scope.cancel(); super.onDestroy() }
    override fun onStartCommand(i:Intent?,f:Int,s:Int)= START_STICKY
}
