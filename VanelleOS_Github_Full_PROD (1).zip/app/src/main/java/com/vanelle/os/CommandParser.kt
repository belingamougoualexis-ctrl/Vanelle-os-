package com.vanelle.os
enum class CommandIntent{UNKNOWN,OPEN_APP,CALL_CONTACT,SEARCH_WEB,YOUTUBE,TRANSLATE,MEMORY_SAVE,MEMORY_GET,MEMORY_CLEAR,EMERGENCY,BATTERY,RESTAURANT,TOOL,LOST_PHONE,MAPS,ACCESSIBILITY_ACTION}
data class ParsedCommand(val intent:CommandIntent,val args:Map<String,String>)
object CommandParser{
    fun parse(input:String):ParsedCommand{
        val t=input.lowercase().trim()
        if(t.contains("n'ouvre pas")) return ParsedCommand(CommandIntent.UNKNOWN,emptyMap())
        if(t.contains("urgence")||t.contains("sos")) return ParsedCommand(CommandIntent.EMERGENCY,emptyMap())
        if(t.contains("retrouve mon telephone")) return ParsedCommand(CommandIntent.LOST_PHONE,emptyMap())
        if(t.contains("batterie")) return ParsedCommand(CommandIntent.BATTERY,emptyMap())
        if(t.contains("retour")||t.contains("revenir")) return ParsedCommand(CommandIntent.ACCESSIBILITY_ACTION,mapOf("action" to "back"))
        if(t.contains("accueil")||t.contains("home")) return ParsedCommand(CommandIntent.ACCESSIBILITY_ACTION,mapOf("action" to "home"))
        if(t.contains("notification")) return ParsedCommand(CommandIntent.ACCESSIBILITY_ACTION,mapOf("action" to "notifications"))
        if(t.contains("recents")) return ParsedCommand(CommandIntent.ACCESSIBILITY_ACTION,mapOf("action" to "recents"))
        if(t.startsWith("ouvre ")||t.startsWith("lance ")) return ParsedCommand(CommandIntent.OPEN_APP,mapOf("app" to input.substringAfter(" ").trim()))
        if(t.startsWith("appelle ")) return ParsedCommand(CommandIntent.CALL_CONTACT,mapOf("name" to input.substring(8).trim()))
        if(t.startsWith("cherche ")) return ParsedCommand(CommandIntent.SEARCH_WEB,mapOf("query" to input.substringAfter(" ").trim()))
        if(t.contains("youtube")) return ParsedCommand(CommandIntent.YOUTUBE,mapOf("query" to input.replace("youtube","",true).trim()))
        if(t.startsWith("traduis ")) return ParsedCommand(CommandIntent.TRANSLATE,mapOf("text" to input.substring(8).trim()))
        if(t.startsWith("souviens toi que ")||t.startsWith("retiens que ")){
            val raw=input.substringAfter(" que ").trim()
            val key=raw.substringBefore(" est ").substringBefore(" = ").take(40).trim().lowercase()
            return ParsedCommand(CommandIntent.MEMORY_SAVE,mapOf("key" to key.ifEmpty{"note_${System.currentTimeMillis()}"}, "data" to raw))
        }
        if(t.startsWith("rappelle moi ")){
            return ParsedCommand(CommandIntent.MEMORY_GET,mapOf("key" to input.substring(13).trim()))
        }
        if(t.contains("efface memoire")) return ParsedCommand(CommandIntent.MEMORY_CLEAR,emptyMap())
        if(t.contains("resto")) return ParsedCommand(CommandIntent.RESTAURANT,mapOf("query" to input))
        if(t.contains("calculatrice")) return ParsedCommand(CommandIntent.TOOL,mapOf("tool" to input))
        if(t.contains("maps")||t.contains("navigue")) return ParsedCommand(CommandIntent.MAPS,mapOf("query" to input))
        return ParsedCommand(CommandIntent.UNKNOWN,emptyMap())
    }
}
