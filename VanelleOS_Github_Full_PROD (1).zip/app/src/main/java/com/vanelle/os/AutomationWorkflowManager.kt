package com.vanelle.os
import android.content.Context
class AutomationWorkflowManager(private val c:Context){
    fun execute(q:String):String{ WebSearchHelper(c).search(q); return q }
}
