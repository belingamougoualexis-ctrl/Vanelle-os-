package com.vanelle.os
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
class BootReceiver:BroadcastReceiver(){
    override fun onReceive(c:Context,i:Intent?){
        if(i?.action!=Intent.ACTION_BOOT_COMPLETED) return
        if(WakeWordPrefs.isEnabled(c)){ try{ ContextCompat.startForegroundService(c,Intent(c,WakeWordService::class.java)) }catch(_:Exception){} }
    }
}
