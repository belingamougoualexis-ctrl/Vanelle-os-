package com.vanelle.os
import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
class MemoryVault(c:Context){
    private val ac=c.applicationContext
    private var p:SharedPreferences?=null
    private fun pref():SharedPreferences?{
        if(p!=null) return p
        return try{
            val mk=MasterKey.Builder(ac).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(ac,"vault",mk,EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM).also{ p=it }
        }catch(_:Exception){ null }
    }
    fun save(k:String,v:String){ pref()?.edit()?.putString(k.lowercase().trim(),v)?.apply() }
    fun get(k:String)= pref()?.getString(k.lowercase().trim(),null)
    fun getAll():Map<String,String>{ val pr=pref() ?: return emptyMap(); return pr.all.mapNotNull{ if(it.value is String) it.key to it.value as String else null }.toMap() }
    fun clear(){ pref()?.edit()?.clear()?.apply() }
}
