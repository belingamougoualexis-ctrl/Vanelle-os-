package com.vanelle.os
import android.content.Context
object MascotManager{
    val mascots= listOf("aurora" to "Aurora","dark" to "Dark","luxe" to "Luxe","neon" to "Neon","silver" to "Silver","lava" to "Lava","deep_blue" to "Deep Blue","star" to "Star","holo" to "Holo","nature" to "Nature","chrome" to "Chrome","aurora_purple" to "Aurora Purple","love" to "Love","vanelle_white" to "Vanelle White","vanelle_blue" to "Vanelle Blue")
    fun getSelected(c:Context)= c.getSharedPreferences("vanelle_prefs",0).getString("mascot","aurora") ?: "aurora"
    fun setSelected(c:Context,id:String){ if(mascots.any{it.first==id}) c.getSharedPreferences("vanelle_prefs",0).edit().putString("mascot",id).apply() }
    fun getDrawableId(c:Context,id:String)= c.resources.getIdentifier("mascot_$id","drawable",c.packageName)
}
