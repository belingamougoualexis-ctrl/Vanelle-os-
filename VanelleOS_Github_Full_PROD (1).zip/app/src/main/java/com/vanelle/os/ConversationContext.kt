package com.vanelle.os
object ConversationContext{
    @Synchronized fun update(i:CommandIntent,a:Map<String,String>){}
}
