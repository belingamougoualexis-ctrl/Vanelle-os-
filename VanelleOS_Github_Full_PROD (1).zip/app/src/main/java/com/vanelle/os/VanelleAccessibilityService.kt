package com.vanelle.os
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
class VanelleAccessibilityService:AccessibilityService(){
    companion object{ var instance:VanelleAccessibilityService?=null }
    override fun onServiceConnected(){ instance=this }
    override fun onUnbind(i:android.content.Intent?):Boolean{ instance=null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e:AccessibilityEvent?){}
    override fun onInterrupt(){}
    fun action(a:String)= when(a){
        "back"->performGlobalAction(GLOBAL_ACTION_BACK)
        "home"->performGlobalAction(GLOBAL_ACTION_HOME)
        "notifications"->performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "recents"->performGlobalAction(GLOBAL_ACTION_RECENTS)
        else->false
    }
}
