package com.vanelle.os
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
class MascotFragment:Fragment(){
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val root=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(32,32,32,32); setBackgroundColor(0xFF0A0A0A.toInt())}
        val hero=ImageView(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,520).apply{bottomMargin=28}; scaleType=ImageView.ScaleType.FIT_CENTER; setBackgroundColor(0xFF111111.toInt())}
        var sel=MascotManager.getSelected(ctx)
        fun refresh(){try{hero.setImageResource(MascotManager.getDrawableId(ctx,sel))}catch(_:Exception){}}
        refresh()
        val scroll=HorizontalScrollView(ctx).apply{isHorizontalScrollBarEnabled=false}
        val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        for((id,name) in MascotManager.mascots){
            val card=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(12,12,12,12); layoutParams=LinearLayout.LayoutParams(168,184).apply{setMargins(0,0,14,0)}; setBackgroundColor(if(id==sel) 0xFF1A1A1A.toInt() else 0xFF111111.toInt())}
            val iv=ImageView(ctx).apply{try{setImageResource(MascotManager.getDrawableId(ctx,id))}catch(_:Exception){}; scaleType=ImageView.ScaleType.FIT_CENTER; layoutParams=LinearLayout.LayoutParams(-1,116)}
            val tv=TextView(ctx).apply{text=name; setTextColor(0xFFFFFFFF.toInt()); textSize=10f; letterSpacing=0.06f; setPadding(0,10,0,0); typeface=android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL)}
            card.addView(iv); card.addView(tv)
            card.setOnClickListener{sel=id; MascotManager.setSelected(ctx,id); refresh(); for(j in 0 until row.childCount){(row.getChildAt(j) as LinearLayout).setBackgroundColor(0xFF111111.toInt())}; card.setBackgroundColor(0xFF1A1A1A.toInt())}
            row.addView(card)
        }
        scroll.addView(row); root.addView(hero); root.addView(scroll); return root
    }
}
class ConfigFragment:Fragment(){
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext(); val sv=ScrollView(ctx).apply{setBackgroundColor(0xFF0A0A0A.toInt())}
        val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(32,40,32,32)}
        val title=TextView(ctx).apply{text="Configuration"; setTextColor(0xFFFFFFFF.toInt()); textSize=16f; letterSpacing=0.08f; typeface=android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL); setPadding(0,0,0,32)}
        val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,22,24,22); setBackgroundColor(0xFF111111.toInt())}
        val status=TextView(ctx).apply{text=if(WakeWordPrefs.isEnabled(ctx)) "Active" else "Inactive"; setTextColor(0xFFFFFFFF.toInt()); textSize=13f; setPadding(20,0,0,0)}
        val sw=Switch(ctx).apply{isChecked=WakeWordPrefs.isEnabled(ctx); setOnCheckedChangeListener{_,c->WakeWordPrefs.setEnabled(ctx,c); status.text=if(c) "Active" else "Inactive"}}
        row.addView(sw); row.addView(status); col.addView(title); col.addView(row); sv.addView(col); return sv
    }
}
class FeaturesFragment:Fragment(){
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext(); val grid=GridLayout(ctx).apply{columnCount=2; setPadding(20,20,20,20); setBackgroundColor(0xFF0A0A0A.toInt())}
        val items=listOf("Ouvrir application","Appeler contact","Recherche","YouTube","Traduction","Memoire","Urgence","Telephone perdu","Navigation","Retour Accueil")
        for(name in items){val card=TextView(ctx).apply{text=name; setTextColor(0xFFFFFFFF.toInt()); textSize=12f; letterSpacing=0.04f; setPadding(22,22,22,22); setBackgroundColor(0xFF111111.toInt()); layoutParams=GridLayout.LayoutParams().apply{width=0; height=GridLayout.LayoutParams.WRAP_CONTENT; columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); setMargins(10,10,10,10)}}; grid.addView(card)}
        return grid
    }
}
