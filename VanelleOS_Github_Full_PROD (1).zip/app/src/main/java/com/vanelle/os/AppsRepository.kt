package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentHashMap
class AppsRepository(private val context:Context){
    private val cache=ConcurrentHashMap<String,List<Item>>()
    @Volatile private var loading=false
    private val scope=CoroutineScope(Dispatchers.IO+SupervisorJob())
    data class Item(val label:String,val pkg:String)
    init{ scope.launch{ load() } }
    private suspend fun load(){
        if(loading) return; loading=true
        val list=withContext(Dispatchers.IO){
            val pm=context.packageManager
            val mi=Intent(Intent.ACTION_MAIN).apply{ addCategory(Intent.CATEGORY_LAUNCHER) }
            val acts=if(Build.VERSION.SDK_INT>=33) pm.queryIntentActivities(mi,PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())) else @Suppress("DEPRECATION") pm.queryIntentActivities(mi,PackageManager.MATCH_ALL)
            acts.map{ Item(it.loadLabel(pm).toString(),it.activityInfo.packageName) }
        }
        cache["apps"]=list; loading=false
    }
    fun launch(name:String):String{
        if(name.isBlank()) return "Nom requis"
        val apps=cache["apps"]
        if(apps.isNullOrEmpty()){ if(!loading) scope.launch{ load() }; return "Chargement" }
        val bestLabel=FuzzyMatch.findBest(name,apps.map{it.label}) ?: return "Application introuvable"
        val best=apps.firstOrNull{ it.label==bestLabel } ?: return "Introuvable"
        val li=context.packageManager.getLaunchIntentForPackage(best.pkg) ?: return "Impossible"
        return try{ li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(li); "${best.label} ouvert" }catch(_:Exception){ "Impossible" }
    }
}
