package com.vanelle.os
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity:AppCompatActivity(){
    private lateinit var vp:ViewPager2
    private lateinit var tl:TabLayout
    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        vp=findViewById(R.id.viewPager)
        tl=findViewById(R.id.tabLayout)
        vp.adapter=Adapter(this)
        TabLayoutMediator(tl,vp){ tab,pos-> tab.text=when(pos){0->"Mascotte";1->"Configuration";else->"Fonctions"} }.attach()
        if(!isEnabled()){
            AlertDialog.Builder(this).setTitle("Accessibilite requise").setMessage("Active l acces pour les actions systeme").setPositiveButton("Activer"){_,_-> startActivity(android.content.Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }.setNegativeButton("Plus tard",null).show()
        }
        intent.getStringExtra("voice_text")?.let{ t->
            val r=intent.getStringExtra("voice_result") ?: ""
            AlertDialog.Builder(this).setTitle(t).setMessage(r).setPositiveButton("Fermer",null).show()
        }
    }
    private fun isEnabled():Boolean{
        val exp="$packageName/${VanelleAccessibilityService::class.java.canonicalName}"
        val en=Settings.Secure.getString(contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val split=TextUtils.SimpleStringSplitter(':')
        split.setString(en)
        while(split.hasNext()){ if(split.next().equals(exp,true)) return true }
        return false
    }
}
class Adapter(a:AppCompatActivity): androidx.viewpager2.adapter.FragmentStateAdapter(a){
    override fun getItemCount()=3
    override fun createFragment(p:Int)= when(p){0->MascotFragment();1->ConfigFragment();else->FeaturesFragment()}
}
