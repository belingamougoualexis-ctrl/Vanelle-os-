package com.vanelle.os
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
class CommandInterpreter(private val context:Context){
    private val apps=AppsRepository(context)
    private val contacts=ContactsRepository(context)
    private val web=WebSearchHelper(context)
    private val yt=YouTubeHelper(context)
    private val tr=TranslateHelper(context)
    private val bat=BatteryHelper(context)
    private val em=EmergencyManager(context)
    private val vault=MemoryVault(context)
    private val maps=MapsHelper(context)
    private val workflow=AutomationWorkflowManager(context)
    private val learner=WorkflowLearner(context)
    suspend fun execute(t:String):String{
        if(t.isBlank()) return "Rien entendu"
        val p=CommandParser.parse(t)
        val res=when(p.intent){
            CommandIntent.OPEN_APP-> apps.launch(p.args["app"] ?: "")
            CommandIntent.CALL_CONTACT-> contacts.call(p.args["name"] ?: "")
            CommandIntent.SEARCH_WEB-> { web.search(p.args["query"] ?: ""); "Recherche lancee" }
            CommandIntent.YOUTUBE-> { yt.search(p.args["query"] ?: ""); "YouTube ouvert" }
            CommandIntent.TRANSLATE-> { tr.translate(p.args["text"] ?: ""); "Traduction ouverte" }
            CommandIntent.MEMORY_SAVE-> withContext(Dispatchers.IO){ vault.save(p.args["key"] ?: "note", p.args["data"] ?: ""); "Retenu" }
            CommandIntent.MEMORY_GET-> withContext(Dispatchers.IO){
                val key=p.args["key"] ?: ""
                val all=vault.getAll()
                val exact=all[key.lowercase()]
                val fuzzy=all.entries.firstOrNull{ it.key.contains(key,ignoreCase=true) || key.contains(it.key,ignoreCase=true) }?.value
                exact ?: fuzzy ?: "Aucune donnee"
            }
            CommandIntent.MEMORY_CLEAR-> withContext(Dispatchers.IO){ vault.clear(); "Memoire effacee" }
            CommandIntent.EMERGENCY-> em.sos()
            CommandIntent.BATTERY-> "Batterie ${bat.level()}%"
            CommandIntent.RESTAURANT-> { web.search(p.args["query"] ?: ""); "Recherche lancee" }
            CommandIntent.TOOL-> workflow.execute(p.args["tool"] ?: "")
            CommandIntent.LOST_PHONE-> LostPhoneManager.trigger(context)
            CommandIntent.MAPS-> { maps.open(p.args["query"] ?: ""); "Maps ouvert" }
            CommandIntent.ACCESSIBILITY_ACTION-> { VanelleAccessibilityService.instance?.action(p.args["action"] ?: ""); "Action executee" }
            else-> "Commande non reconnue"
        }
        withContext(Dispatchers.IO){ learner.log(t) }
        ConversationContext.update(p.intent,p.args)
        return res
    }
}
