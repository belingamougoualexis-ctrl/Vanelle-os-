# VanelleOS 1.0.0 PRODUCTION CLEAN
Structure exacte demandee:
Vanelle/
├── app/
├── gradle/
├── build.gradle.kts
├── settings.gradle.kts
├── gradlew
├── gradlew.bat
└── .github/workflows/android-build.yml

## Installation
1. Replace gradlew / gradlew.bat / gradle/wrapper with real files from Android Studio > New Project > Empty Activity (pour eviter placeholder)
2. Place tes 15 PNG mascot_*.png dans app/src/main/res/drawable/
3. git init, add, commit, push

## Build
./gradlew assembleRelease -> app/build/outputs/apk/release/app-release.apk
GitHub Actions build auto a chaque push sur main.
