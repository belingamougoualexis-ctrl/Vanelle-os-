@echo off
echo Replace this file with gradlew.bat from Android Studio template
