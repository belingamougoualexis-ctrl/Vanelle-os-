# NEXUS Android 2.2.2

**NEXUS est un overlay décentralisé de réseau des réseaux.** La version 2.2.2 ajoute les services edge, synchronisation, tolérance aux pertes, capacités d’accès et diagnostic explicable. Les appareils autorisés peuvent transporter du trafic IP par plusieurs sauts, sélectionner automatiquement une sortie Internet réelle, découvrir des pairs, résoudre des noms `.mesh`, stocker des données de façon distribuée et continuer à fonctionner lorsque certaines connexions disparaissent.

NEXUS ne crée pas de bande passante ou de portée radio à partir de rien. Un téléphone peut exploiter Wi‑Fi, cellulaire, Ethernet, Wi‑Fi Direct ou tout autre transport IP réellement exposé par l'appareil, mais une liaison longue portée, un satellite, une fibre ou une radio doit exister physiquement.

La version 2.2.2 optimise la portée utile au niveau logiciel : découverte Wi‑Fi Direct périodique, jusqu’à 6 candidats de relais par tentative, basculement sur plusieurs chemins et TTL longue distance par défaut de 32 sauts. Cela améliore les chances de trouver un chemin réel ; cela n’augmente pas la portée physique de la radio du téléphone.

## Adresse personnelle et services Internet-like

Chaque installation possède une adresse NEXUS IPv6 overlay stable dérivée de son identité cryptographique. Un utilisateur peut entrer cette adresse ou une IP publique réelle : NEXUS authentifie le nœud distant, crée une demande signée et la transmet par liaison directe, relais ou boîte aux lettres distribuée selon les chemins réellement disponibles. Le destinataire accepte ou refuse avant qu'une relation de contact soit établie.

Cinq fonctions réseau supplémentaires sont exposées dans l'interface : nom décentralisé `.mesh`, trace réelle d'une destination, vérification d'un endpoint IP public avec dérivation de son adresse NEXUS, boîte hors ligne persistante et lien `nexus://contact` ouvrant directement l'écran de demande. Le moteur conserve également le basculement multi-chemins et la reprise automatique des routes.

## Backhaul physique et multi-backhaul réel

`NexusPhysicalBackhaul` inventorie les réseaux IP réellement exposés par Android. NEXUS reconnaît notamment Wi‑Fi, cellulaire, Ethernet, USB, Wi‑Fi Aware, Bluetooth réseau, LoWPAN, Thread et le transport satellite lorsqu'il est disponible sur la version Android concernée. Les transports satellite et USB récents sont traités uniquement derrière les contrôles de version appropriés.

Un terminal fibre, radio longue portée ou laser qui fournit une interface IP à Android peut donc être utilisé comme backhaul. NEXUS ne génère pas lui-même le signal radio/laser ni une capacité satellite : il exploite le réseau que le matériel et son opérateur exposent réellement au système.

`NexusTransportManager` lie maintenant les sockets TCP/UDP sortants à de vrais objets `Network`. Pour plusieurs backhauls validés, les flux indépendants peuvent être répartis entre les réseaux disponibles, avec reprise sur un autre réseau en cas d'échec. Une seule session TCP n'est pas artificiellement "accélérée" par concaténation de liens incompatibles. NEXUS n'invente plus de valeurs de latence/perte pour classer ces backhauls : lorsqu'elles ne sont pas fournies par Android, elles sont simplement traitées comme inconnues.

`NexusExternalLinkProtocol` définit en plus un framing NXL1 avec séquence et CRC-32 pour les accessoires radio/laser/modem qui veulent transporter directement des trames NEXUS. Un accessoire non-IP doit cependant implémenter ce protocole ou fournir une passerelle IP : Android ne peut pas transformer génériquement n'importe quel modem radio USB en interface Internet sans pilote/protocole adapté.

## Architecture 1.0

```text
                         TRANSPORTS PHYSIQUES RÉELS
        Wi‑Fi / cellulaire / Ethernet / P2P / backhaul satellite-réseau / radio-IP
                                      │
                                      ▼
A ───── NEXUS ───── B ───── NEXUS ───── C ───── passerelle ───── Internet
 │                  │                    │
 TUN/VPN            relais               stockage distribué
 │                  │                    │
 E2E                QoS / crédits        DHT / DTN / contenu
                                      │
                               routage hiérarchique
                                      │
                              identité / confiance
```

Les rôles de passerelle et de transit restent opt-in.

## Routage mondial en overlay

`MeshRouter` reste le moteur de prochain saut local : il tient plusieurs candidats, mesure les liens, pénalise les échecs, évite les boucles et bascule sur un autre chemin. Les connexions longue distance utilisent jusqu’à 32 sauts par défaut, avec plusieurs candidats et reprise sur échec.

`NexusGlobalRoutingTable` ajoute une couche hiérarchique :

- domaine virtuel `NXD-*` dérivé de l'identité du nœud ;
- préfixe d'overlay `nexus:NXD-*` ;
- annonces expirables ;
- chemin complet limité pour éviter les boucles ;
- plusieurs routes avec coût calculé à partir de la métrique et du nombre de sauts.

Cela représente un **routage mondial d'overlay**, pas un remplacement de BGP ou des routeurs opérateurs.

## DHT et nommage

`NexusDht` fournit une table de style Kademlia avec distance XOR, expiration et recherche de voisins proches.

Les enregistrements de noms sont signés. Le nommage NEXUS utilise une forme auto-certifiante :

```text
<empreinte de clé publique>.mesh
```

Les enregistrements sont vérifiés avant acceptation puis peuvent être répliqués à plusieurs pairs via `NexusDhtReplicator`.

## NAT traversal

`NexusNatTraversal` réalise une vraie découverte STUN et expose les candidats publics obtenus. La version Android mesure réellement le mapping public avec STUN. Le relais reste le secours lorsque la connexion directe ne fonctionne pas ; aucun NAT n’est déclaré franchissable sans test réel.

NEXUS n'affirme jamais qu'un NAT permet forcément une connexion directe : quand le chemin direct échoue, le relais NEXUS reste le mécanisme de secours.

## DTN / réseau opportuniste

`NexusDtnStore` permet de conserver temporairement une donnée lorsqu'elle ne peut pas être livrée immédiatement.

Chaque bundle contient :

- identité d'origine et destination ;
- expiration ;
- priorité ;
- nombre de tentatives ;
- historique des nœuds visités ;
- vérification d'intégrité du payload.

Le bundle peut être retransmis lorsqu'un pair redevient disponible.

## Bande passante, énergie et QoS

NEXUS combine la politique de relais existante avec `NexusQosController`.

La régulation peut donc prendre en compte :

- débit maximal ;
- partage par pair ;
- quota journalier ;
- batterie et mode de charge ;
- réseaux mesurés ;
- classe de trafic et poids du flux.

L'algorithme applique effectivement des token buckets au chemin de données du relais.

## Crédits

Les crédits sont une **comptabilité interne de ressources** : les octets réellement relayés peuvent produire des crédits et leur solde peut être utilisé lorsque la politique de consommation stricte est activée.

Ce système n'est pas présenté comme une monnaie mondiale, ni comme une blockchain globale.

## Sécurité et lutte contre Sybil

NEXUS combine plusieurs mécanismes :

- identité cryptographique persistante ;
- signature des capacités ;
- HMAC du réseau ;
- chiffrement E2E des sessions ;
- réputation locale ;
- TOFU/listes autorisées ;
- preuve de travail légère `NexusAdmission`.

La preuve de travail **augmente le coût** de création d'identités mais ne résout pas seule les attaques Sybil. Le réseau public doit également utiliser la diversité de chemins, la réputation et des politiques d'admission appropriées.

## Stockage distribué

Le stockage NEXUS découpe les contenus en blocs adressés par hash SHA-256 et peut répliquer les contenus épinglés vers plusieurs pairs.

La récupération teste plusieurs fournisseurs puis vérifie le hash final avant de livrer le contenu.

Il s'agit d'une architecture P2P adressée par contenu inspirée de systèmes comme IPFS/BitTorrent, sans prétendre embarquer toute leur pile.

## Partage hors ligne

L'application peut exporter son APK et proposer son partage Android hors ligne. Un transfert NEXUS direct peut aussi envoyer le fichier à un pair en vérifiant taille et SHA-256.

L'installation finale dépend toujours des restrictions et autorisations Android.

## Un bouton

`CONNECTER AUTOMATIQUEMENT` lance le service, demande l'autorisation VPN si nécessaire, active la découverte et laisse le moteur sélectionner une route réelle.

Le partage de transit reste volontaire afin de protéger batterie, forfait et stockage.

## IPv4 / IPv6

Le cœur userspace conserve IPv4 et IPv6, TCP/UDP, fragments IPv6, contrôle TCP avancé, ICMPv6 et les fonctions ND/MLD ajoutées précédemment.

La gestion des extensions IPv6 reste explicitement limitée au sous-ensemble réellement pris en charge. Par exemple, la reconnaissance du Jumbo Payload ne signifie pas que NEXUS transporte actuellement des jumbograms au-delà du MTU TUN configuré.

## Interopérabilité

Les endpoints de bootstrap sont normalisés par `NexusInterop` :

```text
nexus://203.0.113.10:45454
nexus://[2001:db8::10]:45454
203.0.113.10:45454
```

Une organisation de résilience peut ainsi fournir de vrais points d'entrée distants. NEXUS peut exploiter le backhaul IP que ces points d'entrée exposent.

## Limite physique fondamentale

NEXUS peut résoudre les problèmes logiciels de découverte, routage, chiffrement, résilience, congestion et stockage. Il ne peut pas supprimer les lois physiques :

```text
logiciel NEXUS
      ↓
interfaces radio / câble / satellite / fibre réelles
      ↓
propagation physique
      ↓
autre nœud
```

Un réseau mondial réel nécessite donc suffisamment de nœuds, de liens longue portée et de points d'interconnexion.

## Validation réelle

La CI v2.0 exécute les contrôles du cœur par composant dans une matrice indépendante afin d'éviter qu'un ralentissement du compilateur local masque le résultat d'un autre module. Les contrôles historiques principaux restent automatisés par composant :

```text
ICMPv6 / ND / MLD                         OK
IPv6 / TCP / UDP                          OK
NXP authentifié                            OK
Auto-route / failover                     OK
Multi-hop TCP+UDP                         OK
E2E TCP+UDP                                OK
DHT / routage / admission                 OK
NAT hole-punch                             OK
DTN / QoS                                  OK
Persistance / contenu / crédits / noms    OK
Backhaul physique / USB NXL1              OK
```

Le SDK Android complet n'est pas disponible dans cet environnement de travail ; aucun APK n'est donc présenté comme compilé localement ici. Le workflow GitHub Actions fournit la construction Android et les smoke tests instrumentés séparément.

## Positionnement

NEXUS est conçu prioritairement pour la **résilience réseau, l'accès local/offline, les environnements mal connectés et la continuité de service lors de pannes d'infrastructure**, avec participation volontaire des appareils.

## Services natifs NEXUS v2.0

### Base de données distribuée

`NexusDatabase` fournit une base clé/valeur persistante locale. Les enregistrements portent une version logique, une identité de nœud, une date de modification et un hash d'intégrité. `NexusDatabaseReplicator` peut répliquer les bases utilisateur vers des pairs autorisés lorsque l'option est activée.

### Messagerie

Le plan de services expose une messagerie inter-nœuds. Les messages utilisent un canal de service authentifié puis chiffré. En cas d'indisponibilité du pair, le message peut être conservé dans une file locale persistante et être renvoyé lorsque le nœud destinataire redevient accessible.

### Calcul distribué

`NexusCompute` fournit un petit ensemble d'opérations déterministes et vérifiables : SHA-256, CRC32 et longueur UTF-8. Le service distant n'exécute pas de programme arbitraire envoyé par un pair.

### Ressources

Le nœud peut publier une offre factuelle comprenant les cœurs CPU disponibles, la RAM libre, le stockage libre, la limite de relais configurée et les opérations de calcul proposées. Ces valeurs sont lues sur l'appareil au moment de la publication.

### Runtime NEXUS

`NexusRuntime` fournit une convention `nexus://` et un point d'accès logiciel stable pour les applications NEXUS compatibles. Le runtime expose aussi une synthèse de l'état local du nœud.

### Réparation automatique

`NexusAutoRepair` vérifie les contenus épinglés et tente de récupérer les blocs manquants ou invalides auprès de fournisseurs connus et autorisés. Une réparation réussie reste conditionnée à la disponibilité réelle d'une copie valide.

## Sécurité du plan de services

Le handshake du plan de services est authentifié par HMAC avec la clé réseau acceptée, puis les commandes transitent dans une session AES-GCM dérivée du secret réseau et d'un nonce de session. Les demandes de base sont liées à l'identité authentifiée du pair et les messages ne peuvent pas usurper l'identité d'un autre nœud.

## Préparation production / distribution

Le projet est configuré pour compiler un APK Android avec `compileSdk 37`, `targetSdk 37` et `minSdk 26`. La CI construit les variantes debug et release et contient un smoke test instrumenté sur deux niveaux d'API Android distincts.

La clé de signature de production doit être fournie par le propriétaire autorisé de l'application avant distribution. Le dépôt ne contient aucune clé privée de publication.

Les éléments de conformité et de publication sont regroupés dans `LEGAL.md`, `PRIVACY.md`, `NOTICE.md` et `UPTODOWN-CHECKLIST.md`.

## Services avancés v2.1

### Cache edge / CDN local

Le chemin de récupération teste d'abord un cache local adressé par SHA-256. Les objets expirés sont retirés et un quota LRU simple limite l'empreinte dans le cache Android. Une récupération réseau réussie est mise en cache après vérification du hash.

### Synchronisation universelle

`NexusUniversalSync` échange les enregistrements d'une base avec un pair réellement joignable, fusionne les données distantes avec la résolution déterministe de `NexusDatabase`, puis renvoie les enregistrements produits par le nœud local. Un digest SHA-256 permet de comparer l'état avant et après.

### Tolérance aux pertes

`NexusErasureCoding` fournit actuellement un schéma 2+1 XOR : deux fragments de données et un fragment de parité permettent de reconstruire une perte unique dans la stripe. Ce composant n'est pas présenté comme un Reed-Solomon général.

### Capacités d'accès

`NexusCapabilities` fournit des jetons signés par l'identité du nœud, limités par sujet, ressource et expiration. `NexusAppSdk` expose cette primitive aux applications NEXUS natives.

### Diagnostic explicable

`NexusHealth` vérifie la connectivité, la validation Internet, les quotas, l'intégrité des contenus épinglés, l'intégrité de la base locale, le cache et l'identité, puis fournit un rapport lisible par l'utilisateur.

## NEXUS 2.2 — adressage personnel et longue distance

Chaque installation reçoit une adresse NEXUS IPv6 stable dérivée de son identité cryptographique. Cette adresse est utilisée comme identité réseau persistante, indépendamment de l'adresse IP fournie momentanément par Wi-Fi ou cellulaire.

Une personne peut saisir l'adresse NEXUS d'une autre personne et envoyer une demande signée. Le destinataire voit le nom, l'adresse et le contenu de la demande. Tant qu'il n'accepte pas, le contenu n'est pas ajouté à sa messagerie. Après acceptation, le message est écrit dans la base locale réelle et l'identité de l'expéditeur est observée par le magasin de confiance.

## Cinq capacités renforcées pour une expérience de réseau de type Internet

1. **Carnet d'adresses NEXUS persistant** : les identités NEXUS sont enregistrées localement avec un alias choisi par l'utilisateur, sans compte cloud.
2. **Boîte aux lettres distribuée** : une demande peut rester disponible dans de vrais nœuds NEXUS accessibles, même lorsque le téléphone destinataire est temporairement déconnecté.
3. **Sortie Internet distante indépendante du transit** : utiliser une passerelle Internet NEXUS distante ne demande plus d'activer le transit entrant sur son propre téléphone.
4. **Résilience de données sur fichier réel** : le codage 2+1 accepte maintenant un fichier réellement sélectionné par l'utilisateur et vérifie sa reconstruction, sans contenu de démonstration préfabriqué.
5. **Routage longue distance élargi et diagnostiquable** : l'overlay accepte jusqu'à 64 sauts internes, conserve des alternatives réelles et expose les chemins réellement disponibles avant toute tentative.

Ces fonctions ne suppriment pas les contraintes physiques d'Internet : une distance intercontinentale ou maritime est possible lorsque des backhauls IP réels, une passerelle, du satellite, de la fibre, une radio-IP ou d'autres liens physiques fournissent un chemin entre les nœuds. L'application ne fabrique pas une connexion lorsqu'aucun chemin physique n'existe.
