package com.nexus.network
import android.content.Context
object NetworkKeyManager { const val KEY="TEST-NETWORK-KEY"; fun accepted(context:Context)=listOf(KEY); fun current(context:Context)=KEY }
