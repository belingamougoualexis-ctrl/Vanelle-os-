package com.nexus.network

private fun check(name: String, ok: Boolean) { println((if (ok) "PASS " else "FAIL ") + name); if (!ok) System.exit(1) }

fun main() {
    val L = NexusLongHaul
    check("scope inconnu -> COUNTRY", L.scopeForRtt(null) == L.Scope.COUNTRY)
    check("RTT 20 ms -> LOCAL", L.scopeForRtt(20.0) == L.Scope.LOCAL)
    check("RTT 60 ms -> COUNTRY", L.scopeForRtt(60.0) == L.Scope.COUNTRY)
    check("RTT 120 ms -> CONTINENT", L.scopeForRtt(120.0) == L.Scope.CONTINENT)
    check("RTT 220 ms (France-Cameroun) -> INTERCONTINENTAL", L.scopeForRtt(220.0) == L.Scope.INTERCONTINENTAL)
    check("sauts <= 64 et croissants", L.Scope.values().all { it.maxHops in 1..64 } && L.Scope.values().map { it.maxHops }.zipWithNext().all { it.first <= it.second })
    check("DTN <= 7 jours", L.Scope.values().all { it.dtnTtlMs <= 7L * 24 * 3_600_000L })
    check("hopBudget borné", L.hopBudget(L.Scope.COUNTRY, 40) == 16 && L.hopBudget(L.Scope.CONTINENT, 3) == 7 && L.hopBudget(L.Scope.LOCAL, null) == 8)
    val s = L.Scope.INTERCONTINENTAL
    check("backoff croît", L.backoffMs(0, s, 1.0) < L.backoffMs(3, s, 1.0))
    check("backoff plafonné", L.backoffMs(50, s, 1.0) <= 120_000L && L.backoffMs(0, s, 0.0) >= 500L)
    check("fenêtre min", L.windowBytes(0, 200.0) == 64 * 1024)
    check("fenêtre BDP 10 Mbit/s x 200 ms = 250000 o", L.windowBytes(10_000, 200.0) == 250_000)
    check("fenêtre max 4 Mo", L.windowBytes(1_000_000, 500.0) == 4 * 1024 * 1024)
    val e = L.RttEstimator()
    check("timeout sans mesure = minimum", e.timeoutMs(s) == s.minTimeoutMs)
    e.sample(-5.0); e.sample(Double.NaN)
    check("mesures invalides ignorées", e.smoothedMs() == null)
    repeat(20) { e.sample(220.0) }
    check("SRTT ~ 220", e.smoothedMs()!! in 219.0..221.0)
    check("timeout >= minimum de la portée", e.timeoutMs(s) >= s.minTimeoutMs)
    check("hôte local: 192.168.1.5, 10.0.0.1, localhost, fd00::1", listOf("192.168.1.5","10.0.0.1","localhost","fd00::1","[::1]","172.20.1.1").all { L.isLocalHost(it) })
    check("hôte distant: 41.202.1.1, 8.8.8.8, exemple.cm, 172.32.0.1", listOf("41.202.1.1","8.8.8.8","exemple.cm","172.32.0.1","2001:db8::1").none { L.isLocalHost(it) })
    check("timeout connexion Internet >= 12 s, local inchangé", L.connectTimeoutMs("41.202.1.1", 4000) == 12_000 && L.connectTimeoutMs("192.168.1.5", 4000) == 4000)
    check("timeout lecture Internet >= 8 s, local inchangé", L.readTimeoutMs("8.8.8.8", 2500) == 8_000 && L.readTimeoutMs("10.0.0.1", 2500) == 2500)
    check("TTL route selon chemin", L.routeTtlMs(1) == 40_000L && L.routeTtlMs(20) == 600_000L)
    println("NEXUS long haul self-test: OK")
}
