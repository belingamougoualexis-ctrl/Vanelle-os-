#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/nexus-v1_2-targeted-$$"
mkdir -p "$OUT"
trap 'rm -rf "$OUT"' EXIT

run_jar() {
  local label="$1" main="$2" jar="$3"
  echo "[NEXUS v1.2] $label"
  java -cp "$jar" "$main"
}

compile_and_run() {
  local label="$1" main="$2" output="$3"; shift 3
  echo "[NEXUS v1.2] compile: $label"
  kotlinc "$@" -include-runtime -d "$output"
  run_jar "$label" "$main" "$output"
}

# 1) Pure physical inventory / path planner — no Android SDK required.
compile_and_run \
  "physical backhaul planner" \
  "com.nexus.network.Physical_backhaul_selftestKt" \
  "$OUT/physical.jar" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusMultipathPlanner.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusExternalLinkProtocol.kt" \
  "$ROOT/tools/physical_backhaul_selftest.kt"

# 2) Android transport inventory with controlled API stubs.
compile_and_run \
  "Android physical backhaul + satellite/USB/multipath" \
  "com.nexus.network.Physical_android_backhaul_selftestKt" \
  "$OUT/android-physical.jar" \
  "$ROOT/tools/test-stubs/android/content/Context.kt" \
  "$ROOT/tools/test-stubs/android/content/pm/PackageManager.kt" \
  "$ROOT/tools/test-stubs/android/net/ConnectivityManager.kt" \
  "$ROOT/tools/test-stubs/android/net/LinkProperties.kt" \
  "$ROOT/tools/test-stubs/android/net/Network.kt" \
  "$ROOT/tools/test-stubs/android/net/NetworkCapabilities.kt" \
  "$ROOT/tools/test-stubs/android/os/Build.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusMultipathPlanner.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusPhysicalBackhaul.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusTransportManager.kt" \
  "$ROOT/tools/physical_android_backhaul_selftest.kt"

# 3) Real NXL1 frame protocol over the Android USB bulk abstraction (controlled USB API stubs).
compile_and_run \
  "USB NXL1 bulk transport" \
  "com.nexus.network.Physical_usb_nxl_selftestKt" \
  "$OUT/usb.jar" \
  "$ROOT/tools/test-stubs/android/content/Context.kt" \
  "$ROOT/tools/test-stubs/android/content/pm/PackageManager.kt" \
  "$ROOT/tools/test-stubs/android/net/ConnectivityManager.kt" \
  "$ROOT/tools/test-stubs/android/net/Network.kt" \
  "$ROOT/tools/test-stubs/android/net/NetworkCapabilities.kt" \
  "$ROOT/tools/test-stubs/android/net/LinkProperties.kt" \
  "$ROOT/tools/test-stubs/android/hardware/usb/UsbConstants.kt" \
  "$ROOT/tools/test-stubs/android/hardware/usb/UsbEndpoint.kt" \
  "$ROOT/tools/test-stubs/android/hardware/usb/UsbInterface.kt" \
  "$ROOT/tools/test-stubs/android/hardware/usb/UsbDevice.kt" \
  "$ROOT/tools/test-stubs/android/hardware/usb/UsbDeviceConnection.kt" \
  "$ROOT/tools/test-stubs/android/hardware/usb/UsbManager.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusExternalLinkProtocol.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusUsbNxlTransport.kt" \
  "$ROOT/tools/physical_usb_nxl_selftest.kt"

# 4) IPv6 control plane.
compile_and_run \
  "ICMPv6 / Neighbor Discovery / MLD" \
  "Icmpv6_nd_mld_selftestKt" \
  "$OUT/icmpv6.jar" \
  "$ROOT/app/src/main/java/com/nexus/network/IpPacket.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/TcpOptions.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/Ipv6Packet.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/Icmpv6.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/Ipv6ControlPlane.kt" \
  "$ROOT/tools/icmpv6_nd_mld_selftest.kt"

# 5) Distributed core: DHT, global routing, admission and interop.
CORE_DISTRIBUTED=(
  "$ROOT/tools/test-stubs/minimal/android/content/Context.kt"
  "$ROOT/tools/test-stubs/minimal/com/nexus/network/NsdController.kt"
  "$ROOT/tools/test-stubs/minimal/com/nexus/network/NexusIdentity.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusConfig.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusDht.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusAdmission.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusInterop.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusGlobalRouting.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusLongHaul.kt"
)
kotlinc "${CORE_DISTRIBUTED[@]}" "$ROOT/tools/nexus_v1_0_core_selftest.kt" -include-runtime -d "$OUT/distributed.jar"
run_jar "DHT / global routing / admission / interop" "Nexus_v1_0_core_selftestKt" "$OUT/distributed.jar"

# 6) NAT traversal.
compile_and_run \
  "STUN / UDP candidate probing" \
  "Nexus_v1_0_nat_selftestKt" \
  "$OUT/nat.jar" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusNatTraversal.kt" \
  "$ROOT/tools/nexus_v1_0_nat_selftest.kt"

# 7) DTN + QoS.
compile_and_run \
  "DTN store-and-forward / QoS" \
  "Nexus_v1_0_dtn_qos_selftestKt" \
  "$OUT/dtnqos.jar" \
  "$ROOT/tools/test-stubs/android/content/Context.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusConfig.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusDtnStore.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusQosController.kt" \
  "$ROOT/tools/nexus_v1_0_dtn_qos_selftest.kt"

# 8) E2E TCP/UDP relay encryption.
CORE_E2E=(
  "$ROOT/tools/test-stubs/android/net/VpnService.kt"
  "$ROOT/tools/test-stubs/com/nexus/network/NsdController.kt"
  "$ROOT/tools/test-stubs/com/nexus/network/NexusP2PDirectory.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusConfig.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusSecureFraming.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusStreamChannel.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusE2E.kt"
)
kotlinc "${CORE_E2E[@]}" "$ROOT/tools/nexus_v0_9_e2e_selftest.kt" -include-runtime -d "$OUT/e2e.jar"
run_jar "end-to-end cryptographic TCP/UDP" "Nexus_v0_9_e2e_selftestKt" "$OUT/e2e.jar"

# 9) Authenticated route advertisements / mesh failover.
CORE_ROUTE=(
  "$ROOT/app/src/main/java/com/nexus/network/NexusConfig.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusGlobalRouting.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusLongHaul.kt"
  "$ROOT/app/src/main/java/com/nexus/network/NexusMultipathPlanner.kt"
)
kotlinc "${CORE_ROUTE[@]}" "$ROOT/tools/nxp_route_auth_selftest.kt" "$ROOT/tools/meshroute_core_selftest.kt" -include-runtime -d "$OUT/route.jar"
run_jar "authenticated NXP route advertisement" "Nxp_route_auth_selftestKt" "$OUT/route.jar"
run_jar "mesh auto-route / failover" "Meshroute_core_selftestKt" "$OUT/route.jar"

# 10) Protocol regression and userspace core.
compile_and_run \
  "secure framing / protocol" \
  "Protocol_selftestKt" \
  "$OUT/protocol.jar" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusConfig.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusSecureFraming.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusStreamChannel.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NxpProtocol.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusLongHaul.kt" \
  "$ROOT/tools/protocol_selftest.kt"

"$ROOT/tools/userspace-core-selftest.sh"

echo "NEXUS v1.2 TARGETED REAL CORE SELF-TEST SUITE: OK"
