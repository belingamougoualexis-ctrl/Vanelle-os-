#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/tools/.v2_2-nxp-selftest.jar"
trap 'rm -f "$OUT"' EXIT
kotlinc \
  "$ROOT/tools/test-stubs/v2_2_nxp/android/content/Context.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/com/nexus/network/NexusSecureStore.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/com/nexus/network/NexusConfig.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/com/nexus/network/NetworkKeyManager.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/com/nexus/network/NexusVpnRegistry.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/com/nexus/network/NexusNatTraversal.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/com/nexus/network/NexusGlobalRoutingTable.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/com/nexus/network/NexusAdmission.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/com/nexus/network/NexusDtnStore.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/com/nexus/network/NexusNaming.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/com/nexus/network/NexusAddressBook.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/com/nexus/network/NexusDht.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/com/nexus/network/NexusPeerRequests.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/com/nexus/network/NexusAddress.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/org/json/JSONObject.kt" \
  "$ROOT/tools/test-stubs/v2_2_nxp/org/json/JSONArray.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusCrypto.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NexusIdentity.kt" \
  "$ROOT/app/src/main/java/com/nexus/network/NxpProtocol.kt" "$ROOT/app/src/main/java/com/nexus/network/NexusLongHaul.kt" \
  "$ROOT/tools/nexus-v2_2-nxp-selftest.kt" \
  -include-runtime -d "$OUT"
java -jar "$OUT"
