package com.nexus.network

import android.app.ActivityManager
import android.content.Context
import android.os.StatFs

/** Local, factual resource offer. No global availability is claimed unless another peer advertises it. */
object NexusResourceMarket {
    data class Offer(val nodeId: String, val cpuCores: Int, val ramMb: Long, val storageFreeMb: Long, val relayMbps: Double, val computeOps: List<String>, val createdAt: Long)

    fun localOffer(context: Context): Offer {
        val am=context.getSystemService(ActivityManager::class.java)
        val ram=runCatching { am?.memoryInfo?.availMem ?: 0L }.getOrDefault(0L)/1024L/1024L
        val stat=StatFs(context.filesDir.absolutePath)
        val free=runCatching { stat.availableBytes }.getOrDefault(0L)/1024L/1024L
        return Offer(NexusIdentity.nodeId(context),Runtime.getRuntime().availableProcessors().coerceAtLeast(1),ram,free,NexusSettings.relayLimitMbps(context),NexusCompute.operations,System.currentTimeMillis())
    }

    fun wire(context: Context): String = org.json.JSONObject().apply {
        val o=localOffer(context); put("nodeId",o.nodeId);put("cpuCores",o.cpuCores);put("ramMb",o.ramMb);put("storageFreeMb",o.storageFreeMb);put("relayMbps",o.relayMbps);put("computeOps",org.json.JSONArray(o.computeOps));put("createdAt",o.createdAt)
    }.toString()
}
