package com.nexus.network

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Persistent local address book for stable NEXUS identities. No server account is required. */
object NexusContacts {
    private const val FILE = "nexus-contacts.json"
    private const val MAX_CONTACTS = 500
    private const val MAX_ALIAS = 80

    data class Contact(val id: String, val alias: String, val address: String, val createdAt: Long)

    @Synchronized
    fun list(context: Context): List<Contact> = read(context).sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.alias })

    @Synchronized
    fun add(context: Context, alias: String, address: String): Contact {
        val cleanAlias = alias.trim().take(MAX_ALIAS)
        require(cleanAlias.length >= 1) { "Nom du contact requis." }
        val normalized = NexusAddress.canonicalize(address)
        require(NexusAddress.isValidOverlay(normalized)) { "Adresse NEXUS invalide." }
        val existing = read(context).firstOrNull { it.address == normalized }
        if (existing != null) return existing.copy(alias = cleanAlias).also { write(context, read(context).map { c -> if (c.id == existing.id) it else c }) }
        val contact = Contact(UUID.randomUUID().toString().replace("-", "").take(24), cleanAlias, normalized, System.currentTimeMillis())
        val updated = (read(context) + contact).takeLast(MAX_CONTACTS)
        write(context, updated)
        return contact
    }

    @Synchronized
    fun remove(context: Context, id: String): Boolean {
        val before = read(context)
        val after = before.filterNot { it.id == id }
        if (after.size == before.size) return false
        write(context, after)
        return true
    }

    private fun file(context: Context) = File(context.filesDir, FILE)

    private fun read(context: Context): List<Contact> = runCatching {
        val f = file(context)
        if (!f.isFile) return@runCatching emptyList()
        val arr = JSONArray(f.readText(Charsets.UTF_8))
        buildList {
            for (i in 0 until arr.length()) {
                val j = arr.getJSONObject(i)
                val address = NexusAddress.canonicalize(j.getString("address"))
                if (NexusAddress.isValidOverlay(address)) {
                    add(Contact(j.getString("id"), j.getString("alias").take(MAX_ALIAS), address, j.getLong("createdAt")))
                }
            }
        }
    }.getOrDefault(emptyList())

    private fun write(context: Context, contacts: List<Contact>) {
        val temp = File(context.filesDir, "$FILE.tmp")
        val payload = JSONArray(contacts.take(MAX_CONTACTS).map { c ->
            JSONObject().apply { put("id", c.id); put("alias", c.alias); put("address", c.address); put("createdAt", c.createdAt) }
        }).toString()
        temp.writeText(payload, Charsets.UTF_8)
        check(temp.renameTo(file(context))) { "Impossible d'enregistrer les contacts." }
    }
}
