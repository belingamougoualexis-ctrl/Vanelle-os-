package com.nexus.network

import android.content.Context

object NexusSettings {
    private const val PREFS = "nexus_settings"
    private const val GATEWAY = "gateway_enabled"
    private const val TRANSIT = "transit_enabled"
    private const val RELAY_LIMIT = "relay_limit_mbps"
    private const val RELAY_DAILY = "relay_daily_mb"
    private const val MIN_BATTERY = "relay_min_battery"
    private const val CHARGING_ONLY = "relay_charging_only"
    private const val ALLOW_METERED = "relay_allow_metered"
    private const val STORAGE = "storage_enabled"
    private const val CREDITS = "credits_enforced"
    private const val BOOTSTRAP = "bootstrap_peers"
    private const val TRUST_ONLY = "trusted_only"
    private const val TRUSTED_PEERS = "trusted_peer_ids"
    private const val REPLICATION = "storage_replication_factor"
    private const val STORAGE_QUOTA = "storage_quota_mb"
    private const val DB_REPLICATION = "database_replication_enabled"
    private const val EDGE_CACHE_QUOTA = "edge_cache_quota_mb"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun gatewayEnabled(context: Context): Boolean = prefs(context).getBoolean(GATEWAY, false)
    fun transitEnabled(context: Context): Boolean = prefs(context).getBoolean(TRANSIT, false)
    fun setGateway(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(GATEWAY, enabled).apply()
    fun setTransit(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(TRANSIT, enabled).apply()

    fun relayLimitMbps(context: Context): Double = prefs(context).getFloat(RELAY_LIMIT, 2.0f).toDouble().coerceIn(0.1, 100.0)
    fun setRelayLimitMbps(context: Context, mbps: Double) = prefs(context).edit().putFloat(RELAY_LIMIT, mbps.coerceIn(0.1, 100.0).toFloat()).apply()
    fun relayDailyLimitBytes(context: Context): Long = prefs(context).getLong(RELAY_DAILY, 512L) * 1024L * 1024L
    fun setRelayDailyLimitMb(context: Context, mb: Long) = prefs(context).edit().putLong(RELAY_DAILY, mb.coerceIn(0, 100_000)).apply()
    fun minRelayBattery(context: Context): Int = prefs(context).getInt(MIN_BATTERY, 25).coerceIn(1, 100)
    fun setMinRelayBattery(context: Context, value: Int) = prefs(context).edit().putInt(MIN_BATTERY, value.coerceIn(1, 100)).apply()
    fun relayChargingOnly(context: Context): Boolean = prefs(context).getBoolean(CHARGING_ONLY, false)
    fun setRelayChargingOnly(context: Context, value: Boolean) = prefs(context).edit().putBoolean(CHARGING_ONLY, value).apply()
    fun allowMeteredRelay(context: Context): Boolean = prefs(context).getBoolean(ALLOW_METERED, false)
    fun setAllowMeteredRelay(context: Context, value: Boolean) = prefs(context).edit().putBoolean(ALLOW_METERED, value).apply()
    fun storageRelayEnabled(context: Context): Boolean = prefs(context).getBoolean(STORAGE, false)
    fun setStorageRelayEnabled(context: Context, value: Boolean) = prefs(context).edit().putBoolean(STORAGE, value).apply()
    fun creditsEnforced(context: Context): Boolean = prefs(context).getBoolean(CREDITS, false)
    fun setCreditsEnforced(context: Context, value: Boolean) = prefs(context).edit().putBoolean(CREDITS, value).apply()
    fun bootstrapPeers(context: Context): List<String> = prefs(context).getStringSet(BOOTSTRAP, emptySet()).orEmpty().toList().sorted()
    fun setBootstrapPeers(context: Context, peers: Collection<String>) = prefs(context).edit().putStringSet(BOOTSTRAP, peers.map { it.trim() }.filter { it.isNotBlank() }.toSet()).apply()
    fun trustedOnly(context: Context): Boolean = prefs(context).getBoolean(TRUST_ONLY, false)
    fun setTrustedOnly(context: Context, value: Boolean) = prefs(context).edit().putBoolean(TRUST_ONLY, value).apply()
    fun trustedPeerIds(context: Context): Set<String> = prefs(context).getStringSet(TRUSTED_PEERS, emptySet()).orEmpty()
    fun setTrustedPeerIds(context: Context, ids: Collection<String>) = prefs(context).edit().putStringSet(TRUSTED_PEERS, ids.map { it.trim() }.filter { it.isNotBlank() }.toSet()).apply()
    fun addTrustedPeer(context: Context, nodeId: String) = setTrustedPeerIds(context, trustedPeerIds(context) + nodeId)
    fun removeTrustedPeer(context: Context, nodeId: String) = setTrustedPeerIds(context, trustedPeerIds(context) - nodeId)
    fun replicationFactor(context: Context): Int = prefs(context).getInt(REPLICATION, NexusConfig.CONTENT_REPLICATION_DEFAULT).coerceIn(1, 8)
    fun setReplicationFactor(context: Context, value: Int) = prefs(context).edit().putInt(REPLICATION, value.coerceIn(1, 8)).apply()
    fun storageQuotaBytes(context: Context): Long = prefs(context).getLong(STORAGE_QUOTA, 2048L).coerceIn(128L, 1_000_000L) * 1024L * 1024L
    fun setStorageQuotaMb(context: Context, value: Long) = prefs(context).edit().putLong(STORAGE_QUOTA, value.coerceIn(128L, 1_000_000L)).apply()
    fun databaseReplicationEnabled(context: Context): Boolean = prefs(context).getBoolean(DB_REPLICATION, false)
    fun setDatabaseReplicationEnabled(context: Context, value: Boolean) = prefs(context).edit().putBoolean(DB_REPLICATION, value).apply()
    fun edgeCacheQuotaBytes(context: Context): Long = prefs(context).getLong(EDGE_CACHE_QUOTA, 512L).coerceIn(64L, 10_240L) * 1024L * 1024L
    fun setEdgeCacheQuotaMb(context: Context, value: Long) = prefs(context).edit().putLong(EDGE_CACHE_QUOTA, value.coerceIn(64L, 10_240L)).apply()
}
