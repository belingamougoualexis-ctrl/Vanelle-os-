package com.nexus.network

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class NexusNodeService : Service() {
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "nexus-node-${System.nanoTime()}").apply { isDaemon = true } }
    private var nodeServer: java.net.ServerSocket? = null
    private var socksServer: Socks5Server? = null
    private var relayServer: RelayServer? = null
    private var contentServer: NexusContentServer? = null
    private var appTransferServer: NexusAppTransferServer? = null
    private var contentReplicator: NexusContentReplicator? = null
    private var serviceServer: NexusServiceServer? = null
    private var dbReplicator: NexusDatabaseReplicator? = null
    private lateinit var autoRepair: NexusAutoRepair
    private lateinit var nsd: NsdController
    private var gatewayEnabled = false
    private var transitEnabled = false
    private var lastRepairAt = 0L
    private var lastResourcePublishAt = 0L
    private var lastMessageFlushAt = 0L
    private var lastRequestPullAt = 0L
    private var lastRequestNoticeCount = 0
    private lateinit var router: MeshRouter
    private lateinit var bootstrap: NexusBootstrapManager
    private lateinit var dht: NexusDht
    private lateinit var globalRouting: NexusGlobalRoutingTable
    private lateinit var dtn: NexusDtnStore
    private lateinit var dhtReplicator: NexusDhtReplicator
    private lateinit var nat: NexusNatTraversal
    private lateinit var qos: NexusQosController
    @Volatile private var natStatus = "NAT traversal : non mesuré"
    @Volatile private var natCandidate: NexusNatTraversal.Candidate? = null
    @Volatile private var lastNatProbeAt = 0L
    private val refreshPool = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "nexus-route-refresh").apply { isDaemon = true } }

    override fun onCreate() {
        super.onCreate()
        gatewayEnabled = NexusSettings.gatewayEnabled(this)
        transitEnabled = NexusSettings.transitEnabled(this)
        nsd = NsdController(this)
        router = MeshRouter(NexusIdentity.nodeId(this), { nsd.peersSnapshot() }) { peer -> NexusTrustStore.reputation(this, peer.name) }
        bootstrap = NexusBootstrapManager(this, nsd)
        dht = NexusDht(NexusIdentity.nodeId(this), NexusConfig.DHT_K, java.io.File(filesDir, "nexus-dht"))
        globalRouting = NexusGlobalRoutingTable(NexusIdentity.nodeId(this))
        dtn = NexusDtnStore(this)
        dhtReplicator = NexusDhtReplicator(this, dht) { nsd.peersSnapshot() }.also { it.start() }
        qos = NexusQosController { (NexusSettings.relayLimitMbps(this) * 1_000_000.0 / 8.0).toLong() }
        nat = NexusNatTraversal { NexusVpnRegistry.protect(it) }
        createNotificationChannel()
        startForeground(1001, notification("Nœud NEXUS actif"))
        startNodeServer()
        contentServer = NexusContentServer(this).also { it.start() }
        appTransferServer = NexusAppTransferServer(this).also { it.start() }
        contentReplicator = NexusContentReplicator(this) { nsd.peersSnapshot() }.also { it.start() }
        serviceServer = NexusServiceServer(this).also { it.start() }
        dbReplicator = NexusDatabaseReplicator(this) { nsd.peersSnapshot() }.also { it.start() }
        autoRepair = NexusAutoRepair(this) { nsd.peersSnapshot() }
        publishOwnServices()
        publishOwnNameToDht()
        publishOwnAddressToDht()
        nsd.startDiscovery()
        rebuildServers()
        bootstrap.refresh()
        refreshPool.scheduleAtFixedRate({
            bootstrap.refresh()
            nsd.probeAll()
            nsd.peersSnapshot().forEach { dht.observePeer(it.name) }
            globalRouting.reconcile(nsd.peersSnapshot())
            dht.expire()
            dhtReplicator.replicateOnce()
            dtn.cleanup()
            val nowMs = System.currentTimeMillis()
            if (nowMs - lastRepairAt >= 60_000L) { lastRepairAt = nowMs; runCatching { autoRepair.runOnce() } }
            if (nowMs - lastResourcePublishAt >= 60_000L) { lastResourcePublishAt = nowMs; publishOwnServices(); publishOwnAddressToDht() }
            if (nowMs - lastMessageFlushAt >= 15_000L) { lastMessageFlushAt = nowMs; flushMessageOutbox() }
            if (nowMs - lastRequestPullAt >= 12_000L) { lastRequestPullAt = nowMs; pullAddressRequests() }
            publishStatus()
            rebuildRelayIfNeeded()
            val natNow = System.currentTimeMillis()
            if (natNow - lastNatProbeAt >= 60_000L) {
                lastNatProbeAt = natNow
                runCatching {
                    val result = nat.discover()
                    natCandidate = result.candidates.firstOrNull()
                    natStatus = if (result.reachable) "NAT traversal : ${result.server} → ${natCandidate?.address ?: "mapping inconnue"}:${natCandidate?.port ?: 0}" else "NAT traversal : aucun mapping STUN accessible"
                }
            }
            forwardDtnBundles()
        }, 2, 10, TimeUnit.SECONDS)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            NexusConfig.ACTION_GATEWAY -> setGateway(intent.getBooleanExtra(NexusConfig.EXTRA_ENABLED, false))
            NexusConfig.ACTION_TRANSIT -> setTransit(intent.getBooleanExtra(NexusConfig.EXTRA_ENABLED, true))
            NexusConfig.ACTION_ROTATE_KEY -> rotateKey()
            NexusConfig.ACTION_STOP -> stopSelf()
        }
        return START_STICKY
    }

    private fun startNodeServer() {
        pool.execute {
            runCatching {
                java.net.ServerSocket(NexusConfig.NODE_PORT).use { server ->
                    nodeServer = server
                    nsd.register(NexusIdentity.nodeId(this), NexusConfig.NODE_PORT)
                    while (!server.isClosed) {
                        val socket = server.accept()
                        pool.execute { handleNode(socket) }
                    }
                }
            }
        }
    }

    private fun handleNode(socket: Socket) {
        socket.use {
            runCatching {
                it.soTimeout = 10_000
                val internetValidated = NetworkInspector.snapshot(this).validated
                val advertisedGateway = gatewayEnabled && internetValidated
                // A gateway must advertise itself as a relay-capable entry point even when
                // the user did not enable transit forwarding. Transit controls forwarding to
                // other NEXUS nodes; gateway egress is already a real local Internet service.
                val advertisedRelay = transitEnabled || advertisedGateway
                NxpProtocol.serverHandshake(
                    it,
                    NexusIdentity.nodeId(this),
                    advertisedGateway,
                    advertisedRelay,
                    router.gatewayDistance(advertisedGateway, transitEnabled),
                    router.gatewayPath(advertisedGateway, transitEnabled),
                    gatewayPublicKey = if (advertisedGateway) NexusIdentity.publicKeyBase64(this) else router.gatewayPublicKey(false, transitEnabled),
                    identityContext = this,
                    dhtProvider = dht,
                    dtnProvider = dtn,
                    natCandidateProvider = { natCandidate },
                    secretProvider = { NetworkKeyManager.accepted(this) }
                )
            }
        }
    }

    private fun flushMessageOutbox() {
        runCatching {
            val outbox = NexusMessageOutbox(this)
            val peers = nsd.peersSnapshot().filter { it.host.isNotBlank() && NexusTrustStore.isAllowed(this, it.name) }
            if (peers.isEmpty()) return
            outbox.pending(4).forEach { pending ->
                val direct = peers.firstOrNull { it.name == pending.recipient }
                val candidates = (listOfNotNull(direct) + peers.filter { it !== direct }).distinctBy { it.name }.take(6)
                val delivered = candidates.any { peer ->
                    NexusServiceProtocol.sendMessage(this, peer.host, pending.recipient, pending.body, peer.port, queueOnFailure = false).isSuccess
                }
                if (delivered) outbox.ack(pending.id) else outbox.defer(pending.id)
            }
        }
    }

    private fun publishOwnServices() {
        runCatching {
            val offer=NexusResourceMarket.wire(this)
            val record=dht.signed(this,"resource:${NexusIdentity.nodeId(this)}",offer,5*60_000L)
            dht.put(record)
        }
    }

    private fun publishOwnNameToDht() {
        runCatching {
            val own = NexusNaming.own(this, NexusAddress.advertisedAddresses(this))
            val record = dht.signed(this, own.name, NexusNaming.wire(own), own.expiresAt - System.currentTimeMillis())
            dht.put(record)
        }
    }

    private fun publishOwnAddressToDht() {
        runCatching { dht.put(NexusAddressBook.dhtRecord(this)) }
    }

    private fun pullAddressRequests() {
        runCatching {
            NexusPeerRequests.cleanup(this)
            val requests = NexusPeerRequests.pull(this, nsd.peersSnapshot())
            val pending = NexusPeerRequests.pending(this).size
            if (pending > lastRequestNoticeCount) {
                val added = pending - lastRequestNoticeCount
                lastRequestNoticeCount = pending
                updateNotification("NEXUS : $added nouvelle(s) demande(s) de connexion")
            } else if (pending < lastRequestNoticeCount) {
                lastRequestNoticeCount = pending
            }
            requests.forEach { NexusTrustStore.observe(this, it.senderNodeId, it.senderPublicKey) }
        }
    }

    private fun forwardDtnBundles() {
        if (!::dtn.isInitialized) return
        val peers = nsd.peersSnapshot().filter { it.host.isNotBlank() && NexusTrustStore.isAllowed(this, it.name) }
        if (peers.isEmpty()) return
        dtn.pending(4).forEach { bundle ->
            val direct = peers.firstOrNull { it.name == bundle.destination }
            val candidates = (listOfNotNull(direct) + peers.filter { it !== direct }).distinctBy { it.name }.take(6)
            var delivered = false
            for (peer in candidates) {
                val ok = if (peer.name !in bundle.visited) NxpProtocol.forwardDtn(
                    peer.host, peer.port, bundle, NexusIdentity.nodeId(this), { NetworkKeyManager.accepted(this) }
                ) else false
                if (ok) { NexusTrustStore.reward(this, peer.name, 0.01); delivered = true; break }
                NexusTrustStore.penalize(this, peer.name, 0.005)
            }
            if (delivered) dtn.ack(bundle.id) else dtn.defer(bundle.id)
        }
    }

    private fun setGateway(enabled: Boolean) {
        gatewayEnabled = enabled
        NexusSettings.setGateway(this, enabled)
        rebuildServers()
    }

    private fun setTransit(enabled: Boolean) {
        transitEnabled = enabled
        NexusSettings.setTransit(this, enabled)
        rebuildServers()
    }

    private fun rotateKey() {
        val next = NetworkKeyManager.rotate(this)
        // The previous key remains accepted locally for a short grace window.
        publishStatus("Clé réseau renouvelée • empreinte ${NetworkKeyManager.fingerprint(next)}")
        nsd.probeAll()
    }

    private fun rebuildRelayIfNeeded() {
        if (transitEnabled && relayServer == null) rebuildServers()
    }

    private fun rebuildServers() {
        socksServer?.stop()
        socksServer = null
        relayServer?.stop()
        relayServer = null

        if (gatewayEnabled || transitEnabled) {
            relayServer = RelayServer(
                NexusConfig.RELAY_PORT,
                nodeIdProvider = { NexusIdentity.nodeId(this) },
                secretProvider = { NetworkKeyManager.accepted(this) },
                directInternetAvailable = { gatewayEnabled && NetworkInspector.snapshot(this).validated },
                nextHopSelector = { visited -> router.chooseNextHop(visited, router.gatewayDistance(gatewayEnabled, transitEnabled)) },
                nextHopCandidatesSelector = { visited -> router.candidates(visited, router.gatewayDistance(gatewayEnabled, transitEnabled), 6) },
                onRouteFailure = { router.reportFailure(it); NexusTrustStore.penalize(this, it, 0.05) },
                onRouteSuccess = { router.reportSuccess(it); NexusTrustStore.reward(this, it, 0.02) },
                protectSocket = { NexusVpnRegistry.protect(it) },
                protectDatagram = { NexusVpnRegistry.protect(it) },
                context = this,
                qosController = qos
            ).also { it.start() }
        }

        val socksUpstream = RoutedNexusUpstream(
            vpn = null,
            nodeId = NexusIdentity.nodeId(this),
            networkKeyProvider = { NetworkKeyManager.current(this) },
            gatewayEnabled = { gatewayEnabled },
            transitEnabled = { transitEnabled },
            router = router,
            context = this
        )
        socksServer = Socks5Server(
            NexusConfig.SOCKS_PORT,
            NexusConfig.SOCKS_USERNAME,
            NexusIdentity.localSocksPassword(this),
            connector = { host, port -> socksUpstream.openTcp(host, port) },
            udpConnector = { host, port -> socksUpstream.openUdp(host, port) }
        ).also { it.start() }

        publishStatus()
    }

    private fun publishStatus(extra: String? = null) {
        val validated = NetworkInspector.snapshot(this).validated
        val route = router.summary(gatewayEnabled && validated, transitEnabled)
        val gatewayText = when {
            gatewayEnabled && validated -> "Passerelle validée"
            gatewayEnabled -> "Passerelle activée • Internet non validé"
            else -> "Pas de passerelle locale"
        }
        val text = when {
            gatewayEnabled && transitEnabled -> "$gatewayText + transit • $route"
            gatewayEnabled -> "$gatewayText • $route"
            transitEnabled -> "Transit actif • $route"
            else -> "Nœud actif • $route"
        }
        updateNotification((extra ?: text) + " • ${globalRouting.domainSummary()} • DHT=${dht.size()} • DTN=${dtn.pending(128).size} • $natStatus")
    }

    override fun onDestroy() {
        nsd.unregister()
        nsd.close()
        runCatching { nodeServer?.close() }
        socksServer?.stop()
        relayServer?.stop()
        contentServer?.stop()
        appTransferServer?.stop()
        contentReplicator?.stop()
        serviceServer?.stop()
        dbReplicator?.stop()
        if (::dhtReplicator.isInitialized) dhtReplicator.stop()
        refreshPool.shutdownNow()
        pool.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("nexus", "NEXUS", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun notification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, "nexus")
            .setContentTitle("NEXUS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(1001, notification(text.take(160)))
    }
}
