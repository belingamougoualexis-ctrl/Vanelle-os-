package com.nexus.network

import android.content.Context
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec

object NexusIdentity {
    private const val PREFS = "nexus_identity"
    private const val KEY_ID = "node_id"
    private const val LEGACY_SECRET = "gateway_secret"
    private const val LEGACY_NETWORK = "network_key"
    private const val SECURE_SECRET = "gateway_secret"
    private const val SECURE_NETWORK = "network_key"
    private const val SECURE_PRIVATE = "identity_ec_private"
    private const val SECURE_PUBLIC = "identity_ec_public"

    fun nodeId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ID, null) ?: run {
            val value = "NX-" + randomToken(10)
            prefs.edit().putString(KEY_ID, value).apply()
            value
        }
    }

    fun gatewaySecret(context: Context): String {
        NexusSecureStore.get(context, SECURE_SECRET)?.let { return it }
        val legacy = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(LEGACY_SECRET, null)
        if (legacy != null) {
            NexusSecureStore.put(context, SECURE_SECRET, legacy)
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(LEGACY_SECRET).apply()
            return legacy
        }
        val value = randomToken(12)
        NexusSecureStore.put(context, SECURE_SECRET, value)
        return value
    }

    fun networkKey(context: Context): String {
        NexusSecureStore.get(context, SECURE_NETWORK)?.let { return it }
        val legacy = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(LEGACY_NETWORK, null)
        if (legacy != null) {
            NexusSecureStore.put(context, SECURE_NETWORK, legacy)
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(LEGACY_NETWORK).apply()
            return legacy
        }
        val value = gatewaySecret(context)
        NexusSecureStore.put(context, SECURE_NETWORK, value)
        return value
    }

    fun setNetworkKey(context: Context, value: String) {
        require(value.length >= 8)
        NexusSecureStore.put(context, SECURE_NETWORK, value)
    }

    /** Per-installation local SOCKS credential; never shared or hard-coded in the APK. */
    fun localSocksPassword(context: Context): String {
        val key = "local_socks_password"
        NexusSecureStore.get(context, key)?.let { return it }
        val value = randomToken(24)
        NexusSecureStore.put(context, key, value)
        return value
    }

    fun publicKey(context: Context): PublicKey = keyPair(context).public

    fun publicKeyBase64(context: Context): String = NexusCrypto.encodeBytes(publicKey(context).encoded)

    fun publicKeyFingerprint(context: Context): String = NexusCrypto.sha256Hex(publicKeyBase64(context)).take(24).uppercase()

    fun sign(context: Context, canonical: String): ByteArray {
        val signature = Signature.getInstance("SHA256withECDSA")
        signature.initSign(keyPair(context).private)
        signature.update(canonical.toByteArray(Charsets.UTF_8))
        return signature.sign()
    }

    fun verify(publicKeyB64: String, canonical: String, signatureB64: String): Boolean = runCatching {
        val key = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(NexusCrypto.decodeBytes(publicKeyB64)))
        val signature = Signature.getInstance("SHA256withECDSA")
        signature.initVerify(key)
        signature.update(canonical.toByteArray(Charsets.UTF_8))
        signature.verify(NexusCrypto.decodeBytes(signatureB64))
    }.getOrDefault(false)

    fun ecdh(privateKey: PrivateKey, peerPublicKeyB64: String): ByteArray {
        val peer = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(NexusCrypto.decodeBytes(peerPublicKeyB64)))
        val agreement = javax.crypto.KeyAgreement.getInstance("ECDH")
        agreement.init(privateKey)
        agreement.doPhase(peer, true)
        return agreement.generateSecret()
    }

    fun generateEphemeral(): KeyPair {
        val generator = KeyPairGenerator.getInstance("EC")
        generator.initialize(ECGenParameterSpec("secp256r1"), SecureRandom())
        return generator.generateKeyPair()
    }

    private fun keyPair(context: Context): KeyPair {
        val privateEncoded = NexusSecureStore.get(context, SECURE_PRIVATE)
        val publicEncoded = NexusSecureStore.get(context, SECURE_PUBLIC)
        if (privateEncoded != null && publicEncoded != null) {
            runCatching {
                val privateKey = KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(NexusCrypto.decodeBytes(privateEncoded)))
                val publicKey = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(NexusCrypto.decodeBytes(publicEncoded)))
                return KeyPair(publicKey, privateKey)
            }
        }
        val generated = generateEphemeral()
        NexusSecureStore.put(context, SECURE_PRIVATE, NexusCrypto.encodeBytes(generated.private.encoded))
        NexusSecureStore.put(context, SECURE_PUBLIC, NexusCrypto.encodeBytes(generated.public.encoded))
        return generated
    }

    private fun randomToken(length: Int): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val random = SecureRandom()
        return buildString(length) { repeat(length) { append(alphabet[random.nextInt(alphabet.length)]) } }
    }
}
