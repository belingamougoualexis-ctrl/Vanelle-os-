package com.nexus.network

import android.net.VpnService
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.LinkedHashMap
import java.util.TreeMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max
import kotlin.math.min

/**
 * Real userspace IP stack for the Android TUN.
 *
 * Supported transport path:
 *  - IPv4 + IPv6 base headers
 *  - IPv6 Hop-by-Hop / Routing / Destination / AH extension headers
 *  - bounded IPv6 Fragment reassembly with overlap rejection
 *  - TCP stateful termination with MSS, window scaling, SACK, timestamps,
 *    receive reordering, retransmission, RTT/RTO estimation and congestion control
 *  - UDP NAT/proxy over a real upstream socket or NEXUS relay
 *
 * The application is a proxy/NAT endpoint, not a kernel replacement. ICMP/ICMPv6
 * and unusual IPv6 extension protocols are deliberately rejected rather than faked.
 */
class UserSpaceIpStack(
    private val tunInput: InputStream,
    private val tunOutput: OutputStream,
    private val upstream: UpstreamTransport,
    private val dnsContext: android.content.Context? = null,
    private val dnsPeers: () -> Collection<NsdController.Peer> = { emptyList() },
    private val dnsServers: () -> List<String> = { emptyList() },
    private val dnsSocketProtect: (DatagramSocket) -> Boolean = { NexusVpnRegistry.protect(it) }
) {
    private val tcpMaxUnacked = 256 * 1024
    private val receiveBuffer = 256 * 1024
    private val icmpErrorWindowStart = AtomicLong(0L)
    private val icmpErrorCount = AtomicInteger(0)
    private val maxIcmpErrorsPerSecond = 20
    private val maxTcpAttempts = 7
    private val ipv4Mss = 1380
    private val ipv6Mss = 1220
    private val defaultRto = 1_000L
    private val minRto = 200L
    private val maxRto = 60_000L
    private val synRetryRto = 700L
    private val windowScale = 4
    private val reassembler = Ipv6FragmentReassembler()
    private val ipv6Control = Ipv6ControlPlane(
        virtualAddress = InetAddress.getByName("fd00:4e58:5553::2") as Inet6Address,
        linkLocal = InetAddress.getByName("fe80::2") as Inet6Address
    )

    interface UpstreamTransport {
        fun openTcp(host: String, port: Int): NexusStreamChannel
        fun openUdp(host: String, port: Int): UdpChannel
    }

    interface UdpChannel : AutoCloseable {
        fun send(payload: ByteArray)
        fun startReceiver(onPayload: (ByteArray) -> Unit): Thread
        override fun close()
    }

    private data class FlowKey(val family: Int, val src: String, val sport: Int, val dst: String, val dport: Int)
    private data class PendingTcp(
        val sequence: Long,
        val endSequence: Long,
        val packet: ByteArray,
        val label: String,
        var sentAt: Long,
        var attempts: Int = 1,
        var retransmitted: Boolean = false
    )

    private val tcp = ConcurrentHashMap<FlowKey, TcpFlow>()
    private val udp = ConcurrentHashMap<FlowKey, UdpFlow>()
    private val workers = Executors.newCachedThreadPool { r -> Thread(r, "nexus-ip-${System.nanoTime()}").apply { isDaemon = true } }
    private val timer = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "nexus-ip-cleaner").apply { isDaemon = true } }
    private val packetId = AtomicInteger(1)
    private val packets = AtomicLong(0)
    private val bytes = AtomicLong(0)
    private val tunAccumulator = ByteArrayOutputStream(64 * 1024)
    private var cleanup: ScheduledFuture<*>? = null
    @Volatile private var running = false

    fun start() {
        if (running) return
        running = true
        cleanup = timer.scheduleAtFixedRate({
            cleanupFlows()
            tcp.values.forEach { it.retransmitDue() }
        }, 250, 250, TimeUnit.MILLISECONDS)
        workers.execute { readLoop() }
    }

    fun stop() {
        if (!running) return
        running = false
        cleanup?.cancel(true)
        tcp.values.forEach { it.close() }
        udp.values.forEach { it.close() }
        ipv6Control.expire()
        tcp.clear(); udp.clear(); reassembler.clear()
        timer.shutdownNow(); workers.shutdownNow()
    }

    fun status(): String =
        "IPv4+IPv6 • TCP=${tcp.size} • UDP=${udp.size} • paquets=${packets.get()} • octets=${bytes.get()}"

    private fun readLoop() {
        val buffer = ByteArray(64 * 1024)
        try {
            while (running) {
                val n = tunInput.read(buffer)
                if (n < 0) break
                if (n == 0) continue
                packets.incrementAndGet(); bytes.addAndGet(n.toLong())
                consumeTunChunk(buffer, n)
            }
        } catch (_: Exception) { }
    }

    private fun consumeTunChunk(buffer: ByteArray, length: Int) {
        tunAccumulator.write(buffer, 0, length)
        val all = tunAccumulator.toByteArray()
        var offset = 0
        while (all.size - offset >= 40) {
            val version = (all[offset].toInt() ushr 4) and 0x0f
            val totalLength = when (version) {
                4 -> {
                    if (all.size - offset < 20) break
                    val ihl = (all[offset].toInt() and 0x0f) * 4
                    if (ihl !in 20..60) { offset++; continue }
                    IpPacket.u16(all, offset + 2)
                }
                6 -> 40 + IpPacket.u16(all, offset + 4)
                else -> { offset++; continue }
            }
            if (totalLength <= 0 || totalLength > 65_535) { offset++; continue }
            if (all.size - offset < totalLength) break
            val packet = all.copyOfRange(offset, offset + totalLength)
            workers.execute { handlePacket(packet) }
            offset += totalLength
        }
        tunAccumulator.reset()
        if (offset < all.size) tunAccumulator.write(all, offset, all.size - offset)
        if (tunAccumulator.size() > 131_072) tunAccumulator.reset()
    }

    private fun handlePacket(packet: ByteArray) {
        if (packet.isEmpty()) return
        when ((packet[0].toInt() ushr 4) and 0x0f) {
            4 -> handleIpv4(packet)
            6 -> handleIpv6(packet)
        }
    }

    private fun handleIpv4(packet: ByteArray) {
        val ip = IpPacket.parseIpv4(packet) ?: return
        when (ip.protocol) {
            6 -> handleTcp(4, ip.src, ip.dst, ip.payload)
            17 -> handleUdp(4, ip.src, ip.dst, ip.payload)
        }
    }

    private fun handleIpv6(packet: ByteArray) {
        val ip = Ipv6Packet.parse(packet) ?: return
        var payload = ip.payload
        if (ip.fragment != null) {
            val f = ip.fragment
            payload = reassembler.offer(
                Ipv6FragmentReassembler.Key(ip.src.hostAddress, ip.dst.hostAddress, f.id, ip.nextHeader),
                f.offsetBytes,
                f.more,
                payload
            ) ?: return
        }
        when (ip.nextHeader) {
            6 -> handleTcp(6, ip.src, ip.dst, payload)
            17 -> handleUdp(6, ip.src, ip.dst, payload)
            58 -> handleIcmpv6(ip.src, ip.dst, payload, ip.hopLimit, ip.routerAlert)
            else -> writeIcmpv6Error(4, 1, 0, ip.src, ip.dst, packet)
        }
    }

    private fun handleIcmpv6(src: Inet6Address, dst: Inet6Address, payload: ByteArray, hopLimit: Int, routerAlert: Boolean) {
        val msg = Icmpv6.parse(payload, src, dst) ?: return
        val nd = msg.type in setOf(Icmpv6.ROUTER_SOLICITATION, Icmpv6.ROUTER_ADVERTISEMENT, Icmpv6.NEIGHBOR_SOLICITATION, Icmpv6.NEIGHBOR_ADVERTISEMENT, Icmpv6.REDIRECT)
        val mld = msg.type in setOf(Icmpv6.MLD_QUERY, Icmpv6.MLD_REPORT_V1, Icmpv6.MLD_DONE, Icmpv6.MLD_REPORT_V2)
        if (nd && hopLimit != 255) return
        if (mld && (hopLimit != 1 || !routerAlert)) return
        val response = ipv6Control.handle(src, msg) ?: return
        // ND/MLD messages are link-local control traffic. Keep the generated
        // packet on the virtual NEXUS link instead of sending it through TCP/UDP.
        val responseDst = when (msg.type) {
            Icmpv6.ROUTER_SOLICITATION, Icmpv6.NEIGHBOR_SOLICITATION ->
                if (src.isAnyLocalAddress) InetAddress.getByName("ff02::1") as Inet6Address else src
            Icmpv6.MLD_QUERY -> InetAddress.getByName("ff02::16") as Inet6Address
            else -> src
        }
        val source = when (msg.type) {
            Icmpv6.ROUTER_ADVERTISEMENT, Icmpv6.NEIGHBOR_ADVERTISEMENT, Icmpv6.ECHO_REPLY -> dst
            else -> InetAddress.getByName("fe80::2") as Inet6Address
        }
        val finalized = Icmpv6.finalize(source, responseDst, response)
        val responseHopLimit = if (msg.type in setOf(Icmpv6.ROUTER_SOLICITATION, Icmpv6.NEIGHBOR_SOLICITATION, Icmpv6.MLD_QUERY, Icmpv6.MLD_REPORT_V1, Icmpv6.MLD_REPORT_V2, Icmpv6.MLD_DONE)) 255 else 64
        writePacket(Ipv6Packet.build(source, responseDst, 58, finalized, hopLimit = responseHopLimit))
    }

    private fun writeIcmpv6Error(type: Int, code: Int, value: Int, src: Inet6Address, dst: Inet6Address, invoking: ByteArray) {
        // RFC 4443 requires ICMPv6 error suppression for error packets, multicast
        // destinations (with defined exceptions), and unspecified sources.
        if (src.isAnyLocalAddress || src.isMulticastAddress || dst.isMulticastAddress) return
        val now = System.currentTimeMillis()
        val start = icmpErrorWindowStart.get()
        if (start == 0L || now - start >= 1000L) {
            if (icmpErrorWindowStart.compareAndSet(start, now)) icmpErrorCount.set(0)
        }
        if (icmpErrorCount.incrementAndGet() > maxIcmpErrorsPerSecond) return
        val body = Icmpv6.error(type, code, value, invoking)
        val raw = Icmpv6.finalize(dst, src, body)
        writePacket(Ipv6Packet.build(dst, src, 58, raw, hopLimit = 64))
    }

    private fun handleUdp(family: Int, src: InetAddress, dst: InetAddress, payload: ByteArray) {
        val header = if (payload.size >= 8) IpPacket.Udp(
            IpPacket.u16(payload, 0), IpPacket.u16(payload, 2), IpPacket.u16(payload, 4), IpPacket.u16(payload, 6),
            payload.copyOfRange(8, min(IpPacket.u16(payload, 4).coerceAtLeast(8), payload.size))
        ) else return
        val len = header.length
        if (len < 8 || len > payload.size) return
        val valid = if (family == 4) {
            IpPacket.validateUdpChecksum(src as Inet4Address, dst as Inet4Address, payload.copyOfRange(0, len))
        } else {
            Ipv6Packet.validateUdpChecksum(src as Inet6Address, dst as Inet6Address, payload.copyOfRange(0, len))
        }
        if (!valid) return
        if (header.dstPort == 53 && dnsContext != null && (dst == NexusDns.IPV4 || dst == NexusDns.IPV6)) {
            val context = dnsContext
            val answer = runCatching {
                NexusDns.handleQuery(context, header.payload, dnsPeers(), dnsSocketProtect, dnsServers())
            }.getOrNull()
            if (answer != null) {
                writePacket(buildUdpReply(dst, src, 53, header.srcPort, answer))
            }
            return
        }
        val key = FlowKey(family, src.hostAddress, header.srcPort, dst.hostAddress, header.dstPort)
        val flow = udp.getOrPut(key) {
            runCatching {
                val channel = upstream.openUdp(dst.hostAddress, header.dstPort)
                UdpFlow(key, src, dst, header.srcPort, header.dstPort, channel).also { newFlow ->
                    channel.startReceiver { response ->
                        if (!running || newFlow.closed) return@startReceiver
                        val reply = buildUdpReply(newFlow.remote, newFlow.client, newFlow.remotePort, newFlow.clientPort, response)
                        writePacket(reply); newFlow.touch()
                    }
                }
            }.getOrNull()
        } ?: return
        runCatching { flow.channel.send(header.payload); flow.touch() }.onFailure { flow.close() }
    }

    private fun handleTcp(family: Int, src: InetAddress, dst: InetAddress, payload: ByteArray) {
        val seg = IpPacket.parseTcp(payload) ?: return
        val valid = if (family == 4) IpPacket.validateTcpChecksum(src as Inet4Address, dst as Inet4Address, payload)
        else Ipv6Packet.validateTcpChecksum(src as Inet6Address, dst as Inet6Address, payload)
        if (!valid) return
        val key = FlowKey(family, src.hostAddress, seg.srcPort, dst.hostAddress, seg.dstPort)
        if (seg.rst) { tcp.remove(key)?.close(); return }
        if (seg.syn && !seg.ack) {
            tcp[key]?.resendSynAck() ?: workers.execute { openTcpFlow(key, family, src, dst, seg) }
            return
        }
        tcp[key]?.onSegment(seg)
    }

    private fun openTcpFlow(key: FlowKey, family: Int, src: InetAddress, dst: InetAddress, syn: IpPacket.Tcp) {
        if (!running) return
        val flow = runCatching {
            val channel = upstream.openTcp(dst.hostAddress, syn.dstPort)
            TcpFlow(key, family, src, dst, syn.srcPort, syn.dstPort, syn.sequence, syn.options, channel)
        }.getOrNull()
        if (flow == null) {
            writePacket(buildTcpPacket(family, dst, src, syn.dstPort, syn.srcPort, 0, (syn.sequence + 1) and 0xffffffffL, 0x014, 0))
            return
        }
        if (tcp.putIfAbsent(key, flow) != null) { flow.close(); return }
        flow.sendSynAck()
    }

    private inner class TcpFlow(
        private val key: FlowKey,
        private val family: Int,
        val client: InetAddress,
        val remote: InetAddress,
        val clientPort: Int,
        val remotePort: Int,
        initialClientSeq: Long,
        synOptions: TcpOptions,
        private val channel: NexusStreamChannel
    ) {
        private val lock = Any()
        private val pending = LinkedHashMap<Long, PendingTcp>()
        private val outOfOrder = TreeMap<Long, ByteArray>()
        @Volatile private var lastActivity = System.currentTimeMillis()
        @Volatile private var closed = false
        @Volatile private var established = false
        @Volatile private var remoteReaderStarted = false
        @Volatile private var localFinSent = false
        @Volatile private var peerFinReceived = false
        private val peerMss = (synOptions.mss ?: if (family == 6) ipv6Mss else 536).coerceIn(536, 8960)
        private val clientWindowScale = synOptions.windowScale ?: 0
        private val localWindowScale = if (synOptions.windowScale != null) windowScale else 0
        private val sackPermitted = synOptions.sackPermitted
        private val timestampNegotiated = synOptions.timestampValue != null
        private val effectiveMss = minOf(localMss(), peerMss)
        private var peerTsVal = synOptions.timestampValue ?: 0L
        private var recvNext = (initialClientSeq + 1) and 0xffffffffL
        private var sendNext = ((System.nanoTime() xor initialClientSeq) and 0xffffffffL)
        private var peerWindowBytes = 65535L
        private var unackedBytes = 0
        private var cwnd = 10L * effectiveMss
        private var ssthresh = 64L * 1024L
        private var lastAck = sendNext
        private var duplicateAcks = 0
        private var lastFastRetransmitAck: Long? = null
        private var srtt: Double? = null
        private var rttvar: Double? = null
        private var rtoMs = defaultRto

        private fun localMss() = if (family == 6) ipv6Mss else ipv4Mss

        fun sendSynAck() = synchronized(lock) {
            if (closed) return@synchronized
            val packet = buildTcpPacket(
                family, remote, client, remotePort, clientPort, sendNext, recvNext, 0x012,
                65535, options = TcpOptionCodec.synAck(localMss(), localWindowScale, sackPermitted, nowTs(), peerTsVal.takeIf { timestampNegotiated })
            )
            queueAndSend(packet, sendNext, (sendNext + 1) and 0xffffffffL, "SYN-ACK")
            sendNext = (sendNext + 1) and 0xffffffffL
        }

        fun resendSynAck() = synchronized(lock) {
            pending.values.firstOrNull { it.label == "SYN-ACK" }?.let {
                writePacket(it.packet); it.sentAt = System.currentTimeMillis(); it.attempts++; it.retransmitted = true
            }
        }

        fun onSegment(seg: IpPacket.Tcp) {
            if (closed) return
            touch()
            synchronized(lock) {
                val opts = seg.options
                if (opts.timestampValue != null) peerTsVal = opts.timestampValue
                peerWindowBytes = ((seg.window.toLong() and 0xffff) shl localWindowScale).coerceAtMost(tcpMaxUnacked.toLong())

                if (seg.ack) {
                    val before = lastAck
                    val advanced = acknowledge(seg.acknowledgement, seg.options.sackBlocks)
                    if (seg.acknowledgement == before && seg.payload.isEmpty() && pending.isNotEmpty()) {
                        duplicateAcks++
                        if (duplicateAcks >= 3 && lastFastRetransmitAck != seg.acknowledgement) {
                            fastRetransmitLocked(seg.acknowledgement)
                            lastFastRetransmitAck = seg.acknowledgement
                        }
                    } else if (advanced) {
                        duplicateAcks = 0
                        lastFastRetransmitAck = null
                        lastAck = seg.acknowledgement
                    }
                    if (!established && seg.acknowledgement == sendNext && pending.values.none { it.label == "SYN-ACK" }) {
                        established = true
                        startRemoteReaderLocked()
                    }
                }
                if (!established) return

                if (seg.payload.isNotEmpty()) receiveClientDataLocked(seg)
                if (seg.fin) {
                    val finSeq = (seg.sequence + seg.payload.size) and 0xffffffffL
                    if (finSeq == recvNext) {
                        recvNext = (recvNext + 1) and 0xffffffffL
                        peerFinReceived = true
                        runCatching { channel.shutdownOutput() }
                        sendAckLocked()
                        maybeCloseAfterHalfClose()
                    } else {
                        sendAckLocked()
                    }
                } else if (seg.payload.isNotEmpty() || seg.ack) {
                    sendAckLocked()
                }
            }
        }

        private fun receiveClientDataLocked(seg: IpPacket.Tcp) {
            val seq = seg.sequence
            if (seq == recvNext) {
                deliverContiguousLocked(seg.payload)
                drainReorderLocked()
                return
            }
            if (seqLeq(seq, recvNext)) {
                val consumed = sequenceDistance(seq, recvNext).toInt()
                if (consumed < seg.payload.size) {
                    deliverContiguousLocked(seg.payload.copyOfRange(consumed, seg.payload.size))
                    drainReorderLocked()
                }
                return
            }
            val available = receiveWindowAvailableLocked()
            if (available <= 0) return
            val accept = min(seg.payload.size.toLong(), available).toInt()
            val ahead = ((seq - recvNext) and 0xffffffffL)
            if (ahead <= receiveBuffer.toLong()) {
                outOfOrder.putIfAbsent(seq, seg.payload.copyOf(accept))
            }
            touch(); sendAckLocked()
        }

        private fun deliverContiguousLocked(payload: ByteArray) {
            if (payload.isEmpty()) return
            val maxBytes = receiveWindowAvailableLocked()
            val accepted = min(payload.size.toLong(), maxBytes).toInt()
            if (accepted <= 0) return
            runCatching {
                channel.output.write(payload, 0, accepted); channel.output.flush()
                recvNext = (recvNext + accepted) and 0xffffffffL
            }.onFailure { sendResetLocked(); close() }
        }

        private fun drainReorderLocked() {
            while (true) {
                val e = outOfOrder.floorEntry(recvNext) ?: break
                if (e.key != recvNext) break
                outOfOrder.remove(e.key)
                deliverContiguousLocked(e.value)
                if (closed) break
            }
        }

        private fun receiveWindowAvailableLocked(): Long {
            val buffered = outOfOrder.values.sumOf { it.size }.toLong()
            return (receiveBuffer - buffered).coerceAtLeast(0).toLong()
        }

        fun retransmitDue() {
            if (closed) return
            val now = System.currentTimeMillis()
            synchronized(lock) {
                val item = pending.values.firstOrNull { now - it.sentAt >= if (it.label == "SYN-ACK") synRetryRto else rtoMs }
                    ?: return
                if (item.attempts >= maxTcpAttempts) { sendResetLocked(); close(); return }
                writePacket(item.packet); item.sentAt = now; item.attempts++; item.retransmitted = true
                if (item.label != "SYN-ACK") {
                    ssthresh = maxOf(cwnd / 2, 2L * effectiveMss)
                    cwnd = effectiveMss.toLong()
                    rtoMs = min(maxRto, rtoMs * 2)
                }
            }
        }

        private fun acknowledge(ack: Long, sacks: List<SackBlock>): Boolean {
            var advanced = false
            val now = System.currentTimeMillis()
            val iterator = pending.entries.iterator()
            while (iterator.hasNext()) {
                val item = iterator.next().value
                val covered = seqLeq(item.endSequence, ack) || sacks.any { sackCovers(it, item.sequence, item.endSequence) }
                if (covered) {
                    iterator.remove()
                    val bytes = sequenceDistance(item.sequence, item.endSequence)
                    unackedBytes = (unackedBytes - bytes.toInt()).coerceAtLeast(0)
                    if (seqLeq(item.endSequence, ack)) {
                        advanced = true
                        if (!item.retransmitted) updateRtt(now - item.sentAt)
                        congestionAck(bytes.toInt())
                    }
                }
            }
            return advanced
        }

        private fun sackCovers(s: SackBlock, start: Long, end: Long): Boolean = seqLeq(s.left, start) && seqLeq(end, s.rightExclusive)

        private fun congestionAck(ackedBytes: Int) {
            val mss = effectiveMss.toLong()
            if (cwnd < ssthresh) cwnd += min(ackedBytes.toLong(), mss) else cwnd += max(1L, (mss * mss) / max(cwnd, 1L))
            cwnd = cwnd.coerceIn(2L * mss, tcpMaxUnacked.toLong())
        }

        private fun fastRetransmitLocked(ack: Long) {
            val item = pending.values.firstOrNull() ?: return
            writePacket(item.packet); item.sentAt = System.currentTimeMillis(); item.attempts++; item.retransmitted = true
            ssthresh = maxOf(cwnd / 2, 2L * effectiveMss)
            cwnd = min(ssthresh + 3L * effectiveMss, tcpMaxUnacked.toLong())
            lastAck = ack
        }

        private fun updateRtt(sampleMs: Long) {
            val sample = sampleMs.toDouble().coerceAtLeast(1.0)
            if (srtt == null) {
                srtt = sample; rttvar = sample / 2.0
            } else {
                val rv = rttvar ?: sample / 2.0
                rttvar = 0.75 * rv + 0.25 * kotlin.math.abs((srtt ?: sample) - sample)
                srtt = 0.875 * (srtt ?: sample) + 0.125 * sample
            }
            rtoMs = ((srtt ?: sample) + 4.0 * (rttvar ?: sample / 2)).toLong().coerceIn(minRto, maxRto)
        }

        private fun startRemoteReaderLocked() {
            if (remoteReaderStarted) return
            remoteReaderStarted = true
            workers.execute {
                runCatching {
                    val input = channel.input
                    val buffer = ByteArray(32 * 1024)
                    while (running && !closed) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        if (n == 0) continue
                        var offset = 0
                        while (offset < n && running && !closed) {
                            var sent = false
                            synchronized(lock) {
                                val allowed = sendAllowanceLocked()
                                if (allowed > 0) {
                                    val len = min(min(effectiveMss, n - offset), allowed.toInt())
                                    sendDataLocked(buffer.copyOfRange(offset, offset + len))
                                    offset += len; sent = true
                                }
                            }
                            if (!sent) Thread.sleep(10)
                        }
                    }
                    synchronized(lock) { if (!closed && running && !localFinSent) sendFinLocked() }
                }.onFailure {
                    synchronized(lock) { if (!closed && running && !localFinSent) sendFinLocked() }
                }
            }
        }

        private fun sendAllowanceLocked(): Long {
            val window = min(peerWindowBytes, tcpMaxUnacked.toLong())
            return min(window, cwnd) - unackedBytes.toLong()
        }

        private fun sendDataLocked(payload: ByteArray) {
            if (payload.isEmpty() || closed) return
            val flags = 0x018
            val options = ackOptions()
            val packet = buildTcpPacket(family, remote, client, remotePort, clientPort, sendNext, recvNext, flags, advertisedReceiveWindowLocked(), payload, options)
            val start = sendNext; sendNext = (sendNext + payload.size) and 0xffffffffL
            queueAndSend(packet, start, sendNext, "DATA")
            unackedBytes += payload.size
        }

        private fun sendFinLocked() {
            if (localFinSent || closed) return
            val start = sendNext; val end = (sendNext + 1) and 0xffffffffL
            val packet = buildTcpPacket(family, remote, client, remotePort, clientPort, start, recvNext, 0x011, advertisedReceiveWindowLocked(), options = ackOptions())
            queueAndSend(packet, start, end, "FIN")
            sendNext = end; localFinSent = true
        }

        private fun sendAckLocked() {
            val packet = buildTcpPacket(family, remote, client, remotePort, clientPort, sendNext, recvNext, 0x010, advertisedReceiveWindowLocked(), options = ackOptions())
            writePacket(packet)
        }

        private fun sendResetLocked() {
            val packet = buildTcpPacket(family, remote, client, remotePort, clientPort, sendNext, recvNext, 0x014, 0, options = ackOptions())
            writePacket(packet)
        }

        private fun advertisedReceiveWindowLocked(): Int = receiveWindowAvailableLocked().coerceIn(0, 65535).toInt()

        private fun ackOptions(): ByteArray = TcpOptionCodec.ackOptions(
            nowTs().takeIf { timestampNegotiated },
            peerTsVal.takeIf { timestampNegotiated },
            if (sackPermitted) outOfOrder.map { (left, bytes) -> SackBlock(left, (left + bytes.size) and 0xffffffffL) } else emptyList()
        )

        private fun maybeCloseAfterHalfClose() { if (peerFinReceived && localFinSent && pending.isEmpty()) close() }

        private fun queueAndSend(packet: ByteArray, sequence: Long, endSequence: Long, label: String) {
            pending[sequence] = PendingTcp(sequence, endSequence, packet, label, System.currentTimeMillis())
            writePacket(packet)
        }

        fun touch() { lastActivity = System.currentTimeMillis() }
        fun stale(now: Long): Boolean = now - lastActivity > 5 * 60_000

        fun close() {
            if (closed) return
            closed = true
            runCatching { channel.close() }
            tcp.remove(key, this)
        }
    }

    private inner class UdpFlow(
        private val key: FlowKey,
        val client: InetAddress,
        val remote: InetAddress,
        val clientPort: Int,
        val remotePort: Int,
        val channel: UdpChannel
    ) {
        @Volatile var closed = false
        @Volatile private var lastActivity = System.currentTimeMillis()
        fun touch() { lastActivity = System.currentTimeMillis() }
        fun stale(now: Long): Boolean = now - lastActivity > 120_000
        fun close() { if (!closed) { closed = true; runCatching { channel.close() }; udp.remove(key, this) } }
    }

    private fun buildUdpReply(src: InetAddress, dst: InetAddress, srcPort: Int, dstPort: Int, payload: ByteArray): ByteArray =
        if (src is Inet6Address && dst is Inet6Address) Ipv6Packet.buildUdp(src, dst, srcPort, dstPort, payload)
        else IpPacket.buildUdp(src as Inet4Address, dst as Inet4Address, srcPort, dstPort, payload, packetId.getAndUpdate { if (it == 65535) 1 else it + 1 })

    private fun buildTcpPacket(
        family: Int, src: InetAddress, dst: InetAddress, srcPort: Int, dstPort: Int,
        sequence: Long, acknowledgement: Long, flags: Int, window: Int = 65535,
        payload: ByteArray = ByteArray(0), options: ByteArray = ByteArray(0)
    ): ByteArray = if (family == 6) {
        Ipv6Packet.buildTcp(src as Inet6Address, dst as Inet6Address, srcPort, dstPort, sequence, acknowledgement, flags, window, payload, options = options)
    } else {
        IpPacket.buildTcp(src as Inet4Address, dst as Inet4Address, srcPort, dstPort, sequence, acknowledgement, flags, window, payload, packetId.getAndUpdate { if (it == 65535) 1 else it + 1 }, options)
    }

    @Synchronized private fun writePacket(packet: ByteArray) { runCatching { tunOutput.write(packet); tunOutput.flush() } }

    private fun cleanupFlows() {
        val now = System.currentTimeMillis()
        tcp.values.filter { it.stale(now) }.forEach { it.close() }
        udp.values.filter { it.stale(now) }.forEach { it.close() }
    }

    private fun seqLeq(a: Long, b: Long): Boolean = sequenceDistance(a, b) < 0x80000000L
    private fun sequenceDistance(start: Long, end: Long): Long = (end - start) and 0xffffffffL
    private fun nowTs(): Long = (System.nanoTime() / 1_000_000L) and 0xffffffffL
}

class DirectNexusUpstream(private val vpn: VpnService? = null, private val transportManager: NexusTransportManager? = null) : UserSpaceIpStack.UpstreamTransport {
    override fun openTcp(host: String, port: Int): NexusStreamChannel {
        val socket = transportManager?.openTcpMultipath(host, port, 10_000)?.first ?: Socket()
        check((vpn?.protect(socket) ?: NexusVpnRegistry.protect(socket))) { "Impossible de protéger le socket TCP du VPN" }
        if (transportManager == null) socket.connect(InetSocketAddress(host, port), 10_000)
        socket.soTimeout = 0
        return SocketStreamChannel(socket)
    }

    override fun openUdp(host: String, port: Int): UserSpaceIpStack.UdpChannel = NexusUdpChannels.direct(host, port, vpn, transportManager)
}

class RoutedNexusUpstream(
    private val vpn: VpnService?,
    private val nodeId: String,
    private val networkKeyProvider: () -> String,
    private val gatewayEnabled: () -> Boolean,
    private val transitEnabled: () -> Boolean,
    private val router: MeshRouter,
    private val context: android.content.Context? = null,
    private val transportManager: NexusTransportManager? = context?.let { NexusTransportManager(it) }
) : UserSpaceIpStack.UpstreamTransport {
    override fun openTcp(host: String, port: Int): NexusStreamChannel {
        if (gatewayEnabled()) return DirectNexusUpstream(vpn, transportManager).openTcp(host, port)
        // Transit is an inbound-sharing policy. It must not disable outbound
        // long-range routing through a real Internet gateway.
        val distance = router.outboundGatewayDistance()
        val candidates = router.outboundCandidates(setOf(nodeId), distance, limit = 6)
        var last: Exception? = null
        for (next in candidates) {
            runCatching {
                val raw = RelayProtocol.openRelay(
                    next.host, next.port, host, port, networkKeyProvider(), nodeId, listOf(nodeId), NexusConfig.DEFAULT_ROUTE_TTL,
                    endToEnd = context != null
                )
                val secure = if (context != null) {
                    check(next.gatewayPublicKey.isNotBlank()) { "Clé de passerelle E2E absente" }
                    NexusE2E.client(context, raw, nodeId, next.gatewayPublicKey)
                } else raw
                return NexusCreditGatedChannel(secure, context, next.nodeId).also { router.reportSuccess(next.nodeId) }
            }.onFailure { router.reportFailure(next.nodeId); last = it as? Exception ?: RuntimeException(it) }
        }
        throw last ?: IllegalStateException("Aucune route NEXUS vers une passerelle")
    }

    override fun openUdp(host: String, port: Int): UserSpaceIpStack.UdpChannel {
        if (gatewayEnabled()) return DirectNexusUpstream(vpn, transportManager).openUdp(host, port)
        // Transit is an inbound-sharing policy. It must not disable outbound
        // long-range routing through a real Internet gateway.
        val distance = router.outboundGatewayDistance()
        val candidates = router.outboundCandidates(setOf(nodeId), distance, limit = 6)
        var last: Exception? = null
        for (next in candidates) {
            val session = runCatching {
                val raw = DatagramRelayProtocol.openRelay(next.host, next.port, host, port, networkKeyProvider(), nodeId, listOf(nodeId), NexusConfig.DEFAULT_ROUTE_TTL, endToEnd = context != null)
                if (context != null) {
                    check(next.gatewayPublicKey.isNotBlank()) { "Clé de passerelle E2E UDP absente" }
                    NexusE2EDatagram.client(context, raw, nodeId, next.gatewayPublicKey)
                } else raw
            }.getOrNull()
            if (session != null) {
                router.reportSuccess(next.nodeId)
                return object : UserSpaceIpStack.UdpChannel {
                    @Volatile var closed = false
                    override fun send(payload: ByteArray) {
                        if (!closed && (context == null || NexusCredits.spend(context, next.nodeId, payload.size.toLong()))) sessionSend(session, payload)
                    }
                    override fun startReceiver(onPayload: (ByteArray) -> Unit): Thread = Thread {
                        while (!closed) {
                            val packet = runCatching { sessionReceive(session) }.getOrNull() ?: break
                            onPayload(packet)
                        }
                    }.apply { isDaemon = true; name = "nexus-udp-relay"; start() }
                    override fun close() { closed = true; sessionClose(session) }
                }
            }
            router.reportFailure(next.nodeId)
            last = RuntimeException("Échec du relais UDP ${next.nodeId}")
        }
        throw last ?: IllegalStateException("Aucune route NEXUS vers une passerelle")
    }

    private fun sessionSend(session: Any, payload: ByteArray) {
        when (session) {
            is DatagramRelayProtocol.Session -> session.send(payload)
            is NexusE2EDatagram -> session.send(payload)
            else -> error("Session UDP NEXUS inconnue")
        }
    }

    private fun sessionReceive(session: Any): ByteArray? = when (session) {
        is DatagramRelayProtocol.Session -> session.receive()
        is NexusE2EDatagram -> session.receive()
        else -> null
    }

    private fun sessionClose(session: Any) {
        when (session) {
            is DatagramRelayProtocol.Session -> session.close()
            is NexusE2EDatagram -> session.close()
        }
    }
}
