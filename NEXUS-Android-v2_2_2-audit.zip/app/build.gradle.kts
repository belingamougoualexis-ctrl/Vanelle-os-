plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nexus.network"
    compileSdk = 37

    dependencies {
        implementation("androidx.core:core-ktx:1.18.0")
        androidTestImplementation("androidx.test:core:1.7.0")
        androidTestImplementation("androidx.test:ext:junit:1.3.0")
    }

    defaultConfig {
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        applicationId = "com.nexus.network"
        minSdk = 26
        targetSdk = 37
        versionCode = 24
        versionName = "2.2.2"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
