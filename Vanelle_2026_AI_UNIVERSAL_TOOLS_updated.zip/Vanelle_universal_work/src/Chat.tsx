import React, { useEffect, useState } from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  ToastAndroid,
  View,
} from 'react-native';
import { VanelleNative } from './native';
import { getChat, saveChat } from './storage';
import type { AI, Message, VFile } from './types';
import { buildApiToolInstructions, executeApiTool, parseApiToolCall } from './aiApiTools';
import { colors, ErrorBanner, S as Shared } from './ui';

const MAX_FILE_BYTES = 3 * 1024 * 1024 * 1024; // 3 Go par fichier
const TEXT_EXTENSIONS = ['.txt', '.md', '.csv', '.json', '.html', '.htm', '.js', '.css'];
const IMAGE_EXTENSIONS = ['.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp'];

const S = StyleSheet.create({
  chat: { flex: 1, padding: 12 },
  bubble: { maxWidth: '86%', borderRadius: 16, padding: 11, marginBottom: 9 },
  user: { alignSelf: 'flex-end', backgroundColor: '#EEE9FF' },
  bot: {
    alignSelf: 'flex-start',
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: colors.line,
  },
  bubbleText: { fontSize: 14, color: '#1b1b1f', lineHeight: 20 },
  composer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: colors.line,
    backgroundColor: '#fff',
    gap: 6,
  },
  plus: {
    width: 44,
    height: 44,
    borderRadius: 9,
    backgroundColor: colors.accentSoft,
    borderWidth: 1.5,
    borderColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  plusText: { color: colors.accent, fontWeight: '900', fontSize: 22, lineHeight: 24 },
  send: {
    width: 48,
    height: 44,
    borderRadius: 9,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendText: { color: '#fff', fontWeight: '900' },
  attachHint: {
    paddingHorizontal: 12,
    paddingBottom: 4,
    backgroundColor: '#fff',
  },
  menuBtn: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuIcon: { color: '#fff', fontSize: 22, fontWeight: '900', lineHeight: 24 },
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.45)',
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
    paddingBottom: Platform.OS === 'ios' ? 28 : 16,
    maxHeight: '78%',
  },
  sheetHandle: {
    alignSelf: 'center',
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#ddd',
    marginTop: 10,
    marginBottom: 6,
  },
  sheetTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.ink,
    paddingHorizontal: 18,
    paddingVertical: 10,
  },
  menuRow: {
    paddingHorizontal: 18,
    paddingVertical: 14,
    borderTopWidth: 1,
    borderTopColor: colors.line,
  },
  menuRowText: { fontSize: 15, fontWeight: '700', color: colors.ink },
  menuRowSub: { fontSize: 12, color: colors.inkSoft, marginTop: 3, lineHeight: 17 },
  menuDanger: { color: colors.danger },
  panelBox: {
    paddingHorizontal: 18,
    paddingBottom: 12,
  },
  panelCard: {
    backgroundColor: '#f7f7f4',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.line,
    padding: 12,
    marginBottom: 8,
  },
  panelLabel: { fontSize: 11, fontWeight: '700', color: colors.inkSoft, marginBottom: 2 },
  panelValue: { fontSize: 13, fontWeight: '700', color: colors.ink, lineHeight: 18 },
});

const makeId = () => `${Date.now()}-${Math.random().toString(36).slice(2)}`;

function fmtSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} o`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} Ko`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} Mo`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} Go`;
}

type MenuPanel = 'main' | 'knowledge' | 'info';

export function Chat({
  ai,
  back,
  onUpdateAI,
}: {
  ai: AI;
  back: () => void;
  onUpdateAI?: (next: AI) => Promise<void>;
}) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [status, setStatus] = useState('');
  const [localFiles, setLocalFiles] = useState<VFile[]>(ai.files);
  const [menuOpen, setMenuOpen] = useState(false);
  const [menuPanel, setMenuPanel] = useState<MenuPanel>('main');
  const [modelLoaded, setModelLoaded] = useState(true);

  useEffect(() => {
    void getChat(ai.id).then(setMessages);
  }, [ai.id]);

  useEffect(() => {
    // Le modèle est normalement déjà chargé en mémoire au démarrage de l'app
    // (MainApplication). Ce contrôle ne sert qu'à couvrir le cas rare où
    // l'utilisateur ouvre le chat avant la fin de ce préchargement — auquel
    // cas on l'attend ici plutôt que de le refaire au moment d'envoyer.
    let cancelled = false;
    (async () => {
      if (!VanelleNative) return;
      try {
        const status = await VanelleNative.getModelStatus();
        if (cancelled) return;
        if (status.llmLoaded) {
          setModelLoaded(true);
          return;
        }
        setModelLoaded(false);
        await VanelleNative.preloadModel();
        if (!cancelled) setModelLoaded(true);
      } catch {
        if (!cancelled) setModelLoaded(true); // on laisse send() gérer l'erreur
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    setLocalFiles(ai.files);
  }, [ai.files]);

  const openMenu = () => {
    setMenuPanel('main');
    setMenuOpen(true);
  };

  const closeMenu = () => {
    setMenuOpen(false);
    setMenuPanel('main');
  };

  const appendKnowledge = async (added: VFile[]) => {
    if (!added.length) return;
    const nextFiles = [...localFiles, ...added];
    setLocalFiles(nextFiles);
    if (onUpdateAI) {
      await onUpdateAI({ ...ai, files: nextFiles });
    }
  };

  const pickFiles = async () => {
    setError('');
    setStatus('');
    try {
      const { pick } = await import('@react-native-documents/picker');
      const RNFS = (await import('react-native-fs')).default;
      const results = await pick({ allowMultiSelection: true });
      const added: VFile[] = [];

      for (const doc of results) {
        const size = doc.size ?? 0;
        if (size > MAX_FILE_BYTES) {
          setError(
            `« ${doc.name || 'fichier'} » dépasse 3 Go (${fmtSize(size)}). Chaque fichier doit peser au maximum 3 Go.`
          );
          continue;
        }

        const lower = (doc.name || '').toLowerCase();
        const isText = TEXT_EXTENSIONS.some((ext) => lower.endsWith(ext));
        const isImage = IMAGE_EXTENSIONS.some((ext) => lower.endsWith(ext));
        let note = 'Fichier binaire — contenu non extrait automatiquement.';
        if (isImage) {
          note = 'Image jointe — disponible comme référence de connaissance.';
        } else if (isText) {
          try {
            note = (await RNFS.readFile(doc.uri, 'utf8')).slice(0, 8000);
          } catch {
            note = 'Ce fichier a été ajouté mais son contenu n’a pas pu être lu.';
          }
        }

        added.push({
          id: makeId(),
          name: doc.name || 'fichier',
          note,
          size,
          addedAt: Date.now(),
        });
      }

      if (added.length) {
        await appendKnowledge(added);
        setStatus(
          `${added.length} fichier(s) ajouté(s) aux connaissances. L’ancien contenu est conservé.`
        );
        if (Platform.OS === 'android') {
          ToastAndroid.show('Connaissances mises à jour', ToastAndroid.SHORT);
        }
      }
    } catch (e) {
      const code = (e as { code?: string } | null)?.code;
      if (code !== 'OPERATION_CANCELED' && code !== 'DOCUMENT_PICKER_CANCELED') {
        const reason =
          e instanceof Error ? e.message : "L'ajout du fichier a échoué.";
        setError(reason);
      }
    }
  };

  const clearConversation = async () => {
    setMessages([]);
    await saveChat(ai.id, []);
    closeMenu();
    setStatus('Conversation effacée.');
    if (Platform.OS === 'android') {
      ToastAndroid.show('Conversation effacée', ToastAndroid.SHORT);
    }
  };

  const exportChat = async () => {
    try {
      const payload = JSON.stringify(
        {
          ai: { id: ai.id, name: ai.name },
          exportedAt: new Date().toISOString(),
          messages,
        },
        null,
        2
      );
      const fileName = `vanelle-chat-${ai.name.replace(/\s+/g, '-').toLowerCase()}-${Date.now()}.json`;
      try {
        const RNFS = (await import('react-native-fs')).default;
        const dest =
          (RNFS.DownloadDirectoryPath || RNFS.DocumentDirectoryPath) + '/' + fileName;
        if (Platform.OS === 'android') {
          ToastAndroid.show('Téléchargement en cours…', ToastAndroid.SHORT);
        }
        await RNFS.writeFile(dest, payload, 'utf8');
        if (Platform.OS === 'android') {
          ToastAndroid.show('Téléchargement terminé', ToastAndroid.LONG);
        }
        setStatus(`Chat exporté : ${fileName}`);
      } catch {
        await Share.share({ message: payload, title: fileName });
        setStatus('Chat partagé.');
      }
      closeMenu();
    } catch (e) {
      const reason = e instanceof Error ? e.message : "L'export du chat a échoué.";
      setError(reason);
      closeMenu();
    }
  };

  const send = async () => {
    const text = draft.trim();
    if (!text || busy || !modelLoaded) return;

    const userMsg: Message = { id: makeId(), role: 'user', text, ts: Date.now() };
    const next = [...messages, userMsg];
    setMessages(next);
    setDraft('');
    setBusy(true);
    setError('');
    setStatus('Génération en cours…');

    try {
      if (!VanelleNative) {
        throw new Error(
          'Moteur natif indisponible. Vérifiez que l’application a bien installé les modèles GGUF.'
        );
      }

      const teaching = ai.training
        .map((t) => `- ${t.question} → ${t.answer}`)
        .join('\n');
      const documents = localFiles
        .map((f) => `[${f.name}]\n${f.note.slice(0, 1200)}`)
        .join('\n\n');
      const fallbackRule =
        "Si une question porte sur un sujet que tu n'as pas appris (absent des " +
        "notions et documents ci-dessous) et qui n'est pas une connaissance " +
        "générale fiable, dis-le clairement — par exemple « Je n'ai pas encore " +
        "appris ça, vous pouvez me l'enseigner depuis l'onglet Apprentissage » — " +
        'plutôt que d’inventer une réponse.';
      const apiInstructions = buildApiToolInstructions(ai);
      const systemPrompt = [
        ai.systemPrompt,
        fallbackRule,
        teaching ? `Notions apprises :\n${teaching}` : "Notions apprises : aucune pour l'instant.",
        documents ? `Documents fournis :\n${documents}` : '',
        apiInstructions,
      ]
        .filter(Boolean)
        .join('\n\n');

      let conversation = next;
      let response = await VanelleNative.chat(
        JSON.stringify({
          systemPrompt,
          messages: conversation.map((m) => ({ role: m.role, content: m.text })),
          maxTokens: ai.maxTokens,
          temperature: ai.temperature,
        })
      );

      // Boucle outil courte et bornée : Vanelle peut réellement consulter une API
      // configurée, puis reçoit la réponse HTTP réelle avant de répondre à l'utilisateur.
      // Les opérations mutatives restent bloquées sans confirmation explicite.
      for (let round = 0; round < 2; round++) {
        const toolCall = parseApiToolCall(response.text || '');
        if (!toolCall) break;
        const toolResult = await executeApiTool(ai, toolCall);
        conversation = [
          ...conversation,
          { id: makeId(), role: 'assistant', text: response.text, ts: Date.now() },
          { id: makeId(), role: 'user', text: `Résultat réel de l'outil API :\n${toolResult}\n\nRéponds maintenant à l'utilisateur sans inventer de données.`, ts: Date.now() },
        ];
        response = await VanelleNative.chat(
          JSON.stringify({
            systemPrompt,
            messages: conversation.map((m) => ({ role: m.role, content: m.text })),
            maxTokens: ai.maxTokens,
            temperature: ai.temperature,
          })
        );
      }

      const botMsg: Message = {
        id: makeId(),
        role: 'assistant',
        text: response.text?.replace(/BEGIN_VANELLE_API[\s\S]*?END_VANELLE_API/gi, '').trim() || 'Réponse vide.',
        ts: Date.now(),
      };
      const all = [...next, botMsg];
      setMessages(all);
      await saveChat(ai.id, all);
      setStatus('');
    } catch (e) {
      const reason =
        e instanceof Error
          ? e.message
          : typeof e === 'string'
            ? e
            : 'Échec du moteur IA.';
      const friendly =
        /timeout|timed out|deadline/i.test(reason)
          ? 'Le modèle met plus de temps que prévu (chargement ou génération longue). Réessayez : le moteur reste actif, ce n’est pas une coupure.'
          : reason;
      setError(friendly);
      setStatus('');
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={Shared.root}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={Shared.header}>
        <View style={[Shared.row, { justifyContent: 'space-between' }]}>
          <Pressable onPress={back}>
            <Text style={{ color: '#fff', fontWeight: '800' }}>‹ Retour</Text>
          </Pressable>
          <Text style={Shared.brand}>{ai.name}</Text>
          <Pressable
            style={S.menuBtn}
            onPress={openMenu}
            accessibilityLabel="Menu du chat"
          >
            <Text style={S.menuIcon}>☰</Text>
          </Pressable>
        </View>
      </View>

      {!modelLoaded && (
        <View style={{ paddingHorizontal: 12, paddingTop: 8, backgroundColor: colors.bg }}>
          <Text style={Shared.muted}>
            Dernière préparation du modèle en mémoire (quelques secondes, une seule fois)…
          </Text>
        </View>
      )}

      {(error || status) && (
        <View style={{ paddingHorizontal: 12, paddingTop: 8, backgroundColor: colors.bg }}>
          {error ? <ErrorBanner message={error} onDismiss={() => setError('')} /> : null}
          {status && !error ? (
            <Text style={[Shared.muted, { marginBottom: 6 }]}>{status}</Text>
          ) : null}
        </View>
      )}

      <FlatList
        style={S.chat}
        data={messages}
        keyExtractor={(m) => m.id}
        ListEmptyComponent={
          <View style={[S.bubble, S.bot]}>
            <Text style={S.bubbleText}>
              Bonjour, je suis {ai.name}. Posez votre question. Utilisez ＋ pour joindre des
              fichiers ou images (max 3 Go chacun) — les connaissances s’ajoutent sans effacer
              l’existant. Menu ☰ en haut à droite pour plus d’options.
            </Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={[S.bubble, item.role === 'user' ? S.user : S.bot]}>
            <Text style={S.bubbleText}>{item.text}</Text>
          </View>
        )}
      />

      {localFiles.length > 0 ? (
        <View style={S.attachHint}>
          <Text style={{ fontSize: 11, color: colors.inkSoft }}>
            {localFiles.length} fichier(s) en connaissances · max 3 Go / fichier
          </Text>
        </View>
      ) : null}

      <View style={S.composer}>
        <Pressable
          style={S.plus}
          onPress={() => void pickFiles()}
          accessibilityLabel="Ajouter un fichier ou une image"
        >
          <Text style={S.plusText}>＋</Text>
        </Pressable>
        <TextInput
          style={[Shared.input, { flex: 1, maxHeight: 120 }]}
          value={draft}
          onChangeText={setDraft}
          multiline
          placeholder="Écrivez votre message…"
        />
        <Pressable style={S.send} onPress={() => void send()} disabled={busy}>
          <Text style={S.sendText}>{busy ? '…' : '➤'}</Text>
        </Pressable>
      </View>

      {/* Menu ☰ */}
      <Modal
        visible={menuOpen}
        transparent
        animationType="slide"
        onRequestClose={closeMenu}
      >
        <Pressable style={S.backdrop} onPress={closeMenu}>
          <Pressable style={S.sheet} onPress={(e) => e.stopPropagation()}>
            <View style={S.sheetHandle} />
            {menuPanel === 'main' && (
              <>
                <Text style={S.sheetTitle}>Menu · {ai.name}</Text>
                <Pressable
                  style={S.menuRow}
                  onPress={() => setMenuPanel('knowledge')}
                >
                  <Text style={S.menuRowText}>Voir les connaissances</Text>
                  <Text style={S.menuRowSub}>
                    {ai.training.length} notion(s) · {localFiles.length} fichier(s)
                  </Text>
                </Pressable>
                <Pressable style={S.menuRow} onPress={() => void clearConversation()}>
                  <Text style={[S.menuRowText, S.menuDanger]}>Effacer la conversation</Text>
                  <Text style={S.menuRowSub}>
                    Supprime uniquement l’historique de ce chat
                  </Text>
                </Pressable>
                <Pressable style={S.menuRow} onPress={() => setMenuPanel('info')}>
                  <Text style={S.menuRowText}>Infos de l’IA</Text>
                  <Text style={S.menuRowSub}>
                    Style, tokens, température, prompt
                  </Text>
                </Pressable>
                <Pressable
                  style={S.menuRow}
                  onPress={() => {
                    closeMenu();
                    void pickFiles();
                  }}
                >
                  <Text style={S.menuRowText}>Ajouter un fichier</Text>
                  <Text style={S.menuRowSub}>
                    Même action que le bouton ＋ · max 3 Go / fichier
                  </Text>
                </Pressable>
                <Pressable style={S.menuRow} onPress={() => void exportChat()}>
                  <Text style={S.menuRowText}>Exporter ce chat</Text>
                  <Text style={S.menuRowSub}>
                    {messages.length} message(s) · JSON
                  </Text>
                </Pressable>
                <Pressable style={S.menuRow} onPress={closeMenu}>
                  <Text style={[S.menuRowText, { color: colors.inkSoft }]}>Fermer</Text>
                </Pressable>
              </>
            )}

            {menuPanel === 'knowledge' && (
              <>
                <View style={[Shared.row, { paddingHorizontal: 18, paddingVertical: 8 }]}>
                  <Pressable onPress={() => setMenuPanel('main')}>
                    <Text style={{ fontWeight: '800', color: colors.accent }}>‹ Retour</Text>
                  </Pressable>
                  <Text style={[S.sheetTitle, { flex: 1, paddingVertical: 0 }]}>
                    Connaissances
                  </Text>
                </View>
                <ScrollView style={S.panelBox}>
                  <Text style={[S.panelLabel, { marginBottom: 6 }]}>
                    Notions ({ai.training.length})
                  </Text>
                  {ai.training.length === 0 ? (
                    <Text style={Shared.muted}>Aucune notion enseignée.</Text>
                  ) : (
                    ai.training.map((t) => (
                      <View key={t.id} style={S.panelCard}>
                        <Text style={S.panelValue}>{t.question}</Text>
                        <Text style={Shared.muted}>{t.answer}</Text>
                      </View>
                    ))
                  )}
                  <Text style={[S.panelLabel, { marginTop: 10, marginBottom: 6 }]}>
                    Fichiers ({localFiles.length})
                  </Text>
                  {localFiles.length === 0 ? (
                    <Text style={Shared.muted}>Aucun fichier.</Text>
                  ) : (
                    localFiles.map((f) => (
                      <View key={f.id} style={S.panelCard}>
                        <Text style={S.panelValue}>
                          {f.name} · {fmtSize(f.size)}
                        </Text>
                        <Text style={Shared.muted}>{f.note.slice(0, 160)}</Text>
                      </View>
                    ))
                  )}
                </ScrollView>
              </>
            )}

            {menuPanel === 'info' && (
              <>
                <View style={[Shared.row, { paddingHorizontal: 18, paddingVertical: 8 }]}>
                  <Pressable onPress={() => setMenuPanel('main')}>
                    <Text style={{ fontWeight: '800', color: colors.accent }}>‹ Retour</Text>
                  </Pressable>
                  <Text style={[S.sheetTitle, { flex: 1, paddingVertical: 0 }]}>
                    Infos de l’IA
                  </Text>
                </View>
                <ScrollView style={S.panelBox}>
                  <View style={S.panelCard}>
                    <Text style={S.panelLabel}>Nom</Text>
                    <Text style={S.panelValue}>{ai.name}</Text>
                  </View>
                  <View style={S.panelCard}>
                    <Text style={S.panelLabel}>Style</Text>
                    <Text style={S.panelValue}>{ai.style || '—'}</Text>
                  </View>
                  <View style={S.panelCard}>
                    <Text style={S.panelLabel}>Max tokens</Text>
                    <Text style={S.panelValue}>{String(ai.maxTokens)}</Text>
                  </View>
                  <View style={S.panelCard}>
                    <Text style={S.panelLabel}>Température</Text>
                    <Text style={S.panelValue}>{String(ai.temperature)}</Text>
                  </View>
                  <View style={S.panelCard}>
                    <Text style={S.panelLabel}>System prompt</Text>
                    <Text style={S.panelValue}>
                      {ai.systemPrompt?.trim() || '(vide — notions & fichiers servent de contexte)'}
                    </Text>
                  </View>
                  <View style={S.panelCard}>
                    <Text style={S.panelLabel}>Description</Text>
                    <Text style={S.panelValue}>{ai.description || '—'}</Text>
                  </View>
                </ScrollView>
              </>
            )}
          </Pressable>
        </Pressable>
      </Modal>
    </KeyboardAvoidingView>
  );
}
