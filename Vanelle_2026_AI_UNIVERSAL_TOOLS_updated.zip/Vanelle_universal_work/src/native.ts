import { NativeEventEmitter, NativeModules } from 'react-native';
export type ModelStatus = { llmInstalled:boolean; llmLoaded:boolean; embeddingReady:boolean; llmReady:boolean };
type NativeApi = {
  getModelStatus(): Promise<ModelStatus>; preloadModel(): Promise<boolean>; chat(payload:string):Promise<{text:string}>;
  vaultPut(ref:string,secret:string):Promise<boolean>; createPkceVerifier():Promise<string>; pkceChallenge(verifier:string):Promise<string>; signHmac(secretRef:string,algorithm:string,canonical:string):Promise<string>; startOAuth(url:string):Promise<boolean>; multipartRequest(url:string,headersJson:string,fieldsJson:string,filesJson:string):Promise<{status:number;headers:Record<string,string>;bodyBase64:string}>; importMtlsIdentity(ref:string,pkcs12Base64:string,password:string):Promise<boolean>; deleteMtlsIdentity(ref:string):Promise<boolean>; mtlsRequest(ref:string,url:string,method:string,headersJson:string,bodyBase64?:string|null):Promise<{status:number;headers:Record<string,string>;bodyBase64:string}>; vaultDelete(ref:string):Promise<boolean>; vaultHas(ref:string):Promise<boolean>;
  secureApiRequest(url:string,method:string,headersJson:string,bodyBase64?:string|null,secretRef?:string|null,authType?:string|null,authHeader?:string|null,username?:string|null):Promise<{status:number;headers:Record<string,string>;bodyBase64:string}>;
  openWebSocket(id:string,url:string,headersJson:string):Promise<boolean>; readWebSocketEvents(id:string,max:number):Promise<string[]>; sendWebSocket(id:string,text?:string|null,base64?:string|null):Promise<boolean>; closeWebSocket(id:string):void;
  openSse(id:string,url:string,headersJson:string):Promise<boolean>; readSseEvents(id:string,max:number):Promise<string[]>; closeSse(id:string):void;
};
export const VanelleNative = NativeModules.VanelleNative as NativeApi | undefined;
export const VanelleNativeEvents = VanelleNative ? new NativeEventEmitter(NativeModules.VanelleNative) : null;
