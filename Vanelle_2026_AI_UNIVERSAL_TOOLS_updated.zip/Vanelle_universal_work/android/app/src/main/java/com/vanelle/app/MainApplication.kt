package com.vanelle.app

import android.app.Application
import com.facebook.react.PackageList
import com.facebook.react.ReactApplication
import com.facebook.react.ReactHost
import com.facebook.react.ReactNativeHost
import com.facebook.react.ReactPackage
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.load
import com.facebook.react.defaults.DefaultReactHost.getDefaultReactHost
import com.facebook.react.defaults.DefaultReactNativeHost
import com.facebook.react.soloader.OpenSourceMergedSoMapping
import com.facebook.soloader.SoLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MainApplication : Application(), ReactApplication {

    override val reactNativeHost: ReactNativeHost =
        object : DefaultReactNativeHost(this@MainApplication) {
            override fun getPackages(): List<ReactPackage> =
                PackageList(this).packages.apply {
                    add(VanelleNativePackage())
                }

            override fun getJSMainModuleName(): String = "index"

            override fun getUseDeveloperSupport(): Boolean = BuildConfig.DEBUG

            override val isNewArchEnabled: Boolean =
                BuildConfig.IS_NEW_ARCHITECTURE_ENABLED

            override val isHermesEnabled: Boolean =
                BuildConfig.IS_HERMES_ENABLED
        }

    override val reactHost: ReactHost
        get() = getDefaultReactHost(applicationContext, reactNativeHost)

    override fun onCreate() {
        super.onCreate()
        SoLoader.init(this, OpenSourceMergedSoMapping)
        if (BuildConfig.IS_NEW_ARCHITECTURE_ENABLED) {
            load()
        }

        // 1) Copie + vérifie (SHA-256) les deux modèles GGUF une seule fois, en
        //    tâche de fond, dès le lancement de l'app (copie de fichier locale,
        //    aucun réseau — quasi instantané).
        // 2) Charge tout de suite le modèle de conversation en mémoire (moteur
        //    llama.cpp), au lieu d'attendre le premier message de l'utilisateur.
        //    Avant ce correctif, ce chargement — la vraie étape coûteuse —
        //    n'avait lieu qu'à l'envoi du premier message, ce qui donnait
        //    l'impression que l'app "chargeait encore" après l'ouverture.
        //    Ici il tourne en arrière-plan pendant que l'utilisateur navigue
        //    dans l'app ; le chat n'a normalement plus rien à charger.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            runCatching { ModelAssets.ensureInstalled(applicationContext, ModelAssets.LLM) }
            runCatching { ModelAssets.ensureInstalled(applicationContext, ModelAssets.EMBEDDING) }
            runCatching { EngineHolder.get(applicationContext).ensureLoaded() }
        }
    }
}
