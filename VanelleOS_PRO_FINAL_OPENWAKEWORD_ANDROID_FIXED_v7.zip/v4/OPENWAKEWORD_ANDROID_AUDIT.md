# VanelleOS — audit openWakeWord Android

## Corrections appliquées

- Pipeline audio aligné sur openWakeWord : PCM signé 16-bit, mono, 16 kHz.
- Traitement par blocs de 1280 échantillons (80 ms).
- Pipeline séparé : mel-spectrogramme → embedding Google speech embedding → classifieur du mot d'activation.
- Prétraitement du mel aligné sur openWakeWord : `mel / 10 + 2`.
- Fenêtre d'embedding de 76 trames × 32 bins, puis sortie 96 dimensions.
- Fenêtre du classifieur : 16 embeddings.
- Historique mel et embeddings glissant pour éviter les pertes de contexte.
- Entrée du modèle mel TFLite explicitement redimensionnée avant `allocateTensors()` afin d'éviter le problème Android/TFLite de forme dynamique.
- Les lectures partielles d'AudioRecord sont réassemblées avant traitement : aucun bloc de 80 ms n'est tronqué ou décalé.
- Suppression de la normalisation logicielle agressive du micro : le PCM original est conservé pour ne pas déformer les caractéristiques attendues par le modèle.
- Suppression de la moyenne mobile artificielle du score : le score du classifieur est évalué directement, avec seuil initial 0,50.
- Réinitialisation complète du contexte après détection pour éviter une redétection immédiate sur l'audio résiduel.
- Timeout de 8 secondes pour SpeechRecognizer afin qu'une reconnaissance bloquée ne laisse pas le wake word désactivé.
- Nettoyage systématique de SpeechRecognizer après résultat/erreur.
- Foreground Service microphone démarré avec `ServiceCompat.startForeground()` et le type microphone sur Android 10+.
- Vérification explicite de `RECORD_AUDIO` avant la création du service microphone.
- Suppression du démarrage automatique du service microphone depuis `BOOT_COMPLETED` : Android 14+ l'interdit pour un foreground service de type microphone avec cette configuration. L'écoute doit être activée depuis une activité visible / un mécanisme utilisateur autorisé.

## Limite importante

Aucune correction logicielle ne peut garantir 100 % de détection sur tous les téléphones : le microphone, le bruit, les traitements audio du fabricant, la qualité du modèle `Cassandra` et les restrictions d'économie d'énergie varient selon l'appareil. Le pipeline est cependant maintenant structuré pour respecter le fonctionnement documenté d'openWakeWord et les règles Android applicables au microphone.


## v4 — Android mel fix

The Android implementation no longer loads `melspectrogram.tflite`. The upstream openWakeWord project has a documented Android failure mode where this dynamic-shape TFLite model can fail during Conv2D tensor allocation with `BytesRequired number of elements overflowed`. The app therefore uses the official `melspectrogram.onnx` feature model through ONNX Runtime on Android.

The streaming path now follows the upstream feature flow: 16 kHz mono PCM16, 80 ms updates, raw-history context for the mel model, `76 x 32` mel windows advanced every 80 ms, 96-D embeddings, then the classifier.

This avoids the specific TFLite mel allocation failure rather than hiding it with a threshold or retry loop.
