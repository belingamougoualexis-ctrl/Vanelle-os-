# VanelleOS – règles ProGuard production

-keep class com.vanelle.os.** { *; }
-keepclassmembers class com.vanelle.os.** { *; }

# TensorFlow Lite
-keep class org.tensorflow.** { *; }
-keep class org.tensorflow.lite.** { *; }
-dontwarn org.tensorflow.**
-dontwarn org.tensorflow.lite.**

# Llama.cpp Kotlin / JNI
-keep class org.nehuatl.** { *; }
-keep class org.nehuatl.llamacpp.** { *; }
-keepclassmembers class org.nehuatl.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
-dontwarn org.nehuatl.**

# Kotlin / Coroutines
-keepnames class kotlinx.coroutines.** { *; }
-dontwarn kotlinx.coroutines.**
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }

# JSON
-keep class org.json.** { *; }

# AndroidX
-keep class androidx.** { *; }
-dontwarn androidx.**

# Keep enums used in reflection
-keepclassmembers enum * { *; }

# Attributes
-keepattributes Signature, InnerClasses, EnclosingMethod, *Annotation*, Exception
