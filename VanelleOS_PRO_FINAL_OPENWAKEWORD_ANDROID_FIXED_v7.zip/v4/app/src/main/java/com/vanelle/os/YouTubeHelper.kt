package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.net.Uri
class YouTubeHelper(private val c:Context){
    fun search(q:String):String {
        if (q.isBlank()) return "Que veux-tu chercher sur YouTube ?"
        return try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(q)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            c.startActivity(i)
            "YouTube est ouvert avec la recherche « $q »."
        } catch (_: Exception) {
            "Je n'ai pas pu ouvrir YouTube. Vérifie qu'une application de navigateur ou YouTube est installée et que le téléphone n'est pas en mode avion."
        }
    }
}
