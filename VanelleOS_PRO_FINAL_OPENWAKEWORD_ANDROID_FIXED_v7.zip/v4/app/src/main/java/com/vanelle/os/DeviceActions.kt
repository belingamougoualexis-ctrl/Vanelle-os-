package com.vanelle.os

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Actions appareil 100 % système (pas de simulation).
 * Lampe, volume, mode son, presse-papiers, partage / URL, minuteur.
 */
class DeviceActions(private val context: Context) {

    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    // --- Lampe torche ---
    fun flashlight(on: Boolean?): String {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            ?: return "Service caméra indisponible sur cet appareil."
        return try {
            val id = cm.cameraIdList.firstOrNull { camId ->
                cm.getCameraCharacteristics(camId)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "Aucune lampe torche détectée."
            val enable = on ?: !isTorchOn(cm, id)
            if (Build.VERSION.SDK_INT >= 23) {
                cm.setTorchMode(id, enable)
                lastTorch = enable
                if (enable) "Lampe allumée." else "Lampe éteinte."
            } else {
                "Lampe torche non supportée sur cette version d'Android."
            }
        } catch (e: Exception) {
            "Impossible de contrôler la lampe. Raison : ${e.message ?: "permission ou matériel"}."
        }
    }

    private fun isTorchOn(cm: CameraManager, id: String): Boolean = lastTorch

    // --- Volume ---
    fun volume(direction: String): String {
        return try {
            when (direction) {
                "up" -> {
                    audio.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        AudioManager.ADJUST_RAISE,
                        AudioManager.FLAG_SHOW_UI
                    )
                    "Volume augmenté (${pct()} %)."
                }
                "down" -> {
                    audio.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        AudioManager.ADJUST_LOWER,
                        AudioManager.FLAG_SHOW_UI
                    )
                    "Volume baissé (${pct()} %)."
                }
                "mute" -> {
                    audio.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        AudioManager.ADJUST_MUTE,
                        AudioManager.FLAG_SHOW_UI
                    )
                    "Son coupé."
                }
                "unmute" -> {
                    audio.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        AudioManager.ADJUST_UNMUTE,
                        AudioManager.FLAG_SHOW_UI
                    )
                    "Son rétabli (${pct()} %)."
                }
                else -> "Volume actuel : ${pct()} %."
            }
        } catch (e: Exception) {
            "Contrôle du volume impossible. Raison : ${e.message ?: "système"}."
        }
    }

    private fun pct(): Int {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        return (cur * 100) / max
    }

    // --- Mode sonnerie ---
    fun ringer(mode: String): String {
        return try {
            when (mode) {
                "silent" -> {
                    audio.ringerMode = AudioManager.RINGER_MODE_SILENT
                    "Mode silencieux activé."
                }
                "vibrate" -> {
                    audio.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                    "Mode vibreur activé."
                }
                "normal" -> {
                    audio.ringerMode = AudioManager.RINGER_MODE_NORMAL
                    "Mode son normal activé."
                }
                else -> {
                    val m = when (audio.ringerMode) {
                        AudioManager.RINGER_MODE_SILENT -> "silencieux"
                        AudioManager.RINGER_MODE_VIBRATE -> "vibreur"
                        else -> "normal"
                    }
                    "Mode sonnerie actuel : $m."
                }
            }
        } catch (e: Exception) {
            "Changement de mode son impossible. Raison : ${e.message ?: "restriction système"}."
        }
    }

    // --- Presse-papiers ---
    fun clipboardRead(): String {
        return try {
            val clip = clipboard.primaryClip
            if (clip == null || clip.itemCount == 0) {
                "Presse-papiers vide."
            } else {
                val text = clip.getItemAt(0).coerceToText(context).toString().trim()
                if (text.isBlank()) "Presse-papiers sans texte lisible."
                else "Presse-papiers : ${text.take(300)}"
            }
        } catch (e: Exception) {
            "Lecture du presse-papiers impossible. Raison : ${e.message ?: "système"}."
        }
    }

    fun clipboardWrite(text: String): String {
        if (text.isBlank()) return "Rien à copier : texte vide."
        return try {
            clipboard.setPrimaryClip(ClipData.newPlainText("Vanelle", text.take(4000)))
            "Copié dans le presse-papiers (${text.take(40)}${if (text.length > 40) "…" else ""})."
        } catch (e: Exception) {
            "Écriture presse-papiers impossible. Raison : ${e.message ?: "système"}."
        }
    }

    // --- Ouvrir URL / partager ---
    fun openUrl(raw: String): String {
        var url = raw.trim()
        if (url.isBlank()) return "URL manquante."
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://$url"
        }
        return try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(i)
            "Ouverture de $url."
        } catch (e: Exception) {
            "Impossible d'ouvrir l'URL. Raison : ${e.message ?: "pas d'application compatible"}."
        }
    }

    fun shareText(text: String): String {
        if (text.isBlank()) return "Texte à partager manquant."
        return try {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text.take(4000))
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(i, "Partager via Vanelle").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Menu de partage ouvert."
        } catch (e: Exception) {
            "Partage impossible. Raison : ${e.message ?: "système"}."
        }
    }

    // --- Minuteur réel (notification à échéance) ---
    fun timerMinutes(minutes: Int, label: String = "Minuteur Vanelle"): String {
        val m = minutes.coerceIn(1, 180)
        val triggerAt = System.currentTimeMillis() + m * 60_000L
        return try {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, TimerReceiver::class.java).apply {
                action = TimerReceiver.ACTION
                putExtra("label", label.take(80))
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
            val pi = PendingIntent.getBroadcast(context, TIMER_REQ, intent, flags)
            if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else {
                @Suppress("DEPRECATION")
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
            HapticLanguage.play(context, HapticLanguage.Signal.CONFIRM)
            "Minuteur lancé : $m min."
        } catch (e: Exception) {
            // Fallback Handler (fonctionne si process vivant)
            Handler(Looper.getMainLooper()).postDelayed({
                TimerReceiver.notifyNow(context, label)
            }, m * 60_000L)
            "Minuteur lancé en secours : $m min (actif tant que l'app reste en mémoire)."
        }
    }

    companion object {
        private const val TIMER_REQ = 55021
        @Volatile private var lastTorch = false
    }
}

class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val label = intent?.getStringExtra("label") ?: "Minuteur Vanelle"
        notifyNow(context, label)
        HapticLanguage.play(context, HapticLanguage.Signal.WARNING)
    }

    companion object {
        const val ACTION = "com.vanelle.os.TIMER_DONE"
        fun notifyNow(context: Context, label: String) {
            try {
                val id = "vanelle_timer"
                val nm = context.getSystemService(NotificationManager::class.java)
                if (Build.VERSION.SDK_INT >= 26) {
                    nm?.createNotificationChannel(
                        NotificationChannel(id, "Minuteurs", NotificationManager.IMPORTANCE_HIGH)
                    )
                }
                val n = NotificationCompat.Builder(context, id)
                    .setContentTitle("Minuteur terminé")
                    .setContentText(label)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true)
                    .build()
                nm?.notify(55022, n)
            } catch (_: Exception) {}
        }
    }
}
