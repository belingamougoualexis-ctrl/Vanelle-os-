package com.vanelle.os

import android.content.Context
import org.json.JSONArray

/**
 * Apprentissage de workflows : journalise les commandes et expose des patterns.
 */
class WorkflowLearner(private val c: Context) {
    private val prefs = c.getSharedPreferences("vanelle_workflows", 0)

    fun log(q: String) {
        try {
            val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
            val arr = JSONArray(prefs.getString("w_$hour", "[]"))
            arr.put(q.take(80))
            val trimmed = JSONArray()
            val start = (arr.length() - 40).coerceAtLeast(0)
            for (i in start until arr.length()) trimmed.put(arr.get(i))
            prefs.edit().putString("w_$hour", trimmed.toString()).apply()
        } catch (_: Exception) {}
    }

    fun discover(): String {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val arr = JSONArray(prefs.getString("w_$hour", "[]"))
        if (arr.length() < 3) {
            return "Pas encore assez de données pour découvrir des routines automatiques à ${hour}h. Continue à m'utiliser."
        }
        val counts = mutableMapOf<String, Int>()
        for (i in 0 until arr.length()) {
            val s = arr.getString(i).lowercase()
            val key = when {
                s.contains("batterie") -> "vérifier batterie"
                s.contains("ouvre") || s.contains("lance") -> "ouvrir une app"
                s.contains("appelle") -> "appeler quelqu'un"
                s.contains("cherche") || s.contains("recherche") -> "recherche web"
                s.contains("souviens") || s.contains("rappelle") -> "mémoire"
                else -> s.take(40)
            }
            counts[key] = (counts[key] ?: 0) + 1
        }
        val top = counts.entries.sortedByDescending { it.value }.take(3)
        return "Routines probables vers ${hour}h :\n" +
            top.joinToString("\n") { "• ${it.key} (${it.value}×)" } +
            "\nTu peux figer une routine avec « crée une routine à ${hour}h00 »."
    }
}
