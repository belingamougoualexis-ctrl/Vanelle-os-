package com.vanelle.os
import android.content.Context
import android.content.Intent
class MiniToolGenerator(private val c:Context){
    fun open():String = try{
        val i=Intent().apply{
            action=Intent.ACTION_MAIN
            addCategory("android.intent.category.APP_CALCULATOR")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        c.startActivity(i)
        "Calculatrice ouverte."
    }catch(_:Exception){
        "Je n'ai pas trouvé d'application calculatrice. Installe-en une ou ouvre-la manuellement."
    }
}
