package com.vanelle.os
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

/**
 * Service de téléchargement des données de l'app.
 * - Modèles d'écoute (wake word) + modèle IA (GGUF) dans le même flux
 * - Continue si l'utilisateur quitte l'app (foreground service)
 * - Pause si plus de réseau
 * - Reprend automatiquement au même offset (.part + HTTP Range) pour le GGUF
 */
class DataDownloadService : Service() {

    companion object {
        private const val TAG = "DataDownload"
        const val CHANNEL_ID = "vanelle_data_download"
        const val NOTIF_ID = 4201
        const val ACTION_PROGRESS = "com.vanelle.os.DATA_DOWNLOAD_PROGRESS"
        const val ACTION_DONE = "com.vanelle.os.DATA_DOWNLOAD_DONE"
        const val ACTION_WAITING = "com.vanelle.os.DATA_DOWNLOAD_WAITING"
        const val EXTRA_PERCENT = "percent"
        const val EXTRA_STATUS = "status"

        /** Part de la barre réservée aux modèles d'écoute (petits fichiers). */
        const val WAKE_PROGRESS_SHARE = 5

        @Volatile var isRunning = false
            private set

        fun allDataReady(c: Context): Boolean =
            LlamaModelManager.isReady(c) && WakeWordModelManager.isReady(c)

        fun start(c: Context) {
            if (allDataReady(c)) return
            val i = Intent(c, DataDownloadService::class.java)
            ContextCompat.startForegroundService(c, i)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var cancelled = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (allDataReady(this)) {
            stopSelfSafely()
            return START_NOT_STICKY
        }
        startAsForeground(overallPercent(), "Préparation des données…")
        isRunning = true
        cancelled = false
        registerNetworkWatcher()
        if (job?.isActive != true) {
            job = scope.launch { runDownloadLoop() }
        }
        return START_STICKY
    }

    private suspend fun runDownloadLoop() {
        while (!cancelled && !allDataReady(this)) {
            if (!LlamaModelManager.isNetworkAvailable(this)) {
                broadcastWaiting("Connexion interrompue…")
                updateNotif(overallPercent(), "Connexion interrompue — reprise auto")
                delay(3000)
                continue
            }

            // 1) Modèles d'écoute (openWakeWord) — rapides, en premier
            if (!WakeWordModelManager.isReady(this)) {
                updateNotif(2, "Téléchargement des données de l'app…")
                broadcastProgress(2, "Téléchargement des données de l'app…")
                Log.i(TAG, "Downloading wake-word models…")
                val wakeOk = try {
                    WakeWordModelManager.downloadIfNeeded(this)
                } catch (e: Exception) {
                    Log.w(TAG, "Wake models download error: ${e.message}")
                    false
                }
                if (cancelled) {
                    stopSelfSafely()
                    return
                }
                if (!wakeOk) {
                    updateNotif(overallPercent(), "Nouvelle tentative…")
                    broadcastWaiting("Nouvelle tentative…")
                    delay(4000)
                    continue
                }
                updateNotif(WAKE_PROGRESS_SHARE, "Téléchargement des données de l'app…")
                broadcastProgress(WAKE_PROGRESS_SHARE, "Téléchargement des données de l'app…")
                Log.i(TAG, "Wake-word models ready")
            }

            // 2) Modèle IA (GGUF) — gros fichier avec reprise
            if (LlamaModelManager.isReady(this)) {
                broadcastDone()
                updateNotif(100, "Données prêtes")
                delay(800)
                stopSelfSafely()
                return
            }

            val result = LlamaModelManager.downloadResumable(
                this,
                wifiOnly = false,
                isCancelled = { cancelled }
            ) { pct, downloaded, total ->
                // Mappe 0-100 du GGUF vers WAKE_PROGRESS_SHARE..100
                val mapped = if (pct >= 100) 100
                else WAKE_PROGRESS_SHARE + ((100 - WAKE_PROGRESS_SHARE) * pct) / 100
                val status = if (total > 0) {
                    val mb = downloaded / (1024 * 1024)
                    val totalMb = total / (1024 * 1024)
                    "$mapped % · ${mb} / ${totalMb} Mo"
                } else "$mapped %"
                updateNotif(mapped, status)
                broadcastProgress(mapped, status)
            }

            when (result) {
                "DONE" -> {
                    // S'assurer que les modèles d'écoute sont bien là aussi
                    if (!WakeWordModelManager.isReady(this)) {
                        try { WakeWordModelManager.downloadIfNeeded(this) } catch (_: Exception) {}
                    }
                    broadcastDone()
                    updateNotif(100, "Données prêtes")
                    delay(800)
                    stopSelfSafely()
                    return
                }
                "CANCELLED" -> {
                    stopSelfSafely()
                    return
                }
                "NO_WIFI", "NO_NETWORK" -> {
                    broadcastWaiting(
                        if (result == "NO_WIFI") "En attente du Wi‑Fi…"
                        else "Connexion interrompue — reprise au même point"
                    )
                    delay(2500)
                }
                else -> {
                    updateNotif(overallPercent(), "Nouvelle tentative…")
                    delay(5000)
                }
            }
        }
        if (allDataReady(this)) {
            broadcastDone()
            updateNotif(100, "Données prêtes")
            delay(500)
        }
        stopSelfSafely()
    }

    /** Progression globale : 0-5 % wake, 5-100 % GGUF. */
    private fun overallPercent(): Int {
        if (allDataReady(this)) return 100
        val wakeReady = WakeWordModelManager.isReady(this)
        val base = if (wakeReady) WAKE_PROGRESS_SHARE else 0
        val p = LlamaModelManager.partialBytes(this)
        if (p <= 0) return base
        val ggufPct = ((p * 100) / LlamaModelManager.EXPECTED_MIN_BYTES).toInt().coerceIn(0, 99)
        return (base + ((100 - WAKE_PROGRESS_SHARE) * ggufPct) / 100).coerceIn(0, 99)
    }

    private fun registerNetworkWatcher() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            networkCallback?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (job?.isActive != true && !allDataReady(this@DataDownloadService)) {
                        job = scope.launch { runDownloadLoop() }
                    }
                }
                override fun onLost(network: Network) {
                    broadcastWaiting("Connexion interrompue — reprise auto")
                }
            }
            networkCallback = cb
            val req = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            cm.registerNetworkCallback(req, cb)
        } catch (_: Exception) {}
    }

    private fun broadcastProgress(pct: Int, status: String) {
        sendBroadcast(Intent(ACTION_PROGRESS).setPackage(packageName).apply {
            putExtra(EXTRA_PERCENT, pct)
            putExtra(EXTRA_STATUS, status)
        })
    }

    private fun broadcastWaiting(msg: String) {
        sendBroadcast(Intent(ACTION_WAITING).setPackage(packageName).apply {
            putExtra(EXTRA_STATUS, msg)
            putExtra(EXTRA_PERCENT, overallPercent())
        })
    }

    private fun broadcastDone() {
        sendBroadcast(Intent(ACTION_DONE).setPackage(packageName))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(
                CHANNEL_ID,
                "Mise à jour des données",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Téléchargement des données de VanelleOS"
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun startAsForeground(pct: Int, text: String) {
        val notif = buildNotif(pct, text)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun updateNotif(pct: Int, text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotif(pct, text))
    }

    private fun buildNotif(pct: Int, text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VanelleOS · données")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct.coerceIn(0, 100), pct <= 0)
            .setContentIntent(open)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .build()
    }

    private fun stopSelfSafely() {
        isRunning = false
        cancelled = true
        try {
            networkCallback?.let {
                val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                cm.unregisterNetworkCallback(it)
            }
        } catch (_: Exception) {}
        networkCallback = null
        job?.cancel()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        cancelled = true
        isRunning = false
        scope.cancel()
        super.onDestroy()
    }
}
