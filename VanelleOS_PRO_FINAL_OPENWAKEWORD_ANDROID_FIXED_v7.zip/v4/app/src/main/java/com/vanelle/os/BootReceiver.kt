package com.vanelle.os

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        val action = i?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED &&
            action != Intent.ACTION_LOCKED_BOOT_COMPLETED
        ) return

        try { AlarmScheduler.rescheduleAll(c) } catch (_: Exception) {}
        try { NightlyConsolidation.schedule(c) } catch (_: Exception) {}

        // Do NOT start the microphone foreground service from BOOT_COMPLETED.
        // Android 14+ forbids microphone FGS startup from boot receivers because
        // RECORD_AUDIO is a while-in-use permission. The user must start listening
        // from a visible activity/notification/widget instead.
    }
}
