package com.vanelle.os

import android.content.Context

/**
 * Pare-feu de confidentialité : contrôle explicite de ce qui peut quitter l'appareil.
 */
object PrivacyFirewall {
    private fun p(c: Context) = c.getSharedPreferences("vanelle_privacy", 0)

    fun allowWeb(c: Context) = p(c).getBoolean("allow_web", true)
    fun setAllowWeb(c: Context, on: Boolean) = p(c).edit().putBoolean("allow_web", on).apply()

    fun allowContacts(c: Context) = p(c).getBoolean("allow_contacts", true)
    fun setAllowContacts(c: Context, on: Boolean) = p(c).edit().putBoolean("allow_contacts", on).apply()

    fun allowLocation(c: Context) = p(c).getBoolean("allow_location", true)
    fun setAllowLocation(c: Context, on: Boolean) = p(c).edit().putBoolean("allow_location", on).apply()

    fun lockdown(c: Context) {
        p(c).edit()
            .putBoolean("allow_web", false)
            .putBoolean("allow_contacts", false)
            .putBoolean("allow_location", false)
            .apply()
        PersonalityPrefs.setPreferOffline(c, true)
        PersonalityPrefs.setGuestMode(c, true)
    }

    fun status(c: Context): String {
        return "Pare-feu confidentialité :\n" +
            "• Web/IA cloud : ${if (allowWeb(c)) "autorisé" else "bloqué"}\n" +
            "• Contacts : ${if (allowContacts(c)) "autorisé" else "bloqué"}\n" +
            "• Localisation : ${if (allowLocation(c)) "autorisé" else "bloqué"}\n" +
            "• Mode invité : ${if (PersonalityPrefs.isGuestMode(c)) "oui" else "non"}\n" +
            "• Préférence offline : ${if (PersonalityPrefs.preferOffline(c)) "oui" else "non"}"
    }
}
