package com.vanelle.os

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class TranslateHelper(private val c: Context) {
    companion object {
        val LANG_CODES = mapOf(
            "francais" to "fr", "français" to "fr", "french" to "fr", "fr" to "fr",
            "anglais" to "en", "english" to "en", "en" to "en",
            "espagnol" to "es", "spanish" to "es", "es" to "es",
            "allemand" to "de", "german" to "de", "de" to "de",
            "italien" to "it", "italian" to "it", "it" to "it",
            "portugais" to "pt", "portuguese" to "pt", "pt" to "pt",
            "arabe" to "ar", "arabic" to "ar", "ar" to "ar",
            "chinois" to "zh-CN", "chinese" to "zh-CN", "zh" to "zh-CN",
            "japonais" to "ja", "japanese" to "ja", "ja" to "ja",
            "coreen" to "ko", "coréen" to "ko", "korean" to "ko", "ko" to "ko",
            "russe" to "ru", "russian" to "ru", "ru" to "ru",
            "neerlandais" to "nl", "néerlandais" to "nl", "dutch" to "nl",
            "turc" to "tr", "turkish" to "tr", "tr" to "tr",
            "polonais" to "pl", "polish" to "pl", "pl" to "pl",
            "suedois" to "sv", "suédois" to "sv", "swedish" to "sv",
            "auto" to "auto"
        )

        fun codeFor(name: String): String? {
            val n = name.trim().lowercase()
                .replace("é", "e").replace("è", "e").replace("ê", "e")
                .replace("ç", "c").replace("î", "i").replace("ï", "i")
            return LANG_CODES[n] ?: LANG_CODES[name.trim().lowercase()]
        }
    }

    fun translateText(text: String, source: String, target: String): String {
        if (text.isBlank()) return "Quel texte veux-tu que je traduise ?"
        val sl = normalizeCode(source)
        val tl = normalizeCode(target).let { if (it == "auto") "fr" else it }
        // Essai principal Google Translate (endpoint public gtx)
        val primary = tryTranslate(text, sl, tl)
        if (primary != null) return primary
        // Second essai avec source auto
        if (sl != "auto") {
            val second = tryTranslate(text, "auto", tl)
            if (second != null) return second
        }
        return "Traduction indisponible pour le moment. Raison probable : pas de connexion Internet ou service de traduction temporairement inaccessible. Réessaie dans un instant."
    }

    private fun normalizeCode(code: String): String {
        val c = code.trim().lowercase()
        return when {
            c in listOf("zh", "zh-cn", "zh_cn") -> "zh-CN"
            c == "auto" || c.isBlank() -> "auto"
            else -> codeFor(c) ?: c
        }
    }

    private fun tryTranslate(text: String, sl: String, tl: String): String? {
        return try {
            val q = URLEncoder.encode(text, "UTF-8")
            val url = URL(
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=$tl&dt=t&q=$q"
            )
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 10000
                readTimeout = 10000
                instanceFollowRedirects = true
                setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"
                )
                setRequestProperty("Accept", "*/*")
            }
            if (conn.responseCode !in 200..299) {
                conn.disconnect()
                return null
            }
            val body = conn.inputStream.bufferedReader().readText()
            conn.disconnect()
            parseGtx(body)
        } catch (_: Exception) {
            null
        }
    }

    private fun parseGtx(body: String): String? {
        return try {
            val arr = org.json.JSONArray(body)
            val segments = arr.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until segments.length()) {
                val seg = segments.optJSONArray(i) ?: continue
                sb.append(seg.optString(0, ""))
            }
            sb.toString().trim().ifBlank { null }
        } catch (_: Exception) {
            null
        }
    }
}
