package com.vanelle.os

import android.content.Context
import android.util.Log
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Downloads and validates the shared openWakeWord feature models.
 *
 * Android uses the official ONNX mel model instead of the TFLite mel model.
 * The upstream project itself supports ONNX, and this avoids the known
 * Android/TFLite dynamic-input Conv2D allocation failure in melspectrogram.tflite.
 */
object WakeWordModelManager {
    private const val TAG = "WakeWordModels"
    private const val MEL_URL =
        "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/melspectrogram.onnx"
    private const val EMB_URL =
        "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/embedding_model.tflite"

    private const val MIN_MEL_SIZE = 100_000L
    private const val MIN_EMB_SIZE = 100_000L

    fun melFile(c: Context) = File(c.filesDir, "melspectrogram.onnx")
    fun embFile(c: Context) = File(c.filesDir, "embedding_model.tflite")

    private fun isValidOnnxFile(f: File): Boolean {
        if (!f.exists() || f.length() < MIN_MEL_SIZE) return false
        return try {
            f.inputStream().use { input ->
                val header = ByteArray(16)
                val n = input.read(header)
                if (n < 4) return false
                // ONNX is a protobuf container and has no fixed magic header.
                // Reject obvious HTML/text error pages instead.
                val text = String(header, Charsets.US_ASCII).trimStart()
                !text.startsWith("<html", true) &&
                    !text.startsWith("<!doctype", true) &&
                    !text.startsWith("{\"", true)
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun isValidTfliteFile(f: File): Boolean {
        if (!f.exists() || f.length() < MIN_EMB_SIZE) return false
        return try {
            f.inputStream().use { input ->
                val header = ByteArray(8)
                val read = input.read(header)
                read == 8 && header[4] == 'T'.code.toByte() &&
                    header[5] == 'F'.code.toByte() &&
                    header[6] == 'L'.code.toByte() &&
                    header[7] == '3'.code.toByte()
            }
        } catch (_: Exception) {
            false
        }
    }

    fun isReady(c: Context): Boolean =
        isValidOnnxFile(melFile(c)) && isValidTfliteFile(embFile(c))

    private fun downloadOne(url: String, dest: File, validator: (File) -> Boolean, retries: Int = 3): Boolean {
        repeat(retries) { attempt ->
            try {
                if (validator(dest)) return true
                if (dest.exists()) dest.delete()

                var current = url
                var redirects = 0
                while (redirects < 10) {
                    val conn = (URL(current).openConnection() as HttpURLConnection).apply {
                        instanceFollowRedirects = false
                        connectTimeout = 25_000
                        readTimeout = 90_000
                        setRequestProperty(
                            "User-Agent",
                            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile"
                        )
                        setRequestProperty("Accept", "*/*")
                        requestMethod = "GET"
                    }
                    val code = conn.responseCode
                    if (code in 300..399) {
                        val loc = conn.getHeaderField("Location") ?: run {
                            conn.disconnect()
                            return@repeat
                        }
                        current = if (loc.startsWith("http")) loc else URL(URL(current), loc).toString()
                        conn.disconnect()
                        redirects++
                        continue
                    }
                    if (code !in 200..299) {
                        Log.w(TAG, "HTTP $code for $url (attempt ${attempt + 1})")
                        conn.disconnect()
                        break
                    }

                    val tmp = File(dest.absolutePath + ".part")
                    if (tmp.exists()) tmp.delete()
                    tmp.outputStream().use { out -> conn.inputStream.use { it.copyTo(out) } }
                    conn.disconnect()

                    if (validator(tmp)) {
                        if (dest.exists()) dest.delete()
                        if (tmp.renameTo(dest)) {
                            Log.i(TAG, "Downloaded ${dest.name} (${dest.length()} bytes)")
                            return true
                        }
                    }
                    tmp.delete()
                    Log.w(TAG, "Invalid download for ${dest.name} (${tmp.length()} bytes)")
                    break
                }
            } catch (e: Exception) {
                Log.w(TAG, "Download error for ${dest.name} (attempt ${attempt + 1}): ${e.message}")
            }
            try { Thread.sleep(800L * (attempt + 1)) } catch (_: Exception) {}
        }
        return false
    }

    suspend fun downloadIfNeeded(c: Context): Boolean {
        // Remove the old TFLite mel file left by v1-v3 so it can never be selected again.
        try { File(c.filesDir, "melspectrogram.tflite").delete() } catch (_: Exception) {}

        if (isReady(c)) return true
        WakeWordDiagnostics.log(
            c, TAG,
            "téléchargement des modèles d'écoute ONNX mel + TFLite embedding"
        )

        val melOk = downloadOne(MEL_URL, melFile(c), ::isValidOnnxFile)
        val embOk = downloadOne(EMB_URL, embFile(c), ::isValidTfliteFile)
        val ok = melOk && embOk

        Log.i(TAG, "downloadIfNeeded -> $ok (mel=$melOk emb=$embOk)")
        WakeWordDiagnostics.log(
            c, TAG,
            "téléchargement terminé -> ${if (ok) "OK" else "ÉCHEC"} " +
                "(mel=$melOk, taille=${melFile(c).length()} octets ; " +
                "emb=$embOk, taille=${embFile(c).length()} octets)"
        )
        return ok
    }

    fun clear(c: Context) {
        listOf(
            melFile(c),
            embFile(c),
            File(c.filesDir, "melspectrogram.tflite"),
            File(c.filesDir, "melspectrogram.onnx.part")
        ).forEach { f -> try { if (f.exists()) f.delete() } catch (_: Exception) {} }
    }
}
