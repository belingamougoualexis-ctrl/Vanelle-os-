package com.vanelle.os

import android.content.Context
import android.content.Intent

/**
 * Génère et ouvre une mini-interface à la volée (DynamicToolActivity).
 */
class DynamicUiGenerator(private val context: Context) {
    private val relational = RelationalMemory(context)

    fun create(request: String): String {
        if (request.isBlank()) {
            return "Décris l'outil : compteur, budget, notes, checklist…"
        }
        val r = request.lowercase()
        relational.rememberFact("Outil dynamique: $request")

        val kind = when {
            r.contains("compteur") || r.contains("counter") || r.contains("verre") -> "counter"
            r.contains("budget") || r.contains("dépense") || r.contains("argent") || r.contains("euro") -> "budget"
            r.contains("check") || r.contains("liste") || r.contains("tâche") || r.contains("todo") -> "checklist"
            else -> "notes"
        }
        val title = when (kind) {
            "counter" -> "Compteur dynamique"
            "budget" -> "Budget express"
            "checklist" -> "Checklist"
            else -> "Notes rapides"
        }
        return try {
            val i = Intent(context, DynamicToolActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(DynamicToolActivity.EXTRA_KIND, kind)
                putExtra(DynamicToolActivity.EXTRA_TITLE, title)
            }
            context.startActivity(i)
            "Interface « $title » générée et ouverte. Type : $kind."
        } catch (e: Exception) {
            "Impossible d'ouvrir l'outil dynamique. Raison : ${e.message ?: "activité non déclarée ou restriction système"}."
        }
    }
}
