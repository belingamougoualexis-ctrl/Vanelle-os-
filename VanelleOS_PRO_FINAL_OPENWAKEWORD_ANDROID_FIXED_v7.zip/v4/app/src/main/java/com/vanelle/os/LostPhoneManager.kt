package com.vanelle.os
import android.content.Context
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.*
object LostPhoneManager{
    private var mp:MediaPlayer?=null
    private var h:Handler?=null
    fun trigger(c:Context):String{
        val app=c.applicationContext
        return try{
            h?.removeCallbacksAndMessages(null)
            mp?.let{ if(it.isPlaying) it.stop(); it.release() }; mp=null; h=null
            val vib=app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if(Build.VERSION.SDK_INT>=26) vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0,500,500,500,500),0)) else @Suppress("DEPRECATION") vib?.vibrate(longArrayOf(0,500,500,500,500),0)
            val am=app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val orig=am.getStreamVolume(AudioManager.STREAM_RING)
            val max=am.getStreamMaxVolume(AudioManager.STREAM_RING)
            am.setStreamVolume(AudioManager.STREAM_RING,max,0)
            val uri:Uri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            mp=MediaPlayer().apply{ setAudioAttributes(android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_ALARM).build()); setDataSource(app,uri); isLooping=true; prepare(); start() }
            h=Handler(Looper.getMainLooper())
            h?.postDelayed({ mp?.let{ if(it.isPlaying) it.stop(); it.release() }; mp=null; am.setStreamVolume(AudioManager.STREAM_RING,orig,0); vib?.cancel(); h=null },10000)
            "Alarme téléphone perdu déclenchée : vibration et sonnerie activées pendant 10 secondes."
        }catch(_:Exception){ "Je n'ai pas pu déclencher l'alarme. Vérifie le volume, le mode silencieux et les permissions de vibration." }
    }
}
