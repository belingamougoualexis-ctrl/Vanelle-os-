package com.vanelle.os
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Journal de confiance : ce que Vanelle a entendu / fait. */
object ActivityLog {
    private const val PREF = "vanelle_activity_log"
    private const val KEY = "entries"
    private const val MAX = 100

    fun add(c: Context, type: String, detail: String) {
        if (PersonalityPrefs.isGuestMode(c)) return
        val p = c.getSharedPreferences(PREF, 0)
        val arr = JSONArray(p.getString(KEY, "[]"))
        arr.put(JSONObject()
            .put("ts", System.currentTimeMillis())
            .put("type", type)
            .put("detail", detail.take(200)))
        val trimmed = JSONArray()
        val start = (arr.length() - MAX).coerceAtLeast(0)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        p.edit().putString(KEY, trimmed.toString()).apply()
    }

    fun all(c: Context): List<Triple<Long, String, String>> {
        val arr = JSONArray(c.getSharedPreferences(PREF, 0).getString(KEY, "[]"))
        val out = mutableListOf<Triple<Long, String, String>>()
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.getJSONObject(i)
            out.add(Triple(o.optLong("ts"), o.optString("type"), o.optString("detail")))
        }
        return out
    }

    fun clear(c: Context) {
        c.getSharedPreferences(PREF, 0).edit().clear().apply()
    }

    fun formatLine(ts: Long, type: String, detail: String): String {
        val df = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        return "${df.format(Date(ts))} · $type · $detail"
    }
}
