package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.net.Uri
class EmergencyManager(private val c:Context){
    fun sos():String = try {
        val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:112")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        c.startActivity(i)
        "Numéro d'urgence 112 ouvert. Compose pour appeler les secours."
    } catch (_: Exception) {
        "Je n'ai pas pu ouvrir le numérateur d'urgence. Compose manuellement le 112 ou le 15 / 18 / 17 selon le besoin."
    }
}
