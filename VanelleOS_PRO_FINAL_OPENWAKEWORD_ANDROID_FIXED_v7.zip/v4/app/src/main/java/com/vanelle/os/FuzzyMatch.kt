package com.vanelle.os
object FuzzyMatch{
    private fun dist(a0:String,b0:String):Int{
        val a=a0.lowercase().trim(); val b=b0.lowercase().trim()
        val dp=Array(a.length+1){IntArray(b.length+1)}
        for(i in 0..a.length) dp[i][0]=i; for(j in 0..b.length) dp[0][j]=j
        for(i in 1..a.length) for(j in 1..b.length){ val c=if(a[i-1]==b[j-1])0 else 1; dp[i][j]=minOf(dp[i-1][j]+1,dp[i][j-1]+1,dp[i-1][j-1]+c) }
        return dp[a.length][b.length]
    }
    fun findBest(text:String,cands:List<String>):String?{
        var best:String?=null; var min=Int.MAX_VALUE
        val thr=when{ text.length<=4->1; text.length<=6->2; else->3 }
        for(c in cands){ val d=dist(text,c); if(d<min && d<=thr){ min=d; best=c } }
        return best
    }
    fun close(a:String,b:String,maxDist:Int):Boolean = dist(a,b)<=maxDist
}
