package com.vanelle.os
import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CrashLogger{
    private const val FILE_NAME="last_crash.txt"
    fun install(ctx:Context){
        val appCtx=ctx.applicationContext
        val previous=Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler{ thread,throwable->
            try{
                val sw=StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val stamp=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.FRANCE).format(Date())
                File(appCtx.filesDir,FILE_NAME).writeText("$stamp\n\n$sw")
            }catch(_:Exception){}
            previous?.uncaughtException(thread,throwable)
        }
    }
    fun readLast(ctx:Context):String?{
        val f=File(ctx.filesDir,FILE_NAME)
        return if(f.exists()) f.readText() else null
    }
    fun clear(ctx:Context){ File(ctx.filesDir,FILE_NAME).delete() }
}
