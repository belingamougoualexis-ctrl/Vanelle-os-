package com.vanelle.os

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * Mémoire épisodique + consolidation nocturne.
 * Stocke les interactions de la journée, puis les synthétise en faits durables.
 */
class EpisodicMemory(private val context: Context) {
    private val prefs = context.getSharedPreferences("vanelle_episodic", 0)
    private val relational = RelationalMemory(context)

    fun logEpisode(kind: String, content: String) {
        if (PersonalityPrefs.isGuestMode(context)) return
        val day = dayKey()
        val arr = JSONArray(prefs.getString("day_$day", "[]"))
        arr.put(JSONObject()
            .put("t", System.currentTimeMillis())
            .put("k", kind.take(24))
            .put("c", content.take(400)))
        // garde max 80 épisodes / jour
        val trimmed = JSONArray()
        val start = (arr.length() - 80).coerceAtLeast(0)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        prefs.edit().putString("day_$day", trimmed.toString()).apply()
    }

    fun todaySummary(): String {
        val day = dayKey()
        val arr = JSONArray(prefs.getString("day_$day", "[]"))
        if (arr.length() == 0) return "Aucune interaction mémorisée aujourd'hui."
        val lines = mutableListOf<String>()
        for (i in 0 until arr.length().coerceAtMost(12)) {
            val o = arr.getJSONObject(i)
            lines += "• ${o.optString("k")} : ${o.optString("c").take(90)}"
        }
        return "Aujourd'hui (${arr.length()} épisodes) :\n" + lines.joinToString("\n")
    }

    /**
     * Consolidation : transforme les épisodes du jour en faits relationnels.
     * À appeler la nuit (ou manuellement).
     */
    fun consolidate(): String {
        if (PersonalityPrefs.isGuestMode(context)) {
            return "Mode invité actif : aucune consolidation de mémoire."
        }
        val day = dayKey()
        val arr = JSONArray(prefs.getString("day_$day", "[]"))
        if (arr.length() == 0) return "Rien à consolider pour aujourd'hui."

        var facts = 0
        val important = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val c = arr.getJSONObject(i).optString("c")
            if (c.length > 25 && (c.contains("souviens") || c.contains("rappelle") ||
                        c.contains("rendez") || c.contains("projet") || c.contains("important") ||
                        c.contains("objectif"))) {
                relational.rememberFact(c.take(200))
                important += c.take(80)
                facts++
            }
        }
        prefs.edit().putLong("last_consolidation", System.currentTimeMillis()).apply()
        return if (facts == 0) {
            "Consolidation terminée : ${arr.length()} épisodes passés en revue, aucun fait prioritaire extrait."
        } else {
            "Consolidation nocturne terminée : $facts faits importants extraits et mémorisés.\n" +
                important.take(5).joinToString("\n") { "• $it" }
        }
    }

    private fun dayKey(): String {
        val cal = Calendar.getInstance()
        return "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.DAY_OF_YEAR)}"
    }
}
