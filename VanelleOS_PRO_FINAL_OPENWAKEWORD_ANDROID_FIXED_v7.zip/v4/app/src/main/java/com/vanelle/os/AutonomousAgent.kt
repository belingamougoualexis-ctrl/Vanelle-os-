package com.vanelle.os

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Agent multi-étapes : plan Llama si disponible, sinon règles déterministes.
 * Exécute uniquement des commandes « feuilles » (allowAgents=false) pour éviter la récursion.
 */
class AutonomousAgent(private val context: Context) {
    private val relational = RelationalMemory(context)
    private val localAI = LocalLlamaHelper.get(context)

    data class Step(val description: String, val command: String)
    data class Plan(val goal: String, val steps: List<Step>)

    suspend fun run(goal: String): String = withContext(Dispatchers.IO) {
        if (goal.isBlank()) {
            return@withContext "Objectif vide. Indique ce que tu veux que je réalise."
        }

        HapticLanguage.play(context, HapticLanguage.Signal.LISTENING)
        val plan = buildSmartPlan(goal)
        if (plan.steps.isEmpty()) {
            return@withContext "Impossible de décomposer « ${goal.take(80)} »."
        }

        val interpreter = CommandInterpreter(context)
        val results = mutableListOf<String>()
        var successCount = 0
        for ((i, step) in plan.steps.withIndex()) {
            if (isAgentLike(step.command)) {
                results += "Étape ${i + 1}/${plan.steps.size} — ${step.description} : ignorée (commande agent interdite en sous-étape)."
                continue
            }
            try {
                val res = interpreter.execute(step.command, allowAgents = false)
                if (isSuccess(res)) successCount++
                results += "Étape ${i + 1}/${plan.steps.size} — ${step.description} : $res"
            } catch (e: Exception) {
                results += "Étape ${i + 1}/${plan.steps.size} — ${step.description} : échec (${e.message ?: "erreur"})."
            }
        }

        try {
            relational.rememberFact("Objectif agent: ${goal.take(100)} → $successCount/${plan.steps.size}")
            EpisodicMemory(context).logEpisode("agent", goal.take(120))
        } catch (_: Exception) {}

        buildReport(goal, plan, results, successCount)
    }

    private suspend fun buildSmartPlan(goal: String): Plan {
        if (LlamaModelManager.isReady(context)) {
            val prompt = """
Tu es un planificateur d'actions pour un assistant vocal Android.
Décompose l'objectif en 2 à 5 étapes.
Réponds UNIQUEMENT avec des lignes:
ETAPE | description | commande
Commandes autorisées uniquement: batterie, ouvre [app], navigue vers [lieu], souviens-toi que [...], résume l'écran, urgence, quel est mon contexte
Objectif: $goal
""".trimIndent()
            val raw = localAI.answer(prompt, extraContext = relational.contextForAi(), fastMode = false, maxTokensHint = 180)
            if (raw != LocalLlamaHelper.NOT_READY && raw.isNotBlank()) {
                val steps = parseLlamaPlan(raw)
                if (steps.isNotEmpty()) return Plan(goal, steps.take(5))
            }
        }
        return Plan(goal, heuristicSteps(goal).take(5))
    }

    private fun parseLlamaPlan(raw: String): List<Step> {
        val out = mutableListOf<Step>()
        for (line in raw.lines()) {
            val parts = line.split("|").map { it.trim() }
            if (parts.size < 3) continue
            val desc = parts[1].ifBlank { "Action" }
            val cmd = parts[2].trim()
            if (cmd.isBlank()) continue
            if (isAgentLike(cmd)) continue
            out += Step(desc.take(60), cmd.take(120))
        }
        return out
    }

    private fun isAgentLike(cmd: String): Boolean {
        val c = cmd.lowercase()
        return c.contains("réalise") || c.contains("realise") ||
            c.contains("prépare mon") || c.contains("prepare mon") ||
            c.startsWith("react") || c.contains("mode react") ||
            c.contains("organise ") || c.contains("étape par étape")
    }

    private fun heuristicSteps(goal: String): List<Step> {
        val g = goal.lowercase()
        val steps = mutableListOf<Step>()
        when {
            g.contains("départ") || g.contains("voyage") || g.contains("trajet") ||
                g.contains("aller à") || g.contains("aller a") -> {
                steps += Step("Vérifier la batterie", "batterie")
                extractDestination(g)?.let {
                    steps += Step("Ouvrir l'itinéraire", "navigue vers $it")
                }
                steps += Step("Mémoriser l'intention", "souviens-toi que je prépare un départ")
                steps += Step("Contexte", "quel est mon contexte")
            }
            g.contains("réunion") || g.contains("rdv") || g.contains("rendez-vous") -> {
                steps += Step("Noter le rendez-vous", "souviens-toi que j'ai un rendez-vous important")
                steps += Step("Lire l'écran", "résume l'écran")
            }
            g.contains("budget") || g.contains("dépenses") || g.contains("argent") -> {
                steps += Step("Outil calcul", "calculatrice")
                steps += Step("Mémoriser", "souviens-toi que je veux suivre mon budget")
            }
            g.contains("urgent") || g.contains("secours") -> {
                steps += Step("Urgences", "urgence")
            }
            g.contains("soir") || g.contains("nuit") || g.contains("dormir") -> {
                steps += Step("Consolider la mémoire", "consolide la mémoire")
            }
            else -> {
                steps += Step("Mémoriser l'objectif", "souviens-toi de cet objectif : ${goal.take(100)}")
                steps += Step("État batterie", "batterie")
                steps += Step("Contexte", "quel est mon contexte")
            }
        }
        return steps
    }

    private fun extractDestination(g: String): String? {
        val m = Regex("(?:pour|vers|à|a)\\s+([a-zéèêàâùûôïç\\- ]{2,40})").find(g)
        return m?.groupValues?.get(1)?.trim()?.takeIf { it.length > 2 }
    }

    private fun isSuccess(res: String): Boolean {
        val r = res.lowercase()
        return res.isNotBlank() && !r.contains("pas pu") && !r.contains("impossible") &&
            !r.contains("n'ai pas") && !r.startsWith("active ") &&
            !r.contains("permission")
    }

    private fun buildReport(goal: String, plan: Plan, results: List<String>, success: Int): String {
        val header = if (success == plan.steps.size) {
            "Objectif atteint : « ${goal.take(60)} »."
        } else {
            "Objectif partiellement réalisé ($success/${plan.steps.size}) : « ${goal.take(50)} »."
        }
        HapticLanguage.play(
            context,
            if (success == plan.steps.size) HapticLanguage.Signal.SUCCESS else HapticLanguage.Signal.CONFIRM
        )
        return header + "\n" + results.joinToString("\n")
    }
}
