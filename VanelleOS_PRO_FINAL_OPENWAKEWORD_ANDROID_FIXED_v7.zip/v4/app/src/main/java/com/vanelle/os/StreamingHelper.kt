package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder

class StreamingHelper(private val c:Context){
    private fun isInstalled(pkg:String):Boolean = try{ c.packageManager.getPackageInfo(pkg,0); true }catch(_:Exception){ false }

    fun open(platformRaw:String,titleRaw:String):String{
        val platform=platformRaw.trim().lowercase()
        val title=titleRaw.trim()
        return when{
            platform.contains("youtube")-> {
                try{
                    val i=Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/results?search_query=${URLEncoder.encode(title,"UTF-8")}")).apply{ addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                    c.startActivity(i)
                    if (title.isBlank()) "YouTube ouvert."
                    else "YouTube ouvert avec la recherche « $title »."
                }catch(_:Exception){
                    "Impossible d'ouvrir YouTube. Vérifie qu'un navigateur ou l'application YouTube est installée."
                }
            }
            platform.contains("netflix")-> openAppOrWeb("com.netflix.mediaclient","https://www.netflix.com/search?q=${URLEncoder.encode(title,"UTF-8")}","Netflix")
            platform.contains("disney")-> openAppOrWeb("com.disney.disneyplus","https://www.disneyplus.com/","Disney+")
            platform.contains("prime")-> openAppOrWeb("com.amazon.avod.thirdpartyclient","https://www.primevideo.com/","Prime Video")
            else-> "Plateforme non reconnue (« $platformRaw »). Dis Netflix, Disney+, Prime Video ou YouTube."
        }
    }
    private fun openAppOrWeb(pkg:String,webUrl:String,label:String):String{
        return try{
            if(isInstalled(pkg)){
                val li=c.packageManager.getLaunchIntentForPackage(pkg)
                if(li!=null){
                    li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    c.startActivity(li)
                    return "$label ouvert. Aucun lien public ne permet de rechercher automatiquement un titre précis : cherche-le une fois dans l'app."
                }
            }
            val i=Intent(Intent.ACTION_VIEW,Uri.parse(webUrl)).apply{ addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            c.startActivity(i)
            "$label n'est pas installé, j'ouvre le site web à la place."
        }catch(_:Exception){
            "Impossible d'ouvrir $label. Vérifie qu'un navigateur est disponible et que tu as une connexion Internet."
        }
    }
}
