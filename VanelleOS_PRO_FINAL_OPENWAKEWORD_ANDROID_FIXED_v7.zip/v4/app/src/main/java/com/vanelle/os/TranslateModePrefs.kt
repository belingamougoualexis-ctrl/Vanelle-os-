package com.vanelle.os

import android.content.Context

object TranslateModePrefs {
    private fun p(c: Context) = c.getSharedPreferences("vanelle_prefs", 0)

    fun isActive(c: Context): Boolean = p(c).getBoolean("translate_active", false)

    fun source(c: Context): String = p(c).getString("translate_source", "auto") ?: "auto"

    fun target(c: Context): String = p(c).getString("translate_target", "fr") ?: "fr"

    fun start(c: Context, source: String, target: String) {
        val s = TranslateHelper.codeFor(source) ?: source.ifBlank { "auto" }
        val t = (TranslateHelper.codeFor(target) ?: target.ifBlank { "fr" }).let {
            if (it == "auto") "fr" else it
        }
        p(c).edit()
            .putBoolean("translate_active", true)
            .putString("translate_source", s)
            .putString("translate_target", t)
            .commit()
    }

    fun stop(c: Context) {
        p(c).edit().putBoolean("translate_active", false).commit()
    }
}
