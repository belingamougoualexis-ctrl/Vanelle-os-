package com.vanelle.os

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.Handler
import android.os.Looper
import android.os.VibratorManager

/**
 * Langage haptique : patterns de vibration qui portent un sens.
 */
object HapticLanguage {
    enum class Signal { UNDERSTOOD, CONFIRM, WARNING, SUCCESS, ERROR, LISTENING }

    fun play(context: Context, signal: Signal) {
        val vib = vibrator(context) ?: return
        val run = Runnable {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val effect = when (signal) {
                    Signal.UNDERSTOOD -> VibrationEffect.createWaveform(longArrayOf(0, 40, 60, 40), -1)
                    Signal.CONFIRM -> VibrationEffect.createWaveform(longArrayOf(0, 30, 40, 30, 40, 30), -1)
                    Signal.WARNING -> VibrationEffect.createWaveform(longArrayOf(0, 120, 80, 120, 80, 120), -1)
                    Signal.SUCCESS -> VibrationEffect.createWaveform(longArrayOf(0, 50, 30, 90), -1)
                    Signal.ERROR -> VibrationEffect.createWaveform(longArrayOf(0, 200, 100, 200), -1)
                    Signal.LISTENING -> VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE)
                }
                vib.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                when (signal) {
                    Signal.UNDERSTOOD -> vib.vibrate(longArrayOf(0, 40, 60, 40), -1)
                    Signal.CONFIRM -> vib.vibrate(longArrayOf(0, 30, 40, 30, 40, 30), -1)
                    Signal.WARNING -> vib.vibrate(longArrayOf(0, 120, 80, 120), -1)
                    Signal.SUCCESS -> vib.vibrate(longArrayOf(0, 50, 30, 90), -1)
                    Signal.ERROR -> vib.vibrate(longArrayOf(0, 200, 100, 200), -1)
                    Signal.LISTENING -> vib.vibrate(35)
                }
            }
        } catch (_: Exception) { /* ignore */ }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) run.run()
        else Handler(Looper.getMainLooper()).post(run)
    }

    fun describe(): String = """
        Langage haptique disponible :
        • compris = double pulse court
        • confirmation = triple pulse
        • attention = pulses longs
        • succès = pulse montant
        • erreur = double long
        • écoute = micro-pulse
    """.trimIndent()

    private fun vibrator(context: Context): Vibrator? {
        return if (Build.VERSION.SDK_INT >= 31) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }
}
