package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.provider.MediaStore

/** Multimodal léger : ouverture caméra / galerie pour capture (analyse = résumé écran ou note). */
object MultimodalHelper {
    fun openCamera(c: Context): String {
        return try {
            val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            c.startActivity(i)
            "Caméra ouverte. Prends la photo, puis dis-moi ce que tu veux en faire (ex: retiens ça, résume)."
        } catch (_: Exception) {
            "Impossible d'ouvrir la caméra. Vérifie qu'une application appareil photo est installée et que la permission est accordée."
        }
    }

    fun openGallery(c: Context): String {
        return try {
            val i = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            c.startActivity(i)
            "Galerie ouverte. Choisis une image, puis dis-moi ce que tu veux en faire."
        } catch (_: Exception) {
            "Impossible d'ouvrir la galerie. Vérifie qu'une application de photos est installée."
        }
    }
}
