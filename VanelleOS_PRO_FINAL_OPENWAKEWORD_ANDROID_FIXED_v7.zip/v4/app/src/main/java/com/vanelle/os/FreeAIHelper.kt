package com.vanelle.os
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Réponses réelles hors modèle local : conversation naturelle + Wikipedia FR + DuckDuckGo.
 */
class FreeAIHelper(private val context: Context) {
    private val local = mapOf(
        "bonjour" to "Bonjour ! Je t'écoute — dis-moi ce dont tu as besoin.",
        "salut" to "Salut ! Je suis là, vas-y.",
        "hello" to "Hello ! Je t'écoute.",
        "ca va" to "Ça va très bien, merci. Et toi ?",
        "comment ca va" to "Très bien de mon côté. Qu'est-ce que je peux faire pour toi ?",
        "qui es tu" to "Je suis Vanelle, ton assistante. Je réponds à tes questions et j'exécute des actions sur ton téléphone.",
        "merci" to "Avec plaisir.",
        "merci beaucoup" to "De rien, content d'avoir pu t'aider.",
        "blague" to "Pourquoi les plongeurs plongent-ils en arrière ? Parce que sinon ils tombent dans le bateau.",
        "au revoir" to "À bientôt. Appelle-moi dès que tu as besoin.",
        "bonne nuit" to "Bonne nuit. Repose-toi bien.",
        "aide" to "Tu peux me demander d'ouvrir une app, d'appeler quelqu'un, d'envoyer un message, de chercher sur le web, de traduire, ou simplement me poser une question.",
        "que sais tu faire" to "J'ouvre des apps, j'appelle, j'envoie des SMS, je cherche sur le web, je traduis, je programme des rappels, et je discute avec toi.",
        "comment tu t appelles" to "Je m'appelle Vanelle. Et toi ?"
    )

    fun localOnly(q0: String): String? {
        val q = q0.lowercase().trim()
        if (q.isBlank()) return null
        for ((k, v) in local) {
            if (q == k || q.startsWith("$k ") || FuzzyMatch.close(q, k, 2)) return v
        }
        return null
    }

    suspend fun answer(q0: String): String = withContext(Dispatchers.IO) {
        val q = q0.lowercase().trim()
        if (q.isBlank()) return@withContext "Je n'ai rien entendu, tu peux répéter ?"
        if (!PrivacyFirewall.allowWeb(context)) {
            return@withContext "Pare-feu confidentialité : accès web/IA cloud bloqué. Active le web dans les réglages privacy ou désactive le lockdown."
        }

        for ((k, v) in local) {
            if (q == k || q.startsWith("$k ") || q.contains(" $k") || FuzzyMatch.close(q, k, 2)) {
                return@withContext v
            }
        }

        val topic = q
            .replace(Regex("c'est quoi|c est quoi|qu'est-ce que|qui est|dis[- ]moi|explique[- ]moi|parle[- ]moi de|cassandra|vanelle"), "")
            .trim()
            .take(80)
            .ifEmpty { q.take(40) }

        val wiki = fetchWiki(topic)
        if (wiki != null) return@withContext humanize(wiki)

        val ddg = fetchDDG(topic)
        if (ddg != null) return@withContext humanize(ddg)

        "Je n'ai pas trouvé d'info fiable et à jour là-dessus. Tu peux me redemander autrement, ou dire « cherche [sujet] » pour que j'ouvre une recherche web."
    }

    /** Rend un extrait encyclopédique un peu plus conversationnel. */
    private fun humanize(raw: String): String {
        var t = raw.trim()
        if (t.length > 420) t = t.take(417).trimEnd() + "…"
        // Évite le ton trop encyclopédique en début de phrase
        return t
    }

    private fun fetchWiki(t: String): String? = try {
        val u = URL("https://fr.wikipedia.org/api/rest_v1/page/summary/${URLEncoder.encode(t, "UTF-8")}")
        val c = u.openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "VanelleOS/1.0 (assistant vocal; contact: app)")
        c.connectTimeout = 6000
        c.readTimeout = 6000
        if (c.responseCode == 200) {
            val o = JSONObject(c.inputStream.bufferedReader().readText())
            val e = o.optString("extract")
            if (e.isNotBlank()) e else null
        } else null
    } catch (_: Exception) { null }

    private fun fetchDDG(t: String): String? = try {
        val u = URL("https://api.duckduckgo.com/?q=${URLEncoder.encode(t, "UTF-8")}&format=json&no_html=1&skip_disambig=1")
        val c = u.openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "VanelleOS/1.0")
        c.connectTimeout = 6000
        c.readTimeout = 6000
        if (c.responseCode == 200) {
            val o = JSONObject(c.inputStream.bufferedReader().readText())
            val a = o.optString("AbstractText")
            if (a.isNotBlank()) a else null
        } else null
    } catch (_: Exception) { null }
}
