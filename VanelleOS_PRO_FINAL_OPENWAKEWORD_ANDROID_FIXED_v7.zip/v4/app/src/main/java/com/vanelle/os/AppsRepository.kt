package com.vanelle.os
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.*
class AppsRepository(private val context:Context){
    companion object{
        @Volatile private var cached:List<Item>?=null
        @Volatile private var loading=false
        private val scope=CoroutineScope(Dispatchers.IO+SupervisorJob())
    }
    data class Item(val label:String,val pkg:String)
    init{ ensureLoading() }
    private fun ensureLoading(){
        if(cached!=null || loading) return
        loading=true
        scope.launch{
            val list=try{
                val pm=context.applicationContext.packageManager
                val mi=Intent(Intent.ACTION_MAIN).apply{ addCategory(Intent.CATEGORY_LAUNCHER) }
                val acts=if(Build.VERSION.SDK_INT>=33) pm.queryIntentActivities(mi,PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())) else @Suppress("DEPRECATION") pm.queryIntentActivities(mi,PackageManager.MATCH_ALL)
                acts.map{ Item(it.loadLabel(pm).toString(),it.activityInfo.packageName) }
            }catch(_:Exception){ emptyList() }
            cached=list; loading=false
        }
    }
    suspend fun launch(name:String):String{
        if(name.isBlank()) return "Nom d'application manquant."
        ensureLoading()
        var tries=0
        while(cached==null && tries<30){ delay(100); tries++ }
        val apps=cached
        if(apps.isNullOrEmpty()) return "Je charge encore la liste des applications. Réessaie dans une ou deux secondes."
        val bestLabel=FuzzyMatch.findBest(name,apps.map{it.label})
            ?: return "Je ne trouve aucune application nommée « $name » sur ton téléphone. Vérifie le nom ou dis-moi d'ouvrir une autre app."
        val best=apps.firstOrNull{ it.label==bestLabel }
            ?: return "L'application « $bestLabel » a été trouvée mais je n'arrive pas à la localiser correctement."
        val li=context.packageManager.getLaunchIntentForPackage(best.pkg)
            ?: return "L'application « ${best.label} » est installée mais n'a pas d'écran principal que je peux ouvrir."
        return try{
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(li)
            "D'accord, j'ouvre ${best.label}."
        }catch(_:Exception){
            "Je n'ai pas pu ouvrir « ${best.label} ». Raison probable : restriction système ou application verrouillée. Essaie de l'ouvrir manuellement une fois."
        }
    }
}
