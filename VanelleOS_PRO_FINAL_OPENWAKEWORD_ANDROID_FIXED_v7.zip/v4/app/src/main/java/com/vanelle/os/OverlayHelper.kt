package com.vanelle.os
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max

/**
 * Affiche la mascotte par-dessus l'écran avec synchronisation labiale
 * (bouche qui s'ouvre/ferme au rythme de la parole TTS).
 */
object OverlayHelper {
    private var currentView: View? = null
    private var mouthView: View? = null
    private var answerView: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var hideRunnable: Runnable? = null
    private var mouthRunnable: Runnable? = null
    private var mouthAnimator: ValueAnimator? = null
    private var isTalking = false

    // Formes de bouche (échelle verticale) : fermée → légèrement ouverte → grande ouverture
    private const val MOUTH_CLOSED = 0.15f
    private const val MOUTH_MID = 0.65f
    private const val MOUTH_OPEN = 1.0f

    fun canDraw(c: Context): Boolean = Settings.canDrawOverlays(c)

    fun requestPermission(c: Context) {
        try {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            c.startActivity(i)
        } catch (_: Exception) {}
    }

    private fun dp(c: Context, v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), c.resources.displayMetrics).toInt()

    fun show(c: Context, mascotDrawableId: Int, question: String, answer: String) {
        showInternal(c, mascotDrawableId, question, answer, autoHideMs = 16_000L)
    }

    fun showMascot(c: Context, mascotDrawableId: Int, greeting: String = "") {
        showInternal(c, mascotDrawableId, "", greeting.ifBlank { "Me voici !" }, autoHideMs = 12_000L)
    }

    /**
     * Démarre la synchro labiale.
     * Appelé au début du TTS (onStart).
     */
    fun startTalking() {
        handler.post {
            isTalking = true
            hideRunnable?.let { handler.removeCallbacks(it) }
            mouthRunnable?.let { handler.removeCallbacks(it) }
            mouthAnimator?.cancel()

            val mouth = mouthView ?: return@post
            mouth.visibility = View.VISIBLE
            mouth.scaleX = 1f
            mouth.scaleY = MOUTH_CLOSED
            mouth.alpha = 1f

            // Pas d'animation artificielle : les mouvements sont déclenchés
            // uniquement par les événements réels de synthèse vocale (onRangeStart).
        }
    }

    /**
     * Impulsion labiale synchronisée avec un segment de parole (onRangeStart TTS).
     * @param spokenChunk le morceau de texte en cours de prononciation (optionnel)
     */
    fun pulseMouth(spokenChunk: String? = null) {
        if (!isTalking) return
        handler.post {
            val mouth = mouthView ?: return@post
            mouth.visibility = View.VISIBLE

            // Ouverture selon le contenu phonétique approximatif
            val target = opennessFor(spokenChunk)
            animateMouthTo(target, durationMs = 70L) {
                // Referme un peu après l'impulsion (mouvement naturel)
                if (isTalking) {
                    handler.postDelayed({
                        if (isTalking) animateMouthTo(MOUTH_CLOSED + 0.1f, 90L)
                    }, 80)
                }
            }
        }
    }

    /** Arrête la synchro labiale (TTS terminé ou erreur). */
    fun stopTalking() {
        handler.post {
            isTalking = false
            mouthRunnable?.let { handler.removeCallbacks(it) }
            mouthRunnable = null
            mouthAnimator?.cancel()
            mouthAnimator = null

            val mouth = mouthView
            if (mouth != null) {
                animateMouthTo(MOUTH_CLOSED, 120L) {
                    mouth.visibility = View.INVISIBLE
                }
            }

            // Disparition quelques secondes après la fin de la parole
            hideRunnable?.let { handler.removeCallbacks(it) }
            hideRunnable = Runnable {
                try {
                    currentView?.let { v ->
                        val wm = v.context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                        wm.removeView(v)
                    }
                } catch (_: Exception) {}
                currentView = null
                mouthView = null
                answerView = null
            }
            handler.postDelayed(hideRunnable!!, 3500)
        }
    }

    // --- Animation ---

    private fun animateMouthTo(scaleY: Float, durationMs: Long, end: (() -> Unit)? = null) {
        val mouth = mouthView ?: return
        mouthAnimator?.cancel()
        val start = mouth.scaleY
        val anim = ValueAnimator.ofFloat(start, scaleY).apply {
            duration = durationMs
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { a ->
                val v = a.animatedValue as Float
                mouth.scaleY = v
                // Légère largeur quand la bouche s'ouvre
                mouth.scaleX = 0.85f + 0.15f * (v / MOUTH_OPEN)
                mouth.alpha = max(0.4f, v)
            }
            doOnEndCompat { end?.invoke() }
        }
        mouthAnimator = anim
        anim.start()
    }

    private fun ValueAnimator.doOnEndCompat(block: () -> Unit) {
        addListener(object : android.animation.Animator.AnimatorListener {
            override fun onAnimationStart(a: android.animation.Animator) {}
            override fun onAnimationCancel(a: android.animation.Animator) {}
            override fun onAnimationRepeat(a: android.animation.Animator) {}
            override fun onAnimationEnd(a: android.animation.Animator) { block() }
        })
    }

    /**
     * Estimation grossière d'ouverture selon voyelles / consonnes.
     * Les voyelles → bouche plus ouverte ; consonnes fermées → plus fermée.
     */
    private fun opennessFor(chunk: String?): Float {
        if (chunk.isNullOrBlank()) {
            return listOf(MOUTH_MID, MOUTH_OPEN, MOUTH_MID).random()
        }
        val lower = chunk.lowercase()
        val vowels = lower.count { it in "aeiouyàâäéèêëïîôöùûü" }
        val closed = lower.count { it in "bpm" } // bilabiales = bouche fermée
        return when {
            closed > vowels && closed > 0 -> MOUTH_CLOSED + 0.1f
            vowels >= 2 -> MOUTH_OPEN
            vowels == 1 -> MOUTH_MID + 0.15f
            else -> MOUTH_MID
        }
    }

    private fun showInternal(c: Context, mascotDrawableId: Int, question: String, answer: String, autoHideMs: Long) {
        if (!canDraw(c)) return
        try {
            val appCtx = c.applicationContext
            val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            remove(appCtx)

            val size = dp(appCtx, 150)
            val imgFrame = FrameLayout(appCtx).apply {
                layoutParams = LinearLayout.LayoutParams(size, size)
            }

            val img = ImageView(appCtx).apply {
                if (mascotDrawableId != 0) setImageResource(mascotDrawableId)
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = FrameLayout.LayoutParams(size, size)
            }

            // Bouche : ovale en bas du visage, animée en scaleY
            val mouth = View(appCtx).apply {
                val w = dp(appCtx, 38)
                val h = dp(appCtx, 18)
                layoutParams = FrameLayout.LayoutParams(w, h).apply {
                    gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                    bottomMargin = dp(appCtx, 34)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xFF0D0D0D.toInt())
                    setStroke(dp(appCtx, 1), 0xFFFF2D95.toInt())
                }
                pivotX = w / 2f
                pivotY = h / 2f
                scaleY = MOUTH_CLOSED
                visibility = View.INVISIBLE
                elevation = 8f
            }
            mouthView = mouth
            imgFrame.addView(img)
            imgFrame.addView(mouth)

            val nameTv = TextView(appCtx).apply {
                text = MascotManager.getDisplayName(appCtx)
                setTextColor(0xFFFF2D95.toInt())
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(4, 8, 4, 2)
            }

            val qv = TextView(appCtx).apply {
                text = question
                setTextColor(0xFF6B6B70.toInt())
                textSize = 11f
                setPadding(4, 4, 4, 2)
                gravity = Gravity.CENTER
                visibility = if (question.isBlank()) View.GONE else View.VISIBLE
            }

            val av = TextView(appCtx).apply {
                text = answer
                setTextColor(0xFF0A0A0A.toInt())
                textSize = 13f
                setPadding(4, 0, 4, 4)
                gravity = Gravity.CENTER
            }
            answerView = av

            val card = LinearLayout(appCtx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(appCtx, 20), dp(appCtx, 16), dp(appCtx, 20), dp(appCtx, 16))
                background = UiKit.card(appCtx)
                elevation = 14f
                addView(imgFrame)
                addView(nameTv)
                addView(qv)
                addView(av)
                setOnClickListener { remove(appCtx) }
            }

            val type = if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            params.y = dp(appCtx, 72)

            wm.addView(card, params)
            currentView = card

            hideRunnable?.let { handler.removeCallbacks(it) }
            hideRunnable = Runnable { remove(appCtx) }
            handler.postDelayed(hideRunnable!!, autoHideMs)
        } catch (_: Exception) {}
    }

    fun remove(c: Context) {
        try {
            isTalking = false
            mouthRunnable?.let { handler.removeCallbacks(it) }
            mouthRunnable = null
            mouthAnimator?.cancel()
            mouthAnimator = null
            hideRunnable?.let { handler.removeCallbacks(it) }
            hideRunnable = null
            val wm = c.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            currentView?.let { wm.removeView(it) }
        } catch (_: Exception) {}
        currentView = null
        mouthView = null
        answerView = null
    }
}
