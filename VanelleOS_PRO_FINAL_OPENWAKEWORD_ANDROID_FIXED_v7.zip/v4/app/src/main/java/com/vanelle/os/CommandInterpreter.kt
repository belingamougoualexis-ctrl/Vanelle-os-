package com.vanelle.os
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CommandInterpreter(private val context: Context) {
    companion object {
        // Actions purement locales/appareil : pas besoin de journaliser l'épisode ni
        // de passer par la détection d'humeur avant de les exécuter (chemin rapide).
        private val FAST_INTENTS = setOf(
            CommandIntent.FLASHLIGHT,
            CommandIntent.VOLUME,
            CommandIntent.RINGER,
            CommandIntent.CLIPBOARD_READ,
            CommandIntent.CLIPBOARD_WRITE,
            CommandIntent.OPEN_URL,
            CommandIntent.SHARE_TEXT,
            CommandIntent.TIMER,
            CommandIntent.BATTERY
        )
    }
    private val apps = AppsRepository(context)
    private val contacts = ContactsRepository(context)
    private val web = WebSearchHelper(context)
    private val yt = YouTubeHelper(context)
    private val tr = TranslateHelper(context)
    private val bat = BatteryHelper(context)
    private val em = EmergencyManager(context)
    private val vault = MemoryVault(context)
    private val maps = MapsHelper(context)
    private val tool = MiniToolGenerator(context)
    private val learner = WorkflowLearner(context)
    private val freeAI = FreeAIHelper(context)
    private val localAI = LocalLlamaHelper.get(context)
    private val relance = RelanceRepository(context)
    private val streaming = StreamingHelper(context)
    private val relational = RelationalMemory(context)
    private val agent = AutonomousAgent(context)
    private val episodic = EpisodicMemory(context)
    private val spatial = SpatialContext(context)
    private val dynamicUi = DynamicUiGenerator(context)
    private val emotion = EmotionEngine(context)
    private val device = DeviceActions(context)

    suspend fun execute(t: String, allowAgents: Boolean = true): String {
        if (t.isBlank()) return "Je n'ai rien entendu, tu peux répéter ?"
        // Parse d'abord pour chemin rapide (actions appareil sans overhead)
        val quick = CommandParser.parse(t)
        val isFastAction = quick.intent in FAST_INTENTS
        if (!isFastAction) {
            ActivityLog.add(context, "entendu", t.take(120))
            try { episodic.logEpisode("entendu", t.take(200)) } catch (_: Exception) {}
            try {
                val mood = emotion.detect(t)
                emotion.adaptPersonality(mood)
            } catch (_: Exception) {}
        }
        val parts = splitChain(t)
        if (parts.size >= 2) {
            val parsedParts = parts.map { CommandParser.parse(it) }
            if (parsedParts.all { it.intent != CommandIntent.UNKNOWN }) {
                val results = parts.map { executeSingle(it, allowAgents) }
                withContext(Dispatchers.IO) { learner.log(t) }
                val joined = results.joinToString(". ")
                ActivityLog.add(context, "action", joined.take(120))
                return joined
            }
        }
        val res = executeSingle(t, allowAgents)
        withContext(Dispatchers.IO) { learner.log(t) }
        ActivityLog.add(context, "action", res.take(120))
        return res
    }

    private fun splitChain(text: String): List<String> =
        text.split(Regex("(?i)\\s+et\\s+puis\\s+|\\s+puis\\s+|\\s+et\\s+"))
            .map { it.trim() }.filter { it.isNotBlank() }

    private suspend fun executeSingle(t: String, allowAgents: Boolean = true): String {
        val clean = t.trim().lowercase()
        if (MascotManager.isMascotNameSpoken(context, clean) &&
            clean.split(Regex("\\s+")).size <= 3 &&
            !clean.contains("ouvre") && !clean.contains("appelle") &&
            !clean.contains("cherche") && !clean.contains("envoie")
        ) return showMascotNow()

        val p = CommandParser.parse(t)
        return when (p.intent) {
            CommandIntent.SHOW_MASCOT -> showMascotNow()
            CommandIntent.OPEN_APP -> withContext(Dispatchers.IO) { apps.launch(p.args["app"] ?: "") }
            CommandIntent.CALL_CONTACT -> contacts.call(p.args["name"] ?: "")
            CommandIntent.SEND_MESSAGE -> contacts.sendMessage(p.args["name"] ?: "", p.args["message"] ?: "")
            CommandIntent.SEARCH_WEB -> answerSearchIntent(p.args["query"] ?: t)
            CommandIntent.YOUTUBE -> yt.search(p.args["query"] ?: "")
            CommandIntent.STREAMING -> withContext(Dispatchers.IO) {
                streaming.open(p.args["platform"] ?: "", p.args["title"] ?: "")
            }
            CommandIntent.TRANSLATE -> withContext(Dispatchers.IO) {
                tr.translateText(p.args["text"] ?: "", "auto", "fr")
            }
            CommandIntent.TRANSLATE_MODE_ON -> {
                val src = p.args["source"] ?: "auto"; val tgt = p.args["target"] ?: "fr"
                TranslateModePrefs.start(context, src, tgt)
                "Mode traduction activé."
            }
            CommandIntent.TRANSLATE_MODE_OFF -> {
                TranslateModePrefs.stop(context); "Mode traduction désactivé."
            }
            CommandIntent.MEMORY_SAVE -> withContext(Dispatchers.IO) {
                if (PersonalityPrefs.isGuestMode(context)) return@withContext "Mode invité : je ne mémorise rien."
                val key = p.args["key"] ?: "note"
                val data = p.args["data"] ?: ""
                vault.save(key, data)
                relational.rememberFact(data)
                "C'est noté."
            }
            CommandIntent.MEMORY_GET -> withContext(Dispatchers.IO) {
                val key = p.args["key"] ?: ""
                val all = vault.getAll()
                val exact = all[key]
                val contains = all.entries.firstOrNull { it.key.contains(key, true) }?.value
                val fuzzyKey = FuzzyMatch.findBest(key, all.keys.toList())
                val fuzzy = fuzzyKey?.let { all[it] }
                exact?.toString() ?: contains?.toString() ?: fuzzy?.toString() ?: freeAI.answer(key)
            }
            CommandIntent.MEMORY_CLEAR -> withContext(Dispatchers.IO) {
                vault.clear()
                relational.clearAll()
                "D'accord, j'ai tout effacé de ma mémoire."
            }
            CommandIntent.REMEMBER_FACT -> {
                val fact = p.args["fact"] ?: t
                if (PersonalityPrefs.isGuestMode(context)) "Mode invité : je ne mémorise rien pour l'instant."
                else {
                    relational.rememberFact(fact)
                    "OK, je m'en souviendrai."
                }
            }
            CommandIntent.SET_PROFILE -> {
                val key = p.args["key"] ?: "prenom"
                val value = p.args["value"] ?: ""
                if (PersonalityPrefs.isGuestMode(context)) "Mode invité activé : profil non enregistré."
                else {
                    relational.setProfileField(key, value)
                    if (key == "prenom") "Enchantée, $value."
                    else "C'est noté."
                }
            }
            CommandIntent.EMERGENCY -> em.sos()
            CommandIntent.BATTERY -> "Batterie ${bat.level()} %."
            CommandIntent.RESTAURANT -> {
                val q = p.args["query"] ?: "restaurant près de moi"
                if (web.search(q)) "J'ai lancé une recherche pour « $q »."
                else "Je n'ai pas pu ouvrir la recherche. Vérifie ta connexion Internet."
            }
            CommandIntent.TOOL -> tool.open()
            CommandIntent.LOST_PHONE -> LostPhoneManager.trigger(context)
            CommandIntent.MAPS -> maps.open(p.args["query"] ?: "")
            CommandIntent.ACCESSIBILITY_ACTION -> {
                val svc = VanelleAccessibilityService.instance
                if (svc == null) "Active le service d'accessibilité dans Configuration pour que je puisse faire cette action système."
                else {
                    svc.action(p.args["action"] ?: "")
                    "C'est fait."
                }
            }
            CommandIntent.READ_SCREEN -> screenRead()
            CommandIntent.SCREEN_SUMMARY -> screenSummary()
            CommandIntent.SCREEN_FILL -> screenFill(p.args["text"] ?: "")
            CommandIntent.CLICK_SCREEN -> {
                val svc = VanelleAccessibilityService.instance
                if (svc == null) "Active l'accessibilité dans Configuration."
                else {
                    val ok = svc.clickNodeWithText(p.args["target"] ?: "")
                    if (ok) "C'est fait." else "Élément introuvable à l'écran. Dis-moi le texte exact visible ou active mieux l'accessibilité."
                }
            }
            CommandIntent.SCHEDULE_TASK -> withContext(Dispatchers.IO) {
                val desc = p.args["description"] ?: "Rappel"
                val hour = p.args["hour"]?.toIntOrNull() ?: 8
                val minute = p.args["minute"]?.toIntOrNull() ?: 0
                val repeat = p.args["repeat"]?.toBoolean() ?: false
                val task = relance.addTask(desc, hour, minute, repeat)
                AlarmScheduler.scheduleNext(context, task)
                val exactOk = AlarmScheduler.canScheduleExact(context)
                val base = "Relance programmée : $desc à ${hour}h${minute.toString().padStart(2, '0')}."
                if (!exactOk) base + " Active les alarmes exactes dans Configuration pour plus de précision."
                else base
            }
            CommandIntent.CREATE_ROUTINE -> {
                val hour = p.args["hour"]?.toIntOrNull() ?: 7
                val minute = p.args["minute"]?.toIntOrNull() ?: 30
                val actions = p.args["actions"] ?: "briefing"
                RoutineManager.add(context, "Routine", hour, minute, actions)
                "Routine créée pour ${hour}h${minute.toString().padStart(2, '0')}. Je t'en parlerai à ce moment-là."
            }
            CommandIntent.LIST_ROUTINES -> RoutineManager.describe(context)
            CommandIntent.SET_PERSONALITY ->
                "Je garde un seul style de réponse, clair et naturel."
            CommandIntent.GUEST_MODE_ON -> {
                PersonalityPrefs.setGuestMode(context, true)
                "Mode invité activé : je ne mémorise plus rien."
            }
            CommandIntent.GUEST_MODE_OFF -> {
                PersonalityPrefs.setGuestMode(context, false)
                "Mode invité désactivé. Je peux à nouveau me souvenir."
            }
            CommandIntent.OPEN_CAMERA -> MultimodalHelper.openCamera(context)
            CommandIntent.OPEN_GALLERY -> MultimodalHelper.openGallery(context)
            CommandIntent.SHOW_ACTIVITY_LOG -> {
                val lines = ActivityLog.all(context).take(8)
                if (lines.isEmpty()) "Le journal est vide pour l'instant."
                else lines.joinToString("\n") { ActivityLog.formatLine(it.first, it.second, it.third) }
            }
            CommandIntent.AGENT_GOAL -> {
                if (!allowAgents) "Sous-étape agent refusée (garde anti-récursion)."
                else {
                    HapticLanguage.play(context, HapticLanguage.Signal.LISTENING)
                    agent.run(p.args["goal"] ?: t)
                }
            }
            CommandIntent.EPISODIC_SUMMARY -> episodic.todaySummary()
            CommandIntent.EPISODIC_CONSOLIDATE -> episodic.consolidate()
            CommandIntent.SPATIAL_CONTEXT -> withContext(Dispatchers.IO) {
                val desc = spatial.describe()
                val mode = spatial.suggestedMode()
                "$desc. Mode suggéré : $mode."
            }
            CommandIntent.HAPTIC_DEMO -> {
                HapticLanguage.play(context, HapticLanguage.Signal.SUCCESS)
                HapticLanguage.describe()
            }
            CommandIntent.DYNAMIC_TOOL -> dynamicUi.create(p.args["request"] ?: t)
            CommandIntent.FLASHLIGHT -> {
                val on = when (p.args["on"]) {
                    "1" -> true
                    "0" -> false
                    else -> null
                }
                device.flashlight(on)
            }
            CommandIntent.VOLUME -> device.volume(p.args["dir"] ?: "status")
            CommandIntent.RINGER -> device.ringer(p.args["mode"] ?: "status")
            CommandIntent.CLIPBOARD_READ -> device.clipboardRead()
            CommandIntent.CLIPBOARD_WRITE -> device.clipboardWrite(p.args["text"] ?: "")
            CommandIntent.OPEN_URL -> device.openUrl(p.args["url"] ?: "")
            CommandIntent.SHARE_TEXT -> device.shareText(p.args["text"] ?: "")
            CommandIntent.TIMER -> {
                val m = p.args["minutes"]?.toIntOrNull() ?: 5
                device.timerMinutes(m)
            }
            CommandIntent.POINT_NODE -> {
                val target = p.args["target"] ?: ""
                if (target.isBlank()) "Élément à pointer non précisé."
                else GuidanceOverlay.pointToNode(context, target)
            }
            CommandIntent.GUIDANCE_OVERLAY -> {
                val msg = p.args["message"] ?: "Regarde ici"
                GuidanceOverlay.show(context, msg)
            }
            CommandIntent.FORCE_NIGHTLY -> NightlyConsolidation.runNow(context)
            CommandIntent.PRIVACY_STATUS -> PrivacyFirewall.status(context)
            CommandIntent.PRIVACY_LOCKDOWN -> {
                PrivacyFirewall.lockdown(context)
                HapticLanguage.play(context, HapticLanguage.Signal.WARNING)
                "Lockdown activé. " + PrivacyFirewall.status(context)
            }
            else -> answerSmart(t)
        }
    }


    private suspend fun answerSmart(t: String): String {
        freeAI.localOnly(t)?.let { return it }

        if (LlamaModelManager.isReady(context)) {
            val ctx = relational.contextForAi()
            val fast = t.length < 120
            val llamaRes = localAI.answer(t, extraContext = ctx, fastMode = fast, maxTokensHint = if (fast) 90 else 160)
            if (llamaRes != LocalLlamaHelper.NOT_READY) return llamaRes
        }
        // Si offline préféré et pas de modèle → réponse locale honnête
        if (PersonalityPrefs.preferOffline(context) && !LlamaModelManager.isNetworkAvailable(context)) {
            return "Je suis en mode hors-ligne et les données avancées ne sont pas encore prêtes. Réessaie après la mise à jour, ou pose-moi une commande (ouvrir une app, batterie…)."
        }
        return fallbackAi(t)
    }

    private fun screenRead(): String {
        val svc = VanelleAccessibilityService.instance
            ?: return "Active le service d'accessibilité dans Configuration pour lire l'écran."
        val txt = svc.captureScreenText()
        return if (txt.isBlank()) "Je ne vois pas de texte lisible sur cet écran."
        else "Voici ce que je lis : ${txt.take(500)}"
    }

    private suspend fun screenSummary(): String {
        val svc = VanelleAccessibilityService.instance
            ?: return "Active l'accessibilité dans Configuration pour que je voie l'écran."
        val txt = svc.captureScreenText()
        if (txt.isBlank()) return "Écran vide ou non lisible pour moi."
        if (LlamaModelManager.isReady(context)) {
            val sum = localAI.answer(
                "Résume en 2 phrases :\n${txt.take(600)}",
                extraContext = "",
                fastMode = true,
                maxTokensHint = 100
            )
            if (sum != LocalLlamaHelper.NOT_READY) return sum
        }
        val clean = txt.replace(Regex("\\s+"), " ").trim()
        return "Résumé de l'écran : ${clean.take(320)}"
    }

    private fun screenFill(value: String): String {
        val svc = VanelleAccessibilityService.instance
            ?: return "Active l'accessibilité dans Configuration."
        val ok = svc.fillFocusedOrFirstField(value)
        return if (ok) "Champ rempli : « ${value.take(60)} »."
        else "Aucun champ trouvé. Touche d'abord la zone de texte à l'écran, puis redis : Cassandra, remplis avec …"
    }

    private fun showMascotNow(): String {
        val name = MascotManager.getDisplayName(context)
        return "Salut, je suis $name ! Tu peux me parler, je t'écoute."
    }

    /**
     * Raisonne avant d'ouvrir une application :
     * 1) modèle local si disponible ;
     * 2) réponse Web rapide si elle est suffisamment informative ;
     * 3) sinon seulement, ouverture d'une vraie recherche Web.
     */
    private suspend fun answerSearchIntent(query: String): String {
        val q = query.trim()
        if (q.isBlank()) return "Que veux-tu que je recherche ?"

        if (LlamaModelManager.isReady(context)) {
            val local = localAI.answer(
                "Réponds en français, concis. Si info récente nécessaire, dis-le. Demande : $q",
                extraContext = relational.contextForAi(),
                fastMode = q.length < 100,
                maxTokensHint = 160
            )
            if (local != LocalLlamaHelper.NOT_READY && local.isNotBlank()) return local
        }

        val free = freeAI.answer(q)
        val failed = free.startsWith("Je n'ai pas trouvé", ignoreCase = true) ||
            free.startsWith("Je n'ai pas trouve", ignoreCase = true)

        if (!failed && free.isNotBlank()) return free

        return if (web.search(q)) {
            "Je n'ai pas trouvé de réponse suffisamment fiable directement. " +
                "J'ai lancé une recherche sur « $q »."
        } else {
            "Je n'arrive pas à ouvrir la recherche pour le moment. Vérifie ta connexion Internet."
        }
    }

    private suspend fun fallbackAi(t: String): String {
        val ai = freeAI.answer(t)
        val failed = ai.startsWith("Je n'ai pas trouvé", ignoreCase = true) ||
            ai.startsWith("Je n'ai pas trouve", ignoreCase = true) ||
            ai.isBlank()
        if (failed) {
            val canNet = LlamaModelManager.isNetworkAvailable(context)
            if (!PersonalityPrefs.preferOffline(context) || canNet) {
                val opened = web.search(t)
                return if (opened) {
                    "Je n'ai pas trouvé de réponse directe et fiable. " +
                        "J'ai ouvert une recherche web sur « ${t.take(60)} » pour que tu puisses voir les résultats."
                } else {
                    "Je n'ai pas trouvé d'info fiable et je n'arrive pas non plus à ouvrir le navigateur. " +
                        "Vérifie ta connexion Internet ou reformule ta question."
                }
            }
            return "Je n'ai pas trouvé d'info fiable en mode hors-ligne. " +
                "Active la connexion ou télécharge le modèle local pour des réponses plus riches."
        }
        return ai
    }
}
