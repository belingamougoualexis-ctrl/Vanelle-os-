package com.vanelle.os

import android.view.accessibility.AccessibilityNodeInfo

class ScreenAnalysisHelper {
    /** Ne recycle PAS le root — l'appelant en est responsable. */
    fun capture(root: AccessibilityNodeInfo?): String {
        if (root == null) return ""
        val b = StringBuilder()
        trav(root, b, 0)
        return b.toString().replace(Regex("\\s+"), " ").trim().take(8000)
    }

    private fun trav(n: AccessibilityNodeInfo, b: StringBuilder, d: Int) {
        if (d > 30) return
        try {
            val t = n.text?.toString()
            if (!t.isNullOrBlank()) b.append(t).append(' ')
            val ddesc = n.contentDescription?.toString()
            if (!ddesc.isNullOrBlank() && ddesc != t) b.append(ddesc).append(' ')
            for (i in 0 until n.childCount) {
                val c = try {
                    n.getChild(i)
                } catch (_: Exception) {
                    null
                } ?: continue
                try {
                    trav(c, b, d + 1)
                } finally {
                    try {
                        c.recycle()
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
        }
    }
}
