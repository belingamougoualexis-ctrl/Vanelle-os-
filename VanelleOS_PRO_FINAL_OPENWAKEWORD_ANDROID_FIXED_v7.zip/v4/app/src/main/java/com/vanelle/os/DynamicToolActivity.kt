package com.vanelle.os

import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * UI générée à la volée (équivalent Compose runtime sans dépendance Compose).
 * Construit une mini-app selon le type demandé : compteur, notes, budget, checklist.
 */
class DynamicToolActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val kind = intent.getStringExtra(EXTRA_KIND) ?: "notes"
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Outil Vanelle"

        val root = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 48)
            setBackgroundColor(0xFFFAFAFA.toInt())
        }
        root.addView(col)

        col.addView(TextView(this).apply {
            text = title
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF0A0A0A.toInt())
            setPadding(0, 0, 0, 24)
        })
        col.addView(TextView(this).apply {
            text = "Interface générée dynamiquement · $kind"
            textSize = 12f
            setTextColor(0xFF8A8A8E.toInt())
            setPadding(0, 0, 0, 32)
        })

        when (kind) {
            "counter" -> buildCounter(col)
            "budget" -> buildBudget(col)
            "checklist" -> buildChecklist(col)
            else -> buildNotes(col)
        }

        col.addView(Button(this).apply {
            text = "Fermer"
            setOnClickListener { finish() }
            setPadding(0, 48, 0, 0)
        })

        setContentView(root)
        HapticLanguage.play(this, HapticLanguage.Signal.SUCCESS)
    }

    private fun buildCounter(col: LinearLayout) {
        var value = 0
        val tv = TextView(this).apply {
            text = "0"
            textSize = 48f
            gravity = Gravity.CENTER
            setTextColor(0xFFFF2D95.toInt())
            setPadding(0, 32, 0, 32)
        }
        col.addView(tv)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(label: String, delta: Int) = Button(this).apply {
            text = label
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                value += delta
                if (value < 0) value = 0
                tv.text = value.toString()
            }
        }
        row.addView(btn("−", -1))
        row.addView(btn("+", 1))
        row.addView(btn("Reset", -9999).apply {
            setOnClickListener { value = 0; tv.text = "0" }
        })
        col.addView(row)
    }

    private fun buildBudget(col: LinearLayout) {
        val prefs = getSharedPreferences("vanelle_dyn_budget", 0)
        var total = prefs.getFloat("total", 0f)
        val totalTv = TextView(this).apply {
            text = "Total : %.2f €".format(total)
            textSize = 20f
            setTextColor(0xFF0A0A0A.toInt())
            setPadding(0, 16, 0, 16)
        }
        val input = EditText(this).apply {
            hint = "Montant"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val note = EditText(this).apply { hint = "Libellé (optionnel)" }
        col.addView(totalTv)
        col.addView(input)
        col.addView(note)
        col.addView(Button(this).apply {
            text = "Ajouter une dépense"
            setOnClickListener {
                val v = input.text.toString().replace(",", ".").toFloatOrNull()
                if (v == null) {
                    Toast.makeText(this@DynamicToolActivity, "Montant invalide", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                total += v
                prefs.edit().putFloat("total", total).apply()
                totalTv.text = "Total : %.2f €".format(total)
                val label = note.text.toString().ifBlank { "dépense" }
                RelationalMemory(this@DynamicToolActivity)
                    .rememberFact("Budget: -$v € ($label)")
                input.text.clear()
                note.text.clear()
            }
        })
        col.addView(Button(this).apply {
            text = "Remettre à zéro"
            setOnClickListener {
                total = 0f
                prefs.edit().putFloat("total", 0f).apply()
                totalTv.text = "Total : 0.00 €"
            }
        })
    }

    private fun buildNotes(col: LinearLayout) {
        val prefs = getSharedPreferences("vanelle_dyn_notes", 0)
        val area = EditText(this).apply {
            hint = "Écris ici…"
            minLines = 6
            setText(prefs.getString("body", "") ?: "")
            gravity = Gravity.TOP
        }
        col.addView(area)
        col.addView(Button(this).apply {
            text = "Sauver dans la mémoire Vanelle"
            setOnClickListener {
                val t = area.text.toString().trim()
                prefs.edit().putString("body", t).apply()
                if (t.isNotBlank()) {
                    RelationalMemory(this@DynamicToolActivity).rememberFact("Note outil: ${t.take(200)}")
                    Toast.makeText(this@DynamicToolActivity, "Sauvé", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun buildChecklist(col: LinearLayout) {
        val prefs = getSharedPreferences("vanelle_dyn_check", 0)
        val items = (prefs.getString("items", "Tâche 1|Tâche 2|Tâche 3") ?: "")
            .split("|").filter { it.isNotBlank() }.toMutableList()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refresh() {
            box.removeAllViews()
            items.forEachIndexed { idx, label ->
                box.addView(Button(this).apply {
                    text = "☐ $label"
                    isAllCaps = false
                    setOnClickListener {
                        items.removeAt(idx)
                        prefs.edit().putString("items", items.joinToString("|")).apply()
                        refresh()
                    }
                })
            }
        }
        refresh()
        col.addView(box)
        val add = EditText(this).apply { hint = "Nouvelle tâche" }
        col.addView(add)
        col.addView(Button(this).apply {
            text = "Ajouter"
            setOnClickListener {
                val t = add.text.toString().trim()
                if (t.isNotBlank()) {
                    items += t
                    prefs.edit().putString("items", items.joinToString("|")).apply()
                    add.text.clear()
                    refresh()
                }
            }
        })
    }

    companion object {
        const val EXTRA_KIND = "kind"
        const val EXTRA_TITLE = "title"
    }
}
