package com.vanelle.os

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Journal de diagnostic dédié au pipeline d'écoute "Cassandra" (openWakeWord).
 * Contrairement à Logcat (nécessite un PC + adb), ce journal est lisible directement
 * dans l'app (Configuration → "Voir le journal d'écoute"), copiable en un tap.
 * Capture les étapes clés : chargement des modèles, résolution des formes de tenseurs,
 * démarrage/arrêt de l'écoute, erreurs d'inférence, détections du mot d'activation,
 * et le cycle SpeechRecognizer qui capture la commande après détection.
 */
object WakeWordDiagnostics {
    private const val FILE_NAME = "wakeword_diag.txt"
    private const val MAX_LINES = 300
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.FRANCE)

    @Synchronized
    fun log(ctx: Context, tag: String, message: String) {
        try {
            val stamp = fmt.format(Date())
            val line = "[$stamp] $tag: $message\n"
            val f = File(ctx.applicationContext.filesDir, FILE_NAME)
            val existing = if (f.exists()) f.readText() else ""
            val combined = existing + line
            val lines = combined.lines()
            val trimmed = if (lines.size > MAX_LINES) {
                lines.takeLast(MAX_LINES).joinToString("\n")
            } else combined.trimEnd('\n')
            f.writeText(trimmed)
        } catch (_: Exception) {
            // Journal best-effort — ne jamais interrompre le pipeline d'écoute pour ça.
        }
    }

    fun readAll(ctx: Context): String {
        return try {
            val f = File(ctx.applicationContext.filesDir, FILE_NAME)
            if (f.exists()) f.readText().ifBlank { "Aucun évènement enregistré pour l'instant." }
            else "Aucun évènement enregistré pour l'instant. Dis \"Cassandra\" puis reviens ici."
        } catch (_: Exception) {
            "Impossible de lire le journal."
        }
    }

    fun clear(ctx: Context) {
        try {
            File(ctx.applicationContext.filesDir, FILE_NAME).delete()
        } catch (_: Exception) {
        }
    }
}
