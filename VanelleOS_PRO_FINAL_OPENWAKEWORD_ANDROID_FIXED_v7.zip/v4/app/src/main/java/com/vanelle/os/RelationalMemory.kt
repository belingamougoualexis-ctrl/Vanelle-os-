package com.vanelle.os
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Mémoire relationnelle : profil, faits, humeurs, contexte de conversation.
 * Stockage chiffré via MemoryVault + prefs structurées.
 */
class RelationalMemory(private val c: Context) {
    private val vault = MemoryVault(c)
    private val prefs = c.getSharedPreferences("vanelle_relational", 0)

    fun setProfileField(key: String, value: String) {
        vault.save("profile_$key", value.trim())
        logEvent("memory", "Profil: $key")
    }

    fun getProfileField(key: String): String? = vault.get("profile_$key")

    fun getProfileSummary(): String {
        val keys = listOf("prenom", "ville", "travail", "humeur", "projet", "preference_ton")
        val parts = keys.mapNotNull { k ->
            getProfileField(k)?.let { v -> if (v.isNotBlank()) "$k: $v" else null }
        }
        return parts.joinToString(". ")
    }

    fun rememberFact(fact: String) {
        val arr = JSONArray(prefs.getString("facts", "[]"))
        arr.put(JSONObject().put("t", System.currentTimeMillis()).put("f", fact.take(300)))
        // garde les 40 derniers
        val trimmed = JSONArray()
        val start = (arr.length() - 40).coerceAtLeast(0)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        prefs.edit().putString("facts", trimmed.toString()).apply()
        vault.save("fact_${System.currentTimeMillis()}", fact.take(300))
        logEvent("memory", "Fait: ${fact.take(80)}")
    }

    fun recentFacts(limit: Int = 8): List<String> {
        val arr = JSONArray(prefs.getString("facts", "[]"))
        val out = mutableListOf<String>()
        for (i in (arr.length() - 1) downTo 0) {
            if (out.size >= limit) break
            out.add(arr.getJSONObject(i).optString("f"))
        }
        return out
    }

    fun setMood(mood: String) {
        setProfileField("humeur", mood)
        prefs.edit().putLong("mood_ts", System.currentTimeMillis()).apply()
    }

    /** Contexte injecté dans le prompt IA */
    fun contextForAi(): String {
        if (PersonalityPrefs.isGuestMode(c)) return ""
        val sb = StringBuilder()
        val profile = getProfileSummary().take(180)
        if (profile.isNotBlank()) sb.append("Profil: ").append(profile)
        val facts = recentFacts(3)
        if (facts.isNotEmpty()) {
            if (sb.isNotEmpty()) sb.append(" | ")
            sb.append(facts.joinToString(" | ") { it.take(80) })
        }
        return sb.toString().trim().take(350)
    }

    fun clearAll() {
        vault.clear()
        prefs.edit().clear().apply()
        logEvent("memory", "Mémoire effacée")
    }

    private fun logEvent(type: String, detail: String) {
        ActivityLog.add(c, type, detail)
    }
}
