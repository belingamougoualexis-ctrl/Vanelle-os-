package com.vanelle.os
import android.content.Context
import android.graphics.drawable.GradientDrawable

object UiKit{
    fun card(ctx:Context):GradientDrawable{
        val d=ctx.resources.displayMetrics.density
        return GradientDrawable().apply{
            setColor(0xFFFFFFFF.toInt())
            setStroke((1.5f*d).toInt(),0xFFFF2D95.toInt())
            cornerRadius=8f*d
        }
    }
    fun selected(ctx:Context):GradientDrawable{
        val d=ctx.resources.displayMetrics.density
        return GradientDrawable().apply{
            setColor(0xFFFFE3F1.toInt())
            setStroke((2f*d).toInt(),0xFFFF2D95.toInt())
            cornerRadius=8f*d
        }
    }
    fun pill(ctx:Context):GradientDrawable{
        val d=ctx.resources.displayMetrics.density
        return GradientDrawable().apply{
            setColor(0xFFFFFFFF.toInt())
            setStroke((1.5f*d).toInt(),0xFFFF2D95.toInt())
            cornerRadius=20f*d
        }
    }
}
