pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Requis pour io.github.ljcamargo:llamacpp-kotlin (publié uniquement sur JitPack)
        maven(url = "https://jitpack.io")
    }
}
rootProject.name = "VanelleOS"
include(":app")
