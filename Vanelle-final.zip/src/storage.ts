import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AI, Message } from './types';

const AIS_KEY = '@vanelle/ais';
const chatKey = (id: string) => `@vanelle/chat/${id}`;

export async function getAIs(): Promise<AI[]> {
  const raw = await AsyncStorage.getItem(AIS_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw) as AI[];
  } catch {
    return [];
  }
}

export async function saveAI(ai: AI): Promise<void> {
  const list = await getAIs();
  const next = list.some((x) => x.id === ai.id)
    ? list.map((x) => (x.id === ai.id ? ai : x))
    : [ai, ...list];
  await AsyncStorage.setItem(AIS_KEY, JSON.stringify(next));
}

export async function deleteAI(id: string): Promise<void> {
  const list = await getAIs();
  await AsyncStorage.setItem(
    AIS_KEY,
    JSON.stringify(list.filter((x) => x.id !== id))
  );
  await AsyncStorage.removeItem(chatKey(id));
}

export async function getChat(id: string): Promise<Message[]> {
  const raw = await AsyncStorage.getItem(chatKey(id));
  if (!raw) return [];
  try {
    return JSON.parse(raw) as Message[];
  } catch {
    return [];
  }
}

export async function saveChat(id: string, messages: Message[]): Promise<void> {
  await AsyncStorage.setItem(chatKey(id), JSON.stringify(messages));
}
