import { NativeModules } from 'react-native';

export type ModelStatus = {
  llmReady: boolean;
  embeddingReady: boolean;
};

type VanelleNativeAPI = {
  getModelStatus(): Promise<ModelStatus>;
  chat(payload: string): Promise<{ text: string }>;
};

export const VanelleNative = NativeModules.VanelleNative as
  | VanelleNativeAPI
  | undefined;
