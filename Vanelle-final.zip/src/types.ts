export type Message = {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  ts: number;
};

export type AI = {
  id: string;
  name: string;
  description: string;
  style: string;
  systemPrompt: string;
  maxTokens: number;
  temperature: number;
  createdAt: number;
};
