import React, { useEffect, useState } from 'react';
import {
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { VanelleNative, type ModelStatus } from './native';
import { deleteAI, getAIs, getChat, saveAI, saveChat } from './storage';
import type { AI, Message } from './types';

const S = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#f5f5f2' },
  header: { backgroundColor: '#17171a', padding: 16 },
  brand: { color: '#fff', fontWeight: '800', fontSize: 16, letterSpacing: 2 },
  sub: { color: '#b7f36b', fontSize: 9, letterSpacing: 2 },
  body: { flex: 1, padding: 16 },
  title: { fontSize: 24, fontWeight: '800', color: '#17171a', marginBottom: 6 },
  muted: { color: '#6d6d73', fontSize: 13, lineHeight: 19 },
  card: {
    backgroundColor: '#fff',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#deded8',
    padding: 15,
    marginBottom: 12,
  },
  label: {
    fontSize: 12,
    fontWeight: '700',
    color: '#505057',
    marginTop: 10,
    marginBottom: 6,
  },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#d5d5cf',
    borderRadius: 9,
    paddingHorizontal: 12,
    paddingVertical: 11,
    color: '#17171a',
  },
  button: {
    backgroundColor: '#78a62e',
    borderRadius: 9,
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 12,
  },
  buttonText: { color: '#fff', fontWeight: '800' },
  nav: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: '#deded8',
    backgroundColor: '#fff',
  },
  navItem: { flex: 1, alignItems: 'center', paddingVertical: 12 },
  navText: { fontSize: 11, fontWeight: '700', color: '#77777d' },
  navActive: { color: '#78a62e' },
  status: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#deded8',
    borderRadius: 12,
    padding: 12,
    marginBottom: 14,
  },
  row: { flexDirection: 'row', alignItems: 'center' },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#78a62e',
    marginRight: 8,
  },
  chat: { flex: 1, padding: 12 },
  bubble: { maxWidth: '86%', borderRadius: 16, padding: 11, marginBottom: 9 },
  user: { alignSelf: 'flex-end', backgroundColor: '#dcefb9' },
  bot: {
    alignSelf: 'flex-start',
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#deded8',
  },
  bubbleText: { fontSize: 14, color: '#1b1b1f', lineHeight: 20 },
  composer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: '#deded8',
    backgroundColor: '#fff',
  },
  send: {
    width: 48,
    height: 44,
    borderRadius: 9,
    backgroundColor: '#78a62e',
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendText: { color: '#fff', fontWeight: '900' },
});

const makeId = () => `${Date.now()}-${Math.random().toString(36).slice(2)}`;

const blankAI = (name: string, description: string, style: string): AI => ({
  id: makeId(),
  name,
  description,
  style,
  systemPrompt: '',
  maxTokens: 700,
  temperature: 0.4,
  createdAt: Date.now(),
});

export default function App() {
  const [tab, setTab] = useState<'create' | 'ais' | 'account'>('create');
  const [ais, setAis] = useState<AI[]>([]);
  const [selected, setSelected] = useState<AI | null>(null);
  const [model, setModel] = useState<ModelStatus>({
    llmReady: false,
    embeddingReady: false,
  });

  const refresh = async () => {
    const list = await getAIs();
    setAis(list.sort((a, b) => b.createdAt - a.createdAt));
  };

  const poll = async () => {
    if (!VanelleNative) return;
    try {
      setModel(await VanelleNative.getModelStatus());
    } catch {
      // Native module may not be ready yet during first frames.
    }
  };

  useEffect(() => {
    void refresh();
    void poll();
    const timer = setInterval(() => void poll(), 2500);
    return () => clearInterval(timer);
  }, []);

  if (selected) {
    return (
      <Chat
        ai={selected}
        model={model}
        back={() => {
          setSelected(null);
          void refresh();
        }}
      />
    );
  }

  return (
    <SafeAreaView style={S.root}>
      <StatusBar barStyle="light-content" backgroundColor="#17171a" />
      <View style={S.header}>
        <Text style={S.brand}>VANELLE</Text>
        <Text style={S.sub}>ATELIER IA</Text>
      </View>
      <View style={S.body}>
        <View style={S.status}>
          <View style={S.row}>
            <View style={S.dot} />
            <Text style={{ fontWeight: '800' }}>
              {model.llmReady ? 'Llama.cpp prêt' : 'Préparation de llama.cpp…'}
            </Text>
          </View>
          <Text style={S.muted}>
            LLM {model.llmReady ? '✓' : '…'} · Embeddings{' '}
            {model.embeddingReady ? '✓' : '…'}
          </Text>
        </View>
        {tab === 'create' && (
          <Create
            onCreated={async (ai) => {
              await saveAI(ai);
              await refresh();
              setSelected(ai);
            }}
          />
        )}
        {tab === 'ais' && (
          <AIs
            ais={ais}
            open={setSelected}
            remove={async (id) => {
              await deleteAI(id);
              await refresh();
            }}
          />
        )}
        {tab === 'account' && <Account model={model} />}
      </View>
      <View style={S.nav}>
        <Nav
          label="Créer"
          active={tab === 'create'}
          onPress={() => setTab('create')}
        />
        <Nav
          label="Mes IA"
          active={tab === 'ais'}
          onPress={() => setTab('ais')}
        />
        <Nav
          label="Compte"
          active={tab === 'account'}
          onPress={() => setTab('account')}
        />
      </View>
    </SafeAreaView>
  );
}

function Nav({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable style={S.navItem} onPress={onPress}>
      <Text style={[S.navText, active && S.navActive]}>{label}</Text>
    </Pressable>
  );
}

function Create({ onCreated }: { onCreated: (ai: AI) => Promise<void> }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [style, setStyle] = useState('Généraliste');
  const [busy, setBusy] = useState(false);

  return (
    <ScrollView>
      <Text style={S.title}>Créer une nouvelle IA</Text>
      <Text style={S.muted}>
        Les modèles IA sont inclus dans l’application et disponibles hors
        connexion.
      </Text>
      <View style={S.card}>
        <Text style={S.label}>Nom</Text>
        <TextInput
          style={S.input}
          value={name}
          onChangeText={setName}
          placeholder="Ex. Solutions Pro"
        />
        <Text style={S.label}>Description</Text>
        <TextInput
          style={[S.input, { minHeight: 80, textAlignVertical: 'top' }]}
          value={description}
          onChangeText={setDescription}
          multiline
        />
        <Text style={S.label}>Style</Text>
        <TextInput style={S.input} value={style} onChangeText={setStyle} />
        <Pressable
          style={S.button}
          disabled={busy}
          onPress={async () => {
            if (!name.trim()) {
              Alert.alert('Nom requis', 'Donnez un nom à votre IA.');
              return;
            }
            setBusy(true);
            try {
              await onCreated(
                blankAI(name.trim(), description.trim(), style)
              );
            } finally {
              setBusy(false);
            }
          }}
        >
          <Text style={S.buttonText}>
            {busy ? 'Création…' : 'Commencer'}
          </Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

function AIs({
  ais,
  open,
  remove,
}: {
  ais: AI[];
  open: (ai: AI) => void;
  remove: (id: string) => Promise<void>;
}) {
  return (
    <FlatList
      data={ais}
      keyExtractor={(item) => item.id}
      ListHeaderComponent={
        <>
          <Text style={S.title}>Mes IA</Text>
          <Text style={S.muted}>{ais.length} IA enregistrée(s).</Text>
        </>
      }
      ListEmptyComponent={
        <View style={S.card}>
          <Text style={S.muted}>Aucune IA pour le moment.</Text>
        </View>
      }
      renderItem={({ item }) => (
        <Pressable style={S.card} onPress={() => open(item)}>
          <Text style={{ fontWeight: '800' }}>{item.name}</Text>
          <Text style={S.muted}>
            {item.description || 'Pas encore de description.'}
          </Text>
          <Pressable
            style={[S.button, { backgroundColor: '#e9e9e4' }]}
            onPress={() =>
              Alert.alert('Supprimer ?', `Supprimer ${item.name} ?`, [
                { text: 'Annuler' },
                {
                  text: 'Supprimer',
                  style: 'destructive',
                  onPress: () => void remove(item.id),
                },
              ])
            }
          >
            <Text style={{ fontWeight: '800' }}>Supprimer</Text>
          </Pressable>
        </Pressable>
      )}
    />
  );
}

function Account({ model }: { model: ModelStatus }) {
  return (
    <ScrollView>
      <Text style={S.title}>Compte & moteurs</Text>
      <View style={S.card}>
        <Text style={{ fontWeight: '800' }}>Moteurs locaux</Text>
        <Text style={S.muted}>
          LLM : {model.llmReady ? 'prêt' : 'vérification en cours'}
        </Text>
        <Text style={S.muted}>
          Embeddings :{' '}
          {model.embeddingReady ? 'prêt' : 'vérification en cours'}
        </Text>
        <Text style={[S.muted, { marginTop: 10 }]}>
          Les deux modèles sont intégrés au paquet de l’application. Aucun
          téléchargement n’est nécessaire après l’installation.
        </Text>
      </View>
    </ScrollView>
  );
}

function Chat({
  ai,
  model,
  back,
}: {
  ai: AI;
  model: ModelStatus;
  back: () => void;
}) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void getChat(ai.id).then(setMessages);
  }, [ai.id]);

  const send = async () => {
    const text = draft.trim();
    if (!text || busy) return;

    const userMsg: Message = {
      id: makeId(),
      role: 'user',
      text,
      ts: Date.now(),
    };
    const next = [...messages, userMsg];
    setMessages(next);
    setDraft('');
    setBusy(true);

    try {
      if (!VanelleNative) {
        throw new Error('Moteur natif indisponible.');
      }
      if (!model.llmReady) {
        throw new Error('Le modèle local est encore en préparation.');
      }

      const response = await VanelleNative.chat(
        JSON.stringify({
          systemPrompt: ai.systemPrompt,
          messages: next.map((m) => ({ role: m.role, content: m.text })),
          maxTokens: ai.maxTokens,
          temperature: ai.temperature,
        })
      );

      const botMsg: Message = {
        id: makeId(),
        role: 'assistant',
        text: response.text || 'Réponse vide.',
        ts: Date.now(),
      };
      const all = [...next, botMsg];
      setMessages(all);
      await saveChat(ai.id, all);
    } catch (e) {
      const botMsg: Message = {
        id: makeId(),
        role: 'assistant',
        text:
          e instanceof Error ? e.message : 'Échec du moteur IA.',
        ts: Date.now(),
      };
      const all = [...next, botMsg];
      setMessages(all);
      await saveChat(ai.id, all);
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={S.root}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={S.header}>
        <View style={[S.row, { justifyContent: 'space-between' }]}>
          <Pressable onPress={back}>
            <Text style={{ color: '#fff', fontWeight: '800' }}>‹ Retour</Text>
          </Pressable>
          <Text style={S.brand}>{ai.name}</Text>
          <Text
            style={{
              color: model.llmReady ? '#b7f36b' : '#aaa',
              fontSize: 10,
            }}
          >
            {model.llmReady ? 'PRÊT' : 'PRÉPARATION'}
          </Text>
        </View>
      </View>
      <FlatList
        style={S.chat}
        data={messages}
        keyExtractor={(m) => m.id}
        ListEmptyComponent={
          <View style={[S.bubble, S.bot]}>
            <Text style={S.bubbleText}>
              Bonjour, je suis {ai.name}. Posez votre question.
            </Text>
          </View>
        }
        renderItem={({ item }) => (
          <View
            style={[S.bubble, item.role === 'user' ? S.user : S.bot]}
          >
            <Text style={S.bubbleText}>{item.text}</Text>
          </View>
        )}
      />
      <View style={S.composer}>
        <TextInput
          style={[S.input, { flex: 1, maxHeight: 120 }]}
          value={draft}
          onChangeText={setDraft}
          multiline
          placeholder="Écrivez votre message…"
        />
        <Pressable style={S.send} onPress={() => void send()}>
          <Text style={S.sendText}>{busy ? '…' : '➤'}</Text>
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}
