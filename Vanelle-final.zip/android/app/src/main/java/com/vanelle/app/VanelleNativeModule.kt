package com.vanelle.app

import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class VanelleNativeModule(
    private val reactContext: ReactApplicationContext
) : ReactContextBaseJavaModule(reactContext) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val engine = LlamaEngine(reactContext)

    override fun getName(): String = "VanelleNative"

    @ReactMethod
    fun getModelStatus(promise: Promise) {
        try {
            val map = Arguments.createMap()
            map.putBoolean(
                "llmReady",
                ModelAssets.isReady(reactApplicationContext, ModelAssets.LLM)
            )
            map.putBoolean(
                "embeddingReady",
                ModelAssets.isReady(reactApplicationContext, ModelAssets.EMBEDDING)
            )
            promise.resolve(map)
        } catch (e: Exception) {
            promise.reject("STATUS_ERROR", e)
        }
    }

    @ReactMethod
    fun chat(payload: String, promise: Promise) {
        scope.launch {
            try {
                val json = JSONObject(payload)
                val systemPrompt = json.optString("systemPrompt", "").trim()
                val messagesArray = json.optJSONArray("messages") ?: JSONArray()
                val pairs = ArrayList<Pair<String, String>>(messagesArray.length())
                for (i in 0 until messagesArray.length()) {
                    val msg = messagesArray.getJSONObject(i)
                    pairs.add(
                        msg.optString("role", "user") to msg.optString("content", "")
                    )
                }
                val maxTokens = json.optInt("maxTokens", 700).coerceIn(32, 1024)
                val temperature = json.optDouble("temperature", 0.4).toFloat()
                val prompt = engine.buildPrompt(pairs, systemPrompt.ifEmpty { null })
                val text = engine.generate(prompt, maxTokens, temperature)
                val result = Arguments.createMap()
                result.putString("text", text)
                promise.resolve(result)
            } catch (e: Exception) {
                promise.reject("CHAT_ERROR", e.message, e)
            }
        }
    }
}
