# Vanelle — build rapide

## Prérequis
- Node.js >= 22.13
- JDK 17
- Android SDK (API 36/37, Build-Tools)

## Étapes

```bash
# 1. Installer les dépendances JS
npm install --include=dev

# 2. Télécharger les modèles GGUF (~355 Mo, une seule fois)
chmod +x scripts/*.sh android/gradlew
./scripts/prepare-bundled-models.sh

# 3. Vérifier le projet
./scripts/verify-project.sh

# 4. Compiler l'APK debug
cd android
./gradlew :app:assembleDebug --no-daemon --stacktrace

# APK généré :
# android/app/build/outputs/apk/debug/app-debug.apk
```

## Notes
- Les modèles sont embarqués dans l'APK (pas de téléchargement au runtime).
- `prepare-bundled-models.sh` est obligatoire avant le premier build.
- New Architecture + Hermes activés.
