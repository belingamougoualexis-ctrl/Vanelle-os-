# Compiler Vanelle (Android)

```bash
npm install
cd android && ./gradlew assembleDebug
# APK → android/app/build/outputs/apk/debug/app-debug.apk
```

Requirements: Node.js >= 22.13, JDK 17, Android SDK/Build Tools compatible with React Native 0.87.


## Android native build fix (September 2026)

- The Android runtime ABI is restricted to `arm64-v8a` for the supported 64-bit Android devices; the failing `armeabi-v7a` LLAMAFILE FP16 intrinsic path (`vld1q_f16` / `vld1_f16`) is avoided by disabling the optional LLAMAFILE backend.
- `GGML_LLAMAFILE` is explicitly disabled; llama.cpp documents it as an optional CPU BLAS implementation, not a requirement for model inference.
- The GitHub Actions workflow sets the Gradle wrapper executable bit before the first invocation, preventing `./android/gradlew: Permission denied`.
- Deprecated Gradle/AGP switches that forced the legacy Android DSL/Kotlin behavior were removed from `android/gradle.properties`.
