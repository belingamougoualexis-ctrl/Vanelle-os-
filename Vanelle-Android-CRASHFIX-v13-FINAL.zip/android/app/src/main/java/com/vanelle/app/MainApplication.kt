package com.vanelle.app

import android.app.Application
import android.content.Intent
import android.os.Process
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import com.facebook.react.PackageList
import com.facebook.react.ReactApplication
import com.facebook.react.ReactHost
import com.facebook.react.ReactNativeHost
import com.facebook.react.ReactPackage
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.load
import com.facebook.react.defaults.DefaultReactHost.getDefaultReactHost
import com.facebook.react.defaults.DefaultReactNativeHost
import com.facebook.react.soloader.OpenSourceMergedSoMapping
import com.facebook.soloader.SoLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MainApplication : Application(), ReactApplication {

    override val reactNativeHost: ReactNativeHost =
        object : DefaultReactNativeHost(this@MainApplication) {
            override fun getPackages(): List<ReactPackage> =
                PackageList(this).packages.apply {
                    add(VanelleNativePackage())
                }

            override fun getJSMainModuleName(): String = "index"

            override fun getUseDeveloperSupport(): Boolean = BuildConfig.DEBUG

            override val isNewArchEnabled: Boolean =
                BuildConfig.IS_NEW_ARCHITECTURE_ENABLED

            override val isHermesEnabled: Boolean =
                BuildConfig.IS_HERMES_ENABLED
        }

    override val reactHost: ReactHost
        get() = getDefaultReactHost(applicationContext, reactNativeHost)

    override fun onCreate() {
        // Enregistré EN PREMIER, avant toute initialisation native (SoLoader, etc.)
        // pour intercepter même un crash qui arrive avant que React Native démarre.
        installCrashLogger()

        super.onCreate()
        SoLoader.init(this, OpenSourceMergedSoMapping)
        if (BuildConfig.IS_NEW_ARCHITECTURE_ENABLED) {
            load()
        }

        // Les moteurs locaux sont chargés à la demande après le démarrage de l'interface.
        // Cela évite qu'un problème natif ou un modèle défectueux puisse faire
        // quitter l'application immédiatement à l'ouverture.
    }

    /**
     * Filet de sécurité de dernier recours. Si une erreur (même une Error native
     * type UnsatisfiedLinkError/OutOfMemoryError survenant avant que React Native
     * ait pu démarrer) fait planter l'app, on lance un écran 100% natif — sans
     * aucune dépendance à React Native/JS — qui affiche le rapport et permet de
     * le partager (SMS, mail, WhatsApp...). Sans ça, un crash à l'écran de
     * démarrage ne laisse aucune trace consultable par l'utilisateur, puisque
     * le stockage privé de l'app n'est accessible ni sans ordinateur ni sans
     * root.
     *
     * L'écran de rapport tourne dans un process séparé (":crashreport") pour
     * ne pas être affecté par ce qui vient de casser le process principal.
     */
    private fun installCrashLogger() {
        val appContext = this
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val report = "Vanelle — rapport de crash\n" +
                    "Thread: ${thread.name}\n" +
                    "Appareil: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\n" +
                    "Android: ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})\n\n" +
                    sw.toString()

                Log.e("VanelleCrash", "Uncaught exception on thread ${thread.name}", throwable)
                try {
                    File(filesDir, "last_crash.txt").writeText(report)
                } catch (_: Throwable) { /* stockage indisponible, tant pis */ }

                val intent = Intent(appContext, CrashReportActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    putExtra(CrashReportActivity.EXTRA_REPORT, report)
                }
                appContext.startActivity(intent)
            } catch (_: Throwable) {
                // Ne jamais laisser le logger de crash lui-même planter davantage.
            } finally {
                Process.killProcess(Process.myPid())
            }
        }
    }
}
