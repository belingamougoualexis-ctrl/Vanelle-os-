package com.vanelle.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Process
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Écran de secours entièrement natif (aucune dépendance à React Native ou au
 * bundle JS). Il est lancé directement par le crash handler global de
 * MainApplication, donc il s'affiche MÊME SI le crash empêche React Native
 * de démarrer (par ex. un crash pendant SoLoader.init()).
 *
 * Sans cet écran, un crash à l'écran de démarrage ne laisse aucune trace
 * consultable par l'utilisateur : le stockage privé de l'app n'est pas
 * accessible sans ordinateur/adb.
 */
class CrashReportActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val report = intent.getStringExtra(EXTRA_REPORT).orEmpty()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#17171a"))
            setPadding(32, 64, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Vanelle a rencontré un problème"
            setTextColor(Color.WHITE)
            textSize = 20f
            setPadding(0, 0, 0, 16)
        }

        val subtitle = TextView(this).apply {
            text = "Copiez ou partagez ce rapport pour obtenir de l'aide."
            setTextColor(Color.parseColor("#a0a0a8"))
            textSize = 14f
            setPadding(0, 0, 0, 24)
        }

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        val reportText = TextView(this).apply {
            text = report
            setTextColor(Color.parseColor("#d0d0d5"))
            textSize = 12f
            setTextIsSelectable(true)
        }
        scroll.addView(reportText)

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, 24, 0, 0)
        }

        val shareButton = Button(this).apply {
            text = "Partager"
            setOnClickListener {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Rapport de crash Vanelle")
                    putExtra(Intent.EXTRA_TEXT, report)
                }
                startActivity(Intent.createChooser(sendIntent, "Partager le rapport"))
            }
        }

        val closeButton = Button(this).apply {
            text = "Fermer"
            setOnClickListener {
                finish()
                Process.killProcess(Process.myPid())
            }
        }

        buttonRow.addView(closeButton)
        buttonRow.addView(shareButton)

        root.addView(title)
        root.addView(subtitle)
        root.addView(scroll)
        root.addView(buttonRow)

        setContentView(root)
    }

    companion object {
        const val EXTRA_REPORT = "report"
    }
}
