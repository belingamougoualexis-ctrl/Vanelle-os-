package com.vanelle.app

import android.content.Intent
import android.net.Uri
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import java.security.SecureRandom
import java.security.MessageDigest
import android.util.Base64
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject

class VanelleNativeModule(private val reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Toutes les dépendances lourdes sont lazy : leur initialisation ne doit pas
    // pouvoir faire échouer le démarrage de l'application.
    private val engine: LlamaEngine by lazy { EngineHolder.get(reactContext) }
    private val embeddingEngine: EmbeddingEngine by lazy { EmbeddingHolder.get(reactContext) }
    private val vault: ApiSecretVault by lazy { ApiSecretVault(reactContext) }
    private val transport: UniversalApiTransport by lazy { UniversalApiTransport(vault) }

    override fun getName(): String = "VanelleNative"

    @ReactMethod fun getModelStatus(promise: Promise) {
        try {
            val map = Arguments.createMap()
            map.putBoolean("llmInstalled", ModelAssets.isReady(reactApplicationContext, ModelAssets.LLM))
            // IMPORTANT: status checks must not instantiate LlamaHelper/embedding JNI.
            // A startup health check must be side-effect free.
            val existingEngine = EngineHolder.peek()
            val existingEmbedding = EmbeddingHolder.peek()
            map.putBoolean("llmLoaded", existingEngine?.ready == true)
            map.putBoolean("embeddingReady", ModelAssets.isReady(reactApplicationContext, ModelAssets.EMBEDDING))
            map.putBoolean("embeddingLoaded", existingEmbedding?.isLoaded == true)
            map.putBoolean("llmReady", existingEngine?.ready == true)
            promise.resolve(map)
        } catch (e: Throwable) { promise.reject("STATUS_ERROR", e) }
    }
    @ReactMethod fun preloadModel(promise: Promise) { scope.launch { try { engine.ensureLoaded(); promise.resolve(true) } catch (e: Throwable) { promise.reject("PRELOAD_ERROR", e.message, e) } } }
    @ReactMethod fun chat(payload: String, promise: Promise) { scope.launch { try {
        val json = JSONObject(payload); val systemPrompt = json.optString("systemPrompt", "").trim(); val arr = json.optJSONArray("messages") ?: JSONArray()
        val pairs = ArrayList<Pair<String,String>>(arr.length())
        for (i in 0 until arr.length()) { val m=arr.getJSONObject(i); pairs.add(m.optString("role","user") to m.optString("content","")) }
        val maxTokens=json.optInt("maxTokens",700).coerceIn(32,1024); val temperature=json.optDouble("temperature",0.4).toFloat()
        val text=engine.generate(engine.buildPrompt(pairs, systemPrompt.ifEmpty { null }), maxTokens, temperature)
        promise.resolve(Arguments.createMap().apply { putString("text", text) })
    } catch(e:Throwable){ promise.reject("CHAT_ERROR", e.message, e) } } }

    @ReactMethod fun preloadEmbedding(promise: Promise) {
        scope.launch {
            try {
                embeddingEngine.ensureLoaded()
                promise.resolve(true)
            } catch (e: Throwable) {
                promise.reject("EMBEDDING_PRELOAD_ERROR", e.message, e)
            }
        }
    }

    @ReactMethod fun embeddingDimension(promise: Promise) {
        scope.launch {
            try {
                promise.resolve(embeddingEngine.dimension())
            } catch (e: Throwable) {
                promise.reject("EMBEDDING_DIMENSION_ERROR", e.message, e)
            }
        }
    }

    @ReactMethod fun embedText(text: String, mode: String?, promise: Promise) {
        scope.launch {
            try {
                val vector = when (mode?.lowercase()) {
                    "document", "search_document" -> embeddingEngine.embedDocument(text)
                    else -> embeddingEngine.embedQuery(text)
                }
                val out = Arguments.createArray()
                vector.forEach { out.pushDouble(it.toDouble()) }
                promise.resolve(out)
            } catch (e: Throwable) {
                promise.reject("EMBEDDING_ERROR", e.message, e)
            }
        }
    }


    @ReactMethod fun vaultPut(ref: String, secret: String, promise: Promise) { try { vault.put(ref, secret); promise.resolve(true) } catch(e:Throwable){ promise.reject("VAULT_PUT",e.message,e) } }
    @ReactMethod fun vaultDelete(ref: String, promise: Promise) { try { vault.remove(ref); promise.resolve(true) } catch(e:Throwable){ promise.reject("VAULT_DELETE",e.message,e) } }
    @ReactMethod fun vaultHas(ref: String, promise: Promise) { promise.resolve(vault.get(ref) != null) }

    @ReactMethod fun secureApiRequest(url:String, method:String, headersJson:String, bodyBase64:String?, secretRef:String?, authType:String?, authHeader:String?, username:String?, promise:Promise) {
        scope.launch { try {
            val headers=mutableMapOf<String,String>(); val h=JSONObject(headersJson.ifBlank { "{}" }); h.keys().forEach { k -> headers[k]=h.getString(k) }
            val secret=secretRef?.takeIf { it.isNotBlank() }?.let { vault.get(it) }
            when(authType) {
                "apiKey" -> {
                    if (secret == null) error("Clé API introuvable dans le coffre sécurisé.")
                    headers[authHeader?.ifBlank { "X-API-Key" } ?: "X-API-Key"] = secret
                }
                "bearer" -> {
                    if (secret == null) error("Token Bearer introuvable dans le coffre sécurisé.")
                    headers["Authorization"] = "Bearer $secret"
                }
                "basic" -> {
                    if (secret == null) error("Mot de passe Basic introuvable dans le coffre sécurisé.")
                    headers["Authorization"] = "Basic "+Base64.encodeToString("${username.orEmpty()}:$secret".toByteArray(),Base64.NO_WRAP)
                }
            }
            val bytes=bodyBase64?.takeIf { it.isNotEmpty() }?.let { Base64.decode(it,Base64.NO_WRAP) }
            val (status,responseHeaders,responseBody)=transport.request(method,url,headers,bytes,headers.entries.firstOrNull { it.key.equals("Content-Type",true) }?.value,20_000)
            val out=Arguments.createMap(); out.putInt("status",status); out.putMap("headers",Arguments.createMap().apply { responseHeaders.forEach { (k,v)->putString(k,v) } }); out.putString("bodyBase64",Base64.encodeToString(responseBody,Base64.NO_WRAP)); promise.resolve(out)
        } catch(e:Throwable){ promise.reject("API_REQUEST",e.message,e) } }
    }

    @ReactMethod fun importMtlsIdentity(ref:String, pkcs12Base64:String, password:String, promise:Promise){ try { vault.put("mtls:$ref", JSONObject().apply { put("p12",pkcs12Base64); put("password",password) }.toString()); promise.resolve(true) } catch(e:Throwable){ promise.reject("MTLS_IMPORT",e.message,e) } }
    @ReactMethod fun deleteMtlsIdentity(ref:String,promise:Promise){ try { vault.remove("mtls:$ref"); promise.resolve(true) } catch(e:Throwable){ promise.reject("MTLS_DELETE",e.message,e) } }

    @ReactMethod fun mtlsRequest(ref:String,url:String,method:String,headersJson:String,bodyBase64:String?,promise:Promise){ scope.launch { try { val headers=parseHeaders(headersJson); val body=bodyBase64?.let{Base64.decode(it,Base64.NO_WRAP)}; val (status,rh,rb)=transport.mtlsRequest(ref,method,url,headers,body,headers.entries.firstOrNull{it.key.equals("Content-Type",true)}?.value); val out=Arguments.createMap(); out.putInt("status",status); out.putMap("headers",Arguments.createMap().apply{rh.forEach{(k,v)->putString(k,v)}}); out.putString("bodyBase64",Base64.encodeToString(rb,Base64.NO_WRAP)); promise.resolve(out) } catch(e:Throwable){ promise.reject("MTLS_REQUEST",e.message,e) } } }

    @ReactMethod fun openWebSocket(id:String,url:String,headersJson:String,promise:Promise) {
        try { val headers=parseHeaders(headersJson); transport.openWebSocket(id,url,headers,object:WebSocketListener(){
            override fun onOpen(ws:okhttp3.WebSocket,response:okhttp3.Response){ emit("vanelle.websocket.open", mapOf("id" to id)) }
            override fun onMessage(ws:okhttp3.WebSocket,text:String){ emit("vanelle.websocket.message", mapOf("id" to id,"text" to text)) }
            override fun onMessage(ws:okhttp3.WebSocket,bytes:ByteString){ emit("vanelle.websocket.binary", mapOf("id" to id,"base64" to Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP))) }
            override fun onClosing(ws:okhttp3.WebSocket,code:Int,reason:String){ emit("vanelle.websocket.closing", mapOf("id" to id,"code" to code,"reason" to reason)) }
            override fun onFailure(ws:okhttp3.WebSocket,t:Throwable,response:okhttp3.Response?){ emit("vanelle.websocket.error", mapOf("id" to id,"error" to (t.message ?: "WebSocket error"))) }
        }); promise.resolve(true) } catch(e:Throwable){ promise.reject("WEBSOCKET",e.message,e) }
    }
    @ReactMethod fun sendWebSocket(id:String,text:String?,base64:String?,promise:Promise){ promise.resolve(transport.sendWebSocket(id,text,base64)) }
    @ReactMethod fun readWebSocketEvents(id:String,max:Int,promise:Promise){ promise.resolve(Arguments.fromList(transport.readEvents(id,max))) }
    @ReactMethod fun closeWebSocket(id:String){ transport.closeWebSocket(id) }

    @ReactMethod fun openSse(id:String,url:String,headersJson:String,promise:Promise){ try { transport.openSse(id,url,parseHeaders(headersJson),{ data->emit("vanelle.sse.event",mapOf("id" to id,"data" to data))},{ e->emit("vanelle.sse.error",mapOf("id" to id,"error" to (e.message ?: "SSE error"))) }); promise.resolve(true) } catch(e:Throwable){ promise.reject("SSE",e.message,e) } }
    @ReactMethod fun readSseEvents(id:String,max:Int,promise:Promise){ promise.resolve(Arguments.fromList(transport.readSseEvents(id,max))) }
    @ReactMethod fun closeSse(id:String){ transport.closeSse(id) }

    private fun parseHeaders(json:String):Map<String,String>{ val out=mutableMapOf<String,String>(); val o=JSONObject(json.ifBlank { "{}" }); o.keys().forEach { k->out[k]=o.getString(k) }; return out }
    private fun emit(event:String,data:Map<String,Any>){
        val map=Arguments.createMap(); data.forEach { (k,v) -> when(v){ is String->map.putString(k,v); is Int->map.putInt(k,v); is Boolean->map.putBoolean(k,v) } }
        reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java).emit(event,map)
    }

    @ReactMethod fun createPkceVerifier(promise:Promise){ try { val b=ByteArray(64); SecureRandom().nextBytes(b); promise.resolve(Base64.encodeToString(b,Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)) } catch(e:Throwable){promise.reject("PKCE",e.message,e)} }
    @ReactMethod fun pkceChallenge(verifier:String,promise:Promise){ try { val d=MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray()); promise.resolve(Base64.encodeToString(d,Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)) } catch(e:Throwable){promise.reject("PKCE",e.message,e)} }
    @ReactMethod fun signHmac(secretRef:String, algorithm:String, canonical:String, promise:Promise){ try { val secret=vault.get(secretRef) ?: error("Secret de signature introuvable."); val mac=Mac.getInstance(if(algorithm.equals("hmac-sha512",true))"HmacSHA512" else "HmacSHA256"); mac.init(SecretKeySpec(secret.toByteArray(),mac.algorithm)); promise.resolve(Base64.encodeToString(mac.doFinal(canonical.toByteArray()),Base64.NO_WRAP)) } catch(e:Throwable){ promise.reject("SIGNATURE",e.message,e) } }
    @ReactMethod fun startOAuth(authorizationUrl:String,promise:Promise){ try { val i=Intent(Intent.ACTION_VIEW,Uri.parse(authorizationUrl)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); reactContext.startActivity(i); promise.resolve(true) } catch(e:Throwable){ promise.reject("OAUTH_BROWSER",e.message,e) } }

    @ReactMethod fun multipartRequest(url:String,headersJson:String,fieldsJson:String,filesJson:String,promise:Promise){ scope.launch { try { val fields=mutableMapOf<String,String>(); val f=JSONObject(fieldsJson.ifBlank{"{}"}); f.keys().forEach{fields[it]=f.getString(it)}; val files=mutableListOf<Triple<String,String,ByteArray>>(); val a=JSONArray(filesJson.ifBlank{"[]"}); for(i in 0 until a.length()){val x=a.getJSONObject(i); files.add(Triple(x.getString("name"),x.getString("filename"),Base64.decode(x.getString("base64"),Base64.NO_WRAP)))}; val(status,rh,rb)=transport.multipart(url,parseHeaders(headersJson),fields,files); val out=Arguments.createMap(); out.putInt("status",status); out.putMap("headers",Arguments.createMap().apply{rh.forEach{(k,v)->putString(k,v)}}); out.putString("bodyBase64",Base64.encodeToString(rb,Base64.NO_WRAP)); promise.resolve(out) } catch(e:Throwable){promise.reject("MULTIPART",e.message,e)} } }

    fun handleIntent(intent: Intent?) { val uri=intent?.data ?: return; emit("vanelle.oauth.redirect",mapOf("url" to uri.toString())) }
}
