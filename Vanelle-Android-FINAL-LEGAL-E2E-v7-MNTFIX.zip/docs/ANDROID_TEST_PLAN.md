# Vanelle — test fonctionnel Android

Le workflow construit, signe puis installe l'APK sur un émulateur Android propre.

## Exemple de fonctionnement attendu

1. **Ouverture**
   - Vanelle démarre sans fermeture immédiate.
   - L'écran affiche `VANELLE`.
   - Les onglets `Créer`, `Mes IA`, `Tableau` et `Compte` sont accessibles.

2. **Créer**
   - Saisir `TestVanelle`.
   - Saisir une description.
   - Appuyer sur `Commencer l'apprentissage`.
   - La fiche de l'IA doit s'ouvrir.

3. **Apprentissage**
   - Ouvrir `Apprentissage`.
   - Ajouter une notion de test.
   - L'application doit rester vivante et conserver la notion.

4. **Fichiers**
   - Ouvrir `Fichiers`.
   - `Uploader un fichier` doit ouvrir le sélecteur Android.
   - Annuler le sélecteur ne doit pas faire planter Vanelle.

5. **API**
   - Ouvrir `API`.
   - Les champs de configuration, les méthodes/protocoles et `Ajouter l'API`/`Tester` doivent être accessibles.
   - Le smoke test ne dépend pas d'un serveur Internet externe.

6. **Chat**
   - Ouvrir `Chat`.
   - Le champ `Écrivez votre message…` et le bouton d'envoi doivent être présents.
   - Le test CI ne force pas l'inférence Llama sur un émulateur à faible RAM : cela mesure la capacité du modèle, pas la stabilité du démarrage.

7. **Persistance**
   - Revenir à `Mes IA`.
   - `TestVanelle` doit toujours être présent.

8. **Tableau de bord**
   - Les compteurs doivent être affichés.
   - Le nombre d'IA et de notions doit refléter les données créées.

9. **Compte**
   - Profil, sauvegarde, export et import doivent être accessibles.

## Critère d'échec

Le test échoue si :

- l'APK ne s'installe pas ;
- Vanelle ne démarre pas ;
- le processus `com.vanelle.app` meurt ;
- un `FATAL EXCEPTION`, `SIGSEGV`, `SIGABRT`, `UnsatisfiedLinkError`, `Unable to start activity` ou autre signature critique apparaît dans logcat ;
- un écran attendu ou une fonction principale de l'interface est introuvable.

## Limite volontaire

Le CI ne prétend pas valider une réponse intelligente exacte de Llama. Une vraie validation de l'inférence locale nécessite un appareil/émulateur disposant de suffisamment de RAM et le modèle embarqué. Le test de démarrage et des fonctions de l'interface, lui, est automatique.


## Mandatory legal consent

On a clean first launch, Vanelle must display the Privacy Policy and Terms of Use.
Both acceptance boxes are mandatory and the Continue button is only usable after both are checked.
After acceptance, the consent version is stored locally. The legal documents remain accessible from Account.
