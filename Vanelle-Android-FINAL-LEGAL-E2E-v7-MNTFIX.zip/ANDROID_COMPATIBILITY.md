# VanelleOS — compatibilité Android

- Minimum Android : API 24 (Android 7.0).
- Architectures natives : `armeabi-v7a`, `arm64-v8a`, `x86`, `x86_64`.
- NDK : 29.0.14206865.
- Native C/C++ : llama.cpp + bridge JNI.
- Les modèles GGUF sont embarqués dans l'application ; aucun téléchargement de modèle n'est nécessaire au démarrage.
- Le moteur Llama et le moteur d'embeddings sont créés à la demande.
- Le build de test vérifie les quatre ABI et l'alignement ZIP 16 KiB.

## Limite matérielle

La compatibilité OS/ABI ne signifie pas que l'IA locale sera rapide sur un téléphone très faible en RAM/CPU. L'application doit toutefois pouvoir démarrer sans charger le modèle Llama. Les fonctions IA locales peuvent ensuite être limitées par les ressources disponibles.
