#!/usr/bin/env bash
set -euo pipefail

APK="${1:?APK path required}"
LOG_DIR="${2:-android-test-results}"
PACKAGE="com.vanelle.app"
ACTIVITY=".MainActivity"

mkdir -p "$LOG_DIR"

echo "=== VANELLE ANDROID END-TO-END SMOKE TEST ==="
echo "APK=$APK"
echo "PACKAGE=$PACKAGE"

adb wait-for-device

# Fresh installation: eliminates stale cache/data as a cause.
adb shell am force-stop "$PACKAGE" >/dev/null 2>&1 || true
adb uninstall "$PACKAGE" >/dev/null 2>&1 || true
adb install "$APK"

echo "Installation: OK"

# ---------- Helpers ----------
dump_ui() {
  adb shell uiautomator dump /sdcard/window.xml >/dev/null 2>&1 || true
  adb exec-out cat /sdcard/window.xml 2>/dev/null > "$LOG_DIR/window.xml" || true
}

find_node_bounds() {
  local wanted="$1"
  dump_ui
  python3 - "$LOG_DIR/window.xml" "$wanted" <<'PY'
import sys
import xml.etree.ElementTree as ET

path, wanted = sys.argv[1], sys.argv[2]
try:
    root = ET.parse(path).getroot()
except Exception:
    raise SystemExit(1)

for n in root.iter("node"):
    text = n.attrib.get("text", "")
    desc = n.attrib.get("content-desc", "")
    if text == wanted or wanted in text or desc == wanted or wanted in desc:
        b = n.attrib.get("bounds", "")
        if b:
            print(b)
            raise SystemExit(0)
raise SystemExit(1)
PY
}

bounds_to_xy() {
  python3 - "$1" <<'PY'
import re, sys
m = re.match(r'\[(\d+),(\d+)\]\[(\d+),(\d+)\]', sys.argv[1])
if not m:
    raise SystemExit(1)
x1,y1,x2,y2 = map(int, m.groups())
print((x1+x2)//2, (y1+y2)//2)
PY
}

tap_text() {
  local wanted="$1"
  local bounds
  bounds="$(find_node_bounds "$wanted" || true)"
  if [ -z "$bounds" ]; then
    echo "ERROR: UI element not found: $wanted"
    dump_ui
    exit 1
  fi
  read -r x y < <(bounds_to_xy "$bounds")
  adb shell input tap "$x" "$y"
  sleep 1
}

assert_text() {
  local wanted="$1"
  if ! find_node_bounds "$wanted" >/dev/null 2>&1; then
    echo "ERROR: expected UI text missing: $wanted"
    dump_ui
    exit 1
  fi
  echo "  PASS: $wanted"
}

tap_first_edittext() {
  dump_ui
  local bounds
  bounds="$(python3 - "$LOG_DIR/window.xml" <<'PY'
import sys, xml.etree.ElementTree as ET
root=ET.parse(sys.argv[1]).getroot()
for n in root.iter("node"):
    if n.attrib.get("class") == "android.widget.EditText":
        b=n.attrib.get("bounds","")
        if b:
            print(b)
            raise SystemExit(0)
raise SystemExit(1)
PY
  )"
  if [ -z "$bounds" ]; then
    echo "ERROR: no editable field found"
    exit 1
  fi
  read -r x y < <(bounds_to_xy "$bounds")
  adb shell input tap "$x" "$y"
}

type_text() {
  # adb input text needs spaces encoded as %s.
  local value="$1"
  value="${value// /%s}"
  adb shell input text "$value"
  sleep 0.5
}

check_alive() {
  local label="$1"
  local pid
  pid="$(adb shell pidof "$PACKAGE" | tr -d '\r' || true)"
  if [ -z "$pid" ]; then
    echo "ERROR: Vanelle process died during: $label"
    adb logcat -d -v threadtime > "$LOG_DIR/logcat-${label// /_}.txt" || true
    exit 1
  fi
  echo "  process alive: $pid"
}

check_crash_logs() {
  local label="$1"
  adb logcat -d -v threadtime > "$LOG_DIR/logcat-${label// /_}.txt" || true
  if grep -Eiq \
    'FATAL EXCEPTION|Fatal signal|SIGSEGV|SIGABRT|UnsatisfiedLinkError|NoSuchMethodError|ClassNotFoundException|Unable to start activity|Process .* has died' \
    "$LOG_DIR/logcat-${label// /_}.txt"; then
    echo "ERROR: crash signature detected: $label"
    tail -n 300 "$LOG_DIR/logcat-${label// /_}.txt" || true
    exit 1
  fi
}

# ---------- 1. Clean launch ----------
echo "1/9 — Launch"
adb shell pm clear "$PACKAGE" >/dev/null 2>&1 || true
adb shell am force-stop "$PACKAGE" || true
adb shell am start -n "$PACKAGE/$ACTIVITY"
sleep 8
check_alive "startup"
check_crash_logs "startup"

# Mandatory legal consent on clean first launch.
if find_node_bounds "Avant de commencer" >/dev/null 2>&1; then
  echo "  PASS: mandatory legal consent screen displayed"
  assert_text "Politique de confidentialité"
  assert_text "Conditions d'utilisation"
  assert_text "J'accepte la Politique de confidentialité"
  assert_text "J'accepte les Conditions d'utilisation"
  assert_text "Accepter et continuer"

  tap_text "J'accepte la Politique de confidentialité"
  tap_text "J'accepte les Conditions d'utilisation"
  tap_text "Accepter et continuer"
  sleep 3

  check_alive "after_legal_consent"
  check_crash_logs "after_legal_consent"
fi

assert_text "VANELLE"
assert_text "Créer"
assert_text "Mes IA"
assert_text "Tableau"
assert_text "Compte"

# ---------- 2. Main navigation ----------
echo "2/9 — Navigation principale"
tap_text "Mes IA"
assert_text "Mes IA"
tap_text "Tableau"
assert_text "Tableau de bord"
tap_text "Compte"
assert_text "Compte"
tap_text "Créer"
assert_text "Créer une nouvelle IA"
check_alive "navigation"

# ---------- 3. Create an AI ----------
echo "3/9 — Création d'une IA"
# Name
tap_first_edittext
type_text "TestVanelle"
adb shell input keyevent 61
type_text "Assistant de test Vanelle"
adb shell input keyevent 61
sleep 1
assert_text "Commencer l'apprentissage"
tap_text "Commencer l'apprentissage"
sleep 2
check_alive "creation"
assert_text "TestVanelle"

# ---------- 4. AI detail / persistence ----------
echo "4/9 — Fiche IA"
assert_text "Vue d'ensemble"
assert_text "Apprentissage"
assert_text "Fichiers"
assert_text "API"
assert_text "Chat"

# Exercise persistence/deployment actions on the overview.
assert_text "Enregistrer la fiche"
tap_text "Enregistrer la fiche"
sleep 1
assert_text "Enregistrer la personnalité"
tap_text "Enregistrer la personnalité"
sleep 1
assert_text "Marquer déployée"
tap_text "Marquer déployée"
sleep 1
check_alive "overview_actions"

tap_text "Apprentissage"
assert_text "Apprentissage"
assert_text "Ajouter la notion"

# Add a training notion: first editable field on this tab.
tap_first_edittext
type_text "Question de test"
adb shell input keyevent 61
type_text "Reponse attendue"
tap_text "Ajouter la notion"
sleep 1
check_alive "training"

# Files: open picker and cancel; verifies the Android document provider path
# without requiring a real external file in CI.
tap_text "Fichiers"
assert_text "Uploader un fichier"
tap_text "Uploader un fichier"
sleep 2
adb shell input keyevent 4
sleep 1
check_alive "file_picker"

# API screen: configure a harmless HTTPS endpoint, save it, then exercise
# the Tester action. A network error is acceptable; a crash is not.
tap_text "API"
assert_text "Connecter une API"
assert_text "Ajouter l'API"

tap_first_edittext
type_text "API de test"
adb shell input keyevent 61
type_text "https://example.com"
tap_text "Ajouter l'API"
sleep 1
check_alive "api_add"
assert_text "Tester"

tap_text "Tester"
sleep 3
check_alive "api_test"

# ---------- 5. Chat screen ----------
echo "5/9 — Chat"
tap_text "Chat"
assert_text "Écrivez votre message…"
assert_text "➤"
check_alive "chat"

# We deliberately do not force local Llama inference in this smoke test.
# That would turn a low-RAM emulator test into a model-performance test.
# Native model inference is tested separately when a suitable emulator/device
# has enough RAM and the bundled model is available.

# ---------- 6. Return + persistence ----------
echo "6/9 — Retour et persistance"
tap_text "‹ Retour"
tap_text "Mes IA"
assert_text "TestVanelle"
check_alive "persistence"

# ---------- 7. Dashboard ----------
echo "7/9 — Tableau de bord"
tap_text "Tableau"
assert_text "Tableau de bord"
assert_text "IA créées"
assert_text "notions enseignées"
check_alive "dashboard"

# ---------- 8. Account / backup UI ----------
echo "8/9 — Compte"
tap_text "Compte"
assert_text "Profil"
assert_text "Enregistrer"
assert_text "Sauvegarde complète"
assert_text "Exporter toutes mes données"
assert_text "Importer"
check_alive "account"

# ---------- 9. Final crash check ----------
echo "9/9 — Contrôle final"
sleep 2
check_alive "final"
check_crash_logs "final"

echo ""
echo "=============================================="
echo "VANELLE END-TO-END SMOKE TEST : PASS"
echo "Installation       : OK"
echo "Démarrage          : OK"
echo "Navigation         : OK"
echo "Création IA        : OK"
echo "Apprentissage      : OK"
echo "Fichiers/picker    : OK"
echo "Configuration API  : OK"
echo "Chat UI            : OK"
echo "Persistance        : OK"
echo "Tableau de bord    : OK"
echo "Compte/sauvegarde  : OK"
echo "=============================================="
