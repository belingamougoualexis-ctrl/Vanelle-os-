import React, { useState } from 'react';
import { ScrollView, Text, Pressable } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Btn, Card, PageHead, S } from './ui';

export const LEGAL_VERSION = '2026-09-05';
const CONSENT_KEY = '@vanelle/legal-consent';

export async function hasAcceptedLegal(): Promise<boolean> {
  return (await AsyncStorage.getItem(CONSENT_KEY)) === LEGAL_VERSION;
}

export async function saveLegalConsent(): Promise<void> {
  await AsyncStorage.setItem(CONSENT_KEY, LEGAL_VERSION);
}

const PRIVACY = `Vanelle — Politique de confidentialité

Dernière mise à jour : 5 septembre 2026

1. Objet
Cette politique explique comment Vanelle traite les données utilisées par l'application.

2. Données enregistrées sur l'appareil
Dans sa version actuelle, Vanelle conserve principalement sur l'appareil les informations nécessaires à son fonctionnement : profil/pseudo, IA créées, réglages et personnalité des IA, notions d'apprentissage, informations sur les fichiers ajoutés et historiques de conversation.

3. API et services externes
Le fonctionnement local de Vanelle n'exige pas la création d'un compte en ligne. Lorsqu'une fonctionnalité est configurée pour appeler une API externe, les données nécessaires à cette requête peuvent être transmises au service externe concerné. Ce service applique alors sa propre politique de confidentialité.

4. Clés et secrets
Les clés d'API sont destinées à être protégées par le stockage sécurisé Android utilisé par Vanelle. L'utilisateur reste responsable des clés et services qu'il configure.

5. Fichiers et contenus
Les fichiers, textes, notions et conversations ajoutés par l'utilisateur peuvent être conservés localement afin de fournir les fonctions d'apprentissage, de chat, d'export et d'import. L'utilisateur doit disposer des droits nécessaires pour utiliser ces contenus.

6. Export et partage
La fonction de sauvegarde permet à l'utilisateur d'exporter ses données. Une fois un fichier partagé ou envoyé vers un autre service, son traitement dépend de ce service.

7. Suppression
Les données locales peuvent être supprimées depuis les fonctions de l'application ou en supprimant les données de Vanelle depuis les réglages Android. Les données déjà transmises à un service externe dépendent des règles de ce service.

8. Sécurité
Vanelle applique des mesures techniques raisonnables pour protéger les données locales et les secrets. Aucune méthode de stockage ou de transmission ne peut garantir une sécurité absolue.

9. Modifications
Cette politique peut être mise à jour lorsque les fonctionnalités ou les obligations applicables évoluent. Une nouvelle version peut nécessiter une nouvelle acceptation.

10. Contact
Pour toute demande concernant la confidentialité, utilisez le canal de contact officiel indiqué par l'éditeur de Vanelle.`;

const TERMS = `Vanelle — Conditions d'utilisation

Dernière mise à jour : 5 septembre 2026

1. Acceptation
L'utilisation de Vanelle nécessite l'acceptation de ces conditions et de la Politique de confidentialité.

2. Fonctionnement
Vanelle est un atelier permettant de créer, configurer, entraîner et utiliser des assistants IA. Certaines fonctions peuvent fonctionner localement et d'autres peuvent utiliser les API externes configurées par l'utilisateur.

3. Responsabilité de l'utilisateur
Vous êtes responsable des contenus que vous ajoutez, importez, enseignez ou envoyez à une API. Vous devez respecter les lois applicables ainsi que les conditions des services tiers utilisés avec Vanelle.

4. Intelligence artificielle
Les réponses d'une IA peuvent être inexactes, incomplètes ou inadaptées. Vanelle ne doit pas être utilisé comme unique source pour prendre une décision importante nécessitant un avis professionnel. Vérifiez les informations importantes avant de les utiliser.

5. API et services tiers
Lorsque vous configurez une API externe, vous êtes responsable de l'URL, des identifiants, des autorisations et des conditions du fournisseur concerné. Vanelle ne garantit pas la disponibilité ou l'exactitude d'un service tiers.

6. Fichiers et droits
Vous ne devez importer ou transmettre que des contenus que vous êtes autorisé à utiliser. N'utilisez pas Vanelle pour contourner les droits d'auteur, les restrictions d'accès ou les règles d'un service.

7. Sauvegardes
Les sauvegardes et exports sont sous la responsabilité de l'utilisateur. Conservez-les dans un emplacement sûr et ne partagez pas une sauvegarde contenant des secrets ou des informations privées.

8. Disponibilité
Vanelle peut évoluer, être corrigé ou voir certaines fonctions modifiées. Aucune disponibilité permanente ou compatibilité universelle n'est garantie.

9. Utilisation interdite
Vous ne devez pas utiliser Vanelle pour une activité illégale, frauduleuse, dangereuse ou destinée à porter atteinte aux droits d'autrui.

10. Modifications des conditions
Les conditions peuvent être mises à jour. Une modification importante peut entraîner une nouvelle demande d'acceptation.

11. Fin d'utilisation
Vous pouvez cesser d'utiliser Vanelle et supprimer ses données locales à tout moment. Les services externes restent soumis à leurs propres conditions.`;

function LegalDocument({ title, text, onBack }: { title: string; text: string; onBack?: () => void }) {
  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 30 }}>
      <PageHead eyebrow="Informations légales" title={title}>
        Version du 5 septembre 2026.
      </PageHead>
      <Card>
        {text.split('\n').map((line, i) => (
          <Text key={i} style={[i === 0 ? { fontWeight: '900', fontSize: 17 } : S.muted, { marginBottom: 9 }]}>
            {line}
          </Text>
        ))}
      </Card>
      {onBack ? <Btn label="Retour" ghost onPress={onBack} /> : null}
    </ScrollView>
  );
}

export function PrivacyPolicyScreen({ onBack }: { onBack?: () => void }) {
  return <LegalDocument title="Politique de confidentialité" text={PRIVACY} onBack={onBack} />;
}

export function TermsScreen({ onBack }: { onBack?: () => void }) {
  return <LegalDocument title="Conditions d'utilisation" text={TERMS} onBack={onBack} />;
}

export function LegalConsentScreen({ onAccepted }: { onAccepted: () => void }) {
  const [privacy, setPrivacy] = useState(false);
  const [terms, setTerms] = useState(false);
  const [document, setDocument] = useState<'privacy' | 'terms' | null>(null);

  if (document === 'privacy') return <PrivacyPolicyScreen onBack={() => setDocument(null)} />;
  if (document === 'terms') return <TermsScreen onBack={() => setDocument(null)} />;

  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 30 }}>
      <PageHead eyebrow="Bienvenue" title="Avant de commencer">
        Pour utiliser Vanelle, vous devez lire et accepter la Politique de confidentialité et les Conditions d'utilisation.
      </PageHead>

      <Card>
        <Text style={{ fontWeight: '800', fontSize: 16, marginBottom: 8 }}>Vos données</Text>
        <Text style={S.muted}>
          Vanelle conserve principalement vos données sur cet appareil. Certaines fonctions peuvent transmettre des données aux API externes que vous configurez.
        </Text>
      </Card>

      <Pressable style={S.card} onPress={() => setDocument('privacy')}>
        <Text style={{ fontWeight: '800' }}>Politique de confidentialité</Text>
        <Text style={S.muted}>Lire le document ›</Text>
      </Pressable>

      <Pressable style={S.card} onPress={() => setDocument('terms')}>
        <Text style={{ fontWeight: '800' }}>Conditions d'utilisation</Text>
        <Text style={S.muted}>Lire le document ›</Text>
      </Pressable>

      <Pressable style={S.card} onPress={() => setPrivacy(v => !v)}>
        <Text style={{ fontWeight: '700' }}>{privacy ? '☑' : '☐'} J'accepte la Politique de confidentialité</Text>
      </Pressable>

      <Pressable style={S.card} onPress={() => setTerms(v => !v)}>
        <Text style={{ fontWeight: '700' }}>{terms ? '☑' : '☐'} J'accepte les Conditions d'utilisation</Text>
      </Pressable>

      <Btn
        label="Accepter et continuer"
        disabled={!privacy || !terms}
        onPress={async () => {
          await saveLegalConsent();
          onAccepted();
        }}
      />
    </ScrollView>
  );
}
