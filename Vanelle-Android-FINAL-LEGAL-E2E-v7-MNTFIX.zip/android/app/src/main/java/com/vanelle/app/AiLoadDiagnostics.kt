package com.vanelle.app

import android.util.Log

/**
 * Small, side-effect-free diagnostic helper for local AI startup.
 * It never creates or loads an AI engine.
 */
object AiLoadDiagnostics {
    private const val TAG = "VanelleAI"

    fun logAssetStatus(context: android.content.Context) {
        try {
            val llm = ModelAssets.isReady(context, ModelAssets.LLM)
            val embedding = ModelAssets.isReady(context, ModelAssets.EMBEDDING)
            Log.i(TAG, "assets: llmReady=$llm embeddingReady=$embedding")
        } catch (t: Throwable) {
            Log.e(TAG, "asset check failed", t)
        }
    }
}
