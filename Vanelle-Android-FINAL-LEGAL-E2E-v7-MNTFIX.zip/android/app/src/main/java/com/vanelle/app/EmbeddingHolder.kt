package com.vanelle.app

import android.content.Context

/** Process-wide singleton for the local embedding model. */
object EmbeddingHolder {
    @Volatile
    private var instance: EmbeddingEngine? = null

    fun get(context: Context): EmbeddingEngine =
        instance ?: synchronized(this) {
            instance ?: EmbeddingEngine(context.applicationContext).also { instance = it }
        }

    /** Returns the existing engine without constructing the native wrapper. */
    fun peek(): EmbeddingEngine? = instance
}
