package com.vanelle.app

import android.content.Context

/** Process-wide singleton for the local Llama engine. */
object EngineHolder {
    @Volatile
    private var instance: LlamaEngine? = null

    fun get(context: Context): LlamaEngine =
        instance ?: synchronized(this) {
            instance ?: LlamaEngine(context.applicationContext).also { instance = it }
        }

    /**
     * Returns the existing engine without constructing LlamaHelper.
     * This is important for startup diagnostics: merely asking for status
     * must never initialize the native Llama stack.
     */
    fun peek(): LlamaEngine? = instance
}
