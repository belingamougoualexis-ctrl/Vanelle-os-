package com.vanelle.app

import android.content.Intent
import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.fabricEnabled
import com.facebook.react.defaults.DefaultReactActivityDelegate

class MainActivity : ReactActivity() {
    override fun getMainComponentName(): String = "Vanelle"

    override fun createReactActivityDelegate(): ReactActivityDelegate =
        DefaultReactActivityDelegate(this, mainComponentName, fabricEnabled)

    // Le contexte React Native n'est pas garanti d'être prêt dans onCreate().
    // On ne tente donc aucun accès au module natif pendant le boot.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)

        reactInstanceManager.currentReactContext
            ?.getNativeModule(VanelleNativeModule::class.java)
            ?.handleIntent(intent)
    }
}
