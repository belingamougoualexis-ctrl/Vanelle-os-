import { Link } from "@tanstack/react-router";
import { ArrowLeft, BookOpen, Download, EllipsisVertical, Paperclip, RefreshCw, Settings2, Trash2, Wrench } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { cn, fmtSize, uid } from "@/lib/utils";
import { generateReply, newMsg } from "@/lib/vanelle/chat-client";
import { useEngineStore } from "@/lib/vanelle/engine-store";
import { ingestFiles } from "@/lib/vanelle/files";
import { describeEngine } from "@/lib/vanelle/prompt";
import { Secrets } from "@/lib/vanelle/secrets";
import { Store } from "@/lib/vanelle/store";
import type { ChatAttachment, ChatMessage, UserApi, VanelleAI } from "@/lib/vanelle/types";
import { ApiForm, EngineList } from "./engine-list";
import { Button, Input, Label, Modal, Textarea } from "./ui";

const CHAT_ATTACH_MAX = 8 * 1024 * 1024;
const TEXT_CLIP = 12000;

export function ChatPanel({
  ai,
  onAI,
}: {
  ai: VanelleAI;
  onAI: (ai: VanelleAI) => Promise<void>;
}) {
  const localReady = useEngineStore((s) => s.localReady);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [pending, setPending] = useState<ChatAttachment[]>([]);
  const [busy, setBusy] = useState(false);
  const [menu, setMenu] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [enginesOpen, setEnginesOpen] = useState(false);
  const [apiOpen, setApiOpen] = useState(false);
  const [systemDraft, setSystemDraft] = useState(ai.systemPrompt);
  const [descDraft, setDescDraft] = useState(ai.description);
  const [maxTokensDraft, setMaxTokensDraft] = useState(String(ai.maxTokens ?? 700));
  const [tempDraft, setTempDraft] = useState(String(ai.temperature ?? 0.4));
  const [statusMessage, setStatusMessage] = useState("");
  const threadRef = useRef<HTMLDivElement>(null);
  const attachRef = useRef<HTMLInputElement>(null);
  const knowledgeRef = useRef<HTMLInputElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    void Store.getChat(ai.id).then(setMessages);
  }, [ai.id]);

  useEffect(() => {
    setSystemDraft(ai.systemPrompt);
    setDescDraft(ai.description);
    setMaxTokensDraft(String(ai.maxTokens ?? 700));
    setTempDraft(String(ai.temperature ?? 0.4));
  }, [ai.systemPrompt, ai.description, ai.maxTokens, ai.temperature]);

  useEffect(() => {
    const el = threadRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, busy]);

  useEffect(() => {
    if (!menu) return;
    const close = () => setMenu(false);
    const t = window.setTimeout(() => window.addEventListener("click", close), 0);
    return () => {
      window.clearTimeout(t);
      window.removeEventListener("click", close);
    };
  }, [menu]);

  async function persist(next: ChatMessage[]) {
    setMessages(next);
    await Store.saveChat(ai.id, next);
  }

  async function send() {
    const text = draft.trim();
    const attachments = pending.slice();
    if (!text && !attachments.length) return;
    const fresh = (await Store.getAI(ai.id)) || ai;
    const hist = [...messages, newMsg({ who: "user", text, attachments })];
    setDraft("");
    setPending([]);
    if (inputRef.current) inputRef.current.style.height = "auto";
    await persist(hist);
    setBusy(true);
    const placeholder = newMsg({ who: "bot", text: "…" });
    const withPh = [...hist, placeholder];
    setMessages(withPh);
    try {
      const reply = await generateReply({
        ai: fresh,
        history: hist,
        userText: text,
        attachments,
      });
      const bot = newMsg({
        who: "bot",
        text: reply.text,
        usedKnowledge: reply.usedKnowledge,
        usedApis: reply.usedApis,
      });
      await persist([...hist, bot]);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Échec du moteur IA.";
      await persist([...hist, newMsg({ who: "bot", text: msg })]);
    } finally {
      setBusy(false);
    }
  }

  async function onAttach(files: File[]) {
    const next = [...pending];
    for (const file of files) {
      if (file.size > CHAT_ATTACH_MAX) {
        setStatusMessage(`${file.name} dépasse ${fmtSize(CHAT_ATTACH_MAX)}.`);
        continue;
      }
      try {
        if (file.type.startsWith("image/")) {
          const dataUrl = await readDataUrl(file);
          next.push({ id: uid(), kind: "image", name: file.name, mime: file.type, dataUrl });
        } else {
          let content = await file.text();
          if (content.length > TEXT_CLIP) content = content.slice(0, TEXT_CLIP) + "\n[…tronqué]";
          next.push({ id: uid(), kind: "text", name: file.name, content });
        }
      } catch {
        setStatusMessage(`Impossible de lire ${file.name}.`);
      }
    }
    setPending(next);
    if (next.length) setStatusMessage("");
  }

  const engineHint = describeEngine(ai, localReady);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="mb-2 hidden flex-wrap gap-1.5 md:flex">
        <TabLink id={ai.id} tab="vue" label="Vue" />
        <TabLink id={ai.id} tab="apprentissage" label="Apprentissage" />
        <TabLink id={ai.id} tab="fichiers" label="Fichiers" />
        <TabLink id={ai.id} tab="api" label="API" />
        <TabLink id={ai.id} tab="tester" label="Chat" active />
      </div>

      <div className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-[14px] border border-line bg-paper" style={{ paddingTop: "var(--safe-top)" }}>
        <header className="flex shrink-0 items-center gap-3 border-b border-line bg-paper px-4 py-3">
          <Link
            to="/ia/$id"
            params={{ id: ai.id }}
            search={{ tab: "vue" }}
            className="grid size-9 shrink-0 place-items-center rounded-[10px] text-ink-soft hover:bg-mist md:hidden"
            aria-label="Retour"
          >
            <ArrowLeft className="size-5" />
          </Link>
          <div className="min-w-0 flex-1 truncate font-bold text-base">{ai.nom}</div>
          <div className="hidden max-w-[48%] text-right font-display text-[11px] text-ink-soft sm:block">{engineHint}</div>
          <div className="relative">
            <button
              type="button"
              className="grid size-10 place-items-center rounded-[10px] border-[1.5px] border-line bg-paper text-ink hover:bg-mist"
              aria-label="Menu"
              onClick={(e) => {
                e.stopPropagation();
                setMenu((v) => !v);
              }}
            >
              <EllipsisVertical className="size-5" />
            </button>
            {menu ? (
              <div className="absolute top-12 right-0 z-30 flex min-w-[250px] flex-col rounded-xl border border-line bg-paper p-1.5 shadow-[0_16px_40px_rgba(0,0,0,.14)]">
                <MenuItem icon={Settings2} onClick={() => { setMenu(false); setSettingsOpen(true); }}>
                  Paramètres & system prompt
                </MenuItem>
                <MenuItem icon={RefreshCw} onClick={() => { setMenu(false); setEnginesOpen(true); }}>
                  Moteur llama.cpp
                </MenuItem>
                <MenuItem icon={Wrench} onClick={() => { setMenu(false); setApiOpen(true); }}>
                  Ajouter une API métier
                </MenuItem>
                <MenuItem icon={BookOpen} onClick={() => { setMenu(false); knowledgeRef.current?.click(); }}>
                  Ajouter aux connaissances
                </MenuItem>
                <MenuItem
                  icon={RefreshCw}
                  onClick={() => {
                    setMenu(false);
                    void useEngineStore.getState().reloadLocal();
                  }}
                >
                  Revérifier le moteur
                </MenuItem>
                <MenuItem
                  icon={Download}
                  onClick={() => {
                    setMenu(false);
                    void exportAI(ai);
                  }}
                >
                  Exporter l'IA
                </MenuItem>
                <MenuItem
                  icon={Trash2}
                  onClick={() => {
                    setMenu(false);
                    void persist([]);
                  }}
                >
                  Effacer la conversation
                </MenuItem>
              </div>
            ) : null}
            <input
              ref={knowledgeRef}
              type="file"
              className="hidden"
              multiple
              accept=".zip,.txt,.md,.csv,.json,.html,.js,.css,.pdf,application/zip,text/*"
              onChange={(e) => {
                const files = Array.from(e.target.files || []);
                e.target.value = "";
                if (!files.length) return;
                void (async () => {
                  const next = { ...ai, files: [...ai.files] };
                  const r = await ingestFiles(files, next, setStatusMessage);
                  await onAI(next);
                  setStatusMessage(r.added ? `${r.added} fichier(s) ajouté(s) aux connaissances.` : "Aucun fichier ajouté.");
                  if (r.skipped.length) setStatusMessage(r.skipped.join(" "));
                })();
              }}
            />
          </div>
        </header>

        <div ref={threadRef} className="flex min-h-[280px] flex-1 flex-col gap-3.5 overflow-y-auto bg-mist/60 px-5 py-6">
          {statusMessage ? <div className="rounded-lg border border-line bg-paper px-3 py-2 text-xs text-ink-soft">{statusMessage}</div> : null}
          {messages.length === 0 ? (
            <div className="msg-bot max-w-[760px] rounded-[20px] rounded-bl-md bg-mist px-4 py-3.5 text-[15px] leading-relaxed">
              Bonjour, je suis {ai.nom}. Posez votre question — j'utiliserai le system prompt, vos fichiers et vos API.
            </div>
          ) : (
            messages.map((m) => (
              <div
                key={m.id}
                className={cn(
                  "max-w-[min(760px,94%)] rounded-[20px] px-4 py-3.5 text-[15px] leading-relaxed whitespace-pre-wrap",
                  m.who === "user"
                    ? "self-end rounded-br-sm bg-accent text-white"
                    : "self-start rounded-bl-sm bg-paper text-ink shadow-[0_0_0_1px_var(--color-line)]",
                )}
              >
                {m.text === "…" ? (
                  <span className="v-dots" aria-label="Réflexion en cours">
                    <span />
                    <span />
                    <span />
                  </span>
                ) : (
                  m.text
                )}
                {m.attachments?.length ? (
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {m.attachments.map((a) =>
                      a.kind === "image" ? (
                        <img key={a.id} src={a.dataUrl} alt={a.name} className="size-16 rounded-lg object-cover" />
                      ) : (
                        <span key={a.id} className="rounded-lg bg-black/10 px-2 py-1 text-[11px]">
                          {a.name}
                        </span>
                      ),
                    )}
                  </div>
                ) : null}
                {m.who === "bot" && (m.usedKnowledge?.length || m.usedApis?.length) ? (
                  <div className="mt-2 text-[11px] opacity-70">
                    {m.usedKnowledge?.length ? `Sources : ${m.usedKnowledge.map((k) => k.source).join(" · ")}` : null}
                    {m.usedApis?.length ? ` · API : ${m.usedApis.join(", ")}` : null}
                  </div>
                ) : null}
              </div>
            ))
          )}
        </div>

        <div className="v-composer shrink-0 border-t border-line px-4 py-3.5">
          {pending.length ? (
            <div className="mb-2 flex flex-wrap gap-2">
              {pending.map((a) => (
                <span key={a.id} className="flex max-w-[200px] items-center gap-1.5 rounded-[10px] border border-line bg-mist py-1 pr-2 pl-1 text-xs">
                  {a.kind === "image" ? (
                    <img src={a.dataUrl} alt="" className="size-[26px] rounded-md object-cover" />
                  ) : (
                    <span className="pl-1">doc</span>
                  )}
                  <span className="truncate">{a.name}</span>
                  <button type="button" className="text-ink-soft" onClick={() => setPending(pending.filter((x) => x.id !== a.id))}>
                    ×
                  </button>
                </span>
              ))}
            </div>
          ) : null}
          <div className="flex items-end gap-2.5">
            <button
              type="button"
              className="grid size-12 shrink-0 place-items-center rounded-full border-[1.5px] border-line text-accent hover:bg-mist"
              title="Joindre un fichier ou une image"
              onClick={() => attachRef.current?.click()}
            >
              <Paperclip className="size-5" />
            </button>
            <input
              ref={attachRef}
              type="file"
              className="hidden"
              multiple
              accept="image/*,.txt,.md,.csv,.json,.html,.js,.css,.pdf"
              onChange={(e) => {
                const files = Array.from(e.target.files || []);
                e.target.value = "";
                void onAttach(files);
              }}
            />
            <textarea
              ref={inputRef}
              id="chat-input"
              rows={1}
              value={draft}
              placeholder="Envoyez un message…"
              className="max-h-[180px] min-h-12 flex-1 resize-none rounded-[22px] border-[1.5px] border-line px-4 py-3.5 text-[15px] leading-snug focus:border-accent focus:shadow-[0_0_0_3px_var(--color-accent-soft)] focus:outline-none"
              onChange={(e) => {
                setDraft(e.target.value);
                e.target.style.height = "auto";
                e.target.style.height = Math.min(e.target.scrollHeight, 160) + "px";
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  if (!busy) void send();
                }
              }}
            />
            <Button disabled={busy} onClick={() => void send()}>
              Envoyer
            </Button>
          </div>
        </div>
      </div>

      <Modal open={settingsOpen} title={`Paramètres — ${ai.nom}`} onClose={() => setSettingsOpen(false)}>
        <Label>System prompt (injecté réellement à chaque message)</Label>
        <Textarea
          rows={10}
          value={systemDraft}
          onChange={(e) => setSystemDraft(e.target.value)}
          placeholder="Ex. Tu es un assistant commercial. Tu réponds toujours en français, de façon concise…"
        />
        <p className="mt-2 text-xs text-ink-soft">
          Ce texte est envoyé au moteur en instruction système, avant l'historique et vos fichiers.
        </p>
        <Label>Description</Label>
        <Textarea rows={2} value={descDraft} onChange={(e) => setDescDraft(e.target.value)} />
        <Label>Tokens max (longueur de réponse)</Label>
        <Input
          type="number"
          min={64}
          max={4096}
          value={maxTokensDraft}
          onChange={(e) => setMaxTokensDraft(e.target.value)}
          placeholder="700"
        />
        <p className="mt-1 text-xs text-ink-soft">
          Llama.cpp utilise au maximum 1024 tokens par réponse.
        </p>
        <Label>Température (0 = précis, 1 = créatif)</Label>
        <Input
          type="number"
          min={0}
          max={1.5}
          step={0.05}
          value={tempDraft}
          onChange={(e) => setTempDraft(e.target.value)}
          placeholder="0.4"
        />
        <div className="mt-4 flex justify-end gap-2.5">
          <Button variant="ghost" onClick={() => setSettingsOpen(false)}>
            Fermer
          </Button>
          <Button
            onClick={() => {
              const mt = Math.min(Math.max(parseInt(maxTokensDraft, 10) || 700, 64), 4096);
              const tp = Math.min(Math.max(parseFloat(tempDraft) || 0.4, 0), 1.5);
              void onAI({
                ...ai,
                systemPrompt: systemDraft,
                description: descDraft.trim(),
                maxTokens: mt,
                temperature: tp,
              });
              setSettingsOpen(false);
            }}
          >
            Enregistrer
          </Button>
        </div>
      </Modal>

      <Modal open={enginesOpen} title="Moteur llama.cpp" onClose={() => setEnginesOpen(false)}>
        <p className="mb-3 text-[12.5px] text-ink-soft">
          Llama.cpp est le seul moteur IA de cette application. Le modèle GGUF est téléchargé automatiquement à l'ouverture, conservé localement, puis chargé en mémoire. Aucun moteur LLM distant n'est utilisé.
        </p>
        <EngineList />
        <div className="mt-4 flex justify-end">
          <Button variant="ghost" onClick={() => setEnginesOpen(false)}>Fermer</Button>
        </div>
      </Modal>

      <Modal open={apiOpen} title="Ajouter une API métier" onClose={() => setApiOpen(false)}>
        <p className="mb-3 text-[12.5px] text-ink-soft">
          Les intégrations API restent enregistrées dans l'IA. Le moteur Llama.cpp local ne déclenche pas automatiquement leurs appels.
        </p>
        {(ai.apis || []).map((a) => (
          <div key={a.id} className="flex items-center justify-between border-b border-line py-2 text-sm">
            <div>
              <strong>{a.nom}</strong>
              <div className="text-[11.5px] text-ink-soft">{a.endpoint}</div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                Secrets.remove(a.id);
                void onAI({ ...ai, apis: ai.apis.filter((x) => x.id !== a.id) });
              }}
            >
              Retirer
            </Button>
          </div>
        ))}
        <ApiForm
          onAdd={async (form) => {
            const api: UserApi = {
              id: uid(),
              nom: form.nom,
              endpoint: form.endpoint,
              method: form.method,
              description: form.description,
              ts: Date.now(),
            };
            if (form.cle) Secrets.set(api.id, form.cle);
            await onAI({ ...ai, apis: [...ai.apis, api] });
          }}
        />
        <div className="mt-4 flex justify-end">
          <Button variant="ghost" onClick={() => setApiOpen(false)}>
            Fermer
          </Button>
        </div>
      </Modal>
    </div>
  );
}

function TabLink({ id, tab, label, active }: { id: string; tab: string; label: string; active?: boolean }) {
  return (
    <Link
      to="/ia/$id"
      params={{ id }}
      search={{ tab }}
      className={cn(
        "inline-flex min-h-10 items-center rounded-md px-3 text-xs font-semibold",
        active ? "bg-accent text-white" : "border-[1.5px] border-line bg-paper text-ink hover:bg-mist",
      )}
    >
      {label}
    </Link>
  );
}

function MenuItem({
  icon: Icon,
  children,
  onClick,
}: {
  icon: typeof Settings2;
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-2 rounded-lg px-3.5 py-3 text-left text-[13.5px] text-ink hover:bg-mist"
    >
      <Icon className="size-4 text-ink-soft" />
      {children}
    </button>
  );
}

function readDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(r.error);
    r.readAsDataURL(file);
  });
}

async function exportAI(ai: VanelleAI) {
  const chat = await Store.getChat(ai.id);
  const { BlobWriter, TextReader, ZipWriter } = await import("@zip.js/zip.js");
  const writer = new ZipWriter(new BlobWriter("application/zip"));
  const payload = {
    nom: ai.nom,
    description: ai.description,
    systemPrompt: ai.systemPrompt || "",
    modele: ai.modele,
    training: ai.training || [],
    apis: (ai.apis || []).map(({ id, nom, endpoint, method, description, ts }) => ({
      id,
      nom,
      endpoint,
      method,
      description,
      ts,
    })),
    files: (ai.files || []).map((f) => ({
      id: f.id,
      nom: f.nom,
      taille: f.taille,
      type: f.type,
      resume: f.resume,
      chunks: f.chunks || [],
      source: f.source,
      ts: f.ts,
    })),
  };
  await writer.add("config.json", new TextReader(JSON.stringify(payload, null, 2)));
  await writer.add("chat.json", new TextReader(JSON.stringify(chat, null, 2)));
  await writer.add(
    "README.txt",
    new TextReader("IA exportée depuis Vanelle — réimportez via Vue d'ensemble > Ajouter une IA complète (ZIP).\n"),
  );
  const blob = await writer.close();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${ai.nom.toLowerCase().replace(/\s+/g, "-")}-config.zip`;
  a.click();
  URL.revokeObjectURL(url);
}
