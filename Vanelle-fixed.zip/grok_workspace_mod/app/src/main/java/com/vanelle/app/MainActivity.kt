package com.vanelle.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var engine: LlamaEngine
    private val jsScope = CoroutineScope(Dispatchers.Main)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = LlamaEngine(this)
        engine.onProgress = { status, progress, text, error ->
            runOnUiThread {
                val payload = JSONObject()
                    .put("status", status)
                    .put("progress", progress)
                    .put("text", text)
                if (error != null) payload.put("error", error)
                webView.evaluateJavascript(
                    "window.__vanelleLlamaProgress && window.__vanelleLlamaProgress($payload)",
                    null,
                )
            }
        }

        webView = WebView(this)
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        WebView.setWebContentsDebuggingEnabled(true)

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false
        }
        webView.addJavascriptInterface(JsBridge(), "__vanelleLlama")
        setContentView(webView)

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (webView.canGoBack()) webView.goBack() else finish()
                }
            },
        )

        webView.loadUrl("file:///android_asset/www/index.html")

        // Prépare automatiquement llama.cpp dès l'ouverture de l'application.
        // Le modèle est téléchargé une seule fois, puis rechargé en mémoire à chaque ouverture.
        jsScope.launch {
            withContext(Dispatchers.IO) {
                runCatching { engine.ensureLoaded() }
            }
        }
    }

    inner class JsBridge {
        @JavascriptInterface
        fun ensureLoaded(cb: String) {
            jsScope.launch {
                try {
                    withContext(Dispatchers.IO) { engine.ensureLoaded() }
                    resolve(cb, JSONObject().put("ready", true), null)
                } catch (e: Exception) {
                    resolve(cb, null, e.message ?: "Échec du chargement")
                }
            }
        }

        @JavascriptInterface
        fun chat(payloadJson: String, cb: String) {
            jsScope.launch {
                try {
                    val payload = JSONObject(payloadJson)
                    val messages = payload.optJSONArray("messages") ?: JSONArray()
                    val maxTokens = payload.optInt("maxTokens", 512)
                    val temperature = payload.optDouble("temperature", 0.4).toFloat()
                    val pairs = ArrayList<Pair<String, String>>()
                    for (i in 0 until messages.length()) {
                        val m = messages.getJSONObject(i)
                        pairs.add(m.optString("role", "user") to m.optString("content", ""))
                    }
                    val prompt = engine.buildPrompt(pairs)
                    val text = withContext(Dispatchers.IO) {
                        engine.generate(prompt, maxTokens.coerceIn(32, 1024), temperature)
                    }
                    resolve(cb, JSONObject().put("text", text), null)
                } catch (e: Exception) {
                    resolve(cb, null, e.message ?: "Échec de la génération")
                }
            }
        }

        private fun resolve(cb: String, payload: JSONObject?, error: String?) {
            val arg = payload?.toString() ?: "null"
            val err = if (error == null) "null" else JSONObject.quote(error)
            webView.evaluateJavascript(
                "window.__vanelleLlamaResolve && window.__vanelleLlamaResolve(${JSONObject.quote(cb)}, $arg, $err)",
                null,
            )
        }
    }
}
