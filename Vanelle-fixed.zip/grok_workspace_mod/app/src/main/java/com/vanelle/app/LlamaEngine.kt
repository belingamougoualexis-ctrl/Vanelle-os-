package com.vanelle.app

import android.content.Context
import android.util.Log
import androidx.core.content.FileProvider
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.nehuatl.llamacpp.LlamaHelper
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Unique moteur LLM de Vanelle : llama.cpp + GGUF.
 *
 * Le modèle SmolLM2-360M-Instruct Q4_K_M (~271 Mo) est téléchargé automatiquement
 * la première fois, repris si le téléchargement a été interrompu, vérifié par SHA-256,
 * puis chargé en mémoire. Aucun moteur LLM distant n'intervient dans l'inférence.
 */
class LlamaEngine(private val context: Context) {

    companion object {
        private const val TAG = "VanelleLlama"
        const val MODEL_URL =
            "https://huggingface.co/jc-builds/SmolLM2-360M-Instruct-Q4_K_M-GGUF/resolve/main/SmolLM2-360M-Instruct.Q4_K_M.gguf"
        const val MODEL_FILE = "vanelle-smollm2-360m-q4_k_m.gguf"
        private const val LEGACY_MODEL_FILE = "vanelle-qwen05.gguf"
        private const val MODEL_SHA256 = "ade7aee1e5bd7c3b8f1fedafc61a1a0be31e8afa64e006607cd202323e2ccce0"
        private const val MODEL_MIN_SIZE = 260_000_000L
        const val CONTEXT_SIZE = 2048
    }

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val events = MutableSharedFlow<LlamaHelper.LLMEvent>(extraBufferCapacity = 128)
    private val helper = LlamaHelper(context.contentResolver, ioScope, events)
    private val mutex = Mutex()

    @Volatile
    var ready: Boolean = false
        private set

    var onProgress: ((status: String, progress: Double, text: String, error: String?) -> Unit)? = null

    private var pendingLoad: CompletableDeferred<Unit>? = null
    private var pendingGen: CompletableDeferred<String>? = null
    private val generated = StringBuilder()

    init {
        ioScope.launch {
            events.collect { event ->
                when (event) {
                    is LlamaHelper.LLMEvent.Loaded -> {
                        ready = true
                        emit("ready", 1.0, "Llama.cpp prêt — modèle local chargé en mémoire.")
                        pendingLoad?.complete(Unit)
                    }
                    is LlamaHelper.LLMEvent.Started -> generated.clear()
                    is LlamaHelper.LLMEvent.Ongoing -> generated.append(event.word)
                    is LlamaHelper.LLMEvent.Done -> {
                        val text = event.fullText.ifBlank { generated.toString() }
                        pendingGen?.complete(text)
                    }
                    is LlamaHelper.LLMEvent.Error -> {
                        ready = false
                        emit("error", 0.0, event.message, event.message)
                        pendingLoad?.completeExceptionally(IllegalStateException(event.message))
                        pendingGen?.completeExceptionally(IllegalStateException(event.message))
                    }
                }
            }
        }
    }

    private fun emit(status: String, progress: Double, text: String, error: String? = null) {
        onProgress?.invoke(status, progress, text, error)
    }

    suspend fun ensureLoaded() {
        mutex.withLock {
            if (ready) return
            val model = downloadModelIfNeeded()
            emit("loading", 0.9, "Chargement du modèle en mémoire…")
            val deferred = CompletableDeferred<Unit>()
            pendingLoad = deferred
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                model,
            )
            context.grantUriPermission(
                context.packageName,
                uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION,
            )
            helper.load(uri.toString(), CONTEXT_SIZE, null) { _ -> }
            deferred.await()
            pendingLoad = null
        }
    }

    suspend fun generate(prompt: String, maxTokens: Int, temperature: Float): String {
        if (!ready) ensureLoaded()
        mutex.withLock {
            val deferred = CompletableDeferred<String>()
            pendingGen = deferred
            generated.clear()
            helper.predict(prompt, null, true)
            val raw = deferred.await()
            pendingGen = null
            return cleanReply(raw)
        }
    }

    fun stop() {
        helper.stopPrediction()
    }

    private fun cleanReply(raw: String): String {
        return raw
            .replace("<|im_end|>", "")
            .replace("<|endoftext|>", "")
            .replace("<|im_start|>assistant", "")
            .trim()
    }

    fun buildPrompt(messages: List<Pair<String, String>>): String {
        val sb = StringBuilder()
        for ((role, content) in messages) {
            sb.append("<|im_start|>").append(role).append("\n").append(content).append("<|im_end|>\n")
        }
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }

    private fun downloadModelIfNeeded(): File {
        val dest = File(context.filesDir, MODEL_FILE)
        val legacy = File(context.filesDir, LEGACY_MODEL_FILE)
        if (legacy.exists()) legacy.delete()
        if (dest.exists() && dest.length() >= MODEL_MIN_SIZE && sha256(dest) == MODEL_SHA256) return dest
        if (dest.exists()) dest.delete()

        val partial = File(context.filesDir, "$MODEL_FILE.part")
        var downloaded = if (partial.exists()) partial.length() else 0L
        emit("downloading", 0.0, "Téléchargement du modèle local (~271 Mo)…")

        var url = URL(MODEL_URL)
        var conn: HttpURLConnection? = null
        try {
            var responseCode: Int
            var hops = 0
            while (true) {
                conn?.disconnect()
                conn = (url.openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    setRequestProperty("User-Agent", "Vanelle/1.0 (Android; llama.cpp)")
                    connectTimeout = 30_000
                    readTimeout = 60_000
                    if (downloaded > 0) setRequestProperty("Range", "bytes=$downloaded-")
                }
                responseCode = conn.responseCode
                if (responseCode in 300..399 && hops < 8) {
                    val location = conn.getHeaderField("Location") ?: break
                    url = URL(url, location)
                    hops++
                    continue
                }
                break
            }

            if (responseCode == HttpURLConnection.HTTP_OK && downloaded > 0) {
                partial.delete()
                downloaded = 0L
                conn.disconnect()
                conn = (url.openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "Vanelle/1.0 (Android; llama.cpp)")
                    connectTimeout = 30_000
                    readTimeout = 60_000
                }
                responseCode = conn.responseCode
            }
            if (responseCode != HttpURLConnection.HTTP_OK && responseCode != HttpURLConnection.HTTP_PARTIAL) {
                throw IllegalStateException("Téléchargement modèle HTTP $responseCode")
            }

            val contentLength = conn.contentLengthLong
            val total = if (responseCode == HttpURLConnection.HTTP_PARTIAL && contentLength > 0) downloaded + contentLength else contentLength
            conn.inputStream.use { input ->
                FileOutputStream(partial, responseCode == HttpURLConnection.HTTP_PARTIAL && downloaded > 0).use { output ->
                    val buffer = ByteArray(1 shl 16)
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        output.write(buffer, 0, read)
                        downloaded += read
                        if (total > 0) {
                            emit("downloading", (downloaded.toDouble() / total.toDouble()).coerceIn(0.0, 0.85), "Téléchargement du modèle… ${(downloaded * 100 / total).toInt()} %")
                        }
                    }
                }
            }
        } finally {
            conn?.disconnect()
        }

        if (partial.length() < MODEL_MIN_SIZE || sha256(partial) != MODEL_SHA256) {
            partial.delete()
            throw IllegalStateException("Vérification SHA-256 du modèle échouée. Le téléchargement sera repris au prochain démarrage.")
        }
        if (!partial.renameTo(dest)) {
            partial.copyTo(dest, overwrite = true)
            partial.delete()
        }
        Log.i(TAG, "Modèle local prêt: ${dest.length()} octets")
        return dest
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(1 shl 16)
            var read: Int
            while (input.read(buffer).also { read = it } != -1) digest.update(buffer, 0, read)
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
