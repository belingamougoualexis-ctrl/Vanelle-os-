package com.vanelle.app

import android.util.Log
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Plugin Capacitor "LlamaEngine" — wrapping the real LlamaEngine (llama.cpp).
 * Copier ce fichier + LlamaEngine.kt dans android/app/src/main/java/com/vanelle/app/
 * après `npx cap add android` (voir MOBILE_APP.md / scripts/prepare-android.mjs).
 */
@CapacitorPlugin(name = "LlamaEngine")
class LlamaEnginePlugin : Plugin() {

    companion object {
        private const val TAG = "VanelleLlamaPlugin"
    }

    private var engine: LlamaEngine? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    private fun engine(): LlamaEngine {
        val existing = engine
        if (existing != null) return existing
        val created = LlamaEngine(context)
        created.onProgress = { status, progress, text, error ->
            val data = JSObject()
            data.put("status", status)
            data.put("progress", progress)
            data.put("text", text)
            if (error != null) data.put("error", error)
            notifyListeners("progress", data)
        }
        engine = created
        return created
    }

    @PluginMethod
    fun ensureLoaded(call: PluginCall) {
        scope.launch {
            try {
                engine().ensureLoaded()
                val ret = JSObject()
                ret.put("ready", true)
                call.resolve(ret)
            } catch (e: Exception) {
                Log.e(TAG, "ensureLoaded", e)
                call.reject(e.message ?: "Échec du chargement du modèle natif", e)
            }
        }
    }

    @PluginMethod
    fun chat(call: PluginCall) {
        val messages = call.getArray("messages") ?: JSArray()
        val maxTokens = call.getInt("maxTokens") ?: 512
        val temperature = (call.getDouble("temperature") ?: 0.4).toFloat()
        scope.launch {
            try {
                val pairs = ArrayList<Pair<String, String>>()
                for (i in 0 until messages.length()) {
                    val m: JSONObject = messages.getJSONObject(i)
                    pairs.add(m.optString("role", "user") to m.optString("content", ""))
                }
                val prompt = engine().buildPrompt(pairs)
                val text = engine().generate(prompt, maxTokens.coerceIn(32, 1024), temperature)
                val ret = JSObject()
                ret.put("text", text.trim())
                call.resolve(ret)
            } catch (e: Exception) {
                Log.e(TAG, "chat", e)
                call.reject(e.message ?: "Échec de la génération", e)
            }
        }
    }
}
