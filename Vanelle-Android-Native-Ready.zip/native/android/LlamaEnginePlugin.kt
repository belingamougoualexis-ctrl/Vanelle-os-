package com.vanelle.app

import android.util.Log
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Plugin Capacitor natif "LlamaEngine" — expose le moteur IA local à l'app
 * web via llama.cpp (bibliothèque io.github.ljcamargo:llamacpp-kotlin),
 * pour remplacer WebLLM dans la version native (Android), WebGPU n'étant
 * pas fiable dans une WebView.
 *
 * IMPORTANT — pas encore compilé/testé ici (pas d'accès réseau/Android
 * Studio dans cet environnement). La partie téléchargement + chargement
 * mémoire est écrite dans un style déjà éprouvé sur un précédent projet
 * Vanelle Android avec la même bibliothèque, mais l'API exacte de
 * llamacpp-kotlin (noms de classes/méthodes ci-dessous : LlamaModel,
 * LlamaContext, generate...) est à vérifier contre la version réellement
 * installée par Gradle avant la compilation — voir MOBILE_APP.md.
 */
@CapacitorPlugin(name = "LlamaEngine")
class LlamaEnginePlugin : Plugin() {

    companion object {
        private const val TAG = "VanelleLlama"

        // Modèle GGUF quantifié, taille raisonnable pour un téléphone (~700-900 Mo).
        // À ajuster selon la puissance visée des appareils cibles.
        private const val MODEL_URL =
            "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf"
        private const val MODEL_FILE = "vanelle-model.gguf"
        private const val CONTEXT_SIZE = 4096
    }

    private val loadMutex = Mutex()
    private var runtime: LlamaRuntime? = null

    @PluginMethod
    fun ensureLoaded(call: PluginCall) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                loadMutex.withLock {
                    if (runtime == null) {
                        val model = downloadModelIfNeeded()
                        emitProgress("loading", 0.9, "Chargement en mémoire…")
                        runtime = LlamaRuntime.load(model, CONTEXT_SIZE)
                    }
                }
                emitProgress("ready", 1.0, "Vanelle prête — modèle en mémoire (llama.cpp).")
                val ret = JSObject()
                ret.put("ready", true)
                call.resolve(ret)
            } catch (e: Exception) {
                Log.e(TAG, "Échec chargement modèle natif", e)
                emitProgress("error", 0.0, e.message ?: "Échec du chargement", e.message)
                call.reject(e.message ?: "Échec du chargement du modèle natif", e)
            }
        }
    }

    @PluginMethod
    fun chat(call: PluginCall) {
        val rt = runtime
        if (rt == null) {
            call.reject("Moteur natif non chargé — appelez ensureLoaded() d'abord.")
            return
        }
        val messages = call.getArray("messages") ?: JSArray()
        val maxTokens = call.getInt("maxTokens", 512) ?: 512
        val temperature = (call.getDouble("temperature") ?: 0.4).toFloat()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val prompt = buildPrompt(messages)
                val text = rt.generate(prompt, maxTokens, temperature)
                val ret = JSObject()
                ret.put("text", text.trim())
                call.resolve(ret)
            } catch (e: Exception) {
                Log.e(TAG, "Échec génération", e)
                call.reject(e.message ?: "Échec de la génération", e)
            }
        }
    }

    /** Mise en forme ChatML-like, compatible avec la plupart des modèles instruct récents. */
    private fun buildPrompt(messages: JSArray): String {
        val sb = StringBuilder()
        for (i in 0 until messages.length()) {
            val m = messages.getJSONObject(i)
            val role = m.optString("role", "user")
            val content = m.optString("content", "")
            sb.append("<|im_start|>").append(role).append("\n").append(content).append("<|im_end|>\n")
        }
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }

    private fun downloadModelIfNeeded(): File {
        val dest = File(context.filesDir, MODEL_FILE)
        if (dest.exists() && dest.length() > 0) return dest

        emitProgress("downloading", 0.0, "Téléchargement du modèle…")
        val partial = File(context.filesDir, "$MODEL_FILE.part")
        val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
        conn.connect()
        val total = conn.contentLengthLong
        var downloaded = 0L

        conn.inputStream.use { input ->
            partial.outputStream().use { output ->
                val buffer = ByteArray(1 shl 16)
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    output.write(buffer, 0, read)
                    downloaded += read
                    if (total > 0) {
                        emitProgress("downloading", (downloaded.toDouble() / total) * 0.85, "Téléchargement du modèle…")
                    }
                }
            }
        }
        partial.renameTo(dest)
        return dest
    }

    private fun emitProgress(status: String, progress: Double, text: String, error: String? = null) {
        val data = JSObject()
        data.put("status", status)
        data.put("progress", progress)
        data.put("text", text)
        if (error != null) data.put("error", error)
        notifyListeners("progress", data)
    }
}

/**
 * Fine couche autour de llamacpp-kotlin. À vérifier/adapter contre l'API
 * réelle de la version installée (io.github.ljcamargo:llamacpp-kotlin) —
 * non testé faute d'accès réseau/Gradle dans cet environnement.
 */
private class LlamaRuntime private constructor(/* handle natif llama.cpp */) {
    companion object {
        fun load(model: File, contextSize: Int): LlamaRuntime {
            // TODO : remplacer par l'appel réel de la bibliothèque, par ex. :
            // val ctx = LlamaContext.create(model.absolutePath, contextSize)
            // return LlamaRuntime(ctx)
            throw NotImplementedError(
                "Brancher ici l'API réelle de llamacpp-kotlin (chargement du modèle ${model.absolutePath}, " +
                    "contexte $contextSize) — voir MOBILE_APP.md."
            )
        }
    }

    fun generate(prompt: String, maxTokens: Int, temperature: Float): String {
        // TODO : remplacer par l'appel réel de génération de la bibliothèque.
        throw NotImplementedError("Brancher ici l'appel de génération réel de llamacpp-kotlin.")
    }
}
