package com.vanelle.app

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.loadData(
            "<html><meta name='viewport' content='width=device-width'>" +
            "<body style='font-family:sans-serif;padding:40px'>" +
            "<h1>Vanelle</h1><p>Application Android native prête à être compilée.</p>" +
            "</body></html>",
            "text/html", "UTF-8"
        )
        setContentView(webView)
    }
}
