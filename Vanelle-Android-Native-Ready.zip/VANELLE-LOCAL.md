# Vanelle — moteur local

```bash
npm install
npm run dev
```

- Moteur local WebLLM (SmolLM2-360M), chargement direct au démarrage
- Barre de progression dans la sidebar
- Tokens / température : ⋮ → Paramètres (par IA)
- Chrome ou Edge (WebGPU)
