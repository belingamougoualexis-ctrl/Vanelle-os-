import type { CapacitorConfig } from "@capacitor/core";

const config: CapacitorConfig = {
  appId: "com.vanelle.app",
  appName: "Vanelle",
  webDir: "dist/client",
  server: {
    androidScheme: "https",
  },
  backgroundColor: "#f2f7fb",
};

export default config;
