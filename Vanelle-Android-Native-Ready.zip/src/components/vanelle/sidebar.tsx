import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutGrid, MessageSquarePlus, Plus, Settings2, Sparkles } from "lucide-react";
import { useEffect } from "react";
import { cn } from "@/lib/utils";
import { startLocalEngineOnBoot, useEngineStore } from "@/lib/vanelle/engine-store";

const NAV = [
  { to: "/", label: "Créer une IA", icon: Plus, match: (p: string) => p === "/" },
  { to: "/mes-ia", label: "Mes IA", icon: MessageSquarePlus, match: (p: string) => p.startsWith("/mes-ia") || p.startsWith("/ia/") },
  { to: "/dashboard", label: "Tableau de bord", icon: LayoutGrid, match: (p: string) => p.startsWith("/dashboard") },
  { to: "/compte", label: "Compte & moteurs", icon: Settings2, match: (p: string) => p.startsWith("/compte") },
];

export function Sidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { vanelleReady, probed, detail, probing, progress, status } = useEngineStore();

  // Téléchargement + chargement en mémoire automatique à l'ouverture de l'app
  useEffect(() => {
    startLocalEngineOnBoot();
  }, []);

  const showBar = probing || status === "downloading" || status === "loading";

  return (
    <aside className="hidden shrink-0 flex-col bg-sidebar text-sidebar-text md:flex md:h-screen md:w-[232px] md:sticky md:top-0 md:overflow-y-auto">
      <div className="flex items-center gap-2.5 px-5 pt-5 pb-7">
        <div className="size-9 overflow-hidden rounded-[9px] bg-accent">
          <img src="/vanelle_logo.png" alt="Vanelle" className="size-full object-cover" />
        </div>
        <div className="font-display text-[15px] font-bold leading-tight tracking-wide text-white">
          VANELLE
          <small className="block text-[10px] font-medium tracking-[0.14em] text-accent">ATELIER IA</small>
        </div>
      </div>

      <nav className="flex flex-1 flex-col gap-5 px-3 pb-4">
        <div>
          <div className="mb-2 px-2.5 font-display text-[10px] font-semibold tracking-[0.12em] text-white/35 uppercase">
            Atelier
          </div>
          {NAV.slice(0, 3).map((item) => (
            <NavLink key={item.to} {...item} active={item.match(pathname)} />
          ))}
        </div>
        <div>
          <div className="mb-2 px-2.5 font-display text-[10px] font-semibold tracking-[0.12em] text-white/35 uppercase">
            Compte
          </div>
          <NavLink {...NAV[3]} active={NAV[3].match(pathname)} />
        </div>
      </nav>

      <div className="mt-auto border-t border-sidebar-line px-4 py-3.5">
        <div className="flex items-start gap-2 text-[11px] leading-snug text-white/55">
          <span
            className={cn(
              "mt-1 size-1.5 shrink-0 rounded-full",
              vanelleReady ? "bg-ok" : probing ? "bg-accent animate-pulse" : "bg-white/30",
            )}
          />
          <span>
            {vanelleReady
              ? "Vanelle prête — moteur local en mémoire"
              : probed
                ? detail
                : "Démarrage du moteur local…"}
          </span>
        </div>
        {showBar ? (
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-accent transition-[width] duration-300"
              style={{ width: `${Math.max(4, Math.round(progress * 100))}%` }}
            />
          </div>
        ) : null}
        <div className="mt-2 flex items-center gap-1.5 text-[10px] text-cyan/80">
          <Sparkles className="size-3" strokeWidth={2} />
          {vanelleReady
            ? "100 % local — aucune clé cloud"
            : showBar
              ? "Téléchargement puis chargement en mémoire"
              : "Inférence locale dans le navigateur"}
        </div>
      </div>
    </aside>
  );
}

function NavLink({
  to,
  label,
  icon: Icon,
  active,
}: {
  to: string;
  label: string;
  icon: typeof Plus;
  active: boolean;
}) {
  return (
    <Link
      to={to}
      className={cn(
        "mb-0.5 flex min-h-11 items-center gap-2.5 rounded-md px-2.5 py-2 text-[13.5px] font-medium transition-colors duration-150",
        active ? "bg-accent text-white" : "text-sidebar-text hover:bg-white/10 hover:text-white",
      )}
    >
      <Icon className="size-4 shrink-0" strokeWidth={1.8} />
      {label}
    </Link>
  );
}

/** Barre du haut compacte, mobile uniquement — logo + statut du moteur local. */
export function MobileTopBar() {
  const { vanelleReady, probing, status } = useEngineStore();
  return (
    <header
      className="flex items-center gap-2.5 bg-sidebar px-4 text-sidebar-text md:hidden"
      style={{ paddingTop: "calc(0.625rem + var(--safe-top))", paddingBottom: "0.625rem" }}
    >
      <div className="size-8 overflow-hidden rounded-[8px] bg-accent">
        <img src="/vanelle_logo.png" alt="Vanelle" className="size-full object-cover" />
      </div>
      <div className="font-display text-[14px] font-bold tracking-wide text-white">VANELLE</div>
      <span
        className={cn(
          "ml-auto size-2 shrink-0 rounded-full",
          vanelleReady ? "bg-ok" : probing || status === "downloading" || status === "loading" ? "bg-accent animate-pulse" : "bg-white/30",
        )}
        title={vanelleReady ? "Moteur local prêt" : "Moteur local en préparation"}
      />
    </header>
  );
}

/** Barre d'onglets en bas, mobile uniquement — remplace la sidebar façon app native. */
export function MobileTabBar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="v-tabbar fixed inset-x-0 bottom-0 z-30 flex md:hidden">
      {NAV.map((item) => {
        const active = item.match(pathname);
        const Icon = item.icon;
        return (
          <Link
            key={item.to}
            to={item.to}
            className={cn(
              "flex flex-1 flex-col items-center gap-0.5 py-2 text-[10.5px] font-medium",
              active ? "text-accent" : "text-ink-soft",
            )}
          >
            <Icon className="size-5" strokeWidth={active ? 2.2 : 1.8} />
            {item.label === "Tableau de bord" ? "Tableau" : item.label === "Compte & moteurs" ? "Compte" : item.label}
          </Link>
        );
      })}
    </nav>
  );
}
