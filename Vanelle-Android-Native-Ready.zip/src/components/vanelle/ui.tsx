import type { ButtonHTMLAttributes, InputHTMLAttributes, TextareaHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function PageHead({ eyebrow, title, children }: { eyebrow: string; title: string; children?: React.ReactNode }) {
  return (
    <header className="mb-6">
      <div className="font-display text-[11px] font-semibold tracking-[0.08em] text-accent uppercase">{eyebrow}</div>
      <h1 className="mt-1.5 font-sans text-[26px] font-bold tracking-[-0.03em] text-ink">{title}</h1>
      {children ? <div className="mt-2 max-w-[62ch] text-sm leading-relaxed text-ink-soft">{children}</div> : null}
    </header>
  );
}

export function Card({ className, children }: { className?: string; children: React.ReactNode }) {
  return <section className={cn("v-card", className)}>{children}</section>;
}

export function Label({ children }: { children: React.ReactNode }) {
  return <label className="mb-1.5 mt-3.5 block text-[12.5px] font-semibold first:mt-0">{children}</label>;
}

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn("v-input", props.className)} />;
}

export function Textarea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cn("v-input", props.className)} />;
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={cn("v-input", props.className)} />;
}

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ghost" | "ok" | "danger";
  size?: "md" | "sm";
  block?: boolean;
};

export function Button({ variant = "primary", size = "md", block, className, ...props }: BtnProps) {
  return (
    <button
      {...props}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-full font-semibold transition-[background,transform] duration-150 ease-out active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-45",
        size === "sm" ? "min-h-10 px-3 text-xs" : "min-h-11 px-4.5 text-[13.5px] px-[18px]",
        variant === "primary" && "bg-accent text-white hover:bg-accent-dark",
        variant === "ghost" && "border-[1.5px] border-line bg-transparent text-ink hover:bg-mist",
        variant === "ok" && "bg-ok text-white hover:brightness-95",
        variant === "danger" && "border-[1.5px] border-err/30 bg-err-soft text-err hover:bg-err/15",
        block && "w-full",
        className,
      )}
    />
  );
}

export function Tag({ on, children }: { on?: boolean; children: React.ReactNode }) {
  return (
    <span
      className={cn(
        "inline-block rounded-full px-2.5 py-0.5 text-[10.5px] font-semibold",
        on ? "bg-ok-soft text-ok" : "border border-line bg-mist text-ink-soft",
      )}
    >
      {children}
    </span>
  );
}

export function Modal({
  open,
  title,
  children,
  onClose,
}: {
  open: boolean;
  title: string;
  children: React.ReactNode;
  onClose: () => void;
}) {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink/50 p-4 backdrop-blur-[4px]"
      onClick={onClose}
      role="presentation"
    >
      <div
        className="max-h-[90vh] w-full max-w-[640px] overflow-y-auto rounded-2xl bg-paper p-6 text-ink shadow-[0_24px_60px_rgba(0,0,0,.25)]"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
      >
        <h2 id="modal-title" className="mb-3 text-lg font-bold">
          {title}
        </h2>
        {children}
      </div>
    </div>
  );
}

export function Empty({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-xl border-[1.5px] border-dashed border-line bg-paper px-5 py-11 text-center text-ink-soft">
      {children}
    </div>
  );
}
