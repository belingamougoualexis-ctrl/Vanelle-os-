/**
 * Moteur Vanelle local — deux implémentations derrière la même API :
 *
 * - Dans le navigateur / en PWA : WebLLM (WebGPU), modèle
 *   SmolLM2-360M-Instruct-q4f16_1-MLC, téléchargé et mis en cache par le
 *   navigateur.
 * - Dans l'app native (Android/iOS via Capacitor) : llama.cpp, via le plugin
 *   natif "LlamaEngine" (voir native-llama-plugin.ts + MOBILE_APP.md). C'est
 *   ce chemin qui est utilisé quand Capacitor.isNativePlatform() est vrai —
 *   WebGPU n'étant pas fiable dans une WebView native, on ne s'appuie pas
 *   dessus une fois l'app empaquetée.
 *
 * Le reste de l'app (engine-store.ts, chat-client.ts) n'a pas à savoir
 * lequel des deux tourne : il utilise toujours ensureLocalEngine/localChat/
 * subscribeLocalProgress.
 */

import {
  CreateMLCEngine,
  prebuiltAppConfig,
  type MLCEngineInterface,
  type InitProgressReport,
  type AppConfig,
} from "@mlc-ai/web-llm";
import { Capacitor } from "@capacitor/core";
import { NativeLlama, type NativeLlamaEvent } from "./native-llama-plugin";

/** ID exact dans la liste officielle WebLLM — ne pas changer */
export const VANELLE_LOCAL_MODEL_ID = "SmolLM2-360M-Instruct-q4f16_1-MLC";

// Le WASM précompilé officiel de SmolLM2-360M-Instruct-q4f16_1-MLC supporte
// nativement 4096 tokens (voir catalogue WebLLM). Utiliser 2048 divisait par
// deux la fenêtre réellement disponible pour rien, ce qui aggravait la perte
// du system prompt / des fichiers de connaissance sur les longues requêtes.
const CONTEXT_WINDOW = 4096;

const appConfig: AppConfig = {
  ...prebuiltAppConfig,
  cacheBackend: "cache",
};

export type LocalEngineStatus =
  | "idle"
  | "checking"
  | "downloading"
  | "loading"
  | "ready"
  | "error"
  | "unsupported";

export type LocalProgress = {
  status: LocalEngineStatus;
  progress: number;
  text: string;
  error?: string;
};

type ProgressListener = (p: LocalProgress) => void;

function isNative(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

let lastProgress: LocalProgress = {
  status: "idle",
  progress: 0,
  text: "Moteur local en attente…",
};
const listeners = new Set<ProgressListener>();

function emit(p: LocalProgress) {
  lastProgress = p;
  listeners.forEach((fn) => {
    try {
      fn(p);
    } catch {
      /* ignore */
    }
  });
}

export function subscribeLocalProgress(fn: ProgressListener): () => void {
  listeners.add(fn);
  fn(lastProgress);
  return () => listeners.delete(fn);
}

export function getLocalProgress(): LocalProgress {
  return lastProgress;
}

export function isLocalReady(): boolean {
  return lastProgress.status === "ready";
}

export type LocalChatMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

/* ─────────────────────────── Chemin navigateur (WebLLM) ─────────────────────────── */

let engine: MLCEngineInterface | null = null;
let loadPromise: Promise<MLCEngineInterface> | null = null;

function hasWebGPU(): boolean {
  return typeof navigator !== "undefined" && !!(navigator as Navigator & { gpu?: unknown }).gpu;
}

function onInitProgress(report: InitProgressReport) {
  const p = Math.min(1, Math.max(0, report.progress ?? 0));
  const text = report.text || "Chargement…";
  const lower = text.toLowerCase();
  const downloading =
    lower.includes("fetch") ||
    lower.includes("download") ||
    lower.includes("cache") ||
    lower.includes("load model from") ||
    lower.includes("loading model") ||
    p < 0.85;
  emit({
    status: downloading ? "downloading" : "loading",
    progress: p,
    text:
      p >= 0.99
        ? "Chargement en mémoire GPU…"
        : text.replace(/^\[.*?\]\s*/, "") || text,
  });
}

async function ensureWebEngine(): Promise<MLCEngineInterface> {
  if (engine) return engine;
  if (loadPromise) return loadPromise;

  if (!hasWebGPU()) {
    emit({
      status: "unsupported",
      progress: 0,
      text: "WebGPU requis. Ouvrez l’app dans Chrome ou Edge, ou ajoutez un moteur externe.",
      error: "webgpu-indisponible",
    });
    throw new Error("webgpu-indisponible");
  }

  loadPromise = (async () => {
    emit({ status: "checking", progress: 0.02, text: "Préparation du moteur Vanelle…" });

    const eng = await CreateMLCEngine(
      VANELLE_LOCAL_MODEL_ID,
      { appConfig, initProgressCallback: onInitProgress, logLevel: "warn" },
      { context_window_size: CONTEXT_WINDOW, temperature: 0.4, top_p: 0.9, repetition_penalty: 1.05 },
    );

    engine = eng;
    emit({ status: "ready", progress: 1, text: "Vanelle prête — modèle en mémoire." });
    return eng;
  })();

  loadPromise = loadPromise.catch((e) => {
    const msg = e instanceof Error ? e.message : "Chargement interrompu";
    engine = null;
    loadPromise = null;
    emit({ status: "error", progress: 0, text: msg, error: msg });
    throw e;
  });

  return loadPromise;
}

// Le modèle local n'a que 4096 tokens de contexte au total (system + historique
// + message + réponse). 6000 caractères d'historique à eux seuls (~1500-2000
// tokens en français) laissaient trop peu de place au system prompt et aux
// fichiers de connaissance une fois ajoutés par buildSystemPrompt, qui étaient
// alors coupés ou totalement absents du contexte réellement envoyé au modèle.
function trimMessages(messages: LocalChatMessage[], maxChars = 1800): LocalChatMessage[] {
  if (messages.length <= 2) return messages;
  const system = messages[0]?.role === "system" ? [messages[0]] : [];
  const rest = system.length ? messages.slice(1) : messages.slice();
  let total = system.reduce((n, m) => n + m.content.length, 0);
  const kept: LocalChatMessage[] = [];
  for (let i = rest.length - 1; i >= 0; i--) {
    const m = rest[i];
    if (total + m.content.length > maxChars && kept.length >= 2) break;
    kept.unshift(m);
    total += m.content.length;
  }
  return [...system, ...kept];
}

async function webChat(messages: LocalChatMessage[], maxTokens: number, temperature: number): Promise<string> {
  const eng = await ensureWebEngine();
  const trimmed = trimMessages(messages);
  const reply = await eng.chat.completions.create({
    messages: trimmed,
    temperature,
    max_tokens: maxTokens,
    stream: false,
  });
  const choice = (reply as { choices?: { message?: { content?: string | null } }[] })?.choices?.[0];
  const text = (choice?.message?.content || "").trim();
  if (!text) throw new Error("Réponse vide du moteur.");
  return text;
}

/* ─────────────────────────── Chemin natif (llama.cpp) ─────────────────────────── */

let nativeReadyPromise: Promise<void> | null = null;
let nativeListenerAttached = false;

function attachNativeListener() {
  if (nativeListenerAttached) return;
  nativeListenerAttached = true;
  void NativeLlama.addListener("progress", (event: NativeLlamaEvent) => {
    emit({
      status: event.status,
      progress: event.progress,
      text: event.text,
      error: event.error,
    });
  });
}

async function ensureNativeEngine(): Promise<void> {
  if (lastProgress.status === "ready") return;
  if (nativeReadyPromise) return nativeReadyPromise;

  attachNativeListener();
  emit({ status: "checking", progress: 0.02, text: "Préparation du moteur Vanelle (llama.cpp)…" });

  nativeReadyPromise = NativeLlama.ensureLoaded()
    .then((res) => {
      if (!res.ready) throw new Error("Le modèle natif n'a pas pu être chargé en mémoire.");
      emit({ status: "ready", progress: 1, text: "Vanelle prête — modèle en mémoire (llama.cpp)." });
    })
    .catch((e) => {
      const msg = e instanceof Error ? e.message : "Chargement natif interrompu";
      nativeReadyPromise = null;
      emit({ status: "error", progress: 0, text: msg, error: msg });
      throw e;
    });

  return nativeReadyPromise;
}

async function nativeChat(messages: LocalChatMessage[], maxTokens: number, temperature: number): Promise<string> {
  await ensureNativeEngine();
  const { text } = await NativeLlama.chat({ messages, maxTokens, temperature });
  const trimmed = (text || "").trim();
  if (!trimmed) throw new Error("Réponse vide du moteur.");
  return trimmed;
}

/* ─────────────────────────── API publique (dispatch) ─────────────────────────── */

/**
 * Lance (ou rejoint) le téléchargement + chargement en mémoire du moteur
 * local adapté à la plateforme courante. Idempotent (singleton) — jamais de
 * double téléchargement.
 */
export async function ensureLocalEngine(): Promise<void> {
  if (isNative()) {
    await ensureNativeEngine();
  } else {
    await ensureWebEngine();
  }
}

export async function reloadLocalEngine(): Promise<void> {
  if (isNative()) {
    nativeReadyPromise = null;
  } else {
    try {
      if (engine) {
        await (engine as { unload?: () => Promise<void> }).unload?.();
      }
    } catch {
      /* ignore */
    }
    engine = null;
    loadPromise = null;
  }
  emit({ status: "idle", progress: 0, text: "Chargement du moteur…" });
  await ensureLocalEngine();
}

/** Inférence locale — maxTokens / temperature = config de l'IA utilisateur */
export async function localChat(
  messages: LocalChatMessage[],
  opts?: { maxTokens?: number; temperature?: number },
): Promise<string> {
  const maxTokens = Math.min(Math.max(opts?.maxTokens ?? 512, 32), 1024);
  const temperature = Math.min(Math.max(opts?.temperature ?? 0.4, 0), 1.5);
  return isNative() ? nativeChat(messages, maxTokens, temperature) : webChat(messages, maxTokens, temperature);
}
