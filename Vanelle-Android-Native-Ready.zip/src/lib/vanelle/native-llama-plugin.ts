/**
 * Pont vers le plugin Capacitor natif "LlamaEngine" (Android, via llama.cpp).
 *
 * Ce fichier ne fait qu'enregistrer l'interface du plugin — l'implémentation
 * réelle vit côté natif dans android/app/.../LlamaEnginePlugin.kt (voir
 * MOBILE_APP.md pour l'installation). En dehors d'une app native (navigateur,
 * PWA), le plugin n'existe simplement pas et registerPlugin() renvoie un
 * objet dont les méthodes rejettent — c'est géré dans local-engine.ts qui
 * bascule alors sur le moteur WebLLM du navigateur.
 */
import { registerPlugin } from "@capacitor/core";

export type NativeLlamaEvent = {
  status: "checking" | "downloading" | "loading" | "ready" | "error";
  progress: number;
  text: string;
  error?: string;
};

export interface LlamaEnginePlugin {
  /** Lance (ou rejoint) le téléchargement + chargement en mémoire du modèle GGUF. */
  ensureLoaded(): Promise<{ ready: boolean }>;
  /** Une complétion de chat, bloquante côté JS (le natif gère son propre thread). */
  chat(options: {
    messages: { role: "system" | "user" | "assistant"; content: string }[];
    maxTokens: number;
    temperature: number;
  }): Promise<{ text: string }>;
  /** Écoute la progression de téléchargement/chargement (émis par le natif). */
  addListener(
    eventName: "progress",
    listenerFunc: (event: NativeLlamaEvent) => void,
  ): Promise<{ remove: () => void }>;
}

export const NativeLlama = registerPlugin<LlamaEnginePlugin>("LlamaEngine");
