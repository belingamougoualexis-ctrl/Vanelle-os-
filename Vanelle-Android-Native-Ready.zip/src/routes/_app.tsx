import { createFileRoute, Outlet, useRouterState } from "@tanstack/react-router";
import { useEffect } from "react";
import { MobileTabBar, MobileTopBar, Sidebar } from "@/components/vanelle/sidebar";
import { useEngineStore } from "@/lib/vanelle/engine-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_app")({
  component: AppLayout,
});

function AppLayout() {
  const probe = useEngineStore((s) => s.probe);
  useEffect(() => {
    void probe();
  }, [probe]);

  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const search = useRouterState({ select: (s) => s.location.search });
  const tab = typeof search === "object" && search && "tab" in search ? String((search as { tab?: string }).tab || "") : "";
  const chatMode = pathname.startsWith("/ia/") && tab === "tester";

  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <Sidebar />
      {/* En mode conversation, la barre du haut mobile est masquée pour un plein écran
          immersif façon app de chat native (ChatGPT/Claude) ; la navigation reste à
          un appui du bouton retour dans l'en-tête du panneau de chat lui-même. */}
      {chatMode ? null : <MobileTopBar />}
      <main
        className={cn(
          "min-w-0 flex-1",
          chatMode
            ? "flex h-auto min-h-[100dvh] flex-col md:h-screen md:p-3"
            : "mx-auto w-full max-w-[1180px] px-4 py-6 pb-[calc(4.75rem+var(--safe-bottom))] md:px-9 md:py-8 md:pb-8",
        )}
      >
        <Outlet />
      </main>
      {/* Barre d'onglets mobile fixe en bas — masquée en plein écran de conversation
          pour laisser toute la hauteur à la saisie, comme sur une vraie app de chat. */}
      {chatMode ? null : <MobileTabBar />}
    </div>
  );
}
