# Vanelle — version mobile

## 1. Déjà actif dans ce zip, sans rien compiler (PWA)

L'interface est refaite façon app de chat mobile (barre d'onglets en bas, mode
conversation plein écran, saisie flottante, zones sûres respectées — voir
détail dans l'historique du projet). Avec les meta tags standalone déjà en
place, "Ajouter à l'écran d'accueil" (Safari iOS / Chrome Android) donne déjà
une vraie app installable, plein écran, sans étape de compilation.

Dans ce mode, le moteur IA local reste WebLLM (navigateur, WebGPU) — c'est
lui qui tourne par défaut, y compris dans l'app installée en PWA.

## 2. Pour une app native (.apk/.ipa) avec llama.cpp — ce qui a été préparé

**Important, à lire avant de te lancer** : je n'ai pas accès à Internet ni à
Android Studio/Xcode dans cet environnement. Je ne peux donc pas exécuter les
commandes ci-dessous moi-même, ni compiler/tester le résultat. Ce que j'ai
préparé est du code réel et cohérent, écrit dans le même style qu'un projet
Android Vanelle précédent où cette approche a fini par compiler avec succès
après plusieurs allers-retours — mais je ne peux pas te garantir "zéro erreur"
sans l'avoir vu passer par un vrai `gradle build`. Attends-toi à devoir me
renvoyer les logs d'erreur (comme pour l'autre projet) pour un ou deux
correctifs.

### Étapes

```bash
npm install                       # installe @capacitor/core, @capacitor/android déjà ajoutés au package.json
npm run build                     # construit dist/client
npx cap add android                # génère le dossier android/ (nécessite Internet)
npx cap sync
```

Puis, dans le projet Android généré :

1. **Copier le plugin** : `native/android/LlamaEnginePlugin.kt` → dans
   `android/app/src/main/java/com/vanelle/app/` (créer les dossiers si besoin).
2. **Enregistrer le plugin** dans `MainActivity.java` (générée par `cap add
   android`), dans `registerPlugins` ou via l'annotation `@CapacitorPlugin`
   suffit généralement avec Capacitor 7 si le plugin est sur le classpath —
   sinon ajouter `registerPlugin(LlamaEnginePlugin.class)` avant `super.onCreate`.
3. **Dépendance Gradle** — dans `android/app/build.gradle` :
   ```gradle
   dependencies {
       implementation "io.github.ljcamargo:llamacpp-kotlin:0.4.0"
   }
   ```
   et dans `android/build.gradle` (repositories), ajouter JitPack si absent :
   ```gradle
   maven { url 'https://jitpack.io' }
   ```
4. **minSdk** : cette bibliothèque exige minSdk ≥ 24 — vérifier/ajuster
   `minSdkVersion` dans `android/variables.gradle`.
5. **ProGuard/R8** (build release) : si le chargement de la lib se fait par
   réflexion, ajouter des règles `-keep` correspondantes dans
   `android/app/proguard-rules.pro` (sur le précédent projet Vanelle Android,
   l'omission de ces règles cassait l'IA uniquement en release, pas en debug).
6. **Brancher l'API réelle de llamacpp-kotlin** : `LlamaEnginePlugin.kt`
   contient une classe `LlamaRuntime` avec deux `TODO` explicites (chargement
   du modèle, génération) — à remplacer par les vrais appels de la
   bibliothèque une fois son API consultée (le nom exact des classes peut
   avoir changé entre versions).
7. Compiler :
   ```bash
   npx cap open android      # ouvre Android Studio
   ```
   ou en ligne de commande : `cd android && ./gradlew assembleDebug`.

### Le modèle utilisé

Par défaut le plugin télécharge un modèle Qwen2.5-1.5B-Instruct au format
GGUF quantifié (~900 Mo, URL dans `LlamaEnginePlugin.kt`) — plus capable que
le SmolLM2-360M utilisé côté navigateur, adapté à llama.cpp sur mobile.
Change `MODEL_URL`/`MODEL_FILE` dans le plugin si tu préfères un autre modèle
(plus petit pour les appareils bas de gamme, ou plus gros si tu vises des
appareils récents uniquement).

### Ce que la partie JavaScript fait déjà (branché, pas à retoucher)

`src/lib/vanelle/local-engine.ts` détecte automatiquement la plateforme via
`Capacitor.isNativePlatform()` : dans l'app native, il appelle le plugin
`LlamaEngine` (téléchargement, chargement, chat) ; dans le navigateur/PWA, il
garde WebLLM. Le reste de l'app (`engine-store.ts`, `chat-client.ts`) ne
change pas — il continue à utiliser la même API `ensureLocalEngine`/
`localChat`, quel que soit le moteur réellement utilisé derrière.
