# Publier Alpha Prime sur Uptodown (gratuit, sans certificat)

Contrairement au Microsoft Store, Uptodown n'exige ni frais d'inscription ni
certificat de signature Authenticode payant. C'est la bonne option pour toi
vu ta situation. Voici les étapes réelles.

## Prérequis (déjà prêts)

- L'exécutable Windows produit par `.github/workflows/build-windows-exe.yml`
  (téléchargeable depuis la page "Releases" de ton dépôt GitHub une fois le
  workflow exécuté). **Non signé, et c'est OK pour Uptodown.**

## Étapes

1. Va sur **uptodown.com** et cherche la section développeurs (parfois
   appelée "Developers Zone" ou un lien "Publier votre app" en bas de page
   — l'emplacement exact peut changer selon les mises à jour du site, donc
   cherche "developer"/"publish your app" dans leur menu ou leur pied de
   page si le lien a bougé).
2. Crée un compte développeur (gratuit).
3. Choisis "Windows" comme plateforme et téléverse le `.exe` (ou le dossier
   `AlphaPrime` compressé en `.zip` si l'upload attend une archive).
4. Renseigne : nom de l'app (**Alpha Prime**), description, catégorie
   (ex. "Productivité" / "Développement"), captures d'écran du dashboard,
   icône.
5. Uptodown fait passer le fichier par son propre scan de sécurité avant
   publication — ce n'est pas instantané, prévoir un délai de review.

## Avertissement SmartScreen (réel, pas grave)

Comme l'exécutable n'est pas signé, les utilisateurs Windows qui le lancent
verront un avertissement SmartScreen ("Windows a protégé votre ordinateur").
C'est normal pour un logiciel non signé, pas une erreur de ta part — précise-le
dans la description Uptodown ("cliquez sur 'Informations complémentaires' puis
'Exécuter quand même'") pour rassurer les utilisateurs.

## Politique de confidentialité

Uptodown demande généralement un lien vers une politique de confidentialité
pour les apps qui traitent des données. Utilise `PRIVACY.md` (complété et
idéalement hébergé quelque part en ligne — ex. comme fichier brut sur
GitHub, ou publié en page web) comme lien à fournir.

## Ce que je n'ai pas pu vérifier

Je n'ai pas pu ouvrir la page de soumission moi-même dans cet environnement
(accès web limité aux recherches, pas de compte à créer). Les grandes lignes
ci-dessus sont confirmées par mes recherches (gratuit, pas de certificat requis,
accepte le Windows), mais le détail exact des champs du formulaire peut avoir
changé — suis simplement ce que le site affiche à l'écran au moment de ton
inscription.
