# Alpha Prime — CI/Build fixes

- Corrigé `ai_training_os/safety_gate.py` pour être compatible Python 3.11 dans le f-string du statut Red Team.
- Rendu `run_tests.py` déterministe : chaque fichier de tests retourne toujours un résultat structuré et le processus enfant termine explicitement après nettoyage, évitant les faux timeouts de CI liés aux hooks natifs de bibliothèques ML.
- Ajout d'un préflight `compileall` Python 3.11 et `pip check` dans le workflow Windows.
- Le build PyInstaller n'échoue plus uniquement parce que `llama-cpp-python` (backend GGUF optionnel) n'est pas installé : il est collecté lorsqu'il est réellement présent et sinon le backend reste `UNAVAILABLE` honnêtement.
- Le workflow Windows utilise Python 3.11, un délai de test de 300 s par fichier, et vérifie réellement la présence et la taille de `dist/AlphaPrime/AlphaPrime.exe`.
