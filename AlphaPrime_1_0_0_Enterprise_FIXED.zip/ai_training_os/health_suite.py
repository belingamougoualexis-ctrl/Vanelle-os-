
"""Full local acceptance suite: real checks, fixture tests explicitly labeled as TEST."""
from __future__ import annotations
import importlib, os, tempfile, traceback
from pathlib import Path
from .dependency_manager import matrix as dependency_matrix
from . import utils

KEY_MODULES=["ai_training_os.core","ai_training_os.api_server","ai_training_os.data_engine","ai_training_os.training_engine","ai_training_os.evaluation_engine","ai_training_os.red_team","ai_training_os.ai_council","ai_training_os.ai_scientist","ai_training_os.llm_finetune"]

class HealthSuite:
    def __init__(self, app): self.app=app
    def run(self, include_llm=True) -> dict:
        checks=[]
        def add(name,status,details=None): checks.append({"name":name,"status":status,**(details or {})})
        # SQLite integrity
        try:
            integrity=self.app.conn.execute("PRAGMA integrity_check").fetchone()[0]
            add("sqlite_integrity","PASSED" if integrity=="ok" else "FAILED",{"result":integrity,"truth_status":"REAL"})
        except Exception as exc:add("sqlite_integrity","FAILED",{"cause":str(exc),"truth_status":"FAILED"})
        # Module imports
        for mod in KEY_MODULES:
            try: importlib.import_module(mod); add(f"import:{mod}","PASSED",{"truth_status":"REAL"})
            except Exception as exc:add(f"import:{mod}","FAILED",{"truth_status":"FAILED","cause":f"{type(exc).__name__}: {exc}"})
        # Environment verify (never converts a missing GPU into a failure)
        try:
            from .hardware_manager import HardwareManager
            hw=HardwareManager(self.app.base_dir).status()
            add("environment_scan","PASSED",{"truth_status":"REAL","backend":hw.get("scan",{}).get("training_runtime",{}).get("backend"),"recommended_training":hw.get("recommended_training")})
        except Exception as exc:
            add("environment_scan","FAILED",{"truth_status":"FAILED","cause":str(exc)})
        # Real end-to-end fixture test in an isolated temp workspace.
        fixture=Path(__file__).resolve().parent.parent/"fixtures"/"sample_dataset.csv"
        if fixture.exists():
            try:
                from .core import AITrainingOS
                with tempfile.TemporaryDirectory(prefix="alpha_prime_selftest_") as td:
                    test_app=AITrainingOS(td)
                    pid=test_app.create_project("Alpha Prime self-test")
                    result=test_app.orchestrator.run_tabular_classification(pid,str(fixture),"selftest-dataset","selftest-model","logistic_regression",1)
                    ok=result.get("status")=="REAL" and result.get("training",{}).get("status")=="COMPLETED" and result.get("evaluation_id")
                    details=result if not ok else {"model_version_id":result.get("model_version_id"),"evaluation_id":result.get("evaluation_id"),"safety_gate":result.get("safety_gate",{}).get("final_status")}
                    if ok:
                        try:
                            delivery=self.app.delivery.package_model_version(result.get("model_version_id"))
                            details["delivery"]={"status":delivery.get("status"),"sha256":delivery.get("sha256"),"path":delivery.get("path")}
                        except Exception as exc:
                            ok=False
                            details["delivery"]={"status":"FAILED","cause":f"{type(exc).__name__}: {exc}"}
                    add("end_to_end_training","PASSED" if ok else "FAILED",{"truth_status":"SIMULATED (TEST)","details":details})
            except Exception as exc:add("end_to_end_training","FAILED",{"truth_status":"SIMULATED (TEST)","cause":f"{type(exc).__name__}: {exc}","trace":traceback.format_exc()[-2000:]})
        else:add("end_to_end_training","SKIPPED",{"truth_status":"SIMULATED (TEST)","cause":"Fixture local absente."})
        # Local module surface check
        try:
            from .delivery import DeliveryManager
            from .dataset_studio import DatasetStudio
            from .dependency_manager import matrix as dependency_matrix
            add("professional_services","PASSED",{"truth_status":"REAL","services":["DatasetStudio","DeliveryManager","DependencyManager","LLMHealth"]})
        except Exception as exc:
            add("professional_services","FAILED",{"truth_status":"FAILED","cause":str(exc)})
        deps=dependency_matrix()
        add("llm_stack", "PASSED" if all(v["available"] for k,v in deps["packages"].items() if v["required"]) else "UNAVAILABLE", {"truth_status":"REAL","packages":deps["packages"]})
        if include_llm:
            try:
                lh=self.app.llm_health.verify_all_tasks()
                add("llm_task_profiles",lh.get("status","FAILED"),{"truth_status":lh.get("truth_status","FAILED"),"details":lh})
            except Exception as exc:add("llm_task_profiles","FAILED",{"truth_status":"FAILED","cause":str(exc)})
        failed=[c for c in checks if c["status"]=="FAILED"]
        unavailable=[c for c in checks if c["status"]=="UNAVAILABLE"]
        status="PASSED" if not failed and not unavailable else ("PARTIAL" if not failed else "FAILED")
        return {"status":status,"truth_status":"REAL","checks":checks,"failed_count":len(failed),"unavailable_count":len(unavailable),"message":"Suite locale terminée: aucune capacité indisponible n'est transformée en succès."}
