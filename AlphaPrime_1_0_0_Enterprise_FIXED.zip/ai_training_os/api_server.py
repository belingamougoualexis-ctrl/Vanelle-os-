"""api_server.py — serveur HTTP local pour AI Training OS.

Le serveur écoute par défaut uniquement sur 127.0.0.1 et sert le dashboard
ainsi que des routes JSON. Aucune donnée n'est envoyée vers un service externe.
"""
import json
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from .core import AITrainingOS
from .environment import EnvironmentManager, ServerManager, ServerSpec

MAX_BODY_BYTES = 2 * 1024 * 1024
_SERVER_MANAGER = ServerManager()


class AITOSRequestHandler(BaseHTTPRequestHandler):
    server_version = "AITrainingOS/1.0-local"

    def log_message(self, fmt, *args):
        # Journal serveur minimal et non intrusif.
        print(f"[AITrainingOS] {self.address_string()} - {fmt % args}")

    @property
    def base_dir(self):
        return self.server.base_dir

    def _app(self):
        # Connexion SQLite indépendante par requête: évite qu'un long Council
        # bloque les lectures du dashboard et reste compatible avec le serveur
        # multi-thread local.
        return AITrainingOS(self.base_dir)

    def _send(self, status, payload, content_type="application/json; charset=utf-8"):
        body = payload if isinstance(payload, (bytes, bytearray)) else (
            json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        )
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json_body(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ValueError("Content-Length invalide")
        if length < 0 or length > MAX_BODY_BYTES:
            raise ValueError("Corps de requête trop volumineux")
        raw = self.rfile.read(length)
        if not raw:
            return {}
        return json.loads(raw.decode("utf-8"))

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        try:
            path = urlparse(self.path).path.rstrip("/") or "/"
            qs = parse_qs(urlparse(self.path).query)
            if path == "/":
                return self._serve_dashboard()
            if path == "/assets/alpha-prime-eagle.jpg":
                return self._serve_asset("alpha-prime-eagle.jpg", "image/jpeg")
            if path == "/api/health":
                app = self._app()
                return self._send(200, {"status": "REAL", "service": "AI Training OS", "council": app.council.status()})
            if path == "/api/dashboard":
                app = self._app()
                data = app.dashboard(qs.get("project_id", [None])[0])
                data["council"] = app.council.status()
                data["red_team"] = app.red_team.status()
                data["scientist"] = app.scientist.status()
                data["projects"] = self._projects(app)
                return self._send(200, data)
            if path == "/api/projects":
                app = self._app()
                return self._send(200, {"status": "REAL", "projects": self._projects(app)})
            if path == "/api/council/status":
                return self._send(200, self._app().council.status())
            if path == "/api/system":
                app = self._app(); return self._send(200, app.orchestrator.inspect())
            if path == "/api/capabilities/data":
                return self._send(200, __import__("ai_training_os.data_engine", fromlist=["capabilities"]).capabilities())
            if path == "/api/observability":
                app=self._app(); return self._send(200, app.observability.snapshot(app.base_dir))
            if path == "/api/jobs":
                app=self._app(); return self._send(200,{"status":"REAL","jobs":app.jobs.list_jobs()})
            if path == "/api/experiments":
                app=self._app(); pid=qs.get("project_id",[None])[0]; return self._send(200,{"status":"REAL","experiments":app.experiments.list_for_project(pid) if pid else [dict(r) for r in app.conn.execute("SELECT * FROM experiments ORDER BY created_at DESC LIMIT 100").fetchall()]})
            if path == "/api/missions":
                app=self._app(); pid=qs.get("project_id",[None])[0]
                sql="SELECT id,project_id,raw_request,problem_type,data_type,model_strategy,training_strategy,training_plan_json,created_at FROM ai_missions"
                args=[]
                if pid: sql += " WHERE project_id=?"; args.append(pid)
                sql += " ORDER BY created_at DESC LIMIT 100"
                rows=[]
                for row in app.conn.execute(sql,args).fetchall():
                    item=dict(row)
                    try: item["training_plan"]=json.loads(item.pop("training_plan_json") or "{}")
                    except Exception: item["training_plan"]={}
                    rows.append(item)
                return self._send(200,{"status":"REAL","missions":rows})
            if path == "/api/training/options":
                app=self._app(); pid=qs.get("project_id",[None])[0]
                if not pid: return self._send(400,self._error_payload("project_id est obligatoire", "La configuration d'entraînement dépend d'un projet local.", "Sélectionnez ou créez un projet avant de préparer un entraînement."))
                self._require_project(app,pid)
                versions=app.conn.execute(
                    "SELECT dv.id,dv.dataset_id,dv.version_number,dv.file_path,dv.n_rows,dv.n_cols,dv.status,dv.metadata_json,dv.created_at,d.name AS dataset_name FROM dataset_versions dv JOIN datasets d ON d.id=dv.dataset_id WHERE d.project_id=? ORDER BY dv.created_at DESC", (pid,)).fetchall()
                base_models=app.conn.execute(
                    "SELECT mv.id,mv.model_id,mv.version_number,mv.status,mv.file_path,mv.metrics_json,m.name AS model_name,m.architecture FROM model_versions mv JOIN models m ON mv.model_id=m.id WHERE m.project_id=? ORDER BY mv.created_at DESC LIMIT 100", (pid,)).fetchall()
                modality=None; data_stats=None; candidate_rows=[]
                dvid=qs.get("dataset_version_id",[None])[0]
                if dvid:
                    dv=app.datasets.get_version(dvid)
                    if not dv: return self._send(400,self._error_payload("Version de dataset introuvable", "L'identifiant sélectionné ne correspond à aucune version locale.", "Actualisez les datasets et choisissez une version existante."))
                    try:
                        _, _, _, _, layout=app.orchestrator._read_rows(dv)
                        data_stats={"n_rows":int(dv["n_rows"]),"n_cols":int(dv["n_cols"]),"n_features":len(layout.get("feature_cols",[])),"modality":layout.get("modality"),"torch_available":app.orchestrator._torch_available()}
                        modality=layout.get("modality")
                        cp=app.compute_planner.plan(data_stats["n_rows"], data_stats["n_features"])
                        for model_type in app.model_engine.SUPPORTED.get("classification",[]):
                            plan=app.model_engine.plan("classification",data_stats,cp,model_type)
                            candidate_rows.append({"model_type":model_type,"status":plan.get("status"),"selected_provider":plan.get("selected_provider"),"reason":plan.get("reason"),"compute_tier":plan.get("compute_tier")})
                    except Exception as exc:
                        candidate_rows=[{"model_type":m,"status":"UNAVAILABLE","reason":str(exc)} for m in app.model_engine.SUPPORTED.get("classification",[])]
                else:
                    candidate_rows=[{"model_type":m,"status":"PENDING","reason":"Sélectionnez une version de dataset pour vérifier la compatibilité réelle."} for m in app.model_engine.SUPPORTED.get("classification",[])]
                return self._send(200,{"status":"REAL","dataset_versions":[dict(v) for v in versions],"base_models":[dict(v) for v in base_models],"problem_type":"classification","modality":modality,"data_stats":data_stats,"candidates":candidate_rows})
            if path == "/api/datasets":
                app=self._app(); pid=qs.get("project_id",[None])[0]; sql="SELECT d.*,COUNT(v.id) AS versions_count FROM datasets d LEFT JOIN dataset_versions v ON v.dataset_id=d.id"; args=[];
                if pid: sql += " WHERE d.project_id=?"; args.append(pid)
                sql += " GROUP BY d.id ORDER BY d.created_at DESC"; rows=app.conn.execute(sql,args).fetchall(); return self._send(200,{"status":"REAL","datasets":[dict(r) for r in rows]})
            if path == "/api/dataset-versions":
                app=self._app(); did=qs.get("dataset_id",[None])[0]
                rows=app.conn.execute("SELECT * FROM dataset_versions WHERE dataset_id=? ORDER BY version_number DESC",(did,)).fetchall() if did else app.conn.execute("SELECT * FROM dataset_versions ORDER BY created_at DESC LIMIT 100").fetchall()
                return self._send(200,{"status":"REAL","versions":[dict(r) for r in rows]})
            if path == "/api/models":
                app=self._app(); pid=qs.get("project_id",[None])[0]; sql="SELECT m.*,COUNT(mv.id) AS versions_count FROM models m LEFT JOIN model_versions mv ON mv.model_id=m.id"; args=[];
                if pid: sql += " WHERE m.project_id=?"; args.append(pid)
                sql += " GROUP BY m.id ORDER BY m.created_at DESC"; rows=app.conn.execute(sql,args).fetchall(); return self._send(200,{"status":"REAL","models":[dict(r) for r in rows]})
            if path == "/api/model-versions":
                app=self._app(); mid=qs.get("model_id",[None])[0]; pid=qs.get("project_id",[None])[0]
                if mid:
                    rows=app.conn.execute("SELECT * FROM model_versions WHERE model_id=? ORDER BY version_number DESC",(mid,)).fetchall()
                elif pid:
                    rows=app.conn.execute("SELECT mv.* FROM model_versions mv JOIN models m ON mv.model_id=m.id WHERE m.project_id=? ORDER BY mv.created_at DESC LIMIT 100",(pid,)).fetchall()
                else:
                    rows=app.conn.execute("SELECT * FROM model_versions ORDER BY created_at DESC LIMIT 100").fetchall()
                return self._send(200,{"status":"REAL","versions":[dict(r) for r in rows]})
            if path == "/api/model-version/verify":
                mvid=qs.get("model_version_id",[None])[0]
                if not mvid: return self._send(400,self._error_payload("model_version_id est obligatoire","La vérification concerne une version précise.","Sélectionnez une version du registre."))
                app=self._app(); mv=app.models.get_version(mvid)
                if not mv: return self._send(404,self._error_payload("Version de modèle introuvable","L'identifiant n'existe pas dans SQLite.","Actualisez le registre des modèles."))
                path=mv.get("file_path"); exists=bool(path and os.path.isfile(path)); sha_ok=False
                if exists and mv.get("sha256"): sha_ok=__import__("ai_training_os.utils",fromlist=["sha256_file"]).sha256_file(path)==mv["sha256"]
                return self._send(200,{"status":"REAL","truth_status":"REAL","model_version_id":mvid,"artifact_exists":exists,"sha256_verified":sha_ok,"artifact_path":path,"model_status":mv.get("status"),"ready":bool(exists and (not mv.get("sha256") or sha_ok))})
            if path == "/api/model-genome":
                mvid=self._required(qs,"model_version_id") if False else qs.get("model_version_id",[None])[0]
                if not mvid: return self._send(400,{"status":"FAILED","error":"model_version_id est obligatoire"})
                return self._send(200,self._app().model_genome.build(mvid))
            if path == "/api/local-models":
                app=self._app(); return self._send(200,{"status":"REAL","provider":app.llm_provider.status(),"models":app.llm_provider.available_models(),"bootstrap":app.startup.status(),"finetuning":app.llm_finetune.status()})
            if path == "/api/finetuning/status":
                app=self._app(); return self._send(200,app.llm_finetune.status())
            if path == "/api/llm/config":
                app=self._app(); return self._send(200, app.llm_health.config())
            if path == "/api/llm/verify-tasks":
                app=self._app(); return self._send(200, app.llm_health.verify_all_tasks())
            if path == "/api/llm/preflight":
                app=self._app(); return self._send(200, app.llm_health.preflight())
            if path == "/api/llm/training-models":
                app=self._app(); return self._send(200, {"status":"REAL","models":app.llm_finetune.available_base_models()})
            if path == "/api/dependencies":
                return self._send(200, __import__("ai_training_os.dependency_manager", fromlist=["matrix"]).matrix())
            if path == "/api/system/full-test":
                app=self._app(); return self._send(200, app.health_suite.run(include_llm=True))
            if path == "/api/dataset-studio/inspect":
                dsv=qs.get("dataset_version_id",[None])[0]
                if not dsv: return self._send(400,self._error_payload("dataset_version_id est obligatoire","Le Studio de données travaille sur une version précise.","Sélectionnez une version de dataset puis relancez l'inspection."))
                return self._send(200,self._app().dataset_studio.inspect(dsv))
            if path == "/api/dataset-studio/clean-preview":
                dsv=qs.get("dataset_version_id",[None])[0]
                if not dsv: return self._send(400,self._error_payload("dataset_version_id est obligatoire","Aucune version n'a été sélectionnée.","Sélectionnez une version de dataset."))
                return self._send(200,self._app().dataset_studio.preview_cleaning(dsv))
            if path == "/api/validation-gate":
                mvid=qs.get("model_version_id",[None])[0]
                if not mvid: return self._send(400,self._error_payload("model_version_id est obligatoire","La Safety Gate s'applique à une version de modèle.","Sélectionnez une version de modèle."))
                app=self._app(); row=app.conn.execute("SELECT * FROM safety_gate_reviews WHERE model_version_id=? ORDER BY created_at DESC LIMIT 1",(mvid,)).fetchone()
                if not row: return self._send(200,{"status":"PENDING","truth_status":"REAL","model_version_id":mvid,"message":"Aucune revue n'a encore été exécutée."})
                item=dict(row); item["details"]=__import__("ai_training_os.utils",fromlist=["loads"]).loads(item.pop("details_json") or "{}")
                return self._send(200,{"status":"REAL","truth_status":"REAL","review":item})
            if path == "/api/delivery":
                app=self._app(); rows=app.conn.execute("SELECT * FROM artifacts WHERE kind='delivery' ORDER BY created_at DESC LIMIT 50").fetchall()
                return self._send(200,{"status":"REAL","deliveries":[dict(r) for r in rows]})
            if path == "/api/delivery/download":
                aid=qs.get("id",[None])[0]
                if not aid: return self._send(400,self._error_payload("id est obligatoire","Aucun artefact de livraison n'a été sélectionné.","Sélectionnez une livraison dans le registre."))
                app=self._app(); row=app.conn.execute("SELECT * FROM artifacts WHERE id=? AND kind='delivery'",(aid,)).fetchone()
                if not row: return self._send(404,self._error_payload("Livraison introuvable","L'artefact n'existe plus dans le workspace local.","Actualisez le registre puis recréez la livraison si nécessaire."))
                path_file=row["path"]
                if not os.path.isfile(path_file): return self._send(410,self._error_payload("Fichier de livraison absent","Le fichier enregistré n'est plus présent sur le disque.","Relancez la préparation de la livraison."))
                with open(path_file,"rb") as f: data=f.read()
                self.send_response(200); self.send_header("Content-Type","application/zip"); self.send_header("Content-Length",str(len(data))); self.send_header("Content-Disposition",f'attachment; filename="{os.path.basename(path_file)}"'); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(data); return
            if path == "/api/startup/status":
                return self._send(200, self._app().startup.status())
            if path == "/api/environment/status":
                return self._send(200, EnvironmentManager(self.base_dir).inspect())
            if path == "/api/environment/verify":
                return self._send(200, EnvironmentManager(self.base_dir).verify())
            if path == "/api/environment/full-status":
                return self._send(200, self._app().hardware.status())
            if path == "/api/servers":
                return self._send(200, {"status":"REAL","servers":_SERVER_MANAGER.list()})
            if path == "/api/server/inspect":
                sid=qs.get("server_id",[None])[0]
                spec=_SERVER_MANAGER.nodes.get(sid) if sid else None
                if not spec: return self._send(404,{"status":"FAILED","error":"Serveur introuvable"})
                result=_SERVER_MANAGER.inspect_ssh(spec)
                if result.get("status")=="REAL": result["deployment_plan"]=_SERVER_MANAGER.deployment_plan(result)
                return self._send(200,result)
            if path == "/api/champion":
                app=self._app(); pid=qs.get("project_id",[None])[0]; return self._send(200,{"status":"REAL","champion":app.champion_challenger.get_champion(pid) if pid else None})
            if path == "/api/deployments":
                app=self._app(); rows=app.conn.execute("SELECT * FROM deployments ORDER BY created_at DESC LIMIT 100").fetchall(); return self._send(200,{"status":"REAL","deployments":[dict(r) for r in rows]})
            if path == "/api/backups":
                app=self._app(); rows=app.conn.execute("SELECT * FROM backup_runs ORDER BY created_at DESC LIMIT 100").fetchall(); return self._send(200,{"status":"REAL","backups":[dict(r) for r in rows]})
            if path == "/api/auto-lab":
                app=self._app(); rows=app.conn.execute("SELECT * FROM autolab_runs ORDER BY started_at DESC LIMIT 50").fetchall(); return self._send(200,{"status":"REAL","runs":[dict(r) for r in rows]})
            if path == "/api/synthetic":
                app=self._app(); pid=qs.get("project_id",[None])[0]
                rows=app.conn.execute("SELECT * FROM synthetic_data_runs" + (" WHERE project_id=?" if pid else "") + " ORDER BY created_at DESC LIMIT 50", (pid,) if pid else ()).fetchall()
                return self._send(200,{"status":"REAL","runs":[dict(r) for r in rows]})
            if path == "/api/artifacts":
                app=self._app(); pid=qs.get("project_id",[None])[0]
                rows=app.conn.execute("SELECT * FROM artifacts" + (" WHERE project_id=?" if pid else "") + " ORDER BY created_at DESC LIMIT 100", (pid,) if pid else ()).fetchall()
                return self._send(200,{"status":"REAL","artifacts":[dict(r) for r in rows]})
            if path == "/api/continuous-training":
                app=self._app(); pid=qs.get("project_id",[None])[0]
                rows=app.conn.execute("SELECT * FROM continuous_training_runs" + (" WHERE project_id=?" if pid else "") + " ORDER BY created_at DESC LIMIT 50", (pid,) if pid else ()).fetchall()
                return self._send(200,{"status":"REAL","runs":[dict(r) for r in rows]})
            if path == "/api/champion/compare":
                app=self._app(); a=self._required(qs,"champion_model_version_id"); b=self._required(qs,"challenger_model_version_id")
                ev_raw=qs.get("evaluation_id",[])
                return self._send(200,app.champion_challenger.compare(a,b,ev_raw))
            if path == "/api/security":
                app=self._app(); return self._send(200,{"status":"REAL","code_execution":app.security.code_execution_status(),"dependencies":app.security.dependency_report(["numpy","pandas","sklearn","torch","transformers","llama_cpp","pypdf","PIL","soundfile","cv2"])})
            if path == "/api/enterprise":
                app=self._app(); pid=qs.get("project_id",[None])[0]
                if not pid: return self._send(400,self._error_payload("project_id est obligatoire","Les contrôles entreprise sont liés à un projet local.","Sélectionnez un projet."))
                self._require_project(app,pid); return self._send(200,app.enterprise.list(pid))
            if path == "/api/governance/profile":
                app=self._app(); dsv=self._required_query(qs,"dataset_version_id"); return self._send(200,app.enterprise.profile_dataset(dsv))
            if path == "/api/governance/lineage":
                app=self._app(); pid=self._required_query(qs,"project_id"); self._require_project(app,pid); return self._send(200,app.enterprise.lineage(pid))
            if path == "/api/governance/model-card":
                app=self._app(); card_id=self._required_query(qs,"id"); row=app.conn.execute("SELECT * FROM model_cards WHERE id=?",(card_id,)).fetchone()
                if not row: return self._send(404,self._error_payload("Model Card introuvable","Aucun artefact local ne correspond à cet identifiant.","Générez une Model Card depuis Governance."))
                path_file=row["path"]
                if not os.path.isfile(path_file): return self._send(410,self._error_payload("Model Card absente","Le fichier enregistré n'existe plus sur le disque.","Régénérez la Model Card."))
                with open(path_file,"rb") as f: data=f.read()
                return self._send(200,data,"text/markdown; charset=utf-8")
            if path == "/api/error-clusters":
                app=self._app(); project_id=qs.get("project_id",[None])[0]
                sql="SELECT ec.* FROM error_clusters ec JOIN evaluations ev ON ec.evaluation_id=ev.id JOIN model_versions mv ON ev.model_version_id=mv.id JOIN models m ON mv.model_id=m.id"
                args=[]
                if project_id: sql += " WHERE m.project_id=?"; args.append(project_id)
                sql += " ORDER BY ec.created_at DESC LIMIT 200"
                rows=app.conn.execute(sql,args).fetchall(); return self._send(200,{"status":"REAL","clusters":[dict(r) for r in rows]})
            if path == "/api/evaluations":
                app = self._app()
                project_id = qs.get("project_id", [None])[0]
                sql = """SELECT ev.id, ev.model_version_id, ev.dataset_version_id, ev.status, ev.metrics_json, ev.created_at
                         FROM evaluations ev
                         JOIN model_versions mv ON ev.model_version_id=mv.id
                         JOIN models m ON mv.model_id=m.id"""
                args = []
                if project_id:
                    sql += " WHERE m.project_id=?"
                    args.append(project_id)
                sql += " ORDER BY ev.created_at DESC LIMIT 100"
                rows = app.conn.execute(sql, args).fetchall()
                out=[]
                for r in rows:
                    d=dict(r)
                    try:d["metrics"]=json.loads(d.pop("metrics_json") or "{}")
                    except Exception: d["metrics"]={}
                    out.append(d)
                return self._send(200, {"status":"REAL", "evaluations":out})
            if path == "/api/council/sessions":
                app = self._app()
                project_id = qs.get("project_id", [None])[0]
                rows = app.conn.execute(
                    "SELECT * FROM council_sessions" + (" WHERE project_id=?" if project_id else "") + " ORDER BY created_at DESC LIMIT 50",
                    (project_id,) if project_id else (),
                ).fetchall()
                return self._send(200, {"status": "REAL", "sessions": [dict(r) for r in rows]})
            if path.startswith("/api/council/sessions/"):
                sid = path.split("/")[-1]
                app = self._app()
                row = app.conn.execute("SELECT * FROM council_sessions WHERE id=?", (sid,)).fetchone()
                if not row:
                    return self._send(404, {"status": "FAILED", "error": "Council session introuvable"})
                decisions = app.council.list_decisions(sid)
                result = dict(row)
                try:
                    result["llm_status"] = json.loads(result.pop("llm_status_json") or "{}")
                except Exception:
                    pass
                result["decisions"] = decisions
                return self._send(200, {"status": "REAL", "session": result})
            if path == "/api/red-team/status":
                return self._send(200, self._app().red_team.status())
            if path == "/api/red-team/runs":
                app = self._app()
                return self._send(200, {"status": "REAL", "runs": app.red_team.list_runs(qs.get("project_id", [None])[0])})
            if path.startswith("/api/red-team/runs/"):
                rid = path.split("/")[-1]
                run = self._app().red_team.get_run(rid)
                if not run:
                    return self._send(404, {"status": "FAILED", "error": "Red Team run introuvable"})
                return self._send(200, run)
            if path == "/api/scientist/status":
                return self._send(200, self._app().scientist.status())
            if path == "/api/scientist/reports":
                app = self._app()
                return self._send(200, {"status": "REAL", "reports": app.scientist.list_reports(qs.get("project_id", [None])[0])})
            return self._send(404, {"status": "FAILED", "error": "Route introuvable"})
        except ValueError as exc:
            msg=str(exc)
            return self._send(400, self._error_payload(msg, self._infer_cause(msg), self._infer_solution(msg)))
        except Exception as exc:
            msg=f"{type(exc).__name__}: {exc}"
            return self._send(500, self._error_payload(msg, self._infer_cause(msg), self._infer_solution(msg)))

    def do_POST(self):
        try:
            path = urlparse(self.path).path.rstrip("/") or "/"
            body = self._json_body()
            app = self._app()
            if path == "/api/projects":
                name = str(body.get("name", "")).strip()
                if not name:
                    return self._send(400, {"status": "FAILED", "error": "name est obligatoire"})
                pid = app.create_project(name)
                return self._send(201, {"status": "REAL", "project_id": pid})
            if path == "/api/datasets/import":
                pid=self._required(body,"project_id"); self._require_project(app,pid); name=self._required(body,"name"); src=self._required(body,"source_path")
                ds_id=app.datasets.create_dataset(pid,name,src); dv_id,result=app.datasets.import_version(ds_id,src)
                return self._send(201,{"status":"REAL","dataset_id":ds_id,"dataset_version_id":dv_id,"result":result})
            if path == "/api/missions/analyze":
                pid = self._required(body, "project_id")
                raw = self._required(body, "raw_request")
                self._require_project(app, pid)
                return self._send(201, {"status": "REAL", "mission": app.missions.analyze(pid, raw)})
            if path == "/api/council/convene":
                pid = self._required(body, "project_id")
                raw = self._required(body, "raw_request")
                self._require_project(app, pid)
                context = body.get("context") or self._real_context(app, pid)
                mission_id = body.get("mission_id")
                if mission_id:
                    result = app.council.convene(pid, raw, context, mission_id=mission_id)
                    if result.get("status") == "COMPLETED":
                        self._link_pm(app, result.get("decisions", []), mission_id)
                else:
                    result = app.council.convene_and_create_training_plan(pid, raw, context)
                return self._send(200, {"status": result.get("status", "FAILED"), "council": result})
            if path == "/api/servers/register":
                sid=self._required(body,"id"); host=self._required(body,"host")
                spec=ServerSpec(id=sid,host=host,port=int(body.get("port",22)),user=str(body.get("user", "")),agent_url=body.get("agent_url"),enabled=bool(body.get("enabled",True)))
                return self._send(201,{"status":"REAL","server":_SERVER_MANAGER.register(spec)})
            if path == "/api/servers/remove":
                sid=self._required(body,"id"); return self._send(200,{"status":"REAL","removed":_SERVER_MANAGER.remove(sid)})
            if path == "/api/startup/install":
                return self._send(200, self._app().startup.consent_and_start())
            if path == "/api/startup/retry":
                app=self._app(); app.startup.state["status"]="PENDING"; app.startup.state["last_error"]=None; app.startup._save(); return self._send(200, app.startup.start())
            if path == "/api/llm/prepare":
                from .dependency_manager import ensure
                dep=ensure()
                if dep.get("status")!="REAL": return self._send(200,dep)
                start=app.startup.start()
                verify=app.llm_health.preflight()
                status="REAL" if verify.get("status")=="REAL" else ("UNAVAILABLE" if verify.get("status")=="UNAVAILABLE" else "FAILED")
                return self._send(200,{"status":status,"truth_status":"REAL","dependencies":dep,"startup":start,"llm":verify})
            if path == "/api/local-models/select":
                model=self._required(body,"model"); return self._send(200,self._app().llm_provider.set_model(model,body.get("backend")))
            if path == "/api/llm/config":
                app=self._app(); cfg=body.get("generation_profiles")
                if not isinstance(cfg,dict): raise ValueError("generation_profiles doit être un objet")
                # Only merge known profiles; arbitrary keys are ignored to keep the contract stable.
                for name in ("council","scientist","verification","general"):
                    if isinstance(cfg.get(name),dict): app.llm_provider.config.setdefault("profiles",{}).setdefault(name,{}).update(cfg[name])
                import json as _json, os as _os
                _os.makedirs(_os.path.dirname(app.llm_provider.config_path),exist_ok=True)
                with open(app.llm_provider.config_path,"w",encoding="utf-8") as f: _json.dump(app.llm_provider.config,f,ensure_ascii=False,indent=2)
                return self._send(200,{"status":"REAL","config":app.llm_health.config()})
            if path == "/api/dependencies/install":
                from .dependency_manager import ensure
                return self._send(200, ensure(body.get("packages")))
            if path == "/api/dataset-studio/apply-cleaning":
                dsv=self._required(body,"dataset_version_id")
                result=app.dataset_studio.apply_cleaning(dsv, bool(body.get("drop_duplicates",True)), bool(body.get("drop_missing",True)), bool(body.get("exclude_corrupted",True)))
                return self._send(201,result)
            if path == "/api/governance/contract/create":
                pid=self._required(body,"project_id"); self._require_project(app,pid)
                return self._send(201,app.enterprise.create_contract(pid,self._required(body,"dataset_version_id"),body.get("thresholds") or {}))
            if path == "/api/governance/contract/validate":
                return self._send(200,app.enterprise.validate_contract(self._required(body,"dataset_version_id"),body.get("contract_id")))
            if path == "/api/governance/drift":
                pid=body.get("project_id")
                if pid: self._require_project(app,pid)
                return self._send(200,app.enterprise.drift(self._required(body,"baseline_dataset_version_id"),self._required(body,"candidate_dataset_version_id"),pid))
            if path == "/api/governance/model-card":
                pid=self._required(body,"project_id"); self._require_project(app,pid)
                return self._send(201,app.enterprise.generate_model_card(pid,self._required(body,"model_version_id")))
            if path == "/api/governance/eval-suite/create":
                pid=self._required(body,"project_id"); self._require_project(app,pid)
                return self._send(201,app.enterprise.create_eval_suite(pid,self._required(body,"name"),self._required(body,"golden_dataset_version_id"),body.get("thresholds") or {}))
            if path == "/api/governance/eval-suite/run":
                return self._send(200,app.enterprise.run_eval_suite(self._required(body,"suite_id"),self._required(body,"model_version_id")))
            if path == "/api/environment/prepare":
                return self._send(200, app.hardware.prepare(install_llm_stack=bool(body.get("install_llm_stack",True))))
            if path == "/api/environment/optimize":
                data=EnvironmentManager(self.base_dir).inspect()
                import json as _json, pathlib as _path
                target=_path.Path(self.base_dir)/"environment_plan.json"; target.write_text(_json.dumps(data,ensure_ascii=False,indent=2,default=str),encoding="utf-8")
                return self._send(200,{"status":"REAL","path":str(target),"scan":data["scan"],"plan":data["plan"]})
            if path == "/api/local-models/verify":
                model=self._required(body,"model"); return self._send(200,self._app().llm_provider.verify_model(model,body.get("backend")))
            if path == "/api/finetuning/run":
                app=self._app()
                dataset_path=self._required(body,"dataset_path")
                result=app.llm_finetune.run(dataset_path,output_name=body.get("output_name","alpha-prime-adapter"),method=body.get("method","lora"),epochs=int(body.get("epochs",1)),text_column=body.get("text_column") or None,prompt_column=body.get("prompt_column") or None,response_column=body.get("response_column") or None,learning_rate=float(body.get("learning_rate",2e-4)),batch_size=int(body.get("batch_size",1)),max_length=int(body.get("max_length",512)),test_ratio=float(body.get("test_ratio",0.1)),base_model=body.get("base_model") or None,lora_r=int(body.get("lora_r",16)),lora_alpha=int(body.get("lora_alpha",32)),lora_dropout=float(body.get("lora_dropout",0.05)))
                # When the user launched from a project + registered dataset, promote the real adapter delivery into Model Registry.
                pid=body.get("project_id"); dsv=body.get("dataset_version_id")
                if result.get("status")=="REAL" and pid and dsv:
                    self._require_project(app,pid)
                    dv=app.datasets.get_version(dsv)
                    if not dv: raise ValueError("Version de dataset introuvable")
                    parent=app.conn.execute("SELECT d.project_id,d.name FROM datasets d JOIN dataset_versions v ON v.dataset_id=d.id WHERE v.id=?",(dsv,)).fetchone()
                    if not parent or parent[0]!=pid: raise ValueError("La version de dataset n'appartient pas au projet actif")
                    name=str(body.get("output_name") or "alpha-prime-adapter")
                    arch=f"causal_lm_peft_adapter:{str(body.get('method','lora')).lower()}"
                    model_id=app.models.create_model(pid,name,arch)
                    mv_id=app.models.create_version(model_id,dsv,{"code_version":"local-llm-1","dependencies":{k:"installed-runtime" for k in ("torch","transformers","peft","datasets","accelerate")},"llm_base_model":result.get("base_model"),"method":result.get("method")},{"method":result.get("method"),"lora_config":result.get("lora_config")},{"backend":"LOCAL_TRANSFORMERS","runtime":"PyTorch"},file_path=((result.get("delivery_zip") or {}).get("path")),status="EVALUATING")
                    metrics={"before_eval":result.get("before_eval"),"after_eval":result.get("after_eval"),"smoke_test":result.get("smoke_test"),"trainable_percent":result.get("trainable_percent")}
                    app.models.update_status(mv_id,"EVALUATING",metrics)
                    result["model_version_id"]=mv_id
                    result["model_id"]=model_id
                    result["registry_status"]="REAL"
                return self._send(200,result)
            if path == "/api/training/run":
                pid=self._required(body,"project_id"); self._require_project(app,pid)
                dataset_version_id=self._required(body,"dataset_version_id")
                model_type=str(body.get("model_type") or "auto")
                model_name=str(body.get("model_name") or "local-classifier").strip()
                if not model_name: raise ValueError("model_name est obligatoire")
                result=app.orchestrator.run_tabular_from_dataset_version(
                    pid, dataset_version_id, model_name=model_name, model_type=model_type,
                    n_epochs=int(body.get("n_epochs",3)), security_policy=body.get("security_policy"),
                    base_model_version_id=body.get("base_model_version_id") or None,
                    mission_text=body.get("mission_text"), mission_id=body.get("mission_id") or None,
                )
                return self._send(200,result)
            if path == "/api/training/run-tabular":
                pid=self._required(body,"project_id"); self._require_project(app,pid); src=self._required(body,"source_path")
                result=app.orchestrator.run_tabular_classification(pid,src,body.get("dataset_name","dataset"),body.get("model_name","local-classifier"),body.get("model_type","sgd_incremental"),int(body.get("n_epochs",3)),body.get("security_policy")); return self._send(200,result)
            if path == "/api/training/resume":
                jid=self._required(body,"job_id"); result=app.training.resume(jid); return self._send(200,result)
            if path == "/api/auto-lab/run":
                pid=self._required(body,"project_id"); self._require_project(app,pid)
                source=self._required(body,"source_path")
                candidates=body.get("model_types") or ["sgd_incremental","logistic_regression","random_forest"]
                candidates=[str(x) for x in candidates][:int(body.get("max_experiments",3))]
                plan={"max_experiments":len(candidates),"model_types":candidates,"n_epochs":int(body.get("n_epochs",3)),"security_policy":body.get("security_policy")}
                def run_experiment(i,plan_):
                    model_type=plan_["model_types"][i]
                    return app.orchestrator.run_tabular_classification(pid,source,body.get("dataset_name","autolab-dataset"),f"AutoLab-{model_type}",model_type,int(plan_.get("n_epochs",3)),plan_.get("security_policy"))
                def success(result):
                    threshold=body.get("objective_metric_threshold")
                    metric=body.get("objective_metric","accuracy")
                    if threshold is None: return False
                    metrics=result.get("training",{}).get("metrics") or {}
                    try: return float(metrics.get(metric)) >= float(threshold)
                    except (TypeError,ValueError): return False
                return self._send(200,app.auto_lab.run(pid,plan,run_experiment,success))
            if path == "/api/model-manager/import":
                mid=self._required(body,"model_id"); src=self._required(body,"source_file"); return self._send(201,app.model_manager.import_file(mid,src))
            if path == "/api/model-manager/package":
                mid=self._required(body,"model_id"); src=self._required(body,"source_file"); return self._send(201,app.model_manager.package(mid,src))
            if path == "/api/model-manager/validate":
                mid=self._required(body,"model_id"); return self._send(200,app.model_manager.validate(mid))
            if path == "/api/model-manager/download":
                mid=self._required(body,"model_id"); url=self._required(body,"url"); return self._send(200,app.model_manager.download(mid,url,body.get("expected_sha256"),max_bytes=body.get("max_bytes")))
            if path == "/api/model-manager/repair":
                mid=self._required(body,"model_id"); idx=int(self._required(body,"shard_index")); src=self._required(body,"source_file"); return self._send(200,app.model_manager.repair_shard(mid,idx,src))
            if path == "/api/model-manager/progress":
                mid=self._required(body,"model_id"); return self._send(200,app.model_manager.progress(mid))
            if path == "/api/model-manager/cleanup":
                mid=self._required(body,"model_id"); return self._send(200,app.model_manager.cleanup_temp(mid))
            if path == "/api/model-manager/inspect":
                src=self._required(body,"source_file"); return self._send(200,app.model_manager.inspect_model_file(src))
            if path == "/api/synthetic/bootstrap":
                dsv=self._required(body,"dataset_version_id"); return self._send(201,app.synthetic_lab.generate_bootstrap(dsv,int(body.get("n_rows") or 0) or None,int(body.get("seed",42))))
            if path == "/api/champion/set":
                pid=self._required(body,"project_id"); mvid=self._required(body,"model_version_id"); self._require_project(app,pid); return self._send(200,app.champion_challenger.set_champion(pid,mvid))
            if path == "/api/continuous-training/propose":
                pid=self._required(body,"project_id"); dsv=self._required(body,"dataset_version_id"); self._require_project(app,pid)
                return self._send(201,app.continuous_training.create_cycle(pid,dsv,body.get("base_model_version_id"),body.get("config")))
            if path == "/api/continuous-training/run":
                pid=self._required(body,"project_id"); source=self._required(body,"source_path"); self._require_project(app,pid)
                result=app.continuous_training.run_tabular(
                    app, pid, source, body.get("dataset_name","continuous-data"), body.get("model_name","continuous-model"),
                    body.get("base_model_version_id"), body.get("model_type","auto"), int(body.get("n_epochs",3)), body.get("security_policy")
                )
                return self._send(200,result)
            if path == "/api/continuous-training/mark":
                cid=self._required(body,"cycle_id"); return self._send(200,app.continuous_training.mark(cid,self._required(body,"status"),body.get("model_version_id"),body.get("details")))
            if path == "/api/validation-gate/approve":
                mvid=self._required(body,"model_version_id"); reviewer=self._required(body,"reviewer")
                return self._send(200,app.safety_gate.approve(mvid,reviewer,body.get("comment") or ""))
            if path == "/api/validation-gate/run":
                mvid=self._required(body,"model_version_id"); app=self._app(); row=app.conn.execute("SELECT metrics_json FROM model_versions WHERE id=?",(mvid,)).fetchone()
                if not row: raise ValueError("Version de modèle introuvable")
                metrics=__import__("ai_training_os.utils",fromlist=["loads"]).loads(row["metrics_json"] or "{}")
                policy=body.get("security_policy") or None
                return self._send(200, app.safety_gate.review(mvid,metrics,min_accuracy=float(body.get("min_accuracy",0.5)),security_policy=policy,regression_baseline=body.get("regression_baseline")))
            if path == "/api/delivery/package":
                mvid=self._required(body,"model_version_id"); result=app.delivery.package_model_version(mvid)
                # Also register the delivery as a first-class local artifact so it
                # is downloadable from inside the application.
                row=app.conn.execute("SELECT m.project_id FROM model_versions mv JOIN models m ON mv.model_id=m.id WHERE mv.id=?",(mvid,)).fetchone()
                project_id=row[0] if row else None
                artifact=app.artifacts.put_file(result["path"],"delivery",{"model_version_id":mvid,"project_id":project_id,"sha256":result["sha256"]})
                result.update({"artifact_id":artifact["id"],"download_url":f"/api/delivery/download?id={artifact['id']}"})
                return self._send(201,result)
            if path == "/api/deployment/export":
                mvid=self._required(body,"model_version_id"); target=self._required(body,"output_dir"); return self._send(200,app.deployment.export(mvid,target))
            if path == "/api/deployment/local":
                mvid=self._required(body,"model_version_id"); target=self._required(body,"target_dir"); return self._send(200,app.deployment.deploy_local(mvid,target))
            if path == "/api/backup":
                target=self._required(body,"output_zip"); result=app.disaster_recovery.backup(target); app.conn.execute("INSERT INTO backup_runs (id,workspace,path,sha256,status,metadata_json,created_at) VALUES (?,?,?,?,?,?,?)",((__import__("ai_training_os.utils",fromlist=["new_id"]).new_id("backup")),app.base_dir,target,result["sha256"],"COMPLETED",json.dumps(result),__import__("ai_training_os.utils",fromlist=["now_iso"]).now_iso())); app.conn.commit(); return self._send(201,result)
            if path == "/api/backup/verify":
                target=self._required(body,"backup_zip"); return self._send(200,app.disaster_recovery.verify(target))
            if path == "/api/restore":
                target=self._required(body,"backup_zip"); dest=self._required(body,"target_dir"); return self._send(200,app.disaster_recovery.restore(target,dest))
            if path == "/api/project/import":
                source=self._required(body,"zip_path"); dest=self._required(body,"target_workspace"); return self._send(200,app.exporter.import_project(source,dest))
            if path == "/api/red-team/run":
                evaluation_id = self._required(body, "evaluation_id")
                result = app.red_team.run_for_evaluation(evaluation_id, body.get("project_id"))
                status = 200 if result["status"] in ("COMPLETED", "UNAVAILABLE") else 500
                return self._send(status, result)
            if path == "/api/scientist/analyze":
                pid = self._required(body, "project_id")
                self._require_project(app, pid)
                return self._send(200, app.scientist.analyze(pid))
            return self._send(404, {"status": "FAILED", "error": "Route introuvable"})
        except ValueError as exc:
            msg=str(exc)
            return self._send(400, self._error_payload(msg, self._infer_cause(msg), self._infer_solution(msg)))
        except Exception as exc:
            msg=f"{type(exc).__name__}: {exc}"
            return self._send(500, self._error_payload(msg, self._infer_cause(msg), self._infer_solution(msg)))

    @staticmethod
    def _error_payload(error, cause=None, solution=None):
        return {"status":"FAILED","error":str(error),"message":"L'opération n'a pas pu être terminée.","cause":cause or "Une erreur réelle est survenue pendant l'opération locale.","solution":solution or "Vérifiez les paramètres, les fichiers et les ressources locales, puis réessayez."}

    @staticmethod
    def _infer_cause(message):
        m=str(message).lower()
        if "llm required" in m or "llm local" in m: return "Aucun modèle LLM local compatible n'est prêt, ou le backend local n'est plus disponible."
        if "projet introuvable" in m: return "L'identifiant de projet fourni ne correspond à aucun projet local."
        if "introuvable" in m and "dataset" in m: return "La version ou le fichier dataset demandé n'existe pas dans le workspace local."
        if "source" in m and ("fichier" in m or "dossier" in m): return "Le chemin local fourni est absent, inaccessible ou d'un format non exploitable."
        if "torch" in m or "gpu" in m: return "Le modèle ou le provider demandé dépend d'une capacité GPU/PyTorch qui n'est pas réellement prête."
        if "support" in m and "model_type" in m: return "Le type de modèle demandé n'est pas pris en charge par le moteur ou n'est pas compatible avec les données sélectionnées."
        if "indisponible" in m or "install" in m: return "Une dépendance ou une ressource locale requise n'est pas disponible."
        return "Le backend local a rencontré une condition d'exécution qui a empêché la finalisation."

    @staticmethod
    def _infer_solution(message):
        m=str(message).lower()
        if "llm required" in m or "llm local" in m: return "Ouvrez LLM & Model Manager, installez/importez un modèle local puis vérifiez et sélectionnez-le."
        if "projet introuvable" in m: return "Sélectionnez ou créez un projet local valide dans la barre supérieure, puis réessayez."
        if "introuvable" in m and "dataset" in m: return "Actualisez les datasets et choisissez une version validée du projet actif."
        if "source" in m and ("fichier" in m or "dossier" in m): return "Corrigez le chemin local et lancez d'abord l'import/versioning du dataset."
        if "torch" in m or "gpu" in m: return "Choisissez un modèle CPU compatible ou rendez PyTorch/CUDA réellement opérationnel sur cette machine."
        if "support" in m and "model_type" in m: return "Sélectionnez un type proposé comme compatible pour la modalité du dataset courant."
        if "indisponible" in m or "install" in m: return "Ouvrez Compute/Security/LLM Manager pour voir la dépendance manquante et la résolution locale requise."
        return "Relisez la cause affichée, corrigez le paramètre ou la ressource concernée, puis relancez l'opération."

    def _serve_asset(self, name, content_type):
        asset_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend", "assets", name)
        if not os.path.isfile(asset_path):
            return self._send(404, self._error_payload(f"Asset introuvable: {name}", "Le fichier visuel local n'est pas présent dans la distribution.", "Réinstallez la distribution complète ou restaurez frontend/assets/" + name))
        with open(asset_path, "rb") as f: body=f.read()
        return self._send(200, body, content_type)

    def _serve_dashboard(self):
        dashboard_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend", "dashboard.html")
        with open(dashboard_path, "rb") as f:
            body = f.read()
        return self._send(200, body, "text/html; charset=utf-8")

    @staticmethod
    def _required_query(qs, key):
        value = qs.get(key, [None])[0]
        if value is None or str(value).strip() == "":
            raise ValueError(f"{key} est obligatoire")
        return value

    @staticmethod
    def _required(body, key):
        value = body.get(key)
        if value is None or str(value).strip() == "":
            raise ValueError(f"{key} est obligatoire")
        return value

    @staticmethod
    def _require_project(app, project_id):
        row = app.conn.execute("SELECT id FROM projects WHERE id=?", (project_id,)).fetchone()
        if not row:
            raise ValueError(f"Projet introuvable: {project_id}")

    @staticmethod
    def _projects(app):
        rows = app.conn.execute(
            "SELECT p.*, (SELECT COUNT(*) FROM experiments e WHERE e.project_id=p.id) AS experiments_count, "
            "(SELECT COUNT(*) FROM datasets d WHERE d.project_id=p.id) AS datasets_count, "
            "(SELECT COUNT(*) FROM models m WHERE m.project_id=p.id) AS models_count "
            "FROM projects p ORDER BY p.created_at DESC"
        ).fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    def _real_context(app, project_id):
        dashboard = app.dashboard(project_id)
        history = app.conn.execute(
            "SELECT id,status,provider,metrics_json,created_at FROM experiments WHERE project_id=? ORDER BY created_at DESC LIMIT 20",
            (project_id,),
        ).fetchall()
        return {
            "hardware": dashboard["compute"],
            "compute_plan": dashboard["compute_plan"],
            "project_counts": dashboard["counts"],
            "experiments": [dict(r) for r in history],
        }

    @staticmethod
    def _link_pm(app, decisions, mission_id):
        pm = next((d for d in decisions if d.get("agent_role") == "project_manager" or d.get("role") == "project_manager"), None)
        if pm:
            did = pm.get("id") or pm.get("decision_id")
            if did:
                app.conn.execute(
                    "UPDATE council_decisions SET artifact_type=?, artifact_id=? WHERE id=?",
                    ("training_plan", mission_id, did),
                )
                app.conn.commit()


def create_server(base_dir: str, host="127.0.0.1", port=8787):
    os.makedirs(base_dir, exist_ok=True)
    server = ThreadingHTTPServer((host, int(port)), AITOSRequestHandler)
    server.base_dir = os.path.abspath(base_dir)
    return server


def serve_forever(base_dir: str, host="127.0.0.1", port=8787):
    # Start the HTTP UI first, then prepare the Python LLM stack and models in a
    # background thread. The first launch therefore remains usable while long
    # downloads/installations proceed, and readiness is still truthful.
    server = create_server(base_dir, host, port)
    def _bootstrap():
        try:
            AITrainingOS(base_dir).startup.auto_start()
        except Exception as exc:
            print(f"[AITrainingOS] Bootstrap automatique non démarré: {exc}")
    threading.Thread(target=_bootstrap, name="alpha-prime-bootstrap", daemon=True).start()
    print(f"AI Training OS — serveur local REAL: http://{host}:{server.server_address[1]}/")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()
        server.server_close()
