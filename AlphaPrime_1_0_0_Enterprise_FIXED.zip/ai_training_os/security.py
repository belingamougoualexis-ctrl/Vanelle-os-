"""Local security controls: validation, path confinement, secret redaction, dependency checks."""
import os, re, hashlib
from . import utils

class SecurityEngine:
    def __init__(self, workspace, audit=None): self.workspace=os.path.abspath(workspace); self.audit=audit
    def validate_path(self, path, must_exist=False):
        p=os.path.abspath(path)
        inside=os.path.commonpath([self.workspace,p])==self.workspace
        exists=os.path.exists(p)
        ok=inside and (exists or not must_exist)
        return {"status":"REAL" if ok else "FAILED","path":p,"inside_workspace":inside,"exists":exists,"allowed":ok}
    def sha256(self,path): return utils.sha256_file(path)
    def dependency_report(self, names):
        import importlib.util
        return {n:{"status":"REAL" if importlib.util.find_spec(n) else "UNAVAILABLE","installed":bool(importlib.util.find_spec(n))} for n in names}
    def redact(self, text):
        patterns=[r'(?i)(api[_-]?key\s*[:=]\s*)[^\s,;]+',r'(?i)(token\s*[:=]\s*)[^\s,;]+',r'(?i)(password\s*[:=]\s*)[^\s,;]+']
        out=text
        for pat in patterns: out=re.sub(pat, r'\1[REDACTED]', out)
        return out
    def static_file_check(self,path,max_bytes=None):
        if not os.path.isfile(path): return {"status":"FAILED","reason":"fichier absent"}
        size=os.path.getsize(path)
        ok=max_bytes is None or size<=max_bytes
        return {"status":"REAL" if ok else "FAILED","size_bytes":size,"max_bytes":max_bytes,"allowed":ok,"sha256":utils.sha256_file(path)}
    def code_execution_status(self):
        return {"status":"UNAVAILABLE","reason":"Aucun sandbox OS dédié n'est configuré; le système n'exécute pas arbitrairement du code utilisateur."}
