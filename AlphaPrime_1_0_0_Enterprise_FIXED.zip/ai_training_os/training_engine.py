"""Training orchestration with real checkpoints and real resume where the provider supports it."""
import os, time, json
from . import utils
from .providers import get_provider
from .providers.local_cpu import TrainingInterrupted
from . import compute

class TrainingEngine:
    def __init__(self, conn, job_engine, experiment_registry, checkpoint_root, audit=None): self.conn=conn; self.job_engine=job_engine; self.experiments=experiment_registry; self.checkpoint_root=checkpoint_root; self.audit=audit; os.makedirs(checkpoint_root,exist_ok=True)
    def run(self, experiment_id, provider_name, config):
        provider=get_provider(provider_name); av=provider.is_available(); job_id=self.job_engine.create_job(experiment_id,"TRAINING",provider_name,config)
        if not av["available"]:
            self.job_engine.set_status(job_id,"FAILED"); self.experiments.fail(experiment_id,f"UNAVAILABLE — DEPENDENCY REQUIRED: {av['reason']}"); return {"job_id":job_id,"status":"UNAVAILABLE","truth_status":"UNAVAILABLE","reason":av["reason"]}
        work=dict(config); work["checkpoint_dir"]=os.path.join(self.checkpoint_root,job_id); os.makedirs(work["checkpoint_dir"],exist_ok=True); log_path=os.path.join(work["checkpoint_dir"],"training.jsonl")
        self.job_engine.set_status(job_id,"RUNNING"); self.experiments.start(experiment_id);
        exp_row0=self.conn.execute("SELECT model_version_id FROM experiments WHERE id=?",(experiment_id,)).fetchone();
        if exp_row0 and exp_row0[0]: self.conn.execute("UPDATE model_versions SET status='TRAINING' WHERE id=?",(exp_row0[0],)); self.conn.commit()
        t0=time.time()
        def log(event):
            with open(log_path,"a",encoding="utf-8") as f:f.write(json.dumps({"timestamp":utils.now_iso(),**event},ensure_ascii=False,default=str)+"\n")
        def on_checkpoint(epoch,state):
            p=state.get("path");
            if p: self.job_engine.record_checkpoint(job_id,epoch,p,state.get("metrics",{}))
            self.job_engine.set_status(job_id,"RUNNING",progress=float(state.get("progress",0.0)),last_epoch=epoch); log({"event":"checkpoint","epoch":epoch,"metrics":state.get("metrics",{})})
        try: result=provider.train(work,checkpoint_cb=on_checkpoint)
        except TrainingInterrupted as e:
            self.job_engine.set_status(job_id,"PAUSED"); self.experiments.pause(experiment_id, f"PAUSED — {e}"); log({"event":"interrupted","reason":str(e)}); return {"job_id":job_id,"status":"PAUSED","truth_status":"REAL","reason":str(e),"last_checkpoint":self.job_engine.get_last_valid_checkpoint(job_id)}
        except Exception as e:
            self.job_engine.set_status(job_id,"FAILED"); self.experiments.fail(experiment_id,str(e));
            exp_row=self.conn.execute("SELECT model_version_id FROM experiments WHERE id=?",(experiment_id,)).fetchone()
            if exp_row and exp_row[0]: self.conn.execute("UPDATE model_versions SET status='FAILED' WHERE id=?",(exp_row[0],)); self.conn.commit()
            log({"event":"failed","error":str(e)}); return {"job_id":job_id,"status":"FAILED","truth_status":"FAILED","error":str(e)}
        duration=time.time()-t0; self.job_engine.set_status(job_id,"COMPLETED",progress=1.0); self.experiments.complete(experiment_id,result["metrics"],duration,log_path); log({"event":"completed","metrics":result["metrics"],"duration_seconds":duration,"hardware":compute.full_report(self.checkpoint_root)})
        row=self.conn.execute("SELECT model_version_id FROM experiments WHERE id=?",(experiment_id,)).fetchone(); mvid=row[0] if row else None
        if mvid and result.get("final_model_path"): self.conn.execute("UPDATE model_versions SET file_path=?,sha256=?,metrics_json=?,status=? WHERE id=?",(result["final_model_path"],result.get("final_model_sha256"),utils.dumps(result["metrics"]),"EVALUATING",mvid)); self.conn.commit()
        return {"job_id":job_id,"status":"COMPLETED","truth_status":"REAL","metrics":result["metrics"],"duration_seconds":duration,"final_model_path":result.get("final_model_path"),"final_model_sha256":result.get("final_model_sha256"),"predictions":result.get("predictions"),"y_val":result.get("y_val"),"logs_path":log_path,"model_format":result.get("model_format"),"modality":result.get("modality")}
    def resume(self,job_id):
        ckpt=self.job_engine.get_last_valid_checkpoint(job_id); job=self.job_engine.get(job_id)
        if not job: return {"status":"FAILED","reason":"Job introuvable."}
        if not ckpt: return {"status":"FAILED","reason":"Aucun checkpoint valide trouvé pour la reprise."}
        config=json.loads(job.get("config_json") or "{}")
        provider_name=job["provider"]
        supported_resume = {
            ("LOCAL_CPU_PROVIDER", "sgd_incremental"),
            ("LOCAL_CPU_PROVIDER", "sgd_regressor"),
            ("LOCAL_CPU_PROVIDER", "mlp_sklearn"),
            ("LOCAL_CPU_PROVIDER", "mlp_torch"),
            ("LOCAL_GPU_PROVIDER", "mlp_torch"),
            ("LOCAL_MULTI_GPU_PROVIDER", "mlp_torch"),
        }
        if (provider_name, config.get("model_type")) not in supported_resume:
            return {"status":"UNAVAILABLE","reason":"Le provider/modèle courant ne supporte pas une reprise epoch par epoch locale."}
        config["resume_from"]=ckpt["file_path"]; config["start_epoch"]=int(ckpt["epoch"]); config.pop("stop_after_epoch",None)
        if not job.get("experiment_id"): return {"status":"FAILED","reason":"Job sans experiment lié."}
        config["resumed_from_job_id"] = job_id
        actual=self.run(job["experiment_id"],provider_name,config)
        if actual.get("status")=="COMPLETED":
            return {"status":"REAL","operation":"RESUMED","from_epoch":int(ckpt["epoch"]),"source_checkpoint":ckpt["file_path"],"result":actual}
        return {"status":actual.get("status","FAILED"),"operation":"RESUME_ATTEMPT","from_epoch":int(ckpt["epoch"]),"source_checkpoint":ckpt["file_path"],"result":actual}
