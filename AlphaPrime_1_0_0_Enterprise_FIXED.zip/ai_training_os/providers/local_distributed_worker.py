"""
local_distributed_worker.py — Service worker LAN autonome.

À lancer sur n'importe quelle machine de VOTRE PROPRE réseau local (bureau,
site industriel, cluster on-prem) pour qu'elle rejoigne réellement
l'entraînement distribué d'AI Training OS. Aucun accès Internet n'est
requis ni utilisé : le service écoute uniquement sur votre réseau local.

Usage :
    python3 -m ai_training_os.providers.local_distributed_worker --port 9500

Puis, côté machine qui lance l'entraînement, ajouter dans la config :
    config["nodes"] = ["<ip-de-cette-machine-sur-le-lan>:9500"]

C'est exactement ce mécanisme qui permet de faire monter en charge vers un
grand nombre de machines (usage "géant") tout en restant strictement
local : chaque machine ajoutée est une machine que l'utilisateur possède
et contrôle sur son propre réseau, jamais un service tiers.
"""
import argparse

from .local_distributed import worker_serve_forever


def main():
    parser = argparse.ArgumentParser(description="Worker de calcul local (LAN) pour l'entraînement distribué AI Training OS.")
    parser.add_argument("--host", default="0.0.0.0", help="Interface d'écoute (réseau local uniquement).")
    parser.add_argument("--port", type=int, default=9500)
    args = parser.parse_args()
    print(f"[LOCAL_DISTRIBUTED worker] écoute réelle sur {args.host}:{args.port} (réseau local uniquement, aucun accès Internet).")
    worker_serve_forever(args.host, args.port)


if __name__ == "__main__":
    main()
