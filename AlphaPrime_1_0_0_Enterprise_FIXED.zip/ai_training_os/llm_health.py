
"""Real local LLM role verification and runtime configuration health."""
from __future__ import annotations
from . import utils

TASK_PROMPTS = {
    "council": ("Tu es le rôle Council. Pour ce test, réponds exactement COUNCIL_OK.", "Réponds exactement COUNCIL_OK."),
    "scientist": ("Tu es le rôle AI Scientist. Pour ce test, réponds exactement SCIENTIST_OK.", "Réponds exactement SCIENTIST_OK."),
    "verification": ("Tu es le vérificateur local. Réponds exactement VERIFY_OK.", "Réponds exactement VERIFY_OK."),
    "general": ("Tu es l'assistant local Alpha Prime. Réponds exactement GENERAL_OK.", "Réponds exactement GENERAL_OK."),
}

class LLMHealth:
    def __init__(self, provider):
        self.provider = provider
        self.last_result = None

    def config(self):
        return {"status":"REAL","generation_profiles":self.provider.config,
                "selected_model":self.provider.selected_model,"selected_backend":self.provider.selected_backend}

    def verify_all_tasks(self) -> dict:
        st = self.provider.status()
        if st["status"] != "READY":
            return {"status":"UNAVAILABLE","truth_status":"UNAVAILABLE","cause":st.get("cause") or st.get("message"),
                    "solution":st.get("solution"),"tasks":{}}
        tasks = {}
        all_ok = True
        for task,(system,prompt) in TASK_PROMPTS.items():
            try:
                result = self.provider.complete(system, prompt, task=task)
                out = str(result.get("text", "")).strip()
                # Accept exact marker even if an inference backend echoes the prompt around it.
                marker = task.upper()+"_OK" if task != "verification" else "VERIFY_OK"
                ok = marker in out
                tasks[task] = {"status":"REAL" if ok else "FAILED","verified":ok,
                               "output":out[:500],"backend":result.get("backend"),"model":result.get("model")}
                all_ok = all_ok and ok
            except Exception as exc:
                tasks[task] = {"status":"FAILED","verified":False,"cause":f"{type(exc).__name__}: {exc}",
                               "solution":"Vérifiez le modèle sélectionné, son backend et les paramètres de génération locaux."}
                all_ok = False
        result={"status":"REAL" if all_ok else "FAILED","truth_status":"REAL" if all_ok else "FAILED",
                "backend":self.provider.selected_backend,"model":self.provider.selected_model,"tasks":tasks}
        self.last_result=result
        return result

    def preflight(self):
        """Single real gate for dependency/runtime readiness and all role probes."""
        provider=self.provider.status()
        if provider.get("status")!="READY":
            return {"status":"UNAVAILABLE","truth_status":"REAL","provider":provider,"tasks":{}}
        return self.verify_all_tasks()
