"""
core.py — Point d'entrée unique de AI Training OS.

Instancie tous les composants réels sur une base SQLite locale.
Aucune donnée préremplie : au premier lancement, tout est vide.
"""
import os
from . import db, utils, compute
from .audit import AuditLog
from .dataset_registry import DatasetRegistry
from .data_engine import UniversalDataEngine
from .model_registry import ModelRegistry
from .experiment_registry import ExperimentRegistry
from .job_engine import JobEngine
from .training_engine import TrainingEngine
from .evaluation_engine import EvaluationEngine, ErrorMining
from .safety_gate import SafetyGate
from .cost_guardian import CostGuardian
from .model_manager import ModelManager
from .ai_mission import AIMissionEngine
from .export_import import ProjectExporter
from .compute_planner import SmartComputePlanner
from .providers import list_providers
from .llm_provider import LocalLLMProvider
from .ai_council import AICouncil
from .red_team import RedTeamLab
from .ai_scientist import AIScientist
from .artifact_storage import ArtifactStorage
from .observability import Observability
from .security import SecurityEngine
from .synthetic_data_lab import SyntheticDataLab
from .champion_challenger import ChampionChallenger
from .model_genome import ModelGenome
from .continuous_training import ContinuousTraining
from .deployment_engine import DeploymentEngine
from .auto_lab import AutoLab
from .model_engine import ModelEngine
from .disaster_recovery import DisasterRecovery
from .ai_orchestrator import AIOrchestrator
from .config import ConfigStore
from .startup_manager import StartupManager
from .llm_finetune import LLMFineTuneEngine
from .llm_health import LLMHealth
from .dataset_studio import DatasetStudio
from .delivery import DeliveryManager
from .health_suite import HealthSuite
from .hardware_manager import HardwareManager
from .enterprise_suite import EnterpriseSuite


class AITrainingOS:
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        os.makedirs(base_dir, exist_ok=True)
        self.db_path = os.path.join(base_dir, "aitos.db")
        self.conn = db.init_db(self.db_path)

        self.audit = AuditLog(self.conn)
        self.data_engine = UniversalDataEngine()
        self.compute_engine = compute.ComputeEngine()
        self.datasets = DatasetRegistry(self.conn, os.path.join(base_dir, "storage"), self.audit)
        self.models = ModelRegistry(self.conn, self.audit)
        self.experiments = ExperimentRegistry(self.conn, self.audit)
        self.jobs = JobEngine(self.conn, self.audit)
        self.training = TrainingEngine(self.conn, self.jobs, self.experiments,
                                        os.path.join(base_dir, "checkpoints"), self.audit)
        self.evaluations = EvaluationEngine(self.conn, self.audit)
        self.error_mining = ErrorMining(self.conn, self.audit)
        self.safety_gate = SafetyGate(self.conn, self.audit)
        self.cost_guardian = CostGuardian(base_dir)
        self.model_manager = ModelManager(os.path.join(base_dir, "models"), self.audit)
        self.artifacts = ArtifactStorage(os.path.join(base_dir, "artifacts"), self.audit, self.conn)
        self.missions = AIMissionEngine(self.conn, self.audit)
        self.exporter = ProjectExporter(self.conn, self.audit)
        self.compute_planner = SmartComputePlanner()
        self.startup = StartupManager(base_dir, self.audit)
        self.llm_provider = LocalLLMProvider(base_dir, self.startup)
        self.llm_finetune = LLMFineTuneEngine(base_dir, self.startup, self.audit)
        self.llm_health = LLMHealth(self.llm_provider)
        self.dataset_studio = DatasetStudio(self.datasets, self.audit)
        self.delivery = DeliveryManager(base_dir, self.conn, self.audit)
        self.council = AICouncil(self.conn, base_dir, self.audit, self.missions, self.llm_provider)
        self.red_team = RedTeamLab(self.conn, self.audit)
        self.scientist = AIScientist(self.conn, self.llm_provider, self.audit)
        self.model_engine = ModelEngine()
        self.synthetic_lab = SyntheticDataLab(self.conn, os.path.join(base_dir, "synthetic"), self.audit)
        self.champion_challenger = ChampionChallenger(self.conn, self.audit)
        self.model_genome = ModelGenome(self.conn, self.audit)
        self.continuous_training = ContinuousTraining(self.conn, self.audit)
        self.deployment = DeploymentEngine(self.conn, self.audit)
        self.auto_lab = AutoLab(self.conn, self.audit)
        self.observability = Observability(self.conn, self.audit)
        self.security = SecurityEngine(base_dir, self.audit)
        self.disaster_recovery = DisasterRecovery(base_dir, self.audit)
        self.config = ConfigStore(os.path.join(base_dir, "config.json"))
        self.orchestrator = AIOrchestrator(self)
        self.health_suite = HealthSuite(self)
        self.hardware = HardwareManager(base_dir)
        self.enterprise = EnterpriseSuite(self.conn, base_dir, self.audit)

    def create_project(self, name: str) -> str:
        pid = utils.new_id("proj")
        self.conn.execute(
            "INSERT INTO projects (id, name, created_at, status) VALUES (?,?,?,?)",
            (pid, name, utils.now_iso(), "ACTIVE"),
        )
        self.conn.commit()
        self.audit.log("user", "CREATE_PROJECT", "project", pid, {"name": name})
        return pid

    def dashboard(self, project_id: str = None):
        """Etat réel du système. Aucune valeur fictive si rien n'existe encore."""
        def count(table, where=""):
            q = f"SELECT COUNT(*) FROM {table}"
            if where:
                q += f" WHERE {where}"
            return self.conn.execute(q).fetchone()[0]

        return {
            "compute": compute.full_report(),
            "providers": list_providers(),
            "compute_plan": self.compute_planner.plan(),
            "counts": {
                "projects": count("projects"),
                "datasets": count("datasets"),
                "dataset_versions": count("dataset_versions"),
                "models": count("models"),
                "model_versions": count("model_versions"),
                "experiments": count("experiments"),
                "jobs": count("jobs"),
                "checkpoints": count("checkpoints"),
                "evaluations": count("evaluations"),
                "council_sessions": count("council_sessions"),
                "council_decisions": count("council_decisions"),
                "red_team_runs": count("red_team_runs"),
                "red_team_tests": count("red_team_tests"),
                "scientist_reports": count("scientist_reports"),
                "artifacts": count("artifacts"),
                "autolab_runs": count("autolab_runs"),
                "synthetic_data_runs": count("synthetic_data_runs"),
                "deployments": count("deployments"),
                "continuous_training_runs": count("continuous_training_runs"),
                "data_contracts": count("data_contracts"),
                "drift_runs": count("drift_runs"),
                "model_cards": count("model_cards"),
                "eval_suites": count("eval_suites"),
            },
            "recent_audit": self.audit.list(limit=20),
        }
