"""Tiny server-side probe. Run it on a compute server when SSH deployment is not desired."""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from .scanner import scan, plan

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_): pass
    def do_GET(self):
        if self.path.rstrip("/") == "/health": self._send({"status":"REAL","service":"AlphaPrime Compute Agent"}); return
        if self.path.rstrip("/") == "/environment":
            s=scan(); self._send({"status":"REAL","scan":s,"plan":plan(s)}); return
        self._send({"status":"FAILED","error":"Not found"},404)
    def _send(self,obj,status=200):
        b=json.dumps(obj,ensure_ascii=False).encode(); self.send_response(status); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)

def serve(host="0.0.0.0",port=8765):
    ThreadingHTTPServer((host,port),Handler).serve_forever()

if __name__ == "__main__": serve()
