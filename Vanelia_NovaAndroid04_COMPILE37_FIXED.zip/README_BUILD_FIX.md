# Build compatibility

This project compiles against Android API 37 because Compose 1.12.x requires compileSdk 37 or newer. `minSdk` remains 26, so the compileSdk change does not remove support for older Android versions.

Jetifier is disabled because the project dependencies are AndroidX and AGP 9 no longer needs the deprecated project option.
