package com.vanelle.os

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        val action = i?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED &&
            action != Intent.ACTION_LOCKED_BOOT_COMPLETED
        ) return

        try { AlarmScheduler.rescheduleAll(c) } catch (_: Exception) {}
        try { NightlyConsolidation.schedule(c) } catch (_: Exception) {}

        if (WakeWordPrefs.isEnabled(c)) {
            try {
                ContextCompat.startForegroundService(
                    c, Intent(c, WakeWordService::class.java)
                )
            } catch (_: Exception) {}
        }
    }
}
