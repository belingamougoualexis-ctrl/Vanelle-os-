package com.vanelle.os

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.util.Log
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlinx.coroutines.*

/**
 * Pipeline openWakeWord optimisé (melspectrogram → embedding → classifieur "Cassandra").
 * - Audio 16 kHz / mono / 16-bit
 * - Fenêtres 80 ms ; le modèle d'embedding a besoin d'une fenêtre glissante de plusieurs
 *   trames de mel-spectrogramme empilées dans le temps (accumulées dans melFrameBuffer,
 *   taille lue dynamiquement sur le modèle chargé — ~76 trames ≈ 1,2s de contexte pour
 *   openWakeWord) — sans ça le modèle d'embedding reçoit une entrée à la mauvaise forme et
 *   l'inférence échoue silencieusement à chaque itération (c'était le bug racine empêchant
 *   toute détection, indépendamment du volume de la voix).
 * - Puis fenêtre glissante de 16 embeddings → classifieur "Cassandra"
 * - Seuil 0.22 + cooldown anti-double détection
 * - Score lissé (moyenne mobile) pour plus de robustesse
 * - Gain automatique (matériel si dispo + normalisation logicielle en repli) pour détecter
 *   "Cassandra" à volume de voix normal, sans avoir besoin de crier
 */
class OpenWakeWordDetector(private val context: Context) {
    companion object {
        private const val TAG = "OpenWakeWord"
        private const val SAMPLE_RATE = 16000
        private const val CHUNK_SAMPLES = 1280 // 80 ms
        private const val EMBED_WINDOW = 16
        private const val THRESHOLD = 0.22f
        private const val COOLDOWN_MS = 2200L
        private const val ENERGY_FLOOR = 60.0
        // Amplitude cible (sur 32768 max) après normalisation logicielle, et gain max autorisé
        // pour ne pas transformer le souffle/bruit ambiant en faux signal exploitable.
        private const val TARGET_PEAK = 11000f
        private const val MAX_SOFTWARE_GAIN = 6f
        // Taille max du tampon de trames mel si la forme du modèle d'embedding n'a pas pu
        // être déterminée (repli défensif, ne devrait pas arriver en pratique).
        private const val MEL_BUFFER_FALLBACK_MAX = 200
        // openWakeWord standard : trames mel 32 bins, fenêtre d'embedding de 76 trames,
        // embedding de sortie en 96 dimensions. Utilisé uniquement en repli quand la forme
        // réelle du modèle est dynamique (dimension -1/0, non résolue par TensorFlow Lite
        // tant qu'on ne force pas resizeInput — même problème que celui déjà rencontré et
        // corrigé sur melspectrogram.tflite, cf. openWakeWord GitHub issue #223).
        private const val FALLBACK_EMB_WINDOW = 76
        private const val FALLBACK_MEL_BINS = 32
        private const val FALLBACK_EMBED_DIM = 96
    }

    private var melInterp: Interpreter? = null
    private var embInterp: Interpreter? = null
    private var clsInterp: Interpreter? = null
    private val embedBuffer = ArrayDeque<FloatArray>()
    private val melFrameBuffer = ArrayDeque<FloatArray>()
    private var embFrameWindow = -1
    private var embMelBins = -1
    private var record: AudioRecord? = null
    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    @Volatile private var lastDetectAt = 0L
    private val recentScores = ArrayDeque<Float>()
    private var agc: AutomaticGainControl? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var softGain = 1f
    private var lastErrorLoggedAt = 0L
    private var lastErrorLoggedMsg = ""
    private var lastHeartbeatAt = 0L

    private fun floatInputBuffer(values: FloatArray): ByteBuffer =
        ByteBuffer.allocateDirect(values.size * 4).order(ByteOrder.nativeOrder()).apply {
            asFloatBuffer().put(values)
            rewind()
        }

    private fun floatOutputBuffer(count: Int): ByteBuffer =
        ByteBuffer.allocateDirect(count * 4).order(ByteOrder.nativeOrder())

    private fun readFloats(buf: ByteBuffer, count: Int): FloatArray {
        buf.rewind()
        val out = FloatArray(count)
        buf.asFloatBuffer().get(out)
        return out
    }

    private fun loadModel(file: File): Interpreter? {
        return try {
            val fis = FileInputStream(file)
            val channel = fis.channel
            val buffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
            val interp = Interpreter(buffer)
            try {
                interp.allocateTensors()
            } catch (_: Exception) { /* certains modèles n'en ont pas besoin */ }
            interp
        } catch (e: Exception) {
            Log.e(TAG, "loadModel ${file.name}: ${e.message}")
            null
        }
    }

    /**
     * melspectrogram.tflite a une forme d'entrée dynamique : TensorFlow Lite sur Android
     * ne la résout pas tout seul. Sans resize explicite, l'inférence échoue silencieusement.
     * Cf. openWakeWord GitHub issue #223.
     */
    private fun loadMelModel(file: File): Interpreter? {
        return try {
            val fis = FileInputStream(file)
            val channel = fis.channel
            val buffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
            val interp = Interpreter(buffer)
            try {
                interp.resizeInput(0, intArrayOf(1, CHUNK_SAMPLES))
                interp.allocateTensors()
            } catch (e: Exception) {
                Log.e(TAG, "resizeInput mel failed: ${e.message}")
                interp.close()
                return null
            }
            interp
        } catch (e: Exception) {
            Log.e(TAG, "loadMelModel: ${e.message}")
            null
        }
    }

    private fun loadAssetModel(name: String): Interpreter? {
        return try {
            val afd = context.assets.openFd(name)
            val fis = FileInputStream(afd.fileDescriptor)
            val buffer = fis.channel.map(
                FileChannel.MapMode.READ_ONLY,
                afd.startOffset,
                afd.declaredLength
            )
            val interp = Interpreter(buffer)
            try { interp.allocateTensors() } catch (_: Exception) {}
            interp
        } catch (e: Exception) {
            Log.e(TAG, "loadAssetModel $name: ${e.message}")
            null
        }
    }

    private var embOutDim = -1

    fun prepare(): Boolean {
        if (!WakeWordModelManager.isReady(context)) {
            Log.w(TAG, "prepare: models not ready")
            WakeWordDiagnostics.log(context, TAG, "prepare: modèles mel/embedding pas encore téléchargés")
            return false
        }
        if (melInterp == null) melInterp = loadMelModel(WakeWordModelManager.melFile(context))
        if (melInterp == null) WakeWordDiagnostics.log(context, TAG, "ÉCHEC chargement melspectrogram.tflite")
        if (embInterp == null) embInterp = loadModel(WakeWordModelManager.embFile(context))
        if (embInterp == null) WakeWordDiagnostics.log(context, TAG, "ÉCHEC chargement embedding_model.tflite")
        if (clsInterp == null) clsInterp = loadAssetModel("wakeword_classifier.tflite")
        if (clsInterp == null) WakeWordDiagnostics.log(context, TAG, "ÉCHEC chargement wakeword_classifier.tflite (assets)")

        // --- Modèle d'embedding : résout la forme d'entrée dynamique si besoin ---
        if (embInterp != null && embFrameWindow < 0) {
            try {
                var inShape = embInterp!!.getInputTensor(0).shape()
                val dynamic = inShape.size < 3 || inShape.drop(1).any { it <= 0 }
                if (dynamic) {
                    val window = inShape.getOrElse(1) { -1 }.let { if (it > 0) it else FALLBACK_EMB_WINDOW }
                    val bins = inShape.drop(2).let { rest ->
                        val p = rest.fold(1) { a, b -> if (b > 0) a * b else a }
                        if (rest.isEmpty() || rest.any { it <= 0 }) FALLBACK_MEL_BINS else p
                    }
                    Log.w(TAG, "embedding input shape dynamic (${inShape.toList()}), forcing resize to [1,$window,$bins]")
                    try {
                        embInterp!!.resizeInput(0, intArrayOf(1, window, bins))
                        embInterp!!.allocateTensors()
                        inShape = embInterp!!.getInputTensor(0).shape()
                    } catch (e: Exception) {
                        Log.e(TAG, "resizeInput embedding failed: ${e.message}")
                    }
                }
                if (inShape.size >= 3) {
                    embFrameWindow = inShape[1].let { if (it > 0) it else FALLBACK_EMB_WINDOW }
                    embMelBins = inShape.drop(2).fold(1) { a, b -> a * b }
                        .let { if (it > 0) it else FALLBACK_MEL_BINS }
                } else {
                    embFrameWindow = FALLBACK_EMB_WINDOW
                    embMelBins = FALLBACK_MEL_BINS
                }
                Log.i(TAG, "embedding model window=$embFrameWindow bins=$embMelBins")
                WakeWordDiagnostics.log(context, TAG, "modèle embedding : fenêtre=$embFrameWindow bins=$embMelBins (forme brute=${inShape.toList()})")
            } catch (e: Exception) {
                Log.e(TAG, "reading embedding input shape: ${e.message}")
                WakeWordDiagnostics.log(context, TAG, "ERREUR lecture forme embedding : ${e.message}")
            }
        }

        // --- Dimension de sortie de l'embedding (nécessaire pour dimensionner le classifieur) ---
        if (embInterp != null && embOutDim < 0) {
            try {
                val outShape = embInterp!!.getOutputTensor(0).shape()
                val d = outShape.drop(1).fold(1) { a, b -> if (b > 0) a * b else a }
                embOutDim = if (d > 0) d else FALLBACK_EMBED_DIM
            } catch (e: Exception) {
                embOutDim = FALLBACK_EMBED_DIM
            }
        }

        // --- Classifieur "Cassandra" : même précaution de forme dynamique ---
        if (clsInterp != null && embOutDim > 0) {
            try {
                val inShape = clsInterp!!.getInputTensor(0).shape()
                val dynamic = inShape.size < 3 || inShape.drop(1).any { it <= 0 }
                if (dynamic) {
                    Log.w(TAG, "classifier input shape dynamic (${inShape.toList()}), forcing resize to [1,$EMBED_WINDOW,$embOutDim]")
                    try {
                        clsInterp!!.resizeInput(0, intArrayOf(1, EMBED_WINDOW, embOutDim))
                        clsInterp!!.allocateTensors()
                    } catch (e: Exception) {
                        Log.e(TAG, "resizeInput classifier failed: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "reading classifier input shape: ${e.message}")
            }
        }

        val ok = melInterp != null && embInterp != null && clsInterp != null
        Log.i(TAG, "prepare -> $ok (mel=${melInterp != null} emb=${embInterp != null} cls=${clsInterp != null})")
        WakeWordDiagnostics.log(context, TAG, "prepare -> ${if (ok) "OK" else "ÉCHEC"} (mel=${melInterp != null} emb=${embInterp != null} cls=${clsInterp != null})")
        return ok
    }

    @Suppress("MissingPermission")
    fun start(onDetected: () -> Unit) {
        stop()
        if (melInterp == null && !prepare()) {
            Log.w(TAG, "start: prepare failed")
            WakeWordDiagnostics.log(context, TAG, "démarrage annulé : prepare() a échoué (voir lignes ÉCHEC ci-dessus)")
            return
        }
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) {
            Log.e(TAG, "getMinBufferSize failed: $minBuf")
            WakeWordDiagnostics.log(context, TAG, "ERREUR getMinBufferSize=$minBuf (appareil incompatible avec ce format audio)")
            return
        }
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, CHUNK_SAMPLES * 4)
            )
        } catch (e: Exception) {
            Log.e(TAG, "AudioRecord create: ${e.message}")
            WakeWordDiagnostics.log(context, TAG, "ERREUR création AudioRecord : ${e.message} (permission micro refusée ?)")
            null
        } ?: return
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "AudioRecord not initialized")
            WakeWordDiagnostics.log(context, TAG, "ERREUR AudioRecord non initialisé (micro déjà utilisé par une autre app ?)")
            try { rec.release() } catch (_: Exception) {}
            return
        }
        record = rec
        // AudioSource.VOICE_RECOGNITION fournit volontairement un signal "brut" (Android
        // désactive le gain automatique dessus pour laisser les moteurs de reco faire leur
        // propre traitement). Sans ça, une voix à volume normal reste trop faible pour le
        // classifieur "Cassandra" — d'où le besoin de crier. On réactive le gain automatique
        // matériel quand l'appareil le permet, en repli sur une normalisation logicielle plus bas.
        try {
            if (AutomaticGainControl.isAvailable()) {
                agc = AutomaticGainControl.create(rec.audioSessionId)?.apply { enabled = true }
            }
        } catch (e: Exception) {
            Log.w(TAG, "AGC unavailable: ${e.message}")
        }
        try {
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(rec.audioSessionId)?.apply { enabled = true }
            }
        } catch (e: Exception) {
            Log.w(TAG, "NoiseSuppressor unavailable: ${e.message}")
        }
        try {
            rec.startRecording()
        } catch (e: Exception) {
            Log.e(TAG, "startRecording: ${e.message}")
            WakeWordDiagnostics.log(context, TAG, "ERREUR startRecording : ${e.message}")
            try { rec.release() } catch (_: Exception) {}
            record = null
            return
        }
        embedBuffer.clear()
        recentScores.clear()
        melFrameBuffer.clear()
        softGain = 1f
        Log.i(TAG, "listening started")
        WakeWordDiagnostics.log(context, TAG, "écoute démarrée (fenêtre embedding=$embFrameWindow, bins=$embMelBins)")
        job = scope.launch {
            val buf = ShortArray(CHUNK_SAMPLES)
            while (isActive) {
                val n = try {
                    rec.read(buf, 0, CHUNK_SAMPLES)
                } catch (_: Exception) {
                    -1
                }
                if (n <= 0) {
                    delay(15)
                    continue
                }
                applySoftwareGain(buf, n)
                // Ignore near-silence (réduit faux positifs)
                var energy = 0.0
                for (i in 0 until n) energy += kotlin.math.abs(buf[i].toInt())
                if (energy / n < ENERGY_FLOOR) continue
                try {
                    val frames = runMelFrames(buf)
                    if (frames.isNotEmpty()) {
                        melFrameBuffer.addAll(frames)
                        val cap = if (embFrameWindow > 0) embFrameWindow else MEL_BUFFER_FALLBACK_MAX
                        while (melFrameBuffer.size > cap) melFrameBuffer.removeFirst()
                    }
                    val now0 = System.currentTimeMillis()
                    if (now0 - lastHeartbeatAt > 8000) {
                        lastHeartbeatAt = now0
                        WakeWordDiagnostics.log(
                            context, TAG,
                            "en écoute — mel=${melFrameBuffer.size}/${if (embFrameWindow > 0) embFrameWindow else "?"} " +
                                "embeddings=${embedBuffer.size}/$EMBED_WINDOW dernier score=${recentScores.lastOrNull() ?: "aucun"}"
                        )
                    }
                    val emb = runEmbeddingFromBuffer() ?: continue
                    embedBuffer.addLast(emb)
                    while (embedBuffer.size > EMBED_WINDOW) embedBuffer.removeFirst()
                    if (embedBuffer.size == EMBED_WINDOW) {
                        val score = runClassifier(embedBuffer.toList())
                        recentScores.addLast(score)
                        while (recentScores.size > 3) recentScores.removeFirst()
                        val smoothed = recentScores.average().toFloat()
                        val now = System.currentTimeMillis()
                        if (smoothed > THRESHOLD && now - lastDetectAt > COOLDOWN_MS) {
                            lastDetectAt = now
                            Log.i(TAG, "WAKE DETECTED score=$smoothed")
                            WakeWordDiagnostics.log(context, TAG, "MOT D'ACTIVATION DÉTECTÉ score=$smoothed")
                            embedBuffer.clear()
                            recentScores.clear()
                            withContext(Dispatchers.Main) { onDetected() }
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "inference: ${e.message}")
                    val msg = e.message ?: e.javaClass.simpleName
                    val nowErr = System.currentTimeMillis()
                    if (msg != lastErrorLoggedMsg || nowErr - lastErrorLoggedAt > 5000) {
                        lastErrorLoggedMsg = msg
                        lastErrorLoggedAt = nowErr
                        WakeWordDiagnostics.log(context, TAG, "ERREUR inférence : $msg")
                    }
                }
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        try { agc?.release() } catch (_: Exception) {}
        agc = null
        try { noiseSuppressor?.release() } catch (_: Exception) {}
        noiseSuppressor = null
        try { record?.stop() } catch (_: Exception) {}
        try { record?.release() } catch (_: Exception) {}
        record = null
        embedBuffer.clear()
        recentScores.clear()
        melFrameBuffer.clear()
    }

    /**
     * Normalisation logicielle en repli (utile sur les appareils sans AGC matériel, ou quand
     * le fabricant l'a désactivé pour AudioSource.VOICE_RECOGNITION). Amène le pic d'amplitude
     * du buffer vers TARGET_PEAK, avec un gain lissé dans le temps pour éviter les à-coups
     * (pas de saut brutal de volume entre deux fenêtres de 80 ms), et plafonné à
     * MAX_SOFTWARE_GAIN pour ne pas transformer un simple souffle en signal exploitable.
     */
    private fun applySoftwareGain(buf: ShortArray, n: Int) {
        var peak = 1
        for (i in 0 until n) {
            val a = kotlin.math.abs(buf[i].toInt())
            if (a > peak) peak = a
        }
        val desired = (TARGET_PEAK / peak).coerceIn(1f, MAX_SOFTWARE_GAIN)
        // Lissage : monte/descend progressivement plutôt que d'un coup, sinon un pic isolé
        // (toux, claquement) ferait sauter le gain et déformerait le signal utile qui suit.
        softGain = softGain * 0.8f + desired * 0.2f
        if (softGain <= 1.02f) return
        for (i in 0 until n) {
            val amplified = (buf[i] * softGain).toInt().coerceIn(-32768, 32767)
            buf[i] = amplified.toShort()
        }
    }

    /**
     * Fait tourner melInterp sur un chunk audio et retourne les trames de mel-spectrogramme
     * produites (une par pas temporel), prêtes à être empilées dans melFrameBuffer. Utilise
     * des ByteBuffer directs plutôt que des tableaux imbriqués : ça évite d'avoir à deviner à
     * l'avance le rang exact du tenseur (2D/3D/4D selon la version du modèle), TFLite se base
     * uniquement sur la taille en octets du buffer.
     */
    private fun runMelFrames(pcm: ShortArray): List<FloatArray> {
        val input = FloatArray(pcm.size) { i -> pcm[i] / 32768f }
        val inBuf = floatInputBuffer(input)
        val outShape = melInterp!!.getOutputTensor(0).shape()
        val outCount = outShape.fold(1) { a, b -> a * b }
        val outBuf = floatOutputBuffer(outCount)
        melInterp!!.run(inBuf, outBuf)
        val flat = readFloats(outBuf, outCount)
        val bins = if (outShape.isNotEmpty()) outShape.last() else outCount
        if (bins <= 0 || outCount % bins != 0) return listOf(flat)
        val frameCount = outCount / bins
        return (0 until frameCount).map { f -> FloatArray(bins) { b -> flat[f * bins + b] } }
    }

    /**
     * Construit l'entrée du modèle d'embedding à partir des dernières trames mel accumulées
     * (fenêtre glissante de taille embFrameWindow, lue dynamiquement sur le modèle chargé).
     * Retourne null tant que le tampon n'a pas encore assez de trames.
     */
    private fun runEmbeddingFromBuffer(): FloatArray? {
        val window = if (embFrameWindow > 0) embFrameWindow else return null
        val bins = if (embMelBins > 0) embMelBins else return null
        if (melFrameBuffer.size < window) return null
        val frames = melFrameBuffer.toList().takeLast(window)
        val flat = FloatArray(window * bins)
        for (t in 0 until window) {
            val fr = frames[t]
            for (b in 0 until bins) {
                flat[t * bins + b] = if (b < fr.size) fr[b] else 0f
            }
        }
        return try {
            val inBuf = floatInputBuffer(flat)
            val outShape = embInterp!!.getOutputTensor(0).shape()
            val outCount = outShape.fold(1) { a, b -> a * b }
            val outBuf = floatOutputBuffer(outCount)
            embInterp!!.run(inBuf, outBuf)
            readFloats(outBuf, outCount)
        } catch (e: Exception) {
            Log.w(TAG, "runEmbeddingFromBuffer: ${e.message}")
            null
        }
    }

    private fun runClassifier(embeddings: List<FloatArray>): Float {
        return try {
            val dim = embeddings.first().size
            val flat = FloatArray(embeddings.size * dim)
            for (t in embeddings.indices) {
                val e = embeddings[t]
                for (d in 0 until dim) flat[t * dim + d] = e[d]
            }
            val inBuf = floatInputBuffer(flat)
            val outBuf = floatOutputBuffer(1)
            clsInterp!!.run(inBuf, outBuf)
            readFloats(outBuf, 1)[0]
        } catch (e: Exception) {
            Log.w(TAG, "runClassifier: ${e.message}")
            0f
        }
    }
}
