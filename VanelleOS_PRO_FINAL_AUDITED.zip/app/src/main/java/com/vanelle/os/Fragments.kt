package com.vanelle.os
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.webkit.WebView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
class MascotFragment:Fragment(){
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val root=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(28,28,28,28); setBackgroundColor(0xFFFFFFFF.toInt())}

        // Grande prévisualisation
        val hero=ImageView(ctx).apply{
            layoutParams=LinearLayout.LayoutParams(-1,480).apply{bottomMargin=16}
            scaleType=ImageView.ScaleType.FIT_CENTER
            background=UiKit.card(ctx)
            adjustViewBounds=true
        }
        var sel=MascotManager.getSelected(ctx)
        fun refreshHero(){
            try{ hero.setImageResource(MascotManager.getDrawableId(ctx,sel)) }catch(_:Exception){}
        }
        refreshHero()

        // Nom personnalisé
        val nameTitle=TextView(ctx).apply{
            text="NOM DE TA MASCOTTE"
            setTextColor(0xFF8A8A8E.toInt()); textSize=11f; letterSpacing=0.1f
            setPadding(4,8,0,8)
        }
        val nameRow=LinearLayout(ctx).apply{
            orientation=LinearLayout.HORIZONTAL
            setPadding(16,8,16,8)
            background=UiKit.card(ctx)
        }
        val nameEdit=EditText(ctx).apply{
            hint="Ex: Luna, Buddy, Pixel..."
            setText(MascotManager.getCustomName(ctx))
            setTextColor(0xFF0A0A0A.toInt())
            setHintTextColor(0xFFAAAAAA.toInt())
            textSize=14f
            background=null
            layoutParams=LinearLayout.LayoutParams(0,-2,1f)
            maxLines=1
            isSingleLine=true
        }
        val saveBtn=Button(ctx).apply{
            text="Enregistrer"
            textSize=11f
            background=UiKit.pill(ctx)
            setTextColor(0xFFFF2D95.toInt())
            setOnClickListener{
                val n=nameEdit.text?.toString()?.trim() ?: ""
                MascotManager.setCustomName(ctx,n)
                Toast.makeText(ctx, if(n.isBlank()) "Nom réinitialisé" else "Nom enregistré : $n", Toast.LENGTH_SHORT).show()
            }
        }
        nameRow.addView(nameEdit); nameRow.addView(saveBtn)

        val nameHint=TextView(ctx).apply{
            text="Dis simplement son nom pour la faire apparaître à l'écran (ex: « Luna »). Permission « afficher par-dessus les apps » requise."
            setTextColor(0xFF8A8A8E.toInt()); textSize=10.5f
            setPadding(6,10,6,16)
        }

        // Grille horizontale de styles
        val styleTitle=TextView(ctx).apply{
            text="CHOISIS UN STYLE"
            setTextColor(0xFF8A8A8E.toInt()); textSize=11f; letterSpacing=0.1f
            setPadding(4,4,0,10)
        }
        val scroll=HorizontalScrollView(ctx).apply{isHorizontalScrollBarEnabled=false}
        val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        for((id,name) in MascotManager.mascots){
            val card=LinearLayout(ctx).apply{
                orientation=LinearLayout.VERTICAL
                setPadding(10,10,10,10)
                layoutParams=LinearLayout.LayoutParams(150,170).apply{setMargins(0,0,12,0)}
                background=if(id==sel) UiKit.selected(ctx) else UiKit.card(ctx)
            }
            val iv=ImageView(ctx).apply{
                try{ setImageResource(MascotManager.getDrawableId(ctx,id)) }catch(_:Exception){}
                scaleType=ImageView.ScaleType.FIT_CENTER
                layoutParams=LinearLayout.LayoutParams(-1,110)
                adjustViewBounds=true
            }
            val tv=TextView(ctx).apply{
                text=name
                setTextColor(if(id==sel) 0xFFFF2D95.toInt() else 0xFF0A0A0A.toInt())
                textSize=10f; letterSpacing=0.04f
                setPadding(0,8,0,0)
                gravity=android.view.Gravity.CENTER
                typeface=android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL)
            }
            card.addView(iv); card.addView(tv)
            card.setOnClickListener{
                sel=id
                MascotManager.setSelected(ctx,id)
                refreshHero()
                for(j in 0 until row.childCount){
                    val ch=row.getChildAt(j) as LinearLayout
                    ch.background=UiKit.card(ctx)
                    (ch.getChildAt(1) as TextView).setTextColor(0xFF0A0A0A.toInt())
                }
                card.background=UiKit.selected(ctx)
                tv.setTextColor(0xFFFF2D95.toInt())
            }
            row.addView(card)
        }
        scroll.addView(row)

        // Bouton test apparition
        val testBtn=Button(ctx).apply{
            text="Faire apparaître maintenant"
            textSize=12f
            background=UiKit.pill(ctx)
            setTextColor(0xFFFF2D95.toInt())
            layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=20}
            setOnClickListener{
                if(!OverlayHelper.canDraw(ctx)){
                    Toast.makeText(ctx,"Active d'abord « afficher par-dessus les apps » dans Configuration",Toast.LENGTH_LONG).show()
                    OverlayHelper.requestPermission(ctx)
                    return@setOnClickListener
                }
                val mid=MascotManager.getDrawableId(ctx,MascotManager.getSelected(ctx))
                val name=MascotManager.getDisplayName(ctx)
                OverlayHelper.showMascot(ctx,mid,"Salut, je suis $name !")
            }
        }

        root.addView(hero)
        root.addView(nameTitle)
        root.addView(nameRow)
        root.addView(nameHint)
        root.addView(styleTitle)
        root.addView(scroll)
        root.addView(testBtn)
        return root
    }
}
class ConfigFragment:Fragment(){
    private val refreshers=mutableListOf<()->Unit>()
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext(); refreshers.clear()
        val sv=ScrollView(ctx).apply{setBackgroundColor(0xFFFFFFFF.toInt())}
        val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(32,40,32,40)}

        fun sectionTitle(t:String)=TextView(ctx).apply{text=t; setTextColor(0xFF8A8A8E.toInt()); textSize=11f; letterSpacing=0.1f; setPadding(4,0,0,10)}
        fun spacer(h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,h)}

        // --- Assistant vocal ---
        col.addView(sectionTitle("ASSISTANT VOCAL"))
        val wakeRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,22,24,22); background=UiKit.card(ctx)}
        val wakeStatus=TextView(ctx).apply{text=if(WakeWordPrefs.isEnabled(ctx)) "Active" else "Inactive"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; setPadding(20,0,0,0)}
        val wakeSwitch=Switch(ctx).apply{
            isChecked=WakeWordPrefs.isEnabled(ctx)
            setOnCheckedChangeListener{ btn,checked->
                if(checked && ContextCompat.checkSelfPermission(ctx,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(ctx,"Autorise d'abord le microphone ci-dessous",Toast.LENGTH_LONG).show()
                    btn.isChecked=false; return@setOnCheckedChangeListener
                }
                WakeWordPrefs.setEnabled(ctx,checked); wakeStatus.text=if(checked) "Active" else "Inactive"
                if(checked) ContextCompat.startForegroundService(ctx,Intent(ctx,WakeWordService::class.java))
                else ctx.stopService(Intent(ctx,WakeWordService::class.java))
            }
        }
        wakeRow.addView(wakeSwitch); wakeRow.addView(wakeStatus)
        col.addView(wakeRow)
        val hintText=TextView(ctx).apply{text="Mot d'activation : dis \"Cassandra\" suivi de ta demande, par exemple \"Cassandra, ouvre calculatrice\""; setTextColor(0xFF8A8A8E.toInt()); textSize=10.5f; setPadding(6,8,6,0)}
        col.addView(hintText)
        col.addView(spacer(16))

        // --- Mot d'activation (visible tout en haut, juste sous le switch) ---
        col.addView(sectionTitle("MOT D'ACTIVATION"))
        val wwCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val wwLabel=TextView(ctx).apply{textSize=13f; setTextColor(0xFF0A0A0A.toInt())}
        val wwDetail=TextView(ctx).apply{textSize=11f; setTextColor(0xFF8A8A8E.toInt()); setPadding(0,6,0,0)}
        fun refreshWw(){
            val ready=WakeWordModelManager.isReady(ctx)
            val micOk=ContextCompat.checkSelfPermission(ctx,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED
            val enabled=WakeWordPrefs.isEnabled(ctx)
            wwLabel.text=when{
                !micOk -> "Microphone non autorisé — accorde-le ci-dessous"
                !ready -> "Modèles en cours de préparation (Wi-Fi recommandé)…"
                !enabled -> "Détection prête, mais l'écoute est désactivée (switch ci-dessus)"
                else -> "Détection acoustique active — dis « Cassandra »"
            }
            wwLabel.setTextColor(when{
                ready && enabled && micOk -> 0xFF16A34A.toInt()
                !micOk || !enabled -> 0xFFEF4444.toInt()
                else -> 0xFF0A0A0A.toInt()
            })
            val melOk=WakeWordModelManager.melFile(ctx).exists() && WakeWordModelManager.melFile(ctx).length()>1000
            val embOk=WakeWordModelManager.embFile(ctx).exists() && WakeWordModelManager.embFile(ctx).length()>1000
            wwDetail.text="Modèle mél : ${if(melOk) "OK" else "manquant"}  ·  Embedding : ${if(embOk) "OK" else "manquant"}"
        }
        refreshWw(); refreshers.add(::refreshWw)
        wwCol.addView(wwLabel)
        wwCol.addView(wwDetail)

        val wwBtnRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(0,14,0,0)}
        val forceDlBtn=Button(ctx).apply{
            text="Télécharger modèles"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            setOnClickListener{
                text="…"; isEnabled=false
                lifecycleScope.launch{
                    try{
                        // Supprime les fichiers incomplets pour forcer un vrai re-téléchargement
                        listOf(WakeWordModelManager.melFile(ctx), WakeWordModelManager.embFile(ctx)).forEach{ f->
                            if(f.exists() && f.length()<1000) f.delete()
                        }
                        val ok=withContext(kotlinx.coroutines.Dispatchers.IO){
                            WakeWordModelManager.downloadIfNeeded(ctx)
                        }
                        refreshWw()
                        Toast.makeText(ctx, if(ok) "Modèles prêts" else "Échec du téléchargement — vérifie ta connexion", Toast.LENGTH_LONG).show()
                        if(ok && WakeWordPrefs.isEnabled(ctx) &&
                            ContextCompat.checkSelfPermission(ctx,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED){
                            ctx.stopService(Intent(ctx,WakeWordService::class.java))
                            ContextCompat.startForegroundService(ctx,Intent(ctx,WakeWordService::class.java))
                        }
                    }catch(_:Exception){
                        Toast.makeText(ctx,"Erreur réseau",Toast.LENGTH_SHORT).show()
                    }finally{
                        text="Télécharger modèles"; isEnabled=true
                    }
                }
            }
        }
        val restartBtn=Button(ctx).apply{
            text="Redémarrer écoute"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            layoutParams=LinearLayout.LayoutParams(-2,-2).apply{ marginStart=12 }
            setOnClickListener{
                if(ContextCompat.checkSelfPermission(ctx,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(ctx,"Autorise d'abord le microphone",Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                WakeWordPrefs.setEnabled(ctx,true)
                wakeSwitch.isChecked=true
                wakeStatus.text="Active"
                ctx.stopService(Intent(ctx,WakeWordService::class.java))
                ContextCompat.startForegroundService(ctx,Intent(ctx,WakeWordService::class.java))
                refreshWw()
                Toast.makeText(ctx,"Service d'écoute redémarré",Toast.LENGTH_SHORT).show()
            }
        }
        wwBtnRow.addView(forceDlBtn)
        wwBtnRow.addView(restartBtn)
        wwCol.addView(wwBtnRow)

        val batteryHint=TextView(ctx).apply{
            text="Si l'écoute s'arrête toute seule : Paramètres → Batterie → VanelleOS → Aucune restriction"
            setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,12,0,0)
        }
        wwCol.addView(batteryHint)
        col.addView(wwCol)
        col.addView(spacer(28))

        // --- Autorisations ---
        col.addView(sectionTitle("AUTORISATIONS"))

        fun permRow(label:String, permission:String, consequence:String):View{
            val col2=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
            val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
            val labelView=TextView(ctx).apply{text=label; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
            val statusView=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
            val manageBtn=Button(ctx).apply{
                text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
                setOnClickListener{
                    val intent=Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply{ data=Uri.fromParts("package",ctx.packageName,null) }
                    startActivity(intent)
                }
            }
            val consLabel=TextView(ctx).apply{text="Si refuse : $consequence"; setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,8,0,0)}
            fun refresh(){
                val granted=ContextCompat.checkSelfPermission(ctx,permission)==PackageManager.PERMISSION_GRANTED
                statusView.text=if(granted) "Accordee" else "Non accordee"
                statusView.setTextColor(if(granted) 0xFF16A34A.toInt() else 0xFFEF4444.toInt())
            }
            refresh(); refreshers.add(::refresh)
            row.addView(labelView); row.addView(statusView); row.addView(manageBtn)
            col2.addView(row); col2.addView(consLabel)
            return col2
        }

        col.addView(permRow("Microphone (ecoute vocale)", Manifest.permission.RECORD_AUDIO, "impossible d'utiliser les commandes vocales"))
        col.addView(spacer(2))
        col.addView(permRow("Contacts (appel par nom)", Manifest.permission.READ_CONTACTS, "impossible de trouver un contact par son nom"))
        col.addView(spacer(2))
        col.addView(permRow("Appel telephonique", Manifest.permission.CALL_PHONE, "les demandes d'appel resteront sans effet, meme apres confirmation"))
        col.addView(spacer(2))
        col.addView(permRow("Envoi de SMS", Manifest.permission.SEND_SMS, "les demandes d'envoi de message resteront sans effet, meme apres confirmation"))
        col.addView(spacer(2))
        if(Build.VERSION.SDK_INT>=33){
            col.addView(permRow("Notifications", Manifest.permission.POST_NOTIFICATIONS, "la notification d'ecoute active et les rappels de relances ne s'afficheront pas"))
            col.addView(spacer(2))
        }

        // Accessibilite (mecanisme different : reglage systeme, pas une permission classique)
        val accCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val accRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val accLabel=TextView(ctx).apply{text="Service d'accessibilite (actions systeme)"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val accStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val accBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            setOnClickListener{ startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        fun refreshAcc(){
            val exp="${ctx.packageName}/${VanelleAccessibilityService::class.java.canonicalName}"
            val en=Settings.Secure.getString(ctx.contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            var granted=false
            if(en!=null){ val split=TextUtils.SimpleStringSplitter(':'); split.setString(en); while(split.hasNext()){ if(split.next().equals(exp,true)){ granted=true; break } } }
            accStatus.text=if(granted) "Accordee" else "Non accordee"
            accStatus.setTextColor(if(granted) 0xFF16A34A.toInt() else 0xFFEF4444.toInt())
        }
        refreshAcc(); refreshers.add(::refreshAcc)
        accRow.addView(accLabel); accRow.addView(accStatus); accRow.addView(accBtn)
        val accCons=TextView(ctx).apply{text="Si refuse : les commandes retour/accueil/notifications/recents ne fonctionneront pas"; setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,8,0,0)}
        accCol.addView(accRow); accCol.addView(accCons)
        col.addView(accCol); col.addView(spacer(2))

        // Alarmes exactes (necessaire pour l'onglet Relances)
        val alarmCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val alarmRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val alarmLabel=TextView(ctx).apply{text="Alarmes exactes (relances a l'heure precise)"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val alarmStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val alarmBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            setOnClickListener{ if(Build.VERSION.SDK_INT>=31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:${ctx.packageName}"))) }
        }
        fun refreshAlarm(){
            val granted=AlarmScheduler.canScheduleExact(ctx)
            alarmStatus.text=if(granted) "Accordee" else "Non accordee"
            alarmStatus.setTextColor(if(granted) 0xFF16A34A.toInt() else 0xFFEF4444.toInt())
        }
        refreshAlarm(); refreshers.add(::refreshAlarm)
        alarmRow.addView(alarmLabel); alarmRow.addView(alarmStatus); alarmRow.addView(alarmBtn)
        val alarmCons=TextView(ctx).apply{text="Si refuse : les relances programmees peuvent se declencher en retard, plus jamais a l'heure exacte"; setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,8,0,0)}
        alarmCol.addView(alarmRow); alarmCol.addView(alarmCons)
        col.addView(alarmCol); col.addView(spacer(2))

        // Affichage par-dessus les autres apps (mascotte sur l'ecran principal)
        val overlayCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val overlayRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val overlayLabel=TextView(ctx).apply{text="Affichage sur l'ecran principal"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val overlayStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val overlayBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            setOnClickListener{ OverlayHelper.requestPermission(ctx) }
        }
        fun refreshOverlay(){
            val granted=OverlayHelper.canDraw(ctx)
            overlayStatus.text=if(granted) "Accordee" else "Non accordee"
            overlayStatus.setTextColor(if(granted) 0xFF16A34A.toInt() else 0xFFEF4444.toInt())
        }
        refreshOverlay(); refreshers.add(::refreshOverlay)
        overlayRow.addView(overlayLabel); overlayRow.addView(overlayStatus); overlayRow.addView(overlayBtn)
        val overlayCons=TextView(ctx).apply{text="Si refuse : la mascotte repond seulement dans une fenetre de l'app, pas par-dessus ton ecran habituel"; setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,8,0,0)}
        overlayCol.addView(overlayRow); overlayCol.addView(overlayCons)
        col.addView(overlayCol); col.addView(spacer(28))

        // --- Données de l'application (téléchargement avec barre de progression) ---
        col.addView(sectionTitle("DONNÉES DE L'APPLICATION"))
        val aiCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val aiRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val aiLabel=TextView(ctx).apply{textSize=13f; setTextColor(0xFF0A0A0A.toInt()); layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val aiBtn=Button(ctx).apply{ text="Mettre à jour"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt()) }
        val aiProgress=android.widget.ProgressBar(ctx,null,android.R.attr.progressBarStyleHorizontal).apply{
            max=100; progress=0; visibility=View.GONE; isIndeterminate=false
            layoutParams=LinearLayout.LayoutParams(-1, (8*resources.displayMetrics.density).toInt()).apply{ topMargin=16 }
            if(android.os.Build.VERSION.SDK_INT>=21){
                progressTintList=android.content.res.ColorStateList.valueOf(0xFFFF2D95.toInt())
                progressBackgroundTintList=android.content.res.ColorStateList.valueOf(0x33FF2D95)
            }
        }
        val aiPct=TextView(ctx).apply{
            textSize=11f; setTextColor(0xFF8A8A8E.toInt()); visibility=View.GONE
            setPadding(0,8,0,0)
        }
        fun overallPct():Int{
            if(DataDownloadService.allDataReady(ctx)) return 100
            val wakeReady=WakeWordModelManager.isReady(ctx)
            val base=if(wakeReady) DataDownloadService.WAKE_PROGRESS_SHARE else 0
            val part=LlamaModelManager.partialBytes(ctx)
            if(part<=0) return base
            val ggufPct=((part*100)/LlamaModelManager.EXPECTED_MIN_BYTES).toInt().coerceIn(0,99)
            return (base+((100-DataDownloadService.WAKE_PROGRESS_SHARE)*ggufPct)/100).coerceIn(0,99)
        }
        fun refreshAi(){
            val ready=DataDownloadService.allDataReady(ctx)
            aiLabel.text=if(ready) "Données prêtes" else "Téléchargement des données de l'app requis (Wi-Fi recommandé, ~800 Mo)"
            aiBtn.isEnabled=!ready
            aiBtn.text=if(ready) "À jour" else "Mettre à jour"
            if(ready){
                aiProgress.visibility=View.GONE
                aiPct.visibility=View.GONE
            }
        }
        aiBtn.setOnClickListener{
            aiBtn.isEnabled=false
            aiBtn.text="..."
            aiProgress.visibility=View.VISIBLE
            aiProgress.progress=overallPct()
            aiPct.visibility=View.VISIBLE
            aiPct.text="${overallPct()} % — téléchargement des données de l'app…"
            DataDownloadService.start(ctx)
            DataDownloadScreen.maybeShow(requireActivity())

            lifecycleScope.launch{
                while(isAdded && !DataDownloadService.allDataReady(ctx)){
                    kotlinx.coroutines.delay(1500)
                    val pct=overallPct()
                    aiProgress.visibility=View.VISIBLE
                    aiPct.visibility=View.VISIBLE
                    aiProgress.progress=pct
                    aiPct.text="$pct % — téléchargement des données de l'app…"
                    aiBtn.text=if(pct>0) "$pct %" else "…"
                    if(!DataDownloadService.isRunning && !DataDownloadService.allDataReady(ctx)){
                        DataDownloadService.start(ctx)
                    }
                }
                refreshAi()
                Toast.makeText(ctx,"Données prêtes",Toast.LENGTH_SHORT).show()
            }
        }
        refreshAi(); refreshers.add(::refreshAi)
        aiRow.addView(aiLabel); aiRow.addView(aiBtn)
        aiCol.addView(aiRow)
        aiCol.addView(aiProgress)
        aiCol.addView(aiPct)
        val aiCons=TextView(ctx).apply{text="Les données de l'app améliorent l'écoute et les réponses. Sans elles, une recherche web gratuite est utilisée."; setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,8,0,0)}
        aiCol.addView(aiCons)
        col.addView(aiCol); col.addView(spacer(28))

        // --- Mode traduction (activation vocale uniquement, statut affiche ici) ---
        col.addView(sectionTitle("MODE TRADUCTION"))
        val trRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,20,24,20); background=UiKit.card(ctx)}
        val trActive=TranslateModePrefs.isActive(ctx)
        val trLabel=TextView(ctx).apply{
            text=if(trActive) "Actif : ${TranslateModePrefs.source(ctx)} vers ${TranslateModePrefs.target(ctx)}" else "Dis : Cassandra mode traduction de telle langue vers telle langue"
            setTextColor(0xFF0A0A0A.toInt()); textSize=12f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)
        }
        val trStatus=TextView(ctx).apply{text=if(trActive) "Actif" else "Inactif"; textSize=11f; setTextColor(if(trActive) 0xFF16A34A.toInt() else 0xFF8A8A8E.toInt())}
        trRow.addView(trLabel); trRow.addView(trStatus)
        col.addView(trRow); col.addView(spacer(28))
        refreshers.add{
            val active=TranslateModePrefs.isActive(ctx)
            trLabel.text=if(active) "Actif : ${TranslateModePrefs.source(ctx)} vers ${TranslateModePrefs.target(ctx)}" else "Dis : Cassandra mode traduction de telle langue vers telle langue"
            trStatus.text=if(active) "Actif" else "Inactif"
            trStatus.setTextColor(if(active) 0xFF16A34A.toInt() else 0xFF8A8A8E.toInt())
        }

        // --- Compte local ---
        col.addView(sectionTitle("COMPTE"))
        val accountCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val user=LocalAuth.currentUser(ctx)
        val accountLabel=TextView(ctx).apply{
            text=if(user!=null) "${user.displayName}\n${user.email}" else "Non connecté"
            setTextColor(0xFF0A0A0A.toInt()); textSize=13f
        }
        val accountNote=TextView(ctx).apply{
            text="Compte local — stocké uniquement sur cet appareil"
            setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,6,0,0)
        }
        val accountBtnRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(0,14,0,0)}
        val logoutBtn=Button(ctx).apply{
            text="Se déconnecter"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            setOnClickListener{
                LocalAuth.logout(ctx)
                Toast.makeText(ctx,"Déconnecté",Toast.LENGTH_SHORT).show()
                startActivity(Intent(ctx,AuthActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                requireActivity().finish()
            }
        }
        val deleteBtn=Button(ctx).apply{
            text="Supprimer le compte"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFEF4444.toInt())
            layoutParams=LinearLayout.LayoutParams(-2,-2).apply{ marginStart=12 }
            setOnClickListener{
                AlertDialog.Builder(ctx).setTitle("Supprimer le compte")
                    .setMessage("Supprime le compte local de cet appareil. Les souvenirs ne sont pas effacés automatiquement.")
                    .setPositiveButton("Supprimer"){_,_->
                        LocalAuth.deleteAccount(ctx)
                        Toast.makeText(ctx,"Compte supprimé",Toast.LENGTH_SHORT).show()
                        startActivity(Intent(ctx,AuthActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                        requireActivity().finish()
                    }
                    .setNegativeButton("Annuler",null).show()
            }
        }
        accountBtnRow.addView(logoutBtn)
        accountBtnRow.addView(deleteBtn)
        accountCol.addView(accountLabel)
        accountCol.addView(accountNote)
        accountCol.addView(accountBtnRow)
        col.addView(accountCol)
        col.addView(spacer(28))

        // --- Memoire ---
        col.addView(sectionTitle("MEMOIRE"))
        val clearRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,20,24,20); background=UiKit.card(ctx)}
        val clearLabel=TextView(ctx).apply{text="Effacer tous les souvenirs enregistres"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val clearBtn=Button(ctx).apply{
            text="Effacer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFEF4444.toInt())
            setOnClickListener{
                AlertDialog.Builder(ctx).setTitle("Effacer la memoire")
                    .setMessage("Cette action supprime definitivement tous les souvenirs enregistres. Continuer ?")
                    .setPositiveButton("Effacer"){_,_-> MemoryVault(ctx).clear(); Toast.makeText(ctx,"Memoire effacee",Toast.LENGTH_SHORT).show() }
                    .setNegativeButton("Annuler",null).show()
            }
        }
        clearRow.addView(clearLabel); clearRow.addView(clearBtn)
        col.addView(clearRow); col.addView(spacer(28))

        // --- Legal ---
        col.addView(sectionTitle("LEGAL"))
        val legalCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        fun showLegal(title:String, body:String){
            val tv=TextView(ctx).apply{
                text=body; setTextColor(0xFF0A0A0A.toInt()); textSize=12f
                setPadding(24,16,24,16); setTextIsSelectable(true)
            }
            val scr=ScrollView(ctx).apply{addView(tv)}
            AlertDialog.Builder(ctx).setTitle(title).setView(scr).setPositiveButton("Fermer",null).show()
        }
        val privacyBtn=Button(ctx).apply{
            text="Politique de confidentialite"; textSize=12f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            setOnClickListener{ showLegal(LegalTexts.PRIVACY_TITLE, LegalTexts.PRIVACY) }
        }
        val termsBtn=Button(ctx).apply{
            text="Conditions d'utilisation"; textSize=12f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=12}
            setOnClickListener{ showLegal(LegalTexts.TERMS_TITLE, LegalTexts.TERMS) }
        }
        legalCol.addView(privacyBtn); legalCol.addView(termsBtn)
        col.addView(legalCol); col.addView(spacer(28))

        // --- Confidentialité ---
        col.addView(sectionTitle("CONFIDENTIALITÉ & CONTRÔLE"))
        val trustCol = LinearLayout(ctx).apply{ orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx) }
        val guestRow = LinearLayout(ctx).apply{ orientation=LinearLayout.HORIZONTAL }
        val guestLabel = TextView(ctx).apply{
            text="Mode invité (ne rien mémoriser)"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f
            layoutParams=LinearLayout.LayoutParams(0,-2,1f)
        }
        val guestSw = Switch(ctx).apply{
            isChecked=PersonalityPrefs.isGuestMode(ctx)
            setOnCheckedChangeListener{ _, checked ->
                PersonalityPrefs.setGuestMode(ctx, checked)
                Toast.makeText(ctx, if(checked) "Mode invité ON" else "Mode invité OFF", Toast.LENGTH_SHORT).show()
            }
        }
        guestRow.addView(guestLabel); guestRow.addView(guestSw)
        trustCol.addView(guestRow)

        val offRow = LinearLayout(ctx).apply{ orientation=LinearLayout.HORIZONTAL; setPadding(0,12,0,0) }
        val offLabel = TextView(ctx).apply{
            text="Préférer le hors-ligne"; setTextColor(0xFF0A0A0A.toInt()); textSize=13f
            layoutParams=LinearLayout.LayoutParams(0,-2,1f)
        }
        val offSw = Switch(ctx).apply{
            isChecked=PersonalityPrefs.preferOffline(ctx)
            setOnCheckedChangeListener{ _, checked -> PersonalityPrefs.setPreferOffline(ctx, checked) }
        }
        offRow.addView(offLabel); offRow.addView(offSw)
        trustCol.addView(offRow)

        col.addView(trustCol); col.addView(spacer(20))

        col.addView(sectionTitle("ROUTINES"))
        val rouCol = LinearLayout(ctx).apply{ orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx) }
        val rouTxt = TextView(ctx).apply{
            text=RoutineManager.describe(ctx); setTextColor(0xFF0A0A0A.toInt()); textSize=12f
        }
        val rouBtn = Button(ctx).apply{
            text="Activer briefing matin 7h30"; textSize=12f; background=UiKit.pill(ctx); setTextColor(0xFFFF2D95.toInt())
            layoutParams=LinearLayout.LayoutParams(-1,-2).apply{ topMargin=10 }
            setOnClickListener{
                RoutineManager.ensureDefaultMorning(ctx)
                rouTxt.text=RoutineManager.describe(ctx)
                Toast.makeText(ctx,"Routine matin activée",Toast.LENGTH_SHORT).show()
            }
        }
        rouCol.addView(rouTxt); rouCol.addView(rouBtn)
        col.addView(rouCol); col.addView(spacer(20))

        sv.addView(col); return sv
    }
    override fun onResume(){ super.onResume(); refreshers.forEach{ it() } }
}
class FeaturesFragment:Fragment(){
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val sv=ScrollView(ctx).apply{setBackgroundColor(0xFFFFFFFF.toInt())}
        val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(28,32,28,32)}
        fun spacer(h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,h)}
        val items=listOf(
            Triple("Ouvrir une application","Cassandra, ouvre Spotify","L'application s'ouvre directement."),
            Triple("Appeler un contact","Cassandra, appelle Paul","Une fenetre de confirmation apparait avant l'appel reel."),
            Triple("Envoyer un message","Cassandra, envoie un message a Paul texte j'arrive","Confirmation affichee, puis le SMS part une fois valide."),
            Triple("Recherche","Cassandra, cherche comment faire un tiramisu","Ouvre une recherche web avec ta demande."),
            Triple("YouTube","Cassandra, YouTube Stromae","YouTube s'ouvre avec la recherche."),
            Triple("Traduction","Cassandra, traduis hello how are you","La traduction est prononcee a voix haute."),
            Triple("Mode traduction","Cassandra, mode traduction de l'anglais vers le francais","Chaque phrase captee apres le wake word est traduite et lue, jusqu'a Cassandra quitte mode traduction."),
            Triple("Memoire","Cassandra, retiens que mon code wifi est X / Cassandra, rappelle-moi mon code wifi","Stockage local, retrouve sur demande."),
            Triple("Urgence","Cassandra, urgence","Ouvre l'appel d'urgence 112."),
            Triple("Telephone perdu","Cassandra, retrouve mon telephone","Alarme sonore et vibration meme en silencieux."),
            Triple("Navigation","Cassandra, navigue vers la Tour Eiffel","Maps s'ouvre avec l'itineraire."),
            Triple("Calculatrice","Cassandra, calculatrice","Ouvre la calculatrice du telephone."),
            Triple("Batterie","Cassandra, batterie","Annonce le niveau de batterie a voix haute."),
            Triple("Relance programmee","Cassandra, rappelle-moi d'appeler Paul a 18h30","Alarme reelle visible dans l'onglet Relances."),
            Triple("Retour / Accueil","Cassandra, retour  ou  Cassandra, accueil","Simule le bouton retour ou accueil (accessibilite requise)."),
            Triple("Lire l'ecran","Cassandra, lis l'ecran","Lit le texte affiche (accessibilite requise)."),
            Triple("Resume d'ecran","Cassandra, resume l'ecran","Lit puis resume le texte visible (accessibilite + IA locale si disponible)."),
            Triple("Copilote ecran","Cassandra, remplis avec mon adresse 12 rue de Paris","Saisit le texte dans le champ actif (accessibilite requise — touche d'abord le champ)."),
            Triple("Journal","Cassandra, journal d'activite","Recapitulatif recent des actions Vanelle."),
            Triple("Camera","Cassandra, ouvre la camera","Ouvre l'appareil photo.")
        )
        for((name,example,result) in items){
            val card=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(22,20,22,20); background=UiKit.card(ctx)}
            val title=TextView(ctx).apply{text=name; setTextColor(0xFF0A0A0A.toInt()); textSize=13f; typeface=android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL)}
            val ex=TextView(ctx).apply{text="Exemple : \u00ab $example \u00bb"; setTextColor(0xFFFF2D95.toInt()); textSize=11.5f; setPadding(0,8,0,4)}
            val res=TextView(ctx).apply{text=result; setTextColor(0xFF6B6B70.toInt()); textSize=11f}
            card.addView(title); card.addView(ex); card.addView(res)
            col.addView(card); col.addView(spacer(10))
        }
        sv.addView(col); return sv
    }
}
class RelanceFragment:Fragment(){
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val root=FrameLayout(ctx).apply{setBackgroundColor(0xFFFFFFFF.toInt())}
        fun rebuild(){
            root.removeAllViews()
            val sv=ScrollView(ctx).apply{setBackgroundColor(0xFFFFFFFF.toInt())}
            val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(28,32,28,32)}
            fun sectionTitle(t:String)=TextView(ctx).apply{text=t; setTextColor(0xFF8A8A8E.toInt()); textSize=11f; letterSpacing=0.1f; setPadding(4,0,0,10)}
            fun spacer(h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,h)}
            val fmt=java.text.SimpleDateFormat("dd/MM HH:mm",java.util.Locale.FRANCE)
            val repo=RelanceRepository(ctx)

            col.addView(sectionTitle("A VENIR"))
            val tasks=repo.getTasks()
            if(tasks.isEmpty()) col.addView(TextView(ctx).apply{text="Aucune relance programmee. Dis : Cassandra, rappelle-moi d'appeler Paul a 18h30"; setTextColor(0xFF6B6B70.toInt()); textSize=12f; setPadding(24,16,24,16)})
            for(task in tasks){
                val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
                // Les routines encodent "routine:<id>|<actions>" en interne (voir RoutineManager) :
                // on n'affiche jamais ce prefixe technique a l'utilisateur.
                val displayDesc=if(task.description.startsWith("routine:")) task.description.substringAfter("|",task.description) else task.description
                val label=TextView(ctx).apply{
                    text="$displayDesc\n${task.hour.toString().padStart(2,'0')}h${task.minute.toString().padStart(2,'0')}${if(task.repeatDaily) " - tous les jours" else " - une fois"}"
                    setTextColor(0xFF0A0A0A.toInt()); textSize=12f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)
                }
                val delBtn=Button(ctx).apply{
                    text="Supprimer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFEF4444.toInt())
                    setOnClickListener{
                        try {
                            AlarmScheduler.cancel(ctx, task.id)
                            repo.removeTask(task.id)
                            android.widget.Toast.makeText(ctx, "Relance supprimee", android.widget.Toast.LENGTH_SHORT).show()
                        } catch (_:Exception) {}
                        rebuild()
                    }
                }
                row.addView(label); row.addView(delBtn)
                col.addView(row); col.addView(spacer(8))
            }
            col.addView(spacer(28))

            col.addView(sectionTitle("HISTORIQUE"))
            val history=repo.getHistory()
            if(history.isEmpty()) col.addView(TextView(ctx).apply{text="Aucune relance executee pour le moment."; setTextColor(0xFF6B6B70.toInt()); textSize=12f; setPadding(24,16,24,16)})
            for(h in history.take(30)){
                val row=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,16,24,16); background=UiKit.card(ctx)}
                val labelTop=TextView(ctx).apply{text=h.description; setTextColor(0xFF0A0A0A.toInt()); textSize=12f}
                val labelBottom=TextView(ctx).apply{text="${fmt.format(java.util.Date(h.executedAt))} - ${h.result}"; setTextColor(0xFF8A8A8E.toInt()); textSize=10f; setPadding(0,4,0,0)}
                row.addView(labelTop); row.addView(labelBottom)
                col.addView(row); col.addView(spacer(8))
            }
            sv.addView(col)
            root.addView(sv)
        }
        rebuild()
        return root
    }
}
