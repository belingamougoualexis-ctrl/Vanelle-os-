package com.vanelle.os

import android.content.Context
import android.util.Log
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object WakeWordModelManager {
    private const val TAG = "WakeWordModels"
    private const val MEL_URL =
        "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/melspectrogram.tflite"
    private const val EMB_URL =
        "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/embedding_model.tflite"
    // Taille minimale réaliste pour un vrai fichier .tflite openWakeWord (bien plus stricte
    // que l'ancien seuil de 1000 octets, qui laissait passer des pages d'erreur HTML ou des
    // téléchargements tronqués comme "valides").
    private const val MIN_VALID_SIZE = 50_000L

    fun melFile(c: Context) = File(c.filesDir, "melspectrogram.tflite")
    fun embFile(c: Context) = File(c.filesDir, "embedding_model.tflite")

    /**
     * Vérifie que le fichier a une taille plausible ET commence par la signature FlatBuffer
     * "TFL3" (offset 4) de tout fichier .tflite valide. Sans ça, un téléchargement tronqué ou
     * une page d'erreur HTML (souvent >1000 octets) était accepté à tort comme "prêt", et
     * l'app retentait de le charger indéfiniment sans jamais le re-télécharger.
     */
    private fun isValidTfliteFile(f: File): Boolean {
        if (!f.exists() || f.length() < MIN_VALID_SIZE) return false
        return try {
            f.inputStream().use { input ->
                val header = ByteArray(8)
                val read = input.read(header)
                read == 8 && header[4] == 'T'.code.toByte() && header[5] == 'F'.code.toByte() &&
                    header[6] == 'L'.code.toByte() && header[7] == '3'.code.toByte()
            }
        } catch (_: Exception) {
            false
        }
    }

    fun isReady(c: Context): Boolean =
        isValidTfliteFile(melFile(c)) && isValidTfliteFile(embFile(c))

    private fun downloadOne(url: String, dest: File, retries: Int = 3): Boolean {
        repeat(retries) { attempt ->
            try {
                if (isValidTfliteFile(dest)) return true
                if (dest.exists() && !isValidTfliteFile(dest)) dest.delete()

                var current = url
                var redirects = 0
                while (redirects < 10) {
                    val conn = (URL(current).openConnection() as HttpURLConnection).apply {
                        instanceFollowRedirects = false
                        connectTimeout = 25000
                        readTimeout = 90000
                        setRequestProperty(
                            "User-Agent",
                            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                        )
                        setRequestProperty("Accept", "*/*")
                        requestMethod = "GET"
                    }
                    val code = conn.responseCode
                    if (code in 300..399) {
                        val loc = conn.getHeaderField("Location") ?: run {
                            conn.disconnect()
                            return@repeat
                        }
                        current = if (loc.startsWith("http")) loc else {
                            val base = URL(current)
                            URL(base, loc).toString()
                        }
                        conn.disconnect()
                        redirects++
                        continue
                    }
                    if (code !in 200..299) {
                        Log.w(TAG, "HTTP $code for $url (attempt ${attempt + 1})")
                        conn.disconnect()
                        return@repeat
                    }
                    val tmp = File(dest.absolutePath + ".part")
                    if (tmp.exists()) tmp.delete()
                    tmp.outputStream().use { out ->
                        conn.inputStream.use { it.copyTo(out) }
                    }
                    conn.disconnect()
                    if (isValidTfliteFile(tmp)) {
                        if (dest.exists()) dest.delete()
                        if (tmp.renameTo(dest)) {
                            Log.i(TAG, "Downloaded ${dest.name} (${dest.length()} bytes)")
                            return true
                        }
                    }
                    Log.w(TAG, "Download invalide pour ${dest.name} (${tmp.length()} octets, signature TFL3 absente ou taille suspecte)")
                    tmp.delete()
                    Log.w(TAG, "Download too small or rename failed for ${dest.name}")
                    return@repeat
                }
            } catch (e: Exception) {
                Log.w(TAG, "Download error for $url (attempt ${attempt + 1}): ${e.message}")
            }
            try { Thread.sleep(800L * (attempt + 1)) } catch (_: Exception) {}
        }
        return false
    }

    /**
     * Télécharge les modèles s'ils manquent. Retourne true si les deux sont prêts.
     * Peut être appelé depuis un thread IO (recommandé).
     */
    suspend fun downloadIfNeeded(c: Context): Boolean {
        if (isReady(c)) return true
        WakeWordDiagnostics.log(c, TAG, "téléchargement des modèles d'écoute (mel invalide=${!isValidTfliteFile(melFile(c))}, emb invalide=${!isValidTfliteFile(embFile(c))})")
        val a = downloadOne(MEL_URL, melFile(c))
        val b = downloadOne(EMB_URL, embFile(c))
        val ok = a && b
        Log.i(TAG, "downloadIfNeeded -> $ok (mel=$a emb=$b)")
        WakeWordDiagnostics.log(c, TAG, "téléchargement terminé -> ${if (ok) "OK" else "ÉCHEC"} (mel=$a, taille=${melFile(c).length()} octets ; emb=$b, taille=${embFile(c).length()} octets)")
        return ok
    }

    /** Force la suppression des modèles (pour re-téléchargement complet). */
    fun clear(c: Context) {
        listOf(melFile(c), embFile(c)).forEach { f ->
            try { if (f.exists()) f.delete() } catch (_: Exception) {}
        }
    }
}
