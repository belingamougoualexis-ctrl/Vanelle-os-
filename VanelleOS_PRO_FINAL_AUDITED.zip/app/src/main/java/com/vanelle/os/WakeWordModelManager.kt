package com.vanelle.os

import android.content.Context
import android.util.Log
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object WakeWordModelManager {
    private const val TAG = "WakeWordModels"
    private const val MEL_URL =
        "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/melspectrogram.tflite"
    private const val EMB_URL =
        "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/embedding_model.tflite"

    fun melFile(c: Context) = File(c.filesDir, "melspectrogram.tflite")
    fun embFile(c: Context) = File(c.filesDir, "embedding_model.tflite")

    fun isReady(c: Context): Boolean =
        melFile(c).exists() && melFile(c).length() > 1000 &&
            embFile(c).exists() && embFile(c).length() > 1000

    private fun downloadOne(url: String, dest: File, retries: Int = 3): Boolean {
        repeat(retries) { attempt ->
            try {
                if (dest.exists() && dest.length() > 1000) return true
                if (dest.exists() && dest.length() <= 1000) dest.delete()

                var current = url
                var redirects = 0
                while (redirects < 10) {
                    val conn = (URL(current).openConnection() as HttpURLConnection).apply {
                        instanceFollowRedirects = false
                        connectTimeout = 25000
                        readTimeout = 90000
                        setRequestProperty(
                            "User-Agent",
                            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                        )
                        setRequestProperty("Accept", "*/*")
                        requestMethod = "GET"
                    }
                    val code = conn.responseCode
                    if (code in 300..399) {
                        val loc = conn.getHeaderField("Location") ?: run {
                            conn.disconnect()
                            return@repeat
                        }
                        current = if (loc.startsWith("http")) loc else {
                            val base = URL(current)
                            URL(base, loc).toString()
                        }
                        conn.disconnect()
                        redirects++
                        continue
                    }
                    if (code !in 200..299) {
                        Log.w(TAG, "HTTP $code for $url (attempt ${attempt + 1})")
                        conn.disconnect()
                        return@repeat
                    }
                    val tmp = File(dest.absolutePath + ".part")
                    if (tmp.exists()) tmp.delete()
                    tmp.outputStream().use { out ->
                        conn.inputStream.use { it.copyTo(out) }
                    }
                    conn.disconnect()
                    if (tmp.length() > 1000) {
                        if (dest.exists()) dest.delete()
                        if (tmp.renameTo(dest)) {
                            Log.i(TAG, "Downloaded ${dest.name} (${dest.length()} bytes)")
                            return true
                        }
                    }
                    tmp.delete()
                    Log.w(TAG, "Download too small or rename failed for ${dest.name}")
                    return@repeat
                }
            } catch (e: Exception) {
                Log.w(TAG, "Download error for $url (attempt ${attempt + 1}): ${e.message}")
            }
            try { Thread.sleep(800L * (attempt + 1)) } catch (_: Exception) {}
        }
        return false
    }

    /**
     * Télécharge les modèles s'ils manquent. Retourne true si les deux sont prêts.
     * Peut être appelé depuis un thread IO (recommandé).
     */
    suspend fun downloadIfNeeded(c: Context): Boolean {
        if (isReady(c)) return true
        val a = downloadOne(MEL_URL, melFile(c))
        val b = downloadOne(EMB_URL, embFile(c))
        val ok = a && b
        Log.i(TAG, "downloadIfNeeded -> $ok (mel=$a emb=$b)")
        return ok
    }

    /** Force la suppression des modèles (pour re-téléchargement complet). */
    fun clear(c: Context) {
        listOf(melFile(c), embFile(c)).forEach { f ->
            try { if (f.exists()) f.delete() } catch (_: Exception) {}
        }
    }
}
