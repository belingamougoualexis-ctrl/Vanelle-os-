# Vanelle OS 2.0 — checklist livraison

## Critique (corrigé)
- [x] Boucle récursive mémoire (MemoryEngine ↔ RelationalMemory) — **corrigée**
- [x] Accolades Kotlin OK
- [x] Manifest XML valide
- [x] versionName **2.0.0** / versionCode 40

## Modules
- [x] LocalLlamaHelper + warm-up
- [x] ReasoningHelper + MemoryEngine
- [x] HybridRouter + CloudLlmClient (optionnel)
- [x] ChatHistory threads/dossiers/tags
- [x] ChatFragment + export
- [x] OnboardingActivity
- [x] Widget + mascotte ronde
- [x] Traduction multi-langues
- [x] Personnalité + stats + bannière privé

## À tester sur appareil
1. Install APK → onboarding
2. Autorisations micro / overlay / accessibilité
3. Attendre modèle chargé
4. Conversation texte + mascotte
5. Historique / dossiers / tags
6. Fonctions système (batterie, ouvrir app)
7. Mode offline

## Build
`./gradlew :app:assembleModernDebug` (ou flavor présent dans le projet)
