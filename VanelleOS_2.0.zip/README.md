# Vanelle OS 2.0

Assistante IA **locale** sur Android — Rose / Blanc / Noir.

## Build

```bash
./gradlew :app:assembleModernDebug
# ou assembleDebug selon flavors
```

APK : `app/build/outputs/apk/...`

## Fonctionnalités livrées

### IA locale
- Llama 1B (llamacpp-kotlin) + warm-up auto
- Prompts Vanelle (fiabilité, intention, pas de bluff)
- Raisonnement orchestré (`ReasoningHelper`)
- Mémoire court/long terme (`MemoryEngine`)
- Hybride cloud optionnel (`HybridRouter` + OpenAI-compatible)

### UX
- Onglets : Mascotte · Conversation · Configuration · Fonctions · Relances
- Chat texte + historique (dossiers, tags, recherche)
- Onboarding + démo
- Mascotte flottante ronde (overlay)
- Widget home
- Export conversation
- Personnalité (Pote / Calme / Coach / Énergie)
- Stats transparentes
- Traduction multi-langues

### Système
- Parser d’intentions + actions téléphone
- Accessibilité, relances, offline par défaut
- Pare-feu confidentialité

## Premier lancement

1. Installer l’APK  
2. Onboarding → autorisations (micro, overlay, accessibilité)  
3. Attendre téléchargement / chargement du modèle  
4. Parler via mascotte ou onglet Conversation  

## Confidentialité

Par défaut : **tout local**. Web / cloud uniquement si explicitement autorisés.
