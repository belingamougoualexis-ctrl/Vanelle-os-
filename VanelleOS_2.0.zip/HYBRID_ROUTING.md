# Routage hybride local ↔ cloud (Vanelle)

## Principe

**Edge-first with escalation** : le local traite ~80–90 % des requêtes (outils, cache, Llama 1B, web léger).  
Le cloud n’intervient que sur les cas durs, si l’utilisateur l’autorise et configure une clé.

```
Requête
  → outils / cache / calcul déterministe     → LOCAL
  → fait simple                             → web/RAG local
  → score complexité < 35                   → LOCAL (1B)
  → score 35–54                             → LOCAL puis cloud si réponse faible
  → score ≥ 55                              → CLOUD (si configuré)
  → offline / lockdown / mode off           → LOCAL only
```

## Fichiers

| Fichier | Rôle |
|---------|------|
| `HybridRouter.kt` | Score + destination (`LOCAL`, `LOCAL_THEN_CLOUD`, `CLOUD`) |
| `CloudLlmClient.kt` | API OpenAI-compatible (clé dans `MemoryVault`) |
| `CommandInterpreter.kt` | Appelle `tryCloud` selon la décision / escalade |

## Modes (`HybridRouter.setMode`)

| Mode | Comportement |
|------|----------------|
| `off` | Jamais de cloud (défaut sûr tant que non configuré) |
| `escalate` | Local d’abord ; cloud si score élevé ou réponse locale faible |
| `cloud_preferred` | Cloud plus tôt (score ≥ 25) |

## Configuration cloud

```kotlin
CloudLlmClient.configure(
    context,
    apiKey = "sk-…",
    baseUrl = "https://api.openai.com/v1",  // ou Groq, OpenRouter, proxy…
    model = "gpt-4o-mini"
)
HybridRouter.setMode(context, "escalate")
```

Compatibilité : tout endpoint **Chat Completions** (`/v1/chat/completions`).

## Confidentialité

- `preferOffline` ou `allowWeb=false` → **aucun** appel cloud  
- Clé API uniquement dans `EncryptedSharedPreferences` (`MemoryVault`)  
- Lockdown désactive web + force offline  

## Ce que le local garde toujours

- Commandes téléphone (apps, appels, SMS, écran…)  
- Offline  
- Données sensibles si l’utilisateur a bloqué le web  

## Limites actuelles

- Pas d’UI de saisie de clé dans ce patch (API Kotlin prête ; écran Config à brancher)  
- Pas de streaming cloud  
- Le score est heuristique (pas un classifieur ML) — suffisant pour un 1B mobile  
