# Vanelle — écosystème autour du 1B (pas seulement le LLM)

Les « grandes IA » gagnent souvent par l’écosystème. Vanelle compense ainsi :

| Capacité | Implémentation |
|----------|----------------|
| Web / RAG | `FreeAIHelper` + `synthesizeAnswer` ; faits hors domaine → web d’abord |
| Mémoire persistante | `RelationalMemory` (profil, faits, dialogue, résumé compressé) |
| Outils téléphone | Parser + `ACTION:` + repositories (apps, contacts, maps…) |
| Multi-tour | Résumé extractif des vieux tours + tours récents |
| Vérif factuelle | Lookup factuel → web avant les poids du modèle |
| Personnalité | `PersonalityPrefs.systemTone` + charte |
| Erreurs élégantes | `elegantUnknown` — pas de bluff |
| Feedback | `FeedbackMemory` (corrections → few-shot) |
| Cache | `ResponseCache` questions fréquentes |
| Voix | TTS Android + STT système (déjà en place) |
| Calculs | Code déterministe |

Hors scope runtime (Studio / plus tard) :
- Fine-tune / distillation de raisonnement
- Router cloud hybride (préférence + API)
- Speculative decoding / NNAPI (build natif)
