import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vanelle.os"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vanelle.os"
        // Android 6.0+ pour élargir la compatibilité aux appareils plus anciens.
        minSdk = 23
        targetSdk = 34
        versionCode = 46
        versionName = "2.0.6"
    }


    flavorDimensions += "ai"
    productFlavors {
        create("modern") {
            dimension = "ai"
            // io.github.ljcamargo:llamacpp-kotlin:0.4.0 exige minSdk >= 24.
            minSdk = 24
            // L'IA locale Llama utilise actuellement des bibliothèques natives 64 bits.
            ndk {
                abiFilters += listOf("arm64-v8a", "x86_64")
            }
        }
        create("legacy") {
            dimension = "ai"
            // Variante destinée aux appareils 32 bits : pas de dépendance Llama native.
            // Le reste de Vanelle reste disponible avec ses fonctions de secours.
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/*.kotlin_module"
            )
        }
    }

    androidResources {
        noCompress += listOf("tflite", "gguf")
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        // llamacpp-kotlin 0.4.0 est compilé avec metadata Kotlin 2.3 ;
        // on autorise la lecture pour éviter l'échec CI (stdlib + module natif).
        freeCompilerArgs.add("-Xskip-metadata-version-check")
    }
}

configurations.all {
    resolutionStrategy {
        // Aligner la stdlib sur le compilateur du projet (évite le pull 2.3.20 non géré)
        force(
            "org.jetbrains.kotlin:kotlin-stdlib:2.1.10",
            "org.jetbrains.kotlin:kotlin-stdlib-jdk7:2.1.10",
            "org.jetbrains.kotlin:kotlin-stdlib-jdk8:2.1.10",
            "org.jetbrains.kotlin:kotlin-stdlib-common:2.1.10",
            "androidx.core:core:1.15.0",
            "androidx.core:core-ktx:1.15.0"
        )
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.2.0")
    // Llama natif uniquement dans la variante moderne 64 bits.
    "modernImplementation"("io.github.ljcamargo:llamacpp-kotlin:0.4.0")
}
