package com.vanelle.os
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.Toast
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.content.ClipData
import android.content.ClipboardManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.webkit.WebView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
class MascotFragment:Fragment(){
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val root=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(28,28,28,28); setBackgroundColor(0xFFFFFFFF.toInt())}

        // Grande prévisualisation
        val hero=ImageView(ctx).apply{
            layoutParams=LinearLayout.LayoutParams(-1,480).apply{bottomMargin=16}
            scaleType=ImageView.ScaleType.FIT_CENTER
            background=UiKit.card(ctx)
            adjustViewBounds=true
        }
        var sel=MascotManager.getSelected(ctx)
        fun refreshHero(){
            try{ hero.setImageResource(MascotManager.getDrawableId(ctx,sel)) }catch(_:Exception){}
        }
        refreshHero()

        // Nom personnalisé
        val nameTitle=TextView(ctx).apply{
            text="NOM DE TA MASCOTTE"
            setTextColor(0xFF444444.toInt()); textSize=11f; letterSpacing=0.1f
            setPadding(4,8,0,8)
        }
        val nameRow=LinearLayout(ctx).apply{
            orientation=LinearLayout.HORIZONTAL
            setPadding(16,8,16,8)
            background=UiKit.card(ctx)
        }
        val nameEdit=EditText(ctx).apply{
            hint="Ex: Luna, Buddy, Pixel..."
            setText(MascotManager.getCustomName(ctx))
            setTextColor(0xFF000000.toInt())
            setHintTextColor(0xFF444444.toInt())
            textSize=14f
            background=null
            layoutParams=LinearLayout.LayoutParams(0,-2,1f)
            maxLines=1
            isSingleLine=true
        }
        val saveBtn=Button(ctx).apply{
            text="Enregistrer"
            textSize=11f
            background=UiKit.pill(ctx)
            setTextColor(0xFF000000.toInt())
            setOnClickListener{
                val n=nameEdit.text?.toString()?.trim() ?: ""
                MascotManager.setCustomName(ctx,n)
                Toast.makeText(ctx, if(n.isBlank()) "Nom réinitialisé" else "Nom enregistré : $n", Toast.LENGTH_SHORT).show()
            }
        }
        nameRow.addView(nameEdit); nameRow.addView(saveBtn)

        val nameHint=TextView(ctx).apply{
            text="Clique sur la mascotte flottante pour activer le micro."
            setTextColor(0xFF444444.toInt()); textSize=10.5f
            setPadding(6,10,6,16)
        }

        // Grille horizontale de styles
        val styleTitle=TextView(ctx).apply{
            text="CHOISIS UN STYLE"
            setTextColor(0xFF444444.toInt()); textSize=11f; letterSpacing=0.1f
            setPadding(4,4,0,10)
        }
        val scroll=HorizontalScrollView(ctx).apply{isHorizontalScrollBarEnabled=false}
        val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        for((id,name) in MascotManager.mascots){
            val card=LinearLayout(ctx).apply{
                orientation=LinearLayout.VERTICAL
                setPadding(10,10,10,10)
                // Plus haut pour voir le corps entier (pas de coupe)
                layoutParams=LinearLayout.LayoutParams(150,200).apply{setMargins(0,0,12,0)}
                background=if(id==sel) UiKit.selected(ctx) else UiKit.card(ctx)
            }
            val iv=ImageView(ctx).apply{
                try{ setImageResource(MascotManager.getDrawableId(ctx,id)) }catch(_:Exception){}
                scaleType=ImageView.ScaleType.FIT_CENTER
                layoutParams=LinearLayout.LayoutParams(-1,150)
                adjustViewBounds=true
            }
            val tv=TextView(ctx).apply{
                text=name
                setTextColor(if(id==sel) 0xFF000000.toInt() else 0xFF000000.toInt())
                textSize=10f; letterSpacing=0.04f
                setPadding(0,8,0,0)
                gravity=android.view.Gravity.CENTER
                typeface=android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL)
            }
            card.addView(iv); card.addView(tv)
            card.setOnClickListener{
                sel=id
                MascotManager.setSelected(ctx,id)
                FloatingMascotButton.refreshIcon(ctx)
                refreshHero()
                for(j in 0 until row.childCount){
                    val ch=row.getChildAt(j) as LinearLayout
                    ch.background=UiKit.card(ctx)
                    (ch.getChildAt(1) as TextView).setTextColor(0xFF000000.toInt())
                }
                card.background=UiKit.selected(ctx)
                tv.setTextColor(0xFF000000.toInt())
            }
            row.addView(card)
        }
        scroll.addView(row)

        // Bouton test apparition
        val testBtn=Button(ctx).apply{
            text="Faire apparaître maintenant"
            textSize=12f
            background=UiKit.pill(ctx)
            setTextColor(0xFF000000.toInt())
            layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=20}
            setOnClickListener{
                if(!DataDownloadService.isUsable(ctx)){
                    Toast.makeText(ctx,"L'IA doit être téléchargée et chargée en mémoire avant d'afficher la mascotte.",Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if(!OverlayHelper.canDraw(ctx)){
                    Toast.makeText(ctx,"Active d'abord « afficher par-dessus les apps » dans Configuration",Toast.LENGTH_LONG).show()
                    OverlayHelper.requestPermission(ctx)
                    return@setOnClickListener
                }
                val mid=MascotManager.getDrawableId(ctx,MascotManager.getSelected(ctx))
                val name=MascotManager.getDisplayName(ctx)
                OverlayHelper.showMascot(ctx,mid,"")
            }
        }

        root.addView(hero)
        root.addView(nameTitle)
        root.addView(nameRow)
        root.addView(nameHint)
        root.addView(styleTitle)
        root.addView(scroll)
        root.addView(testBtn)
        return root
    }
}
class ConfigFragment:Fragment(){
    private val refreshers=mutableListOf<()->Unit>()
    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        val msg = UserDataSnapshot.importFromUri(requireContext(), uri)
        Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show()
    }
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext(); refreshers.clear()
        val sv=ScrollView(ctx).apply{setBackgroundColor(0xFFFFFFFF.toInt())}
        val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(32,40,32,40)}

        fun sectionTitle(t:String)=TextView(ctx).apply{text=t; setTextColor(0xFF444444.toInt()); textSize=11f; letterSpacing=0.1f; setPadding(4,0,0,10)}
        fun spacer(h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,h)}

        // --- Assistant vocal ---
        col.addView(sectionTitle("ASSISTANT VOCAL"))
        val voiceInfo=TextView(ctx).apply{
            text="Clique sur la mascotte flottante pour activer le micro."
            setTextColor(0xFF444444.toInt()); textSize=12f; setPadding(24,18,24,18); background=UiKit.card(ctx)
        }
        col.addView(voiceInfo); col.addView(spacer(28))

        // --- Diagnostic : état réel de l'IA et des autres fonctionnalités ---
        col.addView(sectionTitle("DIAGNOSTIC"))

        fun statusDot(ok: Boolean) = if (ok) "\u25CF" else "\u25CF" // rempli dans les deux cas, seule la couleur change
        fun diagRow(label: String, ok: Boolean, detail: String): View {
            val c2 = LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,16,24,16); background=UiKit.card(ctx)}
            val r = LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
            val dot = TextView(ctx).apply{
                text = statusDot(ok); textSize = 13f
                setTextColor(if(ok) 0xFF16A34A.toInt() else 0xFFEF4444.toInt())
                setPadding(0,0,16,0)
            }
            val lbl = TextView(ctx).apply{text=label; setTextColor(0xFF000000.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
            r.addView(dot); r.addView(lbl)
            val det = TextView(ctx).apply{text=detail; setTextColor(0xFF444444.toInt()); textSize=10.5f; setPadding(28,8,0,0)}
            c2.addView(r); c2.addView(det)
            return c2
        }

        val diagCol = LinearLayout(ctx).apply{ orientation = LinearLayout.VERTICAL }
        fun refreshDiag(){
            diagCol.removeAllViews()
            val supported = LlamaModelManager.isLocalAiSupported()
            val downloaded = LlamaModelManager.isReady(ctx)
            val loaded = try { LocalLlamaHelper.get(ctx).isLoaded() } catch (_: Exception) { false }
            val lastFail = AiLoadDiagnostics.lastFailureCause(ctx)
            val aiDetail = when {
                !supported -> "Appareil non compatible avec l'IA locale (32 bits)."
                !downloaded -> "Modèle pas encore téléchargé."
                downloaded && !loaded -> "Téléchargé mais pas chargé en mémoire" + (lastFail?.let { " — cause : $it" } ?: " — pas encore de cause enregistrée.")
                else -> "Opérationnelle."
            }
            diagCol.addView(diagRow("IA locale (Vanelle)", supported && downloaded && loaded, aiDetail))
            diagCol.addView(spacer(2))

            val online = try { LlamaModelManager.isNetworkAvailable(ctx) } catch (_: Exception) { false }
            diagCol.addView(diagRow("Connexion internet", online, if(online) "Détectée." else "Aucune connexion détectée — le téléchargement du modèle et la recherche web sont impossibles."))
            diagCol.addView(spacer(2))

            val webOk = try { PrivacyFirewall.allowWeb(ctx) } catch (_: Exception) { true }
            diagCol.addView(diagRow("Recherche web / traduction en ligne", webOk, if(webOk) "Autorisée." else "Bloquée par le pare-feu confidentialité (Lockdown actif)."))
            diagCol.addView(spacer(2))

            val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            diagCol.addView(diagRow("Micro (commandes vocales)", micOk, if(micOk) "Autorisé." else "Permission refusée — voir AUTORISATIONS ci-dessous."))
            diagCol.addView(spacer(2))

            val accExp = "${ctx.packageName}/${VanelleAccessibilityService::class.java.canonicalName}"
            val accEn = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            var accOk = false
            if (accEn != null) { val sp = TextUtils.SimpleStringSplitter(':'); sp.setString(accEn); while (sp.hasNext()) { if (sp.next().equals(accExp, true)) { accOk = true; break } } }
            diagCol.addView(diagRow("Lecture / remplissage d'écran", accOk, if(accOk) "Service d'accessibilité actif." else "Service d'accessibilité désactivé — voir AUTORISATIONS ci-dessous."))
            diagCol.addView(spacer(2))

            val overlayOk = OverlayHelper.canDraw(ctx)
            diagCol.addView(diagRow("Mascotte flottante", overlayOk, if(overlayOk) "Autorisation d'affichage accordée." else "Autorisation « afficher par-dessus les autres apps » manquante."))
        }
        refreshDiag(); refreshers.add(::refreshDiag)
        col.addView(diagCol); col.addView(spacer(12))

        val retryBtn = Button(ctx).apply{
            text="Réessayer le chargement IA"; textSize=10.5f; background=UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            setOnClickListener{
                try { LocalLlamaHelper.get(ctx).resetLoadFailure() } catch (_: Exception) {}
                DataDownloadService.start(ctx)
                Toast.makeText(ctx,"Nouvelle tentative de chargement lancée…",Toast.LENGTH_SHORT).show()
                view?.postDelayed({ refreshDiag() }, 1500)
            }
        }
        col.addView(retryBtn); col.addView(spacer(12))
        val privacyCard = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            background = VanelleBrand.privacyBanner(ctx)
        }
        privacyCard.addView(TextView(ctx).apply {
            text = "100 % privé par défaut"
            setTextColor(VanelleBrand.ROSE); textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        privacyCard.addView(TextView(ctx).apply {
            text = "Le modèle IA tourne uniquement sur ton téléphone. Aucune clé API cloud."
            setTextColor(0xFF444444.toInt()); textSize = 12f; setPadding(0, 6, 0, 0)
        })
        col.addView(privacyCard); col.addView(spacer(12))
        val statsCard = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            background = UiKit.card(ctx)
        }
        val statsTxt = TextView(ctx).apply {
            text = UsageStats.summary(ctx) + "\n\n" + NativePerf.status(ctx)
            setTextColor(0xFF000000.toInt()); textSize = 12f
        }
        statsCard.addView(statsTxt)
        col.addView(statsCard); col.addView(spacer(28))

        col.addView(sectionTitle("PERSONNALITÉ"))
        val persCard = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            background = UiKit.card(ctx)
        }
        persCard.addView(TextView(ctx).apply {
            text = "Ton de Vanelle (visible et contrôlable)"
            setTextColor(0xFF000000.toInt()); textSize = 13f
        })
        val persRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 10, 0, 0) }
        for ((id, label) in listOf("pote" to "Pote", "calme" to "Calme", "coach" to "Coach", "energique" to "Énergie")) {
            val b = Button(ctx).apply {
                text = label; textSize = 10f
                background = if (PersonalityPrefs.getPersonality(ctx) == id) VanelleBrand.roseOutline(ctx) else UiKit.pill(ctx)
                setTextColor(0xFF000000.toInt())
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 4 }
                setOnClickListener {
                    PersonalityPrefs.setPersonality(ctx, id)
                    Toast.makeText(ctx, "Personnalité : $label", Toast.LENGTH_SHORT).show()
                }
            }
            persRow.addView(b)
        }
        persCard.addView(persRow)
        col.addView(persCard); col.addView(spacer(28))

        // --- Autorisations ---
        col.addView(sectionTitle("AUTORISATIONS"))

        // Aide commune : Android 13+ bloque certaines autorisations (accessibilité, SMS...)
        // pour les apps installées hors Play Store tant qu'on n'a pas explicitement débloqué
        // les « paramètres restreints » dans l'écran Infos de l'application.
        fun showRestrictedSettingsHelp(extra: String = "") {
            AlertDialog.Builder(ctx)
                .setTitle("Autorisation bloquée par Android")
                .setMessage(
                    "Depuis Android 13, une app installée hors Play Store (comme Vanelle OS) " +
                    "doit d'abord être débloquée manuellement avant de pouvoir accorder certaines " +
                    "autorisations sensibles.$extra\n\n" +
                    "Dans l'écran qui va s'ouvrir :\n" +
                    "1. Touche le menu ⋮ en haut à droite\n" +
                    "2. Choisis « Autoriser les paramètres restreints »\n" +
                    "3. Reviens ici et réessaie d'accorder l'autorisation"
                )
                .setPositiveButton("Ouvrir les réglages de l'appli") { _, _ ->
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply { data = Uri.fromParts("package", ctx.packageName, null) }
                    startActivity(intent)
                }
                .setNegativeButton("Annuler", null)
                .show()
        }

        fun permRow(label:String, permission:String, consequence:String, restrictedHint:Boolean=false):View{
            val col2=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
            val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
            val labelView=TextView(ctx).apply{text=label; setTextColor(0xFF000000.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
            val statusView=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
            val manageBtn=Button(ctx).apply{
                text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
                setOnClickListener{
                    val granted=ContextCompat.checkSelfPermission(ctx,permission)==PackageManager.PERMISSION_GRANTED
                    if(restrictedHint && !granted && Build.VERSION.SDK_INT>=33){
                        showRestrictedSettingsHelp(
                            " C'est la cause la plus fréquente quand l'envoi de SMS reste " +
                            "\u00ab non accordée \u00bb même après avoir accepté la demande."
                        )
                    } else {
                        val intent=Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply{ data=Uri.fromParts("package",ctx.packageName,null) }
                        startActivity(intent)
                    }
                }
            }
            val consLabel=TextView(ctx).apply{text="Si refuse : $consequence"; setTextColor(0xFF444444.toInt()); textSize=10f; setPadding(0,8,0,0)}
            fun refresh(){
                val granted=ContextCompat.checkSelfPermission(ctx,permission)==PackageManager.PERMISSION_GRANTED
                statusView.text=if(granted) "Accordee" else "Non accordee"
                statusView.setTextColor(if(granted) 0xFF000000.toInt() else 0xFFEF4444.toInt())
            }
            refresh(); refreshers.add(::refresh)
            row.addView(labelView); row.addView(statusView); row.addView(manageBtn)
            col2.addView(row); col2.addView(consLabel)
            return col2
        }

        col.addView(permRow("Microphone (ecoute vocale)", Manifest.permission.RECORD_AUDIO, "impossible d'utiliser les commandes vocales"))
        col.addView(spacer(2))
        col.addView(permRow("Contacts (appel par nom)", Manifest.permission.READ_CONTACTS, "impossible de trouver un contact par son nom"))
        col.addView(spacer(2))
        col.addView(permRow("Appel telephonique", Manifest.permission.CALL_PHONE, "les demandes d'appel resteront sans effet, meme apres confirmation"))
        col.addView(spacer(2))
        col.addView(permRow("Envoi de SMS", Manifest.permission.SEND_SMS, "les demandes d'envoi de message resteront sans effet, meme apres confirmation", restrictedHint=true))
        col.addView(spacer(2))
        if(Build.VERSION.SDK_INT>=33){
            col.addView(permRow("Notifications", Manifest.permission.POST_NOTIFICATIONS, "la notification d'ecoute active et les rappels de relances ne s'afficheront pas"))
            col.addView(spacer(2))
        }

        // Accessibilite (mecanisme different : reglage systeme, pas une permission classique)
        val accCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val accRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val accLabel=TextView(ctx).apply{text="Service d'accessibilite (actions systeme)"; setTextColor(0xFF000000.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val accStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val accBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            setOnClickListener{
                val exp="${ctx.packageName}/${VanelleAccessibilityService::class.java.canonicalName}"
                val en=Settings.Secure.getString(ctx.contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                var granted=false
                if(en!=null){ val split=TextUtils.SimpleStringSplitter(':'); split.setString(en); while(split.hasNext()){ if(split.next().equals(exp,true)){ granted=true; break } } }
                if(!granted && Build.VERSION.SDK_INT>=33){
                    showRestrictedSettingsHelp(
                        " C'est la cause la plus fréquente quand le service d'accessibilité " +
                        "reste grisé ou refuse de s'activer."
                    )
                } else {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
        }
        fun refreshAcc(){
            val exp="${ctx.packageName}/${VanelleAccessibilityService::class.java.canonicalName}"
            val en=Settings.Secure.getString(ctx.contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            var granted=false
            if(en!=null){ val split=TextUtils.SimpleStringSplitter(':'); split.setString(en); while(split.hasNext()){ if(split.next().equals(exp,true)){ granted=true; break } } }
            accStatus.text=if(granted) "Accordee" else "Non accordee"
            accStatus.setTextColor(if(granted) 0xFF000000.toInt() else 0xFFEF4444.toInt())
        }
        refreshAcc(); refreshers.add(::refreshAcc)
        accRow.addView(accLabel); accRow.addView(accStatus); accRow.addView(accBtn)
        val accCons=TextView(ctx).apply{text="Si refuse : les commandes retour/accueil/notifications/recents ne fonctionneront pas"; setTextColor(0xFF444444.toInt()); textSize=10f; setPadding(0,8,0,0)}
        accCol.addView(accRow); accCol.addView(accCons)
        col.addView(accCol); col.addView(spacer(2))

        // Alarmes exactes (necessaire pour l'onglet Relances)
        val alarmCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val alarmRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val alarmLabel=TextView(ctx).apply{text="Alarmes exactes (relances a l'heure precise)"; setTextColor(0xFF000000.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val alarmStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val alarmBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            setOnClickListener{ if(Build.VERSION.SDK_INT>=31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:${ctx.packageName}"))) }
        }
        fun refreshAlarm(){
            val granted=AlarmScheduler.canScheduleExact(ctx)
            alarmStatus.text=if(granted) "Accordee" else "Non accordee"
            alarmStatus.setTextColor(if(granted) 0xFF000000.toInt() else 0xFFEF4444.toInt())
        }
        refreshAlarm(); refreshers.add(::refreshAlarm)
        alarmRow.addView(alarmLabel); alarmRow.addView(alarmStatus); alarmRow.addView(alarmBtn)
        val alarmCons=TextView(ctx).apply{text="Si refuse : les relances programmees peuvent se declencher en retard, plus jamais a l'heure exacte"; setTextColor(0xFF444444.toInt()); textSize=10f; setPadding(0,8,0,0)}
        alarmCol.addView(alarmRow); alarmCol.addView(alarmCons)
        col.addView(alarmCol); col.addView(spacer(2))

        // Affichage par-dessus les autres apps (mascotte sur l'ecran principal)
        val overlayCol=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
        val overlayRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
        val overlayLabel=TextView(ctx).apply{text="Affichage sur l'ecran principal"; setTextColor(0xFF000000.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        val overlayStatus=TextView(ctx).apply{textSize=11f; setPadding(0,0,20,0)}
        val overlayBtn=Button(ctx).apply{
            text="Gerer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            setOnClickListener{ OverlayHelper.requestPermission(ctx) }
        }
        fun refreshOverlay(){
            val granted=OverlayHelper.canDraw(ctx)
            overlayStatus.text=if(granted) "Accordee" else "Non accordee"
            overlayStatus.setTextColor(if(granted) 0xFF000000.toInt() else 0xFFEF4444.toInt())
        }
        refreshOverlay(); refreshers.add(::refreshOverlay)
        overlayRow.addView(overlayLabel); overlayRow.addView(overlayStatus); overlayRow.addView(overlayBtn)
        val overlayCons=TextView(ctx).apply{text="Si refuse : la mascotte repond seulement dans une fenetre de l'app, pas par-dessus ton ecran habituel"; setTextColor(0xFF444444.toInt()); textSize=10f; setPadding(0,8,0,0)}
        overlayCol.addView(overlayRow); overlayCol.addView(overlayCons)
        col.addView(overlayCol); col.addView(spacer(28))

        // --- Mode traduction : activation vocale uniquement ---
        col.addView(sectionTitle("MODE TRADUCTION"))
        val trRow=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,20,24,20); background=UiKit.card(ctx)}
        val trLabel=TextView(ctx).apply{
            text="Dis dans le micro : « passe en mode traduction de l'anglais vers le français »"
            setTextColor(0xFF000000.toInt()); textSize=12f
        }
        val trStatus=TextView(ctx).apply{
            text=if(TranslateModePrefs.isActive(ctx))
                "Actif : ${TranslateHelper.labelFor(TranslateModePrefs.source(ctx))} → ${TranslateHelper.labelFor(TranslateModePrefs.target(ctx))}"
            else "Inactif"
            textSize=11f; setTextColor(0xFF444444.toInt()); setPadding(0,10,0,0)
        }
        val langLabels = TranslateHelper.UI_LANGUAGES.map { it.first }.toTypedArray()
        val langCodes = TranslateHelper.UI_LANGUAGES.map { it.second }
        fun pickLang(title: String, currentCode: String, onPick: (String) -> Unit) {
            val idx = langCodes.indexOfFirst { it.equals(currentCode, true) }.coerceAtLeast(0)
            AlertDialog.Builder(ctx).setTitle(title)
                .setSingleChoiceItems(langLabels, idx) { d, which ->
                    onPick(langCodes[which])
                    d.dismiss()
                }
                .setNegativeButton("Annuler", null).show()
        }
        val trBtns = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 10, 0, 0) }
        val srcBtn = Button(ctx).apply {
            text = "Source"; textSize = 10f; background = UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 6 }
            setOnClickListener {
                pickLang("Langue source", TranslateModePrefs.source(ctx)) { code ->
                    val t = TranslateModePrefs.target(ctx)
                    if (TranslateModePrefs.isActive(ctx)) TranslateModePrefs.start(ctx, code, t)
                    else { TranslateModePrefs.start(ctx, code, t); TranslateModePrefs.stop(ctx) }
                    trStatus.text = "Source : ${TranslateHelper.labelFor(code)}"
                }
            }
        }
        val tgtBtn = Button(ctx).apply {
            text = "Cible"; textSize = 10f; background = UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 6 }
            setOnClickListener {
                pickLang("Langue cible", TranslateModePrefs.target(ctx)) { code ->
                    val s = TranslateModePrefs.source(ctx)
                    if (TranslateModePrefs.isActive(ctx)) TranslateModePrefs.start(ctx, s, code)
                    else { TranslateModePrefs.start(ctx, s, code); TranslateModePrefs.stop(ctx) }
                    trStatus.text = "Cible : ${TranslateHelper.labelFor(code)}"
                }
            }
        }
        val toggleTr = Button(ctx).apply {
            text = if (TranslateModePrefs.isActive(ctx)) "Arrêter" else "Activer"
            textSize = 10f; background = UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener {
                if (TranslateModePrefs.isActive(ctx)) {
                    TranslateModePrefs.stop(ctx)
                    text = "Activer"
                    trStatus.text = "Inactif"
                } else {
                    TranslateModePrefs.start(ctx, TranslateModePrefs.source(ctx), TranslateModePrefs.target(ctx).let { if (it == "auto") "fr" else it })
                    text = "Arrêter"
                    trStatus.text = "Actif : ${TranslateHelper.labelFor(TranslateModePrefs.source(ctx))} → ${TranslateHelper.labelFor(TranslateModePrefs.target(ctx))}"
                }
            }
        }
        trBtns.addView(srcBtn); trBtns.addView(tgtBtn); trBtns.addView(toggleTr)
        trRow.addView(trLabel); trRow.addView(trStatus)
        col.addView(trRow); col.addView(trBtns); col.addView(spacer(28))
        refreshers.add{
            val active=TranslateModePrefs.isActive(ctx)
            trStatus.text=if(active)
                "Actif : ${TranslateHelper.labelFor(TranslateModePrefs.source(ctx))} → ${TranslateHelper.labelFor(TranslateModePrefs.target(ctx))}"
            else "Inactif"
            toggleTr.text = if (active) "Arrêter" else "Activer"
        }

        col.addView(spacer(28))

        // --- Bouton mascotte flottant (déclenchement manuel, plus fiable que le mot de réveil) ---
        col.addView(sectionTitle("VOIX DE L'IA"))
        val voiceCard = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            background = UiKit.card(ctx)
        }
        val voiceHint = TextView(ctx).apply {
            text = "Débit, hauteur et voix française du moteur TTS de ton téléphone."
            setTextColor(0xFF444444.toInt()); textSize = 11f; setPadding(0, 0, 0, 12)
        }
        voiceCard.addView(voiceHint)

        // Débit
        val rateLabel = TextView(ctx).apply {
            text = "Débit : ${"%.1f".format(VoicePrefs.getRate(ctx))}"
            setTextColor(0xFF000000.toInt()); textSize = 13f
        }
        val rateBar = SeekBar(ctx).apply {
            max = 15 // 0.5 .. 2.0 step 0.1
            progress = ((VoicePrefs.getRate(ctx) - 0.5f) * 10f).toInt().coerceIn(0, 15)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val r = 0.5f + p / 10f
                    rateLabel.text = "Débit : ${"%.1f".format(r)}"
                    if (fromUser) VoicePrefs.setRate(ctx, r)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        voiceCard.addView(rateLabel); voiceCard.addView(rateBar)

        // Hauteur
        val pitchLabel = TextView(ctx).apply {
            text = "Hauteur : ${"%.1f".format(VoicePrefs.getPitch(ctx))}"
            setTextColor(0xFF000000.toInt()); textSize = 13f; setPadding(0, 12, 0, 0)
        }
        val pitchBar = SeekBar(ctx).apply {
            max = 15
            progress = ((VoicePrefs.getPitch(ctx) - 0.5f) * 10f).toInt().coerceIn(0, 15)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val r = 0.5f + p / 10f
                    pitchLabel.text = "Hauteur : ${"%.1f".format(r)}"
                    if (fromUser) VoicePrefs.setPitch(ctx, r)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        voiceCard.addView(pitchLabel); voiceCard.addView(pitchBar)

        // Voix installées
        val voiceListLabel = TextView(ctx).apply {
            text = "Voix française : chargement…"
            setTextColor(0xFF000000.toInt()); textSize = 13f; setPadding(0, 14, 0, 6)
        }
        voiceCard.addView(voiceListLabel)
        val voiceButtons = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
        }
        voiceCard.addView(voiceButtons)

        // TTS temporaire pour lister + tester
        var previewTts: TextToSpeech? = null
        previewTts = TextToSpeech(ctx.applicationContext) { status ->
            if (status != TextToSpeech.SUCCESS) {
                voiceListLabel.text = "Voix : moteur TTS indisponible"
                return@TextToSpeech
            }
            VoicePrefs.apply(ctx, previewTts)
            val voices = VoicePrefs.listFrenchVoices(previewTts)
            val current = VoicePrefs.getVoiceName(ctx)
            if (voices.isEmpty()) {
                voiceListLabel.text = "Aucune voix FR listée — la voix système par défaut sera utilisée."
            } else {
                voiceListLabel.text = "Choisis une voix (${voices.size} disponible(s)) :"
                voiceButtons.removeAllViews()
                // Option défaut
                val defBtn = Button(ctx).apply {
                    text = if (current.isBlank()) "• Défaut système" else "Défaut système"
                    textSize = 11f; background = UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
                    setOnClickListener {
                        VoicePrefs.setVoiceName(ctx, "")
                        VoicePrefs.apply(ctx, previewTts)
                        previewTts?.speak("Bonjour, je suis Vanelle.", TextToSpeech.QUEUE_FLUSH, null, "preview")
                        Toast.makeText(ctx, "Voix par défaut", Toast.LENGTH_SHORT).show()
                    }
                }
                voiceButtons.addView(defBtn)
                for (v in voices.take(8)) {
                    val label = VoicePrefs.labelFor(v)
                    val selected = v.name == current
                    val b = Button(ctx).apply {
                        text = if (selected) "• $label" else label
                        textSize = 10f; background = UiKit.pill(ctx)
                        setTextColor(if (selected) 0xFF000000.toInt() else 0xFF000000.toInt())
                        setOnClickListener {
                            VoicePrefs.setVoiceName(ctx, v.name)
                            VoicePrefs.apply(ctx, previewTts)
                            previewTts?.speak("Bonjour, je suis Vanelle.", TextToSpeech.QUEUE_FLUSH, null, "preview")
                            Toast.makeText(ctx, "Voix sélectionnée", Toast.LENGTH_SHORT).show()
                        }
                    }
                    voiceButtons.addView(b)
                }
            }
        }

        val testBtn = Button(ctx).apply {
            text = "Tester la voix"
            textSize = 12f; background = UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            setOnClickListener {
                try {
                    if (previewTts == null) {
                        Toast.makeText(ctx, "Moteur TTS en cours de chargement…", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    VoicePrefs.apply(ctx, previewTts)
                    val prenom = RelationalMemory(ctx).displayName()
                    val sample = if (prenom.isNotBlank()) "$prenom, bonjour, je suis Vanelle."
                    else "Bonjour, je suis Vanelle."
                    previewTts?.speak(sample, TextToSpeech.QUEUE_FLUSH, null, "preview")
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Test impossible : ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
        voiceCard.addView(testBtn)
        col.addView(voiceCard); col.addView(spacer(28))

        col.addView(sectionTitle("BOUTON MASCOTTE"))
        val floatRow=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,20,24,20); background=UiKit.card(ctx)}
        val floatLabel=TextView(ctx).apply{
            text="Mascotte flottante : clique dessus pour activer le micro"
            setTextColor(0xFF000000.toInt()); textSize=13f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)
        }
        val floatSw=Switch(ctx).apply{
            isChecked = FloatingMascotButton.isEnabled(ctx)
            setOnCheckedChangeListener{ sw, checked ->
                if (checked && !OverlayHelper.canDraw(ctx)) {
                    sw.isChecked = false
                    AlertDialog.Builder(ctx)
                        .setTitle("Autorisation nécessaire")
                        .setMessage("Pour afficher le bouton par-dessus les autres applis, autorise Vanelle OS dans les réglages système qui vont s'ouvrir.")
                        .setPositiveButton("Ouvrir les réglages"){_,_-> OverlayHelper.requestPermission(ctx) }
                        .setNegativeButton("Annuler",null)
                        .show()
                    return@setOnCheckedChangeListener
                }
                FloatingMascotButton.setEnabled(ctx, checked)
                Toast.makeText(ctx, if(checked) "Bouton mascotte activé" else "Bouton mascotte désactivé", Toast.LENGTH_SHORT).show()
            }
        }
        floatRow.addView(floatLabel); floatRow.addView(floatSw)
        col.addView(floatRow)

        // Curseur de taille (réagit tout de suite si le bouton est déjà affiché)
        val sizeCol = LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,16,24,16); background=UiKit.card(ctx)}
        val sizeLabel = TextView(ctx).apply{
            text = "Taille du bouton : ${FloatingMascotButton.getSizeDp(ctx)} dp"
            setTextColor(0xFF000000.toInt()); textSize=13f
        }
        val sizeBar = SeekBar(ctx).apply{
            max = FloatingMascotButton.MAX_SIZE_DP - FloatingMascotButton.MIN_SIZE_DP
            progress = FloatingMascotButton.getSizeDp(ctx) - FloatingMascotButton.MIN_SIZE_DP
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean){
                    val sizeDp = FloatingMascotButton.MIN_SIZE_DP + p
                    sizeLabel.text = "Taille du bouton : $sizeDp dp"
                    if (fromUser) FloatingMascotButton.setSizeDp(ctx, sizeDp)
                }
                override fun onStartTrackingTouch(sb: SeekBar?){}
                override fun onStopTrackingTouch(sb: SeekBar?){}
            })
        }
        sizeCol.addView(sizeLabel); sizeCol.addView(sizeBar)
        col.addView(sizeCol); col.addView(spacer(28))

        // --- Sauvegarde / changement de téléphone ---
        col.addView(sectionTitle("SAUVEGARDE & CHANGEMENT DE TELEPHONE"))
        val backupInfo = TextView(ctx).apply {
            text = "Active la sauvegarde Google pour retrouver mémoire, relances et préférences après réinstallation. Pour un autre téléphone : exporte le fichier puis importe-le ici."
            setTextColor(0xFF444444.toInt()); textSize = 12f; setPadding(24, 18, 24, 12); background = UiKit.card(ctx)
        }
        col.addView(backupInfo); col.addView(spacer(8))

        val sysBackupBtn = Button(ctx).apply {
            text = "Activer la sauvegarde systeme"
            textSize = 12f
            background = UiKit.pill(ctx)
            setTextColor(0xFF000000.toInt())
            setOnClickListener {
                try { UserDataSnapshot.save(ctx) } catch (_: Exception) {}
                val landedOnToggle = UserDataSnapshot.openSystemBackupSettings(ctx)
                if (landedOnToggle) {
                    Toast.makeText(ctx, "Active le bouton \u00ab Sauvegarder sur Google Drive \u00bb en haut de l'écran", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(ctx, "Depuis les réglages : Système puis Sauvegarde, et active \u00ab Sauvegarder sur Google Drive \u00bb", Toast.LENGTH_LONG).show()
                }
            }
        }
        col.addView(sysBackupBtn); col.addView(spacer(8))

        val exportBtn = Button(ctx).apply {
            text = "Exporter mes donnees"
            textSize = 12f
            background = UiKit.pill(ctx)
            setTextColor(0xFF000000.toInt())
            setOnClickListener {
                try {
                    val intent = UserDataSnapshot.shareIntent(ctx)
                    startActivity(Intent.createChooser(intent, "Exporter la sauvegarde VanelleOS"))
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Export impossible : ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        col.addView(exportBtn); col.addView(spacer(8))

        val importBtn = Button(ctx).apply {
            text = "Importer mes donnees"
            textSize = 12f
            background = UiKit.pill(ctx)
            setTextColor(0xFF000000.toInt())
            setOnClickListener {
                try {
                    importLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Import impossible : ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        col.addView(importBtn); col.addView(spacer(28))

        sv.addView(col); return sv
    }
    override fun onResume(){ super.onResume(); refreshers.forEach{ it() } }
}
class FeaturesFragment:Fragment(){
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val sv=ScrollView(ctx).apply{setBackgroundColor(0xFFFFFFFF.toInt())}
        val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(28,32,28,32)}
        fun spacer(h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,h)}
        val items=listOf(
            Triple("Ouvrir une application","Ouvre Spotify","L'application s'ouvre directement."),
            Triple("Appeler un contact","Appelle Paul","Une fenetre de confirmation apparait avant l'appel reel."),
            Triple("Envoyer un message","Envoie un message a Paul texte j'arrive","Confirmation affichee, puis le SMS part une fois valide."),
            Triple("Recherche","Cherche comment faire un tiramisu","Ouvre une recherche web avec ta demande."),
            Triple("YouTube","YouTube Stromae","YouTube s'ouvre avec la recherche."),
            Triple("Traduction","Traduis hello how are you","La traduction est prononcee a voix haute."),
            Triple("Mode traduction","Mode traduction (plusieurs langues)","Choisis source et cible dans Configuration. Chaque phrase captée est traduite et lue jusqu'à désactivation."),
            Triple("Memoire","Retiens que mon code wifi est X / Rappelle-moi mon code wifi","Stockage local, retrouve sur demande."),
            Triple("Urgence","Urgence","Ouvre l'appel d'urgence 112."),
            Triple("Telephone perdu","Retrouve mon telephone","Alarme sonore et vibration meme en silencieux."),
            Triple("Navigation","Navigue vers la Tour Eiffel","Maps s'ouvre avec l'itineraire."),
            Triple("Calculatrice","Calculatrice","Ouvre la calculatrice du telephone."),
            Triple("Batterie","Batterie","Annonce le niveau de batterie a voix haute."),
            Triple("Relance programmee","Rappelle-moi d'appeler Paul a 18h30","Alarme reelle visible dans l'onglet Relances."),
            Triple("Retour / Accueil","Retour ou accueil","Action systeme reelle via le service d'accessibilite (a activer)."),
            Triple("Lire l'ecran","Lis l'ecran","Lit le texte affiche (accessibilite requise)."),
            Triple("Resume d'ecran","Résume l'ecran","Lit puis resume le texte visible (accessibilite + IA locale si disponible)."),
            Triple("Copilote ecran","Remplis avec mon adresse 12 rue de Paris","Saisit le texte dans le champ actif (accessibilite requise — touche d'abord le champ)."),
            Triple("Journal","Journal d'activite","Recapitulatif recent des actions Vanelle."),
            Triple("Camera","Ouvre la camera","Ouvre l'appareil photo.")
        )
        for((name,example,result) in items){
            val card=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(22,20,22,20); background=UiKit.card(ctx)}
            val title=TextView(ctx).apply{text=name; setTextColor(0xFF000000.toInt()); textSize=13f; typeface=android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL)}
            val ex=TextView(ctx).apply{text="Dis : \u00ab $example \u00bb"; setTextColor(0xFF000000.toInt()); textSize=11.5f; setPadding(0,8,0,4)}
            val res=TextView(ctx).apply{text=result; setTextColor(0xFF444444.toInt()); textSize=11f}
            card.addView(title); card.addView(ex); card.addView(res)
            col.addView(card); col.addView(spacer(10))
        }
        sv.addView(col); return sv
    }
}
class RelanceFragment:Fragment(){
    private var rebuildUi: (() -> Unit)? = null

    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{
        val ctx=requireContext()
        val root=FrameLayout(ctx).apply{setBackgroundColor(0xFFFFFFFF.toInt())}
        fun rebuild(){
            root.removeAllViews()
            val sv=ScrollView(ctx).apply{setBackgroundColor(0xFFFFFFFF.toInt())}
            val col=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(28,32,28,32)}
            fun sectionTitle(t:String)=TextView(ctx).apply{text=t; setTextColor(0xFF444444.toInt()); textSize=11f; letterSpacing=0.1f; setPadding(4,0,0,10)}
            fun spacer(h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(-1,h)}
            val fmt=java.text.SimpleDateFormat("dd/MM HH:mm",java.util.Locale.FRANCE)
            val repo=RelanceRepository(ctx)

            col.addView(sectionTitle("A VENIR"))
            val tasks=repo.getTasks()
            if(tasks.isEmpty()) col.addView(TextView(ctx).apply{text="Aucune relance programmee. Dis : Rappelle-moi d'appeler Paul a 18h30"; setTextColor(0xFF444444.toInt()); textSize=12f; setPadding(24,16,24,16)})
            for(task in tasks){
                val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL; setPadding(24,18,24,18); background=UiKit.card(ctx)}
                val displayDesc=if(task.description.startsWith("routine:")) task.description.substringAfter("|",task.description) else task.description
                val label=TextView(ctx).apply{
                    text="$displayDesc\n${task.hour.toString().padStart(2,'0')}h${task.minute.toString().padStart(2,'0')}${if(task.repeatDaily) " - tous les jours" else " - une fois"}"
                    setTextColor(0xFF000000.toInt()); textSize=12f; layoutParams=LinearLayout.LayoutParams(0,-2,1f)
                }
                val delBtn=Button(ctx).apply{
                    text="Supprimer"; textSize=10f; background=UiKit.pill(ctx); setTextColor(0xFFEF4444.toInt())
                    setOnClickListener{
                        try {
                            AlarmScheduler.cancel(ctx, task.id)
                            repo.removeTask(task.id)
                            android.widget.Toast.makeText(ctx, "Relance supprimee", android.widget.Toast.LENGTH_SHORT).show()
                        } catch (_:Exception) {}
                        rebuild()
                    }
                }
                row.addView(label); row.addView(delBtn)
                col.addView(row); col.addView(spacer(8))
            }
            col.addView(spacer(28))

            col.addView(sectionTitle("HISTORIQUE"))
            val history=repo.getHistory()
            if(history.isEmpty()) col.addView(TextView(ctx).apply{text="Aucune relance executee pour le moment."; setTextColor(0xFF444444.toInt()); textSize=12f; setPadding(24,16,24,16)})
            for(h in history.take(30)){
                val row=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL; setPadding(24,16,24,16); background=UiKit.card(ctx)}
                val labelTop=TextView(ctx).apply{text=h.description; setTextColor(0xFF000000.toInt()); textSize=12f}
                val labelBottom=TextView(ctx).apply{text="${fmt.format(java.util.Date(h.executedAt))} - ${h.result}"; setTextColor(0xFF444444.toInt()); textSize=10f; setPadding(0,4,0,0)}
                row.addView(labelTop); row.addView(labelBottom)
                col.addView(row); col.addView(spacer(8))
            }
            sv.addView(col)
            root.addView(sv)
        }
        rebuildUi = { rebuild() }
        rebuild()
        return root
    }
    override fun onResume(){
        super.onResume()
        rebuildUi?.invoke()
    }
}

/**
 * Chat texte avec Vanelle — même historique que la mascotte vocale.
 */
/**
 * Conversation : chat actif + historique organisé (dossiers, tags, recherche).
 */
class ChatFragment : Fragment() {
    private var listCol: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var titleView: TextView? = null
    private var modeHistory = false

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 8)
            setBackgroundColor(0xFFF7F7F8.toInt())
        }

        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(4, 4, 4, 8)
        }
        val title = TextView(ctx).apply {
            text = "Conversation"
            setTextColor(0xFF0A0A0A.toInt()); textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        titleView = title
        val histBtn = Button(ctx).apply {
            text = "Historique"; textSize = 10f
            background = UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            setOnClickListener {
                modeHistory = !modeHistory
                text = if (modeHistory) "Chat" else "Historique"
                refresh(ctx)
            }
        }
        val newBtn = Button(ctx).apply {
            text = "+"; textSize = 14f
            background = VanelleBrand.rosePill(ctx); setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener {
                ChatHistory.newThread(ctx)
                modeHistory = false
                histBtn.text = "Historique"
                refresh(ctx)
                Toast.makeText(ctx, "Nouvelle conversation", Toast.LENGTH_SHORT).show()
            }
        }
        top.addView(title); top.addView(histBtn); top.addView(newBtn)
        root.addView(top)

        val sv = ScrollView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            isFillViewport = true
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 4, 4, 12)
        }
        listCol = col
        scroll = sv
        sv.addView(col)
        root.addView(sv)

        // Zone saisie (masquée en mode historique)
        val inputRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(4, 8, 4, 4)
            background = UiKit.card(ctx)
            tag = "input_row"
        }
        val input = EditText(ctx).apply {
            hint = "Message à Vanelle…"
            setTextColor(0xFF000000.toInt())
            setHintTextColor(0xFF888888.toInt())
            textSize = 14f
            minLines = 1; maxLines = 4
            background = null
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val send = Button(ctx).apply {
            text = "Envoyer"; textSize = 12f
            background = UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
        }
        send.setOnClickListener {
            val msg = input.text?.toString()?.trim().orEmpty()
            if (msg.isBlank()) return@setOnClickListener
            input.setText("")
            appendBubble(ctx, col, "user", msg)
            scrollToBottom()
            send.isEnabled = false
            viewLifecycleOwner.lifecycleScope.launch {
                val res = try {
                    CommandInterpreter(ctx).execute(msg)
                } catch (e: Exception) {
                    "Erreur : ${e.message ?: "inconnue"}"
                }
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    appendBubble(ctx, col, "assistant", res)
                    scrollToBottom()
                    send.isEnabled = true
                    updateTitle(ctx)
                }
            }
        }
        inputRow.addView(input); inputRow.addView(send)
        root.addView(inputRow)

        val actions = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val clear = Button(ctx).apply {
            text = "Effacer fil"; textSize = 10f
            background = UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 4 }
            setOnClickListener {
                AlertDialog.Builder(ctx)
                    .setTitle("Effacer ce fil ?")
                    .setMessage("Supprime les messages de la conversation active.")
                    .setPositiveButton("Effacer") { _, _ ->
                        ChatHistory.clear(ctx); refresh(ctx)
                    }
                    .setNegativeButton("Annuler", null).show()
            }
        }
        val export = Button(ctx).apply {
            text = "Exporter"; textSize = 10f
            background = UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 4 }
            setOnClickListener { ChatExport.share(ctx) }
        }
        val folderBtn = Button(ctx).apply {
            text = "Dossier"; textSize = 10f
            background = UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener { pickFolder(ctx) }
        }
        actions.addView(clear); actions.addView(export); actions.addView(folderBtn)
        root.addView(actions)

        refresh(ctx)
        return root
    }

    override fun onResume() {
        super.onResume()
        refresh(requireContext())
    }

    private fun updateTitle(ctx: android.content.Context) {
        val th = ChatHistory.thread(ctx, ChatHistory.activeId(ctx))
        titleView?.text = th?.title?.take(28) ?: "Conversation"
    }

    private fun refresh(ctx: android.content.Context) {
        val col = listCol ?: return
        col.removeAllViews()
        val inputRow = (view as? ViewGroup)?.let { findInputRow(it) }
        if (modeHistory) {
            inputRow?.visibility = View.GONE
            showHistory(ctx, col)
        } else {
            inputRow?.visibility = View.VISIBLE
            updateTitle(ctx)
            for (m in ChatHistory.messages(ctx)) {
                appendBubble(ctx, col, m.role, m.text)
            }
            scrollToBottom()
        }
    }

    private fun findInputRow(v: View): View? {
        if (v.tag == "input_row") return v
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                findInputRow(v.getChildAt(i))?.let { return it }
            }
        }
        return null
    }

    private fun showHistory(ctx: android.content.Context, col: LinearLayout) {
        col.addView(TextView(ctx).apply {
            text = "Recherche & dossiers"
            setTextColor(0xFF6B7280.toInt()); textSize = 12f; setPadding(8, 4, 8, 8)
        })
        val search = EditText(ctx).apply {
            hint = "Rechercher…"
            setTextColor(0xFF000000.toInt())
            setHintTextColor(0xFF888888.toInt())
            textSize = 13f
            background = UiKit.card(ctx)
            setPadding(24, 16, 24, 16)
        }
        col.addView(search)

        val folderRow = HorizontalScrollView(ctx)
        val folderInner = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 8) }
        var filterFolder: String? = null
        fun rebuildList() {
            // remove old list items after folder row (keep search + folders)
            while (col.childCount > 3) col.removeViewAt(3)
            val q = search.text?.toString().orEmpty()
            var threads = if (q.isNotBlank()) ChatHistory.search(ctx, q) else ChatHistory.allThreads(ctx)
            filterFolder?.let { f -> threads = threads.filter { it.folder.equals(f, true) } }
            if (threads.isEmpty()) {
                col.addView(TextView(ctx).apply {
                    text = "Aucune conversation."
                    setTextColor(0xFF888888.toInt()); setPadding(16, 24, 16, 16)
                })
                return
            }
            for (th in threads) {
                col.addView(threadCard(ctx, th))
            }
        }
        for (f in ChatHistory.folders(ctx)) {
            val b = Button(ctx).apply {
                text = f; textSize = 10f
                background = UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
                setOnClickListener {
                    filterFolder = if (filterFolder == f) null else f
                    rebuildList()
                }
            }
            folderInner.addView(b)
        }
        folderRow.addView(folderInner)
        col.addView(folderRow)

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { rebuildList() }
        })
        rebuildList()
    }

    private fun threadCard(ctx: android.content.Context, th: ChatHistory.Thread): View {
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 16, 22, 16)
            background = VanelleBrand.card(ctx)
        }
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(TextView(ctx).apply {
            text = th.title.ifBlank { "Sans titre" }
            setTextColor(0xFF0A0A0A.toInt()); textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        val active = th.id == ChatHistory.activeId(ctx)
        if (active) {
            head.addView(TextView(ctx).apply {
                text = "Active"; setTextColor(VanelleBrand.ROSE); textSize = 11f
            })
        }
        card.addView(head)
        val meta = buildString {
            append(th.folder)
            if (th.tags.isNotEmpty()) append(" · ").append(th.tags.joinToString(", "))
            append(" · ").append(th.messages.size).append(" msg")
        }
        card.addView(TextView(ctx).apply {
            text = meta
            setTextColor(0xFF6B7280.toInt()); textSize = 11f; setPadding(0, 4, 0, 8)
        })
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val open = Button(ctx).apply {
            text = "Ouvrir"; textSize = 10f
            background = VanelleBrand.rosePill(ctx); setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 4 }
            setOnClickListener {
                ChatHistory.setActive(ctx, th.id)
                modeHistory = false
                refresh(ctx)
            }
        }
        val tagBtn = Button(ctx).apply {
            text = "Tags"; textSize = 10f
            background = UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 4 }
            setOnClickListener { editTags(ctx, th) }
        }
        val del = Button(ctx).apply {
            text = "Suppr."; textSize = 10f
            background = UiKit.pill(ctx); setTextColor(0xFF000000.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener {
                AlertDialog.Builder(ctx)
                    .setTitle("Supprimer ?")
                    .setMessage(th.title)
                    .setPositiveButton("Supprimer") { _, _ ->
                        ChatHistory.deleteThread(ctx, th.id)
                        refresh(ctx)
                    }
                    .setNegativeButton("Annuler", null).show()
            }
        }
        row.addView(open); row.addView(tagBtn); row.addView(del)
        card.addView(row)
        val wrap = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 10)
            addView(card)
        }
        return wrap
    }

    private fun pickFolder(ctx: android.content.Context) {
        val folders = ChatHistory.folders(ctx).toTypedArray()
        val id = ChatHistory.activeId(ctx)
        AlertDialog.Builder(ctx)
            .setTitle("Dossier de la conversation")
            .setItems(folders) { _, which ->
                ChatHistory.setFolder(ctx, id, folders[which])
                Toast.makeText(ctx, "Dossier : ${folders[which]}", Toast.LENGTH_SHORT).show()
                updateTitle(ctx)
            }
            .setNeutralButton("Nouveau…") { _, _ ->
                val input = EditText(ctx).apply { hint = "Nom du dossier" }
                AlertDialog.Builder(ctx).setTitle("Nouveau dossier").setView(input)
                    .setPositiveButton("Créer") { _, _ ->
                        val n = input.text?.toString()?.trim().orEmpty()
                        if (n.isNotBlank()) {
                            ChatHistory.addFolder(ctx, n)
                            ChatHistory.setFolder(ctx, id, n)
                            Toast.makeText(ctx, "Dossier : $n", Toast.LENGTH_SHORT).show()
                        }
                    }.setNegativeButton("Annuler", null).show()
            }
            .setNegativeButton("Annuler", null).show()
    }

    private fun editTags(ctx: android.content.Context, th: ChatHistory.Thread) {
        val input = EditText(ctx).apply {
            setText(th.tags.joinToString(", "))
            hint = "ex: projet, urgent, idée"
        }
        AlertDialog.Builder(ctx).setTitle("Tags").setView(input)
            .setPositiveButton("OK") { _, _ ->
                val tags = input.text?.toString()?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() } ?: emptyList()
                ChatHistory.setTags(ctx, th.id, tags)
                refresh(ctx)
            }.setNegativeButton("Annuler", null).show()
    }

    private fun appendBubble(ctx: android.content.Context, col: LinearLayout, role: String, text: String) {
        val isUser = role.equals("user", true)
        val bubble = TextView(ctx).apply {
            this.text = text
            setTextColor(if (isUser) 0xFFFFFFFF.toInt() else 0xFF111111.toInt())
            textSize = 14f
            setPadding(28, 20, 28, 20)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = 36f
                setColor(if (isUser) 0xFF0A0A0A.toInt() else 0xFFFFFFFF.toInt())
                if (!isUser) setStroke(2, 0xFFE5E5E5.toInt())
            }
        }
        val wrap = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(if (isUser) 48 else 4, 6, if (isUser) 4 else 48, 6)
            gravity = if (isUser) android.view.Gravity.END else android.view.Gravity.START
            addView(bubble)
        }
        col.addView(wrap)
    }

    private fun scrollToBottom() {
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }
}
