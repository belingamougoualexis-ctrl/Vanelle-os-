package com.vanelle.os

import android.content.Context
import org.json.JSONObject

/**
 * Cache de réponses fréquentes — zéro latence, zéro hallucination sur les cas stables.
 * Clé = message normalisé ; TTL léger pour ne pas figer indéfiniment.
 */
object ResponseCache {
    private const val PREFS = "vanelle_response_cache"
    private const val MAX_ENTRIES = 80
    private const val TTL_MS = 7L * 24 * 60 * 60 * 1000 // 7 jours

    private fun p(c: Context) = c.getSharedPreferences(PREFS, 0)

    private fun keyOf(q: String): String =
        q.lowercase()
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(120)

    fun get(c: Context, question: String): String? {
        val k = keyOf(question)
        if (k.length < 4) return null
        val raw = p(c).getString(k, null) ?: return null
        return try {
            val o = JSONObject(raw)
            val ts = o.optLong("ts", 0L)
            if (System.currentTimeMillis() - ts > TTL_MS) {
                p(c).edit().remove(k).apply()
                null
            } else o.optString("a").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

    fun put(c: Context, question: String, answer: String) {
        val k = keyOf(question)
        val a = answer.trim()
        if (k.length < 4 || a.length < 8 || a.length > 800) return
        // Ne cache pas les erreurs / non-prêt
        val lower = a.lowercase()
        if (lower.contains("je ne sais pas") && a.length < 40) return
        if (lower.contains("pas encore prête") || lower.contains("téléchargement")) return
        try {
            val prefs = p(c)
            val o = JSONObject().put("ts", System.currentTimeMillis()).put("a", a.take(600))
            val ed = prefs.edit().putString(k, o.toString())
            // Éviction basique si trop d'entrées
            if (prefs.all.size >= MAX_ENTRIES) {
                val oldest = prefs.all.entries
                    .mapNotNull { (key, v) ->
                        try {
                            key to JSONObject(v as String).optLong("ts", 0L)
                        } catch (_: Exception) {
                            null
                        }
                    }
                    .sortedBy { it.second }
                    .take(20)
                oldest.forEach { ed.remove(it.first) }
            }
            ed.apply()
        } catch (_: Exception) {}
    }
}
