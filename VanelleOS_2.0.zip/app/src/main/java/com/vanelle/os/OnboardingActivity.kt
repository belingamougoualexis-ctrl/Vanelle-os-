package com.vanelle.os

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Onboarding : valeur en < 30 s + démo immédiate + argument vie privée.
 */
class OnboardingActivity : AppCompatActivity() {

    companion object {
        private const val PREF = "vanelle_onboarding"
        fun shouldShow(c: Context): Boolean =
            !c.getSharedPreferences(PREF, 0).getBoolean("done", false)
        fun markDone(c: Context) {
            c.getSharedPreferences(PREF, 0).edit().putBoolean("done", true).apply()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = ScrollView(this).apply {
            setBackgroundColor(VanelleBrand.WHITE)
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 40)
        }

        val badge = TextView(this).apply {
            text = "100 % privé · tout sur ton téléphone"
            setTextColor(VanelleBrand.ROSE)
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(20, 12, 20, 12)
            background = VanelleBrand.privacyBanner(this@OnboardingActivity)
            gravity = Gravity.CENTER
        }
        col.addView(badge)

        val title = TextView(this).apply {
            text = "Vanelle"
            setTextColor(VanelleBrand.BLACK)
            textSize = 32f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 28, 0, 8)
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "Ton assistante locale.\nAucune donnée envoyée au cloud par défaut."
            setTextColor(VanelleBrand.GRAY)
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(8, 0, 8, 28)
        }
        col.addView(title)
        col.addView(sub)

        fun demoCard(emoji: String, titleT: String, body: String, action: String, onClick: () -> Unit) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(28, 22, 28, 22)
                background = VanelleBrand.card(this@OnboardingActivity)
            }
            card.addView(TextView(this).apply {
                text = "$emoji  $titleT"
                setTextColor(VanelleBrand.BLACK)
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
            })
            card.addView(TextView(this).apply {
                text = body
                setTextColor(VanelleBrand.GRAY)
                textSize = 13f
                setPadding(0, 8, 0, 14)
            })
            card.addView(Button(this).apply {
                text = action
                setTextColor(VanelleBrand.WHITE)
                background = VanelleBrand.rosePill(this@OnboardingActivity)
                setOnClickListener { onClick() }
            })
            col.addView(card)
            col.addView(Space(this).apply {
                layoutParams = LinearLayout.LayoutParams(-1, 16)
            })
        }

        demoCard(
            "⚡", "Essaie en 5 secondes",
            "Demande l’heure, la batterie, ou « ouvre YouTube » — Vanelle agit tout de suite sur ton téléphone.",
            "Lancer une démo"
        ) {
            lifecycleScope.launch {
                val r = withContext(Dispatchers.IO) {
                    try {
                        CommandInterpreter(this@OnboardingActivity).execute("quelle est ma batterie")
                    } catch (e: Exception) {
                        "Démo : ouvre Configuration pour activer l’IA, puis réessaie."
                    }
                }
                Toast.makeText(this@OnboardingActivity, r.take(120), Toast.LENGTH_LONG).show()
            }
        }

        demoCard(
            "🔒", "Mode hors-ligne assumé",
            "Le modèle tourne sur l’appareil. Web et cloud restent optionnels et sous ton contrôle (pare-feu).",
            "Compris"
        ) {
            Toast.makeText(this, "Préférence offline active par défaut", Toast.LENGTH_SHORT).show()
        }

        demoCard(
            "🎭", "Personnalité",
            "Pote, calme, coach ou énergique — tu choisis le ton de Vanelle.",
            "Choisir « Pote »"
        ) {
            PersonalityPrefs.setPersonality(this, "pote")
            Toast.makeText(this, "Personnalité : Pote bienveillante", Toast.LENGTH_SHORT).show()
        }

        val start = Button(this).apply {
            text = "Entrer dans Vanelle"
            setTextColor(VanelleBrand.WHITE)
            textSize = 16f
            background = VanelleBrand.rosePill(this@OnboardingActivity)
            setPadding(24, 28, 24, 28)
            setOnClickListener {
                markDone(this@OnboardingActivity)
                startActivity(Intent(this@OnboardingActivity, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK))
                finish()
            }
        }
        col.addView(Space(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 24)
        })
        col.addView(start)

        val skip = TextView(this).apply {
            text = "Passer"
            setTextColor(VanelleBrand.GRAY)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
            setOnClickListener {
                markDone(this@OnboardingActivity)
                finish()
            }
        }
        col.addView(skip)

        root.addView(col)
        setContentView(root)
    }
}
