package com.vanelle.os

/**
 * Orchestration du raisonnement pour un petit modèle local.
 *
 * Principe : le 1B ne "raisonne" pas bien en une passe libre.
 * On force une structure (décomposition, faits vs déductions, auto-check)
 * et on réserve le CoT aux questions qui en ont besoin.
 *
 * Ce n'est pas un second cerveau — c'est un pipeline autour de Llama.
 */
object ReasoningHelper {

    private val COMPLEX = Regex(
        """(?i)(pourquoi|comment\s+(?:ça|fonctionne|marche|expliquer)|explique|compar(?:e|er)|différence|analyse|prouve|déduis|calcule|étape|raisonne|avantages?\s+et\s+inconvénients?|pour\s+ou\s+contre|que\s+se\s+passe|implique|conséquence)"""
    )
    private val MATH = Regex(
        """(?i)(?:combien|calcule|calcul|somme|produit|différence|divis|multipli|\d+\s*[\+\-\*/×÷]\s*\d+|pourcentage|%|\d+\s*(?:plus|moins|fois))"""
    )
    private val FACTUAL = Regex(
        """(?i)(?:c['']est\s+quoi|qu['']est[- ]ce\s+que|qui\s+est|quelle?\s+est|défini|date|capitale|population|mesure)"""
    )

    fun isComplex(t: String): Boolean =
        t.length > 60 || COMPLEX.containsMatchIn(t) || (MATH.containsMatchIn(t) && t.length > 20)

    fun isMathLike(t: String): Boolean = MATH.containsMatchIn(t)

    fun isFactualLookup(t: String): Boolean = FACTUAL.containsMatchIn(t) && t.length < 120

    /**
     * Raisonnement forcé mais **réponse finale seule à afficher**.
     * Format strict pour pouvoir élague le CoT visible (latence perçue).
     */
    fun buildStructuredPrompt(userMessage: String, hasExternalFacts: Boolean): String {
        val base = userMessage.trim()
        return buildString {
            append(base)
            append("\n\nRaisonne brièvement en interne, puis réponds UNIQUEMENT dans ce format :\n")
            append("BROUILLON: (2-4 puces max : faits")
            if (hasExternalFacts) append(" issus du contexte")
            append(" vs déductions ; si fragile, note-le)\n")
            append("RÉPONSE: (2-6 phrases claires, complètes, pour l'utilisateur — c'est la seule partie utile)\n")
            append("Règles : n'invente rien ; si tu ne sais pas, dis-le dans RÉPONSE ; pas de présentation.")
        }
    }

    /**
     * Extrait la partie parlée / affichée : priorise « RÉPONSE: », sinon texte nettoyé.
     * Coupe le chain-of-thought visible pour la latence et le confort vocal.
     */
    fun extractSpokenAnswer(raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return t
        // Bloc RÉPONSE: … (fin ou jusqu'à une autre section)
        Regex("""(?is)RÉPONSE\s*:\s*(.+)$""").find(t)?.groupValues?.getOrNull(1)?.let { body ->
            val clean = body.trim()
                .removePrefix("assistant").trim()
            if (clean.length >= 8) return clean
        }
        Regex("""(?is)(?:conclusion|réponse finale)\s*:\s*(.+)$""").find(t)?.groupValues?.getOrNull(1)?.let { body ->
            val clean = body.trim()
            if (clean.length >= 8) return clean
        }
        // Retire un préambule BROUILLON: … s'il est en tête
        var out = t
        if (out.contains("BROUILLON:", ignoreCase = true)) {
            out = out.substringAfter("RÉPONSE:", missingDelimiterValue = out)
                .substringAfter("Réponse:", missingDelimiterValue = out)
                .trim()
        }
        // Retire listes numérotées de méthode si le modèle a ignoré le format
        val lines = out.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val withoutSteps = lines.filterNot { line ->
            Regex("""^(?:BROUILLON|FAITS|DÉDUCTIONS)\s*:""").containsMatchIn(line) ||
                Regex("""^\d+\)\s*(?:Reformule|Liste|Sépare|Raisonne|Conclusion|Auto-check)""").containsMatchIn(line)
        }
        return withoutSteps.joinToString(" ").ifBlank { out }.trim()
    }

    /** Prompt court pour questions simples — intention + fiabilité seulement. */
    fun buildSimplePrompt(userMessage: String): String =
        userMessage.trim() +
            "\n\nRéponds à l'intention réelle. Si tu ne sais pas, dis-le. N'invente rien. Pas de présentation."

    /**
     * Prompt de reformulation après faits web/RAG :
     * le modèle ne "sait" pas — il raisonne sur des sources.
     */
    fun buildRagPrompt(question: String): String =
        "Question : ${question.trim()}\n\n" +
            "Tu n'utilises QUE les infos fournies dans le contexte (et le bon sens minimal). " +
            "Si le contexte est insuffisant, dis-le clairement. " +
            "Sépare FAITS (tirés du contexte) et DÉDUCTIONS. " +
            "Réponds en français, structuré, complet, sans te présenter."

    /**
     * Calcul arithmétique simple déterministe (vérification externe des étapes critiques).
     * Retourne null si ce n'est pas un calcul trivial fiable.
     */
    fun tryDeterministicMath(t: String): String? {
        val s = t.lowercase()
            .replace('×', '*')
            .replace('÷', '/')
            .replace("plus", "+")
            .replace("moins", "-")
            .replace("fois", "*")
            .replace(',', '.')
        // a + b, a - b, a * b, a / b avec nombres simples
        val m = Regex("""(\d+(?:\.\d+)?)\s*([\+\-\*/])\s*(\d+(?:\.\d+)?)""").find(s) ?: return null
        val a = m.groupValues[1].toDoubleOrNull() ?: return null
        val op = m.groupValues[2]
        val b = m.groupValues[3].toDoubleOrNull() ?: return null
        val r = when (op) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            "/" -> if (b == 0.0) return "Division par zéro : impossible." else a / b
            else -> return null
        }
        val pretty = if (r == r.toLong().toDouble()) r.toLong().toString() else String.format("%.4f", r).trimEnd('0').trimEnd('.')
        return "Résultat : $pretty (calcul exact, pas une estimation)."
    }

    /**
     * Détecte une réponse trop confiante sans substance (heuristique anti-bluff).
     */
    fun looksOverconfidentBluff(text: String): Boolean {
        val t = text.lowercase()
        if (t.length < 40) return false
        val bluff = listOf(
            "il est évident que", "tout le monde sait", "sans aucun doute",
            "c'est certain que", "absolument certain", "je peux garantir"
        )
        val hedge = listOf("peut-être", "probablement", "il semble", "je ne suis pas", "hypothèse", "si je comprends")
        val bluffHits = bluff.count { t.contains(it) }
        val hedgeHits = hedge.count { t.contains(it) }
        return bluffHits >= 1 && hedgeHits == 0 && !t.contains("je ne sais")
    }
}
