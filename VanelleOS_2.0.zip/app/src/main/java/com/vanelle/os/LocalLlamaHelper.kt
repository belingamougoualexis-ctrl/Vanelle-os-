package com.vanelle.os

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.yield
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min

/**
 * Wrapper optimisé autour de llamacpp-kotlin (réflexion).
 *
 * Optimisations :
 * - Instance unique process-wide (un seul chargement du modèle)
 * - n_ctx adapté à la RAM (384–1024) pour limiter OOM
 * - Prompt système compact (moins de tokens de préfill)
 * - Contexte utilisateur tronqué
 * - Timeout adaptatif selon la taille de la requête
 * - warmUp() au démarrage de l'app
 * - Mutex pour sérialiser les inférences (un seul contexte natif)
 * - Succès de charge détecté via callback (Long) ET événement Loaded du SharedFlow
 * - Pas de boucle de 10+ tentatives : 2 essais max (ctx optimal puis repli)
 */
class LocalLlamaHelper private constructor(private val appContext: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val events = MutableSharedFlow<Any>(extraBufferCapacity = 512, replay = 0)

    @Volatile private var loaded = false
    @Volatile private var loading = false
    @Volatile private var loadFailedPermanently = false
    @Volatile private var helper: Any? = null
    @Volatile private var resolvedClass: Class<*>? = null
    private val answerMutex = Mutex()
    private val loadMutex = Mutex()

    private fun resolveLlamaClass(): Class<*>? {
        resolvedClass?.let { return it }
        val candidates = listOf(
            "org.nehuatl.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacpp.LlamaHelper",
            "io.github.ljcamargo.llamacppkotlin.LlamaHelper",
            "com.ljcamargo.llamacpp.LlamaHelper"
        )
        for (name in candidates) {
            try {
                val c = Class.forName(name)
                resolvedClass = c
                android.util.Log.i("VanelleLlama", "LlamaHelper résolu: $name")
                return c
            } catch (_: ClassNotFoundException) {}
        }
        android.util.Log.e("VanelleLlama", "Aucune classe LlamaHelper trouvée parmi: $candidates")
        return null
    }

    /** Fenêtre de contexte : priorise la vitesse (préfill) sur le mobile. */
    private fun optimalContextLength(): Int {
        // Vitesse : n_ctx bas = préfill plus rapide (mémoire-bound sur mobile).
        // 256–512 suffit pour Vanelle (outils + fil court).
        return try {
            val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memMb = am.largeMemoryClass
            val ramMb = LlamaModelManager.totalRamMb(appContext)
            when {
                ramMb >= 6144 && memMb >= 512 -> 512
                ramMb >= 4096 -> 384
                else -> 256
            }
        } catch (_: Exception) {
            384
        }
    }

    @Volatile private var lastLoadError: String? = null

    fun lastError(): String? = lastLoadError

    private suspend fun ensureLoaded(): Boolean {
        if (loaded && helper != null) return true
        if (loadFailedPermanently) return false
        if (!LlamaModelManager.isReady(appContext)) {
            lastLoadError = "Modèle non téléchargé."
            return false
        }
        return loadMutex.withLock {
            if (loaded && helper != null) return@withLock true
            if (loadFailedPermanently) return@withLock false
            if (loading) {
                // Attendre un chargement concurrent déjà en cours (max 120 s)
                repeat(120) {
                    kotlinx.coroutines.delay(1000)
                    if (loaded && helper != null) return@withLock true
                    if (!loading) return@withLock (loaded && helper != null)
                }
                return@withLock (loaded && helper != null)
            }
            loading = true
            try {
                // Llama est toujours tenté en priorité. Plusieurs contextes
                // permettent de réduire la mémoire KV/cache sur les appareils faibles.
                val contexts = listOf(optimalContextLength(), 384, 256, 192).distinct()
                var ok = false
                for ((attempt, nCtx) in contexts.withIndex()) {
                    if (attempt > 0) {
                        try { System.gc() } catch (_: Exception) {}
                        kotlinx.coroutines.delay(1500)
                    }
                    ok = tryLoadOnce(nCtx, timeoutMs = 120_000L)
                    if (ok) {
                        lastLoadError = null
                        android.util.Log.i("VanelleLlama", "Modèle chargé (n_ctx=$nCtx, tentative=${attempt + 1})")
                        AiLoadDiagnostics.logSuccess(appContext, "chargé avec n_ctx=$nCtx (tentative ${attempt + 1}/${contexts.size})")
                        return@withLock true
                    }
                }
                loadFailedPermanently = true
                if (lastLoadError == null) {
                    lastLoadError = LlamaModelManager.memoryWarning(appContext)
                        ?: "Impossible de charger l'IA en mémoire. Ferme d'autres apps, libère de la RAM, puis rouvre VanelleOS."
                }
                android.util.Log.e("VanelleLlama", "Échec du chargement unique: $lastLoadError")
                AiLoadDiagnostics.logFailure(appContext, lastLoadError ?: "cause inconnue", attempt = contexts.size)
                false
            } catch (e: Exception) {
                android.util.Log.e("VanelleLlama", "ensureLoaded exception", e)
                loadFailedPermanently = true
                lastLoadError = "Erreur de chargement : ${e.message ?: "inconnue"}"
                AiLoadDiagnostics.logFailure(appContext, lastLoadError ?: "exception inconnue")
                false
            } finally {
                loading = false
            }
        }
    }

    private suspend fun tryLoadOnce(nCtx: Int, timeoutMs: Long): Boolean {
        return try {
            val klass = resolveLlamaClass()
            if (klass == null) {
                lastLoadError = "Bibliothèque IA locale absente (variante modern / 64 bits requise)."
                return false
            }
            val ctor = try {
                klass.getConstructor(
                    android.content.ContentResolver::class.java,
                    CoroutineScope::class.java,
                    MutableSharedFlow::class.java
                )
            } catch (e: Exception) {
                android.util.Log.e("VanelleLlama", "Constructeur LlamaHelper introuvable", e)
                lastLoadError = "API LlamaHelper incompatible."
                null
            } ?: return false

            val modelFile = LlamaModelManager.modelFile(appContext)
            if (!modelFile.exists() || modelFile.length() != LlamaModelManager.EXPECTED_MIN_BYTES ||
                !LlamaModelManager.verifyModelIntegrity(appContext)) {
                lastLoadError = "Fichier modèle manquant, tronqué ou corrompu. Le téléchargement sera vérifié avant un nouvel essai."
                android.util.Log.e("VanelleLlama", "Intégrité GGUF invalide: ${modelFile.length()} octets")
                return false
            }

            // URI stable : FileProvider si possible, sinon file://
            val modelUri = try {
                androidx.core.content.FileProvider.getUriForFile(
                    appContext,
                    "${appContext.packageName}.fileprovider",
                    modelFile
                ).toString()
            } catch (_: Exception) {
                Uri.fromFile(modelFile).toString()
            }

            // Libère un peu de heap avant le gros mmap/load natif
            try { System.gc() } catch (_: Exception) {}

            val h = ctor.newInstance(appContext.contentResolver, scope, events)

            // Signature officielle v0.4.0 :
            // load(path, contextLength, mmprojPath?, loaded: (Long) -> Unit)
            val loadMethod = try {
                klass.getMethod(
                    "load",
                    String::class.java,
                    Int::class.javaPrimitiveType,
                    String::class.java,
                    kotlin.jvm.functions.Function1::class.java
                )
            } catch (_: Exception) {
                klass.methods.firstOrNull { m -> m.name == "load" && m.parameterTypes.size >= 2 }
            }
            if (loadMethod == null) {
                lastLoadError = "Méthode load() introuvable dans la bibliothèque IA."
                return false
            }

            val ok = withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    val done = java.util.concurrent.atomic.AtomicBoolean(false)
                    fun complete(success: Boolean) {
                        if (done.compareAndSet(false, true) && cont.isActive) {
                            cont.resume(success)
                        }
                    }

                    val watchJob = scope.launch {
                        try {
                            events.takeWhile { event ->
                                when (event.javaClass.simpleName) {
                                    "Loaded" -> {
                                        complete(true)
                                        false
                                    }
                                    "Error" -> {
                                        android.util.Log.w("VanelleLlama", "LLMEvent.Error: $event")
                                        lastLoadError = "Erreur native lors du chargement du modèle."
                                        complete(false)
                                        false
                                    }
                                    else -> true
                                }
                            }.collect { }
                        } catch (_: Exception) {}
                    }

                    try {
                        val callback = object : kotlin.jvm.functions.Function1<Long, Unit> {
                            override fun invoke(id: Long) {
                                android.util.Log.i("VanelleLlama", "Callback load OK, contextId=$id")
                                complete(true)
                            }
                        }
                        when (loadMethod.parameterTypes.size) {
                            4 -> loadMethod.invoke(h, modelUri, nCtx, null, callback)
                            3 -> {
                                try {
                                    loadMethod.invoke(h, modelUri, nCtx, callback)
                                } catch (_: Exception) {
                                    loadMethod.invoke(h, modelUri, nCtx, null)
                                }
                            }
                            2 -> loadMethod.invoke(h, modelUri, nCtx)
                            else -> loadMethod.invoke(h, modelUri)
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("VanelleLlama", "invoke load failed", e)
                        lastLoadError = "Échec chargement : ${e.message ?: e.javaClass.simpleName}"
                        complete(false)
                    }

                    cont.invokeOnCancellation { watchJob.cancel() }
                }
            } ?: run {
                lastLoadError = "Délai dépassé lors du chargement en mémoire."
                false
            }

            if (ok) {
                helper = h
                try { NativePerf.tryTuneHelper(h) } catch (_: Exception) {}
                loaded = true
                loadFailedPermanently = false
                lastLoadError = null
            } else {
                android.util.Log.w("VanelleLlama", "tryLoadOnce(nCtx=$nCtx): échec — $lastLoadError")
            }
            ok
        } catch (e: Exception) {
            android.util.Log.e("VanelleLlama", "tryLoadOnce(nCtx=$nCtx) exception", e)
            lastLoadError = "Erreur : ${e.message ?: "inconnue"}"
            false
        }
    }

    /**
     * Précharge le modèle. ensureLoaded() gère déjà son propre réessai interne
     * (contexte optimal puis repli) — pas besoin de reboucler par-dessus ici.
     */
    suspend fun warmUp(): Boolean = withContext(Dispatchers.IO) {
        if (!LlamaModelManager.isReady(appContext)) return@withContext false
        if (loaded && helper != null) return@withContext true
        if (loadFailedPermanently) return@withContext false
        ensureLoaded()
    }

    fun isLoaded(): Boolean = loaded && helper != null

    /** Réinitialise le flag d'échec permanent (ex. après redémarrage app ou nouvel essai manuel). */
    fun resetLoadFailure() {
        loadFailedPermanently = false
        lastLoadError = null
    }

    /**
     * @param maxTokensHint limite soft : on demande l'arrêt natif, mais on attend toujours Done
     *                      pour récupérer le texte complet (évite les phrases coupées).
     * @param fastMode prompt encore plus court + timeout réduit (commandes simples)
     */
    suspend fun answer(
        userPrompt: String,
        extraContext: String = "",
        fastMode: Boolean = false,
        maxTokensHint: Int = if (fastMode) 100 else 160
    ): String = answerMutex.withLock {
        if (!ensureLoaded()) return@withLock NOT_READY
        val h = helper ?: return@withLock NOT_READY
        val klass = h.javaClass

        val formatted = buildPrompt(userPrompt, extraContext, fastMode)
        val timeoutMs = adaptiveTimeoutMs(formatted.length, fastMode)

        return@withLock try {
            // Signature officielle (kotlinllamacpp / org.nehuatl.llamacpp.LlamaHelper) :
            //   fun predict(prompt: String, imagePath: String? = null, partialCompletion: Boolean = true)
            // JVM : predict(String, String, boolean) — le 3e argument est un boolean primitif.
            // predict() ne retourne rien : la réponse arrive via le SharedFlow<LLMEvent>
            // (Started / Ongoing(word,tokenCount) / Done / Error).
            // Priorité : signature à 3 args (la vraie), puis 2 args, puis fallback générique.
            val method3Args = try {
                klass.getMethod(
                    "predict",
                    String::class.java,
                    String::class.java,
                    Boolean::class.javaPrimitiveType
                )
            } catch (_: Exception) {
                try {
                    // Certaines builds exposent Boolean boxed au lieu de boolean primitif
                    klass.getMethod(
                        "predict",
                        String::class.java,
                        String::class.java,
                        Boolean::class.java
                    )
                } catch (_: Exception) { null }
            }
            val method2Args = try {
                klass.getMethod("predict", String::class.java, String::class.java)
            } catch (_: Exception) { null }
            val method1Arg = try {
                klass.getMethod("predict", String::class.java)
            } catch (_: Exception) { null }

            val predictMethod = method3Args ?: method2Args ?: method1Arg
                ?: listOf("predict", "generate", "complete", "chat", "ask")
                    .asSequence()
                    .flatMap { name -> klass.methods.asSequence().filter { it.name == name } }
                    .filter { it.parameterTypes.isNotEmpty() && String::class.java.isAssignableFrom(it.parameterTypes[0]) }
                    .sortedByDescending { it.parameterTypes.size } // préférer la version complète
                    .firstOrNull()
                ?: run {
                    val allNames = klass.methods.map { it.name }.distinct().sorted()
                    AiLoadDiagnostics.logFailure(
                        appContext,
                        "Réponse : aucune méthode de génération trouvée sur la bibliothèque IA " +
                            "(predict/generate/complete/chat/ask absentes). Méthodes disponibles : $allNames"
                    )
                    return@withLock NOT_READY
                }

            // Construction robuste des arguments :
            // - arg0 = prompt (String)
            // - imagePath (String?) = null → texte seul
            // - partialCompletion (boolean/Boolean) = true (défaut bibliothèque)
            // Ne jamais passer null à un paramètre primitif (boolean/int/long) → crash « got null ».
            fun buildArgs(method: java.lang.reflect.Method, prompt: String): Array<Any?> {
                val types = method.parameterTypes
                return Array(types.size) { idx ->
                    val type = types[idx]
                    when {
                        idx == 0 -> prompt
                        type == Boolean::class.javaPrimitiveType || type == Boolean::class.java -> true
                        type == Int::class.javaPrimitiveType || type == Integer::class.java -> 0
                        type == Long::class.javaPrimitiveType || type == java.lang.Long::class.java -> 0L
                        type == Float::class.javaPrimitiveType || type == java.lang.Float::class.java -> 0f
                        type == Double::class.javaPrimitiveType || type == java.lang.Double::class.java -> 0.0
                        CharSequence::class.java.isAssignableFrom(type) || type == String::class.java -> null // imagePath
                        else -> null
                    }
                }
            }

            // Best-effort, aligné sur le cycle de vie officiel de la démo (stopPrediction() est
            // appelé après Done/Error) : évite de laisser le moteur natif "en génération" et de
            // casser l'appel suivant.
            fun stopPredictionQuietly() {
                try { klass.getMethod("stopPrediction").invoke(h) } catch (_: Exception) {}
            }

            // Important : le SharedFlow a un buffer. Sans drain, les événements d'une
            // génération précédente (souvent une intro générique) sont rejoués à l'infini.
            drainEventsBuffer()

            withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<String> { cont ->
                    val job = scope.launch {
                        try {
                            val sb = StringBuilder(maxTokensHint * 6)
                            var tokenApprox = 0
                            var doneFullText: String? = null
                            var generationStarted = false
                            var stopRequested = false

                            val collector = launch {
                                try {
                                    // On s'arrête UNIQUEMENT sur Done / Error — jamais au milieu d'un Ongoing
                                    // (sinon phrases coupées comme « Mais pour commen »).
                                    events.takeWhile { event ->
                                        val name = event.javaClass.simpleName
                                        when {
                                            name == "Started" -> {
                                                generationStarted = true
                                                true
                                            }
                                            !generationStarted -> true
                                            name == "Ongoing" -> {
                                                val word = extractToken(event)
                                                if (word.isNotEmpty()) {
                                                    sb.append(word)
                                                    tokenApprox++
                                                }
                                                // Limite atteinte → demande l'arrêt natif, mais continue jusqu'à Done
                                                if (!stopRequested &&
                                                    (tokenApprox >= maxTokensHint || sb.length >= maxTokensHint * 10)
                                                ) {
                                                    stopRequested = true
                                                    stopPredictionQuietly()
                                                }
                                                true
                                            }
                                            name == "Done" -> {
                                                doneFullText = extractFullText(event)
                                                false
                                            }
                                            name == "Error" -> {
                                                val msg = extractToken(event).ifEmpty {
                                                    try {
                                                        event.javaClass.getMethod("getMessage").invoke(event)?.toString()
                                                    } catch (_: Exception) { null } ?: "erreur inconnue"
                                                }
                                                AiLoadDiagnostics.logFailure(appContext, "Réponse : événement Error du modèle — $msg")
                                                false
                                            }
                                            else -> {
                                                val word = extractToken(event)
                                                if (word.isNotEmpty()) {
                                                    sb.append(word)
                                                    tokenApprox++
                                                }
                                                true
                                            }
                                        }
                                    }.collect { }
                                } catch (_: Exception) {}
                            }

                            yield()
                            val args = buildArgs(predictMethod, formatted)
                            android.util.Log.i(
                                "VanelleLlama",
                                "predict via ${predictMethod.name}(${predictMethod.parameterTypes.joinToString { it.simpleName }}) " +
                                    "promptLen=${formatted.length}"
                            )
                            predictMethod.invoke(h, *args)
                            withTimeoutOrNull(timeoutMs) { collector.join() }
                            collector.cancel()
                            stopPredictionQuietly()

                            // Préférer le texte complet de Done (allText bibliothèque) s'il est plus long
                            val fromStream = sb.toString().trim()
                            val fromDone = doneFullText?.trim().orEmpty()
                            var text = when {
                                fromDone.length >= fromStream.length && fromDone.isNotBlank() -> fromDone
                                fromStream.isNotBlank() -> fromStream
                                else -> fromDone
                            }
                                .removePrefix("assistant")
                                .trim()

                            // Nettoie une coupure en fin de mot si stop anticipé
                            text = finalizeAnswer(text)

                            // Filet anti-intro générique côté moteur
                            if (text.isNotBlank() && looksLikeGenericIntro(text)) {
                                AiLoadDiagnostics.logFailure(
                                    appContext,
                                    "Réponse : intro générique rejetée (« ${text.take(60)}… »)."
                                )
                                text = ""
                            }

                            if (text.isBlank()) {
                                AiLoadDiagnostics.logFailure(
                                    appContext,
                                    "Réponse : aucune sortie exploitable reçue de predict() " +
                                        "(méthode=${predictMethod.name}, args=${predictMethod.parameterCount}, " +
                                        "started=$generationStarted, tokens≈$tokenApprox)."
                                )
                            } else {
                                try {
                                    UsageStats.recordLocalReply(appContext, text.length, 0L)
                                } catch (_: Exception) {}
                                AiLoadDiagnostics.logSuccess(
                                    appContext,
                                    "génération OK (${text.length} car., ~$tokenApprox jetons) : ${text.take(80)}"
                                )
                            }
                            if (cont.isActive) {
                                cont.resume(text.ifBlank { NOT_READY })
                            }
                        } catch (e: Exception) {
                            stopPredictionQuietly()
                            val detail = when (e) {
                                is IllegalArgumentException ->
                                    "appel predict() — ${e.message ?: "argument invalide (souvent null passé à un boolean primitif)"}"
                                is java.lang.reflect.InvocationTargetException ->
                                    "predict() a levé : ${e.cause?.message ?: e.message ?: e.javaClass.simpleName}"
                                else ->
                                    "exception pendant la génération — ${e.message ?: e.javaClass.simpleName}"
                            }
                            AiLoadDiagnostics.logFailure(appContext, "Réponse : $detail")
                            if (cont.isActive) cont.resume(NOT_READY)
                        }
                    }
                    cont.invokeOnCancellation { job.cancel(); stopPredictionQuietly() }
                }
            } ?: run {
                stopPredictionQuietly()
                AiLoadDiagnostics.logFailure(appContext, "Réponse : délai dépassé (${timeoutMs}ms) sans réponse du modèle.")
                NOT_READY
            }
        } catch (e: Exception) {
            AiLoadDiagnostics.logFailure(appContext, "Réponse : exception — ${e.message ?: e.javaClass.simpleName}")
            NOT_READY
        }
    }

    /**
     * Best-effort : essaye d'avaler d'éventuels événements résiduels sans bloquer.
     * La vraie protection reste le flag generationStarted (ignore tout jusqu'au prochain Started).
     */
    private suspend fun drainEventsBuffer() {
        // no-op volontairement léger — le gate generationStarted suffit.
        // (un collect infini sur SharedFlow bloquerait ou ajouterait de la latence)
    }

    /**
     * Finalise une réponse éventuellement coupée :
     * - retire un dernier mot tronqué (ex. « commen »)
     * - assure une ponctuation de fin si la phrase était presque complète
     */
    private fun finalizeAnswer(raw: String): String {
        var t = raw.trim()
        if (t.isEmpty()) return t
        // Supprime préfixes de rôle parfois collés par le modèle
        t = t.removePrefix("assistant").removePrefix("Assistant").trim()
        // Si ça finit par un mot très court sans ponctuation après une virgule/espace → tronqué
        val badEnding = Regex("""[,:;]\s*[A-Za-zÀ-ÿ]{1,5}$""")
        if (badEnding.containsMatchIn(t)) {
            t = t.replace(badEnding, "").trim()
        }
        // Mot final incomplet typique (pas de ponctuation, se termine par lettre seule après espace long)
        val incompleteWord = Regex("""\s([a-zàâäéèêëïîôùûüç]{1,4})$""")
        if (incompleteWord.containsMatchIn(t) && !t.endsWith(".") && !t.endsWith("!") && !t.endsWith("?")) {
            t = t.replace(incompleteWord, "").trim()
        }
        if (t.isNotEmpty() && t.last() !in charArrayOf('.', '!', '?', '…', '»', '"', '\'')) {
            // N'ajoute un point que si la dernière phrase a l'air finie (mot ≥ 3 lettres)
            val lastWord = t.substringAfterLast(' ').trim()
            if (lastWord.length >= 3) t = "$t."
        }
        return t
    }

    /** Détecte les présentations génériques du modèle 1B. */
    private fun looksLikeGenericIntro(text: String): Boolean {
        val t = text.trim()
        if (t.length > 400) return false
        val lower = t.lowercase()
        val markers = listOf(
            "je suis vanelle",
            "votre assistante personnelle",
            "assistante personnelle, chaleureuse",
            "chaleureuse et précise",
            "qu'est-ce que vous souhaitez accomplir",
            "que souhaitez-vous accomplir",
            "conseils personnalisés",
            "trouver des solutions et à résoudre",
            "comment puis-je vous aider aujourd"
        )
        val hits = markers.count { lower.contains(it) }
        return hits >= 2 || (hits >= 1 && t.length < 260)
    }

    private fun extractToken(event: Any): String {
        for (method in listOf("getWord", "getToken", "getText", "getContent", "getMessage")) {
            try {
                val v = event.javaClass.getMethod(method).invoke(event)
                if (v is String && v.isNotEmpty()) return v
            } catch (_: Exception) {}
        }
        try {
            for (f in event.javaClass.declaredFields) {
                f.isAccessible = true
                val v = f.get(event)
                if (v is String && v.isNotEmpty() && v.length < 200) return v
            }
        } catch (_: Exception) {}
        // Kotlin data class properties sometimes only exposed as componentN / fields without getter
        try {
            val comp1 = event.javaClass.getMethod("component1").invoke(event)
            if (comp1 is String && comp1.isNotEmpty()) return comp1
        } catch (_: Exception) {}
        return ""
    }

    /** Pour LLMEvent.Done(fullText, tokenCount, duration) — récupère le texte complet. */
    private fun extractFullText(event: Any): String? {
        for (method in listOf("getFullText", "getText", "getContent", "getMessage", "component1")) {
            try {
                val v = event.javaClass.getMethod(method).invoke(event)
                if (v is String && v.isNotEmpty()) return v
            } catch (_: Exception) {}
        }
        try {
            for (f in event.javaClass.declaredFields) {
                f.isAccessible = true
                val v = f.get(event)
                if (v is String && v.isNotEmpty()) return v
            }
        } catch (_: Exception) {}
        return null
    }

    private fun buildPrompt(userPrompt: String, extraContext: String, fastMode: Boolean): String {
        // Charte Vanelle : fiabilité, mémoire, spécialisation téléphone, intention, honnêteté.
        val system = if (fastMode) {
            "Tu es Vanelle (locale, téléphone). Français. " +
                "Comprends l'intention réelle, réponds utile et complète. " +
                "Si tu ne sais pas → dis-le. N'invente rien. " +
                "Utilise le contexte/mémoire fourni. Ne te présente pas. " +
                "Action téléphone → première ligne ACTION:TYPE|arg."
        } else {
            "Tu es Vanelle, assistante IA locale sur ce téléphone. " +
                "Tu gagnes la confiance par la fiabilité, pas par le bluff. " +
                "Règles : " +
                "• Fiabilité : si tu n'as pas l'info ou le contexte, dis « je ne sais pas » " +
                "ou demande une précision — ne invente jamais faits, chiffres ni actions. " +
                "• Mémoire : profil, faits et conversation fournis = vérité sur l'utilisateur ; " +
                "garde le fil, relie les sujets, résous pronoms et suites. " +
                "• Spécialité : aide concrète sur l'appareil + explications claires ; " +
                "tu n'es pas un oracle universel. " +
                "• Intention : réponds à ce que la personne veut vraiment. " +
                "• Explication : idée principale, détail simple, exemple court si utile. " +
                "• Ton Vanelle : naturelle, précise, utile — pas une copie d'un autre assistant. " +
                "• Ne te présente jamais. Phrases terminées. " +
                "Action téléphone utile → première ligne : " +
                "ACTION:YOUTUBE|q | OPEN_APP|nom | CALL|nom | MESSAGE|nom|texte | " +
                "SEARCH|q | MAPS|lieu | TIMER|min | FLASHLIGHT|on/off | VOLUME|up/down | " +
                "SCREEN_SUMMARY | CLICK|texte. Sinon aucune ligne ACTION."
        }
        val ctx = extraContext.trim().take(if (fastMode) 500 else 1400)
        val user = userPrompt.trim().take(if (fastMode) 600 else 1200)

        return buildString(capacity = 3500) {
            append("<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n")
            append(system)
            if (ctx.isNotBlank()) {
                append("\nContexte: ")
                append(ctx)
            }
            append("\n<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n")
            append(user)
            append("\n<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n")
        }
    }

    private fun adaptiveTimeoutMs(promptChars: Int, fastMode: Boolean): Long {
        // Réponses plus longues → timeout plus généreux (modèle 1B CPU)
        val base = if (fastMode) 45_000L else 90_000L
        val extra = (promptChars / 6).toLong()
        return min(180_000L, max(base, base + extra))
    }

    companion object {
        const val NOT_READY = "__LLAMA_NOT_READY__"

        @Volatile private var instance: LocalLlamaHelper? = null

        fun get(context: Context): LocalLlamaHelper {
            instance?.let { return it }
            synchronized(this) {
                instance?.let { return it }
                val created = LocalLlamaHelper(context.applicationContext)
                instance = created
                return created
            }
        }
    }
}
