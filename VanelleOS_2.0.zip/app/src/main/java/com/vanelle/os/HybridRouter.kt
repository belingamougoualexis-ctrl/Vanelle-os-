package com.vanelle.os

import android.content.Context

/**
 * Routeur hybride local ↔ cloud.
 *
 * Stratégie **edge-first with escalation** :
 * - 80–90 % des cas : local (outils, cache, Llama 1B, web léger)
 * - 10–20 % des cas durs : cloud si autorisé et configuré
 *
 * Le cloud n'est jamais obligatoire : sans clé / offline / lockdown → local only.
 */
object HybridRouter {

    enum class Destination {
        /** Outils / parser / cache — pas de LLM */
        TOOLS,
        /** Llama local (+ mémoire / RAG léger) */
        LOCAL,
        /** Essayer local, escalader cloud si réponse faible */
        LOCAL_THEN_CLOUD,
        /** Aller directement au cloud (cas clairement hors capacité 1B) */
        CLOUD
    }

    data class Decision(
        val dest: Destination,
        val reason: String,
        val score: Int // 0 = trivial local, 100 = cloud fortement recommandé
    )

    private fun p(c: Context) = c.getSharedPreferences("vanelle_hybrid", 0)

    /** off | escalate | cloud_preferred */
    fun mode(c: Context): String = p(c).getString("mode", "escalate") ?: "escalate"
    fun setMode(c: Context, mode: String) {
        if (mode in listOf("off", "escalate", "cloud_preferred"))
            p(c).edit().putString("mode", mode).apply()
    }

    fun cloudConfigured(c: Context): Boolean = CloudLlmClient.isConfigured(c)

    /**
     * Décision pure (sans I/O). Respecte offline, lockdown, préférences.
     */
    fun decide(c: Context, text: String): Decision {
        val t = text.trim()
        if (t.isEmpty()) return Decision(Destination.LOCAL, "vide", 0)

        // Pare-feu / offline strict
        if (PersonalityPrefs.preferOffline(c) || !PrivacyFirewall.allowWeb(c)) {
            return Decision(Destination.LOCAL, "mode offline ou web bloqué — local only", 0)
        }
        if (!LlamaModelManager.isNetworkAvailable(c)) {
            return Decision(Destination.LOCAL, "pas de réseau — local only", 0)
        }

        val mode = mode(c)
        if (mode == "off" || !cloudConfigured(c)) {
            return Decision(Destination.LOCAL, "hybride désactivé ou cloud non configuré", 0)
        }

        var score = 0
        val reasons = mutableListOf<String>()

        if (ReasoningHelper.isComplex(t)) {
            score += 35
            reasons += "raisonnement complexe"
        }
        if (t.length > 220) {
            score += 20
            reasons += "message long"
        }
        if (t.length > 400) {
            score += 15
            reasons += "très long"
        }
        // Multi-contraintes / code / analyse profonde
        if (Regex("""(?i)(étape par étape|prouve|démontre|architecture|optimise|debug|algorithme|preuve|contre[- ]argument)""")
                .containsMatchIn(t)
        ) {
            score += 25
            reasons += "tâche experte"
        }
        // Ambiguïté forte
        if (Regex("""(?i)(ça dépend|plusieurs (?:cas|interprétations)|d'un côté|d'un autre)""")
                .containsMatchIn(t)
        ) {
            score += 10
            reasons += "ambiguïté"
        }
        // Calcul non trivial (pas juste a+b)
        if (ReasoningHelper.isMathLike(t) && ReasoningHelper.tryDeterministicMath(t) == null) {
            score += 15
            reasons += "math non triviale"
        }
        // Fait pointu : plutôt RAG local/web qu'escalade cloud obligatoire
        if (ReasoningHelper.isFactualLookup(t) && !ReasoningHelper.isComplex(t)) {
            score -= 20
            reasons += "fait → web/RAG local prioritaire"
        }

        score = score.coerceIn(0, 100)
        val why = if (reasons.isEmpty()) "cas standard" else reasons.joinToString(", ")

        return when {
            mode == "cloud_preferred" && score >= 25 && cloudConfigured(c) ->
                Decision(Destination.CLOUD, why, score)
            score >= 55 && cloudConfigured(c) ->
                Decision(Destination.CLOUD, why, score)
            score >= 35 && cloudConfigured(c) ->
                Decision(Destination.LOCAL_THEN_CLOUD, why, score)
            else ->
                Decision(Destination.LOCAL, why, score)
        }
    }

    /** Réponse locale jugée trop faible pour rester seule. */
    fun shouldEscalate(localAnswer: String?): Boolean {
        if (localAnswer.isNullOrBlank()) return true
        val a = localAnswer.trim()
        if (a.length < 12) return true
        val lower = a.lowercase()
        if (lower.contains("__llama_not_ready__")) return true
        if (lower.startsWith("je ne sais pas") && a.length < 80) return true
        if (lower.contains("pas encore prête") || lower.contains("n'est pas encore")) return true
        if (ReasoningHelper.looksOverconfidentBluff(a)) return true
        return false
    }

    fun statusLine(c: Context): String {
        val m = mode(c)
        val cfg = cloudConfigured(c)
        return "Hybride : mode=$m, cloud=${if (cfg) "configuré" else "non configuré"}"
    }
}
