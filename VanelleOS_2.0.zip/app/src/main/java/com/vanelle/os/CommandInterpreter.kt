package com.vanelle.os
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CommandInterpreter(private val context: Context) {
    companion object {
        // Actions purement locales/appareil : pas besoin de journaliser l'épisode ni
        // de passer par la détection d'humeur avant de les exécuter (chemin rapide).
        private val FAST_INTENTS = setOf(
            CommandIntent.FLASHLIGHT,
            CommandIntent.VOLUME,
            CommandIntent.RINGER,
            CommandIntent.CLIPBOARD_READ,
            CommandIntent.CLIPBOARD_WRITE,
            CommandIntent.OPEN_URL,
            CommandIntent.SHARE_TEXT,
            CommandIntent.TIMER,
            CommandIntent.BATTERY,
            CommandIntent.OPEN_APP,
            CommandIntent.CALL_CONTACT,
            CommandIntent.SEND_MESSAGE,
            CommandIntent.YOUTUBE,
            CommandIntent.SEARCH_WEB,
            CommandIntent.MAPS,
            CommandIntent.TRANSLATE,
            CommandIntent.SHOW_MASCOT,
            CommandIntent.OPEN_CAMERA,
            CommandIntent.OPEN_GALLERY,
            CommandIntent.EMERGENCY,
            CommandIntent.LOST_PHONE,
            CommandIntent.ACCESSIBILITY_ACTION,
            CommandIntent.READ_SCREEN,
            CommandIntent.MEMORY_GET,
            CommandIntent.MEMORY_SAVE,
            CommandIntent.REMEMBER_FACT
        )
        private val SIMPLE_GREETING = Regex(
            "(?i)^(bonjour|bonsoir|salut|coucou|hello|hey|yo|cc)\\s*[!.,\\s]*$"
        )
    }
    private val apps = AppsRepository(context)
    private val contacts = ContactsRepository(context)
    private val web = WebSearchHelper(context)
    private val yt = YouTubeHelper(context)
    private val tr = TranslateHelper(context)
    private val bat = BatteryHelper(context)
    private val em = EmergencyManager(context)
    private val vault = MemoryVault(context)
    private val maps = MapsHelper(context)
    private val tool = MiniToolGenerator(context)
    private val learner = WorkflowLearner(context)
    private val freeAI = FreeAIHelper(context)
    private val localAI = LocalLlamaHelper.get(context)
    private val relance = RelanceRepository(context)
    private val streaming = StreamingHelper(context)
    private val relational = RelationalMemory(context)
    private val agent = AutonomousAgent(context)
    private val episodic = EpisodicMemory(context)
    private val spatial = SpatialContext(context)
    private val dynamicUi = DynamicUiGenerator(context)
    private val emotion = EmotionEngine(context)
    private val device = DeviceActions(context)

    suspend fun execute(t: String, allowAgents: Boolean = true): String {
        return try {
            val result = executeInner(t, allowAgents)
            ensureSpoken(result)
        } catch (e: Exception) {
            // Ne jamais attribuer toute erreur à Internet (OOM, modèle, permission, etc.)
            val msg = (e.message ?: "").lowercase()
            val isNet = msg.contains("unknownhost") || msg.contains("socket") ||
                msg.contains("connect") || msg.contains("network") ||
                msg.contains("unreachable") || msg.contains("timed out") ||
                msg.contains("timeout") || e is java.net.UnknownHostException ||
                e is java.net.SocketException || e is java.net.SocketTimeoutException
            ensureSpoken(
                if (isNet) {
                    "Problème réseau temporaire. Vérifie ta connexion, puis réessaie."
                } else {
                    "Erreur : ${e.message ?: "inconnue"}. " +
                        "Si l'IA n'est pas encore chargée, attends la fin du chargement dans l'app. " +
                        "Sinon réessaie ou reformule."
                }
            )
        }
    }

    /** Garantit une phrase parlable : raison + quoi faire. Jamais vide. */
    private fun ensureSpoken(msg: String?): String {
        val m = msg?.trim().orEmpty()
        if (m.isNotBlank()) return m
        return "Je n'ai pas pu répondre correctement. Reformule ta demande ou réessaie dans un instant."
    }

    private suspend fun executeInner(t: String, allowAgents: Boolean = true): String {
        if (t.isBlank()) return "Je n'ai rien entendu. Appuie à nouveau sur la mascotte et parle clairement."

        // 0) Filet de sécurité salutations : jamais de recherche web/Wikipédia pour un simple
        // « bonjour », même si l'IA locale n'est pas encore prête. Réponse immédiate, sans réseau,
        // avant même de vérifier l'état de l'IA.
        if (SIMPLE_GREETING.matches(t.trim())) {
            val prenom = try { relational.displayName() } catch (_: Exception) { "" }
            val reply = if (prenom.isNotBlank()) "Bonjour $prenom, comment puis-je t'aider ?" else "Bonjour, comment puis-je t'aider ?"
            ActivityLog.add(context, "action", reply.take(120))
            return reply
        }

        if (!DataDownloadService.isUsable(context)) {
            return "L'IA est encore en téléchargement ou en chargement en mémoire. Attends qu'elle soit prête avant d'utiliser Vanelle."
        }

        // 1) Chemin ultra-rapide : intentions connues du parser (sans passer par Llama)
        val quick = CommandParser.parse(t)
        val route = SystemCommandRouter.classify(t)
        val isFastAction = quick.intent in FAST_INTENTS || route == SystemCommandRouter.Route.SYSTEM
        if (isFastAction && quick.intent != CommandIntent.UNKNOWN) {
            val res = executeSingle(t, allowAgents)
            ActivityLog.add(context, "action", res.take(120))
            return res
        }

        ActivityLog.add(context, "entendu", t.take(80))
        // Emotion / épisodes en arrière-plan uniquement pour les requêtes libres (évite la latence)

        // 2) Cerveau au centre : Llama seulement si fichier prêt ET déjà chargé en mémoire
        // (évite d'attendre 60–90 s de tentative de load à chaque requête si le load a échoué)
        if (LlamaModelManager.isReady(context) && localAI.isLoaded()) {
            val brain = try {
                brainFirst(t, allowAgents)
            } catch (_: Exception) {
                null
            }
            if (brain != null) {
                withContext(Dispatchers.IO) { learner.log(t) }
                ActivityLog.add(context, "action", brain.take(120))
                return brain
            }
        }

        // 3) Fallback : chaînes d'intentions connues via parser, puis executeSingle
        val parts = splitChain(t)
        if (parts.size >= 2) {
            val parsedParts = parts.map { CommandParser.parse(it) }
            if (parsedParts.all { it.intent != CommandIntent.UNKNOWN }) {
                val results = parts.map { executeSingle(it, allowAgents) }
                withContext(Dispatchers.IO) { learner.log(t) }
                val joined = results.joinToString(". ")
                ActivityLog.add(context, "action", joined.take(120))
                return joined
            }
        }
        val res = executeSingle(t, allowAgents)
        withContext(Dispatchers.IO) { learner.log(t) }
        ActivityLog.add(context, "action", res.take(120))
        return res
    }

    /**
     * Llama au centre : comprend l'intention, répond, et peut déclencher des outils
     * via une ligne ACTION:TYPE|args en tête de réponse.
     */
    
    private suspend fun brainFirst(t: String, allowAgents: Boolean): String? {
        // Calcul trivial → code, pas le modèle
        ReasoningHelper.tryDeterministicMath(t)?.let { return it }

        // Cache réponses fréquentes
        ResponseCache.get(context, t)?.let { cached ->
            relational.addTurn("user", t)
            relational.addTurn("assistant", cached)
            return cached
        }

        // Faits hors domaine → web/RAG d’abord (pas de cloud LLM)
        if (ReasoningHelper.isFactualLookup(t) && PrivacyFirewall.allowWeb(context)) {
            val webFirst = try { synthesizeAnswer(t) } catch (_: Exception) { null }
            if (!webFirst.isNullOrBlank() && !isGenericIntro(webFirst)) {
                ResponseCache.put(context, t, webFirst)
                relational.addTurn("user", t)
                relational.addTurn("assistant", webFirst)
                return webFirst
            }
        }

        val extra = relational.fullContextForAi(dialogTurns = MemoryEngine.SHORT_TURNS, maxChars = 900)
        val needsContext = needsConversationalContext(t)
        val complex = ReasoningHelper.isComplex(t)
        try { relational.learnFromUserUtterance(t) } catch (_: Exception) {}
        try {
            val lastAsst = relational.recentDialog(2).lines().lastOrNull { it.startsWith("Vanelle:") }
                ?.removePrefix("Vanelle:")?.trim()
            FeedbackMemory.maybeCapture(context, t, lastAsst)
        } catch (_: Exception) {}

        val userPrompt = buildString {
            if (complex) {
                append(ReasoningHelper.buildStructuredPrompt(t, hasExternalFacts = false))
            } else {
                append(ReasoningHelper.buildSimplePrompt(t))
            }
            if (needsContext) {
                append(" Relie aux sujets précédents ; résous pronoms et suites.")
            }
            append(" Si action téléphone vraiment utile → commence par ACTION:…")
        }
        // max_tokens bas + fastMode large = latence perçue réduite
        var raw = localAI.answer(
            userPrompt,
            extraContext = if (complex) extra else extra.take(600),
            fastMode = !complex || t.length < 100,
            maxTokensHint = if (complex) 200 else if (t.length < 80) 120 else 160
        )
        if (raw != LocalLlamaHelper.NOT_READY && raw.isNotBlank() && isGenericIntro(raw)) {
            raw = localAI.answer(
                ReasoningHelper.buildSimplePrompt(t),
                extraContext = extra.take(500),
                fastMode = true,
                maxTokensHint = 140
            )
        }
        // Pas de 2e passe « anti-bluff » (trop lent) sauf texte très suspect et court
        if (raw != LocalLlamaHelper.NOT_READY && !raw.isNullOrBlank() &&
            !isGenericIntro(raw) && ReasoningHelper.looksOverconfidentBluff(raw) && raw.length > 200
        ) {
            // Une seule passe déjà faite — on élague juste le ton en post-traitement
            raw = raw.replace(Regex("(?i)il est évident que|sans aucun doute|absolument certain"), "il semble que")
        }

        if (raw == LocalLlamaHelper.NOT_READY || raw.isNullOrBlank()) return null
        if (isGenericIntro(raw)) return null

        relational.addTurn("user", t)
        val (actionLine, spoken) = splitActionAndReply(raw)
        if (actionLine != null) {
            val toolResult = runToolLine(actionLine, allowAgents)
            val reply = when {
                spoken.isNotBlank() && toolResult.isNotBlank() -> "$spoken $toolResult".trim()
                spoken.isNotBlank() -> spoken
                else -> toolResult.ifBlank { "C'est fait." }
            }
            relational.addTurn("assistant", reply)
            return reply
        }
        val text = ReasoningHelper.extractSpokenAnswer(spoken.ifBlank { raw.trim() })
        if (isGenericIntro(text)) return null
        relational.addTurn("assistant", text)
        ResponseCache.put(context, t, text)
        return text
    }

/** Messages qui s'appuient sur le fil (pronoms, suites de sujet, comparaisons). */
    private fun needsConversationalContext(t: String): Boolean {
        val lower = t.lowercase().trim()
        if (relational.recentDialog(4).isBlank()) return false
        if (Regex("(?i)^\\s*(et |mais |donc |alors |sinon )").containsMatchIn(lower)) return true
        if (Regex("(?i)\\b(il|elle|ils|elles|on)\\b").containsMatchIn(lower) && lower.length < 90) return true
        val cues = listOf(
            "ça", "cela", "celui", "celle", "ceux", "celles",
            "lui", "elle", "eux", "leur",
            "pareil", "pareille", "le même", "la même",
            "et pour", "et avec", "et si", "par contre",
            "aussi", "également", "comme tout à l'heure", "comme avant",
            "tu as dit", "tu m'as", "on parlait", "par rapport",
            "celui-là", "celle-là", "ce truc", "pourquoi", "comment ça",
            "et ensuite", "et après"
        )
        return cues.any { lower.contains(it) }
    }

    /** Détecte les réponses purement présentationnelles sans contenu utile. */
    private fun isGenericIntro(text: String): Boolean {
        val t = text.trim()
        if (t.length > 400) return false
        val lower = t.lowercase()
        val markers = listOf(
            "je suis vanelle",
            "votre assistante personnelle",
            "assistante personnelle, chaleureuse",
            "chaleureuse et précise",
            "qu'est-ce que vous souhaitez accomplir",
            "que souhaitez-vous accomplir",
            "conseils personnalisés",
            "trouver des solutions et à résoudre",
            "comment puis-je vous aider aujourd"
        )
        val hits = markers.count { lower.contains(it) }
        // La phrase exacte observée en prod touche ≥3 marqueurs
        return hits >= 2 || (hits >= 1 && t.length < 260)
    }

    private fun splitActionAndReply(raw: String): Pair<String?, String> {
        val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return null to ""
        val first = lines.first()
        val actionRegex = Regex("(?i)^ACTION\\s*:\\s*([A-Z_]+)\\s*(?:\\|\\s*(.*))?$")
        val m = actionRegex.find(first)
        return if (m != null) {
            val type = m.groupValues[1].uppercase()
            val args = m.groupValues.getOrNull(2)?.trim().orEmpty()
            val line = if (args.isNotEmpty()) "$type|$args" else type
            val rest = lines.drop(1).joinToString(" ").trim()
            line to rest
        } else {
            null to raw.trim()
                .removePrefix("assistant")
                .trim()
        }
    }

    private suspend fun runToolLine(line: String, allowAgents: Boolean): String {
        val parts = line.split("|", limit = 3).map { it.trim() }
        val type = parts.getOrNull(0)?.uppercase().orEmpty()
        val a1 = parts.getOrNull(1).orEmpty()
        val a2 = parts.getOrNull(2).orEmpty()
        return when (type) {
            "YOUTUBE" -> yt.searchSmart(QueryCleaner.subject(a1).ifBlank { a1 })
            "OPEN_APP" -> withContext(Dispatchers.IO) { apps.launch(a1) }
            "CALL" -> contacts.call(a1)
            "MESSAGE" -> contacts.sendMessage(a1, a2.ifBlank { "" })
            "SEARCH" -> answerSearchIntent(QueryCleaner.subject(a1).ifBlank { a1.ifBlank { line } })
            "MAPS" -> maps.open(QueryCleaner.subject(a1).ifBlank { a1 })
            "TIMER" -> {
                val m = a1.toIntOrNull() ?: 5
                device.timerMinutes(m)
            }
            "FLASHLIGHT" -> {
                val on = when (a1.lowercase()) {
                    "on", "1", "allume", "allumer" -> true
                    "off", "0", "eteins", "éteins" -> false
                    else -> null
                }
                device.flashlight(on)
            }
            "VOLUME" -> device.volume(
                when (a1.lowercase()) {
                    "up", "plus", "augmenter" -> "up"
                    "down", "moins", "baisser" -> "down"
                    else -> "status"
                }
            )
            "TRANSLATE" -> withContext(Dispatchers.IO) {
                tr.translateText(a1.ifBlank { a2 }, "auto", "fr")
            }
            "AGENT" -> {
                if (!allowAgents) "Action agent refusée."
                else agent.run(a1.ifBlank { "aide" })
            }
            else -> {
                // Dernier recours : parser classique sur la ligne
                val fallback = CommandParser.parse(
                    when (type) {
                        "YOUTUBE" -> "youtube $a1"
                        else -> a1.ifBlank { line }
                    }
                )
                if (fallback.intent != CommandIntent.UNKNOWN) {
                    executeSingle(
                        when (fallback.intent) {
                            CommandIntent.YOUTUBE -> "youtube ${fallback.args["query"] ?: a1}"
                            CommandIntent.OPEN_APP -> "ouvre ${fallback.args["app"] ?: a1}"
                            else -> a1
                        },
                        allowAgents
                    )
                } else "Je n'ai pas compris l'action demandée. Reformule clairement, par exemple « ouvre YouTube » ou « appelle Paul »."
            }
        }
    }

    private fun splitChain(text: String): List<String> =
        text.split(Regex("(?i)\\s+et\\s+puis\\s+|\\s+puis\\s+|\\s+et\\s+"))
            .map { it.trim() }.filter { it.isNotBlank() }

    private suspend fun executeSingle(t: String, allowAgents: Boolean = true): String {
        val clean = t.trim().lowercase()
        if (MascotManager.isMascotNameSpoken(context, clean) &&
            clean.split(Regex("\\s+")).size <= 3 &&
            !clean.contains("ouvre") && !clean.contains("appelle") &&
            !clean.contains("cherche") && !clean.contains("envoie")
        ) return showMascotNow()

        val p = CommandParser.parse(t)
        return when (p.intent) {
            CommandIntent.SHOW_MASCOT -> showMascotNow()
            CommandIntent.OPEN_APP -> withContext(Dispatchers.IO) { apps.launch(p.args["app"] ?: "") }
            CommandIntent.CALL_CONTACT -> contacts.call(p.args["name"] ?: "")
            CommandIntent.SEND_MESSAGE -> contacts.sendMessage(p.args["name"] ?: "", p.args["message"] ?: "")
            CommandIntent.SEARCH_WEB -> answerSearchIntent(p.args["query"] ?: t)
            CommandIntent.YOUTUBE -> yt.searchSmart(p.args["query"] ?: "")
            CommandIntent.STREAMING -> withContext(Dispatchers.IO) {
                streaming.open(p.args["platform"] ?: "", p.args["title"] ?: "")
            }
            CommandIntent.TRANSLATE -> withContext(Dispatchers.IO) {
                tr.translateText(p.args["text"] ?: "", "auto", "fr")
            }
            CommandIntent.TRANSLATE_MODE_ON -> {
                val src = p.args["source"] ?: "auto"; val tgt = p.args["target"] ?: "fr"
                TranslateModePrefs.start(context, src, tgt)
                "Mode traduction activé."
            }
            CommandIntent.TRANSLATE_MODE_OFF -> {
                TranslateModePrefs.stop(context); "Mode traduction désactivé."
            }
            CommandIntent.MEMORY_SAVE -> withContext(Dispatchers.IO) {
                val key = p.args["key"] ?: "note"
                val data = p.args["data"] ?: ""
                vault.save(key, data)
                relational.rememberFact(data)
                "C'est noté."
            }
            CommandIntent.MEMORY_GET -> withContext(Dispatchers.IO) {
                val key = p.args["key"] ?: ""
                val all = vault.getAll()
                val exact = all[key]
                val contains = all.entries.firstOrNull { it.key.contains(key, true) }?.value
                val fuzzyKey = FuzzyMatch.findBest(key, all.keys.toList())
                val fuzzy = fuzzyKey?.let { all[it] }
                exact?.toString() ?: contains?.toString() ?: fuzzy?.toString() ?: freeAI.answer(key)
            }
            CommandIntent.MEMORY_CLEAR -> withContext(Dispatchers.IO) {
                vault.clear()
                relational.clearAll()
                "D'accord, j'ai tout effacé de ma mémoire."
            }
            CommandIntent.REMEMBER_FACT -> {
                val fact = p.args["fact"] ?: t
                relational.rememberFact(fact)
                "OK, je m'en souviendrai."
            }
            CommandIntent.SET_PROFILE -> {
                val key = p.args["key"] ?: "prenom"
                val value = p.args["value"] ?: ""
                relational.setProfileField(key, value)
                if (key == "prenom") "OK." // le prénom sera déjà dit en tête de la phrase
                else "C'est noté."
            }
            CommandIntent.EMERGENCY -> em.sos()
            CommandIntent.BATTERY -> "Batterie ${bat.level()} %."
            CommandIntent.RESTAURANT -> {
                val q = QueryCleaner.subject(p.args["query"] ?: "").ifBlank {
                    QueryCleaner.subject(t).ifBlank { "" }
                }
                if (q.isBlank()) "Quel type de restaurant ou quel lieu veux-tu ?"
                else maps.open(q) // Maps dynamique, pas de requête pré-écrite
            }
            CommandIntent.TOOL -> tool.open()
            CommandIntent.LOST_PHONE -> LostPhoneManager.trigger(context)
            CommandIntent.MAPS -> maps.open(p.args["query"] ?: "")
            CommandIntent.ACCESSIBILITY_ACTION -> {
                val svc = VanelleAccessibilityService.instance
                if (svc == null) "Active le service d'accessibilité dans Configuration pour que je puisse faire cette action système."
                else {
                    svc.action(p.args["action"] ?: "")
                    "C'est fait."
                }
            }
            CommandIntent.READ_SCREEN -> screenRead()
            CommandIntent.SCREEN_SUMMARY -> screenSummary()
            CommandIntent.SCREEN_FILL -> screenFill(p.args["text"] ?: "")
            CommandIntent.CLICK_SCREEN -> {
                val svc = VanelleAccessibilityService.instance
                if (svc == null) "Active l'accessibilité dans Configuration."
                else {
                    val ok = svc.clickNodeWithText(p.args["target"] ?: "")
                    if (ok) "C'est fait." else "Élément introuvable à l'écran. Dis-moi le texte exact visible ou active mieux l'accessibilité."
                }
            }
            CommandIntent.SCHEDULE_TASK -> withContext(Dispatchers.IO) {
                var desc = (p.args["description"] ?: "Rappel").trim()
                desc = desc.replace(Regex("(?i)^rappelle[- ]?moi\\s+"), "")
                    .replace(Regex("(?i)^souviens[- ]?moi\\s+"), "")
                    .replace(Regex("(?i)^programme +"), "")
                    .replace(Regex("(?i)^planifie +"), "")
                    .trim()
                    .ifBlank { "Rappel" }
                val hour = p.args["hour"]?.toIntOrNull() ?: 8
                val minute = p.args["minute"]?.toIntOrNull() ?: 0
                val repeat = p.args["repeat"]?.toBoolean() ?: false
                val task = relance.addTask(desc, hour, minute, repeat)
                AlarmScheduler.scheduleNext(context, task)
                val exactOk = AlarmScheduler.canScheduleExact(context)
                val timeStr = "${hour}h${minute.toString().padStart(2, '0')}"
                val base = "Relance enregistrée : « $desc » à $timeStr. Tu la vois dans l'onglet Relances."
                if (!exactOk) {
                    try {
                        val i = android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                            data = android.net.Uri.parse("package:${context.packageName}")
                            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(i)
                    } catch (_: Exception) {}
                    base + " Important : active les alarmes exactes dans les réglages qui viennent de s'ouvrir, sinon la relance peut ne pas sonner."
                } else base
            }
            CommandIntent.CREATE_ROUTINE -> {
                val hour = p.args["hour"]?.toIntOrNull() ?: 7
                val minute = p.args["minute"]?.toIntOrNull() ?: 30
                val actions = p.args["actions"] ?: "briefing"
                RoutineManager.add(context, "Routine", hour, minute, actions)
                "Routine créée pour ${hour}h${minute.toString().padStart(2, '0')}. Je t'en parlerai à ce moment-là."
            }
            CommandIntent.LIST_ROUTINES -> RoutineManager.describe(context)
            CommandIntent.SET_PERSONALITY ->
                "Je garde un seul style de réponse, clair et naturel."
            CommandIntent.OPEN_CAMERA -> MultimodalHelper.openCamera(context)
            CommandIntent.OPEN_GALLERY -> MultimodalHelper.openGallery(context)
            CommandIntent.SHOW_ACTIVITY_LOG -> {
                val lines = ActivityLog.all(context).take(8)
                if (lines.isEmpty()) "Le journal est vide pour l'instant."
                else lines.joinToString("\n") { ActivityLog.formatLine(it.first, it.second, it.third) }
            }
            CommandIntent.AGENT_GOAL -> {
                if (!allowAgents) "Sous-étape agent refusée (garde anti-récursion)."
                else {
                    HapticLanguage.play(context, HapticLanguage.Signal.LISTENING)
                    agent.run(p.args["goal"] ?: t)
                }
            }
            CommandIntent.EPISODIC_SUMMARY -> episodic.todaySummary()
            CommandIntent.EPISODIC_CONSOLIDATE -> episodic.consolidate()
            CommandIntent.SPATIAL_CONTEXT -> withContext(Dispatchers.IO) {
                val desc = spatial.describe()
                val mode = spatial.suggestedMode()
                "$desc. Mode suggéré : $mode."
            }
            CommandIntent.HAPTIC_DEMO -> {
                HapticLanguage.play(context, HapticLanguage.Signal.SUCCESS)
                HapticLanguage.describe()
            }
            CommandIntent.DYNAMIC_TOOL -> dynamicUi.create(p.args["request"] ?: t)
            CommandIntent.FLASHLIGHT -> {
                val on = when (p.args["on"]) {
                    "1" -> true
                    "0" -> false
                    else -> null
                }
                device.flashlight(on)
            }
            CommandIntent.VOLUME -> device.volume(p.args["dir"] ?: "status")
            CommandIntent.RINGER -> device.ringer(p.args["mode"] ?: "status")
            CommandIntent.CLIPBOARD_READ -> device.clipboardRead()
            CommandIntent.CLIPBOARD_WRITE -> device.clipboardWrite(p.args["text"] ?: "")
            CommandIntent.OPEN_URL -> device.openUrl(p.args["url"] ?: "")
            CommandIntent.SHARE_TEXT -> device.shareText(p.args["text"] ?: "")
            CommandIntent.TIMER -> {
                val m = p.args["minutes"]?.toIntOrNull() ?: 5
                device.timerMinutes(m)
            }
            CommandIntent.POINT_NODE -> {
                val target = p.args["target"] ?: ""
                if (target.isBlank()) "Élément à pointer non précisé."
                else GuidanceOverlay.pointToNode(context, target)
            }
            CommandIntent.GUIDANCE_OVERLAY -> {
                val msg = p.args["message"] ?: "Regarde ici"
                GuidanceOverlay.show(context, msg)
            }
            CommandIntent.FORCE_NIGHTLY -> NightlyConsolidation.runNow(context)
            CommandIntent.PRIVACY_STATUS -> PrivacyFirewall.status(context)
            CommandIntent.PRIVACY_LOCKDOWN -> {
                PrivacyFirewall.lockdown(context)
                HapticLanguage.play(context, HapticLanguage.Signal.WARNING)
                "Lockdown activé. " + PrivacyFirewall.status(context)
            }
            else -> answerSmart(t)
        }
    }


    private suspend fun answerSmart(t: String): String {
        ReasoningHelper.tryDeterministicMath(t)?.let { return it }
        ResponseCache.get(context, t)?.let { return it }

        // 1) Intention dynamique (sujet + destination)
        val routed = QueryCleaner.route(t)
        if (routed.subject.isNotBlank()) {
            when (routed.dest) {
                QueryCleaner.Dest.YOUTUBE -> return yt.searchSmart(routed.subject)
                QueryCleaner.Dest.MAPS -> return maps.open(routed.subject)
                QueryCleaner.Dest.WEB -> return answerSearchIntent(routed.subject)
                QueryCleaner.Dest.STREAMING -> { /* laisse Llama / web */ }
                QueryCleaner.Dest.NONE -> { }
            }
        }

        // Faits / hors domaine → web systématique (vérification croisée)
        if (ReasoningHelper.isFactualLookup(t) || ReasoningHelper.isComplex(t)) {
            if (PrivacyFirewall.allowWeb(context) && LlamaModelManager.isNetworkAvailable(context)) {
                val viaWeb = try { synthesizeAnswer(t) } catch (_: Exception) { null }
                if (!viaWeb.isNullOrBlank() && !isGenericIntro(viaWeb)) {
                    ResponseCache.put(context, t, viaWeb)
                    return viaWeb
                }
            }
        }

        // 2) Cerveau Llama local + mémoire
        if (LlamaModelManager.isReady(context) && localAI.isLoaded()) {
            val ctx = relational.fullContextForAi(dialogTurns = MemoryEngine.SHORT_TURNS, maxChars = 900)
            val needsCtx = needsConversationalContext(t)
            val prompt = buildString {
                append(t.trim())
                append("\n\nComprends le message dans son contexte, réponds de façon cohérente et claire. ")
                if (needsCtx) append("Relie aux sujets précédents et résous les pronoms / suites. ")
                append("Si tu n'as pas l'info, dis-le clairement plutôt qu'inventer. Pas de présentation.")
            }
            val llamaRes = localAI.answer(
                prompt,
                extraContext = ctx,
                fastMode = t.length < 80 && !needsCtx,
                maxTokensHint = if (t.length < 80) 120 else 160
            )
            if (llamaRes != LocalLlamaHelper.NOT_READY && llamaRes.isNotBlank() && !isGenericIntro(llamaRes)) {
                val spoken = ReasoningHelper.extractSpokenAnswer(llamaRes)
                relational.addTurn("user", t)
                relational.addTurn("assistant", spoken)
                ResponseCache.put(context, t, spoken)
                return spoken
            }
        }
        if (PersonalityPrefs.preferOffline(context) && !LlamaModelManager.isNetworkAvailable(context)) {
            return elegantUnknown(
                offline = true,
                canSearch = false
            )
        }
        return fallbackAi(t)
    }

    /** Gestion d'erreur élégante — « assistant sérieux » plutôt que plantage / bluff. */
    private fun elegantUnknown(offline: Boolean, canSearch: Boolean): String = when {
        offline ->
            "Je n'ai pas cette info en local pour le moment, et le mode hors-ligne est actif. " +
                "Active le réseau ou pose une commande concrète (ouvrir une app, batterie, relance…)."
        canSearch ->
            "Je n'ai pas cette information sous la main. Tu peux me dire « cherche … » pour que je regarde en ligne, " +
                "ou reformuler ta question."
        else ->
            "Je ne suis pas sûre de pouvoir répondre correctement à ça. " +
                "Reformule, ou dis-moi si tu veux une recherche web ou une action sur le téléphone."
    }

    private fun screenRead(): String {
        val svc = VanelleAccessibilityService.instance
            ?: return "Active le service d'accessibilité dans Configuration pour lire l'écran."
        val txt = svc.captureScreenText()
        return if (txt.isBlank()) "Je ne vois pas de texte lisible sur cet écran."
        else "Voici ce que je lis : ${txt.take(500)}"
    }

    private suspend fun screenSummary(): String {
        val svc = VanelleAccessibilityService.instance
            ?: return "Active l'accessibilité dans Configuration pour que je voie l'écran."
        val txt = svc.captureScreenText()
        if (txt.isBlank()) return "Écran vide ou non lisible pour moi."
        if (LlamaModelManager.isReady(context)) {
            val sum = localAI.answer(
                "Résume clairement et complètement en 2-4 phrases :\n${txt.take(800)}",
                extraContext = "",
                fastMode = false,
                maxTokensHint = 180
            )
            if (sum != LocalLlamaHelper.NOT_READY) return sum
        }
        val clean = txt.replace(Regex("\\s+"), " ").trim()
        return "Résumé de l'écran : ${clean.take(320)}"
    }

    private fun screenFill(value: String): String {
        val svc = VanelleAccessibilityService.instance
            ?: return "Active l'accessibilité dans Configuration."
        val ok = svc.fillFocusedOrFirstField(value)
        return if (ok) "Champ rempli : « ${value.take(60)} »."
        else "Aucun champ trouvé. Touche d'abord la zone de texte à l'écran, puis redis : remplis avec …"
    }

    private fun showMascotNow(): String {
        val name = MascotManager.getDisplayName(context)
        return "Salut, je suis $name ! Tu peux me parler…"
    }

    /**
     * Raisonne avant d'ouvrir une application :
     * 1) modèle local si disponible ;
     * 2) réponse Web rapide si elle est suffisamment informative ;
     * 3) sinon seulement, ouverture d'une vraie recherche Web.
     */
    private suspend fun answerSearchIntent(query: String): String {
        // Nettoie la requête (retire « fais la recherche de… », etc.)
        val q = YouTubeHelper.cleanQuery(query).ifBlank { query.trim() }
        if (q.isBlank()) return "Que veux-tu que je recherche ?"
        return synthesizeAnswer(q)
    }

    /**
     * Toujours passer par l'IA pour produire une réponse parlée, professionnelle,
     * dans ses propres mots — jamais recopier tel quel un extrait Wikipédia/DDG,
     * et jamais ouvrir de navigateur. Les faits bruts trouvés en ligne ne servent
     * que de contexte à reformuler pour l'IA locale.
     */
    private suspend fun synthesizeAnswer(q: String): String {
        ReasoningHelper.tryDeterministicMath(q)?.let { return it }

        // RAG : faits externes d'abord — le 1B reformule/raisonne, il ne "sait" pas le monde
        val raw = try { freeAI.fetchRawFacts(q) } catch (_: Exception) { null }

        if (LlamaModelManager.isReady(context)) {
            val extraCtx = buildString {
                if (!raw.isNullOrBlank()) {
                    append("FAITS RÉCUPÉRÉS (source externe — ne pas inventer au-delà) :\n")
                    append(raw.take(700))
                } else {
                    append("Aucun fait externe trouvé. Si tu n'as pas l'info, dis-le.")
                }
                val profile = relational.fullContextForAi(dialogTurns = 6, maxChars = 500)
                if (profile.isNotBlank()) {
                    if (isNotEmpty()) append("\n")
                    append(profile)
                }
            }
            try {
                val prompt = if (!raw.isNullOrBlank()) {
                    ReasoningHelper.buildRagPrompt(q)
                } else if (ReasoningHelper.isComplex(q)) {
                    ReasoningHelper.buildStructuredPrompt(q, hasExternalFacts = false)
                } else {
                    ReasoningHelper.buildSimplePrompt(q)
                }
                val local = localAI.answer(
                    prompt,
                    extraContext = extraCtx,
                    fastMode = false,
                    maxTokensHint = if (ReasoningHelper.isComplex(q)) 180 else 140
                )
                if (local != LocalLlamaHelper.NOT_READY && local.isNotBlank() &&
                    !local.contains("pas trouvé de réponse fiable", ignoreCase = true) &&
                    !isGenericIntro(local)
                ) {
                    return ReasoningHelper.extractSpokenAnswer(local)
                }
            } catch (_: Exception) { /* fallback web */ }
        }

        // 2) Faits web bruts
        if (!raw.isNullOrBlank()) {
            val t = raw.trim()
            return if (t.length > 420) t.take(417).trimEnd() + "…" else t
        }

        // 3) FreeAI.answer (Wikipedia / DuckDuckGo)
        try {
            val web = freeAI.answer(q)
            if (web.isNotBlank()) return web
        } catch (_: Exception) {}

        // 4) Dernier recours — messages clairs, jamais de bluff
        val modelOk = LlamaModelManager.isReady(context)
        val loaded = try { localAI.isLoaded() } catch (_: Exception) { false }
        val online = try { LlamaModelManager.isNetworkAvailable(context) } catch (_: Exception) { false }
        return when {
            modelOk && !loaded ->
                "Le modèle est téléchargé mais pas encore en mémoire. Attends la fin du chargement, puis réessaie."
            modelOk && loaded ->
                elegantUnknown(offline = !online, canSearch = online && PrivacyFirewall.allowWeb(context))
            else ->
                "Vanelle n'est pas encore prête (téléchargement / chargement). " +
                    "Dès que le diagnostic affiche l'IA opérationnelle, on pourra reprendre."
        }
    }

    private suspend fun fallbackAi(t: String): String = synthesizeAnswer(t)
}
