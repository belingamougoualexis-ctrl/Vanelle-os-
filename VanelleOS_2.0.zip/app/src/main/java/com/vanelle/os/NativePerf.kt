package com.vanelle.os

import android.content.Context
import android.os.Build

/**
 * Perf native : ce que l'app peut faire sans recompiler le .so.
 *
 * NNAPI / GPU : dépend du build de llamacpp-kotlin embarqué.
 * Si le backend n'est pas compilé dedans, aucun réglage Kotlin ne l'activera.
 * On tente quand même les hooks publics éventuels par réflexion.
 */
object NativePerf {
    fun status(c: Context): String {
        val cores = Runtime.getRuntime().availableProcessors()
        val abi = try {
            Build.SUPPORTED_ABIS.joinToString(", ")
        } catch (_: Exception) {
            Build.CPU_ABI
        }
        return buildString {
            appendLine("Perf native")
            appendLine("• Threads ciblés : 4 (évite le collapse big.LITTLE)")
            appendLine("• Cores dispo : $cores")
            appendLine("• ABI : $abi")
            appendLine("• n_ctx Vanelle : 256–512 (préfill rapide)")
            appendLine("• NNAPI/GPU : dépend du .so llamacpp (pas exposé en Kotlin dans 0.4.0)")
            append("• Pour 30–60 tok/s : AAR recompilé avec backend NNAPI/Vulkan")
        }
    }

    /**
     * Tente d'appeler des setters connus si présents sur le helper natif.
     * No-op si absents (cas normal avec 0.4.0).
     */
    fun tryTuneHelper(helper: Any?) {
        if (helper == null) return
        // 4 threads = sweet spot big.LITTLE (plus = contention, parfois 100x plus lent)
        val threads = 4.coerceAtMost(Runtime.getRuntime().availableProcessors().coerceAtLeast(2))
        for (name in listOf("setThreads", "setNThreads", "nThreads")) {
            try {
                val m = helper.javaClass.methods.firstOrNull {
                    it.name.equals(name, true) && it.parameterTypes.size == 1
                } ?: continue
                val p = m.parameterTypes[0]
                when {
                    p == Int::class.javaPrimitiveType || p == Integer::class.java ->
                        m.invoke(helper, threads)
                    else -> continue
                }
                android.util.Log.i("VanellePerf", "tuned $name=$threads")
                return
            } catch (_: Exception) {}
        }
    }
}
