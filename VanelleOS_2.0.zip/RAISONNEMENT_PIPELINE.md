# Vanelle — raisonnement orchestré (petit modèle)

Un Llama 1B ne raisonne pas bien *seul* en une passe. Vanelle **orchestre** :

| Technique | Implémentation |
|-----------|----------------|
| Décomposition | `ReasoningHelper.buildStructuredPrompt` si question complexe |
| Faits vs déductions | Consigne explicite dans le prompt structuré + RAG |
| Auto-vérification | Second passage si bluff trop confiant (`looksOverconfidentBluff`) |
| Calculs critiques | `tryDeterministicMath` (code, pas génération) |
| RAG | `FreeAI.fetchRawFacts` → reformulation locale (`buildRagPrompt`) |
| Simplicité / latence | Prompt court si question simple — pas de CoT inutile |
| Mémoire | `fullContextForAi` + `learnFromUserUtterance` |
| Format | Étapes numérotées demandées seulement si complexe |

Non implémenté (volontairement, coût mobile) :
- Self-consistency ×3 (trop lent sur CPU)
- Grammaires GBNF (API wrapper limitée)
- Multi-LoRA / distillation (hors scope runtime)

Le modèle = **brique** dans un pipeline, pas un cerveau solitaire.
