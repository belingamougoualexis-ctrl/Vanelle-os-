import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/input";
import { activeDietLabels } from "@/lib/dietary";
import { usePrime } from "@/lib/store";
import { COMMON_ALLERGENS, DIET_OPTIONS } from "@/lib/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/preferences")({ component: PreferencesPage });

function PreferencesPage() {
  const dietary = usePrime((s) => s.dietary);
  const toggleDiet = usePrime((s) => s.toggleDiet);
  const toggleAllergy = usePrime((s) => s.toggleAllergy);
  const setDietary = usePrime((s) => s.setDietary);
  const [dislikeInput, setDislikeInput] = useState("");
  const [customAllergy, setCustomAllergy] = useState("");

  function addDislike() {
    const v = dislikeInput.trim().toLowerCase();
    if (!v) return;
    if (dietary.dislikes.includes(v)) {
      toast("Déjà dans la liste");
      return;
    }
    setDietary({ dislikes: [...dietary.dislikes, v] });
    setDislikeInput("");
  }

  function removeDislike(name: string) {
    setDietary({ dislikes: dietary.dislikes.filter((d) => d !== name) });
  }

  const labels = activeDietLabels(dietary);

  return (
    <div className="enter mx-auto max-w-3xl">
      <PageHeader
        kicker="Profil alimentaire"
        title="Vos préférences"
        lede="Régimes, allergies et aliments à éviter. Appliqués à la création de recettes et au filtre du carnet — 100 % local, rien n’est envoyé à une API payante."
      />

      {labels.length || dietary.allergies.length ? (
        <Card className="mb-6 flex flex-wrap gap-2 p-4">
          {labels.map((l) => (
            <Badge key={l} tone="ocean">
              {l}
            </Badge>
          ))}
          {dietary.allergies.map((a) => (
            <Badge key={a} tone="porcelain">
              Allergie · {a}
            </Badge>
          ))}
        </Card>
      ) : null}

      <Card className="p-6">
        <h2 className="font-display text-2xl">Régimes</h2>
        <p className="mt-1 text-sm text-muted-foreground">Activez ce qui vous correspond. Plusieurs choix possibles.</p>
        <div className="mt-5 grid gap-2 sm:grid-cols-2">
          {DIET_OPTIONS.map((opt) => {
            const on = dietary.diets.includes(opt.id);
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => toggleDiet(opt.id)}
                className={cn(
                  "rounded-xl border px-4 py-3 text-left transition-colors",
                  on
                    ? "border-primary/50 bg-primary/10 text-foreground"
                    : "border-border bg-secondary/40 text-muted-foreground hover:border-border hover:text-foreground",
                )}
              >
                <span className="block text-sm font-medium text-foreground">{opt.label}</span>
                <span className="mt-0.5 block text-xs text-muted-foreground">{opt.hint}</span>
              </button>
            );
          })}
        </div>
      </Card>

      <Card className="mt-5 p-6">
        <h2 className="font-display text-2xl">Allergies</h2>
        <p className="mt-1 text-sm text-muted-foreground">Les recettes contenant ces mots seront filtrées du carnet.</p>
        <div className="mt-4 flex flex-wrap gap-2">
          {COMMON_ALLERGENS.map((a) => {
            const on = dietary.allergies.some((x) => x.toLowerCase() === a.toLowerCase());
            return (
              <button
                key={a}
                type="button"
                onClick={() => toggleAllergy(a)}
                className={cn(
                  "h-9 rounded-full px-3 text-xs transition-colors",
                  on ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
                )}
              >
                {a}
              </button>
            );
          })}
        </div>
        <div className="mt-4 flex gap-2">
          <Input
            placeholder="Autre allergène…"
            value={customAllergy}
            onChange={(e) => setCustomAllergy(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                toggleAllergy(customAllergy);
                setCustomAllergy("");
              }
            }}
          />
          <Button
            variant="outline"
            onClick={() => {
              toggleAllergy(customAllergy);
              setCustomAllergy("");
            }}
          >
            Ajouter
          </Button>
        </div>
      </Card>

      <Card className="mt-5 p-6">
        <h2 className="font-display text-2xl">Aliments à éviter</h2>
        <p className="mt-1 text-sm text-muted-foreground">Goûts personnels (ex. coriandre, foie, anchois).</p>
        <div className="mt-4 flex gap-2">
          <Input
            placeholder="Ex. coriandre"
            value={dislikeInput}
            onChange={(e) => setDislikeInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") addDislike();
            }}
          />
          <Button variant="outline" onClick={addDislike}>
            Ajouter
          </Button>
        </div>
        {dietary.dislikes.length ? (
          <div className="mt-3 flex flex-wrap gap-2">
            {dietary.dislikes.map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => removeDislike(d)}
                className="h-8 rounded-full bg-secondary px-3 text-xs text-muted-foreground hover:text-foreground"
              >
                {d} ×
              </button>
            ))}
          </div>
        ) : null}
      </Card>

      <Card className="mt-5 p-6">
        <Label htmlFor="notes">Notes libres</Label>
        <Textarea
          id="notes"
          className="mt-2 min-h-24"
          placeholder="Ex. je préfère les cuissons douces, peu épicé…"
          value={dietary.notes}
          onChange={(e) => setDietary({ notes: e.target.value })}
        />
        <Button
          className="mt-4"
          variant="outline"
          onClick={() => {
            setDietary({ diets: [], allergies: [], dislikes: [], notes: "" });
            toast.success("Préférences réinitialisées");
          }}
        >
          Tout effacer
        </Button>
      </Card>
    </div>
  );
}
