import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { usePrime } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/robot")({ component: RobotPage });

function RobotPage() {
  const recipes = usePrime((s) => s.recipes);
  const robot = usePrime((s) => s.robot);
  const setRobot = usePrime((s) => s.setRobot);
  const resetRobot = usePrime((s) => s.resetRobot);
  const recipe = recipes.find((r) => r.id === robot.recipeId) ?? recipes[0] ?? null;
  const step = recipe?.steps[robot.stepIndex];

  useEffect(() => {
    if (!robot.running || !recipe) return;
    const id = window.setInterval(() => {
      setRobot((r) => {
        const current = recipe.steps[r.stepIndex];
        const dur = Math.max(8, (current?.durationMin ?? 5) * 0.35);
        const nextProgress = r.progress + 100 / (dur * 2.5);
        const heat = current?.induction ? 40 + current.induction * 18 : r.plateC;
        const plateC = r.plateC + (heat - r.plateC) * 0.08;
        if (nextProgress >= 100) {
          const last = r.stepIndex >= recipe.steps.length - 1;
          return {
            ...r,
            progress: last ? 100 : 0,
            stepIndex: last ? r.stepIndex : r.stepIndex + 1,
            phase: last ? "done" : "cook",
            running: !last,
            plateC,
            arm: last ? "service" : recipe.steps[r.stepIndex + 1]?.arm ?? "enchaîner",
            log: [
              { t: Date.now(), text: last ? "Service. Bras au repos." : `Étape ${r.stepIndex + 2} — ${recipe.steps[r.stepIndex + 1]?.text.slice(0, 48)}` },
              ...r.log,
            ].slice(0, 12),
          };
        }
        return {
          ...r,
          progress: nextProgress,
          plateC,
          phase: r.stepIndex === 0 && nextProgress < 12 ? "preheat" : "cook",
          arm: current?.arm ?? "en geste",
        };
      });
    }, 400);
    return () => window.clearInterval(id);
  }, [robot.running, recipe, setRobot]);

  function start(id: string) {
    const r = recipes.find((x) => x.id === id);
    setRobot({
      running: true,
      recipeId: id,
      stepIndex: 0,
      phase: "preheat",
      plateC: 40,
      arm: r?.steps[0]?.arm ?? "préparer",
      progress: 0,
      startedAt: Date.now(),
      log: [{ t: Date.now(), text: `Préchauffage — ${r?.title}` }],
    });
  }

  return (
    <div className="enter mx-auto max-w-6xl">
      <PageHeader
        kicker="Autonomie totale"
        title="Le cerveau. Le bras. La plaque."
        lede="Prime orchestre la cuisson de A à Z : induction, bras, temps. Ici, le studio pilote une cuisine robotisée fidèle."
        action={
          robot.running ? (
            <Button variant="outline" onClick={() => setRobot({ running: false, phase: "paused" })}>
              Pause
            </Button>
          ) : robot.phase === "done" ? (
            <Button variant="outline" onClick={resetRobot}>
              Réinitialiser
            </Button>
          ) : recipe ? (
            <Button onClick={() => start(recipe.id)}>Orchestrer</Button>
          ) : null
        }
      />

      <div className="grid gap-4 lg:grid-cols-12">
        <Card className="p-6 lg:col-span-5">
          <div className="flex items-center justify-between">
            <Badge tone={robot.phase === "done" ? "ocean" : "mute"}>
              {robot.phase === "idle" ? "Veille" : robot.phase === "done" ? "Service" : robot.phase}
            </Badge>
            <span className="text-xs tabular-nums text-muted-foreground">{Math.round(robot.plateC)} °C plaque</span>
          </div>
          <KitchenMap plateC={robot.plateC} arm={robot.arm} active={robot.running || robot.phase === "done"} />
          <p className="mt-4 text-sm text-muted-foreground">Bras · {robot.arm}</p>
          <Progress className="mt-3" value={robot.progress} />
        </Card>

        <Card className="p-6 lg:col-span-7">
          <p className="text-xs uppercase tracking-[0.16em] text-muted-foreground">{recipe?.title}</p>
          <h2 className="mt-2 font-display text-3xl">
            {robot.phase === "done" ? "À table." : step ? `Étape ${step.n}` : "Choisir un plat"}
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step?.text}</p>
          {!recipe ? (
            <p className="mt-6 text-sm text-muted-foreground">
              Aucune recette dans le carnet. Allez dans <strong>Créer</strong> pour en générer une, puis revenez orchestrer la cuisson.
            </p>
          ) : null}
          <ol className="mt-6 grid gap-2">
            {recipe?.steps.map((s, i) => (
              <li
                key={s.n}
                className={cn(
                  "rounded-lg px-3 py-2 text-sm",
                  i === robot.stepIndex ? "bg-accent text-accent-foreground" : "text-muted-foreground",
                )}
              >
                <span className="mr-2 font-mono text-xs tabular-nums">{String(s.n).padStart(2, "0")}</span>
                {s.text}
              </li>
            ))}
          </ol>
          {recipes.length > 1 ? (
            <div className="mt-4 flex flex-wrap gap-2">
              {recipes.slice(0, 6).map((r) => (
                <Button key={r.id} size="sm" variant="outline" onClick={() => start(r.id)} disabled={robot.running}>
                  {r.title.slice(0, 28)}
                </Button>
              ))}
            </div>
          ) : null}
        </Card>
      </div>

      <section className="mt-8 grid gap-3 md:grid-cols-2">
        {recipes.slice(0, 4).map((r) => (
          <button
            key={r.id}
            onClick={() => start(r.id)}
            className={cn(
              "rounded-2xl bg-card p-5 text-left shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)]",
              robot.recipeId === r.id && "shadow-[0_0_0_1px_var(--color-primary)]",
            )}
          >
            <p className="font-display text-xl">{r.title}</p>
            <p className="text-xs text-muted-foreground">{r.steps.length} gestes · {r.timeMin} min réelles</p>
          </button>
        ))}
      </section>

      {robot.log.length ? (
        <Card className="mt-6 p-5">
          <p className="mb-3 text-xs uppercase tracking-wider text-muted-foreground">Journal machine</p>
          <ul className="grid gap-1.5 font-mono text-xs text-muted-foreground">
            {robot.log.map((l, i) => (
              <li key={i}>{l.text}</li>
            ))}
          </ul>
        </Card>
      ) : null}
    </div>
  );
}

function KitchenMap({ plateC, arm, active }: { plateC: number; arm: string; active: boolean }) {
  const heat = Math.min(1, (plateC - 28) / 200);
  return (
    <div className="relative mx-auto mt-8 aspect-square max-w-xs">
      <div className="absolute inset-0 rounded-2xl bg-secondary" />
      {[0, 1, 2, 3].map((i) => {
        const col = i % 2;
        const row = Math.floor(i / 2);
        const on = active && i === 0;
        return (
          <div
            key={i}
            className="absolute size-[38%] rounded-full shadow-[0_0_0_1px_rgb(243_246_244_/_0.1)]"
            style={{
              left: col === 0 ? "10%" : "52%",
              top: row === 0 ? "10%" : "52%",
              background: on ? `rgba(26,143,130,${0.15 + heat * 0.55})` : "transparent",
            }}
          />
        );
      })}
      <div
        className="absolute left-1/2 top-1/2 size-4 -translate-x-1/2 -translate-y-1/2 rounded-full bg-porcelain transition-transform duration-500"
        style={{ transform: `translate(-50%, -50%) translate(${active ? 28 : 0}px, ${active ? -18 : 0}px)` }}
        title={arm}
      />
    </div>
  );
}
