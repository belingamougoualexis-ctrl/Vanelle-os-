import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { localAdaptForHealth } from "@/lib/local-sense";
import { usePrime, useTodayMacros } from "@/lib/store";
import { formatTime } from "@/lib/utils";

export const Route = createFileRoute("/sante")({ component: SantePage });

function SantePage() {
  const health = usePrime((s) => s.health);
  const setHealth = usePrime((s) => s.setHealth);
  const recipes = usePrime((s) => s.recipes);
  const macros = useTodayMacros();
  const [busy, setBusy] = useState<string | null>(null);
  const pick = recipes[1] ?? recipes[0];

  const status =
    health.glucose >= 140 ? "haute" : health.glucose <= 75 ? "basse" : "dans la zone";

  async function adapt(id: string) {
    const r = recipes.find((x) => x.id === id);
    if (!r) {
      toast.error("Créez d’abord une recette (écran Créer).");
      return;
    }
    setBusy(id);
    await new Promise((x) => setTimeout(x, 150));
    const res = localAdaptForHealth({
      glucose: Math.round(health.glucose),
      fatigue: health.fatigue,
      eatenKcal: macros.kcal,
      eatenGlucides: macros.glucides,
      recipeTitle: r.title,
      recipeSummary: `${r.story}\n${r.ingredients.map((i) => i.name).join(", ")}`,
    });
    setBusy(null);
    toast.success(res.title, {
      description: [res.rationale, ...res.suggestions, ...res.watchouts].slice(0, 4).join(" · "),
      duration: 8000,
    });
  }

  return (
    <div className="enter mx-auto max-w-6xl">
      <PageHeader
        kicker="Santé & bio-feedback"
        title="Cuisiner selon le corps d’aujourd’hui."
        lede="Glycémie, fatigue, sommeil. Conseils locaux selon vos curseurs — pas un diagnostic médical, aucune API."
      />

      <div className="grid gap-4 lg:grid-cols-12">
        <Card className="p-6 lg:col-span-4">
          <Badge tone={health.glucose >= 140 || health.glucose <= 75 ? "porcelain" : "ocean"}>
            Glycémie {status}
          </Badge>
          <p className="mt-5 font-display text-7xl tabular-nums leading-none">{Math.round(health.glucose)}</p>
          <p className="text-sm text-muted-foreground">mg/dL · tendance {health.trend === "up" ? "↑" : health.trend === "down" ? "↓" : "→"}</p>
          <p className="mt-8 text-xs uppercase tracking-wider text-muted-foreground">Corriger la lecture</p>
          <Slider
            className="mt-3"
            min={70}
            max={180}
            value={[Math.round(health.glucose)]}
            onValueChange={([v]) => setHealth({ glucose: v ?? health.glucose })}
          />
          <p className="mt-8 text-xs uppercase tracking-wider text-muted-foreground">Fatigue {health.fatigue}</p>
          <Slider
            className="mt-3"
            min={0}
            max={100}
            value={[health.fatigue]}
            onValueChange={([v]) => setHealth({ fatigue: v ?? health.fatigue })}
          />
        </Card>

        <Card className="p-5 lg:col-span-8">
          <p className="mb-3 text-xs uppercase tracking-[0.16em] text-muted-foreground">Courbe capteur · 3 h</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={health.cgm}>
                <XAxis dataKey="t" tickFormatter={(t) => formatTime(Number(t))} stroke="#8b9c96" fontSize={11} />
                <YAxis domain={[60, 180]} hide />
                <Tooltip
                  contentStyle={{ background: "#0b100f", border: "1px solid #1c2a26", borderRadius: 12 }}
                  labelFormatter={(t) => formatTime(Number(t))}
                  formatter={(v) => [`${v} mg/dL`, ""]}
                />
                <Line type="monotone" dataKey="v" stroke="#1a8f82" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <section className="mt-8">
        <h2 className="mb-4 font-display text-3xl">Adapter une recette</h2>
        <div className="grid gap-3 md:grid-cols-2">
          {recipes.length === 0 ? (
            <Card className="col-span-full p-6 text-sm text-muted-foreground">
              Aucune recette dans le carnet. Inventez-en une (Créer) puis revenez pour l’adapter à votre glycémie.
            </Card>
          ) : (
            recipes.slice(0, 4).map((r) => (
              <Card key={r.id} className="flex items-center justify-between gap-3 p-5">
                <div>
                  <p className="font-display text-xl">{r.title}</p>
                  <p className="text-xs text-muted-foreground">
                    IG {r.nutrition.ig} · {r.nutrition.glucides} g glucides
                  </p>
                </div>
                <Button size="sm" disabled={busy === r.id} onClick={() => void adapt(r.id)}>
                  {busy === r.id ? "…" : "Adapter"}
                </Button>
              </Card>
            ))
          )}
        </div>
        {pick ? (
          <p className="mt-4 text-xs text-muted-foreground">
            Suggestion du jour : {health.glucose > 120 ? "privilégier le gras et la protéine, calmer l’amidon." : health.fatigue > 55 ? "un plat simple, peu de pétrissage, beaucoup d’umami." : "vous pouvez vous offrir une cuisson ambitieuse."}
          </p>
        ) : null}
      </section>
    </div>
  );
}
