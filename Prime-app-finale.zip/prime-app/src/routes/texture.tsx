import { createFileRoute } from "@tanstack/react-router";
import { Camera, Upload } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { analyzeTextureOnDevice } from "@/lib/native-vision";
import type { TextureResult } from "@/lib/types";
import { fileToDataUrl } from "@/lib/utils";

export const Route = createFileRoute("/texture")({ component: TexturePage });

function TexturePage() {
  const [preview, setPreview] = useState<string | null>(null);
  const [question, setQuestion] = useState("La pâte est-elle assez pétrie ? La viande est-elle à point ?");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<TextureResult | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [cam, setCam] = useState(false);

  async function onFile(file: File) {
    const url = await fileToDataUrl(file);
    setPreview(url);
    setResult(null);
  }

  async function startCam() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setCam(true);
      }
    } catch {
      toast.error("Caméra indisponible. Importez une photo.");
    }
  }

  function capture() {
    const video = videoRef.current;
    if (!video) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext("2d")?.drawImage(video, 0, 0);
    setPreview(canvas.toDataURL("image/jpeg", 0.72));
    setResult(null);
  }

  async function analyze() {
    if (!preview) return;
    setBusy(true);
    try {
      // Vision classique locale (canvas) — aucune API
      const res = await analyzeTextureOnDevice(preview, question);
      setResult(res);
    } catch {
      toast.error("Impossible de lire l’image.");
    }
    setBusy(false);
  }

  return (
    <div className="enter mx-auto max-w-5xl">
      <PageHeader
        kicker="Vision locale"
        title="Un vrai œil de chef, dans la poche."
        lede="Photographiez une pâte, une viande, une sauce. Analyse 100 % locale (contraste, grain, transitions) — aucune API IA."
      />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="overflow-hidden">
          <div className="relative aspect-[4/3] bg-secondary">
            {preview ? (
              <img src={preview} alt="Texture à analyser" className="size-full object-cover" />
            ) : (
              <video ref={videoRef} className="size-full object-cover" playsInline muted />
            )}
            {!preview && !cam ? (
              <div className="absolute inset-0 grid place-items-center text-sm text-muted-foreground">
                Viseur en attente
              </div>
            ) : null}
          </div>
          <div className="flex flex-wrap gap-2 p-4">
            <Button variant="outline" onClick={() => fileRef.current?.click()}>
              <Upload /> Importer
            </Button>
            <Button variant="outline" onClick={cam ? capture : startCam}>
              <Camera /> {cam && !preview ? "Capturer" : "Caméra"}
            </Button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) void onFile(f);
              }}
            />
          </div>
        </Card>

        <div className="flex flex-col gap-4">
          <Card className="p-5">
            <p className="mb-2 text-xs uppercase tracking-[0.16em] text-muted-foreground">Question au chef</p>
            <Input value={question} onChange={(e) => setQuestion(e.target.value)} />
            <Button className="mt-4 w-full" disabled={!preview || busy} onClick={() => void analyze()}>
              {busy ? "Lecture de la matière…" : "Analyser la texture"}
            </Button>
          </Card>

          {result ? (
            <Card className="p-6">
              <Badge tone="ocean">{result.subject}</Badge>
              <p className="mt-4 font-display text-6xl tabular-nums">{Math.round(result.score)}</p>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Indice de justesse</p>
              <p className="mt-4 font-display text-2xl italic">{result.verdict}</p>
              <ul className="mt-4 grid gap-1.5 text-sm text-muted-foreground">
                {result.cues.map((c) => (
                  <li key={c}>— {c}</li>
                ))}
              </ul>
              <p className="mt-5 text-sm text-primary">{result.nextMove}</p>
            </Card>
          ) : (
            <Card className="p-6 text-sm text-muted-foreground">
              Pâte assez lisse, mie alvéolée, jus perlé, sauce qui nappe la cuillère : l’œil cherche ces preuves-là.
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
