import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { TasteBars, TasteRadar } from "@/components/taste-radar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input, Textarea } from "@/components/ui/input";
import { tasteOnDevice } from "@/lib/native-vision";
import type { TasteProfile } from "@/lib/types";

export const Route = createFileRoute("/gout")({ component: GoutPage });

function GoutPage() {
  const [dish, setDish] = useState("Côte de bœuf au thym brûlé, jus réduit, pommes grenaille");
  const [tweaks, setTweaks] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{
    title: string;
    note: string;
    taste: TasteProfile;
    risks: string[];
    adjustments: string[];
  } | null>(null);

  async function run() {
    if (!dish.trim()) {
      toast.error("Décrivez le plat.");
      return;
    }
    setBusy(true);
    // 100 % local — lexique + règles, aucune API
    await new Promise((r) => setTimeout(r, 180));
    setResult(tasteOnDevice(dish, tweaks));
    setBusy(false);
  }

  return (
    <div className="enter mx-auto max-w-5xl">
      <PageHeader
        kicker="Palais local"
        title="Goûter avant d’allumer le feu."
        lede="Décrivez le plat et les ingrédients. Calcul 100 % local (lexique organoleptique + règles) — aucune API IA."
      />

      <div className="grid gap-4 lg:grid-cols-5">
        <Card className="p-6 lg:col-span-2">
          <Label htmlFor="dish">Plat envisagé</Label>
          <Input id="dish" className="mt-2" value={dish} onChange={(e) => setDish(e.target.value)} />
          <Label htmlFor="tw" className="mt-5 block">
            Ajustements (sel, acidité, cuisson)
          </Label>
          <Textarea id="tw" className="mt-2" value={tweaks} onChange={(e) => setTweaks(e.target.value)} />
          <Button className="mt-6 w-full" disabled={busy} onClick={() => void run()}>
            {busy ? "Le palais cherche…" : "Simuler le goût"}
          </Button>
        </Card>

        <div className="lg:col-span-3">
          {result ? (
            <Card className="p-6">
              <Badge tone="ocean">{result.title}</Badge>
              <div className="mt-2 grid gap-6 md:grid-cols-2">
                <TasteRadar taste={result.taste} />
                <TasteBars taste={result.taste} />
              </div>
              <p className="mt-4 font-display text-xl italic leading-relaxed">{result.note}</p>
              {result.risks.length ? (
                <div className="mt-5">
                  <p className="text-xs uppercase tracking-wider text-muted-foreground">Risques</p>
                  <ul className="mt-2 grid gap-1 text-sm">
                    {result.risks.map((r) => (
                      <li key={r}>— {r}</li>
                    ))}
                  </ul>
                </div>
              ) : null}
              {result.adjustments.length ? (
                <div className="mt-4">
                  <p className="text-xs uppercase tracking-wider text-muted-foreground">Avant de se lancer</p>
                  <ul className="mt-2 grid gap-1 text-sm text-primary">
                    {result.adjustments.map((r) => (
                      <li key={r}>— {r}</li>
                    ))}
                  </ul>
                </div>
              ) : null}
            </Card>
          ) : (
            <Card className="grid h-full min-h-72 place-items-center p-8 text-center text-sm text-muted-foreground">
              Le radar restera vide tant que le palais n’a pas été consulté.
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
