import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/input";
import { generateRecipe } from "@/lib/ai";
import { dietaryConstraintText } from "@/lib/dietary";
import { REGION_PRESETS } from "@/lib/seed";
import { usePrime } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/creer")({ component: CreerPage });

const PROMPTS = [
  "Il me reste du miso, des topinambours et une orange amère. Je veux un plat que personne n’a vu.",
  "Dessert sans chocolat, sans vanille, qui goûte le feu de bois et l’hiver.",
  "Un poisson de rivière, une technique coréenne, des herbes de garrigue.",
  "Petit-déjeuner salé pour une glycémie capricieuse, texture croquante et veloutée.",
];

function CreerPage() {
  const navigate = useNavigate();
  const region = usePrime((s) => s.region);
  const setRegion = usePrime((s) => s.setRegion);
  const dietary = usePrime((s) => s.dietary);
  const addRecipe = usePrime((s) => s.addRecipe);
  const [constraint, setConstraint] = useState(PROMPTS[0]);
  const [busy, setBusy] = useState(false);

  async function run() {
    if (!constraint.trim()) return;
    setBusy(true);
    const dietTxt = dietaryConstraintText(dietary);
    const fullConstraint = dietTxt
      ? `${constraint}\n\nPréférences alimentaires : ${dietTxt}`
      : constraint;
    const res = await generateRecipe({ data: { constraint: fullConstraint, region } });
    setBusy(false);
    if (!res.ok) {
      toast.error(res.error);
      return;
    }
    addRecipe(res.recipe);
    toast.success("Recette inscrite au carnet.");
    void navigate({ to: "/recette/$id", params: { id: res.recipe.id } });
  }

  return (
    <div className="enter mx-auto max-w-3xl">
      <PageHeader
        kicker="Internet + structure pro"
        title="Recettes réelles, structurées."
        lede="Posez une contrainte. Prime interroge une base de recettes ouverte sur internet et structure le résultat (quantités, étapes, temps) comme un chef pro. 100 % gratuit."
      />

      <Card className="p-6">
        {dietaryConstraintText(dietary) ? (
          <p className="mb-4 text-xs text-muted-foreground">
            Préférences actives : {dietaryConstraintText(dietary)}.{" "}
            <Link to="/preferences" className="text-primary underline">Modifier</Link>
          </p>
        ) : (
          <p className="mb-4 text-xs text-muted-foreground">
            Aucune préférence définie —{" "}
            <Link to="/preferences" className="text-primary underline">régimes & allergies</Link>
          </p>
        )}
        <Label htmlFor="c">Contrainte</Label>
        <Textarea
          id="c"
          className="mt-2 min-h-36 font-display text-xl leading-snug"
          value={constraint}
          onChange={(e) => setConstraint(e.target.value)}
        />
        <div className="mt-4 flex flex-wrap gap-2">
          {PROMPTS.map((p) => (
            <button
              key={p}
              onClick={() => setConstraint(p)}
              className={cn(
                "rounded-full px-3 py-1.5 text-left text-xs text-muted-foreground shadow-[0_0_0_1px_rgb(243_246_244_/_0.1)]",
                constraint === p && "text-primary shadow-[0_0_0_1px_var(--color-primary)]",
              )}
            >
              {p.slice(0, 42)}…
            </button>
          ))}
        </div>

        <div className="mt-6">
          <Label>Territoire</Label>
          <div className="mt-2 flex flex-wrap gap-2">
            {REGION_PRESETS.map((r) => (
              <button
                key={r}
                onClick={() => setRegion(r)}
                className={cn(
                  "h-9 rounded-full px-3 text-xs",
                  region === r ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
                )}
              >
                {r}
              </button>
            ))}
          </div>
        </div>

        <Button className="mt-8 w-full" size="lg" disabled={busy} onClick={() => void run()}>
          {busy ? "Le chef imagine…" : "Inventer la recette"}
        </Button>
      </Card>
    </div>
  );
}
