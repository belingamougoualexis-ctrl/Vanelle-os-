import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/input";
import { translateRecipe } from "@/lib/ai";
import { REGION_PRESETS } from "@/lib/seed";
import { usePrime } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/traduire")({ component: TraduirePage });

const SAMPLE = `Mapo tofu
Tofu soyeux, sauce pimentée au poivre de Sichuan, doubanjiang, porc haché, huile de piment, sauce soja, oignon vert.
L’âme du plat : le málà — numbing + piquant — et le tofu qui tremble encore.`;

function TraduirePage() {
  const navigate = useNavigate();
  const region = usePrime((s) => s.region);
  const setRegion = usePrime((s) => s.setRegion);
  const addRecipe = usePrime((s) => s.addRecipe);
  const [source, setSource] = useState(SAMPLE);
  const [busy, setBusy] = useState(false);

  async function run() {
    setBusy(true);
    const res = await translateRecipe({ data: { source, region } });
    setBusy(false);
    if (!res.ok) {
      toast.error(res.error);
      return;
    }
    addRecipe(res.recipe);
    toast.success("Âme conservée, terroir adapté.");
    void navigate({ to: "/recette/$id", params: { id: res.recipe.id } });
  }

  return (
    <div className="enter mx-auto max-w-3xl">
      <PageHeader
        kicker="Traduction culturelle"
        title="Garder l’âme. Changer le marché."
        lede="Collez une recette lointaine. Prime la réécrit avec ce que l’on trouve ici, sans la vider de son caractère."
      />
      <Card className="p-6">
        <Label htmlFor="src">Recette source</Label>
        <Textarea id="src" className="mt-2 min-h-48" value={source} onChange={(e) => setSource(e.target.value)} />
        <div className="mt-6">
          <Label>Cuisiner comme si l’on était</Label>
          <div className="mt-2 flex flex-wrap gap-2">
            {REGION_PRESETS.map((r) => (
              <button
                key={r}
                onClick={() => setRegion(r)}
                className={cn(
                  "h-9 rounded-full px-3 text-xs",
                  region === r ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
                )}
              >
                {r}
              </button>
            ))}
          </div>
        </div>
        <Button className="mt-8 w-full" size="lg" disabled={busy} onClick={() => void run()}>
          {busy ? "Traduction en cours…" : "Traduire vers le local"}
        </Button>
      </Card>
    </div>
  );
}
