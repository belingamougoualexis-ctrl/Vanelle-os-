import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { MACRO_GOALS, usePrime, useTodayIntake, useTodayMacros } from "@/lib/store";
import { formatTime } from "@/lib/utils";

export const Route = createFileRoute("/nutrition")({ component: NutritionPage });

const KEYS = [
  { k: "kcal" as const, label: "Énergie", unit: "kcal", goal: MACRO_GOALS.kcal },
  { k: "prot" as const, label: "Protéines", unit: "g", goal: MACRO_GOALS.prot },
  { k: "glucides" as const, label: "Glucides", unit: "g", goal: MACRO_GOALS.glucides },
  { k: "lipides" as const, label: "Lipides", unit: "g", goal: MACRO_GOALS.lipides },
  { k: "fibres" as const, label: "Fibres", unit: "g", goal: MACRO_GOALS.fibres },
];

function NutritionPage() {
  const recipes = usePrime((s) => s.recipes);
  const addIntake = usePrime((s) => s.addIntake);
  const intake = useTodayIntake();
  const macros = useTodayMacros();
  const remaining = {
    kcal: MACRO_GOALS.kcal - macros.kcal,
    glucides: MACRO_GOALS.glucides - macros.glucides,
    prot: MACRO_GOALS.prot - macros.prot,
  };

  return (
    <div className="enter mx-auto max-w-5xl">
      <PageHeader
        kicker="Nutrition vivante"
        title="Pas la recette. La journée."
        lede="Les macros se recalculent selon ce que vous avez réellement mangé — portion comprise, pas la fiche isolée."
      />

      <div className="grid gap-4 md:grid-cols-2">
        {KEYS.map((row) => (
          <Card key={row.k} className="p-5">
            <div className="flex items-baseline justify-between">
              <p className="text-xs uppercase tracking-wider text-muted-foreground">{row.label}</p>
              <p className="font-mono text-sm tabular-nums">
                {Math.round(macros[row.k])} / {row.goal} {row.unit}
              </p>
            </div>
            <Progress className="mt-3" value={(macros[row.k] / row.goal) * 100} />
          </Card>
        ))}
      </div>

      <Card className="mt-6 p-6">
        <p className="text-xs uppercase tracking-[0.16em] text-muted-foreground">Il reste à composer</p>
        <p className="mt-2 font-display text-3xl">
          {Math.max(0, Math.round(remaining.kcal))} kcal · {Math.max(0, Math.round(remaining.prot))} g de protéines ·{" "}
          {Math.max(0, Math.round(remaining.glucides))} g de glucides
        </p>
        <p className="mt-2 text-sm text-muted-foreground">
          Choisissez le dîner en fonction du réel, pas d’une moyenne.
        </p>
      </Card>

      <section className="mt-10">
        <h2 className="mb-4 font-display text-3xl">Journal du jour</h2>
        <ul className="grid gap-3">
          {intake.length === 0 ? (
            <Card className="p-6 text-sm text-muted-foreground">Rien n’a encore été logué aujourd’hui.</Card>
          ) : (
            intake.map((e) => (
              <Card key={e.id} className="flex items-center justify-between p-4">
                <div>
                  <p className="font-medium">{e.label}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatTime(e.at)} · portion {e.portion.toFixed(1)}
                  </p>
                </div>
                <p className="font-mono text-sm tabular-nums">{Math.round(e.nutrition.kcal * e.portion)} kcal</p>
              </Card>
            ))
          )}
        </ul>
      </section>

      <section className="mt-10">
        <h2 className="mb-4 font-display text-3xl">Logger une recette</h2>
        <div className="grid gap-3">
          {recipes.slice(0, 5).map((r) => (
            <Card key={r.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
              <Link to="/recette/$id" params={{ id: r.id }} className="font-display text-xl hover:text-primary">
                {r.title}
              </Link>
              <Button
                size="sm"
                variant="outline"
                onClick={() =>
                  addIntake({
                    at: Date.now(),
                    label: r.title,
                    recipeId: r.id,
                    portion: 1,
                    nutrition: r.nutrition,
                  })
                }
              >
                J’ai mangé ça
              </Button>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
