import { createFileRoute, Link } from "@tanstack/react-router";
import { Mic, Square } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/input";
import { localLinkVoiceNote } from "@/lib/local-sense";
import { usePrime } from "@/lib/store";
import { formatDay, formatTime } from "@/lib/utils";

export const Route = createFileRoute("/journal")({ component: JournalPage });

const TAG_LABEL: Record<string, string> = {
  "trop-sale": "Trop salé",
  "trop-fade": "Trop fade",
  parfait: "Parfait",
  "pas-cuit": "Pas assez cuit",
  "trop-cuit": "Trop cuit",
  texture: "Texture",
  autre: "Note",
};

type Recog = {
  lang: string;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onend: (() => void) | null;
};

function JournalPage() {
  const notes = usePrime((s) => s.notes);
  const recipes = usePrime((s) => s.recipes);
  const addNote = usePrime((s) => s.addNote);
  const [text, setText] = useState("");
  const [listening, setListening] = useState(false);
  const [busy, setBusy] = useState(false);
  const recRef = useRef<Recog | null>(null);

  function startVoice() {
    const w = window as unknown as {
      webkitSpeechRecognition?: new () => Recog;
      SpeechRecognition?: new () => Recog;
    };
    const SR = w.webkitSpeechRecognition ?? w.SpeechRecognition;
    if (!SR) {
      toast.error("Dictée indisponible — écrivez la note.");
      return;
    }
    const rec = new SR();
    rec.lang = "fr-FR";
    rec.interimResults = true;
    rec.onresult = (e) => {
      const t = Array.from(e.results)
        .map((r) => r[0]?.transcript ?? "")
        .join(" ");
      setText(t);
    };
    rec.onend = () => setListening(false);
    recRef.current = rec;
    rec.start();
    setListening(true);
  }

  async function save() {
    if (!text.trim()) return;
    setBusy(true);
    // 100 % local — règles de tags, aucune API
    await new Promise((r) => setTimeout(r, 120));
    const res = localLinkVoiceNote(
      text,
      recipes.slice(0, 12).map((r) => ({ id: r.id, title: r.title })),
    );
    addNote({
      transcript: text,
      recipeId: res.recipeId ?? undefined,
      recipeTitle: res.recipeTitle ?? undefined,
      tag: res.tag,
      adjustment: res.adjustment,
    });
    setBusy(false);
    toast.success("Note enregistrée.");
    setText("");
  }

  return (
    <div className="enter mx-auto max-w-3xl">
      <PageHeader
        kicker="Mémoire sensorielle"
        title="« Trop salé cette fois. »"
        lede="Note vocale ou texte. Analyse locale (mots-clés) : tag + ajustement, sans API."
      />

      <Card className="p-5">
        <Textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Dites-le comme en cuisine — trop cuit, manque d’acidité, mie trop serrée…"
        />
        <div className="mt-3 flex flex-wrap gap-2">
          <Button variant={listening ? "porcelain" : "outline"} onClick={() => (listening ? recRef.current?.stop() : startVoice())}>
            {listening ? <Square /> : <Mic />}
            {listening ? "Stop" : "Parler"}
          </Button>
          <Button disabled={busy || !text.trim()} onClick={() => void save()}>
            {busy ? "Relier…" : "Enregistrer"}
          </Button>
        </div>
      </Card>

      <ul className="mt-8 grid gap-3">
        {notes.map((n) => (
          <Card key={n.id} className="p-5">
            <div className="flex items-center justify-between gap-3">
              <Badge>{TAG_LABEL[n.tag] ?? n.tag}</Badge>
              <span className="text-xs text-muted-foreground">
                {formatDay(n.at)} · {formatTime(n.at)}
              </span>
            </div>
            <p className="mt-3 font-display text-2xl italic leading-snug">« {n.transcript} »</p>
            {n.recipeId ? (
              <Link to="/recette/$id" params={{ id: n.recipeId }} className="mt-2 inline-block text-sm text-primary">
                {n.recipeTitle}
              </Link>
            ) : null}
            {n.adjustment ? <p className="mt-2 text-sm text-muted-foreground">Prochaine fois — {n.adjustment}</p> : null}
          </Card>
        ))}
      </ul>
    </div>
  );
}
