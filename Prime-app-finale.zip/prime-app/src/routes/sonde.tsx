import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import {
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { PROBE_PRESETS } from "@/lib/seed";
import { formatRemain, tickProbe } from "@/lib/sensors";
import { usePrime } from "@/lib/store";
import type { ProbeFood } from "@/lib/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/sonde")({ component: SondePage });

function SondePage() {
  const probe = usePrime((s) => s.probe);
  const setProbe = usePrime((s) => s.setProbe);
  const resetProbe = usePrime((s) => s.resetProbe);
  const preset = PROBE_PRESETS[probe.food];
  const done = probe.coreC >= probe.targetC;

  useEffect(() => {
    if (!probe.running) return;
    const id = window.setInterval(() => setProbe((p) => tickProbe(p, 2.2)), 400);
    return () => window.clearInterval(id);
  }, [probe.running, setProbe]);

  return (
    <div className="enter mx-auto max-w-6xl">
      <PageHeader
        kicker="Perception · Thermométrie"
        title="Le temps qu’il reste, déjà."
        lede="Sonde Bluetooth Prime T-2. La courbe est réelle ; le temps restant est une prédiction newtonienne affinée à chaque seconde."
        action={
          probe.running ? (
            <Button variant="outline" onClick={() => setProbe({ running: false })}>
              Pause
            </Button>
          ) : (
            <Button onClick={() => setProbe({ running: true, startedAt: Date.now() })}>Lancer la sonde</Button>
          )
        }
      />

      <div className="mb-6 flex flex-wrap gap-2">
        {(Object.keys(PROBE_PRESETS) as ProbeFood[]).map((k) => (
          <button
            key={k}
            onClick={() => resetProbe(k)}
            className={cn(
              "h-10 rounded-full px-4 text-sm",
              probe.food === k ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
            )}
          >
            {PROBE_PRESETS[k].label.split("·")[0]}
          </button>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <Card className="p-6 lg:col-span-4">
          {done ? <Badge tone="ocean">Cible atteinte · {preset.rest}</Badge> : <Badge>Cœur en montée</Badge>}
          <p className="mt-6 text-xs uppercase tracking-[0.18em] text-muted-foreground">Température à cœur</p>
          <p className="font-display text-7xl tabular-nums leading-none">
            {probe.coreC.toFixed(1)}
            <span className="text-3xl text-muted-foreground">°</span>
          </p>
          <p className="mt-4 text-sm text-muted-foreground">
            Cible {probe.targetC} °C · four {probe.ovenC} °C
          </p>
          <p className="mt-6 font-display text-4xl tabular-nums text-primary">{formatRemain(probe.predictedRemainSec)}</p>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Temps restant prédit</p>

          <div className="mt-8">
            <p className="mb-3 text-xs uppercase tracking-wider text-muted-foreground">Four</p>
            <Slider
              min={80}
              max={260}
              step={5}
              value={[probe.ovenC]}
              onValueChange={([v]) => setProbe({ ovenC: v ?? probe.ovenC })}
            />
          </div>
        </Card>

        <Card className="p-5 lg:col-span-8">
          <p className="mb-3 text-xs uppercase tracking-[0.16em] text-muted-foreground">Courbe · {preset.label}</p>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={probe.history}>
                <XAxis dataKey="t" hide />
                <YAxis domain={[0, Math.max(probe.ovenC, 100)]} hide />
                <ReferenceLine y={probe.targetC} stroke="#1a8f82" strokeDasharray="4 4" />
                <Tooltip
                  contentStyle={{ background: "#0b100f", border: "1px solid #1c2a26", borderRadius: 12 }}
                  formatter={(v) => [`${Number(v).toFixed(1)} °C`, ""]}
                />
                <Line type="monotone" dataKey="core" stroke="#1a8f82" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="predicted" stroke="#f3f6f4" strokeOpacity={0.35} strokeDasharray="5 5" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
    </div>
  );
}
