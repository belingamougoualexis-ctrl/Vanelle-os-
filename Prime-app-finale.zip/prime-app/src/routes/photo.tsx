import { createFileRoute } from "@tanstack/react-router";
import { Camera, Check, ChevronDown, CircleAlert, Sparkles, Upload } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { analyzePhotoOnDevice } from "@/lib/native-vision";
import type { MineralProfile, PhotoAnalysisResult, VitaminProfile } from "@/lib/types";
import { usePrime } from "@/lib/store";
import { fileToDataUrl } from "@/lib/utils";

export const Route = createFileRoute("/photo")({ component: PhotoPage });

function NutrientList({ title, items, empty }: { title: string; items: (VitaminProfile | MineralProfile)[]; empty: string }) {
  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-display text-2xl">{title}</h3>
        <span className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">estimations</span>
      </div>
      {items.length ? (
        <div className="grid gap-2 sm:grid-cols-2">
          {items.map((item, i) => (
            <div key={`${item.vitamin || item.mineral}-${i}`} className="flex items-center justify-between rounded-xl border border-border bg-secondary/70 px-4 py-3">
              <span className="text-sm">{item.vitamin || item.mineral}</span>
              <span className="text-sm font-medium text-primary">
                {item.amount} {item.unit}
                {item.percentDailyValue ? <span className="ml-1 text-xs text-muted-foreground">· {Math.round(item.percentDailyValue)}%</span> : null}
              </span>
            </div>
          ))}
        </div>
      ) : <p className="text-sm text-muted-foreground">{empty}</p>}
    </div>
  );
}

function PhotoPage() {
  const fileRef = useRef<HTMLInputElement>(null);
  const addRecipe = usePrime((s) => s.addRecipe);
  const [preview, setPreview] = useState<string | null>(null);
  const [hint, setHint] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<PhotoAnalysisResult | null>(null);

  async function run() {
    if (!preview) return;
    setBusy(true);
    try {
      // Couleurs locales + recherche internet gratuite (TheMealDB) — aucune API IA
      const res = await analyzePhotoOnDevice(preview, hint);
      setResult(res);
    } catch {
      toast.error("Analyse impossible. Vérifiez l’image ou la connexion.");
    }
    setBusy(false);
  }

  return (
    <div className="enter mx-auto max-w-6xl">
      <PageHeader
        kicker="Vision locale · Nutrition"
        title="Scannez. Comprenez. Cuisinez."
        lede="Analyse locale (couleurs) + base de recettes gratuite sur internet. Aucune API IA. Ajoutez un indice (nom du plat) pour plus de précision."
      />

      <div className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
        <Card className="prime-glow overflow-hidden">
          <button
            className="prime-scan-frame relative flex aspect-[4/3] w-full items-center justify-center overflow-hidden bg-secondary"
            onClick={() => fileRef.current?.click()}
            aria-label="Choisir une photo du plat"
          >
            {preview ? (
              <img src={preview} alt="Plat à analyser" className="size-full object-cover" />
            ) : (
              <div className="flex flex-col items-center gap-3 px-8 text-center">
                <span className="grid size-16 place-items-center rounded-full border border-primary/30 bg-primary/10 text-primary">
                  <Camera className="size-7" strokeWidth={1.4} />
                </span>
                <span className="font-display text-2xl">Déposer votre plat</span>
                <span className="max-w-xs text-sm leading-relaxed text-muted-foreground">Photo nette, assiette entière si possible. Prime travaille mieux avec une vue bien éclairée.</span>
              </div>
            )}
            {busy ? (
              <div className="absolute inset-0 grid place-items-center bg-ink/70 backdrop-blur-sm">
                <div className="text-center">
                  <Sparkles className="mx-auto size-7 animate-pulse text-primary" />
                  <p className="mt-3 font-display text-2xl">Prime analyse…</p>
                  <p className="mt-1 text-xs uppercase tracking-[0.16em] text-muted-foreground">composition · nutrition · recette</p>
                </div>
              </div>
            ) : null}
          </button>
          <input ref={fileRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) { setPreview(await fileToDataUrl(f)); setResult(null); } }} />
          <div className="grid gap-3 p-5">
            <Input placeholder="Indice facultatif : mafé, saumon, riz sauce arachide…" value={hint} onChange={(e) => setHint(e.target.value)} />
            <Button size="lg" className="w-full" disabled={!preview || busy} onClick={() => void run()}>
              <Upload /> {busy ? "Analyse en cours…" : "Analyser ce plat"}
            </Button>
            <p className="flex gap-2 text-xs leading-relaxed text-muted-foreground"><CircleAlert className="mt-0.5 size-3.5 shrink-0" /> Les valeurs nutritionnelles issues d’une photo sont des estimations. Une photo ne permet pas de mesurer exactement les grammes ou les micronutriments.</p>
          </div>
        </Card>

        {!result ? (
          <Card className="p-7">
            <Badge>PRIME VISION</Badge>
            <h2 className="mt-5 max-w-lg font-display text-4xl leading-tight">Une fiche technique complète à partir d’une seule image.</h2>
            <div className="mt-7 grid gap-3 sm:grid-cols-2">
              {["Identification du plat", "Portion estimée", "Calories & macros", "Vitamines & minéraux", "Ingrédients détaillés", "Méthode de cuisson précise"].map((x) => (
                <div key={x} className="flex items-center gap-2 rounded-xl border border-border bg-secondary/50 px-4 py-3 text-sm">
                  <Check className="size-4 text-primary" /> {x}
                </div>
              ))}
            </div>
            <div className="prime-gold-line mt-8" />
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">La précision dépend de ce qui est visible, de la taille de la portion et des ingrédients que Prime peut raisonnablement déduire.</p>
          </Card>
        ) : (
          <div className="space-y-5">
            <Card className="p-7">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <Badge>{result.cuisine}</Badge>
                  <h2 className="mt-3 font-display text-4xl leading-tight">{result.dish}</h2>
                  <p className="mt-2 text-sm text-muted-foreground">{result.portionDescription}</p>
                </div>
                <div className="rounded-2xl border border-primary/25 bg-primary/10 px-4 py-3 text-right">
                  <span className="block text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Confiance</span>
                  <strong className="font-display text-3xl text-primary">{Math.round(result.confidence)}%</strong>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4">
                <Metric label="Calories" value={`${Math.round(result.recipe.nutrition.kcal)} kcal`} />
                <Metric label="Protéines" value={`${result.recipe.nutrition.prot} g`} />
                <Metric label="Glucides" value={`${result.recipe.nutrition.glucides} g`} />
                <Metric label="Lipides" value={`${result.recipe.nutrition.lipides} g`} />
              </div>
            </Card>

            <Card className="p-6">
              <NutrientList title="Vitamines" items={result.vitamins} empty="Aucune vitamine suffisamment estimable depuis cette image." />
              <div className="my-7 border-t border-border" />
              <NutrientList title="Minéraux" items={result.minerals} empty="Aucun minéral suffisamment estimable depuis cette image." />
              <p className="mt-6 rounded-xl bg-secondary p-4 text-xs leading-relaxed text-muted-foreground">Base nutritionnelle : {result.nutritionBasis}</p>
            </Card>
          </div>
        )}
      </div>

      {result ? (
        <section className="mt-7 grid gap-5 lg:grid-cols-[0.8fr_1.2fr]">
          <Card className="p-7">
            <Badge>RECETTE RECONSTRUITE</Badge>
            <h2 className="mt-3 font-display text-3xl">{result.recipe.title}</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{result.recipe.story}</p>
            <div className="mt-6 grid grid-cols-3 gap-2 text-center">
              <div className="rounded-xl bg-secondary p-3"><strong className="block font-display text-xl">{result.recipe.servings}</strong><span className="text-[10px] uppercase tracking-wider text-muted-foreground">portions</span></div>
              <div className="rounded-xl bg-secondary p-3"><strong className="block font-display text-xl">{result.recipe.timeMin} min</strong><span className="text-[10px] uppercase tracking-wider text-muted-foreground">temps</span></div>
              <div className="rounded-xl bg-secondary p-3"><strong className="block font-display text-xl">{result.recipe.difficulty}</strong><span className="text-[10px] uppercase tracking-wider text-muted-foreground">niveau</span></div>
            </div>
            <Button
              className="mt-6 w-full"
              onClick={() => {
                addRecipe(result.recipe);
                toast.success("Recette ajoutée au carnet.");
              }}
            >
              <Sparkles /> Ajouter au carnet
            </Button>
          </Card>
          <Card className="p-7">
            <div className="flex items-center justify-between gap-3">
              <h2 className="font-display text-3xl">Fiche technique</h2>
              <span className="text-xs text-muted-foreground">{result.recipe.ingredients.length} ingrédients · {result.recipe.steps.length} étapes</span>
            </div>
            <div className="mt-5 grid gap-3">
              {result.recipe.ingredients.map((item) => (
                <div key={`${item.name}-${item.qty}`} className="flex justify-between gap-4 border-b border-border pb-3 text-sm"><span>{item.name}</span><strong className="font-medium text-primary">{item.qty}</strong></div>
              ))}
            </div>
            <details className="mt-6 rounded-xl bg-secondary p-4" open>
              <summary className="flex cursor-pointer list-none items-center justify-between font-medium">Méthode pas à pas <ChevronDown className="size-4" /></summary>
              <div className="mt-4 space-y-4">
                {result.recipe.steps.map((step) => (
                  <div key={step.n} className="flex gap-4">
                    <span className="grid size-7 shrink-0 place-items-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">{step.n}</span>
                    <div className="text-sm leading-relaxed"><p>{step.text}</p><p className="mt-1 text-xs text-muted-foreground">{step.durationMin ? `${step.durationMin} min` : ""}{step.tempC ? ` · ${step.tempC} °C` : ""}{step.induction ? ` · puissance ${step.induction}/9` : ""}</p></div>
                  </div>
                ))}
              </div>
            </details>
          </Card>
        </section>
      ) : null}
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div className="rounded-xl border border-border bg-secondary p-3"><span className="block text-[10px] uppercase tracking-wider text-muted-foreground">{label}</span><strong className="mt-1 block font-display text-xl">{value}</strong></div>;
}
