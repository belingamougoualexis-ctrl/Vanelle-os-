import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { TasteBars, TasteRadar } from "@/components/taste-radar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { usePrime } from "@/lib/store";
import { formatMin } from "@/lib/utils";

export const Route = createFileRoute("/recette/$id")({ component: RecipePage });

const DIFF = { simple: "Simple", intermediaire: "Intermédiaire", chef: "Chef" };
const SRC = {
  seed: "Carnet",
  generated: "Inédite",
  translated: "Traduite",
  photo: "Cliché",
  adapted: "Adaptée",
};

function RecipePage() {
  const { id } = Route.useParams();
  const recipes = usePrime((s) => s.recipes);
  const allNotes = usePrime((s) => s.notes);
  const addIntake = usePrime((s) => s.addIntake);
  const recipe = recipes.find((r) => r.id === id);
  const notes = useMemo(() => allNotes.filter((n) => n.recipeId === id), [allNotes, id]);

  if (!recipe) {
    return (
      <div className="enter mx-auto max-w-xl py-20 text-center">
        <p className="font-display text-3xl">Cette recette s’est évanouie.</p>
        <Link to="/" className="mt-4 inline-block text-sm text-primary">
          Retour à l’atelier
        </Link>
      </div>
    );
  }

  return (
    <div className="enter mx-auto max-w-5xl">
      <p className="text-xs uppercase tracking-[0.22em] text-primary">{recipe.origin}</p>
      <h1 className="mt-2 font-display text-5xl font-medium leading-tight">{recipe.title}</h1>
      <div className="mt-4 flex flex-wrap gap-2">
        <Badge>{SRC[recipe.source]}</Badge>
        <Badge tone="mute">{DIFF[recipe.difficulty]}</Badge>
        <Badge tone="mute">{formatMin(recipe.timeMin)}</Badge>
        <Badge tone="mute">{recipe.servings} parts</Badge>
      </div>
      <p className="mt-6 max-w-2xl font-display text-xl italic leading-relaxed text-muted-foreground">{recipe.story}</p>

      <div className="mt-8 flex flex-wrap gap-2">
        <Button
          onClick={() =>
            addIntake({
              at: Date.now(),
              label: recipe.title,
              recipeId: recipe.id,
              portion: 1,
              nutrition: recipe.nutrition,
            })
          }
        >
          Logger dans la journée
        </Button>
        <Button variant="outline" asChild>
          <Link to="/robot">Orchestrer</Link>
        </Button>
        <Button variant="ghost" asChild>
          <Link to="/gout">Simuler le goût</Link>
        </Button>
      </div>

      <div className="mt-10 grid gap-4 lg:grid-cols-2">
        <Card className="p-6">
          <h2 className="font-display text-2xl">Ingrédients</h2>
          <ul className="mt-4 grid gap-2.5">
            {recipe.ingredients.map((ing) => (
              <li key={ing.name} className="flex items-baseline justify-between gap-4 border-b border-border pb-2">
                <span>
                  {ing.name}
                  {ing.local ? <span className="ml-2 text-[10px] uppercase tracking-wider text-primary">local</span> : null}
                  {ing.note ? <span className="mt-0.5 block text-xs text-muted-foreground">{ing.note}</span> : null}
                </span>
                <span className="shrink-0 font-mono text-sm tabular-nums text-muted-foreground">{ing.qty}</span>
              </li>
            ))}
          </ul>
        </Card>
        <Card className="p-6">
          <h2 className="font-display text-2xl">Gestes</h2>
          <ol className="mt-4 grid gap-4">
            {recipe.steps.map((s) => (
              <li key={s.n} className="grid grid-cols-[2.5rem_1fr] gap-3">
                <span className="font-mono text-sm tabular-nums text-primary">{String(s.n).padStart(2, "0")}</span>
                <div>
                  <p className="text-sm leading-relaxed">{s.text}</p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {s.durationMin ? `${s.durationMin} min` : null}
                    {s.tempC ? ` · ${s.tempC} °C` : null}
                    {s.arm ? ` · bras ${s.arm}` : null}
                  </p>
                </div>
              </li>
            ))}
          </ol>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card className="p-6">
          <h2 className="font-display text-2xl">Profil aromatique</h2>
          {recipe.aromaticNote ? (
            <p className="mt-2 text-sm italic text-muted-foreground">{recipe.aromaticNote}</p>
          ) : null}
          <div className="mt-2 grid gap-4 md:grid-cols-2">
            <TasteRadar taste={recipe.taste} size={220} />
            <TasteBars taste={recipe.taste} />
          </div>
        </Card>
        <Card className="p-6">
          <h2 className="font-display text-2xl">Nutrition (par part)</h2>
          <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <Row k="Énergie" v={`${recipe.nutrition.kcal} kcal`} />
            <Row k="Protéines" v={`${recipe.nutrition.prot} g`} />
            <Row k="Glucides" v={`${recipe.nutrition.glucides} g`} />
            <Row k="Lipides" v={`${recipe.nutrition.lipides} g`} />
            <Row k="Fibres" v={`${recipe.nutrition.fibres} g`} />
            <Row k="Sel" v={`${recipe.nutrition.sel} g`} />
            <Row k="Index glycémique" v={`${recipe.nutrition.ig}`} />
          </dl>
        </Card>
      </div>

      {notes.length ? (
        <section className="mt-8">
          <h2 className="mb-3 font-display text-2xl">Mémoire de ce plat</h2>
          <div className="grid gap-3">
            {notes.map((n) => (
              <Card key={n.id} className="p-4">
                <p className="font-display text-xl italic">« {n.transcript} »</p>
                {n.adjustment ? <p className="mt-1 text-sm text-muted-foreground">{n.adjustment}</p> : null}
              </Card>
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-baseline justify-between gap-3 border-b border-border pb-2">
      <dt className="text-muted-foreground">{k}</dt>
      <dd className="font-mono tabular-nums">{v}</dd>
    </div>
  );
}
