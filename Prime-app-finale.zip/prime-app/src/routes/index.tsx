import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, Wind, Thermometer, Sparkles, HeartPulse } from "lucide-react";
import { LogoMark } from "@/components/logo";
import { RecipeCard } from "@/components/recipe-card";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { recipeMatchesDietary } from "@/lib/dietary";
import { MACRO_GOALS, usePrime, useTodayMacros } from "@/lib/store";
import { formatDay } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

const PORTALS = [
  {
    to: "/nez" as const,
    icon: Wind,
    kicker: "Perception",
    title: "Nez électronique",
    text: "Caramélisation, Maillard, point de cuisson — sans ouvrir le four.",
  },
  {
    to: "/sonde" as const,
    icon: Thermometer,
    kicker: "Précision",
    title: "Sonde à cœur",
    text: "Courbe en direct et temps restant prédit par le modèle thermique.",
  },
  {
    to: "/creer" as const,
    icon: Sparkles,
    kicker: "Génération",
    title: "Recette inédite",
    text: "Une contrainte improbable. Un plat que personne n’a écrit.",
  },
  {
    to: "/sante" as const,
    icon: HeartPulse,
    kicker: "Bio-feedback",
    title: "Le corps du jour",
    text: "Glycémie, fatigue, et recettes qui s’adaptent vraiment.",
  },
];

function Home() {
  const recipesAll = usePrime((s) => s.recipes);
  const dietary = usePrime((s) => s.dietary);
  const recipes = recipesAll.filter((r) => recipeMatchesDietary(r, dietary));
  const notes = usePrime((s) => s.notes);
  const health = usePrime((s) => s.health);
  const macros = useTodayMacros();
  const greeting =
    new Date().getHours() < 12 ? "Le service du matin" : new Date().getHours() < 18 ? "Le service du jour" : "Le service du soir";

  return (
    <div className="enter mx-auto max-w-6xl">
      <section className="relative overflow-hidden rounded-2xl bg-card px-6 py-10 shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)] md:px-12 md:py-16">
        <LogoMark className="pointer-events-none absolute -right-4 -top-6 size-56 text-primary/20 md:size-72" />
        <p className="relative text-xs uppercase tracking-[0.22em] text-primary">{greeting}</p>
        <h1 className="relative mt-3 max-w-xl font-display text-5xl font-medium leading-[1.05] tracking-tight md:text-6xl">
          Élevez votre art
          <br />
          <em className="italic">tous les sens.</em>
        </h1>
        <p className="relative mt-5 max-w-lg text-sm leading-relaxed text-muted-foreground">
          Prime est le cerveau de votre cuisine (100 % gratuit) : nez, sonde et palais connectés à l’IA en direct via internet. Aucune recette pré-remplie — tout est généré ou scanné en temps réel, structure de chef pro.
        </p>
        <p className="relative mt-6 text-xs uppercase tracking-[0.16em] text-muted-foreground">{formatDay(Date.now())}</p>
      </section>

      <section className="mt-8 grid gap-4 md:grid-cols-3">
        <Card className="p-5">
          <p className="text-xs uppercase tracking-[0.16em] text-muted-foreground">Glycémie</p>
          <p className="mt-2 font-display text-4xl tabular-nums">{Math.round(health.glucose)}</p>
          <p className="text-sm text-muted-foreground">mg/dL · {health.trend === "up" ? "en hausse" : health.trend === "down" ? "en baisse" : "stable"}</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs uppercase tracking-[0.16em] text-muted-foreground">Énergie du jour</p>
          <p className="mt-2 font-display text-4xl tabular-nums">{Math.round(100 - health.fatigue)}</p>
          <p className="text-sm text-muted-foreground">sommeil {health.sleepH.toFixed(1)} h</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs uppercase tracking-[0.16em] text-muted-foreground">Calories restantes</p>
          <p className="mt-2 font-display text-4xl tabular-nums">{Math.max(0, Math.round(MACRO_GOALS.kcal - macros.kcal))}</p>
          <Progress className="mt-3" value={(macros.kcal / MACRO_GOALS.kcal) * 100} />
        </Card>
      </section>

      <section className="mt-10 grid gap-4 md:grid-cols-2">
        {PORTALS.map((p) => {
          const Icon = p.icon;
          return (
            <Link
              key={p.to}
              to={p.to}
              className="group flex items-start gap-4 rounded-2xl bg-card p-6 shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)] transition-[box-shadow] hover:shadow-[0_0_0_1px_rgb(26_143_130_/_0.55)]"
            >
              <span className="grid size-11 place-items-center rounded-lg bg-secondary text-primary">
                <Icon className="size-5" strokeWidth={1.6} />
              </span>
              <div className="flex-1">
                <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{p.kicker}</p>
                <h2 className="mt-1 font-display text-2xl font-medium">{p.title}</h2>
                <p className="mt-1 text-sm text-muted-foreground">{p.text}</p>
              </div>
              <ArrowUpRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-primary" />
            </Link>
          );
        })}
      </section>

      <section className="mt-12">
        <div className="mb-5 flex items-end justify-between">
          <h2 className="font-display text-3xl">Le carnet</h2>
          <Link to="/creer" className="text-sm text-primary">
            Inventer
          </Link>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          {recipes.length === 0 ? (
            <Card className="col-span-full p-8 text-center">
              <p className="font-display text-xl">Aucune recette encore</p>
              <p className="mt-2 text-sm text-muted-foreground">
                Inventez une recette inédite (accès internet + IA chef pro) ou scannez un plat.
              </p>
              <Link to="/creer" className="mt-4 inline-block text-sm text-primary underline">
                Créer la première
              </Link>
            </Card>
          ) : (
            recipes.slice(0, 6).map((r) => <RecipeCard key={r.id} recipe={r} />)
          )}
        </div>
      </section>

      {notes[0] ? (
        <section className="mt-12">
          <h2 className="mb-4 font-display text-3xl">Dernière mémoire</h2>
          <Card className="p-6">
            <Badge>{notes[0].recipeTitle ?? "Note libre"}</Badge>
            <p className="mt-4 font-display text-2xl italic leading-snug">« {notes[0].transcript} »</p>
            {notes[0].adjustment ? (
              <p className="mt-3 text-sm text-muted-foreground">Prochaine fois — {notes[0].adjustment}</p>
            ) : null}
          </Card>
        </section>
      ) : null}
    </div>
  );
}
