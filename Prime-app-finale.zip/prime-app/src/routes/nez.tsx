import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { COMPOUNDS, NOSE_DISHES } from "@/lib/seed";
import { tickNose } from "@/lib/sensors";
import { usePrime } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/nez")({ component: NezPage });

function NezPage() {
  const nose = usePrime((s) => s.nose);
  const setNose = usePrime((s) => s.setNose);
  const resetNose = usePrime((s) => s.resetNose);
  const dish = NOSE_DISHES.find((d) => d.id === nose.dish) ?? NOSE_DISHES[0];

  useEffect(() => {
    if (!nose.running) return;
    const id = window.setInterval(() => setNose((n) => tickNose(n, 1.1)), 350);
    return () => window.clearInterval(id);
  }, [nose.running, setNose]);

  return (
    <div className="enter mx-auto max-w-6xl">
      <PageHeader
        kicker="Perception · Olfaction"
        title="Le four reste fermé."
        lede="Le nez Prime N-1 lit les composés volatils. Il annonce le caramel, le Maillard, le point juste — sans perdre la chaleur."
        action={
          nose.running ? (
            <Button variant="outline" onClick={() => setNose({ running: false })}>
              Pause
            </Button>
          ) : (
            <Button onClick={() => setNose({ running: true, startedAt: Date.now() })}>Écouter l’air</Button>
          )
        }
      />

      <div className="mb-6 flex flex-wrap gap-2">
        {NOSE_DISHES.map((d) => (
          <button
            key={d.id}
            onClick={() => resetNose(d.id)}
            className={cn(
              "h-10 rounded-full px-4 text-sm",
              nose.dish === d.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
            )}
          >
            {d.label}
          </button>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <Card className="relative overflow-hidden p-6 lg:col-span-5">
          {nose.ready ? (
            <div className="ready-pulse mb-4">
              <Badge tone="ocean">Plat prêt — ne pas ouvrir plus tôt</Badge>
            </div>
          ) : (
            <Badge>Capteur · {nose.running ? "en ligne" : "en veille"}</Badge>
          )}
          <p className="mt-6 text-xs uppercase tracking-[0.18em] text-muted-foreground">Indice de doneness</p>
          <p className="font-display text-7xl tabular-nums leading-none">{Math.round(nose.doneness)}</p>
          <p className="mt-2 text-sm text-muted-foreground">{dish.note}</p>
          <div className="mt-8 grid grid-cols-2 gap-4">
            <Metric label="Caramel" value={nose.caramel} />
            <Metric label="Maillard" value={nose.maillard} />
          </div>
        </Card>

        <Card className="p-5 lg:col-span-7">
          <p className="mb-3 text-xs uppercase tracking-[0.16em] text-muted-foreground">Courbe olfactive</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={nose.history}>
                <XAxis dataKey="t" hide />
                <YAxis domain={[0, 100]} hide />
                <Tooltip
                  contentStyle={{ background: "#0b100f", border: "1px solid #1c2a26", borderRadius: 12 }}
                  labelFormatter={() => ""}
                />
                <Area type="monotone" dataKey="caramel" stroke="#1a8f82" fill="#1a8f82" fillOpacity={0.18} />
                <Area type="monotone" dataKey="maillard" stroke="#f3f6f4" fill="#f3f6f4" fillOpacity={0.06} />
                <Area type="monotone" dataKey="doneness" stroke="#8b9c96" fill="transparent" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <section className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {COMPOUNDS.map((c) => (
          <Card key={c.id} className="p-4">
            <div className="flex items-baseline justify-between">
              <p className="text-sm">{c.name}</p>
              <p className="font-mono text-sm tabular-nums text-primary">{Math.round(nose.compounds[c.id] ?? 0)}</p>
            </div>
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground">{c.family}</p>
            <div className="mt-3 h-1 rounded-full bg-secondary">
              <div
                className="h-full rounded-full bg-primary"
                style={{ width: `${nose.compounds[c.id] ?? 0}%` }}
              />
            </div>
          </Card>
        ))}
      </section>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="font-display text-3xl tabular-nums">{Math.round(value)}</p>
    </div>
  );
}
