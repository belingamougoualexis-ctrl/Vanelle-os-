import {
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
} from "recharts";
import type { TasteProfile } from "@/lib/types";

const LABELS: { key: keyof TasteProfile; label: string }[] = [
  { key: "acide", label: "Acide" },
  { key: "sucre", label: "Sucré" },
  { key: "amer", label: "Amer" },
  { key: "sale", label: "Salé" },
  { key: "umami", label: "Umami" },
  { key: "gras", label: "Gras" },
  { key: "piquant", label: "Piquant" },
];

export function TasteRadar({ taste, size = 260 }: { taste: TasteProfile; size?: number }) {
  const data = LABELS.map((l) => ({ axis: l.label, v: taste[l.key] }));
  return (
    <div className="w-full" style={{ height: size }}>
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={data} cx="50%" cy="50%" outerRadius="72%">
          <PolarGrid stroke="rgba(243,246,244,0.12)" />
          <PolarAngleAxis
            dataKey="axis"
            tick={{ fill: "#8b9c96", fontSize: 11, fontFamily: "Outfit, sans-serif" }}
          />
          <PolarRadiusAxis angle={90} domain={[0, 100]} tick={false} axisLine={false} />
          <Radar dataKey="v" stroke="#1a8f82" fill="#1a8f82" fillOpacity={0.28} strokeWidth={1.6} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function TasteBars({ taste }: { taste: TasteProfile }) {
  return (
    <ul className="grid gap-2.5">
      {LABELS.map((l) => (
        <li key={l.key} className="grid grid-cols-[5.5rem_1fr_2rem] items-center gap-3">
          <span className="text-xs uppercase tracking-wider text-muted-foreground">{l.label}</span>
          <div className="h-1 rounded-full bg-secondary">
            <div className="h-full rounded-full bg-primary" style={{ width: `${taste[l.key]}%` }} />
          </div>
          <span className="text-right font-mono text-xs tabular-nums text-foreground">{taste[l.key]}</span>
        </li>
      ))}
    </ul>
  );
}
