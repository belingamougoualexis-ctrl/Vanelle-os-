import type { ComponentProps } from "react";
import { cn } from "@/lib/utils";

export function Badge({
  className,
  tone = "mute",
  ...props
}: ComponentProps<"span"> & { tone?: "mute" | "ocean" | "porcelain" }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium tracking-wide uppercase",
        tone === "mute" && "bg-secondary text-muted-foreground",
        tone === "ocean" && "bg-primary text-primary-foreground",
        tone === "porcelain" && "bg-porcelain text-ink",
        className,
      )}
      {...props}
    />
  );
}
