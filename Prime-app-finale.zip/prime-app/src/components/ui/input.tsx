import type { ComponentProps } from "react";
import { cn } from "@/lib/utils";

export function Input({ className, ...props }: ComponentProps<"input">) {
  return (
    <input
      className={cn(
        "flex h-11 w-full rounded-md bg-secondary px-3 text-sm text-foreground shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)] outline-none transition-[box-shadow] placeholder:text-muted-foreground focus-visible:shadow-[0_0_0_1px_var(--color-primary)]",
        className,
      )}
      {...props}
    />
  );
}

export function Textarea({ className, ...props }: ComponentProps<"textarea">) {
  return (
    <textarea
      className={cn(
        "flex min-h-28 w-full rounded-lg bg-secondary px-3 py-3 text-sm text-foreground shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)] outline-none placeholder:text-muted-foreground focus-visible:shadow-[0_0_0_1px_var(--color-primary)]",
        className,
      )}
      {...props}
    />
  );
}
