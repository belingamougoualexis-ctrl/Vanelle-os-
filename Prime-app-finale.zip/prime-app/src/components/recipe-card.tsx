import { Link } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { formatMin } from "@/lib/utils";
import type { Recipe } from "@/lib/types";

const DIFF = {
  simple: "Simple",
  intermediaire: "Intermédiaire",
  chef: "Chef",
};

export function RecipeCard({ recipe }: { recipe: Recipe }) {
  return (
    <Link
      to="/recette/$id"
      params={{ id: recipe.id }}
      className="group flex flex-col rounded-2xl bg-card p-5 shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)] transition-[box-shadow,transform] duration-200 hover:shadow-[0_0_0_1px_rgb(26_143_130_/_0.5)]"
    >
      <div className="mb-4 flex items-center justify-between gap-2">
        <Badge>{recipe.origin}</Badge>
        <span className="text-xs tabular-nums text-muted-foreground">{formatMin(recipe.timeMin)}</span>
      </div>
      <h3 className="font-display text-2xl font-medium leading-snug tracking-tight group-hover:text-primary">
        {recipe.title}
      </h3>
      <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-muted-foreground">{recipe.story}</p>
      <div className="mt-5 flex items-center justify-between text-xs uppercase tracking-wider text-muted-foreground">
        <span>{DIFF[recipe.difficulty]}</span>
        <span>{recipe.servings} parts</span>
      </div>
    </Link>
  );
}
