import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={cn("text-primary", className)} fill="none" aria-hidden="true">
      <circle cx="32" cy="34" r="21" stroke="currentColor" strokeWidth="1.7" />
      <circle cx="32" cy="34" r="16" stroke="currentColor" strokeWidth="0.7" opacity="0.45" />
      <path d="M19 15c4 6 8 12 13 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M15.5 11.5c1.8 1.8 3.6 1.8 5.4 0M17 15l-4-4M20 12l-3-4M23 10l-2-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M45 14c-2 7-5 13-11 20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M45 14v16M41.5 14v7M45 30c0 3-2 5-2 7v8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M19 45h26M23 49h18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.7" />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <LogoMark className="size-8" />
      <div className="leading-none">
        <span className="font-display text-[1.45rem] font-semibold tracking-[0.18em] text-foreground">PRIME</span>
        <span className="mt-1 block text-[8px] uppercase tracking-[0.30em] text-primary">L’intelligence au service du goût</span>
      </div>
    </div>
  );
}
