import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "prime-splash-seen";

/** Page d’ouverture élégante — esthétique or / ligne fine, phrasing culinaire */
export function SplashScreen() {
  const [visible, setVisible] = useState(false);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    try {
      if (sessionStorage.getItem(STORAGE_KEY)) return;
    } catch {
      /* ignore */
    }
    setVisible(true);
  }, []);

  function dismiss() {
    setLeaving(true);
    window.setTimeout(() => {
      try {
        sessionStorage.setItem(STORAGE_KEY, "1");
      } catch {
        /* ignore */
      }
      setVisible(false);
    }, 520);
  }

  if (!visible) return null;

  return (
    <button
      type="button"
      aria-label="Entrer dans Prime"
      onClick={dismiss}
      className={cn(
        "fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#f7f4ef] text-[#1a1612] transition-opacity duration-500",
        leaving && "pointer-events-none opacity-0",
      )}
    >
      <div className="relative flex max-w-md flex-col items-center px-8 text-center">
        {/* Motif or — domaine + assiette / herbes (culinaire) */}
        <svg
          viewBox="0 0 320 200"
          className="w-[min(78vw,320px)] text-[#b8954a]"
          fill="none"
          aria-hidden
        >
          {/* Maison / domaine */}
          <path
            d="M48 88 V48 L78 28 L108 48 V88"
            stroke="currentColor"
            strokeWidth="1.4"
            strokeLinejoin="round"
          />
          <path d="M58 88 V62 H98 V88" stroke="currentColor" strokeWidth="1.2" />
          <path d="M72 48 V38" stroke="currentColor" strokeWidth="1.2" />
          <rect x="68" y="68" width="12" height="20" rx="1" stroke="currentColor" strokeWidth="1.1" />
          <path d="M108 58 H148 V88" stroke="currentColor" strokeWidth="1.2" />
          <path d="M118 58 V48 H138 V58" stroke="currentColor" strokeWidth="1.1" />
          <circle cx="42" cy="78" r="10" stroke="currentColor" strokeWidth="1" opacity="0.7" />
          <path d="M42 68 V78 M36 74 H48" stroke="currentColor" strokeWidth="0.9" opacity="0.7" />

          {/* Bouquet herbes / épis à droite */}
          <path d="M210 90 C218 60 235 40 248 28" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
          <path d="M222 88 C228 55 248 38 262 30" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
          <path d="M232 92 C240 65 255 48 270 42" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" />
          <path d="M242 30 C248 22 258 18 268 22" stroke="currentColor" strokeWidth="1" />
          <ellipse cx="255" cy="48" rx="6" ry="10" stroke="currentColor" strokeWidth="1" transform="rotate(-20 255 48)" />
          <ellipse cx="268" cy="55" rx="5" ry="9" stroke="currentColor" strokeWidth="1" transform="rotate(15 268 55)" />
          <path d="M240 70 L248 55 M250 72 L258 58" stroke="currentColor" strokeWidth="0.9" opacity="0.8" />

          {/* Médaillon central : cloche à dôme + feuille */}
          <circle cx="160" cy="118" r="42" stroke="currentColor" strokeWidth="1.6" />
          <circle cx="160" cy="118" r="36" stroke="currentColor" strokeWidth="0.7" opacity="0.45" />
          {/* Cloche de service */}
          <path
            d="M140 128 C140 108 180 108 180 128 L175 128 C175 118 145 118 145 128 Z"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinejoin="round"
          />
          <path d="M148 128 H172" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
          <circle cx="160" cy="106" r="3" stroke="currentColor" strokeWidth="1.2" />
          {/* Feuille / herbe */}
          <path
            d="M168 122 C178 112 188 118 186 128 C176 130 170 126 168 122 Z"
            stroke="currentColor"
            strokeWidth="1.2"
            fill="currentColor"
            fillOpacity="0.12"
          />
          <path d="M168 122 C174 118 180 122 182 126" stroke="currentColor" strokeWidth="0.9" />
        </svg>

        <h1 className="mt-2 font-display text-5xl font-medium tracking-[0.28em] text-[#1a1612] md:text-6xl">
          PRIME
        </h1>
        <p className="mt-4 max-w-xs text-[11px] font-medium uppercase leading-relaxed tracking-[0.28em] text-[#8a7340]">
          L’intelligence au service du goût
        </p>

        <div className="mt-10 flex items-center gap-3 text-[#b8954a]" aria-hidden>
          <svg viewBox="0 0 120 16" className="h-4 w-28" fill="none">
            <path d="M2 10 C20 2 40 14 60 8 C80 2 100 12 118 6" stroke="currentColor" strokeWidth="1" />
            <path d="M10 12 C28 6 48 14 70 10" stroke="currentColor" strokeWidth="0.8" opacity="0.6" />
          </svg>
        </div>

        <p className="mt-8 text-[10px] uppercase tracking-[0.22em] text-[#9a8b72]">Toucher pour entrer</p>
      </div>
    </button>
  );
}
