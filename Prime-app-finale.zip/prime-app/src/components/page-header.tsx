import type { ReactNode } from "react";

export function PageHeader({
  kicker,
  title,
  lede,
  action,
}: {
  kicker: string;
  title: string;
  lede?: string;
  action?: ReactNode;
}) {
  return (
    <header className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="max-w-2xl">
        <p className="mb-2 text-xs font-medium uppercase tracking-[0.22em] text-primary">{kicker}</p>
        <h1 className="font-display text-4xl font-medium leading-tight tracking-tight text-foreground sm:text-5xl">
          {title}
        </h1>
        {lede ? <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground">{lede}</p> : null}
      </div>
      {action}
    </header>
  );
}
