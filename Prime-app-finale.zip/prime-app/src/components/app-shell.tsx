import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { LogoMark, Wordmark } from "@/components/logo";
import { GROUPS, MOBILE_PRIMARY, NAV } from "@/lib/nav";
import { usePrime } from "@/lib/store";
import { cn } from "@/lib/utils";

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);
  const health = usePrime((s) => s.health);
  const nose = usePrime((s) => s.nose);
  const probe = usePrime((s) => s.probe);
  const robot = usePrime((s) => s.robot);
  const tickHealth = usePrime((s) => s.tickHealth);

  useEffect(() => {
    void usePrime.persist.rehydrate();
  }, []);

  useEffect(() => {
    const id = window.setInterval(tickHealth, 8000);
    return () => window.clearInterval(id);
  }, [tickHealth]);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  const live =
    (nose.running && (nose.ready ? "Plat prêt" : "Nez en écoute")) ||
    (probe.running ? "Sonde active" : null) ||
    (robot.running ? "Orchestration" : null);

  return (
    <div className="prime-shell min-h-dvh text-foreground">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-border bg-background md:flex">
        <div className="px-5 py-6">
          <Link to="/" className="block">
            <Wordmark />
          </Link>
          <p className="mt-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Atelier sensoriel</p>
        </div>
        <nav className="flex-1 overflow-y-auto px-3 pb-8">
          {GROUPS.map((g) => (
            <div key={g.id} className="mb-5">
              <p className="mb-1.5 px-2 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{g.label}</p>
              <ul className="grid gap-0.5">
                {NAV.filter((n) => n.group === g.id).map((item) => {
                  const active = pathname === item.to;
                  const Icon = item.icon;
                  return (
                    <li key={item.to}>
                      <Link
                        to={item.to}
                        className={cn(
                          "flex h-10 items-center gap-2.5 rounded-md px-2.5 text-sm transition-colors",
                          active
                            ? "bg-accent text-accent-foreground"
                            : "text-muted-foreground hover:bg-secondary hover:text-foreground",
                        )}
                      >
                        <Icon className="size-4" strokeWidth={1.6} />
                        {item.label}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>
      </aside>

      {open ? (
        <div className="fixed inset-0 z-40 md:hidden">
          <button
            className="absolute inset-0 bg-ink/70"
            aria-label="Fermer le menu"
            onClick={() => setOpen(false)}
          />
          <div className="absolute inset-y-0 left-0 w-72 overflow-y-auto bg-card p-4 shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)]">
            <div className="mb-6 flex items-center justify-between">
              <Wordmark />
              <button className="grid size-11 place-items-center" onClick={() => setOpen(false)} aria-label="Fermer">
                <X className="size-5" />
              </button>
            </div>
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = pathname === item.to;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex h-12 items-center gap-3 rounded-md px-2 text-sm",
                    active ? "bg-accent text-accent-foreground" : "text-muted-foreground",
                  )}
                >
                  <Icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
          </div>
        </div>
      ) : null}

      <div className="md:pl-60">
        <header className="sticky top-0 z-20 flex h-14 items-center justify-between gap-3 border-b border-border bg-background/90 px-4 backdrop-blur-sm md:h-16 md:px-8">
          <div className="flex items-center gap-2 md:hidden">
            <button className="grid size-11 place-items-center" onClick={() => setOpen(true)} aria-label="Menu">
              <Menu className="size-5" />
            </button>
            <Link to="/" className="flex items-center gap-2">
              <LogoMark className="size-7" />
              <span className="font-display text-lg tracking-[0.16em]">PRIME</span>
            </Link>
          </div>
          <div className="hidden items-center gap-3 md:flex">
            {live ? (
              <span className="flex items-center gap-2 text-xs uppercase tracking-[0.16em] text-primary">
                <span className="size-1.5 rounded-full bg-primary ready-pulse" />
                {live}
              </span>
            ) : (
              <span className="text-xs uppercase tracking-[0.16em] text-muted-foreground">PRIME · Intelligence culinaire</span>
            )}
          </div>
          <div className="ml-auto flex items-center gap-3">
            <div className="rounded-full bg-secondary px-3 py-1.5 text-xs tabular-nums">
              <span className="text-muted-foreground">Prime </span>
              <span className="text-foreground">{Math.round(health.glucose)}</span>
              <span className="text-muted-foreground"> mg/dL</span>
            </div>
          </div>
        </header>

        <main className="px-4 py-8 pb-28 md:px-8 md:pb-12">{children}</main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] md:hidden">
        <ul className="grid grid-cols-5">
          {MOBILE_PRIMARY.map((to) => {
            const item = NAV.find((n) => n.to === to)!;
            const Icon = item.icon;
            const active = pathname === to || (to === "/nez" && ["/sonde", "/texture", "/robot"].includes(pathname));
            return (
              <li key={to}>
                <Link
                  to={to}
                  className={cn(
                    "flex h-14 flex-col items-center justify-center gap-1 text-[10px] uppercase tracking-wider",
                    active ? "text-primary" : "text-muted-foreground",
                  )}
                >
                  <Icon className="size-4" strokeWidth={1.6} />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
