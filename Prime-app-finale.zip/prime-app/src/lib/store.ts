import { useMemo } from "react";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import { MACRO_GOALS, SEED_RECIPES } from "./seed";
import { dayStart, emptyNose, emptyProbe, glucoseWalk } from "./sensors";
import type {
  DietaryPreferences,
  HealthState,
  IntakeEntry,
  JournalNote,
  NoseSession,
  ProbeFood,
  ProbeSession,
  Recipe,
  RobotSession,
} from "./types";
import { DEFAULT_DIETARY } from "./types";
import { uid } from "./utils";

type Macros = { kcal: number; prot: number; glucides: number; lipides: number; fibres: number };

type PrimeState = {
  recipes: Recipe[];
  notes: JournalNote[];
  intake: IntakeEntry[];
  health: HealthState;
  region: string;
  dietary: DietaryPreferences;
  nose: NoseSession;
  probe: ProbeSession;
  robot: RobotSession;
  addRecipe: (r: Recipe) => void;
  addNote: (n: Omit<JournalNote, "id" | "at"> & { at?: number }) => void;
  addIntake: (e: Omit<IntakeEntry, "id">) => void;
  setRegion: (r: string) => void;
  setDietary: (p: Partial<DietaryPreferences> | ((d: DietaryPreferences) => DietaryPreferences)) => void;
  toggleDiet: (id: DietaryPreferences["diets"][number]) => void;
  toggleAllergy: (name: string) => void;
  setHealth: (p: Partial<HealthState>) => void;
  tickHealth: () => void;
  setNose: (p: Partial<NoseSession> | ((s: NoseSession) => NoseSession)) => void;
  setProbe: (p: Partial<ProbeSession> | ((s: ProbeSession) => ProbeSession)) => void;
  resetProbe: (food: ProbeFood) => void;
  resetNose: (dish: string) => void;
  setRobot: (p: Partial<RobotSession> | ((s: RobotSession) => RobotSession)) => void;
  resetRobot: () => void;
};

function seedHealth(): HealthState {
  const now = Date.now();
  const cgm = Array.from({ length: 36 }, (_, i) => {
    const t = now - (35 - i) * 5 * 60_000;
    const base = 92 + Math.sin(i / 5) * 10 + (i > 20 ? 8 : 0);
    return { t, v: Math.round(base) };
  });
  return {
    glucose: cgm[cgm.length - 1]?.v ?? 94,
    trend: "stable",
    fatigue: 32,
    sleepH: 7.2,
    cgm,
  };
}

function sumIntake(items: IntakeEntry[]): Macros {
  const start = dayStart();
  return items
    .filter((e) => e.at >= start)
    .reduce(
      (acc, e) => ({
        kcal: acc.kcal + e.nutrition.kcal * e.portion,
        prot: acc.prot + e.nutrition.prot * e.portion,
        glucides: acc.glucides + e.nutrition.glucides * e.portion,
        lipides: acc.lipides + e.nutrition.lipides * e.portion,
        fibres: acc.fibres + e.nutrition.fibres * e.portion,
      }),
      { kcal: 0, prot: 0, glucides: 0, lipides: 0, fibres: 0 },
    );
}

export const usePrime = create<PrimeState>()(
  persist(
    (set, get) => ({
      recipes: SEED_RECIPES,
      notes: [],
      intake: [],
      health: seedHealth(),
      region: "France métropolitaine",
      dietary: { ...DEFAULT_DIETARY },
      nose: emptyNose("tatin"),
      probe: emptyProbe("steak"),
      robot: {
        running: false,
        recipeId: null,
        stepIndex: 0,
        phase: "idle",
        plateC: 28,
        arm: "au repos",
        progress: 0,
        startedAt: null,
        log: [],
      },
      addRecipe: (r) => set({ recipes: [r, ...get().recipes] }),
      addNote: (n) =>
        set({
          notes: [{ id: uid("note"), at: n.at ?? Date.now(), ...n }, ...get().notes],
        }),
      addIntake: (e) => set({ intake: [{ ...e, id: uid("eat") }, ...get().intake] }),
      setRegion: (region) => set({ region }),
      setDietary: (p) =>
        set({
          dietary: typeof p === "function" ? p(get().dietary) : { ...get().dietary, ...p },
        }),
      toggleDiet: (id) => {
        const d = get().dietary;
        const has = d.diets.includes(id);
        set({
          dietary: {
            ...d,
            diets: has ? d.diets.filter((x) => x !== id) : [...d.diets, id],
          },
        });
      },
      toggleAllergy: (name) => {
        const d = get().dietary;
        const key = name.toLowerCase().trim();
        if (!key) return;
        const has = d.allergies.some((a) => a.toLowerCase() === key);
        set({
          dietary: {
            ...d,
            allergies: has
              ? d.allergies.filter((a) => a.toLowerCase() !== key)
              : [...d.allergies, key],
          },
        });
      },
      setHealth: (p) => set({ health: { ...get().health, ...p } }),
      tickHealth: () => {
        const h = get().health;
        const next = glucoseWalk(h.glucose, h.fatigue);
        const trend: HealthState["trend"] = next > h.glucose + 1.2 ? "up" : next < h.glucose - 1.2 ? "down" : "stable";
        const cgm = [...h.cgm, { t: Date.now(), v: Math.round(next) }].slice(-48);
        set({ health: { ...h, glucose: next, trend, cgm } });
      },
      setNose: (p) =>
        set({
          nose: typeof p === "function" ? p(get().nose) : { ...get().nose, ...p },
        }),
      setProbe: (p) =>
        set({
          probe: typeof p === "function" ? p(get().probe) : { ...get().probe, ...p },
        }),
      resetProbe: (food) => set({ probe: emptyProbe(food) }),
      resetNose: (dish) => set({ nose: emptyNose(dish) }),
      setRobot: (p) =>
        set({
          robot: typeof p === "function" ? p(get().robot) : { ...get().robot, ...p },
        }),
      resetRobot: () =>
        set({
          robot: {
            running: false,
            recipeId: null,
            stepIndex: 0,
            phase: "idle",
            plateC: 28,
            arm: "au repos",
            progress: 0,
            startedAt: null,
            log: [],
          },
        }),
    }),
    {
      name: "prime-atelier",
      skipHydration: true,
      partialize: (s) => ({
        recipes: s.recipes,
        notes: s.notes,
        intake: s.intake,
        region: s.region,
        dietary: s.dietary,
        health: { ...s.health, cgm: s.health.cgm.slice(-24) },
      }),
    },
  ),
);

export function useTodayMacros() {
  const intake = usePrime((s) => s.intake);
  return useMemo(() => sumIntake(intake), [intake]);
}

export function useTodayIntake() {
  const intake = usePrime((s) => s.intake);
  return useMemo(() => intake.filter((e) => e.at >= dayStart()), [intake]);
}

export { MACRO_GOALS };
