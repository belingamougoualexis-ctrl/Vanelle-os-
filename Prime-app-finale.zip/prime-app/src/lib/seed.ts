import type { Recipe } from "./types";

/** Aucune recette pré-remplie : tout part de l’utilisateur ou de l’IA en direct (accès internet via API). */
export const SEED_RECIPES: Recipe[] = [];

export const NOSE_DISHES = [
  { id: "tatin", label: "Tarte Tatin", readySec: 148, note: "Caramel ambré, pectine, beurre noisette" },
  { id: "pain", label: "Pain au levain", readySec: 210, note: "Croûte de céréale, Maillard, vapeur d’amidon" },
  { id: "steak", label: "Côte de bœuf", readySec: 132, note: "Pyrazines grillées, sucs, graisse fondue" },
  { id: "sablé", label: "Sablé breton", readySec: 96, note: "Beurre cuisiné, vanille, sucre blond" },
  { id: "oignon", label: "Soupe à l’oignon", readySec: 186, note: "Soufre doux, caramel d’allium" },
];

export const COMPOUNDS = [
  { id: "furaneol", name: "Furaneol", family: "caramel" },
  { id: "diacetyl", name: "Diacétyle", family: "beurre" },
  { id: "pyrazine", name: "Alkyl-pyrazines", family: "grillé" },
  { id: "maltol", name: "Maltol", family: "toasté" },
  { id: "methional", name: "Méthional", family: "rôti" },
  { id: "limonene", name: "Limonène", family: "zeste" },
];

export const PROBE_PRESETS: Record<
  string,
  { label: string; targetC: number; ovenC: number; k: number; rest: string }
> = {
  steak: { label: "Côte de bœuf · saignant", targetC: 53, ovenC: 120, k: 0.018, rest: "Repos 10 min, +3 °C" },
  poulet: { label: "Poulet entier", targetC: 74, ovenC: 180, k: 0.011, rest: "Repos 15 min" },
  porc: { label: "Filet de porc", targetC: 63, ovenC: 160, k: 0.014, rest: "Repos 8 min" },
  saumon: { label: "Pavé de saumon", targetC: 50, ovenC: 180, k: 0.028, rest: "Sortir à 48 °C" },
  pain: { label: "Pain de campagne", targetC: 96, ovenC: 230, k: 0.009, rest: "Croûte 220 °C" },
  tarte: { label: "Tarte fruitée", targetC: 95, ovenC: 190, k: 0.016, rest: "Jus perlé" },
};

export const REGION_PRESETS = [
  "France métropolitaine",
  "Maghreb",
  "Antilles",
  "Afrique de l’Ouest",
  "Québec",
  "Levant",
  "Japon",
  "Mexique",
];

export const MACRO_GOALS = {
  kcal: 2100,
  prot: 110,
  glucides: 220,
  lipides: 70,
  fibres: 30,
};
