import {
  Camera,
  ChefHat,
  HeartPulse,
  Home,
  Languages,
  NotebookPen,
  Radar,
  Sparkles,
  Thermometer,
  UtensilsCrossed,
  Settings2,
  Wind,
  type LucideIcon,
} from "lucide-react";

export type NavItem = {
  to: string;
  label: string;
  hint: string;
  icon: LucideIcon;
  group: "atelier" | "perception" | "creation" | "corps" | "memoire" | "autonomie" | "profil";
};

export const NAV: NavItem[] = [
  { to: "/", label: "Atelier", hint: "Vue d’ensemble", icon: Home, group: "atelier" },
  { to: "/nez", label: "Nez", hint: "Capteur d’odeur", icon: Wind, group: "perception" },
  { to: "/sonde", label: "Sonde", hint: "Température à cœur", icon: Thermometer, group: "perception" },
  { to: "/texture", label: "Texture", hint: "Œil du chef", icon: Camera, group: "perception" },
  { to: "/creer", label: "Inédit", hint: "Recette jamais vue", icon: Sparkles, group: "creation" },
  { to: "/traduire", label: "Traduction", hint: "Âme & terroir", icon: Languages, group: "creation" },
  { to: "/gout", label: "Palais", hint: "Goût avant cuisson", icon: Radar, group: "creation" },
  { to: "/sante", label: "Bio", hint: "Glycémie & fatigue", icon: HeartPulse, group: "corps" },
  { to: "/nutrition", label: "Nutrition", hint: "Journée vivante", icon: UtensilsCrossed, group: "corps" },
  { to: "/journal", label: "Journal", hint: "Mémoire sensorielle", icon: NotebookPen, group: "memoire" },
  { to: "/photo", label: "Scanner", hint: "Plat → nutrition + recette", icon: Camera, group: "memoire" },
  { to: "/robot", label: "Orchestration", hint: "Cuisine autonome", icon: ChefHat, group: "autonomie" },
  { to: "/preferences", label: "Préférences", hint: "Régimes & allergies", icon: Settings2, group: "profil" },
];

export const GROUPS: { id: NavItem["group"]; label: string }[] = [
  { id: "atelier", label: "Maison" },
  { id: "perception", label: "Perception" },
  { id: "creation", label: "IA générative" },
  { id: "corps", label: "Santé" },
  { id: "memoire", label: "Mémoire" },
  { id: "autonomie", label: "Autonomie" },
  { id: "profil", label: "Profil" },
];

export const MOBILE_PRIMARY = ["/", "/photo", "/creer", "/nutrition", "/journal"] as const;
