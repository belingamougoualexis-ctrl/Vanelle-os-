/**
 * Pont vision on-device :
 * 1) Plugin Capacitor TFLite / YOLO (Android natif) si disponible
 * 2) Sinon analyse locale (canvas + règles) — marche toujours dans le navigateur
 */
import { localAnalyzeDishPhoto, localAnalyzeTexture, localSimulateTaste } from "./local-sense";
import type { PhotoResult, TextureResult, TasteProfile } from "./types";

type NativeClassifyResult = {
  label: string;
  confidence: number;
  boxes?: { x: number; y: number; w: number; h: number; label: string; score: number }[];
};

function hasCapacitor(): boolean {
  return typeof window !== "undefined" && !!(window as any).Capacitor?.isNativePlatform?.();
}

async function nativeClassify(imageBase64: string): Promise<NativeClassifyResult | null> {
  try {
    if (!hasCapacitor()) return null;
    const { registerPlugin } = await import("@capacitor/core").catch(() => ({ registerPlugin: null as any }));
    if (!registerPlugin) return null;
    const FoodVision = registerPlugin<{
      classify(options: { imageBase64: string }): Promise<NativeClassifyResult>;
    }>("FoodVision");
    const res = await FoodVision.classify({ imageBase64: imageBase64.replace(/^data:image\/\w+;base64,/, "") });
    if (res?.label) return res; // label + confidence + topK éventuel
  } catch {
    /* plugin absent → fallback */
  }
  return null;
}

/** Texture : natif si dispo, sinon canvas local */
export async function analyzeTextureOnDevice(imageDataUrl: string, question = ""): Promise<TextureResult> {
  // Texture reste locale (rapide, pas besoin du modèle YOLO)
  return localAnalyzeTexture(imageDataUrl, question);
}

/** Photo de plat : TFLite/YOLO natif → sinon couleurs + TheMealDB */
export async function analyzePhotoOnDevice(imageDataUrl: string, hint = ""): Promise<PhotoResult> {
  const native = await nativeClassify(imageDataUrl);
  if (native?.label) {
    const enrichedHint = [hint, native.label].filter(Boolean).join(" ");
    const base = await localAnalyzeDishPhoto(imageDataUrl, enrichedHint || native.label);
    return {
      ...base,
      dish: native.label,
      confidence: Math.round(native.confidence * 100),
      nutritionBasis: `Modèle on-device (TFLite/YOLO) · ${native.label} (${Math.round(native.confidence * 100)} %). Recette structurée via internet gratuit.`,
    };
  }
  return localAnalyzeDishPhoto(imageDataUrl, hint);
}

/** Goût : toujours local (règles + lexique) — marche offline, sans modèle */
export function tasteOnDevice(dish: string, tweaks = "") {
  return localSimulateTaste(dish, tweaks);
}

export type { TasteProfile };
