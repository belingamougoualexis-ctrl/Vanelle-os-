export type TasteProfile = {
  acide: number;
  sucre: number;
  amer: number;
  sale: number;
  umami: number;
  gras: number;
  piquant: number;
};

export type Nutrition = {
  kcal: number;
  prot: number;
  glucides: number;
  lipides: number;
  fibres: number;
  sel: number;
  ig: number;
};

export type Ingredient = {
  name: string;
  qty: string;
  local?: boolean;
  note?: string;
};

export type RecipeStep = {
  n: number;
  text: string;
  durationMin?: number;
  tempC?: number;
  arm?: string;
  induction?: number;
};

export type RecipeSource = "seed" | "generated" | "translated" | "photo" | "adapted";

export type Recipe = {
  id: string;
  title: string;
  origin: string;
  story: string;
  servings: number;
  timeMin: number;
  difficulty: "simple" | "intermediaire" | "chef";
  ingredients: Ingredient[];
  steps: RecipeStep[];
  taste: TasteProfile;
  nutrition: Nutrition;
  tags: string[];
  source: RecipeSource;
  createdAt: number;
  aromaticNote?: string;
};

export type ProbeFood = "steak" | "poulet" | "porc" | "saumon" | "pain" | "tarte";

export type ProbeSession = {
  running: boolean;
  food: ProbeFood;
  targetC: number;
  ovenC: number;
  startC: number;
  startedAt: number | null;
  elapsedSec: number;
  coreC: number;
  predictedRemainSec: number;
  history: { t: number; core: number; predicted: number }[];
};

export type NoseCompound = {
  id: string;
  name: string;
  family: string;
};

export type NoseSession = {
  running: boolean;
  dish: string;
  startedAt: number | null;
  elapsedSec: number;
  ready: boolean;
  readyAt: number | null;
  caramel: number;
  maillard: number;
  doneness: number;
  compounds: Record<string, number>;
  history: { t: number; caramel: number; maillard: number; doneness: number }[];
};

export type JournalNote = {
  id: string;
  at: number;
  transcript: string;
  recipeId?: string;
  recipeTitle?: string;
  tag: "trop-sale" | "trop-fade" | "parfait" | "pas-cuit" | "trop-cuit" | "texture" | "autre";
  adjustment?: string;
};

export type IntakeEntry = {
  id: string;
  at: number;
  label: string;
  recipeId?: string;
  portion: number;
  nutrition: Nutrition;
};

export type HealthState = {
  glucose: number;
  trend: "up" | "stable" | "down";
  fatigue: number;
  sleepH: number;
  cgm: { t: number; v: number }[];
};

export type RobotPhase = "idle" | "preheat" | "cook" | "rest" | "done" | "paused";

export type RobotSession = {
  running: boolean;
  recipeId: string | null;
  stepIndex: number;
  phase: RobotPhase;
  plateC: number;
  arm: string;
  progress: number;
  startedAt: number | null;
  log: { t: number; text: string }[];
};

export type TextureResult = {
  subject: string;
  score: number;
  verdict: string;
  cues: string[];
  nextMove: string;
};

export type VitaminProfile = {
  vitamin: string;
  amount: number;
  unit: string;
  percentDailyValue?: number;
};

export type MineralProfile = {
  mineral: string;
  amount: number;
  unit: string;
  percentDailyValue?: number;
};

export type PhotoResult = {
  dish: string;
  cuisine: string;
  confidence: number;
  portionDescription: string;
  nutritionBasis: string;
  vitamins: VitaminProfile[];
  minerals: MineralProfile[];
  recipe: Recipe;
};

export type PhotoAnalysisResult = PhotoResult;


export type DietFlag =
  | "vegetarien"
  | "vegan"
  | "sans_gluten"
  | "sans_lactose"
  | "halal"
  | "casher"
  | "paleo"
  | "faible_glucides"
  | "faible_sel"
  | "sans_porc"
  | "sans_fruits_de_mer"
  | "sans_oeuf";

export type DietaryPreferences = {
  diets: DietFlag[];
  allergies: string[];
  dislikes: string[];
  notes: string;
};

export const DEFAULT_DIETARY: DietaryPreferences = {
  diets: [],
  allergies: [],
  dislikes: [],
  notes: "",
};

export const DIET_OPTIONS: { id: DietFlag; label: string; hint: string }[] = [
  { id: "vegetarien", label: "Végétarien", hint: "Sans viande ni poisson" },
  { id: "vegan", label: "Végétalien", hint: "Aucun produit animal" },
  { id: "sans_gluten", label: "Sans gluten", hint: "Blé, orge, seigle exclus" },
  { id: "sans_lactose", label: "Sans lactose", hint: "Lait, crème, fromage à limiter" },
  { id: "halal", label: "Halal", hint: "Sans porc, viande conforme" },
  { id: "casher", label: "Casher", hint: "Règles casher de base" },
  { id: "paleo", label: "Paléo", hint: "Peu de céréales / légumineuses" },
  { id: "faible_glucides", label: "Faible en glucides", hint: "Limiter riz, pain, sucre" },
  { id: "faible_sel", label: "Faible en sel", hint: "Assaisonnement doux" },
  { id: "sans_porc", label: "Sans porc", hint: "Porc et charcuterie exclus" },
  { id: "sans_fruits_de_mer", label: "Sans fruits de mer", hint: "Poisson / crustacés exclus" },
  { id: "sans_oeuf", label: "Sans œuf", hint: "Œufs exclus" },
];

export const COMMON_ALLERGENS = [
  "arachide",
  "fruits à coque",
  "soja",
  "sésame",
  "moutarde",
  "céleri",
  "sulfites",
  "poisson",
  "crustacés",
  "lait",
  "œuf",
  "gluten",
];
