import { createServerFn } from "@tanstack/react-start";
import type { MineralProfile, Nutrition, Recipe, TasteProfile, VitaminProfile } from "./types";

type ChatMessage =
  | { role: "system" | "user" | "assistant"; content: string }
  | {
      role: "user";
      content: Array<
        | { type: "text"; text: string }
        | { type: "image_url"; image_url: { url: string; detail?: "low" | "high" } }
      >;
    };

async function grok(messages: ChatMessage[], maxTokens = 1800) {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false as const, error: "L’atelier IA n’est pas disponible pour le moment." };

  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      messages,
      max_tokens: maxTokens,
      temperature: 0.8,
      response_format: { type: "json_object" },
    }),
  });

  if (!res.ok) {
    return { ok: false as const, error: `Atelier indisponible (${res.status}). Réessayez dans un instant.` };
  }

  const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const text = body.choices?.[0]?.message?.content ?? "";
  return { ok: true as const, text };
}

function parseJson<T>(text: string): T {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("Réponse illisible");
  return JSON.parse(text.slice(start, end + 1)) as T;
}

function normalizeRecipe(raw: Partial<Recipe> & { title?: string }, source: Recipe["source"]): Recipe {
  const taste: TasteProfile = {
    acide: Number(raw.taste?.acide ?? 20),
    sucre: Number(raw.taste?.sucre ?? 20),
    amer: Number(raw.taste?.amer ?? 10),
    sale: Number(raw.taste?.sale ?? 30),
    umami: Number(raw.taste?.umami ?? 30),
    gras: Number(raw.taste?.gras ?? 30),
    piquant: Number(raw.taste?.piquant ?? 10),
  };
  const nutrition: Nutrition = {
    kcal: Number(raw.nutrition?.kcal ?? 400),
    prot: Number(raw.nutrition?.prot ?? 15),
    glucides: Number(raw.nutrition?.glucides ?? 30),
    lipides: Number(raw.nutrition?.lipides ?? 18),
    fibres: Number(raw.nutrition?.fibres ?? 3),
    sel: Number(raw.nutrition?.sel ?? 1.2),
    ig: Number(raw.nutrition?.ig ?? 45),
  };
  return {
    id: `ai_${Math.random().toString(36).slice(2, 10)}`,
    title: String(raw.title ?? "Sans titre"),
    origin: String(raw.origin ?? "Inédit"),
    story: String(raw.story ?? ""),
    servings: Number(raw.servings ?? 2),
    timeMin: Number(raw.timeMin ?? 40),
    difficulty: (raw.difficulty as Recipe["difficulty"]) ?? "intermediaire",
    ingredients: Array.isArray(raw.ingredients) ? raw.ingredients : [],
    steps: Array.isArray(raw.steps) ? raw.steps : [],
    taste,
    nutrition,
    tags: Array.isArray(raw.tags) ? raw.tags.map(String) : [],
    source,
    createdAt: Date.now(),
    aromaticNote: raw.aromaticNote ? String(raw.aromaticNote) : undefined,
  };
}

const RECIPE_SHAPE = `JSON strict uniquement :
{
  "title": string (nom précis du plat, style chef),
  "origin": string (région ou tradition culinaire),
  "story": string (2-3 phrases : technique, équilibre, rituel — ton de chef professionnel, jamais marketing),
  "servings": number,
  "timeMin": number (temps total réaliste),
  "difficulty": "simple"|"intermediaire"|"chef",
  "ingredients": [{"name": string, "qty": string (précise : g, ml, c.à.s…), "local": boolean, "note": string?}],
  "steps": [{"n": number, "text": string (geste précis, température, temps, indices sensoriels), "durationMin": number, "tempC": number?, "arm": string?, "induction": number?}],
  "taste": {"acide":0-100,"sucre":0-100,"amer":0-100,"sale":0-100,"umami":0-100,"gras":0-100,"piquant":0-100},
  "nutrition": {"kcal":number,"prot":number,"glucides":number,"lipides":number,"fibres":number,"sel":number,"ig":number},
  "tags": string[],
  "aromaticNote": string (profil aromatique en bouche, ordre d’apparition)
}
Règles chef pro :
- Quantités exactes et techniques de pro (Maillard, confit, nappe, mantecare, etc.)
- Étapes actionnables, avec indices de doneness (couleur, odeur, texture)
- Aucune recette générique ou de blog amateur
- Réponds en français. Pas de markdown. Uniquement le JSON.`;


/** Accès internet gratuit via TheMealDB (clé publique 1) — structure chef pro. */
const MEALDB_BASE = "https://www.themealdb.com/api/json/v1/1";

type MealDBMeal = {
  idMeal: string;
  strMeal: string;
  strCategory: string | null;
  strArea: string | null;
  strInstructions: string | null;
  strTags: string | null;
  [key: string]: string | null;
};

function extractIngredients(meal: MealDBMeal) {
  const out: { name: string; qty: string; local?: boolean }[] = [];
  for (let i = 1; i <= 20; i++) {
    const name = (meal[`strIngredient${i}`] || "").trim();
    const qty = (meal[`strMeasure${i}`] || "").trim();
    if (name) out.push({ name, qty: qty || "selon goût", local: false });
  }
  return out;
}

function parseSteps(instructions: string | null) {
  if (!instructions) return [{ n: 1, text: "Suivre les instructions traditionnelles du plat." }];
  const raw = instructions.replace(/\r\n/g, "\n").split(/\n+/).map((s) => s.trim()).filter(Boolean);
  const steps: { n: number; text: string; durationMin?: number }[] = [];
  let n = 1;
  for (const line of raw) {
    const text = line.replace(/^\d+[\.\)\-\:]\s*/, "").trim();
    if (!text || text.length < 8) continue;
    const minMatch = text.match(/(\d+)\s*(min|minutes?)/i);
    steps.push({ n, text, durationMin: minMatch ? Number(minMatch[1]) : undefined });
    n++;
  }
  if (steps.length === 0) {
    const chunks = instructions.split(/(?<=\.)\s+/).filter((s) => s.trim().length > 15);
    return chunks.slice(0, 12).map((t, i) => ({ n: i + 1, text: t.trim() }));
  }
  return steps;
}

function estimateTime(steps: { durationMin?: number }[], instructions: string | null) {
  const sum = steps.reduce((a, s) => a + (s.durationMin || 0), 0);
  if (sum > 10) return sum;
  const m = (instructions || "").match(/(\d+)\s*(min|minutes?|h|heure)/gi);
  if (m) {
    let t = 0;
    for (const x of m) {
      const n = parseInt(x, 10);
      if (/h|heure/i.test(x)) t += n * 60;
      else t += n;
    }
    if (t > 5) return Math.min(t, 240);
  }
  return Math.max(25, steps.length * 8);
}

function difficultyFromSteps(steps: number, timeMin: number): Recipe["difficulty"] {
  if (steps <= 4 && timeMin < 40) return "simple";
  if (steps >= 9 || timeMin > 90) return "chef";
  return "intermediaire";
}

function roughTaste(category: string | null, area: string | null): TasteProfile {
  const c = (category || "").toLowerCase();
  const a = (area || "").toLowerCase();
  const base = { acide: 25, sucre: 20, amer: 12, sale: 35, umami: 40, gras: 35, piquant: 15 };
  if (c.includes("dessert")) return { ...base, sucre: 75, acide: 30, sale: 10, umami: 8, gras: 45 };
  if (c.includes("seafood") || c.includes("fish")) return { ...base, umami: 55, sale: 45, gras: 28 };
  if (c.includes("beef") || c.includes("lamb") || c.includes("pork")) return { ...base, umami: 65, sale: 40, gras: 50 };
  if (a.includes("indian") || a.includes("thai") || a.includes("mexican")) return { ...base, piquant: 55, umami: 45 };
  return base;
}

function roughNutrition(category: string | null): Nutrition {
  const c = (category || "").toLowerCase();
  let kcal = 420, prot = 18, glucides = 35, lipides = 20, fibres = 4, sel = 1.2, ig = 50;
  if (c.includes("dessert")) { kcal = 380; prot = 6; glucides = 48; lipides = 18; fibres = 2; ig = 60; }
  if (c.includes("vegetarian") || c.includes("vegan")) { kcal = 320; prot = 12; glucides = 42; lipides = 12; fibres = 8; }
  if (c.includes("beef") || c.includes("lamb")) { kcal = 520; prot = 32; glucides = 12; lipides = 35; }
  if (c.includes("seafood")) { kcal = 340; prot = 28; glucides = 15; lipides = 14; }
  return { kcal, prot, glucides, lipides, fibres, sel, ig };
}

function mealToRecipe(meal: MealDBMeal, source: Recipe["source"] = "generated"): Recipe {
  const ingredients = extractIngredients(meal);
  const steps = parseSteps(meal.strInstructions);
  const timeMin = estimateTime(steps, meal.strInstructions);
  const tags = [
    meal.strCategory,
    meal.strArea,
    ...(meal.strTags ? meal.strTags.split(",").map((t) => t.trim()) : []),
  ].filter(Boolean) as string[];
  const story = [
    meal.strArea ? `Tradition ${meal.strArea}` : null,
    meal.strCategory ? `catégorie ${meal.strCategory}` : null,
  ].filter(Boolean).join(" · ");
  return {
    id: `web_${meal.idMeal}_${Math.random().toString(36).slice(2, 6)}`,
    title: meal.strMeal || "Plat du jour",
    origin: meal.strArea || "Cuisine du monde",
    story: story
      ? `${story}. Recette structurée (quantités, étapes, temps) pour cuisine réelle.`
      : "Recette issue d’une base ouverte mondiale, structurée pour la pratique.",
    servings: 4,
    timeMin,
    difficulty: difficultyFromSteps(steps.length, timeMin),
    ingredients,
    steps,
    taste: roughTaste(meal.strCategory, meal.strArea),
    nutrition: roughNutrition(meal.strCategory),
    tags,
    source,
    createdAt: Date.now(),
    aromaticNote: meal.strCategory
      ? `Profil typique ${meal.strCategory}${meal.strArea ? ` · ${meal.strArea}` : ""}.`
      : undefined,
  };
}

async function fetchMealDB(path: string): Promise<MealDBMeal | null> {
  try {
    const res = await fetch(`${MEALDB_BASE}${path}`);
    if (!res.ok) return null;
    const data = (await res.json()) as { meals: MealDBMeal[] | null };
    return data.meals?.[0] ?? null;
  } catch {
    return null;
  }
}

async function searchMealDB(query: string): Promise<MealDBMeal[]> {
  try {
    const q = encodeURIComponent(query.trim().slice(0, 40));
    if (!q) return [];
    const res = await fetch(`${MEALDB_BASE}/search.php?s=${q}`);
    if (!res.ok) return [];
    const data = (await res.json()) as { meals: MealDBMeal[] | null };
    return data.meals ?? [];
  } catch {
    return [];
  }
}

/** Mots-clés de la contrainte → requête internet */
function keywordsFromConstraint(constraint: string, region: string): string[] {
  const stop = new Set(["je", "me", "un", "une", "le", "la", "les", "de", "du", "des", "et", "ou", "pour", "avec", "sans", "qui", "que", "reste", "veux", "plat", "recette", "cuisine", "personne", "vu", "inédit"]);
  const words = constraint
    .toLowerCase()
    .replace(/[^a-zàâäéèêëïîôùûüç0-9\s]/gi, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2 && !stop.has(w));
  const regionWord = region.split(/[\s·,]/)[0]?.trim();
  const out = [...words.slice(0, 4)];
  if (regionWord && regionWord.length > 2) out.push(regionWord);
  return out.length ? out : ["chicken"];
}

export const generateRecipe = createServerFn({ method: "POST" })
  .validator((input: { constraint: string; region: string }) => input)
  .handler(async ({ data }) => {
    // 1) Essai accès internet gratuit (TheMealDB) — structure pro
    const keys = keywordsFromConstraint(data.constraint, data.region);
    let meal: MealDBMeal | null = null;

    for (const k of keys) {
      const found = await searchMealDB(k);
      if (found.length) {
        meal = found[Math.floor(Math.random() * Math.min(found.length, 5))];
        break;
      }
    }
    if (!meal) {
      meal = await fetchMealDB("/random.php");
    }
    if (meal) {
      const recipe = mealToRecipe(meal, "generated");
      // Enrichir un peu le story avec la contrainte
      recipe.story = `Inspiré de « ${data.constraint.slice(0, 80)}${data.constraint.length > 80 ? "…" : ""} » · ${recipe.story}`;
      return { ok: true as const, recipe };
    }

    // 2) Fallback optionnel si clé XAI présente (sinon erreur claire)
    const r = await grok(
      [
        {
          role: "system",
          content: `Tu es un chef professionnel. Invente une recette structurée. ${RECIPE_SHAPE}`,
        },
        {
          role: "user",
          content: `Contrainte : ${data.constraint}\nRégion : ${data.region}`,
        },
      ],
      1800,
    );
    if (!r.ok) {
      return {
        ok: false as const,
        error: "Pas de connexion internet vers la base de recettes, et l’atelier IA n’est pas configuré. Vérifiez l’accès réseau.",
      };
    }
    try {
      return { ok: true as const, recipe: normalizeRecipe(parseJson<Recipe>(r.text), "generated") };
    } catch {
      return { ok: false as const, error: "La recette n’a pas pu être assemblée." };
    }
  });

export const translateRecipe = createServerFn({ method: "POST" })
  .validator((input: { source: string; region: string }) => input)
  .handler(async ({ data }) => {
    // 1) Internet : chercher une variante régionale via TheMealDB
    const regionKey = data.region.split(/[\s·,]/)[0]?.trim() || "French";
    const areaMap: Record<string, string> = {
      France: "French", Maghreb: "Moroccan", Antilles: "Jamaican",
      Québec: "Canadian", Levant: "Egyptian", Japon: "Japanese", Mexique: "Mexican",
      "Afrique": "Kenyan",
    };
    const area = areaMap[regionKey] || regionKey;
    try {
      const res = await fetch(`${MEALDB_BASE}/filter.php?a=${encodeURIComponent(area)}`);
      if (res.ok) {
        const list = (await res.json()) as { meals: { idMeal: string }[] | null };
        const ids = list.meals ?? [];
        if (ids.length) {
          const pick = ids[Math.floor(Math.random() * Math.min(ids.length, 8))];
          const detail = await fetchMealDB(`/lookup.php?i=${pick.idMeal}`);
          if (detail) {
            const recipe = mealToRecipe(detail, "translated");
            recipe.story = `Adaptation pour ${data.region} · ${recipe.story}`;
            return { ok: true as const, recipe };
          }
        }
      }
    } catch { /* continue to AI fallback */ }

    const r = await grok(
      [
        {
          role: "system",
          content: `Tu traduis culturellement une recette : tu gardes l’âme (technique, équilibre, rituel) mais tu remplaces chaque ingrédient introuvable par un équivalent local pertinent. Explique les substitutions dans ingredient.note. ${RECIPE_SHAPE}`,
        },
        {
          role: "user",
          content: `Recette source :\n${data.source}\n\nTerritoire cible : ${data.region}`,
        },
      ],
      2200,
    );
    if (!r.ok) {
      return {
        ok: false as const,
        error: "Impossible de trouver une variante régionale en ligne. Vérifiez l’accès internet.",
      };
    }
    try {
      return { ok: true as const, recipe: normalizeRecipe(parseJson<Recipe>(r.text), "translated") };
    } catch {
      return { ok: false as const, error: "La traduction n’a pas abouti." };
    }
  });

export const simulateTaste = createServerFn({ method: "POST" })
  .validator((input: { dish: string; tweaks?: string }) => input)
  .handler(async ({ data }) => {
    const r = await grok(
      [
        {
          role: "system",
          content: `Tu es un palais entraîné. Tu simules le profil aromatique AVANT cuisson. JSON : {
            "title": string,
            "note": string (paragraphe sensoriel précis, ordre d’apparition des goûts),
            "taste": {"acide":0-100,"sucre":0-100,"amer":0-100,"sale":0-100,"umami":0-100,"gras":0-100,"piquant":0-100},
            "risks": string[],
            "adjustments": string[]
          }`,
        },
        {
          role: "user",
          content: `Plat : ${data.dish}${data.tweaks ? `\nAjustements envisagés : ${data.tweaks}` : ""}`,
        },
      ],
      900,
    );
    if (!r.ok) return r;
    try {
      return { ok: true as const, result: parseJson<{
        title: string;
        note: string;
        taste: TasteProfile;
        risks: string[];
        adjustments: string[];
      }>(r.text) };
    } catch {
      return { ok: false as const, error: "Le palais n’a pas répondu." };
    }
  });

export const analyzeTexture = createServerFn({ method: "POST" })
  .validator((input: { image: string; question: string }) => input)
  .handler(async ({ data }) => {
    const r = await grok(
      [
        {
          role: "system",
          content: `Tu es l’œil d’un chef de partie. Analyse la texture sur la photo (pâte, viande, sauce, pain, légume). JSON : {
            "subject": string,
            "score": 0-100,
            "verdict": string (une phrase),
            "cues": string[] (indices visuels concrets),
            "nextMove": string (geste immédiat)
          }`,
        },
        {
          role: "user",
          content: [
            { type: "text", text: data.question || "Cette texture est-elle à point ?" },
            { type: "image_url", image_url: { url: data.image, detail: "high" } },
          ],
        },
      ],
      700,
    );
    if (!r.ok) return r;
    try {
      return { ok: true as const, result: parseJson<{
        subject: string;
        score: number;
        verdict: string;
        cues: string[];
        nextMove: string;
      }>(r.text) };
    } catch {
      return { ok: false as const, error: "L’œil n’a pas pu lire l’image." };
    }
  });

export const reconstructDish = createServerFn({ method: "POST" })
  .validator((input: { image: string; hint?: string }) => input)
  .handler(async ({ data }) => {
    const r = await grok(
      [
        {
          role: "system",
          content: `Tu reconstruis la recette d’un plat photographié au restaurant. Identifie le plat, la cuisine, puis propose une recette fidèle et cuisinable. ${RECIPE_SHAPE}
Ajoute aussi "dish", "cuisine", "confidence" (0-100) au JSON.`,
        },
        {
          role: "user",
          content: [
            { type: "text", text: data.hint ? `Indice : ${data.hint}` : "Quel est ce plat ? Reconstitue la recette." },
            { type: "image_url", image_url: { url: data.image, detail: "high" } },
          ],
        },
      ],
      2200,
    );
    if (!r.ok) return r;
    try {
      const parsed = parseJson<Recipe & { dish?: string; cuisine?: string; confidence?: number }>(r.text);
      return {
        ok: true as const,
        dish: String(parsed.dish ?? parsed.title),
        cuisine: String(parsed.cuisine ?? parsed.origin),
        confidence: Number(parsed.confidence ?? 70),
        recipe: normalizeRecipe(parsed, "photo"),
      };
    } catch {
      return { ok: false as const, error: "Le plat n’a pas pu être reconnu." };
    }
  });

export const analyzeDishPhoto = createServerFn({ method: "POST" })
  .validator((input: { image: string; hint?: string }) => input)
  .handler(async ({ data }) => {
    const r = await grok(
      [
        {
          role: "system",
          content: `Tu es Prime, un analyste culinaire. À partir d'une photo d'un plat, identifie les éléments visibles, estime une portion réaliste et reconstruis une recette. Donne des valeurs nutritionnelles estimées par portion, jamais présentées comme une mesure médicale ou de laboratoire. Pour les vitamines et minéraux, ne fournis que des valeurs plausibles et indique clairement que ce sont des estimations. Sois très précis sur les ingrédients, quantités, techniques, températures, durées et points de contrôle.
JSON strict : {
  "dish": string,
  "cuisine": string,
  "confidence": 0-100,
  "portionDescription": string,
  "nutritionBasis": string,
  "vitamins": [{"vitamin": string, "amount": number, "unit": string, "percentDailyValue": number}],
  "minerals": [{"mineral": string, "amount": number, "unit": string, "percentDailyValue": number}],
  "recipe": {
    "title": string, "origin": string, "story": string, "servings": number, "timeMin": number,
    "difficulty": "simple"|"intermediaire"|"chef",
    "ingredients": [{"name": string, "qty": string, "local": boolean, "note": string}],
    "steps": [{"n": number, "text": string, "durationMin": number, "tempC": number, "arm": string, "induction": number}],
    "taste": {"acide": number, "sucre": number, "amer": number, "sale": number, "umami": number, "gras": number, "piquant": number},
    "nutrition": {"kcal": number, "prot": number, "glucides": number, "lipides": number, "fibres": number, "sel": number, "ig": number},
    "tags": [string], "aromaticNote": string
  }
}
Réponds en français. Pas de markdown.`,
        },
        {
          role: "user",
          content: [
            { type: "text", text: data.hint ? `Indice utilisateur : ${data.hint}` : "Analyse ce plat photographié avec le maximum de précision possible." },
            { type: "image_url", image_url: { url: data.image, detail: "high" } },
          ],
        },
      ],
      3200,
    );
    if (!r.ok) return r;
    try {
      const raw = parseJson<{
        dish: string;
        cuisine: string;
        confidence: number;
        portionDescription: string;
        nutritionBasis: string;
        vitamins: VitaminProfile[];
        minerals: MineralProfile[];
        recipe: Partial<Recipe>;
      }>(r.text);
      const recipe = normalizeRecipe(raw.recipe ?? {}, "photo");
      return {
        ok: true as const,
        result: {
          dish: String(raw.dish || recipe.title),
          cuisine: String(raw.cuisine || recipe.origin),
          confidence: Number(raw.confidence || 0),
          portionDescription: String(raw.portionDescription || "Estimation d'une portion individuelle."),
          nutritionBasis: String(raw.nutritionBasis || "Estimation visuelle à partir de la portion et des ingrédients supposés."),
          vitamins: Array.isArray(raw.vitamins) ? raw.vitamins : [],
          minerals: Array.isArray(raw.minerals) ? raw.minerals : [],
          recipe,
        },
      };
    } catch {
      return { ok: false as const, error: "L’analyse nutritionnelle n’a pas pu être structurée." };
    }
  });

export const linkVoiceNote = createServerFn({ method: "POST" })
  .validator((input: { transcript: string; recipes: { id: string; title: string }[] }) => input)
  .handler(async ({ data }) => {
    const r = await grok(
      [
        {
          role: "system",
          content: `Tu relies une note de cuisine vocale à une recette existante et proposes un ajustement concret pour la prochaine fois. JSON : {
            "recipeId": string|null,
            "recipeTitle": string|null,
            "tag": "trop-sale"|"trop-fade"|"parfait"|"pas-cuit"|"trop-cuit"|"texture"|"autre",
            "adjustment": string
          }`,
        },
        {
          role: "user",
          content: `Note : "${data.transcript}"\nRecettes : ${data.recipes.map((x) => `${x.id} = ${x.title}`).join(" | ")}`,
        },
      ],
      400,
    );
    if (!r.ok) return r;
    try {
      return { ok: true as const, result: parseJson<{
        recipeId: string | null;
        recipeTitle: string | null;
        tag: "trop-sale" | "trop-fade" | "parfait" | "pas-cuit" | "trop-cuit" | "texture" | "autre";
        adjustment: string;
      }>(r.text) };
    } catch {
      return { ok: false as const, error: "La note n’a pas pu être reliée." };
    }
  });

export const adaptForHealth = createServerFn({ method: "POST" })
  .validator((input: {
    glucose: number;
    fatigue: number;
    eatenKcal: number;
    eatenGlucides: number;
    recipeTitle: string;
    recipeSummary: string;
  }) => input)
  .handler(async ({ data }) => {
    const r = await grok(
      [
        {
          role: "system",
          content: `Tu adaptes une recette au bio-feedback du jour (glycémie, fatigue, ce qui a déjà été mangé). Tu n’es pas un médecin : tu restes culinaire. JSON : {
            "title": string,
            "rationale": string,
            "recipe": {même forme recette},
            "watchouts": string[]
          }\n${RECIPE_SHAPE}`,
        },
        {
          role: "user",
          content: `Glycémie ${data.glucose} mg/dL, fatigue ${data.fatigue}/100, déjà mangé ${data.eatenKcal} kcal dont ${data.eatenGlucides} g de glucides.\nRecette : ${data.recipeTitle}\n${data.recipeSummary}`,
        },
      ],
      2000,
    );
    if (!r.ok) return r;
    try {
      const parsed = parseJson<{ title: string; rationale: string; recipe: Recipe; watchouts: string[] }>(r.text);
      return {
        ok: true as const,
        title: parsed.title,
        rationale: parsed.rationale,
        watchouts: parsed.watchouts ?? [],
        recipe: normalizeRecipe(parsed.recipe ?? parsed, "adapted"),
      };
    } catch {
      return { ok: false as const, error: "L’adaptation n’a pas abouti." };
    }
  });
