import { COMPOUNDS, NOSE_DISHES, PROBE_PRESETS } from "./seed";
import type { NoseSession, ProbeFood, ProbeSession } from "./types";
import { clamp } from "./utils";

export function emptyProbe(food: ProbeFood = "steak"): ProbeSession {
  const p = PROBE_PRESETS[food];
  return {
    running: false,
    food,
    targetC: p.targetC,
    ovenC: p.ovenC,
    startC: 12,
    startedAt: null,
    elapsedSec: 0,
    coreC: 12,
    predictedRemainSec: 0,
    history: [{ t: 0, core: 12, predicted: 12 }],
  };
}

export function tickProbe(s: ProbeSession, dt: number): ProbeSession {
  const p = PROBE_PRESETS[s.food];
  const elapsed = s.elapsedSec + dt;
  const k = p.k;
  const core = s.ovenC - (s.ovenC - s.startC) * Math.exp(-k * elapsed);
  const noise = Math.sin(elapsed * 0.7) * 0.15;
  const coreC = clamp(core + noise, s.startC, s.ovenC);
  const remain = coreC >= s.targetC ? 0 : Math.log((s.ovenC - s.startC) / Math.max(0.2, s.ovenC - s.targetC)) / k - elapsed;
  const predictedRemainSec = Math.max(0, remain);
  const predicted = s.ovenC - (s.ovenC - s.startC) * Math.exp(-k * (elapsed + 1));
  const history = [...s.history, { t: elapsed, core: coreC, predicted }].slice(-240);
  return { ...s, elapsedSec: elapsed, coreC, predictedRemainSec, history };
}

export function emptyNose(dish = "tatin"): NoseSession {
  const compounds: Record<string, number> = {};
  for (const c of COMPOUNDS) compounds[c.id] = 4;
  return {
    running: false,
    dish,
    startedAt: null,
    elapsedSec: 0,
    ready: false,
    readyAt: null,
    caramel: 4,
    maillard: 3,
    doneness: 2,
    compounds,
    history: [{ t: 0, caramel: 4, maillard: 3, doneness: 2 }],
  };
}

function sigmoid(x: number) {
  return 1 / (1 + Math.exp(-x));
}

export function tickNose(s: NoseSession, dt: number): NoseSession {
  const dish = NOSE_DISHES.find((d) => d.id === s.dish) ?? NOSE_DISHES[0];
  const elapsed = s.elapsedSec + dt;
  const peak = dish.readySec;
  const n = elapsed / peak;
  const caramel = clamp(100 * sigmoid((n - 0.72) * 9), 0, 100);
  const maillard = clamp(100 * sigmoid((n - 0.58) * 8), 0, 100);
  const doneness = clamp(100 * sigmoid((n - 0.85) * 11), 0, 100);
  const wobble = 1 + Math.sin(elapsed * 0.35) * 0.04;
  const compounds: Record<string, number> = {
    furaneol: clamp(caramel * 0.92 * wobble, 0, 100),
    diacetyl: clamp(38 + caramel * 0.4 - doneness * 0.15, 0, 100),
    pyrazine: clamp(maillard * 0.88 * wobble, 0, 100),
    maltol: clamp(maillard * 0.7 + caramel * 0.2, 0, 100),
    methional: clamp(maillard * 0.55 + (s.dish === "steak" ? 28 : 8), 0, 100),
    limonene: clamp(12 + Math.sin(elapsed * 0.12) * 6, 0, 40),
  };
  const ready = doneness >= 62 && caramel >= 55;
  const history = [...s.history, { t: elapsed, caramel, maillard, doneness }].slice(-240);
  return {
    ...s,
    elapsedSec: elapsed,
    caramel,
    maillard,
    doneness,
    compounds,
    ready,
    readyAt: ready && !s.ready ? Date.now() : s.readyAt,
    history,
  };
}

export function formatRemain(sec: number) {
  if (sec <= 0) return "0:00";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function glucoseWalk(prev: number, fatigue: number) {
  const drift = (Math.random() - 0.48) * 2.2 + (fatigue - 40) * 0.01;
  return clamp(prev + drift, 68, 168);
}

export function dayStart(ts = Date.now()) {
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}
