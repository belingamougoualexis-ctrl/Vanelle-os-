import type { DietaryPreferences, DietFlag, Recipe } from "./types";
import { DIET_OPTIONS } from "./types";

/** Texte à injecter dans la contrainte de génération / recherche */
export function dietaryConstraintText(d: DietaryPreferences): string {
  const parts: string[] = [];
  for (const id of d.diets) {
    const opt = DIET_OPTIONS.find((o) => o.id === id);
    if (opt) parts.push(opt.label);
  }
  if (d.allergies.length) parts.push(`allergies: ${d.allergies.join(", ")}`);
  if (d.dislikes.length) parts.push(`éviter: ${d.dislikes.join(", ")}`);
  if (d.notes.trim()) parts.push(d.notes.trim());
  return parts.join(" · ");
}

/** Mots-clés TheMealDB / recherche selon régimes */
export function dietarySearchKeywords(d: DietaryPreferences): string[] {
  const keys: string[] = [];
  if (d.diets.includes("vegan") || d.diets.includes("vegetarien")) keys.push("vegetarian");
  if (d.diets.includes("vegan")) keys.push("vegan");
  if (d.diets.includes("sans_gluten")) keys.push("chicken"); // fallback sure - better filter client side
  if (d.diets.includes("faible_glucides")) keys.push("beef");
  return keys;
}

const MEAT = ["bœuf", "boeuf", "beef", "porc", "pork", "agneau", "lamb", "poulet", "chicken", "viande", "bacon", "lard", "saucisse", "jambon", "steak", "dinde", "turkey", "canard", "duck"];
const FISH = ["poisson", "fish", "saumon", "salmon", "thon", "tuna", "crevette", "shrimp", "crabe", "crab", "moule", "mussel", "anchois", "sardine", "seafood"];
const DAIRY = ["lait", "milk", "crème", "cream", "fromage", "cheese", "beurre", "butter", "yaourt", "yogurt", "parmesan"];
const EGG = ["œuf", "oeuf", "egg", "eggs"];
const GLUTEN = ["blé", "wheat", "farine", "flour", "pain", "bread", "pâte", "pasta", "nouille", "noodle", "semoule", "couscous", "orge", "seigle"];
const PORK = ["porc", "pork", "jambon", "bacon", "lard", "saucisse", "chine"];

function textOf(r: Recipe): string {
  return `${r.title} ${r.tags.join(" ")} ${r.ingredients.map((i) => i.name).join(" ")}`.toLowerCase();
}

function hasAny(text: string, words: string[]) {
  return words.some((w) => text.includes(w));
}

/** Filtre local d’une recette selon les préférences */
export function recipeMatchesDietary(r: Recipe, d: DietaryPreferences): boolean {
  const text = textOf(r);

  for (const a of d.allergies) {
    if (a && text.includes(a.toLowerCase())) return false;
  }
  for (const x of d.dislikes) {
    if (x && text.includes(x.toLowerCase())) return false;
  }

  const diets = new Set(d.diets);
  if (diets.has("vegan")) {
    if (hasAny(text, MEAT) || hasAny(text, FISH) || hasAny(text, DAIRY) || hasAny(text, EGG)) return false;
  } else if (diets.has("vegetarien")) {
    if (hasAny(text, MEAT) || hasAny(text, FISH)) return false;
  }
  if (diets.has("sans_gluten") && hasAny(text, GLUTEN)) return false;
  if (diets.has("sans_lactose") && hasAny(text, DAIRY)) return false;
  if (diets.has("sans_oeuf") && hasAny(text, EGG)) return false;
  if ((diets.has("sans_porc") || diets.has("halal") || diets.has("casher")) && hasAny(text, PORK)) return false;
  if (diets.has("sans_fruits_de_mer") && hasAny(text, FISH)) return false;

  return true;
}

export function activeDietLabels(d: DietaryPreferences): string[] {
  return d.diets.map((id) => DIET_OPTIONS.find((o) => o.id === id)?.label ?? id);
}
