# Optimiser le modèle TFLite pour Prime (Android)

## Objectifs

| Variante | Taille | Vitesse | Précision | Idéal pour |
|----------|--------|---------|-----------|------------|
| **FP32** | 100 % | lente | max | debug |
| **Float16** | ~50 % | rapide (GPU) | quasi max | **recommandé** |
| **INT8** | ~25 % | très rapide (CPU/NPU) | -1 à -3 % | bas de gamme |
| **Dynamic** | ~25–40 % | bonne | bonne | compromis |

## 1. Convertir / quantifier (Python)

```bash
pip install tensorflow

# Depuis un modèle Keras
python optimize_model.py --input mon_modele.h5 --output food_model.tflite --quantize float16

# INT8 (téléphones modestes)
python optimize_model.py --input mon_modele.h5 --output food_model.tflite --quantize int8
```

Place le fichier dans :
```
android/app/src/main/assets/food_model.tflite
```

## 2. Optimisations déjà dans le plugin Kotlin

- **GPU delegate** (FP16, sustained speed) si le device le supporte  
- **NNAPI** en secours (NPU/DSP fabricant)  
- **XNNPACK** + multi-thread CPU  
- **Center-crop** avant resize → meilleure précision  
- Détection auto **INT8 vs float**  
- **Top-3** labels renvoyés au JS  

## 3. YOLO vs classification

| Besoin | Modèle | Input | Sortie |
|--------|--------|-------|--------|
| « Quel plat ? » | MobileNet / EfficientNet Food-101 | 224² | 1 label |
| « Où est le plat dans la photo ? » | YOLOv8n-food TFLite | 320–640 | boxes |

Pour YOLO : exporter avec Ultralytics  
```bash
yolo export model=yolov8n.pt format=tflite imgsz=320 int8=True
```
Puis adapter `runFloat` / parsing des boxes dans le plugin.

## 4. Checklist perf

- [ ] Modèle Float16 ou INT8 (pas FP32 en prod)
- [ ] `inputSize` 224 (classif) ou 320 (YOLO nano)
- [ ] Labels alignés sur le modèle (`food_labels.txt`)
- [ ] Image source < 1 Mo côté JS avant base64
- [ ] Tester sur device réel (émulateur ≠ perf GPU)

## 5. Gradle (optimisé)

```gradle
implementation 'org.tensorflow:tensorflow-lite:2.14.0'
implementation 'org.tensorflow:tensorflow-lite-gpu:2.14.0'
implementation 'org.tensorflow:tensorflow-lite-gpu-api:2.14.0'
implementation 'org.tensorflow:tensorflow-lite-support:0.4.4'
```

ProGuard (release) : garder les classes TFLite  
```
-keep class org.tensorflow.lite.** { *; }
```
