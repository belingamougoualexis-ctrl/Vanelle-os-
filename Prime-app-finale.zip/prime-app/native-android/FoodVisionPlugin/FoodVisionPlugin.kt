package app.prime.cuisine.plugins

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.JSObject
import com.getcapacitor.JSArray
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.gpu.GpuDelegate
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min

/**
 * FoodVision — TFLite optimisé on-device
 *
 * Optimisations runtime :
 * - Quantization-aware : accepte float32 / float16 / int8
 * - GPU delegate si compatible, sinon NNAPI, sinon CPU multi-thread
 * - Threads = nombre de cœurs
 * - Prétraitement bitmap in-place, input 224 (MobileNet) configurable
 * - Top-K labels pour fiabilité
 *
 * Assets requis :
 *   android/app/src/main/assets/food_model.tflite  (de préférence INT8 ou Float16)
 *   android/app/src/main/assets/food_labels.txt
 */
@CapacitorPlugin(name = "FoodVision")
class FoodVisionPlugin : Plugin() {

    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private var labels: List<String> = emptyList()
    private var inputSize = 224
    private var isQuantized = false
    private var numThreads = 4

    override fun load() {
        try {
            numThreads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
            labels = context.assets.open("food_labels.txt")
                .bufferedReader()
                .readLines()
                .map { it.trim() }
                .filter { it.isNotBlank() }

            val model = loadModelFile("food_model.tflite")
            val options = Interpreter.Options().apply {
                setNumThreads(numThreads)
                setUseXNNPACK(true) // CPU optimisé
            }

            // 1) GPU si dispo
            val compat = CompatibilityList()
            if (compat.isDelegateSupportedOnThisDevice) {
                val gpuOptions = GpuDelegate.Options().apply {
                    setPrecisionLossAllowed(true) // FP16 côté GPU → plus rapide
                    setInferencePreference(GpuDelegate.Options.INFERENCE_PREFERENCE_SUSTAINED_SPEED)
                }
                gpuDelegate = GpuDelegate(gpuOptions)
                options.addDelegate(gpuDelegate)
            } else {
                // 2) NNAPI (NPU/DSP constructeur) en secours
                options.setUseNNAPI(true)
            }

            interpreter = Interpreter(model, options)

            // Détecter forme d'entrée + quantisation
            val inTensor = interpreter!!.getInputTensor(0)
            val shape = inTensor.shape() // [1, H, W, 3]
            if (shape.size >= 3) {
                inputSize = shape[1]
            }
            isQuantized = inTensor.dataType().toString().contains("UINT8") ||
                inTensor.dataType().toString().contains("INT8")

        } catch (e: Exception) {
            interpreter = null
            gpuDelegate?.close()
            gpuDelegate = null
        }
    }

    override fun handleOnDestroy() {
        interpreter?.close()
        gpuDelegate?.close()
        interpreter = null
        gpuDelegate = null
        super.handleOnDestroy()
    }

    private fun loadModelFile(filename: String): MappedByteBuffer {
        val fd = context.assets.openFd(filename)
        FileInputStream(fd.fileDescriptor).channel.use { channel ->
            return channel.map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        }
    }

    @PluginMethod
    fun classify(call: PluginCall) {
        val b64 = call.getString("imageBase64")
        if (b64.isNullOrBlank()) {
            call.reject("imageBase64 manquant")
            return
        }
        val interp = interpreter
        if (interp == null) {
            call.reject("Modèle TFLite non chargé")
            return
        }

        try {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: run {
                    call.reject("Image invalide")
                    return
                }

            // Center-crop carré puis resize → meilleure précision YOLO/classif
            bmp = centerCropSquare(bmp)
            bmp = Bitmap.createScaledBitmap(bmp, inputSize, inputSize, true)

            val outputScores: FloatArray
            if (isQuantized) {
                outputScores = runQuantized(interp, bmp)
            } else {
                outputScores = runFloat(interp, bmp)
            }

            // Top-3
            val ranked = outputScores.mapIndexed { i, s -> i to s }
                .sortedByDescending { it.second }
                .take(3)

            val best = ranked.first()
            val label = labels.getOrNull(best.first) ?: "unknown"
            val confidence = best.second.toDouble().coerceIn(0.0, 1.0)

            val ret = JSObject()
            ret.put("label", label.replace('_', ' '))
            ret.put("confidence", confidence)

            val topK = JSArray()
            for ((idx, score) in ranked) {
                val o = JSObject()
                o.put("label", (labels.getOrNull(idx) ?: "?").replace('_', ' '))
                o.put("score", score.toDouble())
                topK.put(o)
            }
            ret.put("topK", topK)
            ret.put("boxes", JSArray()) // classification ; YOLO → remplir boxes
            ret.put("backend", if (gpuDelegate != null) "gpu" else "cpu/nnapi")
            ret.put("inputSize", inputSize)
            ret.put("quantized", isQuantized)
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("Erreur TFLite: ${e.message}")
        }
    }

    /** Inference float32 / float16 */
    private fun runFloat(interp: Interpreter, bmp: Bitmap): FloatArray {
        val input = ByteBuffer.allocateDirect(4 * inputSize * inputSize * 3)
        input.order(ByteOrder.nativeOrder())
        val pixels = IntArray(inputSize * inputSize)
        bmp.getPixels(pixels, 0, inputSize, 0, 0, inputSize, inputSize)
        // Normalisation ImageNet-style légère (0–1) — adaptée MobileNet
        for (px in pixels) {
            input.putFloat(((px shr 16) and 0xFF) / 255f)
            input.putFloat(((px shr 8) and 0xFF) / 255f)
            input.putFloat((px and 0xFF) / 255f)
        }
        input.rewind()

        val n = labels.size.coerceAtLeast(1)
        val output = Array(1) { FloatArray(n) }
        interp.run(input, output)
        return softmax(output[0])
    }

    /** Inference INT8 quantifiée (plus rapide, modèle plus petit) */
    private fun runQuantized(interp: Interpreter, bmp: Bitmap): FloatArray {
        val input = ByteBuffer.allocateDirect(inputSize * inputSize * 3)
        input.order(ByteOrder.nativeOrder())
        val pixels = IntArray(inputSize * inputSize)
        bmp.getPixels(pixels, 0, inputSize, 0, 0, inputSize, inputSize)
        for (px in pixels) {
            input.put(((px shr 16) and 0xFF).toByte())
            input.put(((px shr 8) and 0xFF).toByte())
            input.put((px and 0xFF).toByte())
        }
        input.rewind()

        val n = labels.size.coerceAtLeast(1)
        val output = Array(1) { ByteArray(n) }
        interp.run(input, output)

        // Dequantize approximatif si scale non lu — soft scores relatifs
        val floats = FloatArray(n) { i -> (output[0][i].toInt() and 0xFF) / 255f }
        return softmax(floats)
    }

    private fun softmax(logits: FloatArray): FloatArray {
        var max = Float.NEGATIVE_INFINITY
        for (v in logits) if (v > max) max = v
        var sum = 0f
        val exp = FloatArray(logits.size)
        for (i in logits.indices) {
            exp[i] = kotlin.math.exp((logits[i] - max).toDouble()).toFloat()
            sum += exp[i]
        }
        if (sum <= 0f) return logits
        for (i in exp.indices) exp[i] /= sum
        return exp
    }

    private fun centerCropSquare(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val size = min(w, h)
        val x = (w - size) / 2
        val y = (h - size) / 2
        return Bitmap.createBitmap(src, x, y, size, size)
    }
}
