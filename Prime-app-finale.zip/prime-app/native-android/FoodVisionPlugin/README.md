# FoodVision — TFLite / YOLO on-device (Android)

## Installation dans le projet Capacitor

Après `npx cap add android` :

1. Copier `FoodVisionPlugin.kt` vers  
   `android/app/src/main/java/app/prime/cuisine/plugins/FoodVisionPlugin.kt`

2. Enregistrer le plugin dans `MainActivity.java` / `MainActivity.kt` :
   ```kotlin
   registerPlugin(FoodVisionPlugin::class.java)
   ```

3. Dépendances Gradle (`android/app/build.gradle`) :
   ```gradle
   implementation 'org.tensorflow:tensorflow-lite:2.14.0'
   implementation 'org.tensorflow:tensorflow-lite-support:0.4.4'
   ```

4. Assets :
   ```
   android/app/src/main/assets/food_model.tflite   # MobileNet/Food-101 ou YOLOv8n exporté TFLite
   android/app/src/main/assets/food_labels.txt     # une classe par ligne
   ```

5. Rebuild :
   ```bash
   npx cap sync android
   npx cap open android
   ```

## Modèles suggérés (gratuits)

- Classification : [Food-101 MobileNet](https://www.tensorflow.org/lite/models) ou export depuis TensorFlow Hub
- Détection : YOLOv8n entraîné food → export `.tflite` (Ultralytics)

Sans fichier `.tflite`, l’app utilise automatiquement le **fallback local** (couleurs + TheMealDB) : tout reste fonctionnel.
