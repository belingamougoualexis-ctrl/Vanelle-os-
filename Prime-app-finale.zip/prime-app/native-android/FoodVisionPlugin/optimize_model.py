#!/usr/bin/env python3
"""
Optimise un modèle Keras / SavedModel / .tflite existant pour mobile.

Usage :
  pip install tensorflow tensorflow-model-optimization
  python optimize_model.py --input model.h5 --output food_model.tflite --quantize int8
  python optimize_model.py --input food_fp32.tflite --output food_model.tflite --quantize float16

Résultats typiques :
  FP32  ~ 15–40 Mo
  FP16  ~ ½ taille, quasi même précision, plus rapide GPU
  INT8  ~ ¼ taille, très rapide CPU/NPU, légère perte précision
"""

from __future__ import annotations

import argparse
from pathlib import Path


def convert_from_keras(path: Path, quantize: str) -> bytes:
    import tensorflow as tf

    model = tf.keras.models.load_model(str(path))
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    return _apply_quant(converter, quantize)


def convert_from_saved(path: Path, quantize: str) -> bytes:
    import tensorflow as tf

    converter = tf.lite.TFLiteConverter.from_saved_model(str(path))
    return _apply_quant(converter, quantize)


def convert_from_tflite(path: Path, quantize: str) -> bytes:
    """Ré-optimise un .tflite déjà exporté (float16 via converter si possible)."""
    import tensorflow as tf

    # Recharger via concrete n'est pas toujours possible ; pour float16 on préfère
    # repartir du SavedModel. Ici on copie + message si int8 demandé sans dataset.
    data = path.read_bytes()
    if quantize == "none":
        return data
    print(
        "⚠ Ré-quantifier un .tflite existant est limité. "
        "Préférez --input SavedModel ou .h5 pour INT8/FP16."
    )
    return data


def _apply_quant(converter, quantize: str) -> bytes:
    import tensorflow as tf

    converter.optimizations = [tf.lite.Optimize.DEFAULT]

    if quantize == "float16":
        converter.target_spec.supported_types = [tf.float16]
    elif quantize == "int8":
        # Quantization dynamique (pas besoin de dataset représentatif)
        # Pour INT8 full integer, fournir representative_dataset
        converter.target_spec.supported_ops = [
            tf.lite.OpsSet.TFLITE_BUILTINS_INT8,
            tf.lite.OpsSet.TFLITE_BUILTINS,
        ]
        converter.inference_input_type = tf.uint8
        converter.inference_output_type = tf.uint8
        # Dataset factice 224x224 si full-integer demandé
        def rep():
            import numpy as np

            for _ in range(50):
                yield [np.random.rand(1, 224, 224, 3).astype(np.float32)]

        converter.representative_dataset = rep
    # else: DEFAULT = dynamic range quantization

    converter._experimental_lower_tensor_list_ops = False
    tflite_model = converter.convert()
    return tflite_model


def main():
    ap = argparse.ArgumentParser(description="Optimise modèle → TFLite mobile")
    ap.add_argument("--input", required=True, help=".h5 | SavedModel dir | .tflite")
    ap.add_argument("--output", default="food_model.tflite")
    ap.add_argument(
        "--quantize",
        choices=["none", "dynamic", "float16", "int8"],
        default="float16",
        help="float16 recommandé GPU ; int8 recommandé CPU bas de gamme",
    )
    args = ap.parse_args()

    src = Path(args.input)
    if not src.exists():
        raise SystemExit(f"Introuvable: {src}")

    q = args.quantize
    if q == "dynamic":
        q = "none"  # DEFAULT optimization only
        mode = "dynamic"
    else:
        mode = q

    if src.suffix == ".h5" or src.suffix == ".keras":
        data = convert_from_keras(src, mode if mode != "dynamic" else "none")
    elif src.is_dir():
        data = convert_from_saved(src, mode if mode != "dynamic" else "none")
    elif src.suffix == ".tflite":
        data = convert_from_tflite(src, mode)
    else:
        raise SystemExit("Format non supporté (h5, keras, SavedModel, tflite)")

    out = Path(args.output)
    out.write_bytes(data)
    kb = len(data) / 1024
    print(f"✅ Écrit {out} ({kb:.0f} Ko) quantize={args.quantize}")
    print("Copie vers: android/app/src/main/assets/food_model.tflite")


if __name__ == "__main__":
    main()
