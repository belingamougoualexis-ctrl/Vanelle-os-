//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-h1KBc8ZB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/creer",
			"/gout",
			"/journal",
			"/nez",
			"/nutrition",
			"/photo",
			"/robot",
			"/sante",
			"/sonde",
			"/texture",
			"/traduire",
			"/recette/$id"
		],
		preloads: [
			"/assets/index-Cq7YmvdL.js",
			"/assets/utils-Cnenh1K-.js",
			"/assets/invariant-DVltax7q.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cq7YmvdL.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Bts_qynX.js",
			"/assets/card-CZxrTl32.js",
			"/assets/badge-CPFzq370.js",
			"/assets/progress-BnfEQRte.js"
		]
	},
	"/creer": {
		filePath: "/workspace/src/routes/creer.tsx",
		children: void 0,
		preloads: [
			"/assets/creer-DvAKSepJ.js",
			"/assets/ai-CfYnTpLL.js",
			"/assets/page-header-C0RrPFNc.js",
			"/assets/button-BbdEFAMx.js",
			"/assets/card-CZxrTl32.js",
			"/assets/label-DHSub3FH.js",
			"/assets/input-Yr-xUkIN.js"
		]
	},
	"/gout": {
		filePath: "/workspace/src/routes/gout.tsx",
		children: void 0,
		preloads: [
			"/assets/gout-BH38bY3j.js",
			"/assets/ai-CfYnTpLL.js",
			"/assets/page-header-C0RrPFNc.js",
			"/assets/button-BbdEFAMx.js",
			"/assets/card-CZxrTl32.js",
			"/assets/label-DHSub3FH.js",
			"/assets/input-Yr-xUkIN.js",
			"/assets/taste-radar-BiCjnHZ0.js",
			"/assets/badge-CPFzq370.js"
		]
	},
	"/journal": {
		filePath: "/workspace/src/routes/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-kWdxMvgI.js",
			"/assets/ai-CfYnTpLL.js",
			"/assets/page-header-C0RrPFNc.js",
			"/assets/button-BbdEFAMx.js",
			"/assets/card-CZxrTl32.js",
			"/assets/input-Yr-xUkIN.js",
			"/assets/badge-CPFzq370.js"
		]
	},
	"/nez": {
		filePath: "/workspace/src/routes/nez.tsx",
		children: void 0,
		preloads: [
			"/assets/nez-DyF7_GqS.js",
			"/assets/page-header-C0RrPFNc.js",
			"/assets/button-BbdEFAMx.js",
			"/assets/card-CZxrTl32.js",
			"/assets/generateCategoricalChart-B1-ROMcs.js",
			"/assets/YAxis-ruCDPbhF.js",
			"/assets/badge-CPFzq370.js"
		]
	},
	"/nutrition": {
		filePath: "/workspace/src/routes/nutrition.tsx",
		children: void 0,
		preloads: [
			"/assets/nutrition-bQMxzNZh.js",
			"/assets/page-header-C0RrPFNc.js",
			"/assets/button-BbdEFAMx.js",
			"/assets/card-CZxrTl32.js",
			"/assets/progress-BnfEQRte.js"
		]
	},
	"/photo": {
		filePath: "/workspace/src/routes/photo.tsx",
		children: void 0,
		preloads: [
			"/assets/photo-BjUVe0HA.js",
			"/assets/ai-CfYnTpLL.js",
			"/assets/upload-yIovx3Oh.js",
			"/assets/page-header-C0RrPFNc.js",
			"/assets/button-BbdEFAMx.js",
			"/assets/card-CZxrTl32.js",
			"/assets/input-Yr-xUkIN.js",
			"/assets/badge-CPFzq370.js"
		]
	},
	"/robot": {
		filePath: "/workspace/src/routes/robot.tsx",
		children: void 0,
		preloads: [
			"/assets/robot-DkBs1s91.js",
			"/assets/page-header-C0RrPFNc.js",
			"/assets/button-BbdEFAMx.js",
			"/assets/card-CZxrTl32.js",
			"/assets/badge-CPFzq370.js",
			"/assets/progress-BnfEQRte.js"
		]
	},
	"/sante": {
		filePath: "/workspace/src/routes/sante.tsx",
		children: void 0,
		preloads: [
			"/assets/sante-bOmHmn54.js",
			"/assets/ai-CfYnTpLL.js",
			"/assets/page-header-C0RrPFNc.js",
			"/assets/button-BbdEFAMx.js",
			"/assets/card-CZxrTl32.js",
			"/assets/generateCategoricalChart-B1-ROMcs.js",
			"/assets/YAxis-ruCDPbhF.js",
			"/assets/slider-BtqmEP5I.js",
			"/assets/badge-CPFzq370.js"
		]
	},
	"/sonde": {
		filePath: "/workspace/src/routes/sonde.tsx",
		children: void 0,
		preloads: [
			"/assets/sonde-x8TKSKLy.js",
			"/assets/page-header-C0RrPFNc.js",
			"/assets/button-BbdEFAMx.js",
			"/assets/card-CZxrTl32.js",
			"/assets/generateCategoricalChart-B1-ROMcs.js",
			"/assets/YAxis-ruCDPbhF.js",
			"/assets/slider-BtqmEP5I.js",
			"/assets/badge-CPFzq370.js"
		]
	},
	"/texture": {
		filePath: "/workspace/src/routes/texture.tsx",
		children: void 0,
		preloads: [
			"/assets/texture-Bh2Tgj6a.js",
			"/assets/ai-CfYnTpLL.js",
			"/assets/upload-yIovx3Oh.js",
			"/assets/page-header-C0RrPFNc.js",
			"/assets/button-BbdEFAMx.js",
			"/assets/card-CZxrTl32.js",
			"/assets/input-Yr-xUkIN.js",
			"/assets/badge-CPFzq370.js"
		]
	},
	"/traduire": {
		filePath: "/workspace/src/routes/traduire.tsx",
		children: void 0,
		preloads: [
			"/assets/traduire-DTEEXP0o.js",
			"/assets/ai-CfYnTpLL.js",
			"/assets/page-header-C0RrPFNc.js",
			"/assets/button-BbdEFAMx.js",
			"/assets/card-CZxrTl32.js",
			"/assets/label-DHSub3FH.js",
			"/assets/input-Yr-xUkIN.js"
		]
	},
	"/recette/$id": {
		filePath: "/workspace/src/routes/recette.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/recette._id-9JRksga_.js",
			"/assets/button-BbdEFAMx.js",
			"/assets/card-CZxrTl32.js",
			"/assets/taste-radar-BiCjnHZ0.js",
			"/assets/badge-CPFzq370.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
