import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as tickProbe, f as PROBE_PRESETS, h as cn, o as formatRemain, r as useSillage } from "./router-B1GbWoht.mjs";
import { t as PageHeader } from "./page-header-yvGC4AM4.mjs";
import { t as Button } from "./button-BvbbVWOU.mjs";
import { t as Card } from "./card-DWnCgWBa.mjs";
import { a as XAxis, c as ReferenceLine, i as YAxis, m as Tooltip, p as ResponsiveContainer, r as LineChart, s as Line } from "../_libs/recharts+[...].mjs";
import { t as Badge } from "./badge-Cq_6SHsn.mjs";
import { t as Slider } from "./slider-BpPhAY30.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sonde-CH3w3oSi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SondePage() {
	const probe = useSillage((s) => s.probe);
	const setProbe = useSillage((s) => s.setProbe);
	const resetProbe = useSillage((s) => s.resetProbe);
	const preset = PROBE_PRESETS[probe.food];
	const done = probe.coreC >= probe.targetC;
	(0, import_react.useEffect)(() => {
		if (!probe.running) return;
		const id = window.setInterval(() => setProbe((p) => tickProbe(p, 2.2)), 400);
		return () => window.clearInterval(id);
	}, [probe.running, setProbe]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "enter mx-auto max-w-6xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Perception · Thermométrie",
				title: "Le temps qu’il reste, déjà.",
				lede: "Sonde Bluetooth Sillage T-2. La courbe est réelle ; le temps restant est une prédiction newtonienne affinée à chaque seconde.",
				action: probe.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setProbe({ running: false }),
					children: "Pause"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setProbe({
						running: true,
						startedAt: Date.now()
					}),
					children: "Lancer la sonde"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-6 flex flex-wrap gap-2",
				children: Object.keys(PROBE_PRESETS).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => resetProbe(k),
					className: cn("h-10 rounded-full px-4 text-sm", probe.food === k ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
					children: PROBE_PRESETS[k].label.split("·")[0]
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-6 lg:col-span-4",
					children: [
						done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							tone: "ocean",
							children: ["Cible atteinte · ", preset.rest]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Cœur en montée" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-xs uppercase tracking-[0.18em] text-muted-foreground",
							children: "Température à cœur"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-7xl tabular-nums leading-none",
							children: [probe.coreC.toFixed(1), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-3xl text-muted-foreground",
								children: "°"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-sm text-muted-foreground",
							children: [
								"Cible ",
								probe.targetC,
								" °C · four ",
								probe.ovenC,
								" °C"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 font-display text-4xl tabular-nums text-primary",
							children: formatRemain(probe.predictedRemainSec)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wider text-muted-foreground",
							children: "Temps restant prédit"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-3 text-xs uppercase tracking-wider text-muted-foreground",
								children: "Four"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: 80,
								max: 260,
								step: 5,
								value: [probe.ovenC],
								onValueChange: ([v]) => setProbe({ ovenC: v ?? probe.ovenC })
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5 lg:col-span-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-3 text-xs uppercase tracking-[0.16em] text-muted-foreground",
						children: ["Courbe · ", preset.label]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-80",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
								data: probe.history,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "t",
										hide: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										domain: [0, Math.max(probe.ovenC, 100)],
										hide: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReferenceLine, {
										y: probe.targetC,
										stroke: "#1a8f82",
										strokeDasharray: "4 4"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										contentStyle: {
											background: "#0b100f",
											border: "1px solid #1c2a26",
											borderRadius: 12
										},
										formatter: (v) => [`${Number(v).toFixed(1)} °C`, ""]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
										type: "monotone",
										dataKey: "core",
										stroke: "#1a8f82",
										strokeWidth: 2,
										dot: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
										type: "monotone",
										dataKey: "predicted",
										stroke: "#f3f6f4",
										strokeOpacity: .35,
										strokeDasharray: "5 5",
										dot: false
									})
								]
							})
						})
					})]
				})]
			})
		]
	});
}
//#endregion
export { SondePage as component };
