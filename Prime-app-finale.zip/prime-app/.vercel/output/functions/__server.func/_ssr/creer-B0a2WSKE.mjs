import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { h as cn, p as REGION_PRESETS, r as useSillage } from "./router-B1GbWoht.mjs";
import { t as PageHeader } from "./page-header-yvGC4AM4.mjs";
import { t as Button } from "./button-BvbbVWOU.mjs";
import { t as Card } from "./card-DWnCgWBa.mjs";
import { t as Label } from "./label-BfVC8qEA.mjs";
import { n as Textarea } from "./input-BNJ_4Byq.mjs";
import { r as generateRecipe } from "./ai-97EnnJKT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/creer-B0a2WSKE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PROMPTS = [
	"Il me reste du miso, des topinambours et une orange amère. Je veux un plat que personne n’a vu.",
	"Dessert sans chocolat, sans vanille, qui goûte le feu de bois et l’hiver.",
	"Un poisson de rivière, une technique coréenne, des herbes de garrigue.",
	"Petit-déjeuner salé pour une glycémie capricieuse, texture croquante et veloutée."
];
function CreerPage() {
	const navigate = useNavigate();
	const region = useSillage((s) => s.region);
	const setRegion = useSillage((s) => s.setRegion);
	const addRecipe = useSillage((s) => s.addRecipe);
	const [constraint, setConstraint] = (0, import_react.useState)(PROMPTS[0]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function run() {
		if (!constraint.trim()) return;
		setBusy(true);
		const res = await generateRecipe({ data: {
			constraint,
			region
		} });
		setBusy(false);
		if (!res.ok) {
			toast.error(res.error);
			return;
		}
		addRecipe(res.recipe);
		toast.success("Recette inscrite au carnet.");
		navigate({
			to: "/recette/$id",
			params: { id: res.recipe.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "enter mx-auto max-w-3xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "IA générative",
			title: "Jamais vu. Vraiment.",
			lede: "Posez une contrainte improbable. Sillage compose un plat inédit, cuisinable, avec les ingrédients de votre territoire."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "c",
					children: "Contrainte"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "c",
					className: "mt-2 min-h-36 font-display text-xl leading-snug",
					value: constraint,
					onChange: (e) => setConstraint(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: PROMPTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setConstraint(p),
						className: cn("rounded-full px-3 py-1.5 text-left text-xs text-muted-foreground shadow-[0_0_0_1px_rgb(243_246_244_/_0.1)]", constraint === p && "text-primary shadow-[0_0_0_1px_var(--color-primary)]"),
						children: [p.slice(0, 42), "…"]
					}, p))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Territoire" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-2",
						children: REGION_PRESETS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setRegion(r),
							className: cn("h-9 rounded-full px-3 text-xs", region === r ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
							children: r
						}, r))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-8 w-full",
					size: "lg",
					disabled: busy,
					onClick: () => void run(),
					children: busy ? "Le chef imagine…" : "Inventer la recette"
				})
			]
		})]
	});
}
//#endregion
export { CreerPage as component };
