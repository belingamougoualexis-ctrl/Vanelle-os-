import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as Camera, i as Upload } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { g as fileToDataUrl } from "./router-B1GbWoht.mjs";
import { t as PageHeader } from "./page-header-yvGC4AM4.mjs";
import { t as Button } from "./button-BvbbVWOU.mjs";
import { t as Card } from "./card-DWnCgWBa.mjs";
import { t as Input } from "./input-BNJ_4Byq.mjs";
import { n as analyzeTexture } from "./ai-97EnnJKT.mjs";
import { t as Badge } from "./badge-Cq_6SHsn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/texture-CRlJR1sq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TexturePage() {
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [question, setQuestion] = (0, import_react.useState)("La pâte est-elle assez pétrie ? La viande est-elle à point ?");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [result, setResult] = (0, import_react.useState)(null);
	const fileRef = (0, import_react.useRef)(null);
	const videoRef = (0, import_react.useRef)(null);
	const [cam, setCam] = (0, import_react.useState)(false);
	async function onFile(file) {
		const url = await fileToDataUrl(file);
		setPreview(url);
		setResult(null);
	}
	async function startCam() {
		try {
			const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
			if (videoRef.current) {
				videoRef.current.srcObject = stream;
				await videoRef.current.play();
				setCam(true);
			}
		} catch {
			toast.error("Caméra indisponible. Importez une photo.");
		}
	}
	function capture() {
		const video = videoRef.current;
		if (!video) return;
		const canvas = document.createElement("canvas");
		canvas.width = video.videoWidth;
		canvas.height = video.videoHeight;
		canvas.getContext("2d")?.drawImage(video, 0, 0);
		setPreview(canvas.toDataURL("image/jpeg", .72));
		setResult(null);
	}
	async function analyze() {
		if (!preview) return;
		setBusy(true);
		const res = await analyzeTexture({ data: {
			image: preview,
			question
		} });
		setBusy(false);
		if (!res.ok) {
			toast.error(res.error);
			return;
		}
		setResult(res.result);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "enter mx-auto max-w-5xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Perception · Vision",
			title: "Un vrai œil de chef, dans la poche.",
			lede: "Photographiez une pâte, une viande, une sauce. Sillage lit le gluten, le jus, le nappage — et dit le geste suivant."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative aspect-[4/3] bg-secondary",
					children: [preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: preview,
						alt: "Texture à analyser",
						className: "size-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						ref: videoRef,
						className: "size-full object-cover",
						playsInline: true,
						muted: true
					}), !preview && !cam ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 grid place-items-center text-sm text-muted-foreground",
						children: "Viseur en attente"
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => fileRef.current?.click(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {}), " Importer"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: cam ? capture : startCam,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {}),
								" ",
								cam && !preview ? "Capturer" : "Caméra"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "image/*",
							className: "hidden",
							onChange: (e) => {
								const f = e.target.files?.[0];
								if (f) onFile(f);
							}
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs uppercase tracking-[0.16em] text-muted-foreground",
							children: "Question au chef"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: question,
							onChange: (e) => setQuestion(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-4 w-full",
							disabled: !preview || busy,
							onClick: () => void analyze(),
							children: busy ? "Lecture de la matière…" : "Analyser la texture"
						})
					]
				}), result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "ocean",
							children: result.subject
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 font-display text-6xl tabular-nums",
							children: Math.round(result.score)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wider text-muted-foreground",
							children: "Indice de justesse"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 font-display text-2xl italic",
							children: result.verdict
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 grid gap-1.5 text-sm text-muted-foreground",
							children: result.cues.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["— ", c] }, c))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-sm text-primary",
							children: result.nextMove
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "p-6 text-sm text-muted-foreground",
					children: "Pâte assez lisse, mie alvéolée, jus perlé, sauce qui nappe la cuillère : l’œil cherche ces preuves-là."
				})]
			})]
		})]
	});
}
//#endregion
export { TexturePage as component };
