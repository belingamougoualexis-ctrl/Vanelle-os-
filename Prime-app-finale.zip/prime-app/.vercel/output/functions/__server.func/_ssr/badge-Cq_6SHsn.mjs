import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { h as cn } from "./router-B1GbWoht.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-Cq_6SHsn.js
var import_jsx_runtime = require_jsx_runtime();
function Badge({ className, tone = "mute", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium tracking-wide uppercase", tone === "mute" && "bg-secondary text-muted-foreground", tone === "ocean" && "bg-primary text-primary-foreground", tone === "porcelain" && "bg-porcelain text-ink", className),
		...props
	});
}
//#endregion
export { Badge as t };
