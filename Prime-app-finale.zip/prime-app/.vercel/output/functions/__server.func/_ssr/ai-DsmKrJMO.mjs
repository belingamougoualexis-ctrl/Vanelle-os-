import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-DsmKrJMO.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
async function grok(messages, maxTokens = 1800) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "L’atelier IA n’est pas disponible pour le moment."
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			messages,
			max_tokens: maxTokens,
			temperature: .8,
			response_format: { type: "json_object" }
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `Atelier indisponible (${res.status}). Réessayez dans un instant.`
	};
	return {
		ok: true,
		text: (await res.json()).choices?.[0]?.message?.content ?? ""
	};
}
function parseJson(text) {
	const start = text.indexOf("{");
	const end = text.lastIndexOf("}");
	if (start < 0 || end <= start) throw new Error("Réponse illisible");
	return JSON.parse(text.slice(start, end + 1));
}
function normalizeRecipe(raw, source) {
	const taste = {
		acide: Number(raw.taste?.acide ?? 20),
		sucre: Number(raw.taste?.sucre ?? 20),
		amer: Number(raw.taste?.amer ?? 10),
		sale: Number(raw.taste?.sale ?? 30),
		umami: Number(raw.taste?.umami ?? 30),
		gras: Number(raw.taste?.gras ?? 30),
		piquant: Number(raw.taste?.piquant ?? 10)
	};
	const nutrition = {
		kcal: Number(raw.nutrition?.kcal ?? 400),
		prot: Number(raw.nutrition?.prot ?? 15),
		glucides: Number(raw.nutrition?.glucides ?? 30),
		lipides: Number(raw.nutrition?.lipides ?? 18),
		fibres: Number(raw.nutrition?.fibres ?? 3),
		sel: Number(raw.nutrition?.sel ?? 1.2),
		ig: Number(raw.nutrition?.ig ?? 45)
	};
	return {
		id: `ai_${Math.random().toString(36).slice(2, 10)}`,
		title: String(raw.title ?? "Sans titre"),
		origin: String(raw.origin ?? "Inédit"),
		story: String(raw.story ?? ""),
		servings: Number(raw.servings ?? 2),
		timeMin: Number(raw.timeMin ?? 40),
		difficulty: raw.difficulty ?? "intermediaire",
		ingredients: Array.isArray(raw.ingredients) ? raw.ingredients : [],
		steps: Array.isArray(raw.steps) ? raw.steps : [],
		taste,
		nutrition,
		tags: Array.isArray(raw.tags) ? raw.tags.map(String) : [],
		source,
		createdAt: Date.now(),
		aromaticNote: raw.aromaticNote ? String(raw.aromaticNote) : void 0
	};
}
var RECIPE_SHAPE = `JSON strict : {
  "title": string,
  "origin": string,
  "story": string (2-3 phrases, ton de chef, pas de marketing),
  "servings": number,
  "timeMin": number,
  "difficulty": "simple"|"intermediaire"|"chef",
  "ingredients": [{"name": string, "qty": string, "local": boolean, "note": string?}],
  "steps": [{"n": number, "text": string, "durationMin": number, "tempC": number?, "arm": string?, "induction": number?}],
  "taste": {"acide":0-100,"sucre":0-100,"amer":0-100,"sale":0-100,"umami":0-100,"gras":0-100,"piquant":0-100},
  "nutrition": {"kcal":number,"prot":number,"glucides":number,"lipides":number,"fibres":number,"sel":number,"ig":number},
  "tags": string[],
  "aromaticNote": string
}
Réponds en français. Pas de markdown.`;
var generateRecipe_createServerFn_handler = createServerRpc({
	id: "871da0bfcbf05f11e11c7d23834a8efc5dcc38080aa90f0cbfbcba54b166c0a9",
	name: "generateRecipe",
	filename: "src/lib/ai.ts"
}, (opts) => generateRecipe.__executeServer(opts));
var generateRecipe = createServerFn({ method: "POST" }).validator((input) => input).handler(generateRecipe_createServerFn_handler, async ({ data }) => {
	const r = await grok([{
		role: "system",
		content: `Tu es le chef-créateur de Sillage. Tu inventes des recettes 100% inédites, jamais vues, à partir de contraintes improbables. Tu restes praticable en cuisine réelle. ${RECIPE_SHAPE}`
	}, {
		role: "user",
		content: `Contrainte : ${data.constraint}\nIngrédients trouvables : ${data.region}\nInvente un plat que personne n’a écrit. Garde l’âme, pas le pastiche.`
	}], 2200);
	if (!r.ok) return r;
	try {
		return {
			ok: true,
			recipe: normalizeRecipe(parseJson(r.text), "generated")
		};
	} catch {
		return {
			ok: false,
			error: "La recette n’a pas pu être assemblée."
		};
	}
});
var translateRecipe_createServerFn_handler = createServerRpc({
	id: "293464d06fb1460a8c114fa1d75a9096291e236c6d580b062a15f91f01da7f78",
	name: "translateRecipe",
	filename: "src/lib/ai.ts"
}, (opts) => translateRecipe.__executeServer(opts));
var translateRecipe = createServerFn({ method: "POST" }).validator((input) => input).handler(translateRecipe_createServerFn_handler, async ({ data }) => {
	const r = await grok([{
		role: "system",
		content: `Tu traduis culturellement une recette : tu gardes l’âme (technique, équilibre, rituel) mais tu remplaces chaque ingrédient introuvable par un équivalent local pertinent. Explique les substitutions dans ingredient.note. ${RECIPE_SHAPE}`
	}, {
		role: "user",
		content: `Recette source :\n${data.source}\n\nTerritoire cible : ${data.region}`
	}], 2200);
	if (!r.ok) return r;
	try {
		return {
			ok: true,
			recipe: normalizeRecipe(parseJson(r.text), "translated")
		};
	} catch {
		return {
			ok: false,
			error: "La traduction n’a pas abouti."
		};
	}
});
var simulateTaste_createServerFn_handler = createServerRpc({
	id: "dfc05ac40c613e9c22f0eb9b474a3efd84519c90b5e50e2f8bb6028be7a859d7",
	name: "simulateTaste",
	filename: "src/lib/ai.ts"
}, (opts) => simulateTaste.__executeServer(opts));
var simulateTaste = createServerFn({ method: "POST" }).validator((input) => input).handler(simulateTaste_createServerFn_handler, async ({ data }) => {
	const r = await grok([{
		role: "system",
		content: `Tu es un palais entraîné. Tu simules le profil aromatique AVANT cuisson. JSON : {
            "title": string,
            "note": string (paragraphe sensoriel précis, ordre d’apparition des goûts),
            "taste": {"acide":0-100,"sucre":0-100,"amer":0-100,"sale":0-100,"umami":0-100,"gras":0-100,"piquant":0-100},
            "risks": string[],
            "adjustments": string[]
          }`
	}, {
		role: "user",
		content: `Plat : ${data.dish}${data.tweaks ? `\nAjustements envisagés : ${data.tweaks}` : ""}`
	}], 900);
	if (!r.ok) return r;
	try {
		return {
			ok: true,
			result: parseJson(r.text)
		};
	} catch {
		return {
			ok: false,
			error: "Le palais n’a pas répondu."
		};
	}
});
var analyzeTexture_createServerFn_handler = createServerRpc({
	id: "c2969cbc33535fec3c768b3c6ccaec8243e41ace08d91b13a657342ec3de915b",
	name: "analyzeTexture",
	filename: "src/lib/ai.ts"
}, (opts) => analyzeTexture.__executeServer(opts));
var analyzeTexture = createServerFn({ method: "POST" }).validator((input) => input).handler(analyzeTexture_createServerFn_handler, async ({ data }) => {
	const r = await grok([{
		role: "system",
		content: `Tu es l’œil d’un chef de partie. Analyse la texture sur la photo (pâte, viande, sauce, pain, légume). JSON : {
            "subject": string,
            "score": 0-100,
            "verdict": string (une phrase),
            "cues": string[] (indices visuels concrets),
            "nextMove": string (geste immédiat)
          }`
	}, {
		role: "user",
		content: [{
			type: "text",
			text: data.question || "Cette texture est-elle à point ?"
		}, {
			type: "image_url",
			image_url: {
				url: data.image,
				detail: "high"
			}
		}]
	}], 700);
	if (!r.ok) return r;
	try {
		return {
			ok: true,
			result: parseJson(r.text)
		};
	} catch {
		return {
			ok: false,
			error: "L’œil n’a pas pu lire l’image."
		};
	}
});
var reconstructDish_createServerFn_handler = createServerRpc({
	id: "5120c2e8a03c1b170b29f2895649f45466d0661485925a8752411f55f5346f6c",
	name: "reconstructDish",
	filename: "src/lib/ai.ts"
}, (opts) => reconstructDish.__executeServer(opts));
var reconstructDish = createServerFn({ method: "POST" }).validator((input) => input).handler(reconstructDish_createServerFn_handler, async ({ data }) => {
	const r = await grok([{
		role: "system",
		content: `Tu reconstruis la recette d’un plat photographié au restaurant. Identifie le plat, la cuisine, puis propose une recette fidèle et cuisinable. ${RECIPE_SHAPE}
Ajoute aussi "dish", "cuisine", "confidence" (0-100) au JSON.`
	}, {
		role: "user",
		content: [{
			type: "text",
			text: data.hint ? `Indice : ${data.hint}` : "Quel est ce plat ? Reconstitue la recette."
		}, {
			type: "image_url",
			image_url: {
				url: data.image,
				detail: "high"
			}
		}]
	}], 2200);
	if (!r.ok) return r;
	try {
		const parsed = parseJson(r.text);
		return {
			ok: true,
			dish: String(parsed.dish ?? parsed.title),
			cuisine: String(parsed.cuisine ?? parsed.origin),
			confidence: Number(parsed.confidence ?? 70),
			recipe: normalizeRecipe(parsed, "photo")
		};
	} catch {
		return {
			ok: false,
			error: "Le plat n’a pas pu être reconnu."
		};
	}
});
var linkVoiceNote_createServerFn_handler = createServerRpc({
	id: "fd53c9381ed684abe1801a1a0fe01ad54e7563225960c4847907993b0074f7a6",
	name: "linkVoiceNote",
	filename: "src/lib/ai.ts"
}, (opts) => linkVoiceNote.__executeServer(opts));
var linkVoiceNote = createServerFn({ method: "POST" }).validator((input) => input).handler(linkVoiceNote_createServerFn_handler, async ({ data }) => {
	const r = await grok([{
		role: "system",
		content: `Tu relies une note de cuisine vocale à une recette existante et proposes un ajustement concret pour la prochaine fois. JSON : {
            "recipeId": string|null,
            "recipeTitle": string|null,
            "tag": "trop-sale"|"trop-fade"|"parfait"|"pas-cuit"|"trop-cuit"|"texture"|"autre",
            "adjustment": string
          }`
	}, {
		role: "user",
		content: `Note : "${data.transcript}"\nRecettes : ${data.recipes.map((x) => `${x.id} = ${x.title}`).join(" | ")}`
	}], 400);
	if (!r.ok) return r;
	try {
		return {
			ok: true,
			result: parseJson(r.text)
		};
	} catch {
		return {
			ok: false,
			error: "La note n’a pas pu être reliée."
		};
	}
});
var adaptForHealth_createServerFn_handler = createServerRpc({
	id: "2967bc14aa108be5728e9c28a95a0df8d30d6b0c46062848dc09a54daa0dcf26",
	name: "adaptForHealth",
	filename: "src/lib/ai.ts"
}, (opts) => adaptForHealth.__executeServer(opts));
var adaptForHealth = createServerFn({ method: "POST" }).validator((input) => input).handler(adaptForHealth_createServerFn_handler, async ({ data }) => {
	const r = await grok([{
		role: "system",
		content: `Tu adaptes une recette au bio-feedback du jour (glycémie, fatigue, ce qui a déjà été mangé). Tu n’es pas un médecin : tu restes culinaire. JSON : {
            "title": string,
            "rationale": string,
            "recipe": {même forme recette},
            "watchouts": string[]
          }\n${RECIPE_SHAPE}`
	}, {
		role: "user",
		content: `Glycémie ${data.glucose} mg/dL, fatigue ${data.fatigue}/100, déjà mangé ${data.eatenKcal} kcal dont ${data.eatenGlucides} g de glucides.\nRecette : ${data.recipeTitle}\n${data.recipeSummary}`
	}], 2e3);
	if (!r.ok) return r;
	try {
		const parsed = parseJson(r.text);
		return {
			ok: true,
			title: parsed.title,
			rationale: parsed.rationale,
			watchouts: parsed.watchouts ?? [],
			recipe: normalizeRecipe(parsed.recipe ?? parsed, "adapted")
		};
	} catch {
		return {
			ok: false,
			error: "L’adaptation n’a pas abouti."
		};
	}
});
//#endregion
export { adaptForHealth_createServerFn_handler, analyzeTexture_createServerFn_handler, generateRecipe_createServerFn_handler, linkVoiceNote_createServerFn_handler, reconstructDish_createServerFn_handler, simulateTaste_createServerFn_handler, translateRecipe_createServerFn_handler };
