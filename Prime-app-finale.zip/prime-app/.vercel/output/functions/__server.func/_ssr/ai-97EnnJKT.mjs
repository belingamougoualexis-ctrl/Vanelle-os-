import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-97EnnJKT.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var generateRecipe = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("871da0bfcbf05f11e11c7d23834a8efc5dcc38080aa90f0cbfbcba54b166c0a9"));
var translateRecipe = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("293464d06fb1460a8c114fa1d75a9096291e236c6d580b062a15f91f01da7f78"));
var simulateTaste = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("dfc05ac40c613e9c22f0eb9b474a3efd84519c90b5e50e2f8bb6028be7a859d7"));
var analyzeTexture = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("c2969cbc33535fec3c768b3c6ccaec8243e41ace08d91b13a657342ec3de915b"));
var reconstructDish = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("5120c2e8a03c1b170b29f2895649f45466d0661485925a8752411f55f5346f6c"));
var linkVoiceNote = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("fd53c9381ed684abe1801a1a0fe01ad54e7563225960c4847907993b0074f7a6"));
var adaptForHealth = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("2967bc14aa108be5728e9c28a95a0df8d30d6b0c46062848dc09a54daa0dcf26"));
//#endregion
export { reconstructDish as a, linkVoiceNote as i, analyzeTexture as n, simulateTaste as o, generateRecipe as r, translateRecipe as s, adaptForHealth as t };
