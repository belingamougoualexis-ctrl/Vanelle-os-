import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { h as cn } from "./router-B1GbWoht.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/input-BNJ_4Byq.js
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-md bg-secondary px-3 text-sm text-foreground shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)] outline-none transition-[box-shadow] placeholder:text-muted-foreground focus-visible:shadow-[0_0_0_1px_var(--color-primary)]", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-28 w-full rounded-lg bg-secondary px-3 py-3 text-sm text-foreground shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)] outline-none placeholder:text-muted-foreground focus-visible:shadow-[0_0_0_1px_var(--color-primary)]", className),
		...props
	});
}
//#endregion
export { Textarea as n, Input as t };
