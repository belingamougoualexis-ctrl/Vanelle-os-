import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useTodayMacros, i as useTodayIntake, r as useSillage, u as MACRO_GOALS, y as formatTime } from "./router-B1GbWoht.mjs";
import { t as PageHeader } from "./page-header-yvGC4AM4.mjs";
import { t as Button } from "./button-BvbbVWOU.mjs";
import { t as Card } from "./card-DWnCgWBa.mjs";
import { t as Progress } from "./progress-gyYcsKbV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nutrition-iRcGaF94.js
var import_jsx_runtime = require_jsx_runtime();
var KEYS = [
	{
		k: "kcal",
		label: "Énergie",
		unit: "kcal",
		goal: MACRO_GOALS.kcal
	},
	{
		k: "prot",
		label: "Protéines",
		unit: "g",
		goal: MACRO_GOALS.prot
	},
	{
		k: "glucides",
		label: "Glucides",
		unit: "g",
		goal: MACRO_GOALS.glucides
	},
	{
		k: "lipides",
		label: "Lipides",
		unit: "g",
		goal: MACRO_GOALS.lipides
	},
	{
		k: "fibres",
		label: "Fibres",
		unit: "g",
		goal: MACRO_GOALS.fibres
	}
];
function NutritionPage() {
	const recipes = useSillage((s) => s.recipes);
	const addIntake = useSillage((s) => s.addIntake);
	const intake = useTodayIntake();
	const macros = useTodayMacros();
	const remaining = {
		kcal: MACRO_GOALS.kcal - macros.kcal,
		glucides: MACRO_GOALS.glucides - macros.glucides,
		prot: MACRO_GOALS.prot - macros.prot
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "enter mx-auto max-w-5xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Nutrition vivante",
				title: "Pas la recette. La journée.",
				lede: "Les macros se recalculent selon ce que vous avez réellement mangé — portion comprise, pas la fiche isolée."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: KEYS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wider text-muted-foreground",
							children: row.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-sm tabular-nums",
							children: [
								Math.round(macros[row.k]),
								" / ",
								row.goal,
								" ",
								row.unit
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						className: "mt-3",
						value: macros[row.k] / row.goal * 100
					})]
				}, row.k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-6 p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
						children: "Il reste à composer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-display text-3xl",
						children: [
							Math.max(0, Math.round(remaining.kcal)),
							" kcal · ",
							Math.max(0, Math.round(remaining.prot)),
							" g de protéines ·",
							" ",
							Math.max(0, Math.round(remaining.glucides)),
							" g de glucides"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Choisissez le dîner en fonction du réel, pas d’une moyenne."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-4 font-display text-3xl",
					children: "Journal du jour"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-3",
					children: intake.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "p-6 text-sm text-muted-foreground",
						children: "Rien n’a encore été logué aujourd’hui."
					}) : intake.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "flex items-center justify-between p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: e.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								formatTime(e.at),
								" · portion ",
								e.portion.toFixed(1)
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-sm tabular-nums",
							children: [Math.round(e.nutrition.kcal * e.portion), " kcal"]
						})]
					}, e.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-4 font-display text-3xl",
					children: "Logger une recette"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3",
					children: recipes.slice(0, 5).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "flex flex-wrap items-center justify-between gap-3 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/recette/$id",
							params: { id: r.id },
							className: "font-display text-xl hover:text-primary",
							children: r.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => addIntake({
								at: Date.now(),
								label: r.title,
								recipeId: r.id,
								portion: 1,
								nutrition: r.nutrition
							}),
							children: "J’ai mangé ça"
						})]
					}, r.id))
				})]
			})
		]
	});
}
//#endregion
export { NutritionPage as component };
