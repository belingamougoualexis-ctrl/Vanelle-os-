import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { h as cn } from "./router-B1GbWoht.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/progress-gyYcsKbV.js
var import_jsx_runtime = require_jsx_runtime();
function Progress({ value = 0, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("h-1.5 w-full overflow-hidden rounded-full bg-secondary", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full rounded-full bg-primary transition-[width] duration-300 ease-out",
			style: { width: `${Math.min(100, Math.max(0, value))}%` }
		})
	});
}
//#endregion
export { Progress as t };
