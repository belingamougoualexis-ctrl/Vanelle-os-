import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Sparkles, h as HeartPulse, n as Wind, o as Thermometer, v as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { _ as formatDay, a as useTodayMacros, m as LogoMark, r as useSillage, u as MACRO_GOALS, v as formatMin } from "./router-B1GbWoht.mjs";
import { t as Card } from "./card-DWnCgWBa.mjs";
import { t as Badge } from "./badge-Cq_6SHsn.mjs";
import { t as Progress } from "./progress-gyYcsKbV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B5PCvhJZ.js
var import_jsx_runtime = require_jsx_runtime();
var DIFF = {
	simple: "Simple",
	intermediaire: "Intermédiaire",
	chef: "Chef"
};
function RecipeCard({ recipe }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/recette/$id",
		params: { id: recipe.id },
		className: "group flex flex-col rounded-2xl bg-card p-5 shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)] transition-[box-shadow,transform] duration-200 hover:shadow-[0_0_0_1px_rgb(26_143_130_/_0.5)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: recipe.origin }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs tabular-nums text-muted-foreground",
					children: formatMin(recipe.timeMin)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-2xl font-medium leading-snug tracking-tight group-hover:text-primary",
				children: recipe.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 line-clamp-2 text-sm leading-relaxed text-muted-foreground",
				children: recipe.story
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center justify-between text-xs uppercase tracking-wider text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: DIFF[recipe.difficulty] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [recipe.servings, " parts"] })]
			})
		]
	});
}
var PORTALS = [
	{
		to: "/nez",
		icon: Wind,
		kicker: "Perception",
		title: "Nez électronique",
		text: "Caramélisation, Maillard, point de cuisson — sans ouvrir le four."
	},
	{
		to: "/sonde",
		icon: Thermometer,
		kicker: "Précision",
		title: "Sonde à cœur",
		text: "Courbe en direct et temps restant prédit par le modèle thermique."
	},
	{
		to: "/creer",
		icon: Sparkles,
		kicker: "Génération",
		title: "Recette inédite",
		text: "Une contrainte improbable. Un plat que personne n’a écrit."
	},
	{
		to: "/sante",
		icon: HeartPulse,
		kicker: "Bio-feedback",
		title: "Le corps du jour",
		text: "Glycémie, fatigue, et recettes qui s’adaptent vraiment."
	}
];
function Home() {
	const recipes = useSillage((s) => s.recipes);
	const notes = useSillage((s) => s.notes);
	const health = useSillage((s) => s.health);
	const macros = useTodayMacros();
	const greeting = (/* @__PURE__ */ new Date()).getHours() < 12 ? "Le service du matin" : (/* @__PURE__ */ new Date()).getHours() < 18 ? "Le service du jour" : "Le service du soir";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "enter mx-auto max-w-6xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden rounded-2xl bg-card px-6 py-10 shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)] md:px-12 md:py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "pointer-events-none absolute -right-4 -top-6 size-56 text-primary/20 md:size-72" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "relative text-xs uppercase tracking-[0.22em] text-primary",
						children: greeting
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "relative mt-3 max-w-xl font-display text-5xl font-medium leading-[1.05] tracking-tight md:text-6xl",
						children: [
							"Cuisiner avec",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								className: "italic",
								children: "tous les sens."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "relative mt-5 max-w-lg text-sm leading-relaxed text-muted-foreground",
						children: "Sillage est le cerveau de votre cuisine : un nez qui entend le caramel, une sonde qui voit l’avenir d’une cuisson, un palais qui goûte avant le feu."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "relative mt-6 text-xs uppercase tracking-[0.16em] text-muted-foreground",
						children: formatDay(Date.now())
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 grid gap-4 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
								children: "Glycémie"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-4xl tabular-nums",
								children: Math.round(health.glucose)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted-foreground",
								children: ["mg/dL · ", health.trend === "up" ? "en hausse" : health.trend === "down" ? "en baisse" : "stable"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
								children: "Énergie du jour"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-4xl tabular-nums",
								children: Math.round(100 - health.fatigue)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted-foreground",
								children: [
									"sommeil ",
									health.sleepH.toFixed(1),
									" h"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
								children: "Calories restantes"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-4xl tabular-nums",
								children: Math.max(0, Math.round(MACRO_GOALS.kcal - macros.kcal))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
								className: "mt-3",
								value: macros.kcal / MACRO_GOALS.kcal * 100
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-10 grid gap-4 md:grid-cols-2",
				children: PORTALS.map((p) => {
					const Icon = p.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: p.to,
						className: "group flex items-start gap-4 rounded-2xl bg-card p-6 shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)] transition-[box-shadow] hover:shadow-[0_0_0_1px_rgb(26_143_130_/_0.55)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-11 place-items-center rounded-lg bg-secondary text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-5",
									strokeWidth: 1.6
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs uppercase tracking-[0.18em] text-muted-foreground",
										children: p.kicker
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-1 font-display text-2xl font-medium",
										children: p.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-muted-foreground",
										children: p.text
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-primary" })
						]
					}, p.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-5 flex items-end justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "Le carnet"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/creer",
						className: "text-sm text-primary",
						children: "Inventer"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 md:grid-cols-3",
					children: recipes.slice(0, 6).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecipeCard, { recipe: r }, r.id))
				})]
			}),
			notes[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-4 font-display text-3xl",
					children: "Dernière mémoire"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: notes[0].recipeTitle ?? "Note libre" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 font-display text-2xl italic leading-snug",
							children: [
								"« ",
								notes[0].transcript,
								" »"
							]
						}),
						notes[0].adjustment ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-muted-foreground",
							children: ["Prochaine fois — ", notes[0].adjustment]
						}) : null
					]
				})]
			}) : null
		]
	});
}
//#endregion
export { Home as component };
