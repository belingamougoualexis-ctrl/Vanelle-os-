import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PageHeader } from "./page-header-yvGC4AM4.mjs";
import { t as Button } from "./button-BvbbVWOU.mjs";
import { t as Card } from "./card-DWnCgWBa.mjs";
import { t as Label } from "./label-BfVC8qEA.mjs";
import { n as Textarea, t as Input } from "./input-BNJ_4Byq.mjs";
import { o as simulateTaste } from "./ai-97EnnJKT.mjs";
import { n as TasteRadar, t as TasteBars } from "./taste-radar-CHkUGlxO.mjs";
import { t as Badge } from "./badge-Cq_6SHsn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gout-DSAwlAHF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function GoutPage() {
	const [dish, setDish] = (0, import_react.useState)("Côte de bœuf au thym brûlé, jus réduit, pommes grenaille");
	const [tweaks, setTweaks] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [result, setResult] = (0, import_react.useState)(null);
	async function run() {
		setBusy(true);
		const res = await simulateTaste({ data: {
			dish,
			tweaks
		} });
		setBusy(false);
		if (!res.ok) {
			toast.error(res.error);
			return;
		}
		setResult(res.result);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "enter mx-auto max-w-5xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Simulation du goût",
			title: "Goûter avant d’allumer le feu.",
			lede: "Décrivez le plat. Sillage dessine le profil aromatique — acide, umami, amer — et les risques avant que vous ne vous lanciez."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-6 lg:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "dish",
						children: "Plat envisagé"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "dish",
						className: "mt-2",
						value: dish,
						onChange: (e) => setDish(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "tw",
						className: "mt-5 block",
						children: "Ajustements (sel, acidité, cuisson)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "tw",
						className: "mt-2",
						value: tweaks,
						onChange: (e) => setTweaks(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-6 w-full",
						disabled: busy,
						onClick: () => void run(),
						children: busy ? "Le palais cherche…" : "Simuler le goût"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:col-span-3",
				children: result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "ocean",
							children: result.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid gap-6 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TasteRadar, { taste: result.taste }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TasteBars, { taste: result.taste })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 font-display text-xl italic leading-relaxed",
							children: result.note
						}),
						result.risks.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wider text-muted-foreground",
								children: "Risques"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 grid gap-1 text-sm",
								children: result.risks.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["— ", r] }, r))
							})]
						}) : null,
						result.adjustments.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wider text-muted-foreground",
								children: "Avant de se lancer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 grid gap-1 text-sm text-primary",
								children: result.adjustments.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["— ", r] }, r))
							})]
						}) : null
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "grid h-full min-h-72 place-items-center p-8 text-center text-sm text-muted-foreground",
					children: "Le radar restera vide tant que le palais n’a pas été consulté."
				})
			})]
		})]
	});
}
//#endregion
export { GoutPage as component };
