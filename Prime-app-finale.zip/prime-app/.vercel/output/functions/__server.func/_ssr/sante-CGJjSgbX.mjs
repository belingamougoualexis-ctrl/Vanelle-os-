import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useTodayMacros, r as useSillage, y as formatTime } from "./router-B1GbWoht.mjs";
import { t as PageHeader } from "./page-header-yvGC4AM4.mjs";
import { t as Button } from "./button-BvbbVWOU.mjs";
import { t as Card } from "./card-DWnCgWBa.mjs";
import { t as adaptForHealth } from "./ai-97EnnJKT.mjs";
import { a as XAxis, i as YAxis, m as Tooltip, p as ResponsiveContainer, r as LineChart, s as Line } from "../_libs/recharts+[...].mjs";
import { t as Badge } from "./badge-Cq_6SHsn.mjs";
import { t as Slider } from "./slider-BpPhAY30.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sante-CGJjSgbX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SantePage() {
	const health = useSillage((s) => s.health);
	const setHealth = useSillage((s) => s.setHealth);
	const recipes = useSillage((s) => s.recipes);
	const addRecipe = useSillage((s) => s.addRecipe);
	const macros = useTodayMacros();
	const navigate = useNavigate();
	const [busy, setBusy] = (0, import_react.useState)(null);
	const pick = recipes[1] ?? recipes[0];
	const status = health.glucose >= 140 ? "haute" : health.glucose <= 75 ? "basse" : "dans la zone";
	async function adapt(id) {
		const r = recipes.find((x) => x.id === id);
		if (!r) return;
		setBusy(id);
		const res = await adaptForHealth({ data: {
			glucose: Math.round(health.glucose),
			fatigue: health.fatigue,
			eatenKcal: macros.kcal,
			eatenGlucides: macros.glucides,
			recipeTitle: r.title,
			recipeSummary: `${r.story}\n${r.ingredients.map((i) => i.name).join(", ")}`
		} });
		setBusy(null);
		if (!res.ok) {
			toast.error(res.error);
			return;
		}
		addRecipe(res.recipe);
		toast.success(res.title);
		navigate({
			to: "/recette/$id",
			params: { id: res.recipe.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "enter mx-auto max-w-6xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Santé & bio-feedback",
				title: "Cuisiner selon le corps d’aujourd’hui.",
				lede: "Glycémie, fatigue, sommeil. Sillage n’est pas un médecin — il ajuste le menu, pas un diagnostic."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-6 lg:col-span-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							tone: health.glucose >= 140 || health.glucose <= 75 ? "porcelain" : "ocean",
							children: ["Glycémie ", status]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 font-display text-7xl tabular-nums leading-none",
							children: Math.round(health.glucose)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: ["mg/dL · tendance ", health.trend === "up" ? "↑" : health.trend === "down" ? "↓" : "→"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 text-xs uppercase tracking-wider text-muted-foreground",
							children: "Corriger la lecture"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							className: "mt-3",
							min: 70,
							max: 180,
							value: [Math.round(health.glucose)],
							onValueChange: ([v]) => setHealth({ glucose: v ?? health.glucose })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-8 text-xs uppercase tracking-wider text-muted-foreground",
							children: ["Fatigue ", health.fatigue]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							className: "mt-3",
							min: 0,
							max: 100,
							value: [health.fatigue],
							onValueChange: ([v]) => setHealth({ fatigue: v ?? health.fatigue })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5 lg:col-span-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-xs uppercase tracking-[0.16em] text-muted-foreground",
						children: "Courbe capteur · 3 h"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
								data: health.cgm,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "t",
										tickFormatter: (t) => formatTime(Number(t)),
										stroke: "#8b9c96",
										fontSize: 11
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										domain: [60, 180],
										hide: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										contentStyle: {
											background: "#0b100f",
											border: "1px solid #1c2a26",
											borderRadius: 12
										},
										labelFormatter: (t) => formatTime(Number(t)),
										formatter: (v) => [`${v} mg/dL`, ""]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
										type: "monotone",
										dataKey: "v",
										stroke: "#1a8f82",
										strokeWidth: 2,
										dot: false
									})
								]
							})
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-4 font-display text-3xl",
						children: "Adapter une recette"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 md:grid-cols-2",
						children: recipes.slice(0, 4).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "flex items-center justify-between gap-3 p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl",
								children: r.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									"IG ",
									r.nutrition.ig,
									" · ",
									r.nutrition.glucides,
									" g glucides"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								disabled: busy === r.id,
								onClick: () => void adapt(r.id),
								children: busy === r.id ? "…" : "Adapter"
							})]
						}, r.id))
					}),
					pick ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-xs text-muted-foreground",
						children: ["Suggestion du jour : ", health.glucose > 120 ? "privilégier le gras et la protéine, calmer l’amidon." : health.fatigue > 55 ? "un plat simple, peu de pétrissage, beaucoup d’umami." : "vous pouvez vous offrir une cuisson ambitieuse."]
					}) : null
				]
			})
		]
	});
}
//#endregion
export { SantePage as component };
