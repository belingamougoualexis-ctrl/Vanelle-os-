import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { h as cn, p as REGION_PRESETS, r as useSillage } from "./router-B1GbWoht.mjs";
import { t as PageHeader } from "./page-header-yvGC4AM4.mjs";
import { t as Button } from "./button-BvbbVWOU.mjs";
import { t as Card } from "./card-DWnCgWBa.mjs";
import { t as Label } from "./label-BfVC8qEA.mjs";
import { n as Textarea } from "./input-BNJ_4Byq.mjs";
import { s as translateRecipe } from "./ai-97EnnJKT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/traduire-RS_zHELn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SAMPLE = `Mapo tofu
Tofu soyeux, sauce pimentée au poivre de Sichuan, doubanjiang, porc haché, huile de piment, sauce soja, oignon vert.
L’âme du plat : le málà — numbing + piquant — et le tofu qui tremble encore.`;
function TraduirePage() {
	const navigate = useNavigate();
	const region = useSillage((s) => s.region);
	const setRegion = useSillage((s) => s.setRegion);
	const addRecipe = useSillage((s) => s.addRecipe);
	const [source, setSource] = (0, import_react.useState)(SAMPLE);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function run() {
		setBusy(true);
		const res = await translateRecipe({ data: {
			source,
			region
		} });
		setBusy(false);
		if (!res.ok) {
			toast.error(res.error);
			return;
		}
		addRecipe(res.recipe);
		toast.success("Âme conservée, terroir adapté.");
		navigate({
			to: "/recette/$id",
			params: { id: res.recipe.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "enter mx-auto max-w-3xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Traduction culturelle",
			title: "Garder l’âme. Changer le marché.",
			lede: "Collez une recette lointaine. Sillage la réécrit avec ce que l’on trouve ici, sans la vider de son caractère."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "src",
					children: "Recette source"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "src",
					className: "mt-2 min-h-48",
					value: source,
					onChange: (e) => setSource(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Cuisiner comme si l’on était" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-2",
						children: REGION_PRESETS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setRegion(r),
							className: cn("h-9 rounded-full px-3 text-xs", region === r ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
							children: r
						}, r))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-8 w-full",
					size: "lg",
					disabled: busy,
					onClick: () => void run(),
					children: busy ? "Traduction en cours…" : "Traduire vers le local"
				})
			]
		})]
	});
}
//#endregion
export { TraduirePage as component };
