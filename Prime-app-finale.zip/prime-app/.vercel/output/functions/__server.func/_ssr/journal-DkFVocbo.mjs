import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as Mic, s as Square } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { _ as formatDay, r as useSillage, y as formatTime } from "./router-B1GbWoht.mjs";
import { t as PageHeader } from "./page-header-yvGC4AM4.mjs";
import { t as Button } from "./button-BvbbVWOU.mjs";
import { t as Card } from "./card-DWnCgWBa.mjs";
import { n as Textarea } from "./input-BNJ_4Byq.mjs";
import { i as linkVoiceNote } from "./ai-97EnnJKT.mjs";
import { t as Badge } from "./badge-Cq_6SHsn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/journal-DkFVocbo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TAG_LABEL = {
	"trop-sale": "Trop salé",
	"trop-fade": "Trop fade",
	parfait: "Parfait",
	"pas-cuit": "Pas assez cuit",
	"trop-cuit": "Trop cuit",
	texture: "Texture",
	autre: "Note"
};
function JournalPage() {
	const notes = useSillage((s) => s.notes);
	const recipes = useSillage((s) => s.recipes);
	const addNote = useSillage((s) => s.addNote);
	const [text, setText] = (0, import_react.useState)("");
	const [listening, setListening] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const recRef = (0, import_react.useRef)(null);
	function startVoice() {
		const w = window;
		const SR = w.webkitSpeechRecognition ?? w.SpeechRecognition;
		if (!SR) {
			toast.error("Dictée indisponible — écrivez la note.");
			return;
		}
		const rec = new SR();
		rec.lang = "fr-FR";
		rec.interimResults = true;
		rec.onresult = (e) => {
			const t = Array.from(e.results).map((r) => r[0]?.transcript ?? "").join(" ");
			setText(t);
		};
		rec.onend = () => setListening(false);
		recRef.current = rec;
		rec.start();
		setListening(true);
	}
	async function save() {
		if (!text.trim()) return;
		setBusy(true);
		const res = await linkVoiceNote({ data: {
			transcript: text,
			recipes: recipes.slice(0, 12).map((r) => ({
				id: r.id,
				title: r.title
			}))
		} });
		setBusy(false);
		if (!res.ok) {
			addNote({
				transcript: text,
				tag: "autre"
			});
			toast.error(res.error);
			setText("");
			return;
		}
		addNote({
			transcript: text,
			recipeId: res.result.recipeId ?? void 0,
			recipeTitle: res.result.recipeTitle ?? void 0,
			tag: res.result.tag,
			adjustment: res.result.adjustment
		});
		toast.success("Note reliée au carnet.");
		setText("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "enter mx-auto max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Mémoire sensorielle",
				title: "« Trop salé cette fois. »",
				lede: "Une note vocale spontanée. Sillage la rattache à la bonne recette et propose l’ajustement pour la prochaine fois."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: text,
					onChange: (e) => setText(e.target.value),
					placeholder: "Dites-le comme en cuisine — trop cuit, manque d’acidité, mie trop serrée…"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: listening ? "porcelain" : "outline",
						onClick: () => listening ? recRef.current?.stop() : startVoice(),
						children: [listening ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {}), listening ? "Stop" : "Parler"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: busy || !text.trim(),
						onClick: () => void save(),
						children: busy ? "Relier…" : "Enregistrer"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 grid gap-3",
				children: notes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: TAG_LABEL[n.tag] ?? n.tag }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: [
									formatDay(n.at),
									" · ",
									formatTime(n.at)
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 font-display text-2xl italic leading-snug",
							children: [
								"« ",
								n.transcript,
								" »"
							]
						}),
						n.recipeId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/recette/$id",
							params: { id: n.recipeId },
							className: "mt-2 inline-block text-sm text-primary",
							children: n.recipeTitle
						}) : null,
						n.adjustment ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: ["Prochaine fois — ", n.adjustment]
						}) : null
					]
				}, n.id))
			})
		]
	});
}
//#endregion
export { JournalPage as component };
