import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as createRootRoute, b as useRouter, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { _ as Camera, a as TriangleAlert, c as Sparkles, f as Menu, g as ChefHat, h as HeartPulse, l as Radar, m as House, n as Wind, o as Thermometer, p as Languages, r as UtensilsCrossed, t as X, u as NotebookPen } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-CLr7vfbM.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function formatMin(min) {
	if (min < 60) return `${Math.round(min)} min`;
	const h = Math.floor(min / 60);
	const m = Math.round(min % 60);
	return m ? `${h} h ${m}` : `${h} h`;
}
function formatTime(ts) {
	return new Intl.DateTimeFormat("fr-FR", {
		hour: "2-digit",
		minute: "2-digit"
	}).format(ts);
}
function formatDay(ts) {
	return new Intl.DateTimeFormat("fr-FR", {
		weekday: "long",
		day: "numeric",
		month: "long"
	}).format(ts);
}
async function fileToDataUrl(file, maxEdge = 1024, quality = .72) {
	const bitmap = await createImageBitmap(file);
	const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
	const w = Math.max(1, Math.round(bitmap.width * scale));
	const h = Math.max(1, Math.round(bitmap.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Canvas indisponible");
	ctx.drawImage(bitmap, 0, 0, w, h);
	bitmap.close();
	return canvas.toDataURL("image/jpeg", quality);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-B1GbWoht.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function LogoMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className: cn("text-primary", className),
		fill: "none",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "36",
				r: "18",
				stroke: "currentColor",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "36",
				r: "11",
				stroke: "currentColor",
				strokeWidth: "0.8",
				opacity: "0.55"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M32 25c0-6 3.2-11 2-16M28.5 22c-1.2-5 1-10-2.5-14M35.5 22c1.5-5 4.5-8 6-13",
				stroke: "currentColor",
				strokeWidth: "1.3",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M26 38c2.5-4 6-5 6-1.5 0 4-7 3.5-7 8 0 4.5 6 6 11 2",
				stroke: "currentColor",
				strokeWidth: "1.6",
				strokeLinecap: "round"
			})
		]
	});
}
function Wordmark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center gap-2.5", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-[1.35rem] font-medium tracking-[0.18em] text-foreground",
			children: "SILLAGE"
		})]
	});
}
var NAV = [
	{
		to: "/",
		label: "Atelier",
		hint: "Vue d’ensemble",
		icon: House,
		group: "atelier"
	},
	{
		to: "/nez",
		label: "Nez",
		hint: "Capteur d’odeur",
		icon: Wind,
		group: "perception"
	},
	{
		to: "/sonde",
		label: "Sonde",
		hint: "Température à cœur",
		icon: Thermometer,
		group: "perception"
	},
	{
		to: "/texture",
		label: "Texture",
		hint: "Œil du chef",
		icon: Camera,
		group: "perception"
	},
	{
		to: "/creer",
		label: "Inédit",
		hint: "Recette jamais vue",
		icon: Sparkles,
		group: "creation"
	},
	{
		to: "/traduire",
		label: "Traduction",
		hint: "Âme & terroir",
		icon: Languages,
		group: "creation"
	},
	{
		to: "/gout",
		label: "Palais",
		hint: "Goût avant cuisson",
		icon: Radar,
		group: "creation"
	},
	{
		to: "/sante",
		label: "Bio",
		hint: "Glycémie & fatigue",
		icon: HeartPulse,
		group: "corps"
	},
	{
		to: "/nutrition",
		label: "Nutrition",
		hint: "Journée vivante",
		icon: UtensilsCrossed,
		group: "corps"
	},
	{
		to: "/journal",
		label: "Journal",
		hint: "Mémoire sensorielle",
		icon: NotebookPen,
		group: "memoire"
	},
	{
		to: "/photo",
		label: "Cliché",
		hint: "Plat du resto",
		icon: Camera,
		group: "memoire"
	},
	{
		to: "/robot",
		label: "Orchestration",
		hint: "Cuisine autonome",
		icon: ChefHat,
		group: "autonomie"
	}
];
var GROUPS = [
	{
		id: "atelier",
		label: "Maison"
	},
	{
		id: "perception",
		label: "Perception"
	},
	{
		id: "creation",
		label: "IA générative"
	},
	{
		id: "corps",
		label: "Santé"
	},
	{
		id: "memoire",
		label: "Mémoire"
	},
	{
		id: "autonomie",
		label: "Autonomie"
	}
];
var MOBILE_PRIMARY = [
	"/",
	"/nez",
	"/creer",
	"/sante",
	"/journal"
];
var SEED_RECIPES = [
	{
		id: "seed_tatin",
		title: "Tarte Tatin fumée au foin",
		origin: "France · Sologne",
		story: "Les pommes confisent dans un caramel au beurre noisette jusqu’à la limite de l’amertume, puis un voile de foin grillé rappelle le verger après l’orage.",
		servings: 6,
		timeMin: 75,
		difficulty: "intermediaire",
		ingredients: [
			{
				name: "Pommes Reine des Reinettes",
				qty: "6",
				local: true
			},
			{
				name: "Beurre demi-sel",
				qty: "80 g",
				local: true
			},
			{
				name: "Sucre de canne blond",
				qty: "120 g"
			},
			{
				name: "Pâte feuilletée",
				qty: "1 disque"
			},
			{
				name: "Foin de prairie (propre, alimentaire)",
				qty: "une poignée",
				local: true
			},
			{
				name: "Vinaigre de cidre",
				qty: "1 c.à.c",
				local: true
			}
		],
		steps: [
			{
				n: 1,
				text: "Chauffer une plaque à 190 °C. Faire infuser le foin 4 min dans le beurre fondu, filtrer.",
				durationMin: 8,
				tempC: 190,
				induction: 4,
				arm: "infuser"
			},
			{
				n: 2,
				text: "Caraméliser sucre et beurre infusé jusqu’à un ambre profond. Déglacer du vinaigre.",
				durationMin: 8,
				tempC: 175,
				induction: 6,
				arm: "nappé"
			},
			{
				n: 3,
				text: "Ranger les pommes serrées, face bombée vers le fond. Cuire 20 min à découvert.",
				durationMin: 20,
				tempC: 180,
				induction: 5,
				arm: "disposer"
			},
			{
				n: 4,
				text: "Couvrir de pâte, rentrer les bords, enfourner 25 min.",
				durationMin: 25,
				tempC: 190,
				arm: "couvrir"
			},
			{
				n: 5,
				text: "Repos 8 min, démoulage d’un geste. Servir tiède.",
				durationMin: 8,
				arm: "retourner"
			}
		],
		taste: {
			acide: 28,
			sucre: 72,
			amer: 22,
			sale: 18,
			umami: 12,
			gras: 48,
			piquant: 4
		},
		nutrition: {
			kcal: 410,
			prot: 4,
			glucides: 54,
			lipides: 20,
			fibres: 3,
			sel: .6,
			ig: 62
		},
		tags: [
			"dessert",
			"caramel",
			"nez"
		],
		source: "seed",
		createdAt: Date.now() - 3456e5,
		aromaticNote: "Beurre noisette, pomme compotée, foin chaud, acidité de cidre en fin de bouche."
	},
	{
		id: "seed_boeuf",
		title: "Côte de bœuf au thym brûlé",
		origin: "France · Charolais",
		story: "Une pièce épaisse saisie jusqu’à la croûte Maillard, puis conduite à cœur par convection douce. Le thym brûlé parfume la graisse de couverture.",
		servings: 4,
		timeMin: 50,
		difficulty: "simple",
		ingredients: [
			{
				name: "Côte de bœuf Charolaise 6 cm",
				qty: "1,2 kg",
				local: true
			},
			{
				name: "Gros sel de Guérande",
				qty: "12 g",
				local: true
			},
			{
				name: "Poivre noir concassé",
				qty: "4 g"
			},
			{
				name: "Thym frais",
				qty: "1 botte",
				local: true
			},
			{
				name: "Beurre",
				qty: "40 g",
				local: true
			},
			{
				name: "Ail en chemise",
				qty: "4 gousses",
				local: true
			}
		],
		steps: [
			{
				n: 1,
				text: "Tempérer la viande 40 min. Sécher, saler généreusement.",
				durationMin: 40,
				arm: "reposer"
			},
			{
				n: 2,
				text: "Saisir 90 s par face sur plaque à 260 °C jusqu’à croûte sombre.",
				durationMin: 4,
				tempC: 260,
				induction: 9,
				arm: "saisir"
			},
			{
				n: 3,
				text: "Baisser à 120 °C, ajouter beurre, ail, thym. Arroser. Sonde à 53 °C à cœur pour saignant.",
				durationMin: 18,
				tempC: 120,
				induction: 3,
				arm: "arroser"
			},
			{
				n: 4,
				text: "Repos 10 min sous cloche. Trancher dans le sens contraire des fibres.",
				durationMin: 10,
				arm: "trancher"
			}
		],
		taste: {
			acide: 8,
			sucre: 6,
			amer: 14,
			sale: 42,
			umami: 78,
			gras: 62,
			piquant: 18
		},
		nutrition: {
			kcal: 620,
			prot: 48,
			glucides: 1,
			lipides: 47,
			fibres: 0,
			sel: 1.8,
			ig: 0
		},
		tags: [
			"viande",
			"sonde",
			"feu"
		],
		source: "seed",
		createdAt: Date.now() - 1728e5,
		aromaticNote: "Croûte grillée, sucs, thym empyreumatique, beurre noisette, fer du sang à peine perlé."
	},
	{
		id: "seed_levain",
		title: "Pain de campagne au levain de seigle",
		origin: "France · Beauce",
		story: "Un levain jeune, une pâte un peu ferme, un pliage patient. La mie reste humide, la croûte chante en sortant du four.",
		servings: 8,
		timeMin: 1080,
		difficulty: "chef",
		ingredients: [
			{
				name: "Farine T80",
				qty: "400 g",
				local: true
			},
			{
				name: "Farine de seigle T130",
				qty: "100 g",
				local: true
			},
			{
				name: "Levain chef",
				qty: "100 g",
				local: true
			},
			{
				name: "Eau",
				qty: "340 g"
			},
			{
				name: "Sel",
				qty: "10 g",
				local: true
			}
		],
		steps: [
			{
				n: 1,
				text: "Autolyse 30 min (farines + eau). Ajouter levain et sel.",
				durationMin: 30,
				arm: "mélanger"
			},
			{
				n: 2,
				text: "Pétrir jusqu’à fenêtre de gluten souple. 4 series de rabats toutes les 30 min.",
				durationMin: 150,
				arm: "pétrir"
			},
			{
				n: 3,
				text: "Pointage 3 h à 24 °C. Façonnage, apprêt au froid 12 h.",
				durationMin: 720,
				arm: "façonner"
			},
			{
				n: 4,
				text: "Enfourner à 250 °C avec buée, 20 min, puis 220 °C 25 min.",
				durationMin: 45,
				tempC: 250,
				arm: "enfourner"
			}
		],
		taste: {
			acide: 46,
			sucre: 12,
			amer: 18,
			sale: 32,
			umami: 22,
			gras: 6,
			piquant: 2
		},
		nutrition: {
			kcal: 265,
			prot: 9,
			glucides: 52,
			lipides: 1.5,
			fibres: 4,
			sel: 1.1,
			ig: 55
		},
		tags: [
			"pain",
			"texture",
			"fermentation"
		],
		source: "seed",
		createdAt: Date.now() - 5184e5,
		aromaticNote: "Croûte de céréale grillée, mie lactique, seigle, une pointe de miel d’abeille sauvage."
	},
	{
		id: "seed_saumon",
		title: "Saumon miso, céleri nashi",
		origin: "Japon · adapté",
		story: "Le miso blanc caramelise en glaçage laqué. Le céleri-rave et le nashi coupent le gras par un croquant d’eau froide.",
		servings: 2,
		timeMin: 35,
		difficulty: "simple",
		ingredients: [
			{
				name: "Pavés de saumon",
				qty: "2 × 160 g"
			},
			{
				name: "Miso blanc",
				qty: "30 g"
			},
			{
				name: "Mirin",
				qty: "15 g"
			},
			{
				name: "Céleri-rave",
				qty: "200 g",
				local: true
			},
			{
				name: "Nashi ou poire ferme",
				qty: "1",
				local: true
			},
			{
				name: "Citron",
				qty: "1/2",
				local: true
			}
		],
		steps: [
			{
				n: 1,
				text: "Mélanger miso et mirin. Napper le saumon. Repos 12 min.",
				durationMin: 12,
				arm: "nappé"
			},
			{
				n: 2,
				text: "Julienne de céleri et nashi, citron, sel. Réserver au froid.",
				durationMin: 8,
				arm: "couper"
			},
			{
				n: 3,
				text: "Cuire le saumon peau vers le bas 6 min, glacer 2 min à 180 °C.",
				durationMin: 8,
				tempC: 180,
				induction: 5,
				arm: "glacer"
			}
		],
		taste: {
			acide: 34,
			sucre: 38,
			amer: 10,
			sale: 44,
			umami: 70,
			gras: 52,
			piquant: 6
		},
		nutrition: {
			kcal: 430,
			prot: 34,
			glucides: 14,
			lipides: 26,
			fibres: 3,
			sel: 2.1,
			ig: 28
		},
		tags: [
			"poisson",
			"umami",
			"sante"
		],
		source: "seed",
		createdAt: Date.now() - 864e5,
		aromaticNote: "Miso toasté, peau craquante, poire d’eau, céleri cru, gras du saumon encore nacre."
	},
	{
		id: "seed_risotto",
		title: "Risotto aux cèpes et thé fumé",
		origin: "Italie · Piémont",
		story: "Le riz s’abreuve d’un bouillon de cèpes. Un trait de thé lapsang en fin de cuisson donne l’impression d’un feu de camp sous les pins.",
		servings: 4,
		timeMin: 40,
		difficulty: "intermediaire",
		ingredients: [
			{
				name: "Riz carnaroli",
				qty: "280 g"
			},
			{
				name: "Cèpes frais ou réhydratés",
				qty: "250 g",
				local: true
			},
			{
				name: "Échalotes",
				qty: "2",
				local: true
			},
			{
				name: "Bouillon de volaille",
				qty: "1 L",
				local: true
			},
			{
				name: "Parmesan 24 mois",
				qty: "60 g"
			},
			{
				name: "Thé lapsang souchong",
				qty: "1 c.à.c"
			},
			{
				name: "Beurre",
				qty: "40 g",
				local: true
			}
		],
		steps: [
			{
				n: 1,
				text: "Infuser le thé 3 min dans 80 ml de bouillon, filtrer.",
				durationMin: 4,
				arm: "infuser"
			},
			{
				n: 2,
				text: "Suer échalotes, nacrer le riz, déglacer. Ajouter le bouillon louche à louche.",
				durationMin: 18,
				tempC: 95,
				induction: 4,
				arm: "nacrer"
			},
			{
				n: 3,
				text: "Incorporer cèpes rôtis, thé fumé, beurre et parmesan. Mantecare hors du feu.",
				durationMin: 6,
				arm: "mantecare"
			}
		],
		taste: {
			acide: 12,
			sucre: 10,
			amer: 16,
			sale: 40,
			umami: 82,
			gras: 46,
			piquant: 4
		},
		nutrition: {
			kcal: 520,
			prot: 16,
			glucides: 62,
			lipides: 22,
			fibres: 3,
			sel: 1.7,
			ig: 58
		},
		tags: [
			"riz",
			"umami",
			"fumé"
		],
		source: "seed",
		createdAt: Date.now() - 2592e5,
		aromaticNote: "Sous-bois, beurre, fumée froide, parmesan cristallisé, riz encore al dente."
	}
];
var NOSE_DISHES = [
	{
		id: "tatin",
		label: "Tarte Tatin",
		readySec: 148,
		note: "Caramel ambré, pectine, beurre noisette"
	},
	{
		id: "pain",
		label: "Pain au levain",
		readySec: 210,
		note: "Croûte de céréale, Maillard, vapeur d’amidon"
	},
	{
		id: "steak",
		label: "Côte de bœuf",
		readySec: 132,
		note: "Pyrazines grillées, sucs, graisse fondue"
	},
	{
		id: "sablé",
		label: "Sablé breton",
		readySec: 96,
		note: "Beurre cuisiné, vanille, sucre blond"
	},
	{
		id: "oignon",
		label: "Soupe à l’oignon",
		readySec: 186,
		note: "Soufre doux, caramel d’allium"
	}
];
var COMPOUNDS = [
	{
		id: "furaneol",
		name: "Furaneol",
		family: "caramel"
	},
	{
		id: "diacetyl",
		name: "Diacétyle",
		family: "beurre"
	},
	{
		id: "pyrazine",
		name: "Alkyl-pyrazines",
		family: "grillé"
	},
	{
		id: "maltol",
		name: "Maltol",
		family: "toasté"
	},
	{
		id: "methional",
		name: "Méthional",
		family: "rôti"
	},
	{
		id: "limonene",
		name: "Limonène",
		family: "zeste"
	}
];
var PROBE_PRESETS = {
	steak: {
		label: "Côte de bœuf · saignant",
		targetC: 53,
		ovenC: 120,
		k: .018,
		rest: "Repos 10 min, +3 °C"
	},
	poulet: {
		label: "Poulet entier",
		targetC: 74,
		ovenC: 180,
		k: .011,
		rest: "Repos 15 min"
	},
	porc: {
		label: "Filet de porc",
		targetC: 63,
		ovenC: 160,
		k: .014,
		rest: "Repos 8 min"
	},
	saumon: {
		label: "Pavé de saumon",
		targetC: 50,
		ovenC: 180,
		k: .028,
		rest: "Sortir à 48 °C"
	},
	pain: {
		label: "Pain de campagne",
		targetC: 96,
		ovenC: 230,
		k: .009,
		rest: "Croûte 220 °C"
	},
	tarte: {
		label: "Tarte fruitée",
		targetC: 95,
		ovenC: 190,
		k: .016,
		rest: "Jus perlé"
	}
};
var REGION_PRESETS = [
	"France métropolitaine",
	"Maghreb",
	"Antilles",
	"Afrique de l’Ouest",
	"Québec",
	"Levant",
	"Japon",
	"Mexique"
];
var MACRO_GOALS = {
	kcal: 2100,
	prot: 110,
	glucides: 220,
	lipides: 70,
	fibres: 30
};
function emptyProbe(food = "steak") {
	const p = PROBE_PRESETS[food];
	return {
		running: false,
		food,
		targetC: p.targetC,
		ovenC: p.ovenC,
		startC: 12,
		startedAt: null,
		elapsedSec: 0,
		coreC: 12,
		predictedRemainSec: 0,
		history: [{
			t: 0,
			core: 12,
			predicted: 12
		}]
	};
}
function tickProbe(s, dt) {
	const p = PROBE_PRESETS[s.food];
	const elapsed = s.elapsedSec + dt;
	const k = p.k;
	const coreC = clamp(s.ovenC - (s.ovenC - s.startC) * Math.exp(-k * elapsed) + Math.sin(elapsed * .7) * .15, s.startC, s.ovenC);
	const remain = coreC >= s.targetC ? 0 : Math.log((s.ovenC - s.startC) / Math.max(.2, s.ovenC - s.targetC)) / k - elapsed;
	const predictedRemainSec = Math.max(0, remain);
	const predicted = s.ovenC - (s.ovenC - s.startC) * Math.exp(-k * (elapsed + 1));
	const history = [...s.history, {
		t: elapsed,
		core: coreC,
		predicted
	}].slice(-240);
	return {
		...s,
		elapsedSec: elapsed,
		coreC,
		predictedRemainSec,
		history
	};
}
function emptyNose(dish = "tatin") {
	const compounds = {};
	for (const c of COMPOUNDS) compounds[c.id] = 4;
	return {
		running: false,
		dish,
		startedAt: null,
		elapsedSec: 0,
		ready: false,
		readyAt: null,
		caramel: 4,
		maillard: 3,
		doneness: 2,
		compounds,
		history: [{
			t: 0,
			caramel: 4,
			maillard: 3,
			doneness: 2
		}]
	};
}
function sigmoid(x) {
	return 1 / (1 + Math.exp(-x));
}
function tickNose(s, dt) {
	const dish = NOSE_DISHES.find((d) => d.id === s.dish) ?? NOSE_DISHES[0];
	const elapsed = s.elapsedSec + dt;
	const n = elapsed / dish.readySec;
	const caramel = clamp(100 * sigmoid((n - .72) * 9), 0, 100);
	const maillard = clamp(100 * sigmoid((n - .58) * 8), 0, 100);
	const doneness = clamp(100 * sigmoid((n - .85) * 11), 0, 100);
	const wobble = 1 + Math.sin(elapsed * .35) * .04;
	const compounds = {
		furaneol: clamp(caramel * .92 * wobble, 0, 100),
		diacetyl: clamp(38 + caramel * .4 - doneness * .15, 0, 100),
		pyrazine: clamp(maillard * .88 * wobble, 0, 100),
		maltol: clamp(maillard * .7 + caramel * .2, 0, 100),
		methional: clamp(maillard * .55 + (s.dish === "steak" ? 28 : 8), 0, 100),
		limonene: clamp(12 + Math.sin(elapsed * .12) * 6, 0, 40)
	};
	const ready = doneness >= 62 && caramel >= 55;
	const history = [...s.history, {
		t: elapsed,
		caramel,
		maillard,
		doneness
	}].slice(-240);
	return {
		...s,
		elapsedSec: elapsed,
		caramel,
		maillard,
		doneness,
		compounds,
		ready,
		readyAt: ready && !s.ready ? Date.now() : s.readyAt,
		history
	};
}
function formatRemain(sec) {
	if (sec <= 0) return "0:00";
	return `${Math.floor(sec / 60)}:${Math.floor(sec % 60).toString().padStart(2, "0")}`;
}
function glucoseWalk(prev, fatigue) {
	return clamp(prev + ((Math.random() - .48) * 2.2 + (fatigue - 40) * .01), 68, 168);
}
function dayStart(ts = Date.now()) {
	const d = new Date(ts);
	d.setHours(0, 0, 0, 0);
	return d.getTime();
}
function seedHealth() {
	const now = Date.now();
	const cgm = Array.from({ length: 36 }, (_, i) => {
		const t = now - (35 - i) * 5 * 6e4;
		const base = 92 + Math.sin(i / 5) * 10 + (i > 20 ? 8 : 0);
		return {
			t,
			v: Math.round(base)
		};
	});
	return {
		glucose: cgm[cgm.length - 1]?.v ?? 94,
		trend: "stable",
		fatigue: 32,
		sleepH: 7.2,
		cgm
	};
}
function sumIntake(items) {
	const start = dayStart();
	return items.filter((e) => e.at >= start).reduce((acc, e) => ({
		kcal: acc.kcal + e.nutrition.kcal * e.portion,
		prot: acc.prot + e.nutrition.prot * e.portion,
		glucides: acc.glucides + e.nutrition.glucides * e.portion,
		lipides: acc.lipides + e.nutrition.lipides * e.portion,
		fibres: acc.fibres + e.nutrition.fibres * e.portion
	}), {
		kcal: 0,
		prot: 0,
		glucides: 0,
		lipides: 0,
		fibres: 0
	});
}
var useSillage = create()(persist((set, get) => ({
	recipes: SEED_RECIPES,
	notes: [{
		id: "note_seed",
		at: Date.now() - 936e5,
		transcript: "Tatin trop sucrée cette fois, le caramel est allé trop loin.",
		recipeId: "seed_tatin",
		recipeTitle: "Tarte Tatin fumée au foin",
		tag: "trop-sale",
		adjustment: "Arrêter le caramel un cran plus tôt, ajouter 1 c.à.c de vinaigre de cidre en plus."
	}],
	intake: [{
		id: "in_seed",
		at: Date.now() - 144e5,
		label: "Café et tartine de seigle",
		portion: 1,
		nutrition: {
			kcal: 220,
			prot: 7,
			glucides: 32,
			lipides: 6,
			fibres: 4,
			sel: .6,
			ig: 50
		}
	}],
	health: seedHealth(),
	region: "France métropolitaine",
	nose: emptyNose("tatin"),
	probe: emptyProbe("steak"),
	robot: {
		running: false,
		recipeId: null,
		stepIndex: 0,
		phase: "idle",
		plateC: 28,
		arm: "au repos",
		progress: 0,
		startedAt: null,
		log: []
	},
	addRecipe: (r) => set({ recipes: [r, ...get().recipes] }),
	addNote: (n) => set({ notes: [{
		id: uid("note"),
		at: n.at ?? Date.now(),
		...n
	}, ...get().notes] }),
	addIntake: (e) => set({ intake: [{
		...e,
		id: uid("eat")
	}, ...get().intake] }),
	setRegion: (region) => set({ region }),
	setHealth: (p) => set({ health: {
		...get().health,
		...p
	} }),
	tickHealth: () => {
		const h = get().health;
		const next = glucoseWalk(h.glucose, h.fatigue);
		const trend = next > h.glucose + 1.2 ? "up" : next < h.glucose - 1.2 ? "down" : "stable";
		const cgm = [...h.cgm, {
			t: Date.now(),
			v: Math.round(next)
		}].slice(-48);
		set({ health: {
			...h,
			glucose: next,
			trend,
			cgm
		} });
	},
	setNose: (p) => set({ nose: typeof p === "function" ? p(get().nose) : {
		...get().nose,
		...p
	} }),
	setProbe: (p) => set({ probe: typeof p === "function" ? p(get().probe) : {
		...get().probe,
		...p
	} }),
	resetProbe: (food) => set({ probe: emptyProbe(food) }),
	resetNose: (dish) => set({ nose: emptyNose(dish) }),
	setRobot: (p) => set({ robot: typeof p === "function" ? p(get().robot) : {
		...get().robot,
		...p
	} }),
	resetRobot: () => set({ robot: {
		running: false,
		recipeId: null,
		stepIndex: 0,
		phase: "idle",
		plateC: 28,
		arm: "au repos",
		progress: 0,
		startedAt: null,
		log: []
	} })
}), {
	name: "sillage-atelier",
	skipHydration: true,
	partialize: (s) => ({
		recipes: s.recipes,
		notes: s.notes,
		intake: s.intake,
		region: s.region,
		health: {
			...s.health,
			cgm: s.health.cgm.slice(-24)
		}
	})
}));
function useTodayMacros() {
	const intake = useSillage((s) => s.intake);
	return (0, import_react.useMemo)(() => sumIntake(intake), [intake]);
}
function useTodayIntake() {
	const intake = useSillage((s) => s.intake);
	return (0, import_react.useMemo)(() => intake.filter((e) => e.at >= dayStart()), [intake]);
}
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const [open, setOpen] = (0, import_react.useState)(false);
	const health = useSillage((s) => s.health);
	const nose = useSillage((s) => s.nose);
	const probe = useSillage((s) => s.probe);
	const robot = useSillage((s) => s.robot);
	const tickHealth = useSillage((s) => s.tickHealth);
	(0, import_react.useEffect)(() => {
		useSillage.persist.rehydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(tickHealth, 8e3);
		return () => window.clearInterval(id);
	}, [tickHealth]);
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	const live = nose.running && (nose.ready ? "Plat prêt" : "Nez en écoute") || (probe.running ? "Sonde active" : null) || (robot.running ? "Orchestration" : null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-border bg-background md:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-5 py-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground",
						children: "Atelier sensoriel"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex-1 overflow-y-auto px-3 pb-8",
					children: GROUPS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1.5 px-2 text-[10px] uppercase tracking-[0.18em] text-muted-foreground",
							children: g.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid gap-0.5",
							children: NAV.filter((n) => n.group === g.id).map((item) => {
								const active = pathname === item.to;
								const Icon = item.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: item.to,
									className: cn("flex h-10 items-center gap-2.5 rounded-md px-2.5 text-sm transition-colors", active ? "bg-accent text-accent-foreground" : "text-muted-foreground hover:bg-secondary hover:text-foreground"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-4",
										strokeWidth: 1.6
									}), item.label]
								}) }, item.to);
							})
						})]
					}, g.id))
				})]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "absolute inset-0 bg-ink/70",
					"aria-label": "Fermer le menu",
					onClick: () => setOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-y-0 left-0 w-72 overflow-y-auto bg-card p-4 shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-6 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "grid size-11 place-items-center",
							onClick: () => setOpen(false),
							"aria-label": "Fermer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}), NAV.map((item) => {
						const Icon = item.icon;
						const active = pathname === item.to;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex h-12 items-center gap-3 rounded-md px-2 text-sm", active ? "bg-accent text-accent-foreground" : "text-muted-foreground"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
						}, item.to);
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:pl-60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-20 flex h-14 items-center justify-between gap-3 border-b border-border bg-background/90 px-4 backdrop-blur-sm md:h-16 md:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 md:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "grid size-11 place-items-center",
								onClick: () => setOpen(true),
								"aria-label": "Menu",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-lg tracking-[0.16em]",
									children: "SILLAGE"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden items-center gap-3 md:flex",
							children: live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2 text-xs uppercase tracking-[0.16em] text-primary",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-primary ready-pulse" }), live]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
								children: "Studio capteurs"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "ml-auto flex items-center gap-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-full bg-secondary px-3 py-1.5 text-xs tabular-nums",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Glycémie "
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-foreground",
										children: Math.round(health.glucose)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: " mg/dL"
									})
								]
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "px-4 py-8 pb-28 md:px-8 md:pb-12",
					children
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-5",
					children: MOBILE_PRIMARY.map((to) => {
						const item = NAV.find((n) => n.to === to);
						const Icon = item.icon;
						const active = pathname === to || to === "/nez" && [
							"/sonde",
							"/texture",
							"/robot"
						].includes(pathname);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to,
							className: cn("flex h-14 flex-col items-center justify-center gap-1 text-[10px] uppercase tracking-wider", active ? "text-primary" : "text-muted-foreground"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-4",
								strokeWidth: 1.6
							}), item.label]
						}) }, to);
					})
				})
			})
		]
	});
}
var styles_default = "/assets/styles-DhRbXCiE.css";
var APP_NAME = "Sillage";
var Route$13 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#050807"
			},
			{
				name: "description",
				content: "Sillage — atelier de cuisine sensorielle. Nez, sonde, palais et mémoire."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;1,500&family=Outfit:wght@300;400;500;600&display=swap"
			}
		]
	}),
	component: Root
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "fr",
		suppressHydrationWarning: true,
		className: "antialiased",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-background text-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					theme: "dark",
					position: "bottom-right",
					toastOptions: { className: "bg-card text-foreground border-border" }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$12 = () => import("./routes-B5PCvhJZ.mjs");
var Route$12 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./creer-B0a2WSKE.mjs");
var Route$11 = createFileRoute("/creer")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./gout-DSAwlAHF.mjs");
var Route$10 = createFileRoute("/gout")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./journal-DkFVocbo.mjs");
var Route$9 = createFileRoute("/journal")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./nez-Cn0gsrtl.mjs");
var Route$8 = createFileRoute("/nez")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./nutrition-iRcGaF94.mjs");
var Route$7 = createFileRoute("/nutrition")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./photo-D-B8RMAb.mjs");
var Route$6 = createFileRoute("/photo")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./robot--urwTFhF.mjs");
var Route$5 = createFileRoute("/robot")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./sante-CGJjSgbX.mjs");
var Route$4 = createFileRoute("/sante")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./sonde-CH3w3oSi.mjs");
var Route$3 = createFileRoute("/sonde")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./texture-CRlJR1sq.mjs");
var Route$2 = createFileRoute("/texture")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./traduire-RS_zHELn.mjs");
var Route$1 = createFileRoute("/traduire")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./recette._id-stQ8N8s4.mjs");
var Route = createFileRoute("/recette/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$12.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$13
	}),
	CreerRoute: Route$11.update({
		id: "/creer",
		path: "/creer",
		getParentRoute: () => Route$13
	}),
	GoutRoute: Route$10.update({
		id: "/gout",
		path: "/gout",
		getParentRoute: () => Route$13
	}),
	JournalRoute: Route$9.update({
		id: "/journal",
		path: "/journal",
		getParentRoute: () => Route$13
	}),
	NezRoute: Route$8.update({
		id: "/nez",
		path: "/nez",
		getParentRoute: () => Route$13
	}),
	NutritionRoute: Route$7.update({
		id: "/nutrition",
		path: "/nutrition",
		getParentRoute: () => Route$13
	}),
	PhotoRoute: Route$6.update({
		id: "/photo",
		path: "/photo",
		getParentRoute: () => Route$13
	}),
	RobotRoute: Route$5.update({
		id: "/robot",
		path: "/robot",
		getParentRoute: () => Route$13
	}),
	SanteRoute: Route$4.update({
		id: "/sante",
		path: "/sante",
		getParentRoute: () => Route$13
	}),
	SondeRoute: Route$3.update({
		id: "/sonde",
		path: "/sonde",
		getParentRoute: () => Route$13
	}),
	TextureRoute: Route$2.update({
		id: "/texture",
		path: "/texture",
		getParentRoute: () => Route$13
	}),
	TraduireRoute: Route$1.update({
		id: "/traduire",
		path: "/traduire",
		getParentRoute: () => Route$13
	}),
	RecetteIdRoute: Route.update({
		id: "/recette/$id",
		path: "/recette/$id",
		getParentRoute: () => Route$13
	})
};
var routeTree = Route$13._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { formatDay as _, useTodayMacros as a, tickProbe as c, NOSE_DISHES as d, PROBE_PRESETS as f, fileToDataUrl as g, cn as h, useTodayIntake as i, COMPOUNDS as l, LogoMark as m, Route as n, formatRemain as o, REGION_PRESETS as p, useSillage as r, tickNose as s, router_exports as t, MACRO_GOALS as u, formatMin as v, formatTime as y };
