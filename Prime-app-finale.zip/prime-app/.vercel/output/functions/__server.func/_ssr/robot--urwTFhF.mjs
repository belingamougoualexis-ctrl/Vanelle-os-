import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { h as cn, r as useSillage } from "./router-B1GbWoht.mjs";
import { t as PageHeader } from "./page-header-yvGC4AM4.mjs";
import { t as Button } from "./button-BvbbVWOU.mjs";
import { t as Card } from "./card-DWnCgWBa.mjs";
import { t as Badge } from "./badge-Cq_6SHsn.mjs";
import { t as Progress } from "./progress-gyYcsKbV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/robot--urwTFhF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RobotPage() {
	const recipes = useSillage((s) => s.recipes);
	const robot = useSillage((s) => s.robot);
	const setRobot = useSillage((s) => s.setRobot);
	const resetRobot = useSillage((s) => s.resetRobot);
	const recipe = recipes.find((r) => r.id === robot.recipeId) ?? recipes[1] ?? recipes[0];
	const step = recipe?.steps[robot.stepIndex];
	(0, import_react.useEffect)(() => {
		if (!robot.running || !recipe) return;
		const id = window.setInterval(() => {
			setRobot((r) => {
				const current = recipe.steps[r.stepIndex];
				const dur = Math.max(8, (current?.durationMin ?? 5) * .35);
				const nextProgress = r.progress + 100 / (dur * 2.5);
				const heat = current?.induction ? 40 + current.induction * 18 : r.plateC;
				const plateC = r.plateC + (heat - r.plateC) * .08;
				if (nextProgress >= 100) {
					const last = r.stepIndex >= recipe.steps.length - 1;
					return {
						...r,
						progress: last ? 100 : 0,
						stepIndex: last ? r.stepIndex : r.stepIndex + 1,
						phase: last ? "done" : "cook",
						running: !last,
						plateC,
						arm: last ? "service" : recipe.steps[r.stepIndex + 1]?.arm ?? "enchaîner",
						log: [{
							t: Date.now(),
							text: last ? "Service. Bras au repos." : `Étape ${r.stepIndex + 2} — ${recipe.steps[r.stepIndex + 1]?.text.slice(0, 48)}`
						}, ...r.log].slice(0, 12)
					};
				}
				return {
					...r,
					progress: nextProgress,
					plateC,
					phase: r.stepIndex === 0 && nextProgress < 12 ? "preheat" : "cook",
					arm: current?.arm ?? "en geste"
				};
			});
		}, 400);
		return () => window.clearInterval(id);
	}, [
		robot.running,
		recipe,
		setRobot
	]);
	function start(id) {
		const r = recipes.find((x) => x.id === id);
		setRobot({
			running: true,
			recipeId: id,
			stepIndex: 0,
			phase: "preheat",
			plateC: 40,
			arm: r?.steps[0]?.arm ?? "préparer",
			progress: 0,
			startedAt: Date.now(),
			log: [{
				t: Date.now(),
				text: `Préchauffage — ${r?.title}`
			}]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "enter mx-auto max-w-6xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Autonomie totale",
				title: "Le cerveau. Le bras. La plaque.",
				lede: "Sillage orchestre la cuisson de A à Z : induction, bras, temps. Ici, le studio pilote une cuisine robotisée fidèle.",
				action: robot.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setRobot({
						running: false,
						phase: "paused"
					}),
					children: "Pause"
				}) : robot.phase === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: resetRobot,
					children: "Réinitialiser"
				}) : recipe ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => start(recipe.id),
					children: "Orchestrer"
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-6 lg:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: robot.phase === "done" ? "ocean" : "mute",
								children: robot.phase === "idle" ? "Veille" : robot.phase === "done" ? "Service" : robot.phase
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs tabular-nums text-muted-foreground",
								children: [Math.round(robot.plateC), " °C plaque"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KitchenMap, {
							plateC: robot.plateC,
							arm: robot.arm,
							active: robot.running || robot.phase === "done"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-sm text-muted-foreground",
							children: ["Bras · ", robot.arm]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
							className: "mt-3",
							value: robot.progress
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-6 lg:col-span-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
							children: recipe?.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-3xl",
							children: robot.phase === "done" ? "À table." : step ? `Étape ${step.n}` : "Choisir un plat"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted-foreground",
							children: step?.text
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-6 grid gap-2",
							children: recipe?.steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: cn("rounded-lg px-3 py-2 text-sm", i === robot.stepIndex ? "bg-accent text-accent-foreground" : "text-muted-foreground"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mr-2 font-mono text-xs tabular-nums",
									children: String(s.n).padStart(2, "0")
								}), s.text]
							}, s.n))
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-8 grid gap-3 md:grid-cols-2",
				children: recipes.slice(0, 4).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => start(r.id),
					className: cn("rounded-2xl bg-card p-5 text-left shadow-[0_0_0_1px_rgb(243_246_244_/_0.08)]", robot.recipeId === r.id && "shadow-[0_0_0_1px_var(--color-primary)]"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl",
						children: r.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							r.steps.length,
							" gestes · ",
							r.timeMin,
							" min réelles"
						]
					})]
				}, r.id))
			}),
			robot.log.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-6 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-xs uppercase tracking-wider text-muted-foreground",
					children: "Journal machine"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-1.5 font-mono text-xs text-muted-foreground",
					children: robot.log.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: l.text }, i))
				})]
			}) : null
		]
	});
}
function KitchenMap({ plateC, arm, active }) {
	const heat = Math.min(1, (plateC - 28) / 200);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto mt-8 aspect-square max-w-xs",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 rounded-2xl bg-secondary" }),
			[
				0,
				1,
				2,
				3
			].map((i) => {
				const col = i % 2;
				const row = Math.floor(i / 2);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute size-[38%] rounded-full shadow-[0_0_0_1px_rgb(243_246_244_/_0.1)]",
					style: {
						left: col === 0 ? "10%" : "52%",
						top: row === 0 ? "10%" : "52%",
						background: active && i === 0 ? `rgba(26,143,130,${.15 + heat * .55})` : "transparent"
					}
				}, i);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute left-1/2 top-1/2 size-4 -translate-x-1/2 -translate-y-1/2 rounded-full bg-porcelain transition-transform duration-500",
				style: { transform: `translate(-50%, -50%) translate(${active ? 28 : 0}px, ${active ? -18 : 0}px)` },
				title: arm
			})
		]
	});
}
//#endregion
export { RobotPage as component };
