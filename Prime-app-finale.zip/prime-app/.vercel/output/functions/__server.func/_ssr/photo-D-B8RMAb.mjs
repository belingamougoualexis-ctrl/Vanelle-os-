import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Upload } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { g as fileToDataUrl, r as useSillage } from "./router-B1GbWoht.mjs";
import { t as PageHeader } from "./page-header-yvGC4AM4.mjs";
import { t as Button } from "./button-BvbbVWOU.mjs";
import { t as Card } from "./card-DWnCgWBa.mjs";
import { t as Input } from "./input-BNJ_4Byq.mjs";
import { a as reconstructDish } from "./ai-97EnnJKT.mjs";
import { t as Badge } from "./badge-Cq_6SHsn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/photo-D-B8RMAb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PhotoPage() {
	const fileRef = (0, import_react.useRef)(null);
	const addRecipe = useSillage((s) => s.addRecipe);
	const navigate = useNavigate();
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [hint, setHint] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [meta, setMeta] = (0, import_react.useState)(null);
	async function run() {
		if (!preview) return;
		setBusy(true);
		const res = await reconstructDish({ data: {
			image: preview,
			hint
		} });
		setBusy(false);
		if (!res.ok) {
			toast.error(res.error);
			return;
		}
		addRecipe(res.recipe);
		setMeta({
			dish: res.dish,
			cuisine: res.cuisine,
			confidence: res.confidence
		});
		toast.success("Recette reconstituée.");
		navigate({
			to: "/recette/$id",
			params: { id: res.recipe.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "enter mx-auto max-w-4xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Mémoire · Cliché",
			title: "Le plat du resto, chez vous.",
			lede: "Une photo suffit. Sillage nomme le plat et reconstitue une recette fidèle, cuisinable dans votre cuisine."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "relative flex aspect-square w-full items-center justify-center bg-secondary",
					onClick: () => fileRef.current?.click(),
					children: preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: preview,
						alt: "Plat photographié",
						className: "size-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex flex-col items-center gap-2 text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-6" }), "Déposer le cliché"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: fileRef,
					type: "file",
					accept: "image/*",
					className: "hidden",
					onChange: async (e) => {
						const f = e.target.files?.[0];
						if (f) setPreview(await fileToDataUrl(f));
					}
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col justify-between p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
						children: "Indice (optionnel)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-2",
						placeholder: "Ramen du 11e, sauce sombre, œuf mollet…",
						value: hint,
						onChange: (e) => setHint(e.target.value)
					}),
					meta ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "ocean",
								children: meta.cuisine
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-display text-3xl",
								children: meta.dish
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted-foreground",
								children: [
									"Confiance ",
									Math.round(meta.confidence),
									" %"
								]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm leading-relaxed text-muted-foreground",
						children: "L’éclairage du resto, l’assiette, la nappe : tout compte. Cadrez le plat, pas la table."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-6 w-full",
					size: "lg",
					disabled: !preview || busy,
					onClick: () => void run(),
					children: busy ? "Reconstitution…" : "Retrouver la recette"
				})]
			})]
		})]
	});
}
//#endregion
export { PhotoPage as component };
