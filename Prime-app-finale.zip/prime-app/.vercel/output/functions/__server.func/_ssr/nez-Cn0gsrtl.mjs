import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { d as NOSE_DISHES, h as cn, l as COMPOUNDS, r as useSillage, s as tickNose } from "./router-B1GbWoht.mjs";
import { t as PageHeader } from "./page-header-yvGC4AM4.mjs";
import { t as Button } from "./button-BvbbVWOU.mjs";
import { t as Card } from "./card-DWnCgWBa.mjs";
import { a as XAxis, i as YAxis, m as Tooltip, o as Area, p as ResponsiveContainer, t as AreaChart } from "../_libs/recharts+[...].mjs";
import { t as Badge } from "./badge-Cq_6SHsn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nez-Cn0gsrtl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NezPage() {
	const nose = useSillage((s) => s.nose);
	const setNose = useSillage((s) => s.setNose);
	const resetNose = useSillage((s) => s.resetNose);
	const dish = NOSE_DISHES.find((d) => d.id === nose.dish) ?? NOSE_DISHES[0];
	(0, import_react.useEffect)(() => {
		if (!nose.running) return;
		const id = window.setInterval(() => setNose((n) => tickNose(n, 1.1)), 350);
		return () => window.clearInterval(id);
	}, [nose.running, setNose]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "enter mx-auto max-w-6xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Perception · Olfaction",
				title: "Le four reste fermé.",
				lede: "Le nez Sillage N-1 lit les composés volatils. Il annonce le caramel, le Maillard, le point juste — sans perdre la chaleur.",
				action: nose.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setNose({ running: false }),
					children: "Pause"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setNose({
						running: true,
						startedAt: Date.now()
					}),
					children: "Écouter l’air"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-6 flex flex-wrap gap-2",
				children: NOSE_DISHES.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => resetNose(d.id),
					className: cn("h-10 rounded-full px-4 text-sm", nose.dish === d.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
					children: d.label
				}, d.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "relative overflow-hidden p-6 lg:col-span-5",
					children: [
						nose.ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "ready-pulse mb-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "ocean",
								children: "Plat prêt — ne pas ouvrir plus tôt"
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: ["Capteur · ", nose.running ? "en ligne" : "en veille"] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-xs uppercase tracking-[0.18em] text-muted-foreground",
							children: "Indice de doneness"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-7xl tabular-nums leading-none",
							children: Math.round(nose.doneness)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: dish.note
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 grid grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Caramel",
								value: nose.caramel
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Maillard",
								value: nose.maillard
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5 lg:col-span-7",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-xs uppercase tracking-[0.16em] text-muted-foreground",
						children: "Courbe olfactive"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
								data: nose.history,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "t",
										hide: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										domain: [0, 100],
										hide: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										contentStyle: {
											background: "#0b100f",
											border: "1px solid #1c2a26",
											borderRadius: 12
										},
										labelFormatter: () => ""
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										type: "monotone",
										dataKey: "caramel",
										stroke: "#1a8f82",
										fill: "#1a8f82",
										fillOpacity: .18
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										type: "monotone",
										dataKey: "maillard",
										stroke: "#f3f6f4",
										fill: "#f3f6f4",
										fillOpacity: .06
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										type: "monotone",
										dataKey: "doneness",
										stroke: "#8b9c96",
										fill: "transparent"
									})
								]
							})
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
				children: COMPOUNDS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: c.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-sm tabular-nums text-primary",
								children: Math.round(nose.compounds[c.id] ?? 0)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-wider text-muted-foreground",
							children: c.family
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-1 rounded-full bg-secondary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full bg-primary",
								style: { width: `${nose.compounds[c.id] ?? 0}%` }
							})
						})
					]
				}, c.id))
			})
		]
	});
}
function Metric({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs uppercase tracking-wider text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-display text-3xl tabular-nums",
		children: Math.round(value)
	})] });
}
//#endregion
export { NezPage as component };
