import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { h as cn } from "./router-B1GbWoht.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/label-BfVC8qEA.js
var import_jsx_runtime = require_jsx_runtime();
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground", className),
		...props
	});
}
//#endregion
export { Label as t };
