import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { d as PolarRadiusAxis, f as PolarGrid, l as Radar, n as RadarChart, p as ResponsiveContainer, u as PolarAngleAxis } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/taste-radar-CHkUGlxO.js
var import_jsx_runtime = require_jsx_runtime();
var LABELS = [
	{
		key: "acide",
		label: "Acide"
	},
	{
		key: "sucre",
		label: "Sucré"
	},
	{
		key: "amer",
		label: "Amer"
	},
	{
		key: "sale",
		label: "Salé"
	},
	{
		key: "umami",
		label: "Umami"
	},
	{
		key: "gras",
		label: "Gras"
	},
	{
		key: "piquant",
		label: "Piquant"
	}
];
function TasteRadar({ taste, size = 260 }) {
	const data = LABELS.map((l) => ({
		axis: l.label,
		v: taste[l.key]
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "w-full",
		style: { height: size },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
				data,
				cx: "50%",
				cy: "50%",
				outerRadius: "72%",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, { stroke: "rgba(243,246,244,0.12)" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
						dataKey: "axis",
						tick: {
							fill: "#8b9c96",
							fontSize: 11,
							fontFamily: "Outfit, sans-serif"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarRadiusAxis, {
						angle: 90,
						domain: [0, 100],
						tick: false,
						axisLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
						dataKey: "v",
						stroke: "#1a8f82",
						fill: "#1a8f82",
						fillOpacity: .28,
						strokeWidth: 1.6
					})
				]
			})
		})
	});
}
function TasteBars({ taste }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid gap-2.5",
		children: LABELS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "grid grid-cols-[5.5rem_1fr_2rem] items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs uppercase tracking-wider text-muted-foreground",
					children: l.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1 rounded-full bg-secondary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-primary",
						style: { width: `${taste[l.key]}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-right font-mono text-xs tabular-nums text-foreground",
					children: taste[l.key]
				})
			]
		}, l.key))
	});
}
//#endregion
export { TasteRadar as n, TasteBars as t };
