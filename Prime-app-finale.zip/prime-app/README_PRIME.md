# Prime — Intelligence au service du goût

App cuisine **gratuite**, prête publication web + Android.

## Démarrage

```bash
npm install
npm run dev          # http://localhost:8080
npm run build        # production → dist/
```

## Fonctionnalités

| Module | Fonctionne | Comment |
|--------|------------|---------|
| Splash | Oui | Slogan *L’intelligence au service du goût* |
| Créer | Oui | TheMealDB (internet gratuit) + structure pro |
| Traduire | Oui | Variante régionale TheMealDB |
| Préférences | Oui | Régimes, allergies, à éviter (local, persisté) |
| Goût | Oui | Lexique + règles locales |
| Texture | Oui | Analyse canvas locale |
| Photo | Oui | Couleurs + TheMealDB + ajout carnet |
| Journal | Oui | Tags locaux + dictée navigateur |
| Santé | Oui | Conseils selon glycémie (local) |
| Nez / Sonde / Robot | Oui | Simulations pédagogiques |
| Nutrition | Oui | Macros du jour |
| Carnet filtré | Oui | Selon préférences alimentaires |
| TFLite Android | Optionnel | Plugin + modèle dans assets |

**Aucune clé API payante** requise pour les flux principaux.

## Préférences alimentaires

Menu → **Préférences** : végétarien, vegan, sans gluten, allergies, etc.  
Appliquées à la création et au filtre du carnet.

## Android

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
npm run build && npx cap sync android
npx cap open android
```

TFLite : `native-android/FoodVisionPlugin/` (voir OPTIMIZE.md).

## Publication

- **Web** : déployer `dist/`
- **Android** : AAB signé → Play Store
- Manifest PWA déjà présent (`public/__grok/`)

## Structure

```
src/routes/           écrans
src/lib/local-sense.ts    goût, texture, photo, journal, santé
src/lib/dietary.ts        préférences + filtres
src/lib/native-vision.ts  pont TFLite
src/lib/ai.ts             TheMealDB
src/components/splash.tsx page d’ouverture
native-android/           plugin TFLite optimisé
```
