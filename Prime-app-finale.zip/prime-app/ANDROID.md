# Prime — App Android (on-device, sans API IA payante)

## Important

| Techno | Plateforme |
|--------|------------|
| **CoreML** | iOS uniquement |
| **TensorFlow Lite / YOLO** | Android natif |
| **TensorFlow.js** | Navigateur + WebView Android (Capacitor) |

Cette app est en **React (web)**. Pour en faire une **application Android installable** sans tout réécrire en Kotlin :

1. On packagé avec **Capacitor** → APK / AAB installable sur téléphone
2. La vision / le goût tournent **sur l’appareil** (canvas + règles + option TF.js)
3. Les recettes viennent d’internet gratuit (TheMealDB), pas d’API IA payante

Pour du **YOLO / TFLite 100 % natif Kotlin**, il faudrait une réécriture native (plusieurs semaines) + modèles `.tflite` dans `assets/`.

---

## Prérequis sur ta machine

- Node.js 20+
- Android Studio (Ladybug ou plus récent)
- JDK 17+
- Téléphone Android ou émulateur

```bash
# une fois
npm install
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
```

---

## Build APK

```bash
# 1. Build web
npm run build

# 2. Sync vers le projet Android
npx cap sync android

# 3. Ouvrir dans Android Studio
npx cap open android
```

Dans Android Studio : **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

Fichier généré : `android/app/build/outputs/apk/debug/app-debug.apk`

---

## Fonctionnalités on-device (déjà dans le code)

| Feature | Méthode Android / WebView |
|---------|---------------------------|
| Goût avant cuisson | Lexique + règles JS (local-sense) |
| Texture | Analyse pixels canvas (contraste, grain) |
| Photo de plat | Couleurs locales + TheMealDB (internet) |
| Recettes | Internet gratuit, structure pro |

Aucune clé OpenAI / Gemini / xAI requise pour ces flux.

---

## Option avancée : TensorFlow Lite natif

Si tu veux YOLO / MobileNet **TFLite** dans une couche Kotlin :

1. Placer le modèle `food101.tflite` (ou YOLOv8n-food) dans `android/app/src/main/assets/`
2. Ajouter la dépendance Gradle :
   ```gradle
   implementation 'org.tensorflow:tensorflow-lite:2.14.0'
   implementation 'org.tensorflow:tensorflow-lite-support:0.4.4'
   ```
3. Créer un plugin Capacitor `FoodClassifierPlugin` qui expose `classify(imageBase64)`
4. Appeler ce plugin depuis `local-sense.ts` à la place des heuristiques couleur

Documentation Capacitor plugins : https://capacitorjs.com/docs/plugins

---

## PWA (sans Android Studio)

Tu peux aussi **installer l’app depuis le navigateur** (Chrome Android) :
Menu → « Ajouter à l’écran d’accueil ».  
Les fonctions locales (goût, texture) marchent hors ligne une fois chargées.

---

## Plugin TFLite / YOLO (déjà fourni)

Dossier : `native-android/FoodVisionPlugin/`

| Fichier | Rôle |
|---------|------|
| `FoodVisionPlugin.kt` | Plugin Capacitor classification on-device |
| `food_labels.txt` | 101 classes type Food-101 |
| `README.md` | Installation pas à pas |

Sans `food_model.tflite` dans les assets Android, **l’app fonctionne quand même** :
- Goût → règles locales
- Texture → canvas
- Photo → couleurs + TheMealDB

Dès que tu ajoutes un `.tflite`, le plugin natif est utilisé automatiquement.
