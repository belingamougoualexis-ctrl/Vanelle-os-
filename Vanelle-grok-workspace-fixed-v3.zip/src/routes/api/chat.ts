import { createFileRoute } from "@tanstack/react-router";
import { runChat, type ChatPayload } from "@/lib/grok.server";

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let payload: ChatPayload;
        try {
          payload = (await request.json()) as ChatPayload;
        } catch {
          return Response.json({ error: "Corps JSON invalide." }, { status: 400 });
        }
        if (!payload?.ai || !Array.isArray(payload.messages)) {
          return Response.json({ error: "Requête incomplète." }, { status: 400 });
        }

        const stream = new ReadableStream({
          async start(controller) {
            const encoder = new TextEncoder();
            const send = (event: unknown) => {
              controller.enqueue(encoder.encode(`data: ${JSON.stringify(event)}\n\n`));
            };
            try {
              await runChat(payload, send);
            } catch (e) {
              send({
                type: "error",
                message: e instanceof Error ? e.message : "Échec du moteur IA.",
              });
              send({ type: "done" });
            } finally {
              controller.close();
            }
          },
        });

        return new Response(stream, {
          headers: {
            "Content-Type": "text/event-stream; charset=utf-8",
            "Cache-Control": "no-store",
            Connection: "keep-alive",
          },
        });
      },
    },
  },
});
