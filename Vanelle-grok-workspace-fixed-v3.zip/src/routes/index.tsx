import { createFileRoute } from "@tanstack/react-router";
import { VanelleApp } from "@/components/vanelle-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <VanelleApp />;
}
