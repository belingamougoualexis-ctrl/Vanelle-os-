export type ChatEvent =
  | { type: "delta"; text: string }
  | { type: "tool"; name: string; ok: boolean; preview: string }
  | {
      type: "confirm";
      apiId: string;
      apiName: string;
      method: string;
      query?: Record<string, string>;
      body?: unknown;
    }
  | { type: "error"; message: string }
  | { type: "done" };
