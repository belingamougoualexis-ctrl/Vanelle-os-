export type Message = {
  id: string;
  role: "user" | "assistant";
  text: string;
  ts: number;
  pendingConfirm?: {
    apiId: string;
    apiName: string;
    method: string;
    query?: Record<string, string>;
    body?: unknown;
  };
};

export const CATEGORIES = [
  "Identité",
  "Personnalité",
  "Connaissances",
  "Compétences",
  "Règles",
] as const;
export type Category = (typeof CATEGORIES)[number];

export type Training = {
  id: string;
  category: Category | string;
  question: string;
  answer: string;
  ts: number;
};

export type VFile = {
  id: string;
  name: string;
  note: string;
  size: number;
  addedAt: number;
  mime?: string;
  dataUrl?: string;
};

export type HttpMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE" | "HEAD" | "OPTIONS";
export type ApiProtocol =
  | "rest"
  | "graphql"
  | "sse"
  | "websocket"
  | "multipart"
  | "binary"
  | "mtls"
  | "custom";
export type AuthType = "none" | "apiKey" | "bearer" | "basic";

export type UserApi = {
  id: string;
  name: string;
  endpoint: string;
  method: HttpMethod;
  description: string;
  secretRef?: string;
  protocol?: ApiProtocol;
  authType?: AuthType;
  authHeader?: string;
  username?: string;
  requestHeaders?: Record<string, string>;
  queryParams?: Record<string, string>;
  body?: string;
  timeoutMs?: number;
  retries?: number;
  retryNonIdempotent?: boolean;
  /** Indices 0, 1, 2 of the personality traits this API is bound to. */
  linkedTraits?: number[];
  ts: number;
};

export type AI = {
  id: string;
  name: string;
  description: string;
  style: string;
  traits: [string, string, string];
  systemPrompt: string;
  maxTokens: number;
  temperature: number;
  createdAt: number;
  training: Training[];
  files: VFile[];
  apis: UserApi[];
  deployed: boolean;
  deployedAt?: number;
};

export type Profile = {
  pseudo: string;
};

export const blankProfile = (): Profile => ({ pseudo: "" });

export function blankAI(name: string, description: string, style: string): AI {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
    name,
    description,
    style,
    traits: ["", "", ""],
    systemPrompt: "",
    maxTokens: 700,
    temperature: 0.4,
    createdAt: Date.now(),
    training: [],
    files: [],
    apis: [],
    deployed: false,
  };
}

export function migrateAI(ai: Partial<AI> & { id: string; name: string }): AI {
  const traits = ai.traits && ai.traits.length === 3 ? ai.traits : (["", "", ""] as [string, string, string]);
  return {
    id: ai.id,
    name: ai.name,
    description: ai.description ?? "",
    style: ai.style ?? "Généraliste",
    traits: [traits[0] ?? "", traits[1] ?? "", traits[2] ?? ""] as [string, string, string],
    systemPrompt: ai.systemPrompt ?? "",
    maxTokens: ai.maxTokens ?? 700,
    temperature: ai.temperature ?? 0.4,
    createdAt: ai.createdAt ?? Date.now(),
    training: ai.training ?? [],
    files: ai.files ?? [],
    apis: (ai.apis ?? []).map((api) => ({
      ...api,
      linkedTraits: api.linkedTraits ?? [],
    })),
    deployed: ai.deployed ?? false,
    deployedAt: ai.deployedAt,
  };
}
