import { validatePublicHttpsUrl } from "./safe-url";
import type { ProxyAuth, ProxyRequest, ProxyResult } from "./proxy-types";

export type { ProxyAuth, ProxyRequest, ProxyResult };

const DEFAULT_TIMEOUT_MS = 15_000;
const DEFAULT_RETRIES = 2;
const RETRYABLE = new Set([408, 425, 429, 500, 502, 503, 504]);

function parseBody(raw: string): unknown {
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return raw;
  }
}

function buildUrl(endpoint: string, query?: ProxyRequest["query"]): string {
  const u = validatePublicHttpsUrl(endpoint);
  if (query) {
    for (const [k, v] of Object.entries(query)) {
      if (v !== undefined && v !== null) u.searchParams.set(k, String(v));
    }
  }
  return u.toString();
}

function authHeaders(auth: ProxyAuth | undefined): Record<string, string> {
  if (!auth || auth.type === "none") return {};
  if (auth.type === "apiKey" && auth.key) return { [auth.header || "X-API-Key"]: auth.key };
  if (auth.type === "bearer" && auth.token) return { Authorization: `Bearer ${auth.token}` };
  if (auth.type === "basic") {
    const encoded = Buffer.from(`${auth.username}:${auth.password}`).toString("base64");
    return { Authorization: `Basic ${encoded}` };
  }
  return {};
}

function retryDelay(a: number) {
  return Math.min(5000, 400 * 2 ** (a - 1)) + Math.floor(Math.random() * 250);
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function executeProxy(cfg: ProxyRequest): Promise<ProxyResult> {
  const method = cfg.method || "GET";
  const url = buildUrl(cfg.endpoint, cfg.query);
  const retries = Math.max(0, cfg.retries ?? DEFAULT_RETRIES);
  const canRetry =
    method === "GET" || method === "HEAD" || method === "OPTIONS" || !!cfg.retryNonIdempotent;
  const maxAttempts = canRetry ? retries + 1 : 1;
  const startedAll = Date.now();
  let lastError: unknown;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const c = new AbortController();
    const timeout = setTimeout(() => c.abort(), cfg.timeoutMs ?? DEFAULT_TIMEOUT_MS);
    try {
      const headers: Record<string, string> = {
        Accept: "application/json, text/plain, */*",
        ...authHeaders(cfg.auth),
        ...(cfg.headers || {}),
      };
      let body: string | undefined;
      if (cfg.body !== undefined && method !== "GET" && method !== "HEAD") {
        body = typeof cfg.body === "string" ? cfg.body : JSON.stringify(cfg.body);
        if (!Object.keys(headers).some((k) => k.toLowerCase() === "content-type")) {
          headers["Content-Type"] = "application/json";
        }
      }
      const response = await fetch(url, { method, headers, body, signal: c.signal });
      const raw = await response.text();
      const rh: Record<string, string> = {};
      response.headers.forEach((v, k) => {
        rh[k] = v;
      });
      const result: ProxyResult = {
        ok: response.ok,
        status: response.status,
        statusText: response.statusText,
        headers: rh,
        data: parseBody(raw),
        raw: raw.slice(0, 80_000),
        elapsedMs: Date.now() - startedAll,
        attempts: attempt,
      };
      if (response.ok || !canRetry || !RETRYABLE.has(response.status) || attempt >= maxAttempts) {
        return result;
      }
      const ra = Number(rh["retry-after"]);
      await sleep(Number.isFinite(ra) ? Math.min(30000, ra * 1000) : retryDelay(attempt));
    } catch (e) {
      lastError = e;
      if (attempt >= maxAttempts) break;
      await sleep(retryDelay(attempt));
    } finally {
      clearTimeout(timeout);
    }
  }
  if ((lastError as { name?: string } | null)?.name === "AbortError") {
    throw new Error(
      `L'API n'a pas répondu dans ${Math.round((cfg.timeoutMs ?? DEFAULT_TIMEOUT_MS) / 1000)} s.`,
    );
  }
  throw new Error(
    `Impossible de joindre l'API après ${maxAttempts} tentative(s). ${lastError instanceof Error ? lastError.message : ""}`.trim(),
  );
}

export function summarizeApiData(data: unknown) {
  if (data === null) return "Réponse vide.";
  if (typeof data === "string") return data.slice(0, 1000);
  try {
    return JSON.stringify(data, null, 2).slice(0, 1800);
  } catch {
    return "Réponse reçue mais impossible à afficher.";
  }
}
