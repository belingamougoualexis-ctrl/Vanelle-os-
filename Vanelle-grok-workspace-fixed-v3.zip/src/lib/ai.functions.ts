import { createServerFn } from "@tanstack/react-start";
import type { ProxyRequest } from "./proxy-types";

export const getAiStatus = createServerFn({ method: "GET" }).handler(async () => {
  const { isAiAvailable } = await import("./grok.server");
  return { available: isAiAvailable() };
});

export type ApiTestResult = {
  ok: boolean;
  status: number;
  statusText: string;
  preview: string;
  elapsedMs: number;
  attempts: number;
};

export const testConfiguredApi = createServerFn({ method: "POST" })
  .validator((input: ProxyRequest) => input)
  .handler(async ({ data }): Promise<ApiTestResult> => {
    const { executeProxy, summarizeApiData } = await import("./proxy.server");
    const result = await executeProxy(data);
    return {
      ok: result.ok,
      status: result.status,
      statusText: result.statusText,
      preview: summarizeApiData(result.data),
      elapsedMs: result.elapsedMs,
      attempts: result.attempts,
    };
  });
