import { create } from "zustand";
import { persist, createJSONStorage, type StateStorage } from "zustand/middleware";
import { blankProfile, migrateAI, type AI, type Message, type Profile, type UserApi } from "./types";
import { makeId } from "./utils";

const memory: Record<string, string> = {};
const memoryStorage: StateStorage = {
  getItem: (name) => memory[name] ?? null,
  setItem: (name, value) => {
    memory[name] = value;
  },
  removeItem: (name) => {
    delete memory[name];
  },
};

const storage: StateStorage =
  typeof window === "undefined"
    ? memoryStorage
    : {
        getItem: (name) => {
          try {
            return localStorage.getItem(name);
          } catch {
            return memory[name] ?? null;
          }
        },
        setItem: (name, value) => {
          try {
            localStorage.setItem(name, value);
          } catch {
            memory[name] = value;
          }
        },
        removeItem: (name) => {
          try {
            localStorage.removeItem(name);
          } catch {
            delete memory[name];
          }
        },
      };

type VanelleState = {
  ais: AI[];
  chats: Record<string, Message[]>;
  profile: Profile;
  secrets: Record<string, string>;
  saveAI: (ai: AI) => void;
  deleteAI: (id: string) => void;
  getAI: (id: string) => AI | undefined;
  saveChat: (id: string, messages: Message[]) => void;
  saveProfile: (profile: Profile) => void;
  putSecret: (ref: string, value: string) => void;
  getSecret: (ref?: string) => string | undefined;
  deleteSecret: (ref: string) => void;
  attachApi: (aiId: string, api: UserApi, secret?: string) => void;
  importBundle: (data: {
    profile?: Profile;
    ais?: AI[];
    chats?: Record<string, Message[]>;
    secrets?: Record<string, string>;
  }) => void;
};

export const useVanelleStore = create<VanelleState>()(
  persist(
    (set, get) => ({
      ais: [],
      chats: {},
      profile: blankProfile(),
      secrets: {},
      saveAI: (ai) =>
        set((s) => {
          const next = migrateAI(ai);
          const exists = s.ais.some((x) => x.id === next.id);
          return {
            ais: exists ? s.ais.map((x) => (x.id === next.id ? next : x)) : [next, ...s.ais],
          };
        }),
      deleteAI: (id) =>
        set((s) => {
          const removed = s.ais.find((x) => x.id === id);
          const secrets = { ...s.secrets };
          if (removed) {
            for (const api of removed.apis) {
              if (api.secretRef) delete secrets[api.secretRef];
            }
          }
          const chats = { ...s.chats };
          delete chats[id];
          return { ais: s.ais.filter((x) => x.id !== id), chats, secrets };
        }),
      getAI: (id) => get().ais.find((x) => x.id === id),
      saveChat: (id, messages) =>
        set((s) => ({
          chats: { ...s.chats, [id]: messages },
        })),
      saveProfile: (profile) => set({ profile }),
      putSecret: (ref, value) =>
        set((s) => ({ secrets: { ...s.secrets, [ref]: value } })),
      getSecret: (ref) => (ref ? get().secrets[ref] : undefined),
      deleteSecret: (ref) =>
        set((s) => {
          const secrets = { ...s.secrets };
          delete secrets[ref];
          return { secrets };
        }),
      attachApi: (aiId, api, secret) =>
        set((s) => {
          const secrets = { ...s.secrets };
          let nextApi = { ...api };
          if (secret && secret.trim()) {
            const ref = api.secretRef || `api:${aiId}:${api.id || makeId()}`;
            secrets[ref] = secret.trim();
            nextApi = { ...nextApi, secretRef: ref };
          }
          return {
            secrets,
            ais: s.ais.map((ai) =>
              ai.id === aiId
                ? {
                    ...ai,
                    apis: ai.apis.some((x) => x.id === nextApi.id)
                      ? ai.apis.map((x) => (x.id === nextApi.id ? nextApi : x))
                      : [...ai.apis, nextApi],
                  }
                : ai,
            ),
          };
        }),
      importBundle: (data) =>
        set((s) => {
          const profile = data.profile ? { ...blankProfile(), ...data.profile } : s.profile;
          let ais = s.ais;
          if (Array.isArray(data.ais)) {
            const incoming = data.ais.map((a) => migrateAI(a));
            const byId = new Map(ais.map((a) => [a.id, a]));
            for (const ai of incoming) byId.set(ai.id, ai);
            ais = Array.from(byId.values()).sort((a, b) => b.createdAt - a.createdAt);
          }
          const chats = { ...s.chats, ...(data.chats ?? {}) };
          const secrets = { ...s.secrets, ...(data.secrets ?? {}) };
          return { profile, ais, chats, secrets };
        }),
    }),
    {
      name: "vanelle-studio",
      storage: createJSONStorage(() => storage),
      partialize: (s) => ({
        ais: s.ais,
        chats: s.chats,
        profile: s.profile,
        secrets: s.secrets,
      }),
    },
  ),
);
