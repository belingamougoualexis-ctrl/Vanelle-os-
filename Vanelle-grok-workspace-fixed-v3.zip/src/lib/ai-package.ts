import JSZip from "jszip";
import type { AI, Message } from "./types";
import { migrateAI } from "./types";
import { makeId } from "./utils";

const PACKAGE_VERSION = 1;

export async function buildAIZip(ai: AI, chat: Message[]): Promise<Blob> {
  const zip = new JSZip();
  zip.file(
    "manifest.json",
    JSON.stringify(
      { app: "Vanelle", packageVersion: PACKAGE_VERSION, exportedAt: new Date().toISOString() },
      null,
      2,
    ),
  );
  zip.file(
    "ai.json",
    JSON.stringify(
      {
        id: ai.id,
        name: ai.name,
        description: ai.description,
        style: ai.style,
        traits: ai.traits,
        systemPrompt: ai.systemPrompt,
        maxTokens: ai.maxTokens,
        temperature: ai.temperature,
        createdAt: ai.createdAt,
        deployed: ai.deployed,
        deployedAt: ai.deployedAt,
        apis: ai.apis.map(({ secretRef: _s, ...api }) => api),
      },
      null,
      2,
    ),
  );
  zip.file("training.json", JSON.stringify(ai.training, null, 2));
  const filesFolder = zip.folder("files");
  if (filesFolder) {
    filesFolder.file(
      "manifest.json",
      JSON.stringify(
        ai.files.map((f) => ({ id: f.id, name: f.name, size: f.size, addedAt: f.addedAt, mime: f.mime })),
        null,
        2,
      ),
    );
    for (const f of ai.files) {
      filesFolder.file(`${f.id}.txt`, f.note);
    }
  }
  zip.file("chat-history.json", JSON.stringify(chat, null, 2));
  return zip.generateAsync({ type: "blob" });
}

export type ImportedAIPackage = { ai: AI; chat: Message[] };

export async function parseAIZip(file: File | ArrayBuffer | Uint8Array): Promise<ImportedAIPackage> {
  const zip = await JSZip.loadAsync(file);
  const readJSON = async <T,>(path: string, fallback: T): Promise<T> => {
    const entry = zip.file(path);
    if (!entry) return fallback;
    const text = await entry.async("string");
    try {
      return JSON.parse(text) as T;
    } catch {
      return fallback;
    }
  };

  const aiJson = await readJSON<Partial<AI> & { name?: string }>("ai.json", {});
  if (!aiJson.name?.trim()) {
    throw new Error("Ce .zip ne contient pas d'IA Vanelle valide (ai.json manquant).");
  }
  const training = await readJSON("training.json", []);
  const filesManifest = await readJSON<
    Array<{ id: string; name: string; size: number; addedAt: number; mime?: string }>
  >("files/manifest.json", []);
  const files = await Promise.all(
    filesManifest.map(async (f) => {
      const entry = zip.file(`files/${f.id}.txt`);
      const note = entry ? await entry.async("string") : "";
      return { id: f.id, name: f.name, size: f.size, addedAt: f.addedAt, note, mime: f.mime };
    }),
  );
  const chat = await readJSON<Message[]>("chat-history.json", []);
  const ai = migrateAI({
    id: makeId(),
    name: aiJson.name.trim(),
    description: aiJson.description,
    style: aiJson.style,
    traits: aiJson.traits,
    systemPrompt: aiJson.systemPrompt,
    maxTokens: aiJson.maxTokens,
    temperature: aiJson.temperature,
    createdAt: Date.now(),
    training,
    files,
    apis: (aiJson.apis ?? []).map((a) => ({ ...a, secretRef: undefined })),
    deployed: false,
  });
  return { ai, chat };
}
