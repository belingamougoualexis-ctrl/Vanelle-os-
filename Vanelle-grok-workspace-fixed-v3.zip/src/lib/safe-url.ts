const BLOCKED_HOSTS = new Set(["localhost", "127.0.0.1", "0.0.0.0", "::1", "metadata.google.internal"]);

function isPrivateHostname(host: string): boolean {
  const h = host.toLowerCase().replace(/^\[|\]$/g, "");
  if (BLOCKED_HOSTS.has(h)) return true;
  if (h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".localhost")) return true;
  if (/^10\.\d+\.\d+\.\d+$/.test(h)) return true;
  if (/^192\.168\.\d+\.\d+$/.test(h)) return true;
  if (/^172\.(1[6-9]|2\d|3[0-1])\.\d+\.\d+$/.test(h)) return true;
  if (/^169\.254\.\d+\.\d+$/.test(h)) return true;
  if (/^127\.\d+\.\d+\.\d+$/.test(h)) return true;
  if (h === "::" || h.startsWith("fe80:") || h.startsWith("fc") || h.startsWith("fd")) return true;
  return false;
}

export function validatePublicHttpsUrl(endpoint: string): URL {
  let u: URL;
  try {
    u = new URL(endpoint.trim());
  } catch {
    throw new Error("Endpoint invalide. Utilisez une URL complète (https://…).");
  }
  if (u.protocol !== "https:") {
    throw new Error("Vanelle exige HTTPS pour les API Internet.");
  }
  if (isPrivateHostname(u.hostname)) {
    throw new Error("Cet hôte n'est pas autorisé (réseau privé ou local).");
  }
  return u;
}
