export type ProxyAuth =
  | { type: "none" }
  | { type: "apiKey"; key: string; header?: string }
  | { type: "bearer"; token: string }
  | { type: "basic"; username: string; password: string };

export type ProxyRequest = {
  endpoint: string;
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE" | "HEAD" | "OPTIONS";
  headers?: Record<string, string>;
  query?: Record<string, string | number | boolean | null | undefined>;
  body?: unknown;
  auth?: ProxyAuth;
  timeoutMs?: number;
  retries?: number;
  retryNonIdempotent?: boolean;
};

export type ProxyResult = {
  ok: boolean;
  status: number;
  statusText: string;
  headers: Record<string, string>;
  data: unknown;
  raw: string;
  elapsedMs: number;
  attempts: number;
  preview?: string;
};
