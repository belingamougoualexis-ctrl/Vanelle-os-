import type { VFile } from "./types";
import {
  IMAGE_EXTENSIONS,
  IMAGE_PREVIEW_MAX,
  MAX_FILE_BYTES,
  TEXT_EXTENSIONS,
  TEXT_EXTRACT_BYTES,
  fmtSize,
  makeId,
} from "./utils";

export type FileReadResult = {
  added: VFile[];
  errors: string[];
};

function extOf(name: string) {
  const i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(i).toLowerCase() : "";
}

async function readTextHead(file: File): Promise<string> {
  const slice = file.slice(0, TEXT_EXTRACT_BYTES);
  const text = await slice.text();
  return text.slice(0, 8000);
}

async function readImagePreview(file: File): Promise<string | undefined> {
  if (file.size > IMAGE_PREVIEW_MAX) return undefined;
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : undefined);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export async function ingestFiles(list: FileList | File[]): Promise<FileReadResult> {
  const files = Array.from(list);
  const added: VFile[] = [];
  const errors: string[] = [];

  for (const file of files) {
    if (file.size > MAX_FILE_BYTES) {
      errors.push(
        `« ${file.name} » dépasse 3 Go (${fmtSize(file.size)}). Chaque fichier doit peser au maximum 3 Go — la limite s’applique fichier par fichier, pas au total.`,
      );
      continue;
    }

    const ext = extOf(file.name);
    const isText = TEXT_EXTENSIONS.includes(ext);
    const isImage = IMAGE_EXTENSIONS.includes(ext) || file.type.startsWith("image/");
    let note = "Fichier binaire — contenu non extrait automatiquement.";
    let dataUrl: string | undefined;

    if (isImage) {
      note = "Image jointe — disponible comme référence de connaissance.";
      try {
        dataUrl = await readImagePreview(file);
      } catch {
        dataUrl = undefined;
      }
    } else if (isText) {
      try {
        note = await readTextHead(file);
        if (!note.trim()) note = "Fichier texte vide.";
      } catch {
        note = "Ce fichier a été ajouté mais son contenu n’a pas pu être lu.";
      }
    }

    added.push({
      id: makeId(),
      name: file.name || "fichier",
      note,
      size: file.size,
      addedAt: Date.now(),
      mime: file.type || undefined,
      dataUrl,
    });
  }

  return { added, errors };
}

export function downloadBlob(filename: string, blob: Blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export function downloadText(filename: string, text: string, mime = "application/json") {
  downloadBlob(filename, new Blob([text], { type: mime }));
}
