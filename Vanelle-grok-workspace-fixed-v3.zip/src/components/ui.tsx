import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, TextareaHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Card({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <section
      className={cn(
        "mb-3 rounded-xl border border-line bg-surface p-4 shadow-[0_8px_22px_rgba(0,0,0,0.04)]",
        className,
      )}
    >
      {children}
    </section>
  );
}

export function PageHead({
  eyebrow,
  title,
  children,
}: {
  eyebrow: string;
  title: string;
  children?: ReactNode;
}) {
  return (
    <header className="mb-4">
      <p className="mb-1 text-[10px] font-extrabold uppercase tracking-[0.16em] text-accent">
        {eyebrow}
      </p>
      <h1 className="font-display text-[1.55rem] font-extrabold leading-tight tracking-tight text-ink">
        {title}
      </h1>
      {children ? <p className="mt-1.5 text-[13px] leading-relaxed text-muted">{children}</p> : null}
    </header>
  );
}

export function Label({ children }: { children: ReactNode }) {
  return (
    <label className="mb-1.5 mt-3 block text-[12px] font-bold text-[#505057]">{children}</label>
  );
}

export function Field({
  className,
  ...props
}: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={cn(
        "h-11 w-full rounded-md border border-input-line bg-surface px-3.5 text-[14px] text-ink outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-muted/70 focus:border-accent focus:ring-2 focus:ring-accent/20",
        className,
      )}
    />
  );
}

export function Area({
  className,
  ...props
}: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={cn(
        "min-h-[80px] w-full rounded-md border border-input-line bg-surface px-3.5 py-3 text-[14px] text-ink outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-muted/70 focus:border-accent focus:ring-2 focus:ring-accent/20",
        className,
      )}
    />
  );
}

export function Btn({
  ghost,
  danger,
  className,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { ghost?: boolean; danger?: boolean }) {
  return (
    <button
      {...props}
      className={cn(
        "inline-flex min-h-11 items-center justify-center rounded-[13px] px-4 text-[14px] font-extrabold transition-[transform,opacity,background-color] duration-150 disabled:cursor-not-allowed disabled:opacity-50 active:scale-[0.98]",
        ghost
          ? "bg-[#e9e9e4] text-ink hover:bg-[#deded8]"
          : danger
            ? "bg-danger-bg text-danger hover:bg-[#fde4e0]"
            : "bg-accent text-white hover:bg-accent-deep",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Pill({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "min-h-9 rounded-sm border-[1.5px] px-3 py-2 text-[11.5px] font-bold transition-colors duration-150",
        active
          ? "border-accent bg-accent text-white"
          : "border-line bg-surface text-ink hover:border-accent/40",
      )}
    >
      {label}
    </button>
  );
}

export function Tag({ on, children }: { on: boolean; children: ReactNode }) {
  return (
    <span
      className={cn(
        "rounded-full px-2 py-0.5 text-[10.5px] font-bold",
        on ? "bg-accent-soft text-accent" : "bg-[#eee] text-muted",
      )}
    >
      {children}
    </span>
  );
}

export function ErrorBanner({
  message,
  onDismiss,
}: {
  message: string;
  onDismiss?: () => void;
}) {
  if (!message) return null;
  return (
    <button
      type="button"
      onClick={onDismiss}
      className="mb-2.5 w-full rounded-md border-[1.5px] border-danger-border bg-danger-bg p-3 text-left"
    >
      <p className="text-[13px] font-bold leading-snug text-danger">{message}</p>
      {onDismiss ? (
        <p className="mt-1 text-[11px] font-medium text-danger">Appuyez pour fermer</p>
      ) : null}
    </button>
  );
}

export function SuccessBanner({ message }: { message: string }) {
  if (!message) return null;
  return (
    <div className="mb-2.5 rounded-md border border-[#c5e0a0] bg-accent-soft p-3">
      <p className="whitespace-pre-wrap text-[13px] font-bold leading-snug text-[#3d5c0a]">
        {message}
      </p>
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return (
    <Card>
      <p className="text-[13px] leading-relaxed text-muted">{children}</p>
    </Card>
  );
}

export function Step({ n, children }: { n: number; children: ReactNode }) {
  return (
    <div className="mb-2 mt-0.5 flex items-center gap-2">
      <span className="flex size-5 items-center justify-center rounded-full bg-accent text-[11px] font-extrabold text-white">
        {n}
      </span>
      <h2 className="text-[15px] font-extrabold text-ink">{children}</h2>
    </div>
  );
}

export function Muted({ children, className }: { children: ReactNode; className?: string }) {
  return <p className={cn("text-[13px] leading-relaxed text-muted", className)}>{children}</p>;
}

export function RowKV({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between border-b border-line py-2.5">
      <span className="text-[13px] text-ink">{k}</span>
      <span className="text-[13px] font-extrabold tabular-nums text-ink">{v}</span>
    </div>
  );
}
