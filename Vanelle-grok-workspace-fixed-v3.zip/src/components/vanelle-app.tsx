import { useEffect, useState, type ReactNode } from "react";
import { getAiStatus } from "@/lib/ai.functions";
import { useVanelleStore } from "@/lib/store";
import type { AI } from "@/lib/types";
import { Bot, LayoutDashboard, Plus, UserRound } from "lucide-react";
import { AccountView } from "./account-view";
import { AIStudio } from "./ai-studio";
import { AisView } from "./ais-view";
import { CreateView } from "./create-view";
import { DashboardView } from "./dashboard-view";
import { cn } from "@/lib/utils";

type Tab = "create" | "ais" | "dashboard" | "account";

export function VanelleApp() {
  const [tab, setTab] = useState<Tab>("create");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [modelState, setModelState] = useState<"checking" | "ready" | "unavailable">("checking");

  useEffect(() => {
    let cancelled = false;
    void getAiStatus()
      .then((s) => {
        if (!cancelled) setModelState(s.available ? "ready" : "unavailable");
      })
      .catch(() => {
        if (!cancelled) setModelState("unavailable");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const open = (ai: AI) => setSelectedId(ai.id);
  const created = (ai: AI) => {
    setSelectedId(ai.id);
  };

  if (selectedId) {
    return (
      <div className="flex h-dvh min-h-dvh flex-col overflow-hidden bg-bg">
        <AIStudio aiId={selectedId} onBack={() => setSelectedId(null)} />
      </div>
    );
  }

  return (
    <div className="flex h-dvh min-h-dvh overflow-hidden bg-bg">
      <aside className="hidden w-[240px] shrink-0 flex-col bg-header text-white md:flex">
        <div className="px-5 py-6">
          <p className="font-display text-[17px] font-extrabold tracking-[0.14em]">VANELLE</p>
          <p className="mt-1 text-[10px] font-medium tracking-[0.18em] text-champagne">ATELIER IA</p>
          {modelState === "unavailable" ? (
            <p className="mt-3 text-[10px] text-[#f2b3ab]">Moteur IA indisponible.</p>
          ) : null}
          {modelState === "ready" ? (
            <p className="mt-3 text-[10px] text-champagne">IA prête</p>
          ) : null}
        </div>
        <nav className="flex flex-1 flex-col gap-0.5 px-2">
          <SideNav label="Créer" active={tab === "create"} onClick={() => setTab("create")} />
          <SideNav label="Mes IA" active={tab === "ais"} onClick={() => setTab("ais")} />
          <SideNav label="Tableau" active={tab === "dashboard"} onClick={() => setTab("dashboard")} />
          <SideNav label="Compte" active={tab === "account"} onClick={() => setTab("account")} />
        </nav>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="bg-header px-[18px] py-[18px] text-white md:hidden">
          <p className="font-display text-[17px] font-extrabold tracking-[0.14em]">VANELLE</p>
          <p className="mt-0.5 text-[9px] font-medium tracking-[0.18em] text-champagne">ATELIER IA</p>
          {modelState === "unavailable" ? (
            <p className="mt-1.5 text-[10px] text-[#f2b3ab]">Moteur IA indisponible sur cet appareil.</p>
          ) : null}
        </header>

        <main className="vanelle-scroll min-h-0 flex-1 overflow-y-auto p-4 pb-24 md:p-8 md:pb-8">
          <div className="mx-auto w-full max-w-[720px]">
            {tab === "create" && <CreateView onCreated={created} />}
            {tab === "ais" && <AisView open={open} />}
            {tab === "dashboard" && <DashboardView open={open} />}
            {tab === "account" && <AccountView />}
          </div>
        </main>

        <nav className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-4 border-t border-line bg-surface md:hidden">
          <NavBtn
            label="Créer"
            active={tab === "create"}
            onClick={() => setTab("create")}
            icon={<Plus className="size-4" />}
          />
          <NavBtn
            label="Mes IA"
            active={tab === "ais"}
            onClick={() => setTab("ais")}
            icon={<Bot className="size-4" />}
          />
          <NavBtn
            label="Tableau"
            active={tab === "dashboard"}
            onClick={() => setTab("dashboard")}
            icon={<LayoutDashboard className="size-4" />}
          />
          <NavBtn
            label="Compte"
            active={tab === "account"}
            onClick={() => setTab("account")}
            icon={<UserRound className="size-4" />}
          />
        </nav>
      </div>
    </div>
  );
}

function SideNav({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-md px-3 py-2.5 text-left text-[13px] font-bold transition-colors",
        active ? "bg-white/10 text-white" : "text-white/55 hover:bg-white/5 hover:text-white",
      )}
    >
      {label}
    </button>
  );
}

function NavBtn({
  label,
  active,
  onClick,
  icon,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
  icon: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex min-h-12 flex-col items-center justify-center gap-0.5 py-2.5 text-[10.5px] font-bold",
        active ? "bg-[#faf9ff] text-accent" : "text-[#77777d]",
      )}
    >
      {icon}
      {label}
    </button>
  );
}
