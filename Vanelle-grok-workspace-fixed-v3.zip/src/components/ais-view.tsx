import { useState } from "react";
import { useVanelleStore } from "@/lib/store";
import type { AI } from "@/lib/types";
import { Btn, Card, Empty, PageHead, Tag } from "./ui";

export function AisView({ open }: { open: (ai: AI) => void }) {
  const ais = useVanelleStore((s) => s.ais);
  const deleteAI = useVanelleStore((s) => s.deleteAI);
  const [confirming, setConfirming] = useState<string | null>(null);
  const sorted = [...ais].sort((a, b) => b.createdAt - a.createdAt);

  return (
    <div>
      <PageHead eyebrow="Atelier" title="Mes IA">
        {`${sorted.length} IA en cours de construction.`}
      </PageHead>
      {sorted.length === 0 ? (
        <Empty>Vous n'avez encore créé aucune IA.</Empty>
      ) : (
        sorted.map((item) => (
          <Card key={item.id}>
            <button type="button" className="w-full text-left" onClick={() => open(item)}>
              <div className="flex items-center justify-between gap-3">
                <h2 className="text-[14.5px] font-extrabold">{item.name}</h2>
                <Tag on={item.deployed}>{item.deployed ? "déployée" : "en cours"}</Tag>
              </div>
              <p className="mt-1 text-[13px] text-muted">
                {item.description || "Pas encore de description."}
              </p>
              <p className="mt-1 text-[11px] text-muted">
                {item.files.length} fichier(s) · {item.training.length} notion(s) · {item.apis.length}{" "}
                API
              </p>
            </button>
            <Btn
              ghost
              className="mt-2.5 w-full"
              onClick={() => {
                if (confirming !== item.id) {
                  setConfirming(item.id);
                  return;
                }
                setConfirming(null);
                deleteAI(item.id);
              }}
            >
              {confirming === item.id ? "Confirmer la suppression" : "Supprimer"}
            </Btn>
          </Card>
        ))
      )}
    </div>
  );
}
