import { useVanelleStore } from "@/lib/store";
import type { AI } from "@/lib/types";
import { Card, PageHead } from "./ui";

export function DashboardView({ open }: { open: (ai: AI) => void }) {
  const ais = useVanelleStore((s) => s.ais);
  const totalTraining = ais.reduce((s, a) => s + a.training.length, 0);
  const totalFiles = ais.reduce((s, a) => s + a.files.length, 0);
  const totalApis = ais.reduce((s, a) => s + a.apis.length, 0);
  const deployed = ais.filter((a) => a.deployed).length;
  const stats = [
    { num: ais.length, lbl: "IA créées" },
    { num: deployed, lbl: "déployées" },
    { num: totalTraining, lbl: "notions enseignées" },
    { num: totalFiles, lbl: "fichiers analysés" },
    { num: totalApis, lbl: "API connectées" },
  ];

  return (
    <div>
      <PageHead eyebrow="Vue d'ensemble" title="Tableau de bord">
        L'état de tout ce que vous construisez ici.
      </PageHead>
      <div className="mb-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
        {stats.map((s) => (
          <div
            key={s.lbl}
            className="rounded-md border border-line bg-surface p-3.5"
          >
            <p className="font-display text-[26px] font-extrabold tabular-nums leading-none text-accent">
              {s.num}
            </p>
            <p className="mt-1.5 text-[11px] font-bold text-muted">{s.lbl}</p>
          </div>
        ))}
      </div>
      <Card>
        <h2 className="text-[15px] font-extrabold">Progression par IA</h2>
        {ais.length === 0 ? (
          <p className="mt-2 text-[13px] text-muted">Rien à afficher pour l'instant.</p>
        ) : (
          [...ais]
            .sort((a, b) => b.createdAt - a.createdAt)
            .map((ai) => (
              <button
                key={ai.id}
                type="button"
                className="block w-full border-b border-line py-2.5 text-left last:border-0"
                onClick={() => open(ai)}
              >
                <p className="font-bold">{ai.name}</p>
                <p className="text-[11.5px] text-muted">
                  {ai.training.length} notions · {ai.files.length} fichiers · {ai.apis.length} API
                </p>
              </button>
            ))
        )}
      </Card>
    </div>
  );
}
