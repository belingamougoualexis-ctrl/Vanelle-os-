import { useState } from "react";
import { downloadText } from "@/lib/files";
import { useVanelleStore } from "@/lib/store";
import { Area, Btn, Card, ErrorBanner, Field, Label, PageHead, SuccessBanner } from "./ui";

export function AccountView() {
  const profile = useVanelleStore((s) => s.profile);
  const saveProfile = useVanelleStore((s) => s.saveProfile);
  const ais = useVanelleStore((s) => s.ais);
  const chats = useVanelleStore((s) => s.chats);
  const importBundle = useVanelleStore((s) => s.importBundle);
  const [pseudo, setPseudo] = useState(profile.pseudo);
  const [importText, setImportText] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [exporting, setExporting] = useState(false);

  const exportAll = () => {
    setError("");
    setNote("");
    setExporting(true);
    try {
      const payload = JSON.stringify(
        {
          version: 2,
          exportedAt: new Date().toISOString(),
          profile: { ...profile, pseudo },
          ais: ais.map((ai) => ({
            ...ai,
            apis: ai.apis.map(({ secretRef: _s, ...api }) => api),
          })),
          chats,
        },
        null,
        2,
      );
      const fileName = `vanelle-sauvegarde-${Date.now()}.json`;
      downloadText(fileName, payload);
      setNote(
        `Export terminé. Fichier : ${fileName}\nContient profil, ${ais.length} IA (prompt, tokens, température, notions, fichiers, API sans secrets) et chats.`,
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "L'export a échoué.");
    } finally {
      setExporting(false);
    }
  };

  const importAll = () => {
    setError("");
    setNote("");
    try {
      const data = JSON.parse(importText) as {
        profile?: { pseudo?: string };
        ais?: typeof ais;
        chats?: typeof chats;
      };
      importBundle({
        profile: data.profile ? { pseudo: data.profile.pseudo ?? "" } : undefined,
        ais: data.ais,
        chats: data.chats,
      });
      if (data.profile?.pseudo) setPseudo(data.profile.pseudo);
      setImportText("");
      setNote("Sauvegarde importée (profil, IA, API, fichiers, notions, chats).");
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Ce texte n'a pas pu être lu comme sauvegarde JSON.",
      );
    }
  };

  return (
    <div>
      <PageHead eyebrow="Compte" title="Compte">
        Vos IA restent sur cet appareil.
      </PageHead>
      {error ? <ErrorBanner message={error} onDismiss={() => setError("")} /> : null}
      {note && !error ? <SuccessBanner message={note} /> : null}

      <Card>
        <h2 className="text-[15px] font-extrabold">Profil</h2>
        <Label>Votre nom ou pseudo</Label>
        <Field
          value={pseudo}
          onChange={(e) => setPseudo(e.target.value)}
          placeholder="Ex. Camille"
        />
        <Btn
          className="mt-2.5 w-full"
          onClick={() => {
            saveProfile({ pseudo });
            setNote("Profil enregistré.");
          }}
        >
          Enregistrer
        </Btn>
      </Card>

      <Card>
        <h2 className="text-[15px] font-extrabold">Sauvegarde complète</h2>
        <p className="mt-1 text-[13px] leading-relaxed text-muted">
          L'export inclut tout : profil, chaque IA (systemPrompt, maxTokens, temperature, style,
          traits), notions d'apprentissage, fichiers (notes/extraits), API (sans secrets), et
          historiques de chat. À l'import, les données s'ajoutent / mettent à jour sans tout
          effacer.
        </p>
        <Btn ghost className="mt-2.5 w-full" disabled={exporting} onClick={exportAll}>
          {exporting ? "Export en cours…" : "Exporter toutes mes données"}
        </Btn>
        <Label>Coller une sauvegarde (.json)</Label>
        <Area
          value={importText}
          onChange={(e) => setImportText(e.target.value)}
          placeholder="{ ...contenu du fichier vanelle-sauvegarde.json... }"
        />
        <Btn ghost className="mt-2 w-full" disabled={!importText.trim()} onClick={importAll}>
          Importer
        </Btn>
      </Card>
    </div>
  );
}
