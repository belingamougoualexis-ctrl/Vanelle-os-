import { useEffect, useRef, useState } from "react";
import { buildAIZip } from "@/lib/ai-package";
import { ingestFiles, downloadBlob } from "@/lib/files";
import { testConfiguredApi, type ApiTestResult } from "@/lib/ai.functions";
import { useVanelleStore } from "@/lib/store";
import { CATEGORIES, type AI, type Training, type UserApi } from "@/lib/types";
import { fmtSize, makeId } from "@/lib/utils";
import { toast } from "sonner";
import { ApiEditor } from "./api-editor";
import { ChatView } from "./chat-view";
import {
  Area,
  Btn,
  Card,
  ErrorBanner,
  Field,
  Label,
  Muted,
  Pill,
  RowKV,
  Step,
  SuccessBanner,
  Tag,
} from "./ui";

type SubTab = "vue" | "apprentissage" | "fichiers" | "api" | "tester";

export function AIStudio({
  aiId,
  onBack,
  startInChat,
}: {
  aiId: string;
  onBack: () => void;
  startInChat?: boolean;
}) {
  const ai = useVanelleStore((s) => s.ais.find((x) => x.id === aiId));
  const saveAI = useVanelleStore((s) => s.saveAI);
  const [tab, setTab] = useState<SubTab>(startInChat ? "tester" : "vue");

  if (!ai) {
    return (
      <div className="p-6">
        <p className="text-muted">Cette IA n'existe plus.</p>
        <Btn className="mt-3" onClick={onBack}>
          Retour
        </Btn>
      </div>
    );
  }

  const save = (next: AI) => {
    saveAI(next);
  };

  if (tab === "tester") {
    return <ChatView ai={ai} back={() => setTab("vue")} onSave={save} />;
  }

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col">
      <header className="bg-header px-4 py-4 text-white">
        <div className="flex items-center justify-between gap-3">
          <button type="button" className="min-h-10 text-[14px] font-extrabold" onClick={onBack}>
            ‹ Retour
          </button>
          <p className="truncate font-display text-[15px] font-extrabold tracking-[0.08em]">
            « {ai.name} »
          </p>
          <span className="w-16" />
        </div>
        <p className="mt-1 text-[11px] text-champagne">
          {ai.description || "Pas encore de description."}
        </p>
      </header>
      <div className="border-b border-line bg-surface px-4 pt-3">
        <div className="flex flex-wrap gap-1.5 pb-3">
          <Pill label="Vue d'ensemble" active={tab === "vue"} onClick={() => setTab("vue")} />
          <Pill
            label="Apprentissage"
            active={tab === "apprentissage"}
            onClick={() => setTab("apprentissage")}
          />
          <Pill label="Fichiers" active={tab === "fichiers"} onClick={() => setTab("fichiers")} />
          <Pill label="API" active={tab === "api"} onClick={() => setTab("api")} />
          <Pill label="Chat" active={false} onClick={() => setTab("tester")} />
        </div>
      </div>
      <div className="vanelle-scroll min-h-0 flex-1 overflow-y-auto bg-bg p-4">
        {tab === "vue" && (
          <TabVue ai={ai} onSave={save} onDeleted={onBack} onTest={() => setTab("tester")} />
        )}
        {tab === "apprentissage" && <TabApprentissage ai={ai} onSave={save} />}
        {tab === "fichiers" && <TabFichiers ai={ai} onSave={save} />}
        {tab === "api" && <TabApi ai={ai} onSave={save} />}
      </div>
    </div>
  );
}

function TraitApiPicker({
  ai,
  traitIndex,
  onSave,
}: {
  ai: AI;
  traitIndex: number;
  onSave: (ai: AI) => void;
}) {
  const linked = ai.apis.filter((a) => (a.linkedTraits ?? []).includes(traitIndex));
  const toggle = (api: UserApi) => {
    const set = new Set(api.linkedTraits ?? []);
    if (set.has(traitIndex)) set.delete(traitIndex);
    else set.add(traitIndex);
    onSave({
      ...ai,
      apis: ai.apis.map((x) =>
        x.id === api.id ? { ...x, linkedTraits: Array.from(set).sort() } : x,
      ),
    });
  };
  return (
    <div className="mt-2 rounded-md border border-line bg-surface-alt p-2.5">
      <p className="text-[11px] font-bold text-muted">API liées à ce trait (plusieurs possibles)</p>
      {ai.apis.length === 0 ? (
        <p className="mt-1 text-[12px] text-muted">
          Aucune API pour l'instant — ajoutez-en ci-dessous.
        </p>
      ) : (
        <div className="mt-1.5 flex flex-wrap gap-1.5">
          {ai.apis.map((api) => {
            const on = (api.linkedTraits ?? []).includes(traitIndex);
            return (
              <button
                key={api.id}
                type="button"
                onClick={() => toggle(api)}
                className={`min-h-8 rounded-full border px-2.5 text-[11px] font-bold ${
                  on
                    ? "border-accent bg-accent text-white"
                    : "border-line bg-surface text-ink"
                }`}
              >
                {api.name}
              </button>
            );
          })}
        </div>
      )}
      {linked.length ? (
        <p className="mt-1.5 text-[11px] text-muted">
          {linked.length} API rattachée{linked.length > 1 ? "s" : ""}
        </p>
      ) : null}
    </div>
  );
}

function TabVue({
  ai,
  onSave,
  onDeleted,
  onTest,
}: {
  ai: AI;
  onSave: (ai: AI) => void;
  onDeleted: () => void;
  onTest: () => void;
}) {
  const deleteAI = useVanelleStore((s) => s.deleteAI);
  const chats = useVanelleStore((s) => s.chats);
  const attachApi = useVanelleStore((s) => s.attachApi);
  const [name, setName] = useState(ai.name);
  const [description, setDescription] = useState(ai.description);
  const [style, setStyle] = useState(ai.style);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState("");
  const [exportNote, setExportNote] = useState("");
  const [trait1, setTrait1] = useState(ai.traits?.[0] ?? "");
  const [trait2, setTrait2] = useState(ai.traits?.[1] ?? "");
  const [trait3, setTrait3] = useState(ai.traits?.[2] ?? "");
  const [systemPrompt, setSystemPrompt] = useState(ai.systemPrompt ?? "");
  const [maxTokens, setMaxTokens] = useState(String(ai.maxTokens ?? 700));
  const [temperature, setTemperature] = useState(String(ai.temperature ?? 0.4));
  const [personaSaved, setPersonaSaved] = useState(false);
  const [showApiForm, setShowApiForm] = useState(false);
  const isNew = ai.training.length === 0 && ai.files.length === 0 && ai.apis.length === 0;

  useEffect(() => {
    setName(ai.name);
    setDescription(ai.description);
    setStyle(ai.style);
    setTrait1(ai.traits?.[0] ?? "");
    setTrait2(ai.traits?.[1] ?? "");
    setTrait3(ai.traits?.[2] ?? "");
    setSystemPrompt(ai.systemPrompt ?? "");
    setMaxTokens(String(ai.maxTokens ?? 700));
    setTemperature(String(Number(ai.temperature ?? 0.4).toFixed(1)));
  }, [ai.id]);

  const exportZip = async () => {
    setExportError("");
    setExportNote("");
    setExporting(true);
    try {
      const blob = await buildAIZip(ai, chats[ai.id] ?? []);
      const fileName = `${ai.name.replace(/\s+/g, "-").toLowerCase()}-vanelle-ia.zip`;
      downloadBlob(fileName, blob);
      setExportNote(
        `IA exportée en .zip : ${fileName} (notions, fichiers, API sans secrets, prompt, chat de test).`,
      );
      toast.success("IA exportée");
    } catch (e) {
      setExportError(e instanceof Error ? e.message : "L'export du .zip a échoué.");
    } finally {
      setExporting(false);
    }
  };

  return (
    <div>
      {isNew ? (
        <Card className="border-accent/30 bg-accent-soft/40">
          <h2 className="text-[15px] font-extrabold">Votre atelier est ouvert</h2>
          <Muted className="mt-1">
            Ajoutez les 3 traits, reliez-y une ou plusieurs API, puis déposez des fichiers (3 Go max
            chacun). Tout se fait ici, sans revenir en arrière.
          </Muted>
        </Card>
      ) : null}

      {exportError ? <ErrorBanner message={exportError} onDismiss={() => setExportError("")} /> : null}
      {exportNote && !exportError ? <SuccessBanner message={exportNote} /> : null}

      <Card>
        <h2 className="mb-1 text-[15px] font-extrabold">Fiche d'identité</h2>
        <Label>Nom de l'IA</Label>
        <Field value={name} onChange={(e) => setName(e.target.value)} />
        <Label>Description</Label>
        <Area value={description} onChange={(e) => setDescription(e.target.value)} />
        <Label>Style de base</Label>
        <Field value={style} onChange={(e) => setStyle(e.target.value)} />
        <Btn
          className="mt-3 w-full"
          disabled={!name.trim()}
          onClick={() => {
            onSave({
              ...ai,
              name: name.trim() || ai.name,
              description: description.trim(),
              style,
            });
            toast.success("Fiche enregistrée");
          }}
        >
          Enregistrer la fiche
        </Btn>
        <Btn
          ghost
          className="mt-2 w-full"
          onClick={() => {
            if (!confirmingDelete) {
              setConfirmingDelete(true);
              return;
            }
            deleteAI(ai.id);
            onDeleted();
          }}
        >
          {confirmingDelete ? "Confirmer la suppression" : "Supprimer cette IA"}
        </Btn>
      </Card>

      <Card>
        <h2 className="mb-1 text-[15px] font-extrabold">Personnalité — 3 traits</h2>
        <Muted>
          Ces 3 traits décrivent le caractère de l'IA et sont injectés dans son prompt système à
          chaque message. Vous pouvez y rattacher une ou plusieurs API — l'IA saura lesquelles
          utiliser selon le trait.
        </Muted>
        <Label>Trait 1</Label>
        <Field value={trait1} onChange={(e) => setTrait1(e.target.value)} placeholder="Ex. Chaleureuse" />
        <TraitApiPicker ai={ai} traitIndex={0} onSave={onSave} />
        <Label>Trait 2</Label>
        <Field value={trait2} onChange={(e) => setTrait2(e.target.value)} placeholder="Ex. Directe" />
        <TraitApiPicker ai={ai} traitIndex={1} onSave={onSave} />
        <Label>Trait 3</Label>
        <Field value={trait3} onChange={(e) => setTrait3(e.target.value)} placeholder="Ex. Curieuse" />
        <TraitApiPicker ai={ai} traitIndex={2} onSave={onSave} />

        <div className="mt-3 border-t border-line pt-3">
          <p className="text-[12px] font-bold text-[#505057]">Connecter une ou plusieurs API</p>
          <Muted className="mt-1">
            Les API ajoutées ici sont disponibles pour le chat et peuvent être liées aux 3 traits
            ci-dessus.
          </Muted>
          {ai.apis.length ? (
            <ul className="mt-2 space-y-1.5">
              {ai.apis.map((a) => (
                <li key={a.id} className="rounded-md border border-line bg-surface-alt px-3 py-2">
                  <p className="text-[13px] font-bold">{a.name}</p>
                  <p className="text-[11px] text-muted">
                    {a.method} · {a.endpoint}
                  </p>
                </li>
              ))}
            </ul>
          ) : null}
          {showApiForm ? (
            <div className="mt-2">
              <ApiEditor
                compact
                onAdd={(api, secret) => {
                  attachApi(ai.id, api, secret);
                  toast.success(`${api.name} connectée`);
                  setShowApiForm(false);
                }}
              />
            </div>
          ) : (
            <Btn ghost className="mt-2 w-full" onClick={() => setShowApiForm(true)}>
              Ajouter une API
            </Btn>
          )}
        </div>

        <Label>Prompt système</Label>
        <Muted>
          Instructions libres qui s'ajoutent aux traits pour cadrer le comportement de l'IA —
          modifiable à tout moment.
        </Muted>
        <Area
          className="mt-2 min-h-[100px]"
          value={systemPrompt}
          onChange={(e) => setSystemPrompt(e.target.value)}
          placeholder="Ex. Tu es l'assistante de la boutique, réponds toujours en français, reste concise."
        />
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Max tokens</Label>
            <Field
              type="number"
              min={128}
              max={2000}
              value={maxTokens}
              onChange={(e) => setMaxTokens(e.target.value)}
            />
          </div>
          <div>
            <Label>Température</Label>
            <Field
              type="number"
              min={0}
              max={1.4}
              step={0.1}
              value={temperature}
              onChange={(e) => setTemperature(e.target.value)}
            />
          </div>
        </div>
        {personaSaved ? (
          <SuccessBanner message="Personnalité et prompt système enregistrés." />
        ) : null}
        <Btn
          className="mt-3 w-full"
          onClick={() => {
            onSave({
              ...ai,
              traits: [trait1.trim(), trait2.trim(), trait3.trim()],
              systemPrompt,
              maxTokens: Math.min(2000, Math.max(128, Number(maxTokens) || 700)),
              temperature: Math.min(1.4, Math.max(0, Number(temperature) || 0.4)),
            });
            setPersonaSaved(true);
            toast.success("Personnalité enregistrée");
          }}
        >
          Enregistrer la personnalité
        </Btn>
      </Card>

      <TabFichiers ai={ai} onSave={onSave} compact />

      <Card>
        <h2 className="text-[15px] font-extrabold">Résumé</h2>
        <RowKV k="Notions enseignées" v={String(ai.training.length)} />
        <RowKV k="Fichiers analysés" v={String(ai.files.length)} />
        <RowKV k="API connectées" v={String(ai.apis.length)} />
        <div className="flex items-center justify-between py-2.5">
          <span className="text-[13px]">Statut</span>
          <Tag on={ai.deployed}>{ai.deployed ? "déployée" : "brouillon"}</Tag>
        </div>
        <Btn
          ghost
          className="mt-2 w-full"
          onClick={() => {
            onSave({ ...ai, deployed: true, deployedAt: Date.now() });
            toast.success("IA marquée déployée");
          }}
        >
          Marquer déployée
        </Btn>
      </Card>

      <Card>
        <h2 className="text-[15px] font-extrabold">Exporter cette IA</h2>
        <Muted>
          Un .zip contenant tout ce qui fait cette IA : identité, style, prompt système, notions
          enseignées, fichiers connaissances, API documentées et l'historique du chat de test.
          Réimportable pour continuer l'apprentissage ailleurs. Les secrets API ne sont pas inclus.
        </Muted>
        <Btn ghost className="mt-2.5 w-full" disabled={exporting} onClick={() => void exportZip()}>
          {exporting ? "Préparation du .zip…" : "Exporter en .zip"}
        </Btn>
      </Card>

      <Btn className="mb-6 mt-1 w-full" onClick={onTest}>
        Ouvrir le chat de test
      </Btn>
    </div>
  );
}

function TabApprentissage({ ai, onSave }: { ai: AI; onSave: (ai: AI) => void }) {
  const [category, setCategory] = useState<string>(CATEGORIES[0]);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");

  return (
    <div>
      <Card>
        <Step n={1}>Enseigner une notion</Step>
        <Muted>
          Ces paires question/réponse sont injectées dans le prompt système à chaque message.
        </Muted>
        <Label>Catégorie</Label>
        <div className="mt-2 flex flex-wrap gap-1.5">
          {CATEGORIES.map((c) => (
            <Pill key={c} label={c} active={category === c} onClick={() => setCategory(c)} />
          ))}
        </div>
        <Label>Question / situation</Label>
        <Field
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="Ex. Comment te présenter ?"
        />
        <Label>Réponse attendue</Label>
        <Area
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          placeholder="Ex. Je suis un assistant concis et bienveillant."
        />
        <Btn
          className="mt-3 w-full"
          disabled={!question.trim() || !answer.trim()}
          onClick={() => {
            const t: Training = {
              id: makeId(),
              category,
              question: question.trim(),
              answer: answer.trim(),
              ts: Date.now(),
            };
            onSave({ ...ai, training: [...ai.training, t] });
            setQuestion("");
            setAnswer("");
            toast.success("Notion ajoutée");
          }}
        >
          Ajouter la notion
        </Btn>
      </Card>

      <Card>
        <h2 className="text-[15px] font-extrabold">Notions enregistrées ({ai.training.length})</h2>
        {ai.training.length === 0 ? (
          <Muted className="mt-2">Rien pour l'instant — commencez par son identité.</Muted>
        ) : (
          CATEGORIES.map((c) => {
            const items = ai.training.filter((t) => t.category === c);
            if (!items.length) return null;
            return (
              <div key={c}>
                <p className="mt-2.5 text-[12px] font-bold text-muted">{c}</p>
                {items.map((t) => (
                  <div key={t.id} className="border-b border-line py-2.5">
                    <p className="text-[13px] font-bold">{t.question}</p>
                    <p className="text-[13px] text-muted">{t.answer}</p>
                    <Btn
                      ghost
                      className="mt-1.5 h-9 min-h-9 self-start px-3.5"
                      onClick={() =>
                        onSave({ ...ai, training: ai.training.filter((x) => x.id !== t.id) })
                      }
                    >
                      Retirer
                    </Btn>
                  </div>
                ))}
              </div>
            );
          })
        )}
      </Card>
    </div>
  );
}

function TabFichiers({
  ai,
  onSave,
  compact,
}: {
  ai: AI;
  onSave: (ai: AI) => void;
  compact?: boolean;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");

  const upload = async (list: FileList | null) => {
    if (!list?.length) return;
    setBusy(true);
    setStatus("");
    setError("");
    try {
      const { added, errors } = await ingestFiles(list);
      if (errors.length) setError(errors.join(" "));
      if (added.length) {
        onSave({ ...ai, files: [...ai.files, ...added] });
        setStatus(
          `${added.length} fichier(s) ajouté(s) — le chat s'en sert désormais. Anciennes données conservées.`,
        );
        toast.success("Connaissances mises à jour");
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "L'ajout du fichier a échoué.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      {error ? <ErrorBanner message={error} onDismiss={() => setError("")} /> : null}
      {status ? <SuccessBanner message={status} /> : null}
      <Card>
        {compact ? (
          <h2 className="text-[15px] font-extrabold">Fichiers de connaissance</h2>
        ) : (
          <Step n={1}>Ajouter des données</Step>
        )}
        <Muted className="mt-1">
          TXT, MD, CSV, JSON, HTML, JS, CSS : le contenu est extrait et vraiment utilisé par le chat.
          Images et autres formats sont conservés comme référence. Limite : 3 Go par fichier (pas
          sur le total). Chaque ajout s'empile — rien n'est écrasé sauf si vous retirez
          explicitement un fichier.
        </Muted>
        <input
          ref={inputRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => {
            const files = e.target.files;
            e.target.value = "";
            void upload(files);
          }}
        />
        <Btn
          className="mt-3 w-full"
          disabled={busy}
          onClick={() => inputRef.current?.click()}
        >
          {busy ? "Lecture…" : "Uploader un fichier"}
        </Btn>
      </Card>
      <Card>
        <h2 className="text-[15px] font-extrabold">Fichiers analysés ({ai.files.length})</h2>
        {ai.files.length === 0 ? (
          <Muted className="mt-2">Aucun fichier pour l'instant.</Muted>
        ) : (
          ai.files.map((f) => (
            <div key={f.id} className="border-b border-line py-2.5 last:border-0">
              <p className="text-[13px] font-bold">{f.name}</p>
              <p className="text-[11px] text-muted">{fmtSize(f.size)}</p>
              <p className="text-[13px] text-muted">{f.note.slice(0, 140)}</p>
              <Btn
                ghost
                className="mt-1.5 h-9 min-h-9 px-3.5"
                onClick={() => onSave({ ...ai, files: ai.files.filter((x) => x.id !== f.id) })}
              >
                Retirer
              </Btn>
            </div>
          ))
        )}
      </Card>
    </div>
  );
}

function TabApi({ ai, onSave }: { ai: AI; onSave: (ai: AI) => void }) {
  const attachApi = useVanelleStore((s) => s.attachApi);
  const getSecret = useVanelleStore((s) => s.getSecret);
  const deleteSecret = useVanelleStore((s) => s.deleteSecret);
  const [testing, setTesting] = useState<string | null>(null);
  const [testResult, setTestResult] = useState("");
  const [testError, setTestError] = useState("");

  const testApi = async (api: UserApi) => {
    setTesting(api.id);
    setTestResult("");
    setTestError("");
    try {
      const secret = getSecret(api.secretRef);
      const auth =
        api.authType === "apiKey"
          ? { type: "apiKey" as const, key: secret || "", header: api.authHeader || "X-API-Key" }
          : api.authType === "bearer"
            ? { type: "bearer" as const, token: secret || "" }
            : api.authType === "basic"
              ? { type: "basic" as const, username: api.username || "", password: secret || "" }
              : { type: "none" as const };
      const result = (await testConfiguredApi({
        data: {
          endpoint: api.endpoint,
          method: api.method,
          auth,
          query: api.queryParams,
          headers: api.requestHeaders,
          body: api.body,
          timeoutMs: api.timeoutMs || 15000,
          retries: api.retries ?? 2,
          retryNonIdempotent: api.retryNonIdempotent,
        },
      })) as ApiTestResult;
      if (!result.ok) throw new Error(`HTTP ${result.status} ${result.statusText || ""}`.trim());
      setTestResult(`Connexion OK · HTTP ${result.status} · ${result.elapsedMs} ms\n${result.preview}`);
    } catch (e) {
      setTestError(e instanceof Error ? e.message : "Échec de l'appel API.");
    } finally {
      setTesting(null);
    }
  };

  return (
    <div>
      {testError ? <ErrorBanner message={testError} onDismiss={() => setTestError("")} /> : null}
      {testResult ? <SuccessBanner message={testResult} /> : null}
      <Card>
        <h2 className="text-[15px] font-extrabold">Connecter une API</h2>
        <ApiEditor
          onAdd={(api, secret) => {
            attachApi(ai.id, api, secret);
            toast.success(`${api.name} connectée`);
          }}
        />
      </Card>
      <Card>
        <h2 className="text-[15px] font-extrabold">Intégrations API ({ai.apis.length})</h2>
        {ai.apis.length === 0 ? (
          <Muted className="mt-2">Aucune API configurée.</Muted>
        ) : (
          ai.apis.map((a) => (
            <div key={a.id} className="border-b border-line py-2.5 last:border-0">
              <p className="text-[13px] font-bold">{a.name}</p>
              <p className="text-[13px] text-muted">
                {a.endpoint} · {a.method}
                {a.protocol && a.protocol !== "rest" ? ` · ${a.protocol}` : ""}
              </p>
              {a.description ? <p className="text-[13px] text-muted">{a.description}</p> : null}
              {(a.linkedTraits ?? []).length ? (
                <p className="mt-1 text-[11px] text-accent">
                  Liée aux traits{" "}
                  {(a.linkedTraits ?? [])
                    .map((i) => ai.traits[i] || `Trait ${i + 1}`)
                    .join(" · ")}
                </p>
              ) : null}
              <div className="mt-1.5 flex flex-wrap gap-2">
                <Btn
                  ghost
                  className="h-9 min-h-9 px-3.5"
                  disabled={testing === a.id}
                  onClick={() => void testApi(a)}
                >
                  {testing === a.id ? "Test…" : "Tester"}
                </Btn>
                <Btn
                  ghost
                  className="h-9 min-h-9 px-3.5"
                  onClick={() => {
                    if (a.secretRef) deleteSecret(a.secretRef);
                    onSave({ ...ai, apis: ai.apis.filter((x) => x.id !== a.id) });
                  }}
                >
                  Retirer
                </Btn>
              </div>
            </div>
          ))
        )}
      </Card>
    </div>
  );
}
