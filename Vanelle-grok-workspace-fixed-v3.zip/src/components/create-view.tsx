import { useRef, useState } from "react";
import { parseAIZip } from "@/lib/ai-package";
import { useVanelleStore } from "@/lib/store";
import { blankAI, type AI } from "@/lib/types";
import { toast } from "sonner";
import { Area, Btn, Card, ErrorBanner, Field, Label, PageHead, SuccessBanner } from "./ui";

export function CreateView({ onCreated }: { onCreated: (ai: AI) => void }) {
  const saveAI = useVanelleStore((s) => s.saveAI);
  const saveChat = useVanelleStore((s) => s.saveChat);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [style, setStyle] = useState("Généraliste");
  const [busy, setBusy] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importError, setImportError] = useState("");
  const [importNote, setImportNote] = useState("");
  const zipRef = useRef<HTMLInputElement>(null);

  const importZip = async (file: File) => {
    setImportError("");
    setImportNote("");
    setImporting(true);
    try {
      if (!file.name.toLowerCase().endsWith(".zip")) {
        throw new Error("Choisissez un fichier .zip exporté depuis Vanelle.");
      }
      const { ai, chat } = await parseAIZip(file);
      saveAI(ai);
      if (chat.length) saveChat(ai.id, chat);
      setImportNote(
        `IA importée avec ${ai.training.length} notion(s) et ${ai.files.length} fichier(s). Ouverture de la fiche.`,
      );
      toast.success(`${ai.name} importée`);
      onCreated(ai);
    } catch (e) {
      setImportError(e instanceof Error ? e.message : "L'import du .zip a échoué.");
    } finally {
      setImporting(false);
    }
  };

  return (
    <div>
      <PageHead eyebrow="Étape 0" title="Créer une nouvelle IA">
        Donnez-lui un nom et un point de départ, puis enseignez-lui ce qu'elle doit savoir —
        notions, fichiers, API — depuis sa fiche.
      </PageHead>
      {importError ? <ErrorBanner message={importError} onDismiss={() => setImportError("")} /> : null}
      {importNote && !importError ? <SuccessBanner message={importNote} /> : null}

      <Card>
        <h2 className="text-[15px] font-extrabold">Importer une IA (.zip)</h2>
        <p className="mt-1 text-[13px] leading-relaxed text-muted">
          Reprenez une IA exportée depuis Vanelle — son apprentissage continue là où vous l'avez
          laissé.
        </p>
        <input
          ref={zipRef}
          type="file"
          accept=".zip,application/zip"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            e.target.value = "";
            if (f) void importZip(f);
          }}
        />
        <Btn
          ghost
          className="mt-2.5 w-full"
          disabled={importing}
          onClick={() => zipRef.current?.click()}
        >
          {importing ? "Import en cours…" : "Choisir un .zip"}
        </Btn>
      </Card>

      <Card>
        <Label>Nom</Label>
        <Field
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Ex. Solutions Pro"
        />
        <Label>Description</Label>
        <Area
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="En une phrase, à quoi sert cette IA ?"
        />
        <Label>Style</Label>
        <Field value={style} onChange={(e) => setStyle(e.target.value)} />
        <Btn
          className="mt-3 w-full"
          disabled={busy || !name.trim()}
          onClick={() => {
            setBusy(true);
            try {
              const ai = blankAI(name.trim(), description.trim(), style);
              saveAI(ai);
              onCreated(ai);
            } finally {
              setBusy(false);
            }
          }}
        >
          {busy ? "Création…" : "Commencer l'apprentissage"}
        </Btn>
      </Card>
    </div>
  );
}
