import { useState } from "react";
import { testConfiguredApi, type ApiTestResult } from "@/lib/ai.functions";
import type { AuthType, HttpMethod, ApiProtocol, UserApi } from "@/lib/types";
import { makeId } from "@/lib/utils";
import { Area, Btn, ErrorBanner, Field, Label, Pill, SuccessBanner } from "./ui";

const METHODS: HttpMethod[] = ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"];
const PROTOCOLS: ApiProtocol[] = [
  "rest",
  "graphql",
  "sse",
  "websocket",
  "multipart",
  "binary",
  "mtls",
  "custom",
];
const AUTHS: AuthType[] = ["none", "apiKey", "bearer", "basic"];

function parseJsonObject(raw: string): Record<string, string> | undefined {
  if (!raw.trim()) return undefined;
  try {
    const v = JSON.parse(raw) as unknown;
    if (v && typeof v === "object" && !Array.isArray(v)) {
      const out: Record<string, string> = {};
      for (const [k, val] of Object.entries(v as Record<string, unknown>)) {
        out[k] = String(val);
      }
      return out;
    }
  } catch {
    /* ignore */
  }
  return undefined;
}

export function ApiEditor({
  onAdd,
  compact,
}: {
  onAdd: (api: UserApi, secret?: string) => void;
  compact?: boolean;
}) {
  const [name, setName] = useState("");
  const [endpoint, setEndpoint] = useState("");
  const [method, setMethod] = useState<HttpMethod>("GET");
  const [protocol, setProtocol] = useState<ApiProtocol>("rest");
  const [description, setDescription] = useState("");
  const [authType, setAuthType] = useState<AuthType>("none");
  const [secret, setSecret] = useState("");
  const [username, setUsername] = useState("");
  const [headersText, setHeadersText] = useState("");
  const [queryText, setQueryText] = useState("");
  const [bodyText, setBodyText] = useState("");
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState("");
  const [testError, setTestError] = useState("");
  const [advanced, setAdvanced] = useState(false);

  const reset = () => {
    setName("");
    setEndpoint("");
    setDescription("");
    setSecret("");
    setUsername("");
    setHeadersText("");
    setQueryText("");
    setBodyText("");
  };

  const buildApi = (): UserApi => ({
    id: makeId(),
    name: name.trim(),
    endpoint: endpoint.trim(),
    method,
    protocol,
    description: description.trim(),
    authType,
    authHeader: authType === "apiKey" ? username.trim() || "X-API-Key" : undefined,
    username: authType === "basic" ? username.trim() : undefined,
    requestHeaders: parseJsonObject(headersText),
    queryParams: parseJsonObject(queryText),
    body: bodyText.trim() || undefined,
    timeoutMs: 15000,
    retries: 2,
    retryNonIdempotent: false,
    linkedTraits: [],
    ts: Date.now(),
  });

  const test = async () => {
    setTesting(true);
    setTestResult("");
    setTestError("");
    try {
      const auth =
        authType === "apiKey"
          ? { type: "apiKey" as const, key: secret, header: username.trim() || "X-API-Key" }
          : authType === "bearer"
            ? { type: "bearer" as const, token: secret }
            : authType === "basic"
              ? { type: "basic" as const, username: username.trim(), password: secret }
              : { type: "none" as const };
      const result = (await testConfiguredApi({
        data: {
          endpoint: endpoint.trim(),
          method,
          auth,
          query: parseJsonObject(queryText),
          headers: parseJsonObject(headersText),
          body: bodyText.trim() || undefined,
          timeoutMs: 15000,
          retries: 1,
        },
      })) as ApiTestResult;
      if (!result.ok) {
        throw new Error(`HTTP ${result.status} ${result.statusText || ""}`.trim());
      }
      setTestResult(`Connexion OK · HTTP ${result.status} · ${result.elapsedMs} ms\n${result.preview}`);
    } catch (e) {
      setTestError(e instanceof Error ? e.message : "Échec de l'appel API.");
    } finally {
      setTesting(false);
    }
  };

  return (
    <div>
      {testError ? <ErrorBanner message={testError} onDismiss={() => setTestError("")} /> : null}
      {testResult ? <SuccessBanner message={testResult} /> : null}
      {!compact ? (
        <p className="text-[13px] leading-relaxed text-muted">
          Les identifiants restent sur cet appareil et ne sont jamais exportés dans un .zip. Vanelle
          affiche le code HTTP, le temps de réponse et un aperçu. Vous pouvez en connecter plusieurs.
        </p>
      ) : null}
      <Label>Nom</Label>
      <Field value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex. Stock produits" />
      <Label>Endpoint</Label>
      <Field
        value={endpoint}
        onChange={(e) => setEndpoint(e.target.value)}
        placeholder="https://api.exemple.com/stock"
        autoCapitalize="none"
      />
      <Label>Méthode</Label>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {METHODS.map((x) => (
          <Pill key={x} label={x} active={method === x} onClick={() => setMethod(x)} />
        ))}
      </div>
      <Label>Authentification</Label>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {AUTHS.map((x) => (
          <Pill
            key={x}
            label={x === "none" ? "Aucune" : x === "apiKey" ? "API Key" : x === "bearer" ? "Bearer" : "Basic"}
            active={authType === x}
            onClick={() => setAuthType(x)}
          />
        ))}
      </div>
      {authType === "apiKey" ? (
        <>
          <Label>Nom du header</Label>
          <Field
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="X-API-Key"
            autoCapitalize="none"
          />
          <Label>Clé</Label>
          <Field type="password" value={secret} onChange={(e) => setSecret(e.target.value)} />
        </>
      ) : null}
      {authType === "bearer" ? (
        <>
          <Label>Token Bearer</Label>
          <Field type="password" value={secret} onChange={(e) => setSecret(e.target.value)} />
        </>
      ) : null}
      {authType === "basic" ? (
        <>
          <Label>Utilisateur</Label>
          <Field value={username} onChange={(e) => setUsername(e.target.value)} autoCapitalize="none" />
          <Label>Mot de passe</Label>
          <Field type="password" value={secret} onChange={(e) => setSecret(e.target.value)} />
        </>
      ) : null}
      <Label>Description</Label>
      <Field
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="À quoi sert cette API pour l'IA ?"
      />

      <button
        type="button"
        className="mt-3 text-[12px] font-bold text-accent"
        onClick={() => setAdvanced((v) => !v)}
      >
        {advanced ? "Masquer les options avancées" : "Options avancées (protocole, headers, body)"}
      </button>
      {advanced ? (
        <>
          <Label>Protocole</Label>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {PROTOCOLS.map((x) => (
              <Pill key={x} label={x} active={protocol === x} onClick={() => setProtocol(x)} />
            ))}
          </div>
          <Label>Headers JSON (optionnel)</Label>
          <Area
            value={headersText}
            onChange={(e) => setHeadersText(e.target.value)}
            placeholder='{"Accept":"application/json"}'
          />
          <Label>Paramètres query JSON (optionnel)</Label>
          <Area
            value={queryText}
            onChange={(e) => setQueryText(e.target.value)}
            placeholder='{"page":"1"}'
          />
          <Label>Body JSON (POST/PUT/PATCH, optionnel)</Label>
          <Area
            value={bodyText}
            onChange={(e) => setBodyText(e.target.value)}
            placeholder='{"message":"Bonjour"}'
          />
        </>
      ) : null}

      <div className="mt-3 flex flex-wrap gap-2">
        <Btn
          type="button"
          disabled={!name.trim() || !endpoint.trim()}
          onClick={() => {
            onAdd(buildApi(), secret || undefined);
            reset();
          }}
        >
          Ajouter l'API
        </Btn>
        <Btn
          type="button"
          ghost
          disabled={!endpoint.trim() || testing}
          onClick={() => void test()}
        >
          {testing ? "Test…" : "Tester"}
        </Btn>
      </div>
    </div>
  );
}
