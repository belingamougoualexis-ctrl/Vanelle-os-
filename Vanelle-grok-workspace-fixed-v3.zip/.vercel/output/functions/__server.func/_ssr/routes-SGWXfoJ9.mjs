import { i as __toESM } from "../_runtime.mjs";
import { y as require_jsx_runtime, z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as Plus, c as LayoutDashboard, i as SendHorizontal, l as Bot, n as UserRound, o as Paperclip, s as Menu, t as X } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as require_lib } from "../_libs/jszip+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-SGWXfoJ9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_lib = /* @__PURE__ */ __toESM(require_lib());
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getAiStatus = createServerFn({ method: "GET" }).handler(createSsrRpc("ff37bd4a346b92aa36f1ec2ff6ed8b658f41e4d31cf5e569929a78526b554496"));
var testConfiguredApi = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("9acb408f13a7e8f39ad1d0b8518e6cae86a37ee814cbc13236e40e5b3c7ef456"));
var DB_NAME = "vanelle-2026";
var STORE = "kv";
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, 1);
		req.onupgradeneeded = () => {
			if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("IndexedDB indisponible"));
	});
}
async function idbGet(key) {
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const req = db.transaction(STORE, "readonly").objectStore(STORE).get(key);
		req.onsuccess = () => {
			const v = req.result;
			resolve(typeof v === "string" ? v : v == null ? null : JSON.stringify(v));
		};
		req.onerror = () => reject(req.error);
	});
}
async function idbSet(key, value) {
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put(value, key);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}
async function idbDel(key) {
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).delete(key);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}
var CATEGORIES = [
	"Identité",
	"Personnalité",
	"Connaissances",
	"Compétences",
	"Règles"
];
var blankProfile = () => ({ pseudo: "" });
function blankAI(name, description, style) {
	return {
		id: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
		name,
		description,
		style,
		traits: [
			"",
			"",
			""
		],
		systemPrompt: "",
		maxTokens: 700,
		temperature: .4,
		createdAt: Date.now(),
		training: [],
		files: [],
		apis: [],
		deployed: false
	};
}
function migrateAI(ai) {
	const traits = ai.traits && ai.traits.length === 3 ? ai.traits : [
		"",
		"",
		""
	];
	return {
		id: ai.id,
		name: ai.name,
		description: ai.description ?? "",
		style: ai.style ?? "Généraliste",
		traits: [
			traits[0] ?? "",
			traits[1] ?? "",
			traits[2] ?? ""
		],
		systemPrompt: ai.systemPrompt ?? "",
		maxTokens: ai.maxTokens ?? 700,
		temperature: ai.temperature ?? .4,
		createdAt: ai.createdAt ?? Date.now(),
		training: ai.training ?? [],
		files: ai.files ?? [],
		apis: (ai.apis ?? []).map((api) => ({
			...api,
			linkedTraits: api.linkedTraits ?? []
		})),
		deployed: ai.deployed ?? false,
		deployedAt: ai.deployedAt
	};
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function makeId() {
	return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
function fmtSize(bytes) {
	if (bytes < 1024) return `${bytes} o`;
	if (bytes < 1048576) return `${Math.round(bytes / 1024)} Ko`;
	if (bytes < 1073741824) return `${(bytes / 1048576).toFixed(1)} Mo`;
	return `${(bytes / 1073741824).toFixed(2)} Go`;
}
var TEXT_EXTRACT_BYTES = 32768;
var TEXT_EXTENSIONS = [
	".txt",
	".md",
	".csv",
	".json",
	".html",
	".htm",
	".js",
	".css",
	".ts",
	".tsx",
	".xml",
	".yml",
	".yaml"
];
var IMAGE_EXTENSIONS = [
	".png",
	".jpg",
	".jpeg",
	".webp",
	".gif",
	".bmp"
];
var idbStorage = {
	getItem: (name) => idbGet(name),
	setItem: (name, value) => idbSet(name, value),
	removeItem: (name) => idbDel(name)
};
var useVanelleStore = create()(persist((set, get) => ({
	ais: [],
	chats: {},
	profile: blankProfile(),
	secrets: {},
	hydrated: false,
	setHydrated: (v) => set({ hydrated: v }),
	saveAI: (ai) => set((s) => {
		const next = migrateAI(ai);
		return { ais: s.ais.some((x) => x.id === next.id) ? s.ais.map((x) => x.id === next.id ? next : x) : [next, ...s.ais] };
	}),
	deleteAI: (id) => set((s) => {
		const removed = s.ais.find((x) => x.id === id);
		const secrets = { ...s.secrets };
		if (removed) {
			for (const api of removed.apis) if (api.secretRef) delete secrets[api.secretRef];
		}
		const chats = { ...s.chats };
		delete chats[id];
		return {
			ais: s.ais.filter((x) => x.id !== id),
			chats,
			secrets
		};
	}),
	getAI: (id) => get().ais.find((x) => x.id === id),
	saveChat: (id, messages) => set((s) => ({ chats: {
		...s.chats,
		[id]: messages
	} })),
	saveProfile: (profile) => set({ profile }),
	putSecret: (ref, value) => set((s) => ({ secrets: {
		...s.secrets,
		[ref]: value
	} })),
	getSecret: (ref) => ref ? get().secrets[ref] : void 0,
	deleteSecret: (ref) => set((s) => {
		const secrets = { ...s.secrets };
		delete secrets[ref];
		return { secrets };
	}),
	attachApi: (aiId, api, secret) => set((s) => {
		const secrets = { ...s.secrets };
		let nextApi = { ...api };
		if (secret && secret.trim()) {
			const ref = api.secretRef || `api:${aiId}:${api.id || makeId()}`;
			secrets[ref] = secret.trim();
			nextApi = {
				...nextApi,
				secretRef: ref
			};
		}
		return {
			secrets,
			ais: s.ais.map((ai) => ai.id === aiId ? {
				...ai,
				apis: ai.apis.some((x) => x.id === nextApi.id) ? ai.apis.map((x) => x.id === nextApi.id ? nextApi : x) : [...ai.apis, nextApi]
			} : ai)
		};
	}),
	importBundle: (data) => set((s) => {
		const profile = data.profile ? {
			...blankProfile(),
			...data.profile
		} : s.profile;
		let ais = s.ais;
		if (Array.isArray(data.ais)) {
			const incoming = data.ais.map((a) => migrateAI(a));
			const byId = new Map(ais.map((a) => [a.id, a]));
			for (const ai of incoming) byId.set(ai.id, ai);
			ais = Array.from(byId.values()).sort((a, b) => b.createdAt - a.createdAt);
		}
		const chats = {
			...s.chats,
			...data.chats ?? {}
		};
		const secrets = {
			...s.secrets,
			...data.secrets ?? {}
		};
		return {
			profile,
			ais,
			chats,
			secrets
		};
	})
}), {
	name: "vanelle-studio",
	storage: createJSONStorage(() => idbStorage),
	skipHydration: true,
	partialize: (s) => ({
		ais: s.ais,
		chats: s.chats,
		profile: s.profile,
		secrets: s.secrets
	})
}));
function extOf(name) {
	const i = name.lastIndexOf(".");
	return i >= 0 ? name.slice(i).toLowerCase() : "";
}
async function readTextHead(file) {
	return (await file.slice(0, TEXT_EXTRACT_BYTES).text()).slice(0, 8e3);
}
async function readImagePreview(file) {
	if (file.size > 1572864) return void 0;
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : void 0);
		reader.onerror = () => reject(reader.error);
		reader.readAsDataURL(file);
	});
}
async function ingestFiles(list) {
	const files = Array.from(list);
	const added = [];
	const errors = [];
	for (const file of files) {
		if (file.size > 3221225472) {
			errors.push(`« ${file.name} » dépasse 3 Go (${fmtSize(file.size)}). Chaque fichier doit peser au maximum 3 Go — la limite s’applique fichier par fichier, pas au total.`);
			continue;
		}
		const ext = extOf(file.name);
		const isText = TEXT_EXTENSIONS.includes(ext);
		const isImage = IMAGE_EXTENSIONS.includes(ext) || file.type.startsWith("image/");
		let note = "Fichier binaire — contenu non extrait automatiquement.";
		let dataUrl;
		if (isImage) {
			note = "Image jointe — disponible comme référence de connaissance.";
			try {
				dataUrl = await readImagePreview(file);
			} catch {
				dataUrl = void 0;
			}
		} else if (isText) try {
			note = await readTextHead(file);
			if (!note.trim()) note = "Fichier texte vide.";
		} catch {
			note = "Ce fichier a été ajouté mais son contenu n’a pas pu être lu.";
		}
		added.push({
			id: makeId(),
			name: file.name || "fichier",
			note,
			size: file.size,
			addedAt: Date.now(),
			mime: file.type || void 0,
			dataUrl
		});
	}
	return {
		added,
		errors
	};
}
function downloadBlob(filename, blob) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.rel = "noopener";
	document.body.appendChild(a);
	a.click();
	a.remove();
	setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function downloadText(filename, text, mime = "application/json") {
	downloadBlob(filename, new Blob([text], { type: mime }));
}
function Card({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("mb-3 rounded-xl border border-line bg-surface p-4 shadow-[0_8px_22px_rgba(0,0,0,0.04)]", className),
		children
	});
}
function PageHead({ eyebrow, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-1 text-[10px] font-extrabold uppercase tracking-[0.16em] text-accent",
				children: eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-[1.55rem] font-extrabold leading-tight tracking-tight text-ink",
				children: title
			}),
			children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-[13px] leading-relaxed text-muted",
				children
			}) : null
		]
	});
}
function Label({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: "mb-1.5 mt-3 block text-[12px] font-bold text-[#505057]",
		children
	});
}
function Field({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cn("h-11 w-full rounded-md border border-input-line bg-surface px-3.5 text-[14px] text-ink outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-muted/70 focus:border-accent focus:ring-2 focus:ring-accent/20", className)
	});
}
function Area({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: cn("min-h-[80px] w-full rounded-md border border-input-line bg-surface px-3.5 py-3 text-[14px] text-ink outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-muted/70 focus:border-accent focus:ring-2 focus:ring-accent/20", className)
	});
}
function Btn({ ghost, danger, className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		...props,
		className: cn("inline-flex min-h-11 items-center justify-center rounded-[13px] px-4 text-[14px] font-extrabold transition-[transform,opacity,background-color] duration-150 disabled:cursor-not-allowed disabled:opacity-50 active:scale-[0.98]", ghost ? "bg-[#e9e9e4] text-ink hover:bg-[#deded8]" : danger ? "bg-danger-bg text-danger hover:bg-[#fde4e0]" : "bg-accent text-white hover:bg-accent-deep", className),
		children
	});
}
function Pill({ label, active, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("min-h-9 rounded-sm border-[1.5px] px-3 py-2 text-[11.5px] font-bold transition-colors duration-150", active ? "border-accent bg-accent text-white" : "border-line bg-surface text-ink hover:border-accent/40"),
		children: label
	});
}
function Tag({ on, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("rounded-full px-2 py-0.5 text-[10.5px] font-bold", on ? "bg-accent-soft text-accent" : "bg-[#eee] text-muted"),
		children
	});
}
function ErrorBanner({ message, onDismiss }) {
	if (!message) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onDismiss,
		className: "mb-2.5 w-full rounded-md border-[1.5px] border-danger-border bg-danger-bg p-3 text-left",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[13px] font-bold leading-snug text-danger",
			children: message
		}), onDismiss ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-[11px] font-medium text-danger",
			children: "Appuyez pour fermer"
		}) : null]
	});
}
function SuccessBanner({ message }) {
	if (!message) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mb-2.5 rounded-md border border-[#c5e0a0] bg-accent-soft p-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "whitespace-pre-wrap text-[13px] font-bold leading-snug text-[#3d5c0a]",
			children: message
		})
	});
}
function Empty({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[13px] leading-relaxed text-muted",
		children
	}) });
}
function Step({ n, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 mt-0.5 flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex size-5 items-center justify-center rounded-full bg-accent text-[11px] font-extrabold text-white",
			children: n
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-[15px] font-extrabold text-ink",
			children
		})]
	});
}
function Muted({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("text-[13px] leading-relaxed text-muted", className),
		children
	});
}
function RowKV({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between border-b border-line py-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[13px] text-ink",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[13px] font-extrabold tabular-nums text-ink",
			children: v
		})]
	});
}
function AccountView() {
	const profile = useVanelleStore((s) => s.profile);
	const saveProfile = useVanelleStore((s) => s.saveProfile);
	const ais = useVanelleStore((s) => s.ais);
	const chats = useVanelleStore((s) => s.chats);
	const importBundle = useVanelleStore((s) => s.importBundle);
	const [pseudo, setPseudo] = (0, import_react.useState)(profile.pseudo);
	const [importText, setImportText] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [exporting, setExporting] = (0, import_react.useState)(false);
	const exportAll = () => {
		setError("");
		setNote("");
		setExporting(true);
		try {
			const payload = JSON.stringify({
				version: 2,
				exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
				profile: {
					...profile,
					pseudo
				},
				ais: ais.map((ai) => ({
					...ai,
					apis: ai.apis.map(({ secretRef: _s, ...api }) => api)
				})),
				chats
			}, null, 2);
			const fileName = `vanelle-sauvegarde-${Date.now()}.json`;
			downloadText(fileName, payload);
			setNote(`Export terminé. Fichier : ${fileName}\nContient profil, ${ais.length} IA (prompt, tokens, température, notions, fichiers, API sans secrets) et chats.`);
		} catch (e) {
			setError(e instanceof Error ? e.message : "L'export a échoué.");
		} finally {
			setExporting(false);
		}
	};
	const importAll = () => {
		setError("");
		setNote("");
		try {
			const data = JSON.parse(importText);
			importBundle({
				profile: data.profile ? { pseudo: data.profile.pseudo ?? "" } : void 0,
				ais: data.ais,
				chats: data.chats
			});
			if (data.profile?.pseudo) setPseudo(data.profile.pseudo);
			setImportText("");
			setNote("Sauvegarde importée (profil, IA, API, fichiers, notions, chats).");
		} catch (e) {
			setError(e instanceof Error ? e.message : "Ce texte n'a pas pu être lu comme sauvegarde JSON.");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			eyebrow: "Compte",
			title: "Compte",
			children: "Vos IA restent sur cet appareil."
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBanner, {
			message: error,
			onDismiss: () => setError("")
		}) : null,
		note && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuccessBanner, { message: note }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-[15px] font-extrabold",
				children: "Profil"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Votre nom ou pseudo" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: pseudo,
				onChange: (e) => setPseudo(e.target.value),
				placeholder: "Ex. Camille"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				className: "mt-2.5 w-full",
				onClick: () => {
					saveProfile({ pseudo });
					setNote("Profil enregistré.");
				},
				children: "Enregistrer"
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-[15px] font-extrabold",
				children: "Sauvegarde complète"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[13px] leading-relaxed text-muted",
				children: "L'export inclut tout : profil, chaque IA (systemPrompt, maxTokens, temperature, style, traits), notions d'apprentissage, fichiers (notes/extraits), API (sans secrets), et historiques de chat. À l'import, les données s'ajoutent / mettent à jour sans tout effacer."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				ghost: true,
				className: "mt-2.5 w-full",
				disabled: exporting,
				onClick: exportAll,
				children: exporting ? "Export en cours…" : "Exporter toutes mes données"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Coller une sauvegarde (.json)" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
				value: importText,
				onChange: (e) => setImportText(e.target.value),
				placeholder: "{ ...contenu du fichier vanelle-sauvegarde.json... }"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				ghost: true,
				className: "mt-2 w-full",
				disabled: !importText.trim(),
				onClick: importAll,
				children: "Importer"
			})
		] })
	] });
}
var PACKAGE_VERSION = 1;
async function buildAIZip(ai, chat) {
	const zip = new import_lib.default();
	zip.file("manifest.json", JSON.stringify({
		app: "Vanelle",
		packageVersion: PACKAGE_VERSION,
		exportedAt: (/* @__PURE__ */ new Date()).toISOString()
	}, null, 2));
	zip.file("ai.json", JSON.stringify({
		id: ai.id,
		name: ai.name,
		description: ai.description,
		style: ai.style,
		traits: ai.traits,
		systemPrompt: ai.systemPrompt,
		maxTokens: ai.maxTokens,
		temperature: ai.temperature,
		createdAt: ai.createdAt,
		deployed: ai.deployed,
		deployedAt: ai.deployedAt,
		apis: ai.apis.map(({ secretRef: _s, ...api }) => api)
	}, null, 2));
	zip.file("training.json", JSON.stringify(ai.training, null, 2));
	const filesFolder = zip.folder("files");
	if (filesFolder) {
		filesFolder.file("manifest.json", JSON.stringify(ai.files.map((f) => ({
			id: f.id,
			name: f.name,
			size: f.size,
			addedAt: f.addedAt,
			mime: f.mime
		})), null, 2));
		for (const f of ai.files) filesFolder.file(`${f.id}.txt`, f.note);
	}
	zip.file("chat-history.json", JSON.stringify(chat, null, 2));
	return zip.generateAsync({ type: "blob" });
}
async function parseAIZip(file) {
	const zip = await import_lib.default.loadAsync(file);
	const readJSON = async (path, fallback) => {
		const entry = zip.file(path);
		if (!entry) return fallback;
		const text = await entry.async("string");
		try {
			return JSON.parse(text);
		} catch {
			return fallback;
		}
	};
	const aiJson = await readJSON("ai.json", {});
	if (!aiJson.name?.trim()) throw new Error("Ce .zip ne contient pas d'IA Vanelle valide (ai.json manquant).");
	const training = await readJSON("training.json", []);
	const filesManifest = await readJSON("files/manifest.json", []);
	const files = await Promise.all(filesManifest.map(async (f) => {
		const entry = zip.file(`files/${f.id}.txt`);
		const note = entry ? await entry.async("string") : "";
		return {
			id: f.id,
			name: f.name,
			size: f.size,
			addedAt: f.addedAt,
			note,
			mime: f.mime
		};
	}));
	const chat = await readJSON("chat-history.json", []);
	return {
		ai: migrateAI({
			id: makeId(),
			name: aiJson.name.trim(),
			description: aiJson.description,
			style: aiJson.style,
			traits: aiJson.traits,
			systemPrompt: aiJson.systemPrompt,
			maxTokens: aiJson.maxTokens,
			temperature: aiJson.temperature,
			createdAt: Date.now(),
			training,
			files,
			apis: (aiJson.apis ?? []).map((a) => ({
				...a,
				secretRef: void 0
			})),
			deployed: false
		}),
		chat
	};
}
var METHODS = [
	"GET",
	"POST",
	"PUT",
	"PATCH",
	"DELETE",
	"HEAD",
	"OPTIONS"
];
var PROTOCOLS = [
	"rest",
	"graphql",
	"sse",
	"websocket",
	"multipart",
	"binary",
	"mtls",
	"custom"
];
var AUTHS = [
	"none",
	"apiKey",
	"bearer",
	"basic"
];
function parseJsonObject(raw) {
	if (!raw.trim()) return void 0;
	try {
		const v = JSON.parse(raw);
		if (v && typeof v === "object" && !Array.isArray(v)) {
			const out = {};
			for (const [k, val] of Object.entries(v)) out[k] = String(val);
			return out;
		}
	} catch {}
}
function ApiEditor({ onAdd, compact }) {
	const [name, setName] = (0, import_react.useState)("");
	const [endpoint, setEndpoint] = (0, import_react.useState)("");
	const [method, setMethod] = (0, import_react.useState)("GET");
	const [protocol, setProtocol] = (0, import_react.useState)("rest");
	const [description, setDescription] = (0, import_react.useState)("");
	const [authType, setAuthType] = (0, import_react.useState)("none");
	const [secret, setSecret] = (0, import_react.useState)("");
	const [username, setUsername] = (0, import_react.useState)("");
	const [headersText, setHeadersText] = (0, import_react.useState)("");
	const [queryText, setQueryText] = (0, import_react.useState)("");
	const [bodyText, setBodyText] = (0, import_react.useState)("");
	const [testing, setTesting] = (0, import_react.useState)(false);
	const [testResult, setTestResult] = (0, import_react.useState)("");
	const [testError, setTestError] = (0, import_react.useState)("");
	const [advanced, setAdvanced] = (0, import_react.useState)(false);
	const reset = () => {
		setName("");
		setEndpoint("");
		setDescription("");
		setSecret("");
		setUsername("");
		setHeadersText("");
		setQueryText("");
		setBodyText("");
	};
	const buildApi = () => ({
		id: makeId(),
		name: name.trim(),
		endpoint: endpoint.trim(),
		method,
		protocol,
		description: description.trim(),
		authType,
		authHeader: authType === "apiKey" ? username.trim() || "X-API-Key" : void 0,
		username: authType === "basic" ? username.trim() : void 0,
		requestHeaders: parseJsonObject(headersText),
		queryParams: parseJsonObject(queryText),
		body: bodyText.trim() || void 0,
		timeoutMs: 15e3,
		retries: 2,
		retryNonIdempotent: false,
		linkedTraits: [],
		ts: Date.now()
	});
	const test = async () => {
		setTesting(true);
		setTestResult("");
		setTestError("");
		try {
			const auth = authType === "apiKey" ? {
				type: "apiKey",
				key: secret,
				header: username.trim() || "X-API-Key"
			} : authType === "bearer" ? {
				type: "bearer",
				token: secret
			} : authType === "basic" ? {
				type: "basic",
				username: username.trim(),
				password: secret
			} : { type: "none" };
			const result = await testConfiguredApi({ data: {
				endpoint: endpoint.trim(),
				method,
				auth,
				query: parseJsonObject(queryText),
				headers: parseJsonObject(headersText),
				body: bodyText.trim() || void 0,
				timeoutMs: 15e3,
				retries: 1
			} });
			if (!result.ok) throw new Error(`HTTP ${result.status} ${result.statusText || ""}`.trim());
			setTestResult(`Connexion OK · HTTP ${result.status} · ${result.elapsedMs} ms\n${result.preview}`);
		} catch (e) {
			setTestError(e instanceof Error ? e.message : "Échec de l'appel API.");
		} finally {
			setTesting(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		testError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBanner, {
			message: testError,
			onDismiss: () => setTestError("")
		}) : null,
		testResult ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuccessBanner, { message: testResult }) : null,
		!compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[13px] leading-relaxed text-muted",
			children: "Les identifiants restent sur cet appareil et ne sont jamais exportés dans un .zip. Vanelle affiche le code HTTP, le temps de réponse et un aperçu. Vous pouvez en connecter plusieurs."
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Nom" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			value: name,
			onChange: (e) => setName(e.target.value),
			placeholder: "Ex. Stock produits"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Endpoint" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			value: endpoint,
			onChange: (e) => setEndpoint(e.target.value),
			placeholder: "https://api.exemple.com/stock",
			autoCapitalize: "none"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Méthode" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 flex flex-wrap gap-1.5",
			children: METHODS.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
				label: x,
				active: method === x,
				onClick: () => setMethod(x)
			}, x))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Authentification" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 flex flex-wrap gap-1.5",
			children: AUTHS.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
				label: x === "none" ? "Aucune" : x === "apiKey" ? "API Key" : x === "bearer" ? "Bearer" : "Basic",
				active: authType === x,
				onClick: () => setAuthType(x)
			}, x))
		}),
		authType === "apiKey" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Nom du header" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: username,
				onChange: (e) => setUsername(e.target.value),
				placeholder: "X-API-Key",
				autoCapitalize: "none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Clé" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				type: "password",
				value: secret,
				onChange: (e) => setSecret(e.target.value)
			})
		] }) : null,
		authType === "bearer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Token Bearer" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			type: "password",
			value: secret,
			onChange: (e) => setSecret(e.target.value)
		})] }) : null,
		authType === "basic" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Utilisateur" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: username,
				onChange: (e) => setUsername(e.target.value),
				autoCapitalize: "none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Mot de passe" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				type: "password",
				value: secret,
				onChange: (e) => setSecret(e.target.value)
			})
		] }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Description" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			value: description,
			onChange: (e) => setDescription(e.target.value),
			placeholder: "À quoi sert cette API pour l'IA ?"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-3 text-[12px] font-bold text-accent",
			onClick: () => setAdvanced((v) => !v),
			children: advanced ? "Masquer les options avancées" : "Options avancées (protocole, headers, body)"
		}),
		advanced ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Protocole" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex flex-wrap gap-1.5",
				children: PROTOCOLS.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
					label: x,
					active: protocol === x,
					onClick: () => setProtocol(x)
				}, x))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Headers JSON (optionnel)" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
				value: headersText,
				onChange: (e) => setHeadersText(e.target.value),
				placeholder: "{\"Accept\":\"application/json\"}"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Paramètres query JSON (optionnel)" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
				value: queryText,
				onChange: (e) => setQueryText(e.target.value),
				placeholder: "{\"page\":\"1\"}"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Body JSON (POST/PUT/PATCH, optionnel)" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
				value: bodyText,
				onChange: (e) => setBodyText(e.target.value),
				placeholder: "{\"message\":\"Bonjour\"}"
			})
		] }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-wrap gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				type: "button",
				disabled: !name.trim() || !endpoint.trim(),
				onClick: () => {
					onAdd(buildApi(), secret || void 0);
					reset();
				},
				children: "Ajouter l'API"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				type: "button",
				ghost: true,
				disabled: !endpoint.trim() || testing,
				onClick: () => void test(),
				children: testing ? "Test…" : "Tester"
			})]
		})
	] });
}
function ChatView({ ai, back, onSave }) {
	const chats = useVanelleStore((s) => s.chats);
	const saveChat = useVanelleStore((s) => s.saveChat);
	const secrets = useVanelleStore((s) => s.secrets);
	const attachApi = useVanelleStore((s) => s.attachApi);
	const [messages, setMessages] = (0, import_react.useState)(() => chats[ai.id] ?? []);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("");
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [menuPanel, setMenuPanel] = (0, import_react.useState)("main");
	const listRef = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const abortRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setMessages(chats[ai.id] ?? []);
	}, [ai.id, chats]);
	(0, import_react.useEffect)(() => {
		const el = listRef.current;
		if (el) el.scrollTop = el.scrollHeight;
	}, [
		messages,
		busy,
		status
	]);
	const closeMenu = () => {
		setMenuOpen(false);
		setMenuPanel("main");
	};
	const persist = (next) => {
		setMessages(next);
		saveChat(ai.id, next);
	};
	const pickFiles = async (list) => {
		if (!list?.length) return;
		setError("");
		try {
			const { added, errors } = await ingestFiles(list);
			if (errors.length) setError(errors.join(" "));
			if (added.length) {
				onSave({
					...ai,
					files: [...ai.files, ...added]
				});
				setStatus(`${added.length} fichier(s) ajouté(s) aux connaissances. L'ancien contenu est conservé.`);
				toast.success("Connaissances mises à jour");
			}
		} catch (e) {
			setError(e instanceof Error ? e.message : "L'ajout du fichier a échoué.");
		}
	};
	const send = async (opts) => {
		const text = (opts?.extraUser ?? draft).trim();
		if (!text && !opts?.confirmed || busy) return;
		const next = [...messages];
		if (text) {
			const userMsg = {
				id: makeId(),
				role: "user",
				text,
				ts: Date.now()
			};
			next.push(userMsg);
		}
		persist(next);
		setDraft("");
		setBusy(true);
		setError("");
		setStatus("Génération en cours…");
		const controller = new AbortController();
		abortRef.current = controller;
		const botId = makeId();
		let botText = "";
		try {
			const res = await fetch("/api/chat", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					ai: {
						...ai,
						files: ai.files.map(({ dataUrl: _d, ...f }) => f)
					},
					messages: next.map(({ pendingConfirm: _p, ...m }) => m),
					secrets,
					confirmed: opts?.confirmed
				}),
				signal: controller.signal
			});
			if (!res.ok || !res.body) {
				const t = await res.text().catch(() => "");
				throw new Error(t || `Erreur ${res.status}`);
			}
			const reader = res.body.getReader();
			const decoder = new TextDecoder();
			let buf = "";
			let pending;
			while (true) {
				const { done, value } = await reader.read();
				if (done) break;
				buf += decoder.decode(value, { stream: true });
				const parts = buf.split("\n\n");
				buf = parts.pop() ?? "";
				for (const part of parts) {
					const line = part.split("\n").find((l) => l.startsWith("data: "));
					if (!line) continue;
					let event;
					try {
						event = JSON.parse(line.slice(6));
					} catch {
						continue;
					}
					if (event.type === "delta") {
						botText += event.text;
						setStatus("");
						setMessages([...next, {
							id: botId,
							role: "assistant",
							text: botText,
							ts: Date.now(),
							pendingConfirm: pending
						}]);
					} else if (event.type === "tool") setStatus(`API « ${event.name} » ${event.ok ? "OK" : "échec"}…`);
					else if (event.type === "confirm") pending = {
						apiId: event.apiId,
						apiName: event.apiName,
						method: event.method,
						query: event.query,
						body: event.body
					};
					else if (event.type === "error") {
						setError(event.message);
						setStatus("");
					}
				}
			}
			const all = [...next, {
				id: botId,
				role: "assistant",
				text: botText.trim() || (error ? "" : "Réponse vide."),
				ts: Date.now(),
				pendingConfirm: pending
			}].filter((m) => m.role !== "assistant" || m.text || m.pendingConfirm);
			persist(all);
			setStatus("");
		} catch (e) {
			if (e.name === "AbortError") {
				setStatus("");
				return;
			}
			const reason = e instanceof Error ? e.message : "Échec du moteur IA.";
			setError(/timeout|timed out|deadline/i.test(reason) ? "Le modèle met plus de temps que prévu. Réessayez : le moteur reste actif." : reason);
			setStatus("");
		} finally {
			setBusy(false);
			abortRef.current = null;
		}
	};
	const exportChat = () => {
		downloadText(`vanelle-chat-${ai.name.replace(/\s+/g, "-").toLowerCase()}-${Date.now()}.json`, JSON.stringify({
			ai: {
				id: ai.id,
				name: ai.name
			},
			exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
			messages
		}, null, 2));
		toast.success("Chat exporté");
		closeMenu();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-1 flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "bg-header px-4 py-3.5 text-white",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-10 font-extrabold",
							onClick: back,
							children: "‹ Retour"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-display text-[15px] font-extrabold tracking-wide",
							children: ai.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "flex size-10 items-center justify-center",
							"aria-label": "Menu du chat",
							onClick: () => {
								setMenuPanel("main");
								setMenuOpen(true);
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
								className: "size-5",
								strokeWidth: 2.4
							})
						})
					]
				})
			}),
			(error || status) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-bg px-3 pt-2",
				children: [error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBanner, {
					message: error,
					onDismiss: () => setError("")
				}) : null, status && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1.5 text-[13px] text-muted",
					children: status
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: listRef,
				className: "vanelle-scroll min-h-0 flex-1 overflow-y-auto p-3",
				children: [messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-w-[86%] rounded-lg border border-line bg-surface p-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[14px] leading-relaxed text-ink",
						children: [
							"Bonjour, je suis ",
							ai.name,
							". Posez votre question. Utilisez ＋ pour joindre des fichiers ou images (max 3 Go chacun) — les connaissances s'ajoutent sans effacer l'existant. Menu en haut à droite pour connecter des API, voir les connaissances et plus."
						]
					})
				}) : messages.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `mb-2.5 max-w-[86%] rounded-lg p-3 ${item.role === "user" ? "ml-auto bg-accent-soft" : "border border-line bg-surface"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-wrap text-[14px] leading-relaxed text-ink",
						children: item.text
					}), item.pendingConfirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 rounded-md border border-line bg-surface-alt p-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[12px] font-bold text-ink",
							children: [
								"Confirmer ",
								item.pendingConfirm.method,
								" · ",
								item.pendingConfirm.apiName,
								" ?"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								className: "h-9 min-h-9 px-3 text-[12px]",
								onClick: () => void send({
									extraUser: `Oui, je confirme l'appel ${item.pendingConfirm.method} vers ${item.pendingConfirm.apiName}.`,
									confirmed: item.pendingConfirm
								}),
								children: "Confirmer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								ghost: true,
								className: "h-9 min-h-9 px-3 text-[12px]",
								onClick: () => persist(messages.map((m) => m.id === item.id ? {
									...m,
									pendingConfirm: void 0
								} : m)),
								children: "Annuler"
							})]
						})]
					}) : null]
				}, item.id)), busy && !messages.some((m) => m.role === "assistant" && m.id.startsWith("tmp")) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-1 text-[12px] text-muted",
					children: "Vanelle réfléchit…"
				}) : null]
			}),
			ai.files.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "bg-surface px-3 pb-1 text-[11px] text-muted",
				children: [ai.files.length, " fichier(s) en connaissances · max 3 Go / fichier"]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end gap-1.5 border-t border-line bg-surface p-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						multiple: true,
						className: "hidden",
						onChange: (e) => {
							const files = e.target.files;
							e.target.value = "";
							pickFiles(files);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 shrink-0 items-center justify-center rounded-[9px] border-[1.5px] border-accent bg-accent-soft text-accent",
						"aria-label": "Ajouter un fichier ou une image",
						onClick: () => fileRef.current?.click(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, {
							className: "size-4",
							strokeWidth: 2.4
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: draft,
						onChange: (e) => setDraft(e.target.value),
						onKeyDown: (e) => {
							if (e.key === "Enter" && !e.shiftKey) {
								e.preventDefault();
								send();
							}
						},
						rows: 1,
						placeholder: "Écrivez votre message…",
						className: "max-h-[120px] min-h-11 flex-1 resize-none rounded-md border border-input-line bg-surface px-3 py-2.5 text-[14px] outline-none focus:border-accent focus:ring-2 focus:ring-accent/20"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 shrink-0 items-center justify-center rounded-[9px] bg-accent text-white disabled:opacity-50",
						disabled: busy || !draft.trim(),
						onClick: () => void send(),
						"aria-label": "Envoyer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SendHorizontal, {
							className: "size-4",
							strokeWidth: 2.4
						})
					})
				]
			}),
			menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 flex items-end justify-center bg-black/45",
				onClick: closeMenu,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[78%] w-full max-w-[480px] overflow-y-auto rounded-t-xl bg-surface pb-5 pt-2",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-1.5 h-1 w-10 rounded-full bg-[#ddd]" }),
						menuPanel === "main" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "px-[18px] py-2.5 text-[15px] font-extrabold",
								children: ["Menu · ", ai.name]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
								title: "Connecter une API",
								sub: `${ai.apis.length} API · en ajouter une ou plusieurs`,
								onClick: () => setMenuPanel("apis")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
								title: "Voir les connaissances",
								sub: `${ai.training.length} notion(s) · ${ai.files.length} fichier(s)`,
								onClick: () => setMenuPanel("knowledge")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
								title: "Effacer la conversation",
								sub: "Supprime uniquement l'historique de ce chat",
								danger: true,
								onClick: () => {
									persist([]);
									closeMenu();
									setStatus("Conversation effacée.");
									toast.success("Conversation effacée");
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
								title: "Infos de l'IA",
								sub: "Style, tokens, température, prompt, traits",
								onClick: () => setMenuPanel("info")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
								title: "Ajouter un fichier",
								sub: "Même action que le trombone · max 3 Go / fichier",
								onClick: () => {
									closeMenu();
									fileRef.current?.click();
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
								title: "Exporter ce chat",
								sub: `${messages.length} message(s) · JSON`,
								onClick: exportChat
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
								title: "Fermer",
								sub: "",
								muted: true,
								onClick: closeMenu
							})
						] }),
						menuPanel === "apis" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelHead, {
							title: "API connectées",
							onBack: () => setMenuPanel("main")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-[18px] pb-3",
							children: [ai.apis.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Aucune API. Ajoutez-en une ou plusieurs ci-dessous." }) : ai.apis.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApiCard, { api: a }, a.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								className: "mt-2 w-full",
								onClick: () => setMenuPanel("addApi"),
								children: "Ajouter une API"
							})]
						})] }),
						menuPanel === "addApi" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelHead, {
							title: "Nouvelle API",
							onBack: () => setMenuPanel("apis")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-[18px] pb-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApiEditor, {
								compact: true,
								onAdd: (api, secret) => {
									attachApi(ai.id, api, secret);
									toast.success(`${api.name} connectée`);
									setMenuPanel("apis");
								}
							})
						})] }),
						menuPanel === "knowledge" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelHead, {
							title: "Connaissances",
							onBack: () => setMenuPanel("main")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-[18px] pb-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mb-1.5 text-[11px] font-bold text-muted",
									children: [
										"Notions (",
										ai.training.length,
										")"
									]
								}),
								ai.training.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Aucune notion enseignée." }) : ai.training.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-2 rounded-md border border-line bg-surface-alt p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[13px] font-bold",
										children: t.question
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[13px] text-muted",
										children: t.answer
									})]
								}, t.id)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mb-1.5 mt-2.5 text-[11px] font-bold text-muted",
									children: [
										"Fichiers (",
										ai.files.length,
										")"
									]
								}),
								ai.files.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Aucun fichier." }) : ai.files.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-2 rounded-md border border-line bg-surface-alt p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[13px] font-bold",
										children: [
											f.name,
											" · ",
											fmtSize(f.size)
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[13px] text-muted",
										children: f.note.slice(0, 160)
									})]
								}, f.id))
							]
						})] }),
						menuPanel === "info" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelHead, {
							title: "Infos de l'IA",
							onBack: () => setMenuPanel("main")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-[18px] pb-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
									label: "Nom",
									value: ai.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
									label: "Style",
									value: ai.style || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
									label: "Traits de personnalité",
									value: (ai.traits ?? []).map((t) => t.trim()).filter(Boolean).join(" · ") || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
									label: "Max tokens",
									value: String(ai.maxTokens)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
									label: "Température",
									value: String(ai.temperature)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
									label: "System prompt",
									value: ai.systemPrompt?.trim() || "(vide — notions & fichiers servent de contexte)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
									label: "Description",
									value: ai.description || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
									label: "API",
									value: `${ai.apis.length} connectée(s)`
								})
							]
						})] })
					]
				})
			}) : null
		]
	});
}
function MenuRow({ title, sub, onClick, danger, muted }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "w-full border-t border-line px-[18px] py-3.5 text-left",
		onClick,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `text-[15px] font-bold ${danger ? "text-danger" : muted ? "text-muted" : "text-ink"}`,
			children: title
		}), sub ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-0.5 text-[12px] leading-snug text-muted",
			children: sub
		}) : null]
	});
}
function PanelHead({ title, onBack }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 px-[18px] py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "font-extrabold text-accent",
				onClick: onBack,
				children: "‹ Retour"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "flex-1 text-[15px] font-extrabold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
				className: "size-4 text-muted",
				"aria-hidden": true
			})
		]
	});
}
function InfoCard({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 rounded-md border border-line bg-surface-alt p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-0.5 text-[11px] font-bold text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "whitespace-pre-wrap text-[13px] font-bold leading-snug text-ink",
			children: value
		})]
	});
}
function ApiCard({ api }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 rounded-md border border-line bg-surface-alt p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[13px] font-bold",
			children: api.name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-[12px] text-muted",
			children: [
				api.method,
				" · ",
				api.endpoint
			]
		})]
	});
}
function AIStudio({ aiId, onBack, startInChat }) {
	const ai = useVanelleStore((s) => s.ais.find((x) => x.id === aiId));
	const saveAI = useVanelleStore((s) => s.saveAI);
	const [tab, setTab] = (0, import_react.useState)(startInChat ? "tester" : "vue");
	if (!ai) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Cette IA n'existe plus."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			className: "mt-3",
			onClick: onBack,
			children: "Retour"
		})]
	});
	const save = (next) => {
		saveAI(next);
	};
	if (tab === "tester") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatView, {
		ai,
		back: () => setTab("vue"),
		onSave: save
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "bg-header px-4 py-4 text-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-10 text-[14px] font-extrabold",
							onClick: onBack,
							children: "‹ Retour"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate font-display text-[15px] font-extrabold tracking-[0.08em]",
							children: [
								"« ",
								ai.name,
								" »"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-16" })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-[11px] text-champagne",
					children: ai.description || "Pas encore de description."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b border-line bg-surface px-4 pt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-1.5 pb-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
							label: "Vue d'ensemble",
							active: tab === "vue",
							onClick: () => setTab("vue")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
							label: "Apprentissage",
							active: tab === "apprentissage",
							onClick: () => setTab("apprentissage")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
							label: "Fichiers",
							active: tab === "fichiers",
							onClick: () => setTab("fichiers")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
							label: "API",
							active: tab === "api",
							onClick: () => setTab("api")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
							label: "Chat",
							active: false,
							onClick: () => setTab("tester")
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "vanelle-scroll min-h-0 flex-1 overflow-y-auto bg-bg p-4",
				children: [
					tab === "vue" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabVue, {
						ai,
						onSave: save,
						onDeleted: onBack,
						onTest: () => setTab("tester")
					}),
					tab === "apprentissage" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabApprentissage, {
						ai,
						onSave: save
					}),
					tab === "fichiers" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabFichiers, {
						ai,
						onSave: save
					}),
					tab === "api" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabApi, {
						ai,
						onSave: save
					})
				]
			})
		]
	});
}
function TraitApiPicker({ ai, traitIndex, onSave }) {
	const linked = ai.apis.filter((a) => (a.linkedTraits ?? []).includes(traitIndex));
	const toggle = (api) => {
		const set = new Set(api.linkedTraits ?? []);
		if (set.has(traitIndex)) set.delete(traitIndex);
		else set.add(traitIndex);
		onSave({
			...ai,
			apis: ai.apis.map((x) => x.id === api.id ? {
				...x,
				linkedTraits: Array.from(set).sort()
			} : x)
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-2 rounded-md border border-line bg-surface-alt p-2.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-bold text-muted",
				children: "API liées à ce trait (plusieurs possibles)"
			}),
			ai.apis.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[12px] text-muted",
				children: "Aucune API pour l'instant — ajoutez-en ci-dessous."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1.5 flex flex-wrap gap-1.5",
				children: ai.apis.map((api) => {
					const on = (api.linkedTraits ?? []).includes(traitIndex);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => toggle(api),
						className: `min-h-8 rounded-full border px-2.5 text-[11px] font-bold ${on ? "border-accent bg-accent text-white" : "border-line bg-surface text-ink"}`,
						children: api.name
					}, api.id);
				})
			}),
			linked.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1.5 text-[11px] text-muted",
				children: [
					linked.length,
					" API rattachée",
					linked.length > 1 ? "s" : ""
				]
			}) : null
		]
	});
}
function TabVue({ ai, onSave, onDeleted, onTest }) {
	const deleteAI = useVanelleStore((s) => s.deleteAI);
	const chats = useVanelleStore((s) => s.chats);
	const attachApi = useVanelleStore((s) => s.attachApi);
	const [name, setName] = (0, import_react.useState)(ai.name);
	const [description, setDescription] = (0, import_react.useState)(ai.description);
	const [style, setStyle] = (0, import_react.useState)(ai.style);
	const [confirmingDelete, setConfirmingDelete] = (0, import_react.useState)(false);
	const [exporting, setExporting] = (0, import_react.useState)(false);
	const [exportError, setExportError] = (0, import_react.useState)("");
	const [exportNote, setExportNote] = (0, import_react.useState)("");
	const [trait1, setTrait1] = (0, import_react.useState)(ai.traits?.[0] ?? "");
	const [trait2, setTrait2] = (0, import_react.useState)(ai.traits?.[1] ?? "");
	const [trait3, setTrait3] = (0, import_react.useState)(ai.traits?.[2] ?? "");
	const [systemPrompt, setSystemPrompt] = (0, import_react.useState)(ai.systemPrompt ?? "");
	const [maxTokens, setMaxTokens] = (0, import_react.useState)(String(ai.maxTokens ?? 700));
	const [temperature, setTemperature] = (0, import_react.useState)(String(ai.temperature ?? .4));
	const [personaSaved, setPersonaSaved] = (0, import_react.useState)(false);
	const [showApiForm, setShowApiForm] = (0, import_react.useState)(false);
	const isNew = ai.training.length === 0 && ai.files.length === 0 && ai.apis.length === 0;
	(0, import_react.useEffect)(() => {
		setName(ai.name);
		setDescription(ai.description);
		setStyle(ai.style);
		setTrait1(ai.traits?.[0] ?? "");
		setTrait2(ai.traits?.[1] ?? "");
		setTrait3(ai.traits?.[2] ?? "");
		setSystemPrompt(ai.systemPrompt ?? "");
		setMaxTokens(String(ai.maxTokens ?? 700));
		setTemperature(String(ai.temperature ?? .4));
	}, [ai.id]);
	const exportZip = async () => {
		setExportError("");
		setExportNote("");
		setExporting(true);
		try {
			const blob = await buildAIZip(ai, chats[ai.id] ?? []);
			const fileName = `${ai.name.replace(/\s+/g, "-").toLowerCase()}-vanelle-ia.zip`;
			downloadBlob(fileName, blob);
			setExportNote(`IA exportée en .zip : ${fileName} (notions, fichiers, API sans secrets, prompt, chat de test).`);
			toast.success("IA exportée");
		} catch (e) {
			setExportError(e instanceof Error ? e.message : "L'export du .zip a échoué.");
		} finally {
			setExporting(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		isNew ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "border-accent/30 bg-accent-soft/40",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-[15px] font-extrabold",
				children: "Votre atelier est ouvert"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
				className: "mt-1",
				children: "Ajoutez les 3 traits, reliez-y une ou plusieurs API, puis déposez des fichiers (3 Go max chacun). Tout se fait ici, sans revenir en arrière."
			})]
		}) : null,
		exportError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBanner, {
			message: exportError,
			onDismiss: () => setExportError("")
		}) : null,
		exportNote && !exportError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuccessBanner, { message: exportNote }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-1 text-[15px] font-extrabold",
				children: "Fiche d'identité"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Nom de l'IA" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: name,
				onChange: (e) => setName(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Description" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
				value: description,
				onChange: (e) => setDescription(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Style de base" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: style,
				onChange: (e) => setStyle(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				className: "mt-3 w-full",
				disabled: !name.trim(),
				onClick: () => {
					onSave({
						...ai,
						name: name.trim() || ai.name,
						description: description.trim(),
						style
					});
					toast.success("Fiche enregistrée");
				},
				children: "Enregistrer la fiche"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				ghost: true,
				className: "mt-2 w-full",
				onClick: () => {
					if (!confirmingDelete) {
						setConfirmingDelete(true);
						return;
					}
					deleteAI(ai.id);
					onDeleted();
				},
				children: confirmingDelete ? "Confirmer la suppression" : "Supprimer cette IA"
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-1 text-[15px] font-extrabold",
				children: "Personnalité — 3 traits"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Ces 3 traits décrivent le caractère de l'IA et sont injectés dans son prompt système à chaque message. Vous pouvez y rattacher une ou plusieurs API — l'IA saura lesquelles utiliser selon le trait." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Trait 1" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: trait1,
				onChange: (e) => setTrait1(e.target.value),
				placeholder: "Ex. Chaleureuse"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TraitApiPicker, {
				ai,
				traitIndex: 0,
				onSave
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Trait 2" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: trait2,
				onChange: (e) => setTrait2(e.target.value),
				placeholder: "Ex. Directe"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TraitApiPicker, {
				ai,
				traitIndex: 1,
				onSave
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Trait 3" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: trait3,
				onChange: (e) => setTrait3(e.target.value),
				placeholder: "Ex. Curieuse"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TraitApiPicker, {
				ai,
				traitIndex: 2,
				onSave
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 border-t border-line pt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] font-bold text-[#505057]",
						children: "Connecter une ou plusieurs API"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
						className: "mt-1",
						children: "Les API ajoutées ici sont disponibles pour le chat et peuvent être liées aux 3 traits ci-dessus."
					}),
					ai.apis.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-1.5",
						children: ai.apis.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-md border border-line bg-surface-alt px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[13px] font-bold",
								children: a.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-muted",
								children: [
									a.method,
									" · ",
									a.endpoint
								]
							})]
						}, a.id))
					}) : null,
					showApiForm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApiEditor, {
							compact: true,
							onAdd: (api, secret) => {
								attachApi(ai.id, api, secret);
								toast.success(`${api.name} connectée`);
								setShowApiForm(false);
							}
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						ghost: true,
						className: "mt-2 w-full",
						onClick: () => setShowApiForm(true),
						children: "Ajouter une API"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Prompt système" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Instructions libres qui s'ajoutent aux traits pour cadrer le comportement de l'IA — modifiable à tout moment." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
				className: "mt-2 min-h-[100px]",
				value: systemPrompt,
				onChange: (e) => setSystemPrompt(e.target.value),
				placeholder: "Ex. Tu es l'assistante de la boutique, réponds toujours en français, reste concise."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Max tokens" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					type: "number",
					min: 128,
					max: 2e3,
					value: maxTokens,
					onChange: (e) => setMaxTokens(e.target.value)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Température" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					type: "number",
					min: 0,
					max: 1.4,
					step: .1,
					value: temperature,
					onChange: (e) => setTemperature(e.target.value)
				})] })]
			}),
			personaSaved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuccessBanner, { message: "Personnalité et prompt système enregistrés." }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				className: "mt-3 w-full",
				onClick: () => {
					onSave({
						...ai,
						traits: [
							trait1.trim(),
							trait2.trim(),
							trait3.trim()
						],
						systemPrompt,
						maxTokens: Math.min(2e3, Math.max(128, Number(maxTokens) || 700)),
						temperature: Math.min(1.4, Math.max(0, Number(temperature) || .4))
					});
					setPersonaSaved(true);
					toast.success("Personnalité enregistrée");
				},
				children: "Enregistrer la personnalité"
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabFichiers, {
			ai,
			onSave,
			compact: true
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-[15px] font-extrabold",
				children: "Résumé"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowKV, {
				k: "Notions enseignées",
				v: String(ai.training.length)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowKV, {
				k: "Fichiers analysés",
				v: String(ai.files.length)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowKV, {
				k: "API connectées",
				v: String(ai.apis.length)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between py-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[13px]",
					children: "Statut"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
					on: ai.deployed,
					children: ai.deployed ? "déployée" : "brouillon"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				ghost: true,
				className: "mt-2 w-full",
				onClick: () => {
					onSave({
						...ai,
						deployed: true,
						deployedAt: Date.now()
					});
					toast.success("IA marquée déployée");
				},
				children: "Marquer déployée"
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-[15px] font-extrabold",
				children: "Exporter cette IA"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Un .zip contenant tout ce qui fait cette IA : identité, style, prompt système, notions enseignées, fichiers connaissances, API documentées et l'historique du chat de test. Réimportable pour continuer l'apprentissage ailleurs. Les secrets API ne sont pas inclus." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				ghost: true,
				className: "mt-2.5 w-full",
				disabled: exporting,
				onClick: () => void exportZip(),
				children: exporting ? "Préparation du .zip…" : "Exporter en .zip"
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			className: "mb-6 mt-1 w-full",
			onClick: onTest,
			children: "Ouvrir le chat de test"
		})
	] });
}
function TabApprentissage({ ai, onSave }) {
	const [category, setCategory] = (0, import_react.useState)(CATEGORIES[0]);
	const [question, setQuestion] = (0, import_react.useState)("");
	const [answer, setAnswer] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
			n: 1,
			children: "Enseigner une notion"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, { children: "Ces paires question/réponse sont injectées dans le prompt système à chaque message." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Catégorie" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 flex flex-wrap gap-1.5",
			children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
				label: c,
				active: category === c,
				onClick: () => setCategory(c)
			}, c))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Question / situation" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			value: question,
			onChange: (e) => setQuestion(e.target.value),
			placeholder: "Ex. Comment te présenter ?"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Réponse attendue" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
			value: answer,
			onChange: (e) => setAnswer(e.target.value),
			placeholder: "Ex. Je suis un assistant concis et bienveillant."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			className: "mt-3 w-full",
			disabled: !question.trim() || !answer.trim(),
			onClick: () => {
				const t = {
					id: makeId(),
					category,
					question: question.trim(),
					answer: answer.trim(),
					ts: Date.now()
				};
				onSave({
					...ai,
					training: [...ai.training, t]
				});
				setQuestion("");
				setAnswer("");
				toast.success("Notion ajoutée");
			},
			children: "Ajouter la notion"
		})
	] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
		className: "text-[15px] font-extrabold",
		children: [
			"Notions enregistrées (",
			ai.training.length,
			")"
		]
	}), ai.training.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
		className: "mt-2",
		children: "Rien pour l'instant — commencez par son identité."
	}) : CATEGORIES.map((c) => {
		const items = ai.training.filter((t) => t.category === c);
		if (!items.length) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2.5 text-[12px] font-bold text-muted",
			children: c
		}), items.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-b border-line py-2.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] font-bold",
					children: t.question
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] text-muted",
					children: t.answer
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					ghost: true,
					className: "mt-1.5 h-9 min-h-9 self-start px-3.5",
					onClick: () => onSave({
						...ai,
						training: ai.training.filter((x) => x.id !== t.id)
					}),
					children: "Retirer"
				})
			]
		}, t.id))] }, c);
	})] })] });
}
function TabFichiers({ ai, onSave, compact }) {
	const inputRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [status, setStatus] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const upload = async (list) => {
		if (!list?.length) return;
		setBusy(true);
		setStatus("");
		setError("");
		try {
			const { added, errors } = await ingestFiles(list);
			if (errors.length) setError(errors.join(" "));
			if (added.length) {
				onSave({
					...ai,
					files: [...ai.files, ...added]
				});
				setStatus(`${added.length} fichier(s) ajouté(s) — le chat s'en sert désormais. Anciennes données conservées.`);
				toast.success("Connaissances mises à jour");
			}
		} catch (e) {
			setError(e instanceof Error ? e.message : "L'ajout du fichier a échoué.");
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBanner, {
			message: error,
			onDismiss: () => setError("")
		}) : null,
		status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuccessBanner, { message: status }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-[15px] font-extrabold",
				children: "Fichiers de connaissance"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
				n: 1,
				children: "Ajouter des données"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
				className: "mt-1",
				children: "TXT, MD, CSV, JSON, HTML, JS, CSS : le contenu est extrait et vraiment utilisé par le chat. Images et autres formats sont conservés comme référence. Limite : 3 Go par fichier (pas sur le total). Chaque ajout s'empile — rien n'est écrasé sauf si vous retirez explicitement un fichier."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				multiple: true,
				className: "hidden",
				onChange: (e) => {
					const files = e.target.files;
					e.target.value = "";
					upload(files);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				className: "mt-3 w-full",
				disabled: busy,
				onClick: () => inputRef.current?.click(),
				children: busy ? "Lecture…" : "Uploader un fichier"
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "text-[15px] font-extrabold",
			children: [
				"Fichiers analysés (",
				ai.files.length,
				")"
			]
		}), ai.files.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
			className: "mt-2",
			children: "Aucun fichier pour l'instant."
		}) : ai.files.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-b border-line py-2.5 last:border-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] font-bold",
					children: f.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-muted",
					children: fmtSize(f.size)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] text-muted",
					children: f.note.slice(0, 140)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					ghost: true,
					className: "mt-1.5 h-9 min-h-9 px-3.5",
					onClick: () => onSave({
						...ai,
						files: ai.files.filter((x) => x.id !== f.id)
					}),
					children: "Retirer"
				})
			]
		}, f.id))] })
	] });
}
function TabApi({ ai, onSave }) {
	const attachApi = useVanelleStore((s) => s.attachApi);
	const getSecret = useVanelleStore((s) => s.getSecret);
	const deleteSecret = useVanelleStore((s) => s.deleteSecret);
	const [testing, setTesting] = (0, import_react.useState)(null);
	const [testResult, setTestResult] = (0, import_react.useState)("");
	const [testError, setTestError] = (0, import_react.useState)("");
	const testApi = async (api) => {
		setTesting(api.id);
		setTestResult("");
		setTestError("");
		try {
			const secret = getSecret(api.secretRef);
			const auth = api.authType === "apiKey" ? {
				type: "apiKey",
				key: secret || "",
				header: api.authHeader || "X-API-Key"
			} : api.authType === "bearer" ? {
				type: "bearer",
				token: secret || ""
			} : api.authType === "basic" ? {
				type: "basic",
				username: api.username || "",
				password: secret || ""
			} : { type: "none" };
			const result = await testConfiguredApi({ data: {
				endpoint: api.endpoint,
				method: api.method,
				auth,
				query: api.queryParams,
				headers: api.requestHeaders,
				body: api.body,
				timeoutMs: api.timeoutMs || 15e3,
				retries: api.retries ?? 2,
				retryNonIdempotent: api.retryNonIdempotent
			} });
			if (!result.ok) throw new Error(`HTTP ${result.status} ${result.statusText || ""}`.trim());
			setTestResult(`Connexion OK · HTTP ${result.status} · ${result.elapsedMs} ms\n${result.preview}`);
		} catch (e) {
			setTestError(e instanceof Error ? e.message : "Échec de l'appel API.");
		} finally {
			setTesting(null);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		testError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBanner, {
			message: testError,
			onDismiss: () => setTestError("")
		}) : null,
		testResult ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuccessBanner, { message: testResult }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-[15px] font-extrabold",
			children: "Connecter une API"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApiEditor, { onAdd: (api, secret) => {
			attachApi(ai.id, api, secret);
			toast.success(`${api.name} connectée`);
		} })] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "text-[15px] font-extrabold",
			children: [
				"Intégrations API (",
				ai.apis.length,
				")"
			]
		}), ai.apis.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muted, {
			className: "mt-2",
			children: "Aucune API configurée."
		}) : ai.apis.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-b border-line py-2.5 last:border-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] font-bold",
					children: a.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[13px] text-muted",
					children: [
						a.endpoint,
						" · ",
						a.method,
						a.protocol && a.protocol !== "rest" ? ` · ${a.protocol}` : ""
					]
				}),
				a.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] text-muted",
					children: a.description
				}) : null,
				(a.linkedTraits ?? []).length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-[11px] text-accent",
					children: [
						"Liée aux traits",
						" ",
						(a.linkedTraits ?? []).map((i) => ai.traits[i] || `Trait ${i + 1}`).join(" · ")
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1.5 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						ghost: true,
						className: "h-9 min-h-9 px-3.5",
						disabled: testing === a.id,
						onClick: () => void testApi(a),
						children: testing === a.id ? "Test…" : "Tester"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						ghost: true,
						className: "h-9 min-h-9 px-3.5",
						onClick: () => {
							if (a.secretRef) deleteSecret(a.secretRef);
							onSave({
								...ai,
								apis: ai.apis.filter((x) => x.id !== a.id)
							});
						},
						children: "Retirer"
					})]
				})
			]
		}, a.id))] })
	] });
}
function AisView({ open }) {
	const ais = useVanelleStore((s) => s.ais);
	const deleteAI = useVanelleStore((s) => s.deleteAI);
	const [confirming, setConfirming] = (0, import_react.useState)(null);
	const sorted = [...ais].sort((a, b) => b.createdAt - a.createdAt);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		eyebrow: "Atelier",
		title: "Mes IA",
		children: `${sorted.length} IA en cours de construction.`
	}), sorted.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "Vous n'avez encore créé aucune IA." }) : sorted.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "w-full text-left",
		onClick: () => open(item),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[14.5px] font-extrabold",
					children: item.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
					on: item.deployed,
					children: item.deployed ? "déployée" : "en cours"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[13px] text-muted",
				children: item.description || "Pas encore de description."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-[11px] text-muted",
				children: [
					item.files.length,
					" fichier(s) · ",
					item.training.length,
					" notion(s) · ",
					item.apis.length,
					" ",
					"API"
				]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
		ghost: true,
		className: "mt-2.5 w-full",
		onClick: () => {
			if (confirming !== item.id) {
				setConfirming(item.id);
				return;
			}
			setConfirming(null);
			deleteAI(item.id);
		},
		children: confirming === item.id ? "Confirmer la suppression" : "Supprimer"
	})] }, item.id))] });
}
function CreateView({ onCreated }) {
	const saveAI = useVanelleStore((s) => s.saveAI);
	const saveChat = useVanelleStore((s) => s.saveChat);
	const [name, setName] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [style, setStyle] = (0, import_react.useState)("Généraliste");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [importing, setImporting] = (0, import_react.useState)(false);
	const [importError, setImportError] = (0, import_react.useState)("");
	const [importNote, setImportNote] = (0, import_react.useState)("");
	const zipRef = (0, import_react.useRef)(null);
	const importZip = async (file) => {
		setImportError("");
		setImportNote("");
		setImporting(true);
		try {
			if (!file.name.toLowerCase().endsWith(".zip")) throw new Error("Choisissez un fichier .zip exporté depuis Vanelle.");
			const { ai, chat } = await parseAIZip(file);
			saveAI(ai);
			if (chat.length) saveChat(ai.id, chat);
			setImportNote(`IA importée avec ${ai.training.length} notion(s) et ${ai.files.length} fichier(s). Ouverture de la fiche.`);
			toast.success(`${ai.name} importée`);
			onCreated(ai);
		} catch (e) {
			setImportError(e instanceof Error ? e.message : "L'import du .zip a échoué.");
		} finally {
			setImporting(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			eyebrow: "Étape 0",
			title: "Créer une nouvelle IA",
			children: "Donnez-lui un nom et un point de départ, puis enseignez-lui ce qu'elle doit savoir — notions, fichiers, API — depuis sa fiche."
		}),
		importError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBanner, {
			message: importError,
			onDismiss: () => setImportError("")
		}) : null,
		importNote && !importError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuccessBanner, { message: importNote }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-[15px] font-extrabold",
				children: "Importer une IA (.zip)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[13px] leading-relaxed text-muted",
				children: "Reprenez une IA exportée depuis Vanelle — son apprentissage continue là où vous l'avez laissé."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: zipRef,
				type: "file",
				accept: ".zip,application/zip",
				className: "hidden",
				onChange: (e) => {
					const f = e.target.files?.[0];
					e.target.value = "";
					if (f) importZip(f);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				ghost: true,
				className: "mt-2.5 w-full",
				disabled: importing,
				onClick: () => zipRef.current?.click(),
				children: importing ? "Import en cours…" : "Choisir un .zip"
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Nom" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: name,
				onChange: (e) => setName(e.target.value),
				placeholder: "Ex. Solutions Pro"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Description" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
				value: description,
				onChange: (e) => setDescription(e.target.value),
				placeholder: "En une phrase, à quoi sert cette IA ?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Style" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: style,
				onChange: (e) => setStyle(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				className: "mt-3 w-full",
				disabled: busy || !name.trim(),
				onClick: () => {
					setBusy(true);
					try {
						const ai = blankAI(name.trim(), description.trim(), style);
						saveAI(ai);
						onCreated(ai);
					} finally {
						setBusy(false);
					}
				},
				children: busy ? "Création…" : "Commencer l'apprentissage"
			})
		] })
	] });
}
function DashboardView({ open }) {
	const ais = useVanelleStore((s) => s.ais);
	const totalTraining = ais.reduce((s, a) => s + a.training.length, 0);
	const totalFiles = ais.reduce((s, a) => s + a.files.length, 0);
	const totalApis = ais.reduce((s, a) => s + a.apis.length, 0);
	const deployed = ais.filter((a) => a.deployed).length;
	const stats = [
		{
			num: ais.length,
			lbl: "IA créées"
		},
		{
			num: deployed,
			lbl: "déployées"
		},
		{
			num: totalTraining,
			lbl: "notions enseignées"
		},
		{
			num: totalFiles,
			lbl: "fichiers analysés"
		},
		{
			num: totalApis,
			lbl: "API connectées"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			eyebrow: "Vue d'ensemble",
			title: "Tableau de bord",
			children: "L'état de tout ce que vous construisez ici."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 grid grid-cols-2 gap-2 sm:grid-cols-3",
			children: stats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-md border border-line bg-surface p-3.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-[26px] font-extrabold tabular-nums leading-none text-accent",
					children: s.num
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1.5 text-[11px] font-bold text-muted",
					children: s.lbl
				})]
			}, s.lbl))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-[15px] font-extrabold",
			children: "Progression par IA"
		}), ais.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-[13px] text-muted",
			children: "Rien à afficher pour l'instant."
		}) : [...ais].sort((a, b) => b.createdAt - a.createdAt).map((ai) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "block w-full border-b border-line py-2.5 text-left last:border-0",
			onClick: () => open(ai),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-bold",
				children: ai.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[11.5px] text-muted",
				children: [
					ai.training.length,
					" notions · ",
					ai.files.length,
					" fichiers · ",
					ai.apis.length,
					" API"
				]
			})]
		}, ai.id))] })
	] });
}
function VanelleApp() {
	const hydrated = useVanelleStore((s) => s.hydrated);
	const setHydrated = useVanelleStore((s) => s.setHydrated);
	const [tab, setTab] = (0, import_react.useState)("create");
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	const [modelState, setModelState] = (0, import_react.useState)("checking");
	(0, import_react.useEffect)(() => {
		Promise.resolve(useVanelleStore.persist.rehydrate()).then(() => setHydrated(true));
	}, [setHydrated]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		getAiStatus().then((s) => {
			if (!cancelled) setModelState(s.available ? "ready" : "unavailable");
		}).catch(() => {
			if (!cancelled) setModelState("unavailable");
		});
		return () => {
			cancelled = true;
		};
	}, []);
	const open = (ai) => setSelectedId(ai.id);
	const created = (ai) => {
		setSelectedId(ai.id);
	};
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-header text-white",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-5 py-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-[17px] font-extrabold tracking-[0.14em]",
				children: "VANELLE"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[10px] font-medium tracking-[0.18em] text-champagne",
				children: "ATELIER IA"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-1 items-center justify-center bg-bg text-[13px] text-muted",
			children: "Chargement de l'atelier…"
		})]
	});
	if (selectedId) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-dvh min-h-dvh flex-col overflow-hidden bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AIStudio, {
			aiId: selectedId,
			onBack: () => setSelectedId(null)
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh min-h-dvh overflow-hidden bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden w-[240px] shrink-0 flex-col bg-header text-white md:flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 py-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-[17px] font-extrabold tracking-[0.14em]",
						children: "VANELLE"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[10px] font-medium tracking-[0.18em] text-champagne",
						children: "ATELIER IA"
					}),
					modelState === "unavailable" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-[10px] text-[#f2b3ab]",
						children: "Moteur IA indisponible."
					}) : null,
					modelState === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-[10px] text-champagne",
						children: "IA prête"
					}) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex flex-1 flex-col gap-0.5 px-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideNav, {
						label: "Créer",
						active: tab === "create",
						onClick: () => setTab("create")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideNav, {
						label: "Mes IA",
						active: tab === "ais",
						onClick: () => setTab("ais")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideNav, {
						label: "Tableau",
						active: tab === "dashboard",
						onClick: () => setTab("dashboard")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideNav, {
						label: "Compte",
						active: tab === "account",
						onClick: () => setTab("account")
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-1 flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "bg-header px-[18px] py-[18px] text-white md:hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-[17px] font-extrabold tracking-[0.14em]",
							children: "VANELLE"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-[9px] font-medium tracking-[0.18em] text-champagne",
							children: "ATELIER IA"
						}),
						modelState === "unavailable" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 text-[10px] text-[#f2b3ab]",
							children: "Moteur IA indisponible sur cet appareil."
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "vanelle-scroll min-h-0 flex-1 overflow-y-auto p-4 pb-24 md:p-8 md:pb-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto w-full max-w-[720px]",
						children: [
							tab === "create" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateView, { onCreated: created }),
							tab === "ais" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AisView, { open }),
							tab === "dashboard" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardView, { open }),
							tab === "account" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountView, {})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "fixed inset-x-0 bottom-0 z-20 grid grid-cols-4 border-t border-line bg-surface md:hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
							label: "Créer",
							active: tab === "create",
							onClick: () => setTab("create"),
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
							label: "Mes IA",
							active: tab === "ais",
							onClick: () => setTab("ais"),
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
							label: "Tableau",
							active: tab === "dashboard",
							onClick: () => setTab("dashboard"),
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
							label: "Compte",
							active: tab === "account",
							onClick: () => setTab("account"),
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-4" })
						})
					]
				})
			]
		})]
	});
}
function SideNav({ label, active, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("rounded-md px-3 py-2.5 text-left text-[13px] font-bold transition-colors", active ? "bg-white/10 text-white" : "text-white/55 hover:bg-white/5 hover:text-white"),
		children: label
	});
}
function NavBtn({ label, active, onClick, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex min-h-12 flex-col items-center justify-center gap-0.5 py-2.5 text-[10.5px] font-bold", active ? "bg-[#faf9ff] text-accent" : "text-[#77777d]"),
		children: [icon, label]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VanelleApp, {});
}
//#endregion
export { Home as component };
