import { n as __exportAll$1 } from "../_runtime.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/proxy.server-B0vTIDHS.js
var proxy_server_B0vTIDHS_exports = /* @__PURE__ */ __exportAll$1({
	i: () => __exportAll,
	n: () => proxy_server_exports,
	r: () => summarizeApiData,
	t: () => executeProxy
});
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var BLOCKED_HOSTS = /* @__PURE__ */ new Set([
	"localhost",
	"127.0.0.1",
	"0.0.0.0",
	"::1",
	"metadata.google.internal"
]);
function isPrivateHostname(host) {
	const h = host.toLowerCase().replace(/^\[|\]$/g, "");
	if (BLOCKED_HOSTS.has(h)) return true;
	if (h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".localhost")) return true;
	if (/^10\.\d+\.\d+\.\d+$/.test(h)) return true;
	if (/^192\.168\.\d+\.\d+$/.test(h)) return true;
	if (/^172\.(1[6-9]|2\d|3[0-1])\.\d+\.\d+$/.test(h)) return true;
	if (/^169\.254\.\d+\.\d+$/.test(h)) return true;
	if (/^127\.\d+\.\d+\.\d+$/.test(h)) return true;
	if (h === "::" || h.startsWith("fe80:") || h.startsWith("fc") || h.startsWith("fd")) return true;
	return false;
}
function validatePublicHttpsUrl(endpoint) {
	let u;
	try {
		u = new URL(endpoint.trim());
	} catch {
		throw new Error("Endpoint invalide. Utilisez une URL complète (https://…).");
	}
	if (u.protocol !== "https:") throw new Error("Vanelle exige HTTPS pour les API Internet.");
	if (isPrivateHostname(u.hostname)) throw new Error("Cet hôte n'est pas autorisé (réseau privé ou local).");
	return u;
}
var proxy_server_exports = /* @__PURE__ */ __exportAll({
	executeProxy: () => executeProxy,
	summarizeApiData: () => summarizeApiData
});
var DEFAULT_TIMEOUT_MS = 15e3;
var DEFAULT_RETRIES = 2;
var RETRYABLE = /* @__PURE__ */ new Set([
	408,
	425,
	429,
	500,
	502,
	503,
	504
]);
function parseBody(raw) {
	if (!raw) return null;
	try {
		return JSON.parse(raw);
	} catch {
		return raw;
	}
}
function buildUrl(endpoint, query) {
	const u = validatePublicHttpsUrl(endpoint);
	if (query) {
		for (const [k, v] of Object.entries(query)) if (v !== void 0 && v !== null) u.searchParams.set(k, String(v));
	}
	return u.toString();
}
function authHeaders(auth) {
	if (!auth || auth.type === "none") return {};
	if (auth.type === "apiKey" && auth.key) return { [auth.header || "X-API-Key"]: auth.key };
	if (auth.type === "bearer" && auth.token) return { Authorization: `Bearer ${auth.token}` };
	if (auth.type === "basic") return { Authorization: `Basic ${Buffer.from(`${auth.username}:${auth.password}`).toString("base64")}` };
	return {};
}
function retryDelay(a) {
	return Math.min(5e3, 400 * 2 ** (a - 1)) + Math.floor(Math.random() * 250);
}
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function executeProxy(cfg) {
	const method = cfg.method || "GET";
	const url = buildUrl(cfg.endpoint, cfg.query);
	const retries = Math.max(0, cfg.retries ?? DEFAULT_RETRIES);
	const canRetry = method === "GET" || method === "HEAD" || method === "OPTIONS" || !!cfg.retryNonIdempotent;
	const maxAttempts = canRetry ? retries + 1 : 1;
	const startedAll = Date.now();
	let lastError;
	for (let attempt = 1; attempt <= maxAttempts; attempt++) {
		const c = new AbortController();
		const timeout = setTimeout(() => c.abort(), cfg.timeoutMs ?? DEFAULT_TIMEOUT_MS);
		try {
			const headers = {
				Accept: "application/json, text/plain, */*",
				...authHeaders(cfg.auth),
				...cfg.headers || {}
			};
			let body;
			if (cfg.body !== void 0 && method !== "GET" && method !== "HEAD") {
				body = typeof cfg.body === "string" ? cfg.body : JSON.stringify(cfg.body);
				if (!Object.keys(headers).some((k) => k.toLowerCase() === "content-type")) headers["Content-Type"] = "application/json";
			}
			const response = await fetch(url, {
				method,
				headers,
				body,
				signal: c.signal
			});
			const raw = await response.text();
			const rh = {};
			response.headers.forEach((v, k) => {
				rh[k] = v;
			});
			const result = {
				ok: response.ok,
				status: response.status,
				statusText: response.statusText,
				headers: rh,
				data: parseBody(raw),
				raw: raw.slice(0, 8e4),
				elapsedMs: Date.now() - startedAll,
				attempts: attempt
			};
			if (response.ok || !canRetry || !RETRYABLE.has(response.status) || attempt >= maxAttempts) return result;
			const ra = Number(rh["retry-after"]);
			await sleep(Number.isFinite(ra) ? Math.min(3e4, ra * 1e3) : retryDelay(attempt));
		} catch (e) {
			lastError = e;
			if (attempt >= maxAttempts) break;
			await sleep(retryDelay(attempt));
		} finally {
			clearTimeout(timeout);
		}
	}
	if (lastError?.name === "AbortError") throw new Error(`L'API n'a pas répondu dans ${Math.round((cfg.timeoutMs ?? DEFAULT_TIMEOUT_MS) / 1e3)} s.`);
	throw new Error(`Impossible de joindre l'API après ${maxAttempts} tentative(s). ${lastError instanceof Error ? lastError.message : ""}`.trim());
}
function summarizeApiData(data) {
	if (data === null) return "Réponse vide.";
	if (typeof data === "string") return data.slice(0, 1e3);
	try {
		return JSON.stringify(data, null, 2).slice(0, 1800);
	} catch {
		return "Réponse reçue mais impossible à afficher.";
	}
}
//#endregion
export { summarizeApiData as i, executeProxy as n, proxy_server_B0vTIDHS_exports as r, __exportAll as t };
