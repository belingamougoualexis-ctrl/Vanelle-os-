import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai.functions-CQ3uQ3cd.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getAiStatus_createServerFn_handler = createServerRpc({
	id: "ff37bd4a346b92aa36f1ec2ff6ed8b658f41e4d31cf5e569929a78526b554496",
	name: "getAiStatus",
	filename: "src/lib/ai.functions.ts"
}, (opts) => getAiStatus.__executeServer(opts));
var getAiStatus = createServerFn({ method: "GET" }).handler(getAiStatus_createServerFn_handler, async () => {
	const { isAiAvailable } = await import("./grok.server-Dv8j0X8M.mjs").then((n) => n.t);
	return { available: isAiAvailable() };
});
var testConfiguredApi_createServerFn_handler = createServerRpc({
	id: "9acb408f13a7e8f39ad1d0b8518e6cae86a37ee814cbc13236e40e5b3c7ef456",
	name: "testConfiguredApi",
	filename: "src/lib/ai.functions.ts"
}, (opts) => testConfiguredApi.__executeServer(opts));
var testConfiguredApi = createServerFn({ method: "POST" }).validator((input) => input).handler(testConfiguredApi_createServerFn_handler, async ({ data }) => {
	const { executeProxy, summarizeApiData } = await import("./proxy.server-B0vTIDHS.mjs").then((n) => n.r).then((n) => n.n);
	const result = await executeProxy(data);
	return {
		ok: result.ok,
		status: result.status,
		statusText: result.statusText,
		preview: summarizeApiData(result.data),
		elapsedMs: result.elapsedMs,
		attempts: result.attempts
	};
});
//#endregion
export { getAiStatus_createServerFn_handler, testConfiguredApi_createServerFn_handler };
