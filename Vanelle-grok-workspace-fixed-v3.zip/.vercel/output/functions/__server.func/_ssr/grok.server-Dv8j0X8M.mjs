import { i as summarizeApiData, n as executeProxy, t as __exportAll } from "./proxy.server-B0vTIDHS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/grok.server-Dv8j0X8M.js
function buildSystemPrompt(ai) {
	const teaching = ai.training.map((t) => `- [${t.category}] ${t.question} → ${t.answer}`).join("\n");
	const documents = ai.files.map((f) => `[${f.name}]\n${f.note.slice(0, 1200)}`).join("\n\n");
	const traitsList = (ai.traits ?? []).map((t) => t.trim()).filter(Boolean);
	const traitsLine = traitsList.length ? `Traits de personnalité à incarner : ${traitsList.join(", ")}.` : "";
	const linked = ai.apis.filter((a) => (a.linkedTraits ?? []).length > 0).map((a) => {
		const labels = (a.linkedTraits ?? []).map((i) => ai.traits[i]?.trim()).filter(Boolean);
		return `- ${a.name} liée aux traits : ${labels.join(", ") || a.linkedTraits?.join(", ")}`;
	});
	return [
		`Tu es ${ai.name}, une IA créée dans Vanelle Atelier.`,
		ai.description ? `Rôle : ${ai.description}` : "",
		ai.style ? `Style : ${ai.style}` : "",
		traitsLine,
		linked.length ? `APIs rattachées aux traits :\n${linked.join("\n")}` : "",
		ai.systemPrompt,
		"Si une question porte sur un sujet que tu n'as pas appris (absent des notions et documents ci-dessous) et qui n'est pas une connaissance générale fiable, dis-le clairement — par exemple « Je n'ai pas encore appris ça, vous pouvez me l'enseigner depuis l'onglet Apprentissage » — plutôt que d'inventer une réponse.",
		"Réponds dans la langue de l'utilisateur, de préférence en français si le message l'est.",
		"N'invente jamais de données d'API. N'affiche jamais de clés, tokens ou secrets.",
		teaching ? `Notions apprises :\n${teaching}` : "Notions apprises : aucune pour l'instant.",
		documents ? `Documents fournis :\n${documents}` : ""
	].filter(Boolean).join("\n\n");
}
function listApisForTools(ai) {
	return ai.apis.map((api) => ({
		id: api.id,
		name: api.name,
		description: api.description,
		protocol: api.protocol ?? "rest",
		method: api.method,
		endpoint: api.endpoint,
		authentication: api.authType || "none"
	}));
}
var grok_server_exports = /* @__PURE__ */ __exportAll({
	isAiAvailable: () => isAiAvailable,
	runChat: () => runChat
});
var MODEL = "grok-4.5";
var SAFE_METHODS = /* @__PURE__ */ new Set([
	"GET",
	"HEAD",
	"OPTIONS"
]);
function grokTools(ai) {
	const available = listApisForTools(ai);
	if (!available.length) return void 0;
	return [{
		type: "function",
		function: {
			name: "vanelle_call_api",
			description: "Appelle une API configurée de cette IA. Utilise uniquement un apiId de la liste. Ne fabrique jamais de secret. GET/HEAD/OPTIONS s'exécutent directement. POST/PUT/PATCH/DELETE exigent userConfirmed=true après accord explicite de l'utilisateur.",
			parameters: {
				type: "object",
				properties: {
					apiId: {
						type: "string",
						description: `Un de : ${available.map((a) => `${a.id} (${a.name})`).join(", ")}`
					},
					method: {
						type: "string",
						enum: [
							"GET",
							"POST",
							"PUT",
							"PATCH",
							"DELETE",
							"HEAD",
							"OPTIONS"
						]
					},
					query: {
						type: "object",
						additionalProperties: { type: "string" }
					},
					body: {},
					userConfirmed: { type: "boolean" }
				},
				required: ["apiId"]
			}
		}
	}];
}
function resolveAuth(api, secrets) {
	const secret = api.secretRef ? secrets[api.secretRef] : void 0;
	if (api.authType === "apiKey" && secret) return {
		type: "apiKey",
		key: secret,
		header: api.authHeader || "X-API-Key"
	};
	if (api.authType === "bearer" && secret) return {
		type: "bearer",
		token: secret
	};
	if (api.authType === "basic") return {
		type: "basic",
		username: api.username || "",
		password: secret || ""
	};
	return { type: "none" };
}
async function runApi(ai, secrets, args) {
	const api = ai.apis.find((x) => x.id === args.apiId);
	if (!api) return {
		kind: "error",
		text: "API demandée introuvable dans cette IA."
	};
	const method = (args.method || api.method || "GET").toUpperCase();
	if (!SAFE_METHODS.has(method) && !args.userConfirmed) return {
		kind: "confirm",
		text: `CONFIRMATION_REQUISE: l'appel ${method} vers « ${api.name} » peut modifier des données. Demande confirmation à l'utilisateur avant de l'exécuter.`,
		extra: {
			type: "confirm",
			apiId: api.id,
			apiName: api.name,
			method,
			query: args.query,
			body: args.body
		}
	};
	try {
		const req = {
			endpoint: api.endpoint,
			method,
			headers: api.requestHeaders,
			query: {
				...api.queryParams ?? {},
				...args.query ?? {}
			},
			body: args.body ?? (api.body ? safeJson(api.body) : void 0),
			auth: resolveAuth(api, secrets),
			timeoutMs: api.timeoutMs || 15e3,
			retries: api.retries ?? 2,
			retryNonIdempotent: api.retryNonIdempotent
		};
		const result = await executeProxy(req);
		const preview = summarizeApiData(result.data);
		return {
			kind: "ok",
			text: `API_RESULT\nHTTP ${result.status} ${result.statusText}\n${preview}`
		};
	} catch (e) {
		return {
			kind: "error",
			text: `API_ERROR: ${e instanceof Error ? e.message : "échec"}`
		};
	}
}
function safeJson(raw) {
	try {
		return JSON.parse(raw);
	} catch {
		return raw;
	}
}
async function grokComplete(messages, tools, ai) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) throw new Error("AI_UNAVAILABLE");
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: MODEL,
			messages,
			tools,
			temperature: Math.min(1.4, Math.max(0, ai.temperature ?? .4)),
			max_tokens: Math.min(2e3, Math.max(128, ai.maxTokens ?? 700))
		})
	});
	if (!res.ok) {
		const t = await res.text().catch(() => "");
		throw new Error(`xAI API error ${res.status}${t ? `: ${t.slice(0, 200)}` : ""}`);
	}
	return (await res.json()).choices[0]?.message;
}
async function runChat(payload, emit) {
	if (!process.env.XAI_API_KEY) {
		emit({
			type: "error",
			message: "Le moteur IA n'est pas disponible dans cet environnement."
		});
		emit({ type: "done" });
		return;
	}
	const { ai, secrets } = payload;
	const system = buildSystemPrompt(ai);
	const tools = grokTools(ai);
	const history = [{
		role: "system",
		content: system
	}, ...payload.messages.filter((m) => m.role === "user" || m.role === "assistant").slice(-24).map((m) => ({
		role: m.role,
		content: m.text
	}))];
	if (payload.confirmed) {
		const result = await runApi(ai, secrets, {
			...payload.confirmed,
			userConfirmed: true
		});
		emit({
			type: "tool",
			name: payload.confirmed.apiId,
			ok: result.kind === "ok",
			preview: result.text.slice(0, 400)
		});
		history.push({
			role: "user",
			content: `L'utilisateur a confirmé l'appel API. Résultat réel :\n${result.text}\n\nRéponds maintenant à l'utilisateur sans inventer de données.`
		});
	}
	try {
		for (let round = 0; round < 3; round++) {
			const msg = await grokComplete(history, tools, ai);
			if (!msg) throw new Error("Réponse vide du moteur IA.");
			const calls = msg.tool_calls ?? [];
			if (!calls.length) {
				emit({
					type: "delta",
					text: (msg.content || "").trim() || "Réponse vide."
				});
				emit({ type: "done" });
				return;
			}
			history.push({
				role: "assistant",
				content: msg.content ?? "",
				tool_calls: calls
			});
			for (const call of calls) {
				let args;
				try {
					args = JSON.parse(call.function.arguments || "{}");
				} catch {
					args = { apiId: "" };
				}
				const result = await runApi(ai, secrets, args);
				if (result.extra) emit(result.extra);
				emit({
					type: "tool",
					name: ai.apis.find((a) => a.id === args.apiId)?.name || args.apiId,
					ok: result.kind === "ok",
					preview: result.text.slice(0, 400)
				});
				history.push({
					role: "tool",
					tool_call_id: call.id,
					content: result.text
				});
			}
		}
		emit({
			type: "delta",
			text: "L'appel d'outils a atteint sa limite. Reformulez votre demande."
		});
		emit({ type: "done" });
	} catch (e) {
		const reason = e instanceof Error ? e.message : "Échec du moteur IA.";
		emit({
			type: "error",
			message: /timeout|timed out|deadline/i.test(reason) ? "Le modèle met plus de temps que prévu. Réessayez — ce n'est pas une coupure." : reason === "AI_UNAVAILABLE" ? "Le moteur IA n'est pas disponible dans cet environnement." : reason
		});
		emit({ type: "done" });
	}
}
function isAiAvailable() {
	return Boolean(process.env.XAI_API_KEY);
}
//#endregion
export { runChat as n, grok_server_exports as t };
