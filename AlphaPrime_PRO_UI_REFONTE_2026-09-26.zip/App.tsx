import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as Haptics from 'expo-haptics';
import { SafeAreaProvider, SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { DashboardScreen } from './src/screens/DashboardScreen';
import { ProjectsScreen } from './src/screens/ProjectsScreen';
import { DataScreen } from './src/screens/DataScreen';
import { EvaluationScreen } from './src/screens/EvaluationScreen';
import { GovernanceScreen } from './src/screens/GovernanceScreen';
import { ModelScreen } from './src/screens/ModelScreen';
import { AppState } from './src/core/types';
import { EMPTY_STATE, loadState, saveState } from './src/storage/store';
import { detectDevice } from './src/services/device';
import { colors } from './src/ui/theme';
import { useAdaptiveLayout } from './src/ui/adaptive';
import { AmbientBackground } from './src/components/AmbientBackground';

const tabs = [
  ['Accueil', '⌂'], ['Projets', '▦'], ['Données', '▤'], ['Modèles', '◈'], ['Évaluation', '✓'], ['Gouvernance', '⊙'],
] as const;
type Tab = typeof tabs[number][0];

type DeviceInfo = Awaited<ReturnType<typeof detectDevice>>;

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <View style={compact ? styles.brandCompact : styles.brandBlock}>
      <Image source={require('./assets/alpha-prime-eagle.jpg')} style={compact ? styles.brandLogoCompact : styles.brandLogo} resizeMode="cover" />
      {!compact ? (
        <View style={styles.brandCopy}>
          <Text style={styles.brandName}>ALPHA PRIME</Text>
          <Text style={styles.brandTag}>LOCAL AI ENGINEERING</Text>
        </View>
      ) : null}
    </View>
  );
}

function Navigation({ tab, setTab }: { tab: Tab; setTab: (tab: Tab) => void }) {
  const insets = useSafeAreaInsets();
  const { isCompact, isMedium, isShortHeight } = useAdaptiveLayout();
  const side = !isCompact;
  const rail = isMedium;
  const item = (label: Tab, glyph: string) => {
    const active = label === tab;
    return (
      <Pressable
        key={label}
        accessibilityRole="tab"
        accessibilityState={{ selected: active }}
        accessibilityLabel={label}
        onPress={() => { void Haptics.selectionAsync().catch(() => undefined); setTab(label); }}
        style={({ pressed }) => [
          side ? (rail ? styles.railItem : styles.sideItem) : styles.navItem,
          active && styles.activeItem,
          pressed && styles.pressed,
        ]}
      >
        <Text style={[styles.navGlyph, active && styles.activeGlyph]}>{glyph}</Text>
        <Text numberOfLines={1} style={[styles.navLabel, active && styles.activeText]}>{label}</Text>
      </Pressable>
    );
  };

  if (side) {
    return (
      <View style={[styles.sidebar, rail && styles.sidebarRail]}>
        <Brand compact={rail} />
        {!rail ? <Text style={styles.navSectionLabel}>WORKSPACE</Text> : null}
        <View style={rail ? styles.railNav : styles.sideNav}>{tabs.map(([label, glyph]) => item(label, glyph))}</View>
        {!rail ? (
          <View style={styles.sideFooter}>
            <Text style={styles.footerTitle}>LOCAL WORKSPACE</Text>
            <Text style={styles.footerNote}>Fichiers, modèles et résultats restent liés à cet espace de travail local.</Text>
          </View>
        ) : null}
      </View>
    );
  }

  return (
    <View style={[styles.nav, { bottom: Math.max(insets.bottom, 8), height: isShortHeight ? 62 : 70 }]}>
      {tabs.map(([label, glyph]) => item(label, glyph))}
    </View>
  );
}

function AlphaPrimeApp() {
  const insets = useSafeAreaInsets();
  const { isCompact, horizontalPadding, contentMaxWidth } = useAdaptiveLayout();
  const [tab, setTab] = useState<Tab>('Accueil');
  const [state, setStateRaw] = useState<AppState>(EMPTY_STATE);
  const [device, setDevice] = useState<DeviceInfo | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let alive = true;
    void (async () => {
      try {
        const [loaded, deviceInfo] = await Promise.all([loadState(), detectDevice()]);
        if (!alive) return;
        setStateRaw(loaded);
        setDevice(deviceInfo);
      } finally {
        if (alive) setReady(true);
      }
    })();
    return () => { alive = false; };
  }, []);

  const setState = (next: AppState) => { setStateRaw(next); void saveState(next).catch(() => undefined); };

  const content = useMemo(() => {
    if (!ready) return null;
    switch (tab) {
      case 'Accueil': return <DashboardScreen state={state} device={device} onNavigate={setTab} />;
      case 'Projets': return <ProjectsScreen state={state} setState={setState} />;
      case 'Données': return <DataScreen state={state} setState={setState} onOpenModel={() => setTab('Modèles')} />;
      case 'Modèles': return <ModelScreen state={state} setState={setState} device={device} />;
      case 'Évaluation': return <EvaluationScreen state={state} setState={setState} device={device} />;
      case 'Gouvernance': return <GovernanceScreen state={state} />;
    }
  }, [device, ready, state, tab]);

  if (!ready) {
    return <SafeAreaView style={styles.loading}><Brand compact /><ActivityIndicator size="small" color={colors.primary} /><Text style={styles.loadingText}>Initialisation de l’espace local…</Text></SafeAreaView>;
  }

  const side = !isCompact;
  return (
    <AmbientBackground>
      <StatusBar style="dark" />
      <View style={styles.desktopShell}>
        {side ? <Navigation tab={tab} setTab={setTab} /> : null}
        <View style={styles.main}>
          <SafeAreaView edges={['top']}>
            <View style={[styles.header, { paddingHorizontal: horizontalPadding, paddingTop: 12, paddingBottom: 12, marginTop: Math.max(insets.top > 0 ? 0 : 2, 0) }]}>
              <View style={styles.headerLeft}>
                <Brand compact={isCompact} />
                {side ? <View><Text style={styles.headerKicker}>ESPACE DE TRAVAIL</Text><Text style={styles.headerSection}>{tab}</Text></View> : null}
              </View>
              <View style={styles.headerMeta}><Text style={styles.headerMetaText}>{device?.model ?? 'Appareil'}</Text><Text style={styles.headerMetaText}>{device?.os ?? 'Système'}</Text></View>
            </View>
          </SafeAreaView>
          <View style={[styles.content, { maxWidth: contentMaxWidth, paddingHorizontal: horizontalPadding }]}>{content}</View>
          {!side ? <Navigation tab={tab} setTab={setTab} /> : null}
        </View>
      </View>
    </AmbientBackground>
  );
}

export default function App() { return <SafeAreaProvider><AlphaPrimeApp /></SafeAreaProvider>; }

const styles = StyleSheet.create({
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background, gap: 16 },
  loadingText: { color: colors.muted, fontSize: 13, paddingHorizontal: 24, textAlign: 'center' },
  desktopShell: { flex: 1, flexDirection: 'row' },
  main: { flex: 1, minWidth: 0 },
  sidebar: { width: 252, borderRightWidth: 1, borderRightColor: colors.line, backgroundColor: '#FBFCFD', paddingHorizontal: 14, paddingTop: 18, paddingBottom: 16 },
  sidebarRail: { width: 82, alignItems: 'center', paddingHorizontal: 8 },
  brandBlock: { flexDirection: 'row', alignItems: 'center', gap: 10, minWidth: 0 },
  brandCompact: { alignItems: 'center', justifyContent: 'center' },
  brandLogo: { width: 40, height: 40, borderRadius: 12, borderWidth: 1, borderColor: '#D7DCE3' },
  brandLogoCompact: { width: 42, height: 42, borderRadius: 13, borderWidth: 1, borderColor: '#D7DCE3' },
  brandCopy: { gap: 2 },
  brandName: { color: colors.text, fontSize: 14, fontWeight: '900', letterSpacing: 0.65 },
  brandTag: { color: colors.muted, fontSize: 8, fontWeight: '700', letterSpacing: 1.05 },
  navSectionLabel: { color: colors.mutedLight, fontSize: 9, fontWeight: '800', letterSpacing: 1.2, paddingHorizontal: 10, marginTop: 24, marginBottom: 7 },
  sideNav: { gap: 4 },
  railNav: { gap: 6, marginTop: 26 },
  sideItem: { minHeight: 46, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 11, borderRadius: 11, borderWidth: 1, borderColor: 'transparent' },
  railItem: { width: 56, minHeight: 52, alignItems: 'center', justifyContent: 'center', gap: 4, borderRadius: 11, borderWidth: 1, borderColor: 'transparent' },
  navItem: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 3, borderRadius: 10, borderWidth: 1, borderColor: 'transparent', paddingHorizontal: 3 },
  activeItem: { backgroundColor: colors.primarySoft, borderColor: '#D8E2FF' },
  pressed: { opacity: 0.78 },
  navGlyph: { color: colors.muted, fontSize: 18, lineHeight: 20, fontWeight: '500' },
  activeGlyph: { color: colors.primary, fontWeight: '700' },
  navLabel: { color: colors.muted, fontSize: 9, fontWeight: '700' },
  activeText: { color: colors.primary },
  sideFooter: { marginTop: 'auto', padding: 12, borderTopWidth: 1, borderTopColor: colors.line },
  footerTitle: { color: colors.textSecondary, fontSize: 9, fontWeight: '800', letterSpacing: 1 },
  footerNote: { color: colors.muted, fontSize: 9, lineHeight: 14, marginTop: 5 },
  header: { minHeight: 72, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 14, borderBottomWidth: 1, borderBottomColor: colors.line, backgroundColor: '#F9FAFB' },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 14, flex: 1, minWidth: 0 },
  headerKicker: { color: colors.mutedLight, fontSize: 8, fontWeight: '800', letterSpacing: 1.1 },
  headerSection: { color: colors.text, fontSize: 15, fontWeight: '800', marginTop: 2 },
  headerMeta: { alignItems: 'flex-end', maxWidth: 230 },
  headerMetaText: { color: colors.muted, fontSize: 9, fontWeight: '600' },
  content: { width: '100%', alignSelf: 'center', flex: 1 },
  nav: { position: 'absolute', left: 10, right: 10, flexDirection: 'row', backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: colors.line, borderRadius: 16, paddingHorizontal: 5, paddingVertical: 4, shadowColor: '#101828', shadowOpacity: 0.08, shadowRadius: 18, shadowOffset: { width: 0, height: 8 }, elevation: 4 },
});
