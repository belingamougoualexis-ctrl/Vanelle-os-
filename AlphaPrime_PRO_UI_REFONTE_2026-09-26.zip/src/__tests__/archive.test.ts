import { inspectArchive } from '../services/archive';

describe('archive support matrix', () => {
  test('recognizes mobile-extractable archives', () => {
    expect(inspectArchive('data.zip').kind).toBe('zip');
    expect(inspectArchive('data.tar').kind).toBe('tar');
    expect(inspectArchive('data.gz').kind).toBe('gzip');
    expect(inspectArchive('data.tgz').kind).toBe('tar.gz');
    expect(inspectArchive('data.tar.gz').kind).toBe('tar.gz');
  });

  test('keeps other common archive formats importable but explicit about extraction limits', () => {
    for (const name of ['data.7z', 'data.rar', 'data.bz2', 'data.xz']) {
      const result = inspectArchive(name);
      expect(result.kind).toBe('unknown');
      expect(result.supported).toBe(false);
      expect(result.reason).toBeTruthy();
    }
  });
});
