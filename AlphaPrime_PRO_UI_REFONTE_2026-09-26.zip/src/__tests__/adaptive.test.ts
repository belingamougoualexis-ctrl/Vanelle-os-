import { classifyWindow } from '../ui/adaptive';

describe('adaptive window policy', () => {
  test('uses current adaptive width classes at every boundary', () => {
    expect(classifyWindow(320)).toBe('compact');
    expect(classifyWindow(599)).toBe('compact');
    expect(classifyWindow(600)).toBe('medium');
    expect(classifyWindow(899)).toBe('medium');
    expect(classifyWindow(900)).toBe('expanded');
    expect(classifyWindow(1199)).toBe('expanded');
    expect(classifyWindow(1200)).toBe('large');
    expect(classifyWindow(1599)).toBe('large');
    expect(classifyWindow(1600)).toBe('xlarge');
  });

  test('never relies on phone/tablet labels for layout decisions', () => {
    for (const width of [240, 360, 599, 600, 840, 900, 1199, 1200, 1366, 1599, 1600, 1920]) {
      expect(['compact', 'medium', 'expanded', 'large', 'xlarge']).toContain(classifyWindow(width));
    }
  });
});
