import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { MetricCard } from '../components/MetricCard';
import { AdaptiveCard } from '../components/AdaptiveCard';
import { PrimaryButton } from '../components/PrimaryButton';
import { AppState, DeviceProfile } from '../core/types';
import { colors, radii } from '../ui/theme';

export function DashboardScreen({ state, device, onNavigate }: { state: AppState; device: DeviceProfile | null; onNavigate: (tab: 'Accueil' | 'Projets' | 'Données' | 'Modèles' | 'Évaluation' | 'Gouvernance') => void }) {
  const runs = state.runs.slice(-5).reverse();
  return (
    <ScrollView contentContainerStyle={styles.wrap} showsVerticalScrollIndicator={false}>
      <View style={styles.hero}>
        <Text style={styles.eyebrow}>ALPHA PRIME / LOCAL AI WORKSPACE</Text>
        <Text style={styles.heroTitle}>Un poste de travail clair pour construire, vérifier et déployer localement.</Text>
        <Text style={styles.heroSubtitle}>Aucune statistique n’est inventée : les états apparaissent après des opérations réelles sur cet appareil.</Text>
        <View style={styles.heroMeta}><Text style={styles.heroMetaText}>{device?.model ?? 'Appareil en cours d’analyse'}</Text><Text style={styles.heroMetaText}>{device?.recommendedModelClass ?? 'profil en cours'}</Text></View>
      </View>

      <View style={styles.metricGrid}>
        <MetricCard label="Projets" value={state.projects.length} />
        <MetricCard label="Sources" value={state.sources.length} />
        <MetricCard label="Datasets" value={state.datasets.length} />
        <MetricCard label="Exécutions" value={state.runs.length} />
      </View>

      <AdaptiveCard>
        <View style={styles.sectionHead}><View><Text style={styles.cardTitle}>Entrées de travail</Text><Text style={styles.body}>Trois objets, trois fonctions. Ne pas les mélanger.</Text></View></View>
        <View style={styles.actionGrid}>
          <Action title="Importer un modèle" text="Le modèle local qui sera chargé par le runtime." onPress={() => onNavigate('Modèles')} />
          <Action title="Importer des sources" text="Documents et connaissances à conserver dans l’espace local." onPress={() => onNavigate('Données')} />
          <Action title="Importer un dataset" text="Données destinées aux traitements, évaluations et entraînement." onPress={() => onNavigate('Données')} />
        </View>
      </AdaptiveCard>

      <AdaptiveCard>
        <View style={styles.sectionHead}><View><Text style={styles.cardTitle}>Appareil détecté</Text><Text style={styles.body}>Profil issu des informations exposées par le système.</Text></View></View>
        <View style={styles.deviceGrid}>
          <Info label="Appareil" value={device?.deviceName ?? '—'} />
          <Info label="Fabricant" value={device?.brand ?? '—'} />
          <Info label="Système" value={device?.os ?? '—'} />
          <Info label="RAM" value={device?.totalMemoryMB ? `${Math.round(device.totalMemoryMB / 1024)} Go` : 'non exposée'} />
          <Info label="Forme" value={device?.isTablet ? 'Tablette' : 'Téléphone / autre'} />
          <Info label="Exécution" value={device?.isPhysicalDevice ? 'Appareil physique' : 'Environnement système'} />
          <Info label="Profil modèle" value={device?.recommendedModelClass ?? '—'} />
          <Info label="Stratégie GPU" value={device?.gpuStrategy ?? '—'} />
        </View>
      </AdaptiveCard>

      <AdaptiveCard>
        <View style={styles.sectionHead}><View><Text style={styles.cardTitle}>Journal des opérations</Text><Text style={styles.body}>Les derniers événements réellement enregistrés.</Text></View><Text style={styles.count}>{runs.length}</Text></View>
        {runs.length === 0 ? <View style={styles.emptyState}><Text style={styles.emptyTitle}>Aucune opération enregistrée</Text><Text style={styles.emptyText}>Crée un projet, importe un fichier ou vérifie un modèle pour commencer.</Text></View> : runs.map((run) => (
          <View style={styles.run} key={run.id}>
            <View style={styles.runIndex}><Text style={styles.runIndexText}>{run.status === 'passed' ? 'OK' : '!'}</Text></View>
            <View style={styles.runBody}><Text style={styles.runTitle}>{run.kind.toUpperCase()}</Text><Text style={styles.small}>{run.status.toUpperCase()} · {new Date(run.endedAt).toLocaleString()}</Text></View>
          </View>
        ))}
      </AdaptiveCard>
    </ScrollView>
  );
}

function Action({ title, text, onPress }: { title: string; text: string; onPress: () => void }) {
  return <View style={styles.action}><Text style={styles.actionTitle}>{title}</Text><Text style={styles.actionText}>{text}</Text><PrimaryButton title="Ouvrir" onPress={onPress} secondary /></View>;
}

function Info({ label, value }: { label: string; value: string }) {
  return <View style={styles.info}><Text style={styles.infoLabel}>{label}</Text><Text style={styles.infoValue} numberOfLines={2}>{value}</Text></View>;
}

const styles = StyleSheet.create({
  wrap: { paddingTop: 6, paddingBottom: 120, gap: 16 },
  hero: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line, borderRadius: radii.xl, padding: 24 },
  eyebrow: { color: colors.gold, fontSize: 9, fontWeight: '800', letterSpacing: 1.25 },
  heroTitle: { color: colors.text, fontSize: 29, lineHeight: 34, fontWeight: '800', letterSpacing: -0.8, marginTop: 10, maxWidth: 760 },
  heroSubtitle: { color: colors.muted, fontSize: 13, lineHeight: 20, marginTop: 9, maxWidth: 720 },
  heroMeta: { flexDirection: 'row', flexWrap: 'wrap', gap: 9, marginTop: 18 },
  heroMetaText: { color: colors.textSecondary, fontSize: 10, fontWeight: '700', paddingHorizontal: 10, paddingVertical: 7, borderWidth: 1, borderColor: colors.line, borderRadius: radii.pill, backgroundColor: colors.surfaceSoft },
  metricGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  sectionHead: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 },
  cardTitle: { color: colors.text, fontSize: 16, fontWeight: '800' },
  body: { color: colors.muted, fontSize: 11, lineHeight: 17, marginTop: 3 },
  actionGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 14 },
  action: { flexGrow: 1, flexBasis: 220, minWidth: 210, borderWidth: 1, borderColor: colors.line, borderRadius: radii.md, padding: 14, gap: 6 },
  actionTitle: { color: colors.text, fontSize: 13, fontWeight: '800' },
  actionText: { color: colors.muted, fontSize: 10, lineHeight: 16, minHeight: 47 },
  deviceGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 14 },
  info: { flexGrow: 1, flexBasis: 155, minWidth: 140, backgroundColor: colors.surfaceSoft, borderWidth: 1, borderColor: colors.line, borderRadius: radii.sm, padding: 10 },
  infoLabel: { color: colors.mutedLight, fontSize: 8, fontWeight: '800', letterSpacing: 0.7 },
  infoValue: { color: colors.text, fontSize: 11, fontWeight: '700', marginTop: 4 },
  count: { color: colors.muted, fontSize: 11, fontWeight: '700' },
  emptyState: { borderWidth: 1, borderColor: colors.line, borderRadius: radii.md, padding: 18, marginTop: 12 },
  emptyTitle: { color: colors.text, fontSize: 13, fontWeight: '800' },
  emptyText: { color: colors.muted, fontSize: 11, lineHeight: 17, marginTop: 4 },
  run: { flexDirection: 'row', alignItems: 'center', gap: 11, paddingVertical: 11, borderTopWidth: 1, borderTopColor: colors.line, marginTop: 8 },
  runIndex: { width: 28, height: 28, borderRadius: 8, backgroundColor: colors.surfaceStrong, borderWidth: 1, borderColor: colors.line, alignItems: 'center', justifyContent: 'center' },
  runIndexText: { color: colors.textSecondary, fontSize: 9, fontWeight: '800' },
  runBody: { flex: 1 },
  runTitle: { color: colors.textSecondary, fontSize: 10, fontWeight: '800', letterSpacing: 0.4 },
  small: { color: colors.muted, fontSize: 10, lineHeight: 15, marginTop: 2 },
});
