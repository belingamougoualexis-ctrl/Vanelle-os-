import React, { useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { PrimaryButton } from '../components/PrimaryButton';
import { AdaptiveCard } from '../components/AdaptiveCard';
import { ScreenIntro } from '../components/ScreenIntro';
import { AppState, Project } from '../core/types';
import { colors, radii } from '../ui/theme';

export function ProjectsScreen({ state, setState }: { state: AppState; setState: (s: AppState) => void }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const create = () => {
    const clean = name.trim();
    if (!clean) return Alert.alert('Nom requis', 'Indique un nom de projet.');
    const now = new Date().toISOString();
    const project: Project = { id: `p_${Date.now()}`, name: clean, description: description.trim(), createdAt: now, updatedAt: now };
    setState({ ...state, projects: [...state.projects, project] });
    setName(''); setDescription('');
  };
  return (
    <ScrollView contentContainerStyle={styles.wrap} showsVerticalScrollIndicator={false}>
      <ScreenIntro eyebrow="WORKSPACE" title="Projets" subtitle="Crée et organise tes espaces de travail directement sur l’appareil." />
      <AdaptiveCard>
        <Text style={styles.section}>Nouveau projet</Text>
        <Text style={styles.helper}>Les champs restent vides jusqu’à ce que tu les renseignes.</Text>
        <TextInput value={name} onChangeText={setName} placeholder="Nom du projet" placeholderTextColor={colors.mutedLight} style={styles.input} />
        <TextInput value={description} onChangeText={setDescription} placeholder="Description facultative" placeholderTextColor={colors.mutedLight} style={[styles.input, styles.multiline]} multiline />
        <PrimaryButton title="Créer le projet" onPress={create} />
      </AdaptiveCard>
      {state.projects.length === 0 ? (
        <AdaptiveCard style={styles.empty}><Text style={styles.emptyTitle}>Aucun projet local</Text><Text style={styles.emptyText}>Commence par créer ton premier espace. Rien n’est généré automatiquement.</Text></AdaptiveCard>
      ) : state.projects.map((p) => (
        <AdaptiveCard key={p.id} style={styles.project}>
          <View style={styles.projectMark}><Text style={styles.projectMarkText}>{p.name.trim().slice(0, 1).toUpperCase()}</Text></View>
          <View style={{ flex: 1 }}><Text style={styles.name}>{p.name}</Text><Text style={styles.small}>{p.description || 'Aucune description renseignée'}</Text></View>
          <View style={styles.arrow}><Text style={styles.arrowText}>›</Text></View>
        </AdaptiveCard>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { paddingTop: 8, paddingBottom: 120, gap: 14 },
  section: { color: colors.text, fontSize: 16, fontWeight: '800' },
  helper: { color: colors.muted, fontSize: 11, lineHeight: 17, marginTop: 2, marginBottom: 5 },
  input: { minHeight: 50, backgroundColor: colors.surfaceSoft, borderRadius: radii.md, paddingHorizontal: 14, paddingVertical: 12, color: colors.text, borderWidth: 1, borderColor: colors.line, fontSize: 13 },
  multiline: { minHeight: 96, textAlignVertical: 'top' },
  empty: { alignItems: 'center' },
  emptyTitle: { color: colors.text, fontSize: 14, fontWeight: '800' },
  emptyText: { color: colors.muted, fontSize: 11, lineHeight: 17, textAlign: 'center', marginTop: 5, maxWidth: 500 },
  project: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  projectMark: { width: 43, height: 43, borderRadius: 15, backgroundColor: colors.surfaceStrong, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.line },
  projectMarkText: { color: colors.textSecondary, fontSize: 15, fontWeight: '800' },
  name: { color: colors.text, fontSize: 14, fontWeight: '800' },
  small: { color: colors.muted, fontSize: 11, lineHeight: 17, marginTop: 3 },
  arrow: { width: 30, height: 30, borderRadius: 11, backgroundColor: colors.surfaceSoft, alignItems: 'center', justifyContent: 'center' },
  arrowText: { color: colors.textSecondary, fontSize: 20, lineHeight: 22, marginTop: -1 },
});
