import React, { useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { AppState, DatasetProfile, SourceAsset } from '../core/types';
import { profileCsv, profileJson } from '../services/dataEngine';
import { extractArchive, inspectArchive } from '../services/archive';
import { PrimaryButton } from '../components/PrimaryButton';
import { AdaptiveCard } from '../components/AdaptiveCard';
import { ScreenIntro } from '../components/ScreenIntro';
import { colors, radii } from '../ui/theme';

async function pickAnyFile() {
  return DocumentPicker.getDocumentAsync({ type: '*/*', copyToCacheDirectory: true, multiple: false });
}

function extension(name: string): string {
  const lower = name.toLowerCase();
  if (lower.endsWith('.tar.gz')) return 'tar.gz';
  return lower.split('.').pop() || 'unknown';
}

async function copyPrivate(uri: string, name: string, folder: 'sources' | 'datasets') {
  const dir = `${FileSystem.documentDirectory}${folder}/`;
  await FileSystem.makeDirectoryAsync(dir, { intermediates: true });
  const clean = name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const destination = `${dir}${Date.now()}_${clean}`;
  await FileSystem.copyAsync({ from: uri, to: destination });
  const info = await FileSystem.getInfoAsync(destination);
  if (!info.exists || !('size' in info) || !info.size) throw new Error('Le fichier n’a pas pu être stocké dans l’espace privé local.');
  return { destination, size: info.size };
}

export function DataScreen({ state, setState, onOpenModel }: { state: AppState; setState: (s: AppState) => void; onOpenModel?: () => void }) {
  const [busy, setBusy] = useState(false);

  const importModelRoute = () => { if (onOpenModel) onOpenModel(); else Alert.alert('Importer un modèle', 'Ouvre la section Modèles pour importer et vérifier un modèle GGUF local.'); };

  const importSource = async () => {
    if (busy) return;
    const result = await pickAnyFile();
    if (result.canceled || !result.assets[0]) return;
    const asset = result.assets[0];
    setBusy(true);
    try {
      const stored = await copyPrivate(asset.uri, asset.name, 'sources');
      const archive = inspectArchive(asset.name);
      let extractedCount = 0;
      if (archive.kind !== 'unknown' && archive.supported) {
        const extracted = await extractArchive(stored.destination, asset.name);
        extractedCount = extracted.length;
      }
      const projectId = state.projects[0]?.id ?? 'unassigned';
      const source: SourceAsset = {
        id: `s_${Date.now()}`,
        projectId,
        name: asset.name,
        sourcePath: stored.destination,
        format: extension(asset.name),
        sizeBytes: stored.size,
        archive: archive.kind !== 'unknown',
        extractedCount,
        importedAt: new Date().toISOString(),
      };
      setState({ ...state, sources: [...state.sources, source] });
      Alert.alert('Source importée', extractedCount ? `${asset.name}\n${extractedCount} élément(s) extrait(s) localement.` : `${asset.name}\nConservée dans le stockage local.`);
    } catch (e) {
      Alert.alert('Import impossible', e instanceof Error ? e.message : 'Erreur locale inconnue.');
    } finally {
      setBusy(false);
    }
  };

  const importDataset = async () => {
    if (busy) return;
    const result = await pickAnyFile();
    if (result.canceled || !result.assets[0]) return;
    const asset = result.assets[0];
    const ext = extension(asset.name);
    setBusy(true);
    try {
      const stored = await copyPrivate(asset.uri, asset.name, 'datasets');
      const now = new Date().toISOString();
      const projectId = state.projects[0]?.id ?? 'unassigned';
      let profiled = false;
      let profile = { rows: 0, columns: 0, missingCells: 0, duplicateRows: 0, malformedRows: 0, piiHits: 0, schemaHash: '' };
      if (ext === 'csv' || ext === 'json') {
        const text = await FileSystem.readAsStringAsync(asset.uri);
        profile = ext === 'csv' ? await profileCsv(text) : await profileJson(text);
        profiled = true;
      } else if (['zip', 'tar', 'gz', 'tgz'].includes(ext) || asset.name.toLowerCase().endsWith('.tar.gz')) {
        const inspection = inspectArchive(asset.name);
        if (inspection.supported) {
          const extracted = await extractArchive(asset.uri, asset.name);
          const candidate = extracted.find((x) => /\.(csv|json)$/i.test(x.name));
          if (candidate) {
            const text = await FileSystem.readAsStringAsync(candidate.uri);
            profile = /\.csv$/i.test(candidate.name) ? await profileCsv(text) : await profileJson(text);
            profiled = true;
          }
        }
      }
      const dataset: DatasetProfile = { id: `d_${Date.now()}`, projectId, name: asset.name, sourcePath: stored.destination, format: ext, sizeBytes: stored.size, profiled, ...profile, importedAt: now };
      const run = profiled ? { id: `r_${Date.now() + 1}`, projectId, kind: 'profile' as const, startedAt: now, endedAt: new Date().toISOString(), status: profile.malformedRows === 0 ? 'passed' as const : 'failed' as const, metrics: { rows: profile.rows, columns: profile.columns, missingCells: profile.missingCells, duplicateRows: profile.duplicateRows, malformedRows: profile.malformedRows, piiHits: profile.piiHits }, notes: ['Profilage exécuté localement. Les PII sont des candidats détectés par règles, pas une classification juridique.'] } : null;
      setState({ ...state, datasets: [...state.datasets, dataset], runs: run ? [...state.runs, run] : state.runs });
      Alert.alert('Dataset importé', profiled ? `${profile.rows} lignes · ${profile.columns} colonnes analysées localement.` : `${asset.name} a été importé. Le format est conservé sans inventer de statistiques.`);
    } catch (e) {
      Alert.alert('Import impossible', e instanceof Error ? e.message : 'Erreur locale inconnue.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.wrap} showsVerticalScrollIndicator={false}>
      <ScreenIntro eyebrow="DATA WORKSPACE" title="Données et sources" subtitle="Trois flux distincts : le modèle exécute, les sources apportent des documents, le dataset sert à l’entraînement et à l’évaluation. Tous les fichiers peuvent être importés ; les archives reconnues sont décompressées localement." />

      <View style={styles.importGrid}>
        <ImportCard icon="01" title="Importer un modèle" text="GGUF local uniquement. Vérification runtime dans Modèles." button="Ouvrir Modèles" onPress={importModelRoute} disabled={busy} />
        <ImportCard icon="02" title="Importer des sources" text="Documents, archives et fichiers bruts. Le contenu est conservé dans l’espace local." button={busy ? 'Traitement…' : 'Choisir un fichier'} onPress={importSource} disabled={busy} />
        <ImportCard icon="03" title="Importer un dataset" text="Tous formats sont acceptés à l’import. CSV/JSON sont profilés réellement ; les autres restent intacts." button={busy ? 'Traitement…' : 'Choisir un dataset'} onPress={importDataset} disabled={busy} />
      </View>

      <AdaptiveCard>
        <View style={styles.sectionHead}><Text style={styles.section}>Sources importées</Text><Text style={styles.count}>{state.sources.length}</Text></View>
        {state.sources.length === 0 ? <Text style={styles.emptyText}>Aucune source locale. Rien n’est ajouté automatiquement.</Text> : state.sources.map((s) => <View key={s.id} style={styles.listRow}><View style={styles.indexBox}><Text style={styles.indexText}>S</Text></View><View style={styles.rowBody}><Text style={styles.name} numberOfLines={1}>{s.name}</Text><Text style={styles.meta}>{s.format.toUpperCase()} · {(s.sizeBytes / 1024 / 1024).toFixed(1)} MB{s.extractedCount ? ` · ${s.extractedCount} extrait(s)` : ''}</Text></View></View>)}
      </AdaptiveCard>

      <AdaptiveCard>
        <View style={styles.sectionHead}><Text style={styles.section}>Datasets importés</Text><Text style={styles.count}>{state.datasets.length}</Text></View>
        {state.datasets.length === 0 ? <Text style={styles.emptyText}>Aucun dataset local. Les indicateurs restent vides jusqu’à une vraie importation.</Text> : state.datasets.map((d) => (
          <View key={d.id} style={styles.datasetBlock}>
            <View style={styles.listRow}><View style={styles.indexBox}><Text style={styles.indexText}>D</Text></View><View style={styles.rowBody}><Text style={styles.name} numberOfLines={1}>{d.name}</Text><Text style={styles.meta}>{d.format.toUpperCase()} · {(d.sizeBytes / 1024 / 1024).toFixed(1)} MB · {d.profiled ? 'profilé' : 'importé'}</Text></View></View>
            {d.profiled ? <View style={styles.statRow}><MiniStat label="Lignes" value={String(d.rows)} /><MiniStat label="Colonnes" value={String(d.columns)} /><MiniStat label="Manquants" value={String(d.missingCells)} /><MiniStat label="Doublons" value={String(d.duplicateRows)} /></View> : null}
            {d.profiled ? <Text style={styles.line}>Mal formées : {d.malformedRows} · candidats PII : {d.piiHits}</Text> : null}
          </View>
        ))}
      </AdaptiveCard>
    </ScrollView>
  );
}

function ImportCard({ icon, title, text, button, onPress, disabled }: { icon: string; title: string; text: string; button: string; onPress: () => void; disabled: boolean }) {
  return <AdaptiveCard style={styles.importCard}><View style={styles.indexLarge}><Text style={styles.indexLargeText}>{icon}</Text></View><View style={styles.importBody}><Text style={styles.importTitle}>{title}</Text><Text style={styles.importText}>{text}</Text><PrimaryButton title={button} onPress={onPress} disabled={disabled} secondary /></View></AdaptiveCard>;
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return <View style={styles.mini}><Text style={styles.miniLabel}>{label}</Text><Text style={styles.miniValue}>{value}</Text></View>;
}

const styles = StyleSheet.create({
  wrap: { paddingTop: 6, paddingBottom: 120, gap: 16 },
  importGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  importCard: { flexGrow: 1, flexBasis: 300, minWidth: 280, flexDirection: 'row', gap: 14, alignItems: 'flex-start' },
  indexLarge: { width: 42, height: 42, borderRadius: 12, backgroundColor: colors.surfaceStrong, borderWidth: 1, borderColor: colors.line, alignItems: 'center', justifyContent: 'center' },
  indexLargeText: { color: colors.primary, fontSize: 11, fontWeight: '800', letterSpacing: 0.7 },
  importBody: { flex: 1, minWidth: 0, gap: 7 },
  importTitle: { color: colors.text, fontSize: 15, fontWeight: '800' },
  importText: { color: colors.muted, fontSize: 11, lineHeight: 17, minHeight: 53 },
  sectionHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  section: { color: colors.text, fontSize: 15, fontWeight: '800' },
  count: { color: colors.muted, fontSize: 11, fontWeight: '700' },
  emptyText: { color: colors.muted, fontSize: 11, lineHeight: 17, marginTop: 9 },
  listRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 13, marginTop: 12, borderTopWidth: 1, borderTopColor: colors.line },
  indexBox: { width: 34, height: 34, borderRadius: 10, backgroundColor: colors.surfaceStrong, borderWidth: 1, borderColor: colors.line, alignItems: 'center', justifyContent: 'center' },
  indexText: { color: colors.textSecondary, fontSize: 11, fontWeight: '800' },
  rowBody: { flex: 1, minWidth: 0 },
  name: { color: colors.text, fontSize: 13, fontWeight: '700' },
  meta: { color: colors.muted, fontSize: 10, marginTop: 3 },
  datasetBlock: { borderTopWidth: 1, borderTopColor: colors.line, marginTop: 4 },
  statRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  mini: { flexGrow: 1, minWidth: 90, backgroundColor: colors.surfaceSoft, borderRadius: radii.sm, borderWidth: 1, borderColor: colors.line, padding: 9 },
  miniLabel: { color: colors.mutedLight, fontSize: 8, fontWeight: '800', letterSpacing: 0.5 },
  miniValue: { color: colors.text, fontSize: 16, fontWeight: '800', marginTop: 3 },
  line: { color: colors.textSecondary, fontSize: 10, lineHeight: 16, marginTop: 10 },
});
