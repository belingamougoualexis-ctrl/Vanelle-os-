import React, { useEffect, useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { PrimaryButton } from '../components/PrimaryButton';
import { AdaptiveCard } from '../components/AdaptiveCard';
import { ScreenIntro } from '../components/ScreenIntro';
import { AppState, BackendInfo, DeviceProfile } from '../core/types';
import { chatLocal, getLoadedBackend, getLoadedRuntimeEvidence, importModelFromUri, inspectBackends, loadLocalModel, unloadLocalModel } from '../services/llm';
import { colors, radii } from '../ui/theme';

export function ModelScreen({ state, setState, device }: { state: AppState; setState: (s: AppState) => void; device: DeviceProfile | null }) {
  const [backends, setBackends] = useState<BackendInfo[]>([]);
  const [busy, setBusy] = useState(false);
  const [runtime, setRuntime] = useState('Aucun modèle chargé');

  useEffect(() => {
    void inspectBackends().then(setBackends).catch(() => setBackends([]));
  }, []);

  const importModel = async () => {
    if (busy) return;
    const result = await DocumentPicker.getDocumentAsync({ type: ['application/octet-stream', '*/*'], copyToCacheDirectory: true });
    if (result.canceled || !result.assets[0]) return;
    const asset = result.assets[0];
    if (!asset.name.toLowerCase().endsWith('.gguf')) {
      Alert.alert('Format non pris en charge', 'Sélectionne un modèle GGUF local.');
      return;
    }
    setBusy(true);
    try {
      const model = await importModelFromUri(asset.uri, asset.name);
      setState({ ...state, localModel: model });
      Alert.alert('Modèle importé', 'Le fichier GGUF a été vérifié puis copié dans le stockage privé.');
    } catch (e) {
      Alert.alert('Import impossible', e instanceof Error ? e.message : 'Erreur locale');
    } finally {
      setBusy(false);
    }
  };

  const testLoad = async () => {
    if (!state.localModel || busy) return;
    setBusy(true);
    try {
      await loadLocalModel(state.localModel, device?.totalMemoryMB ?? null);
      await chatLocal(state.localModel, [{ role: 'user', content: 'Réponds uniquement par OK.' }], device?.totalMemoryMB ?? null);
      const evidence = getLoadedRuntimeEvidence();
      const capability = evidence.gpu ? `Accélération matérielle confirmée · ${evidence.deviceName ?? getLoadedBackend()}` : 'Calcul local CPU confirmé';
      setRuntime(capability);
      Alert.alert('Vérification réussie', capability);
    } catch (e) {
      setRuntime('Vérification échouée');
      Alert.alert('Vérification échouée', e instanceof Error ? e.message : 'Erreur locale');
    } finally {
      setBusy(false);
    }
  };

  const unload = async () => {
    await unloadLocalModel();
    setRuntime('Aucun modèle chargé');
  };

  return (
    <ScrollView contentContainerStyle={styles.wrap} showsVerticalScrollIndicator={false}>
      <ScreenIntro eyebrow="MODEL RUNTIME" title="Modèle local" subtitle="Le runtime ne déclare une capacité utilisable qu’après chargement et inférence réellement exécutés." />

      <AdaptiveCard>
        <View style={styles.sectionHead}><Text style={styles.section}>Machine active</Text><View style={styles.statusPill}><Text style={styles.statusText}>PROFIL LOCAL</Text></View></View>
        <Text style={styles.device}>{device?.brand ?? '—'} {device?.model ?? '—'}</Text>
        <Text style={styles.line}>{device?.os ?? '—'} · {device?.totalMemoryMB ? `${Math.round(device.totalMemoryMB / 1024)} Go RAM` : 'RAM non exposée'}</Text>
        <View style={styles.chips}><InfoChip label="Profil" value={device?.recommendedModelClass ?? '—'} /><InfoChip label="Stratégie" value={device?.gpuStrategy ?? '—'} /></View>
      </AdaptiveCard>

      <AdaptiveCard>
        <Text style={styles.section}>Capacités runtime disponibles</Text>
        {backends.length === 0 ? (
          <View style={styles.inlineNotice}><Text style={styles.noticeText}>Aucun backend natif utilisable n’a encore été confirmé par ce build.</Text></View>
        ) : backends.map((b) => (
          <View key={`${b.backend}-${b.deviceName}`} style={styles.backendRow}>
            <View style={styles.backendIcon}><Text style={styles.backendLetter}>{b.backend.slice(0, 1).toUpperCase()}</Text></View>
            <View style={{ flex: 1 }}><Text style={styles.backendName}>{b.backend}</Text><Text style={styles.line}>{b.deviceName} · {b.type}</Text></View>
          </View>
        ))}
      </AdaptiveCard>

      <PrimaryButton title={busy ? 'Opération en cours…' : 'Importer un modèle GGUF'} onPress={importModel} disabled={busy} />

      {state.localModel ? (
        <AdaptiveCard>
          <View style={styles.sectionHead}><View style={{ flex: 1 }}><Text style={styles.name}>{state.localModel.name}</Text><Text style={styles.line}>{(state.localModel.sizeBytes / 1024 / 1024).toFixed(1)} MB · GGUF</Text></View><View style={styles.modelBadge}><Text style={styles.modelBadgeText}>LOCAL</Text></View></View>
          <Text style={styles.path}>{state.localModel.name} · stockage privé de l’appareil</Text>
          <View style={styles.actions}><View style={{ flex: 1 }}><PrimaryButton title={busy ? 'Vérification…' : 'Vérifier réellement'} onPress={testLoad} disabled={busy} /></View><View style={{ flex: 1 }}><PrimaryButton title="Libérer la mémoire" onPress={unload} disabled={busy} secondary /></View></View>
          <View style={styles.runtimeBox}><Text style={styles.runtimeLabel}>ÉTAT DU RUNTIME</Text><Text style={styles.runtime}>{runtime}</Text></View>
        </AdaptiveCard>
      ) : (
        <AdaptiveCard style={styles.empty}><Text style={styles.emptyTitle}>Aucun modèle local</Text><Text style={styles.emptyText}>Aucune capacité de génération n’est présumée avant l’installation et la vérification d’un modèle réel.</Text></AdaptiveCard>
      )}
    </ScrollView>
  );
}

function InfoChip({ label, value }: { label: string; value: string }) {
  return <View style={styles.infoChip}><Text style={styles.infoLabel}>{label}</Text><Text style={styles.infoValue}>{value}</Text></View>;
}

const styles = StyleSheet.create({
  wrap: { paddingTop: 8, paddingBottom: 120, gap: 14 },
  sectionHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  section: { color: colors.text, fontSize: 15, fontWeight: '800' },
  statusPill: { paddingHorizontal: 8, paddingVertical: 5, backgroundColor: colors.surfaceStrong, borderRadius: radii.pill, borderWidth: 1, borderColor: colors.line },
  statusText: { color: colors.textSecondary, fontSize: 8, fontWeight: '800', letterSpacing: 0.55 },
  device: { color: colors.text, fontSize: 15, fontWeight: '800', marginTop: 10 },
  line: { color: colors.muted, fontSize: 11, lineHeight: 17, marginTop: 3 },
  chips: { flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 13 },
  infoChip: { flexGrow: 1, minWidth: 130, backgroundColor: colors.surfaceSoft, borderWidth: 1, borderColor: colors.line, borderRadius: radii.sm, padding: 9 },
  infoLabel: { color: colors.mutedLight, fontSize: 8, fontWeight: '800', letterSpacing: 0.65 },
  infoValue: { color: colors.text, fontSize: 11, fontWeight: '800', marginTop: 3 },
  inlineNotice: { flexDirection: 'row', gap: 8, alignItems: 'center', marginTop: 12, padding: 12, borderRadius: radii.sm, backgroundColor: colors.surfaceSoft, borderWidth: 1, borderColor: colors.line },
  noticeText: { flex: 1, color: colors.muted, fontSize: 11, lineHeight: 17 },
  backendRow: { flexDirection: 'row', alignItems: 'center', gap: 11, paddingVertical: 11, borderTopWidth: 1, borderTopColor: colors.line, marginTop: 8 },
  backendIcon: { width: 36, height: 36, borderRadius: 10, backgroundColor: colors.surfaceStrong, alignItems: 'center', justifyContent: 'center' },
  backendLetter: { color: colors.primary, fontSize: 13, fontWeight: '800' },
  name: { color: colors.text, fontSize: 14, fontWeight: '800' },
  modelBadge: { paddingHorizontal: 8, paddingVertical: 5, borderRadius: radii.pill, backgroundColor: colors.surfaceStrong, borderWidth: 1, borderColor: colors.line },
  modelBadgeText: { color: colors.primary, fontSize: 8, fontWeight: '800', letterSpacing: 0.6 },
  path: { color: colors.mutedLight, fontSize: 9, lineHeight: 14, marginTop: 9 },
  actions: { flexDirection: 'row', gap: 9, marginTop: 13 },
  runtimeBox: { marginTop: 13, padding: 12, backgroundColor: colors.surfaceStrong, borderRadius: radii.md, borderWidth: 1, borderColor: colors.line },
  runtimeLabel: { color: colors.mutedLight, fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  runtime: { color: colors.text, fontSize: 11, lineHeight: 17, marginTop: 4, fontWeight: '700' },
  empty: { alignItems: 'center' },
  emptyTitle: { color: colors.text, fontSize: 14, fontWeight: '800' },
  emptyText: { color: colors.muted, fontSize: 11, lineHeight: 17, textAlign: 'center', marginTop: 4, maxWidth: 520 },
});
