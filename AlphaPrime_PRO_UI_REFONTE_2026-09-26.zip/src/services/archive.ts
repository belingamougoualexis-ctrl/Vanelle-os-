import { gunzipSync, unzipSync } from 'fflate';
import * as FileSystem from 'expo-file-system/legacy';

export type ExtractedEntry = { name: string; uri: string; sizeBytes: number };
export type ArchiveInspection = { supported: boolean; kind: 'zip' | 'tar' | 'gzip' | 'tar.gz' | 'unknown'; reason?: string };

const ARCHIVE_EXTENSIONS = new Set(['zip', 'tar', 'gz', 'tgz', 'bz2', 'xz', '7z', 'rar']);

function extension(name: string): string {
  return name.toLowerCase().split('.').pop() ?? '';
}

export function inspectArchive(name: string): ArchiveInspection {
  const lower = name.toLowerCase();
  if (lower.endsWith('.tar.gz') || lower.endsWith('.tgz')) return { supported: true, kind: 'tar.gz' };
  const ext = extension(name);
  if (ext === 'zip') return { supported: true, kind: 'zip' };
  if (ext === 'tar') return { supported: true, kind: 'tar' };
  if (ext === 'gz') return { supported: true, kind: 'gzip' };
  if (ARCHIVE_EXTENSIONS.has(ext)) return { supported: false, kind: 'unknown', reason: `Archive ${ext.toUpperCase()} détectée. Le fichier peut être conservé et transféré, mais ce runtime mobile ne fournit pas encore son extracteur natif.` };
  return { supported: false, kind: 'unknown' };
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return globalThis.btoa(binary);
}

function decodeText(bytes: Uint8Array): string {
  return new TextDecoder().decode(bytes).replace(/\0+$/g, '');
}

function safeRelativePath(name: string): string | null {
  const normalized = name.replace(/\\/g, '/').replace(/^\/+/, '');
  const parts = normalized.split('/').filter(Boolean);
  if (parts.some((part) => part === '..')) return null;
  const safe = parts.map((part) => part.replace(/[^a-zA-Z0-9._-]/g, '_')).join('/');
  return safe || null;
}

function tarEntries(bytes: Uint8Array): Array<{ name: string; bytes: Uint8Array }> {
  const entries: Array<{ name: string; bytes: Uint8Array }> = [];
  for (let offset = 0; offset + 512 <= bytes.length; offset += 512) {
    const header = bytes.subarray(offset, offset + 512);
    const empty = header.every((b) => b === 0);
    if (empty) break;
    const name = decodeText(header.subarray(0, 100));
    const prefix = decodeText(header.subarray(345, 500));
    const sizeText = decodeText(header.subarray(124, 136)).trim().replace(/\0/g, '');
    const size = Number.parseInt(sizeText || '0', 8);
    const type = header[156];
    if (type === 53) { // directory
      offset += Math.ceil(size / 512) * 512 - 512;
      continue;
    }
    if (!Number.isFinite(size) || size < 0 || offset + 512 + size > bytes.length) throw new Error('Archive TAR invalide ou tronquée.');
    const fullName = prefix ? `${prefix}/${name}` : name;
    entries.push({ name: fullName, bytes: bytes.slice(offset + 512, offset + 512 + size) });
    offset += Math.ceil(size / 512) * 512 - 512;
  }
  return entries;
}

async function writeBytes(dir: string, relativeName: string, bytes: Uint8Array): Promise<ExtractedEntry | null> {
  const safe = safeRelativePath(relativeName);
  if (!safe) return null;
  const target = `${dir}${safe}`;
  const segments = safe.split('/');
  if (segments.length > 1) await FileSystem.makeDirectoryAsync(`${dir}${segments.slice(0, -1).join('/')}/`, { intermediates: true });
  await FileSystem.writeAsStringAsync(target, bytesToBase64(bytes), { encoding: FileSystem.EncodingType.Base64 });
  return { name: safe, uri: target, sizeBytes: bytes.byteLength };
}

export async function extractArchive(uri: string, name: string): Promise<ExtractedEntry[]> {
  const inspection = inspectArchive(name);
  if (!inspection.supported) throw new Error(inspection.reason || 'Le fichier n’est pas une archive extractible par ce runtime.');
  const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
  const binary = Uint8Array.from(globalThis.atob(base64), (char) => char.charCodeAt(0));
  const stamp = Date.now();
  const dir = `${FileSystem.documentDirectory}extracted/${stamp}/`;
  await FileSystem.makeDirectoryAsync(dir, { intermediates: true });
  let entries: Array<{ name: string; bytes: Uint8Array }> = [];
  if (inspection.kind === 'zip') {
    const files = unzipSync(binary) as Record<string, Uint8Array>;
    entries = Object.entries(files).filter(([key]) => !key.endsWith('/')).map(([key, value]) => ({ name: key, bytes: value }));
  } else if (inspection.kind === 'gzip') {
    const nameWithoutGz = name.replace(/\.gz$/i, '') || 'decompressed';
    entries = [{ name: nameWithoutGz, bytes: gunzipSync(binary) }];
  } else if (inspection.kind === 'tar.gz') {
    entries = tarEntries(gunzipSync(binary));
  } else {
    entries = tarEntries(binary);
  }
  const written: ExtractedEntry[] = [];
  for (const entry of entries) {
    const result = await writeBytes(dir, entry.name, entry.bytes);
    if (result) written.push(result);
  }
  return written;
}
