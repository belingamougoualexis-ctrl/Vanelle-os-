import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors } from '../ui/theme';

export function ScreenIntro({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle: string }) {
  return (
    <View style={styles.wrap}>
      <Text style={styles.eyebrow}>{eyebrow}</Text>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.subtitle}>{subtitle}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { gap: 7, paddingTop: 2 },
  eyebrow: { color: colors.mutedLight, fontSize: 10, fontWeight: '800', letterSpacing: 1.35 },
  title: { color: colors.text, fontSize: 31, lineHeight: 36, fontWeight: '800', letterSpacing: -0.85 },
  subtitle: { color: colors.muted, fontSize: 13, lineHeight: 20, maxWidth: 780 },
});
