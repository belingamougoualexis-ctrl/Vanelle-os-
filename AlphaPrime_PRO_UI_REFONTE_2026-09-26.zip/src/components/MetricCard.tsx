import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, radii } from '../ui/theme';

export function MetricCard({ label, value, hint }: { label: string; value: string | number; hint?: string }) {
  return (
    <View style={styles.card}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.value}>{value}</Text>
      {hint ? <Text style={styles.hint}>{hint}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flexGrow: 1,
    flexBasis: 150,
    minWidth: 145,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: radii.lg,
    padding: 16,
  },
  label: { color: colors.muted, fontSize: 11, fontWeight: '700', letterSpacing: 0.1 },
  value: { color: colors.text, fontSize: 28, lineHeight: 32, fontWeight: '800', marginTop: 9, letterSpacing: -0.7 },
  hint: { color: colors.mutedLight, fontSize: 10, marginTop: 4, lineHeight: 15 },
});
