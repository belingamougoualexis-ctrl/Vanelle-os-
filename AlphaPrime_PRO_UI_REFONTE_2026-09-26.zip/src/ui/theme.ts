import { Platform, StyleSheet } from 'react-native';

// Business-grade light palette: restrained, high-contrast, no decorative colored dots/orbs.
export const colors = {
  background: '#F5F6F8',
  surface: '#FFFFFF',
  surfaceSoft: '#F8F9FB',
  surfaceStrong: '#F0F2F5',
  text: '#121722',
  textSecondary: '#374151',
  muted: '#667085',
  mutedLight: '#98A2B3',
  line: '#E4E7EC',
  lineStrong: '#D0D5DD',
  primary: '#2557C5',
  primaryPressed: '#1E46A3',
  primarySoft: '#EAF0FF',
  gold: '#B88A2E',
  goldSoft: '#F7F0DF',
  success: '#166534',
  warning: '#8A5A14',
  danger: '#B42318',
  onPrimary: '#FFFFFF',
  darkPanel: '#18202C',
  darkPanel2: '#222C3A',
} as const;

export const radii = {
  xs: 8,
  sm: 10,
  md: 14,
  lg: 18,
  xl: 22,
  pill: 999,
} as const;

export const spacing = {
  xs: 6,
  sm: 10,
  md: 14,
  lg: 18,
  xl: 24,
  xxl: 32,
} as const;

export const typography = StyleSheet.create({
  body: {
    fontSize: 14,
    lineHeight: 21,
    color: colors.textSecondary,
    fontFamily: Platform.select({ ios: 'System', android: 'sans-serif', windows: 'Segoe UI', default: undefined }),
  },
  title: {
    fontSize: 30,
    lineHeight: 36,
    fontWeight: '800',
    letterSpacing: -0.8,
    color: colors.text,
    fontFamily: Platform.select({ ios: 'System', android: 'sans-serif', windows: 'Segoe UI', default: undefined }),
  },
  subtitle: {
    fontSize: 14,
    lineHeight: 21,
    color: colors.muted,
    fontFamily: Platform.select({ ios: 'System', android: 'sans-serif', windows: 'Segoe UI', default: undefined }),
  },
  section: {
    fontSize: 16,
    lineHeight: 21,
    fontWeight: '700',
    letterSpacing: -0.15,
    color: colors.text,
    fontFamily: Platform.select({ ios: 'System', android: 'sans-serif', windows: 'Segoe UI', default: undefined }),
  },
});
