import { useWindowDimensions } from 'react-native';

export type WindowClass = 'compact' | 'medium' | 'expanded' | 'large' | 'xlarge';
export type HeightClass = 'compact' | 'medium' | 'expanded';

export function classifyWindow(width: number): WindowClass {
  if (width < 600) return 'compact';
  if (width < 900) return 'medium';
  if (width < 1200) return 'expanded';
  if (width < 1600) return 'large';
  return 'xlarge';
}

export function classifyHeight(height: number): HeightClass {
  if (height < 480) return 'compact';
  if (height < 900) return 'medium';
  return 'expanded';
}

export function useAdaptiveLayout() {
  const { width, height } = useWindowDimensions();
  const windowClass = classifyWindow(width);
  const heightClass = classifyHeight(height);
  return {
    width,
    height,
    windowClass,
    heightClass,
    isCompact: windowClass === 'compact',
    isMedium: windowClass === 'medium',
    isExpanded: windowClass === 'expanded',
    isLarge: windowClass === 'large',
    isXLarge: windowClass === 'xlarge',
    isShortHeight: heightClass === 'compact',
    horizontalPadding: width < 600 ? 14 : width < 900 ? 20 : width < 1200 ? 28 : 36,
    contentMaxWidth: width >= 1600 ? 1500 : width >= 1200 ? 1300 : width >= 900 ? 1120 : 920,
  };
}
