package com.vanelle.os

import android.content.Context
import android.graphics.drawable.GradientDrawable

/**
 * Identité visuelle Vanelle : Rose / Blanc / Noir
 * (cohérent Vanelle OS · Studio · Négociation)
 */
object VanelleBrand {
    const val ROSE = 0xFFE11D48.toInt()       // rose principal
    const val ROSE_SOFT = 0xFFFCE7F3.toInt()  // fond rose léger
    const val ROSE_DEEP = 0xFFBE123C.toInt()  // accent
    const val WHITE = UiKit.WHITE
    const val BLACK = 0xFF0A0A0A.toInt()
    const val GRAY = UiKit.TEXT_MUTED
    const val SURFACE = 0xFFFAFAFA.toInt()

    fun rosePill(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(ROSE)
            cornerRadius = 24f * d
        }
    }

    fun roseOutline(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(WHITE)
            setStroke((1.5f * d).toInt(), ROSE)
            cornerRadius = 16f * d
        }
    }

    fun card(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(WHITE)
            setStroke((1f * d).toInt(), 0xFFE5E5E5.toInt())
            cornerRadius = 14f * d
        }
    }

    fun privacyBanner(ctx: Context): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(ROSE_SOFT)
            setStroke((1f * d).toInt(), ROSE)
            cornerRadius = 12f * d
        }
    }
}
