package com.vanelle.os
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.method.ScrollingMovementMethod
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max

/**
 * Affiche la mascotte par-dessus l'écran avec synchronisation labiale
 * (bouche qui s'ouvre/ferme au rythme de la parole TTS).
 */
object OverlayHelper {
    private var currentView: View? = null
    private var mouthView: View? = null
    private var answerView: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var hideRunnable: Runnable? = null
    private var mouthRunnable: Runnable? = null
    private var mouthAnimator: ValueAnimator? = null
    private var isTalking = false

    // Formes de bouche personnalisées (visèmes simplifiés)
    // scaleY plafonné pour que la bouche ne monte JAMAIS jusqu'aux yeux.
    // scaleY = ouverture, scaleX = largeur des lèvres
    private const val MOUTH_CLOSED_Y = 0.18f
    private const val MOUTH_CLOSED_X = 0.60f
    private const val MOUTH_MID_Y = 0.38f
    private const val MOUTH_MID_X = 0.88f
    private const val MOUTH_OPEN_Y = 0.52f   // max réel (plus de 1.0 qui déformait le visage)
    private const val MOUTH_OPEN_X = 1.00f
    private const val MOUTH_WIDE_Y = 0.40f   // sourire / "é"
    private const val MOUTH_WIDE_X = 1.15f
    private const val MOUTH_ROUND_Y = 0.45f  // "o" / "ou"
    private const val MOUTH_ROUND_X = 0.72f
    // Compat pour anciens appels
    private const val MOUTH_CLOSED = MOUTH_CLOSED_Y
    private const val MOUTH_MID = MOUTH_MID_Y
    private const val MOUTH_OPEN = MOUTH_OPEN_Y

    fun canDraw(c: Context): Boolean = Settings.canDrawOverlays(c)

    fun requestPermission(c: Context) {
        try {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            c.startActivity(i)
        } catch (_: Exception) {}
    }

    private fun dp(c: Context, v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), c.resources.displayMetrics).toInt()

    fun show(c: Context, mascotDrawableId: Int, question: String, answer: String) {
        showInternal(c, mascotDrawableId, question, answer, autoHideMs = 16_000L)
    }

    fun showMascot(c: Context, mascotDrawableId: Int, greeting: String = "") {
        showInternal(c, mascotDrawableId, "", greeting, autoHideMs = 12_000L)
    }

    /**
     * Démarre la synchro labiale personnalisée.
     * Appelé au début du TTS (onStart).
     */
    /**
     * État d'écoute : la mascotte reste affichée et sa bouche/sourire s'ouvre
     * immédiatement pendant que SpeechRecognizer attend la voix de l'utilisateur.
     */
    fun startListening() {
        handler.post {
            isTalking = true
            hideRunnable?.let { handler.removeCallbacks(it) }
            mouthRunnable?.let { handler.removeCallbacks(it) }
            mouthAnimator?.cancel()

            val mouth = mouthView ?: return@post
            mouth.visibility = View.VISIBLE
            mouth.alpha = 0.95f
            // Ouverture visible du sourire : c'est l'indicateur "je t'écoute".
            animateMouthTo(MOUTH_WIDE_Y, MOUTH_WIDE_X, 160L)
        }
    }

    fun startTalking() {
        handler.post {
            isTalking = true
            hideRunnable?.let { handler.removeCallbacks(it) }
            mouthRunnable?.let { handler.removeCallbacks(it) }
            mouthAnimator?.cancel()

            val mouth = mouthView ?: return@post
            mouth.visibility = View.VISIBLE
            mouth.scaleX = MOUTH_CLOSED_X
            mouth.scaleY = MOUTH_CLOSED_Y
            mouth.alpha = 0.95f
            // Micro-mouvement d'ouverture au démarrage (plus vivant)
            animateMouthTo(MOUTH_MID_Y, MOUTH_MID_X, 110L)
        }
    }

    /**
     * Impulsion labiale synchronisée avec un segment de parole (onRangeStart TTS).
     * Forme des lèvres adaptée au son (visème simplifié français).
     */
    fun pulseMouth(spokenChunk: String? = null) {
        if (!isTalking) return
        handler.post {
            val mouth = mouthView ?: return@post
            mouth.visibility = View.VISIBLE

            val (targetY, targetX, holdMs) = visemeFor(spokenChunk)
            animateMouthTo(targetY, targetX, durationMs = 55L) {
                // Referme naturellement après l'impulsion
                if (isTalking) {
                    handler.postDelayed({
                        if (isTalking) animateMouthTo(MOUTH_CLOSED_Y + 0.08f, MOUTH_CLOSED_X + 0.12f, 95L)
                    }, holdMs)
                }
            }
        }
    }

    /** Arrête la synchro labiale (TTS terminé ou erreur). */
    fun stopTalking() {
        handler.post {
            isTalking = false
            mouthRunnable?.let { handler.removeCallbacks(it) }
            mouthRunnable = null
            mouthAnimator?.cancel()
            mouthAnimator = null

            val mouth = mouthView
            if (mouth != null) {
                animateMouthTo(MOUTH_CLOSED_Y, MOUTH_CLOSED_X, 140L) {
                    mouth.visibility = View.INVISIBLE
                }
            }

            // Disparition quelques secondes après la fin de la parole
            hideRunnable?.let { handler.removeCallbacks(it) }
            hideRunnable = Runnable {
                try {
                    currentView?.let { v ->
                        val wm = v.context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                        wm.removeView(v)
                    }
                } catch (_: Exception) {}
                currentView = null
                mouthView = null
                answerView = null
            }
            hideRunnable?.let { handler.postDelayed(it, 3500) }
        }
    }

    // --- Animation personnalisée des lèvres ---

    private fun animateMouthTo(scaleY: Float, scaleX: Float, durationMs: Long, end: (() -> Unit)? = null) {
        val mouth = mouthView ?: return
        mouthAnimator?.cancel()
        val startY = mouth.scaleY
        val startX = mouth.scaleX
        val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                mouth.scaleY = startY + (scaleY - startY) * t
                mouth.scaleX = startX + (scaleX - startX) * t
                // Légère variation d'opacité selon l'ouverture
                mouth.alpha = 0.55f + 0.45f * mouth.scaleY.coerceIn(0f, 1f)
            }
            doOnEndCompat { end?.invoke() }
        }
        mouthAnimator = anim
        anim.start()
    }

    /** Compat : ancien appel à 1 paramètre (scaleY seul). */
    private fun animateMouthTo(scaleY: Float, durationMs: Long, end: (() -> Unit)? = null) {
        val x = when {
            scaleY >= MOUTH_OPEN_Y * 0.9f -> MOUTH_OPEN_X
            scaleY >= MOUTH_MID_Y -> MOUTH_MID_X
            else -> MOUTH_CLOSED_X
        }
        animateMouthTo(scaleY, x, durationMs, end)
    }

    private fun ValueAnimator.doOnEndCompat(block: () -> Unit) {
        addListener(object : android.animation.Animator.AnimatorListener {
            override fun onAnimationStart(a: android.animation.Animator) {}
            override fun onAnimationCancel(a: android.animation.Animator) {}
            override fun onAnimationRepeat(a: android.animation.Animator) {}
            override fun onAnimationEnd(a: android.animation.Animator) { block() }
        })
    }

    /**
     * Visèmes simplifiés pour le français.
     * Retourne (scaleY, scaleX, holdMs).
     *  - A / À  → grande ouverture
     *  - É / È  → large (sourire)
     *  - O / OU → arrondie
     *  - I / U  → étroite
     *  - B / P / M → fermée
     */
    private fun visemeFor(chunk: String?): Triple<Float, Float, Long> {
        if (chunk.isNullOrBlank()) {
            // Variation aléatoire légère pour rester vivant
            return listOf(
                Triple(MOUTH_MID_Y, MOUTH_MID_X, 70L),
                Triple(MOUTH_OPEN_Y * 0.9f, MOUTH_OPEN_X, 80L),
                Triple(MOUTH_WIDE_Y, MOUTH_WIDE_X, 75L)
            ).random()
        }
        val lower = chunk.lowercase()
        // Priorité aux sons les plus caractéristiques
        when {
            lower.any { it in "bpm" } ->
                return Triple(MOUTH_CLOSED_Y + 0.05f, MOUTH_CLOSED_X, 55L)
            lower.any { it in "oôöùûu" } || lower.contains("ou") || lower.contains("on") ->
                return Triple(MOUTH_ROUND_Y, MOUTH_ROUND_X, 85L)
            lower.any { it in "éèêëe" } || lower.contains("ai") || lower.contains("ei") ->
                return Triple(MOUTH_WIDE_Y, MOUTH_WIDE_X, 75L)
            lower.any { it in "aàâä" } ->
                return Triple(MOUTH_OPEN_Y, MOUTH_OPEN_X, 90L)
            lower.any { it in "iîïy" } ->
                return Triple(MOUTH_MID_Y * 0.7f, MOUTH_CLOSED_X + 0.15f, 65L)
            lower.any { it in "aeiouyàâäéèêëïîôöùûü" } ->
                return Triple(MOUTH_MID_Y + 0.15f, MOUTH_MID_X, 70L)
            else ->
                return Triple(MOUTH_MID_Y * 0.6f, MOUTH_MID_X * 0.85f, 60L)
        }
    }

    private fun showInternal(c: Context, mascotDrawableId: Int, question: String, answer: String, autoHideMs: Long) {
        if (!canDraw(c)) return
        try {
            val appCtx = c.applicationContext
            val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            remove(appCtx)

            // Cadre portrait pour corps entier visible (ratio assets 512×640)
            val sizeW = dp(appCtx, 140)
            val sizeH = dp(appCtx, 180)
            val imgFrame = FrameLayout(appCtx).apply {
                layoutParams = LinearLayout.LayoutParams(sizeW, sizeH)
            }

            val img = ImageView(appCtx).apply {
                if (mascotDrawableId != 0) setImageResource(mascotDrawableId)
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = FrameLayout.LayoutParams(sizeW, sizeH)
            }

            // Bouche centree horizontalement, ancree sur la zone bouche du visage
            // (assets 512x640 : visage haut-centre, bouche ~52 % de la hauteur cadre)
            val mouth = View(appCtx).apply {
                val w = dp(appCtx, 32)
                val h = dp(appCtx, 12)
                layoutParams = FrameLayout.LayoutParams(w, h).apply {
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    topMargin = (sizeH * 0.52f).toInt()
                    // leger recentrage si le dessin a un biais
                    leftMargin = 0
                    rightMargin = 0
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xFF1A1A1A.toInt())
                    setStroke(dp(appCtx, 1), UiKit.BLACK)
                }
                // Pivot au centre de la bouche pour un scale symmetrique
                pivotX = w / 2f
                pivotY = h / 2f
                scaleX = MOUTH_CLOSED_X
                scaleY = MOUTH_CLOSED_Y
                visibility = View.INVISIBLE
                elevation = 12f
            }
            mouthView = mouth
            imgFrame.addView(img)
            imgFrame.addView(mouth)

            val nameTv = TextView(appCtx).apply {
                text = MascotManager.getDisplayName(appCtx)
                setTextColor(UiKit.BLACK)
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(4, 8, 4, 2)
            }

            val qv = TextView(appCtx).apply {
                text = question
                setTextColor(UiKit.TEXT_MUTED)
                textSize = 11f
                setPadding(4, 4, 4, 2)
                gravity = Gravity.CENTER
                visibility = if (question.isBlank()) View.GONE else View.VISIBLE
                setTextIsSelectable(true)
                setOnLongClickListener {
                    if (question.isNotBlank()) copyAnswerToClipboard(appCtx, question)
                    true
                }
            }

            // Zone de texte réponse : scrollable + sélectionnable + copiable (long-press ou bouton)
            val av = TextView(appCtx).apply {
                text = answer
                setTextColor(UiKit.BLACK)
                textSize = 13f
                setPadding(dp(appCtx, 6), dp(appCtx, 4), dp(appCtx, 6), dp(appCtx, 6))
                gravity = Gravity.START or Gravity.TOP
                setTextIsSelectable(true)
                movementMethod = ScrollingMovementMethod.getInstance()
                // Hauteur max en mode compact pour forcer le scroll si long
                maxHeight = dp(appCtx, 120)
                // Appui long → copie tout le texte dans le presse-papiers (fiable même en overlay)
                setOnLongClickListener {
                    copyAnswerToClipboard(appCtx, answer)
                    true
                }
            }
            answerView = av

            val answerScroll = ScrollView(appCtx).apply {
                isFillViewport = false
                isVerticalScrollBarEnabled = true
                overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    height = dp(appCtx, 130)
                }
                addView(av)
                setOnLongClickListener {
                    copyAnswerToClipboard(appCtx, answer)
                    true
                }
            }

            // Bouton « Copier » toujours visible sous le texte
            val copyBtn = TextView(appCtx).apply {
                text = "📋  Copier"
                setTextColor(0xFF1565C0.toInt())
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(dp(appCtx, 8), dp(appCtx, 6), dp(appCtx, 8), dp(appCtx, 4))
                setOnClickListener { copyAnswerToClipboard(appCtx, answer) }
            }

            var expanded = false
            val card = LinearLayout(appCtx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(appCtx, 20), dp(appCtx, 16), dp(appCtx, 20), dp(appCtx, 16))
                background = UiKit.card(appCtx)
                elevation = 14f
                addView(imgFrame)
                addView(nameTv)
                addView(qv)
                addView(answerScroll)
                addView(copyBtn)
            }

            val type = if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

            // NOT_FOCUSABLE + NOT_TOUCH_MODAL : ne vole jamais le focus clavier / IME
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            params.y = dp(appCtx, 72)

            // Double-tap sur la zone texte (ou la carte) → agrandir à la taille de l'écran
            val gestureDetector = GestureDetector(appCtx, object : GestureDetector.SimpleOnGestureListener() {
                override fun onDoubleTap(e: MotionEvent): Boolean {
                    expanded = !expanded
                    val metrics = appCtx.resources.displayMetrics
                    if (expanded) {
                        // Plein écran quasi-total
                        params.width = metrics.widthPixels - dp(appCtx, 16)
                        params.height = metrics.heightPixels - dp(appCtx, 48)
                        params.gravity = Gravity.CENTER
                        params.y = 0
                        answerScroll.layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            0, 1f
                        )
                        av.maxHeight = Int.MAX_VALUE
                        av.textSize = 15f
                        card.setPadding(dp(appCtx, 16), dp(appCtx, 20), dp(appCtx, 16), dp(appCtx, 20))
                    } else {
                        // Retour mode compact
                        params.width = WindowManager.LayoutParams.WRAP_CONTENT
                        params.height = WindowManager.LayoutParams.WRAP_CONTENT
                        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                        params.y = dp(appCtx, 72)
                        answerScroll.layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(appCtx, 130)
                        )
                        av.maxHeight = dp(appCtx, 120)
                        av.textSize = 13f
                        card.setPadding(dp(appCtx, 20), dp(appCtx, 16), dp(appCtx, 20), dp(appCtx, 16))
                    }
                    try {
                        wm.updateViewLayout(card, params)
                    } catch (_: Exception) {}
                    // Empêche l'auto-hide pendant la lecture étendue
                    hideRunnable?.let { handler.removeCallbacks(it) }
                    if (!expanded) {
                        hideRunnable = Runnable { remove(appCtx) }
                        hideRunnable?.let { handler.postDelayed(it, 12_000L) }
                    }
                    return true
                }

                override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                    // Simple tap ferme seulement si pas en mode étendu (pour laisser copier/scroll)
                    if (!expanded) remove(appCtx)
                    return true
                }
            })

            card.setOnTouchListener { _, ev ->
                gestureDetector.onTouchEvent(ev)
                true
            }
            // Aussi sur la zone de texte pour que le double-tap marche bien
            answerScroll.setOnTouchListener { v, ev ->
                gestureDetector.onTouchEvent(ev)
                // Laisse le ScrollView gérer le scroll
                v.onTouchEvent(ev)
                true
            }

            wm.addView(card, params)
            currentView = card

            hideRunnable?.let { handler.removeCallbacks(it) }
            hideRunnable = Runnable { remove(appCtx) }
            hideRunnable?.let { handler.postDelayed(it, autoHideMs) }
        } catch (_: Exception) {}
    }

    fun remove(c: Context) {
        try {
            isTalking = false
            mouthRunnable?.let { handler.removeCallbacks(it) }
            mouthRunnable = null
            mouthAnimator?.cancel()
            mouthAnimator = null
            hideRunnable?.let { handler.removeCallbacks(it) }
            hideRunnable = null
            val wm = c.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            currentView?.let { wm.removeView(it) }
        } catch (_: Exception) {}
        currentView = null
        mouthView = null
        answerView = null
    }

    /** Copie le texte de la réponse dans le presse-papiers et affiche un toast. */
    private fun copyAnswerToClipboard(c: Context, text: String) {
        if (text.isBlank()) return
        try {
            val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Vanelle", text))
            Toast.makeText(c, "Texte copié ✓", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            try {
                Toast.makeText(c, "Impossible de copier", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {}
        }
    }
}
