package com.vanelle.os
import android.Manifest
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import java.util.Locale
import kotlinx.coroutines.launch
class MainActivity:AppCompatActivity(){
    private lateinit var vp:ViewPager2
    private lateinit var tl:TabLayout
    private var tts:TextToSpeech?=null
    private val mouthHandler=Handler(Looper.getMainLooper())
    private var mouthRunnable:Runnable?=null
    @Volatile private var processingCommand=false
    private val activeCommands = java.util.concurrent.atomic.AtomicInteger(0)
    private val maxParallelCommands = 4
    private val profilePhotoLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val ok = RelationalMemory(this).saveProfilePhotoFromUri(uri)
            if (ok) {
                refreshProfileHeader()
                Toast.makeText(this, "Photo de profil enregistrée", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Impossible d'enregistrer la photo : ${FailureReason.from(e)}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private var permissionsStarted = false
    private var permissionIndex = 0
    private var permissionGateReady = false
    private var permissionBlocked = false

    private val runtimePermissions: List<String>
        get() = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            add(Manifest.permission.READ_CONTACTS)
            add(Manifest.permission.CALL_PHONE)
            add(Manifest.permission.SEND_SMS)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.READ_MEDIA_IMAGES)
            else add(Manifest.permission.READ_EXTERNAL_STORAGE)
            add(Manifest.permission.CAMERA)
        }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()){ granted ->
        val permission = runtimePermissions.getOrNull(permissionIndex) ?: return@registerForActivityResult
        if (granted) {
            permissionBlocked = false
            permissionIndex++
            requestNextRuntimePermission()
        } else {
            // Une permission refusée bloque volontairement la suite.
            permissionBlocked = true
            showPermissionBlockedDialog(permission)
        }
    }
    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        if(!LocalAuth.isLoggedIn(this)){
            startActivity(Intent(this,AuthActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            finish()
            return
        }
        // Onboarding désactivé
        setContentView(R.layout.activity_main)
        vp=findViewById(R.id.viewPager)
        tl=findViewById(R.id.tabLayout)
        vp.adapter=Adapter(this)
        TabLayoutMediator(tl,vp){ tab,pos->
            tab.text=when(pos){
                0->"Mascotte"
                1->"Conversation"
                2->"Configuration"
                3->"Fonctions"
                4->"Relances"
                else->"Notes"
            }
        }.attach()
        val openTab = intent.getIntExtra("open_tab", -1)
        if (openTab in 0 until 6) {
            try { vp.setCurrentItem(openTab, false) } catch (_: Exception) {}
        }
        setupProfileHeader()
        requestNeededPermissions()
        tts=TextToSpeech(this){ status-> if(status==TextToSpeech.SUCCESS){ tts?.language=Locale.FRANCE; VoicePrefs.apply(this, tts) } }
        handleIncomingIntent(intent)
        // Téléchargement automatique de l'IA dès que nécessaire.
        // Le modèle n'est jamais embarqué dans l'APK : il est conservé dans le stockage
        // de l'application. Une mise à jour de l'APK par-dessus l'installation existante
        // réutilise donc le modèle déjà téléchargé et évite de recommencer le téléchargement.
        if (!DataDownloadService.isUsable(this)) {
            DataDownloadService.start(this)
            DataDownloadScreen.maybeShow(this)
        }
        // La mascotte n'attend plus que le modèle soit prêt pour apparaître.
        // Elle peut ainsi parler/indiquer « attends le téléchargement et le chargement »
        // au lieu de disparaître pendant la préparation de l'IA.
        try {
            if (OverlayHelper.canDraw(this)) {
                FloatingMascotButton.setEnabled(this, true)
                FloatingMascotButton.show(this)
            }
        } catch (_: Exception) {}
        warmUpLocalAiWhenReady()
        // Propose les réglages date/heure système (Android interdit de forcer l'horloge sans privilège système)
        maybeOpenDateTimeIfNeeded()
        maybePromptSystemBackup()
    }

    private fun setupProfileHeader() {
        findViewById<View>(R.id.profilePlusBtn)?.setOnClickListener { showProfilePanel() }
    }

    private fun refreshProfileHeader() {
        // Plus de bandeau permanent : le profil s'ouvre via le bouton +
    }

    /** Panneau profil accessible via le « + » en haut : nom, e-mail, photo. */
    private fun showProfilePanel() {
        val mem = RelationalMemory(this)
        val user = LocalAuth.currentUser(this)
        val density = resources.displayMetrics.density

        val col = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding((24 * density).toInt(), (16 * density).toInt(), (24 * density).toInt(), (8 * density).toInt())
        }

        // Photo de profil (cliquable)
        val avatar = ImageView(this).apply {
            layoutParams = android.widget.LinearLayout.LayoutParams((72 * density).toInt(), (72 * density).toInt()).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = (12 * density).toInt()
            }
            scaleType = ImageView.ScaleType.CENTER_CROP
            if (mem.hasProfilePhoto()) {
                try {
                    val bmp = BitmapFactory.decodeFile(mem.profilePhotoFile().absolutePath)
                    if (bmp != null) setImageBitmap(bmp)
                    else setImageResource(android.R.drawable.ic_menu_myplaces)
                } catch (_: Exception) {
                    setImageResource(android.R.drawable.ic_menu_myplaces)
                }
            } else {
                setImageResource(android.R.drawable.ic_menu_myplaces)
            }
            setOnClickListener { profilePhotoLauncher.launch("image/*") }
        }
        col.addView(avatar)

        val photoHint = TextView(this).apply {
            text = "Toucher la photo pour la changer"
            setTextColor(UiKit.TEXT_MUTED)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, (16 * density).toInt())
        }
        col.addView(photoHint)

        // Prénom
        val nameLabel = TextView(this).apply {
            text = "Prénom"
            setTextColor(UiKit.TEXT_MUTED)
            textSize = 12f
        }
        col.addView(nameLabel)
        val nameInput = EditText(this).apply {
            setText(mem.displayName())
            hint = "Ton prénom"
            setPadding((12 * density).toInt(), (10 * density).toInt(), (12 * density).toInt(), (10 * density).toInt())
            setSingleLine(true)
        }
        col.addView(nameInput)

        // E-mail (lecture seule, issu du compte local)
        val emailLabel = TextView(this).apply {
            text = "E-mail"
            setTextColor(UiKit.TEXT_MUTED)
            textSize = 12f
            setPadding(0, (14 * density).toInt(), 0, 0)
        }
        col.addView(emailLabel)
        val emailValue = TextView(this).apply {
            text = user?.email ?: "—"
            setTextColor(UiKit.BLACK)
            textSize = 15f
            setPadding(0, (4 * density).toInt(), 0, (8 * density).toInt())
        }
        col.addView(emailValue)

        AlertDialog.Builder(this)
            .setTitle("Mon profil")
            .setView(col)
            .setPositiveButton("Enregistrer") { _, _ ->
                val v = nameInput.text?.toString()?.trim().orEmpty()
                if (v.isNotBlank()) {
                    mem.setProfileField("prenom", v)
                    Toast.makeText(this, "Bonjour $v", Toast.LENGTH_SHORT).show()
                }
            }
            .setNeutralButton("Photo") { _, _ -> profilePhotoLauncher.launch("image/*") }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun warmUpLocalAiWhenReady(){
        lifecycleScope.launch {
            repeat(720) { // jusqu'à ~1 h en arrière-plan, sans bloquer l'interface
                if (LlamaModelManager.isReady(this@MainActivity)) {
                    LocalLlamaHelper.get(this@MainActivity).warmUp()
                    return@launch
                }
                kotlinx.coroutines.delay(5000)
            }
        }
    }

    override fun onNewIntent(i:Intent){
        super.onNewIntent(i)
        setIntent(i)
        handleIncomingIntent(i)
    }
    private fun handleIncomingIntent(i:Intent){
        val confirmType=i.getStringExtra("confirm_type")
        if(!confirmType.isNullOrBlank()){
            val name=i.getStringExtra("confirm_name") ?: ""
            val message=i.getStringExtra("confirm_message") ?: ""
            val msg=if(confirmType=="call") "Confirmer l'appel vers $name ?" else "Confirmer l'envoi du message a $name :\n\"$message\""
            AlertDialog.Builder(this).setTitle("Confirmation requise").setMessage(msg)
                .setPositiveButton("Confirmer"){_,_->
                    val contacts=ContactsRepository(this)
                    val res=if(confirmType=="call") contacts.call(name) else contacts.sendMessage(name,message)
                    WorkflowLearner(this).log("[confirme] $confirmType $name")
                    android.widget.Toast.makeText(this,res,android.widget.Toast.LENGTH_LONG).show()
                }
                .setNegativeButton("Annuler"){_,_-> android.widget.Toast.makeText(this,"Annule",android.widget.Toast.LENGTH_SHORT).show() }
                .setCancelable(false).show()
            i.removeExtra("confirm_type")
            return
        }
        val pendingCommand = i.getStringExtra("pending_command")
        if(!pendingCommand.isNullOrBlank()){
            i.removeExtra("pending_command")
            val pendingResult = i.getStringExtra("pending_result")
            i.removeExtra("pending_result")
            // Plusieurs commandes en parallèle (max 4)
            if(activeCommands.get() >= maxParallelCommands){
                android.widget.Toast.makeText(this,"J'ai déjà plusieurs tâches en cours, réessaie dans un instant",android.widget.Toast.LENGTH_SHORT).show()
                return
            }
            activeCommands.incrementAndGet()
            processingCommand=true
            // Ne pas rester au premier plan si on peut parler en overlay
            if (OverlayHelper.canDraw(this)) {
                try { moveTaskToBack(true) } catch (_: Exception) {}
            }
            lifecycleScope.launch{
                try {
                var res = if (!pendingResult.isNullOrBlank()) pendingResult
                    else CommandInterpreter(this@MainActivity).execute(pendingCommand)
                if (res.isBlank()) {
                    res = "Je n'ai pas pu répondre. Reformule ta demande ou vérifie ta connexion et les permissions dans Configuration."
                }
                if(OverlayHelper.canDraw(this@MainActivity)){
                    val sel=MascotManager.getSelected(this@MainActivity)
                    val mid=try{ MascotManager.getDrawableId(this@MainActivity,sel) }catch(_:Exception){0}
                    OverlayHelper.show(this@MainActivity,mid,pendingCommand,res)
                    // Synchro labiale : onStart + onRangeStart (syllabes) + onDone
                    val spoken = res
                    tts?.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
                        override fun onStart(id:String?){ OverlayHelper.startTalking() }
                        override fun onDone(id:String?){ OverlayHelper.stopTalking() }
                        override fun onError(id:String?){ OverlayHelper.stopTalking() }
                        override fun onRangeStart(utteranceId:String?, start:Int, end:Int, frame:Int){
                            // Segment de texte en cours de prononciation → pulse de bouche
                            val chunk = try {
                                if(start>=0 && end>start && end<=spoken.length) spoken.substring(start, end) else null
                            } catch(_:Exception){ null }
                            OverlayHelper.pulseMouth(chunk)
                        }
                    })
                    if(res.isNotBlank()){
                        try{
                            val params = android.os.Bundle()
                            // Demande les callbacks de plage pour une meilleure synchro (API 26+)
                            run {
                                val spokenText = RelationalMemory(this@MainActivity).withSpokenName(res)
                                VoicePrefs.applyForText(this@MainActivity, tts, spokenText)
                                tts?.speak(spokenText, TextToSpeech.QUEUE_ADD, params, "vanelle_utt")
                            }
                        }catch(_:Exception){
                            try{ run {
                                    val spokenText = RelationalMemory(this@MainActivity).withSpokenName(res)
                                    tts?.speak(spokenText,TextToSpeech.QUEUE_ADD,null,"vanelle_utt")
                                } }catch(_:Exception){}
                        }
                    }
                    moveTaskToBack(true)
                }else{
                    showMascotDialog(pendingCommand,res)
                }
                } finally {
                    if(activeCommands.decrementAndGet() <= 0){
                        activeCommands.set(0)
                        processingCommand=false
                    }
                }
            }
        }
    }
    private fun showMascotDialog(voiceText:String,voiceResult:String){
            val sel = MascotManager.getSelected(this)
            val mascotId = try { MascotManager.getDrawableId(this, sel) } catch (_:Exception){ 0 }
            val imageView = ImageView(this).apply {
                if (mascotId != 0) setImageResource(mascotId)
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = FrameLayout.LayoutParams(420,420)
            }
            val mouth = View(this).apply{
                // Bouche en bas du visage, pivot haut → ouverture vers le bas seulement
                layoutParams = FrameLayout.LayoutParams(52,16).apply{
                    gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    topMargin = (420 * 0.58f).toInt()
                }
                background = GradientDrawable().apply{
                    shape = GradientDrawable.OVAL
                    setColor(UiKit.BLACK)
                    setStroke(2, UiKit.BLACK)
                }
                pivotX = 26f
                pivotY = 0f
                scaleX = 0.60f
                scaleY = 0.18f
                visibility = View.INVISIBLE
            }
            val frame = FrameLayout(this).apply{
                layoutParams = android.widget.LinearLayout.LayoutParams(420,420).apply{ setMargins(0,20,0,20) }
                addView(imageView); addView(mouth)
            }
            // Animation UNIQUEMENT sur les lèvres (ouverture limitée, jamais jusqu'aux yeux)
            fun startMouth(){
                mouth.visibility = View.VISIBLE
                mouth.scaleX = 0.60f
                mouth.scaleY = 0.18f
                mouth.animate().cancel()
                mouth.animate().scaleX(0.88f).scaleY(0.40f).setDuration(110L).start()
            }
            fun pulseMouth(){
                mouth.visibility = View.VISIBLE
                mouth.animate().cancel()
                mouth.animate().scaleX(0.98f).scaleY(0.50f).setDuration(55L).withEndAction {
                    mouth.animate().scaleX(0.65f).scaleY(0.22f).setDuration(85L).start()
                }.start()
            }
            fun stopMouth(){
                mouthRunnable?.let{ mouthHandler.removeCallbacks(it) }
                mouth.animate().cancel()
                mouth.animate().scaleX(0.60f).scaleY(0.18f).setDuration(120L).withEndAction {
                    mouth.visibility = View.INVISIBLE
                }.start()
            }
            val qView = TextView(this).apply { text = "Tu: $voiceText"; setTextColor(UiKit.TEXT_MUTED); textSize = 12f; setPadding(24,0,24,12) }
            val aView = TextView(this).apply { text = voiceResult; setTextColor(UiKit.BLACK); textSize = 14f; setPadding(24,0,24,24) }
            val container = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                setPadding(24,24,24,24)
                background=UiKit.card(this@MainActivity)
                addView(frame); addView(qView); addView(aView)
            }
            val spokenDialog = voiceResult
            tts?.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
                override fun onStart(id:String?){ runOnUiThread{ startMouth() } }
                override fun onDone(id:String?){ runOnUiThread{ stopMouth() } }
                override fun onError(id:String?){ runOnUiThread{ stopMouth() } }
                override fun onRangeStart(utteranceId:String?, start:Int, end:Int, frame:Int){
                    runOnUiThread{ pulseMouth() }
                }
            })
            AlertDialog.Builder(this).setView(container)
                .setNeutralButton("Plus de précision") { _, _ ->
                    val input = android.widget.EditText(this).apply {
                        hint = "Précise ta demande…"
                        setSingleLine(false)
                        minLines = 2
                        maxLines = 4
                        setPadding(24, 16, 24, 16)
                    }
                    AlertDialog.Builder(this)
                        .setTitle("Préciser la demande")
                        .setMessage("Vanelle peut continuer la conversation sans rouvrir une application.")
                        .setView(input)
                        .setNegativeButton("Annuler", null)
                        .setPositiveButton("Envoyer") { _, _ ->
                            val followUp = input.text?.toString()?.trim().orEmpty()
                            if (followUp.isNotBlank()) {
                                lifecycleScope.launch {
                                    val followUpResult = CommandInterpreter(this@MainActivity).execute(followUp)
                                    showMascotDialog(followUp, followUpResult)
                                }
                            }
                        }
                        .show()
                }
                .setPositiveButton("Fermer",null)
                .setOnDismissListener{ stopMouth(); try{ tts?.stop() }catch(_:Exception){} }
                .show()
            if(voiceResult.isNotBlank()){
                try{
                    val spokenText = RelationalMemory(this).withSpokenName(voiceResult)
                    VoicePrefs.applyForText(this, tts, spokenText)
                    tts?.speak(spokenText,TextToSpeech.QUEUE_FLUSH,null,"vanelle_utt")
                }catch(_:Exception){}
            }
    }
    
    override fun onResume(){
        super.onResume()
        try { applyVoice() } catch (_: Exception) {}
        try { refreshProfileHeader() } catch (_: Exception) {}
        if (permissionGateReady) {
            requestSpecialPermissionsChain()
        } else if (permissionsStarted) {
            requestNextRuntimePermission()
        }
        try {
            if (OverlayHelper.canDraw(this) && permissionGateReady) {
                if (!FloatingMascotButton.isEnabled(this)) FloatingMascotButton.setEnabled(this, true)
                else FloatingMascotButton.show(this)
            }
        } catch (_: Exception) {}
        // Reprendre téléchargement / chargement IA sans action manuelle
        try {
            if (!DataDownloadService.isUsable(this) && !DataDownloadService.isRunning) {
                DataDownloadService.start(this)
            } else if (LlamaModelManager.isReady(this)) {
                warmUpLocalAiWhenReady()
            }
        } catch (_: Exception) {}
    }
    private fun applyVoice(){ try { VoicePrefs.apply(this, tts) } catch (_: Exception) {} }
    override fun onDestroy(){ tts?.stop(); tts?.shutdown(); mouthRunnable?.let{ mouthHandler.removeCallbacks(it) }; super.onDestroy() }
    /**
     * Propose l'ouverture des réglages système date/heure si l'heure automatique
     * est désactivée (Android interdit à une app de forcer l'horloge sans privilège
     * système). Affiché une seule fois pour ne pas être intrusif.
     */
    private fun maybeOpenDateTimeIfNeeded(){
        try {
            val autoTime = Settings.Global.getInt(contentResolver, Settings.Global.AUTO_TIME, 1)
            if (autoTime == 0 && !DateTimePrefs.wasPrompted(this)) {
                DateTimePrefs.setPrompted(this)
                AlertDialog.Builder(this).setTitle("Date et heure")
                    .setMessage("La date et l'heure automatiques semblent désactivées. Une horloge incorrecte peut empêcher certaines fonctions (téléchargements, traduction) de fonctionner.")
                    .setPositiveButton("Régler"){_,_-> startActivity(Intent(Settings.ACTION_DATE_SETTINGS)) }
                    .setNegativeButton("Plus tard",null).show()
            }
        } catch (_: Exception) {}
    }

    /** Demande d'activer la sauvegarde système (Google) pour retrouver les données après réinstall ou nouvel appareil. */
    private fun maybePromptSystemBackup(){
        if (UserDataSnapshot.wasBackupPrompted(this)) return
        UserDataSnapshot.setBackupPrompted(this)
        try { UserDataSnapshot.save(this) } catch (_: Exception) {}
        AlertDialog.Builder(this)
            .setTitle("Sauvegarde de tes données")
            .setMessage(
                "Pour retrouver mémoire, relances et préférences si tu désinstalles l'app ou changes de téléphone, " +
                "active la sauvegarde Google / Android.\n\n" +
                "Tu pourras aussi exporter un fichier dans Configuration → Exporter mes données, " +
                "puis l'importer sur un autre téléphone."
            )
            .setPositiveButton("Activer la sauvegarde"){ _, _ ->
                UserDataSnapshot.openSystemBackupSettings(this)
            }
            .setNegativeButton("Plus tard", null)
            .show()
    }

    private fun requestNeededPermissions(){
        if (permissionsStarted) return
        permissionsStarted = true
        permissionIndex = 0
        requestNextRuntimePermission()
    }

    /**
     * Demande UNE permission à la fois. Si l'utilisateur refuse, Vanelle ne poursuit
     * jamais l'initialisation tant que cette permission n'est pas accordée.
     */
    private fun requestNextRuntimePermission(){
        val permissions = runtimePermissions
        while (permissionIndex < permissions.size &&
            ContextCompat.checkSelfPermission(this, permissions[permissionIndex]) == PackageManager.PERMISSION_GRANTED) {
            permissionIndex++
        }
        if (permissionIndex >= permissions.size) {
            permissionGateReady = true
            requestSpecialPermissionsChain()
            return
        }
        val permission = permissions[permissionIndex]
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            permissionIndex++
            requestNextRuntimePermission()
            return
        }
        permissionLauncher.launch(permission)
    }

    private fun permissionReason(permission: String): Pair<String, String> = when (permission) {
        Manifest.permission.RECORD_AUDIO -> "Microphone" to "Vanelle en a besoin pour t'entendre quand tu lui parles et utiliser les fonctions vocales."
        Manifest.permission.READ_CONTACTS -> "Contacts" to "Vanelle en a besoin uniquement pour les fonctions qui utilisent tes contacts et pour exécuter les actions que tu lui demandes."
        Manifest.permission.CALL_PHONE -> "Téléphone" to "Cette autorisation permet à Vanelle de lancer un appel lorsque tu lui demandes explicitement de le faire."
        Manifest.permission.SEND_SMS -> "SMS" to "Cette autorisation permet à Vanelle d'envoyer un SMS uniquement lorsque tu lui demandes explicitement une action SMS."
        Manifest.permission.POST_NOTIFICATIONS -> "Notifications" to "Les notifications servent à te prévenir des téléchargements de l'IA, relances et tâches importantes."
        Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_EXTERNAL_STORAGE -> "Photos et fichiers" to "Cette autorisation permet de choisir une image ou un fichier depuis ton appareil pour les fonctions d'importation."
        Manifest.permission.CAMERA -> "Caméra" to "Vanelle en a besoin pour les fonctions qui utilisent la caméra et l'analyse visuelle."
        else -> "Autorisation nécessaire" to "Cette autorisation est nécessaire au fonctionnement des fonctions correspondantes de Vanelle."
    }

    private fun showPermissionBlockedDialog(permission: String){
        val (title, reason) = permissionReason(permission)
        val permanentlyDenied = !shouldShowRequestPermissionRationale(permission)
        AlertDialog.Builder(this)
            .setTitle("$title requis")
            .setMessage(
                "$reason\n\n" +
                    if (permanentlyDenied) "L'autorisation a été refusée. Ouvre les réglages de VanelleOS et autorise-la pour continuer."
                    else "Pour continuer la configuration de VanelleOS, cette autorisation doit être acceptée."
            )
            .setPositiveButton(if (permanentlyDenied) "Ouvrir les réglages" else "Autoriser") { _, _ ->
                permissionBlocked = false
                if (permanentlyDenied) {
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.parse("package:$packageName")
                        })
                    } catch (_: Exception) {}
                } else {
                    permissionLauncher.launch(permission)
                }
            }
            .setCancelable(false)
            .show()
    }

    /** Permissions / réglages spéciaux : un seul écran à la fois, jamais de poursuite en cas de refus. */
    private fun requestSpecialPermissionsChain(){
        if (!permissionGateReady) return
        // Accès « Ne pas déranger » dès le démarrage (requis pour mode silencieux / vibreur)
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                val nm = getSystemService(android.app.NotificationManager::class.java)
                val prefs = getSharedPreferences("vanelle_perms", 0)
                val asked = prefs.getBoolean("dnd_asked", false)
                if (nm != null && !nm.isNotificationPolicyAccessGranted && !asked) {
                    requestDndAccessIfNeeded()
                    return
                }
            } catch (_: Exception) {}
        }
        if (!isEnabled()) {
            AlertDialog.Builder(this)
                .setTitle("Accessibilité requise")
                .setMessage("Vanelle a besoin de l'accessibilité pour lire l'écran, cliquer, remplir des champs et exécuter les actions que tu lui demandes. Active-la pour continuer.")
                .setPositiveButton("Activer"){_,_-> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .setCancelable(false)
                .show()
            return
        }
        if (!OverlayHelper.canDraw(this)) {
            requestOverlayIfNeeded()
            return
        }
        if (Build.VERSION.SDK_INT >= 31 && !AlarmScheduler.canScheduleExact(this)) {
            requestExactAlarmIfNeeded()
            return
        }
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                val pm = getSystemService(android.os.PowerManager::class.java)
                if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
                    requestBatteryOptIfNeeded()
                    return
                }
            } catch (_: Exception) {}
        }
        // Tout est accepté : seulement maintenant la suite de l'application est considérée prête.
    }

    /** Accès politique de notification (Do Not Disturb) — requis pour mode silencieux / vibreur. */
    private fun requestDndAccessIfNeeded(){
        if (Build.VERSION.SDK_INT < 24) return
        try {
            val nm = getSystemService(android.app.NotificationManager::class.java)
            if (nm != null && nm.isNotificationPolicyAccessGranted) return
        } catch (_: Exception) {}
        AlertDialog.Builder(this)
            .setTitle("Mode son (Ne pas déranger)")
            .setMessage(
                "Pour que Vanelle puisse passer ton téléphone en silencieux, vibreur ou son normal quand tu le demandes, " +
                "autorise l'accès « Ne pas déranger » (politique de notification).\n\n" +
                "Dans l'écran suivant, active Vanelle dans la liste."
            )
            .setPositiveButton("Autoriser"){ _, _ ->
                getSharedPreferences("vanelle_perms", 0).edit().putBoolean("dnd_asked", true).apply()
                try {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                } catch (_: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = android.net.Uri.parse("package:$packageName")
                        })
                    } catch (_: Exception) {}
                }
            }
            .setNegativeButton("Plus tard"){ _, _ ->
                getSharedPreferences("vanelle_perms", 0).edit().putBoolean("dnd_asked", true).apply()
                // Continuer la chaîne même si refusé (activable plus tard dans Configuration)
                requestSpecialPermissionsChainContinue()
            }
            .setCancelable(false)
            .show()
    }

    /** Suite de la chaîne après DND (ou si DND déjà accordé / reporté). */
    private fun requestSpecialPermissionsChainContinue(){
        if (!isEnabled()) {
            AlertDialog.Builder(this)
                .setTitle("Accessibilité requise")
                .setMessage("Vanelle a besoin de l'accessibilité pour lire l'écran, cliquer, remplir des champs et exécuter les actions que tu lui demandes. Active-la pour continuer.")
                .setPositiveButton("Activer"){_,_-> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .setCancelable(false)
                .show()
            return
        }
        if (!OverlayHelper.canDraw(this)) {
            requestOverlayIfNeeded()
            return
        }
        if (Build.VERSION.SDK_INT >= 31 && !AlarmScheduler.canScheduleExact(this)) {
            requestExactAlarmIfNeeded()
            return
        }
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                val pm = getSystemService(android.os.PowerManager::class.java)
                if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
                    requestBatteryOptIfNeeded()
                    return
                }
            } catch (_: Exception) {}
        }
    }

    /** Permission spéciale (Settings) pour afficher la mascotte partout. */
    private fun requestOverlayIfNeeded(){
        if(OverlayHelper.canDraw(this)){
            try {
                if (DataDownloadService.isUsable(this)) {
                    if (!FloatingMascotButton.isEnabled(this)) {
                        FloatingMascotButton.setEnabled(this, true)
                    } else {
                        FloatingMascotButton.show(this)
                    }
                } else {
                    FloatingMascotButton.hide(this)
                }
            } catch (_: Exception) {}
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Mascotte sur toutes les apps")
            .setMessage(
                "Pour que la mascotte apparaisse peu importe l'application ouverte (WhatsApp, navigateur, écran d'accueil…), " +
                "autorise « Afficher par-dessus les autres applications » pour VanelleOS.\n\n" +
                "Sans cette autorisation, la mascotte ne peut pas s'afficher hors de l'app."
            )
            .setPositiveButton("Autoriser"){ _, _ ->
                OverlayHelper.requestPermission(this)
            }
            .setCancelable(false)
            .show()
    }

    /** Alarmes exactes (Android 12+) : sans ça, les relances peuvent ne jamais sonner. */
    private fun requestExactAlarmIfNeeded(){
        if (Build.VERSION.SDK_INT < 31) return
        if (AlarmScheduler.canScheduleExact(this)) return
        AlertDialog.Builder(this)
            .setTitle("Relances / alarmes exactes")
            .setMessage(
                "Pour que tes relances sonnent à l'heure exacte, autorise VanelleOS à « programmer des alarmes et des rappels exacts ».\n\n" +
                "Sans cette autorisation, Android peut retarder ou ignorer les relances."
            )
            .setPositiveButton("Autoriser"){ _, _ ->
                try {
                    val i = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                        data = Uri.parse("package:$packageName")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(i)
                } catch (_: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.parse("package:$packageName")
                        })
                    } catch (_: Exception) {}
                }
            }
            .setCancelable(false)
            .show()
    }

    /** Ignore l'optimisation batterie pour que les relances partent même en veille. */
    private fun requestBatteryOptIfNeeded(){
        if (Build.VERSION.SDK_INT < 23) return
        try {
            val pm = getSystemService(android.os.PowerManager::class.java) ?: return
            if (pm.isIgnoringBatteryOptimizations(packageName)) return
            AlertDialog.Builder(this)
                .setTitle("Relances en arrière-plan")
                .setMessage(
                    "Pour que les relances fonctionnent même quand le téléphone est en veille, " +
                    "autorise VanelleOS à ne pas être optimisée par la batterie.\n\n" +
                    "Sinon le système peut bloquer les alarmes."
                )
                .setPositiveButton("Autoriser"){ _, _ ->
                    try {
                        val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                            data = Uri.parse("package:$packageName")
                        }
                        startActivity(i)
                    } catch (_: Exception) {
                        try {
                            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                        } catch (_: Exception) {}
                    }
                }
                .setCancelable(false)
                .show()
        } catch (_: Exception) {}
    }
    private fun isEnabled():Boolean{
        val exp="$packageName/${VanelleAccessibilityService::class.java.canonicalName}"
        val en=Settings.Secure.getString(contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val split=TextUtils.SimpleStringSplitter(':')
        split.setString(en)
        while(split.hasNext()){ if(split.next().equals(exp,true)) return true }
        return false
    }
}
class Adapter(a:AppCompatActivity): androidx.viewpager2.adapter.FragmentStateAdapter(a){
    override fun getItemCount()=6
    override fun createFragment(p:Int)= when(p){
        0->MascotFragment()
        1->ChatFragment()
        2->ConfigFragment()
        3->FeaturesFragment()
        4->RelanceFragment()
        else->NotesFragment()
    }
}
