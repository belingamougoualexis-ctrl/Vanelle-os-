package com.vanelle.os

/**
 * Orchestration du raisonnement pour un petit modèle local.
 *
 * Principe : le 1B ne "raisonne" pas bien en une passe libre.
 * On force une structure (décomposition, faits vs déductions, auto-check)
 * et on réserve le CoT aux questions qui en ont besoin.
 *
 * Ce n'est pas un second cerveau — c'est un pipeline autour de Llama.
 */
object ReasoningHelper {

    private val COMPLEX = Regex(
        """(?i)(pourquoi|comment\s+(?:ça|fonctionne|marche|expliquer)|explique|compar(?:e|er)|différence|analyse|prouve|déduis|calcule|étape|raisonne|avantages?\s+et\s+inconvénients?|pour\s+ou\s+contre|que\s+se\s+passe|implique|conséquence)"""
    )
    private val MATH = Regex(
        """(?i)(?:combien|calcule|calcul|somme|produit|différence|divis|multipli|\d+\s*[\+\-\*/×÷]\s*\d+|pourcentage|%|\d+\s*(?:plus|moins|fois))"""
    )
    private val FACTUAL = Regex(
        """(?i)(?:c['']est\s+quoi|qu['']est[- ]ce\s+que|qui\s+est|quelle?s?\s+est|quel\s+est|défini|date|capitale|population|superficie|mesure|plus\s+(?:grand|grande|petit|petite|haut|haute|long|longue|peuplé|peuplée|riche)|record|combien\s+de|où\s+(?:est|se\s+trouve)|pays|continent|océan|montagne|ville)"""
    )

    fun isComplex(t: String): Boolean =
        t.length > 60 || COMPLEX.containsMatchIn(t) || (MATH.containsMatchIn(t) && t.length > 20)

    fun isMathLike(t: String): Boolean = MATH.containsMatchIn(t)

    /** Questions de culture générale / faits : le 1B doit s'appuyer sur le web, pas inventer. */
    fun isFactualLookup(t: String): Boolean {
        if (t.length >= 160) return false
        if (FACTUAL.containsMatchIn(t)) return true
        // Formulations libres type « le plus grand pays du monde »
        val low = t.lowercase()
        val cues = listOf(
            "plus grand", "plus grande", "plus petit", "plus haute", "plus haut",
            "capitale", "population", "superficie", "combien d", "c'est quoi", "c est quoi",
            "qui a inventé", "en quelle année", "quel pays", "quelle ville",
            "what is", "who is", "where is", "how many", "how much", "when did",
            "que es", "quien es", "donde", "cuanto",
            "histoire", "history", "definition", "définition", "inventeur", "président", "president"
        )
        return cues.any { low.contains(it) }
    }

    /**
     * Réécrit une question en requête de recherche plus exploitable
     * (ex. « quel est le plus grand pays » → « plus grand pays du monde superficie »).
     */
    fun searchQueryFor(t: String): String {
        var q = t.trim()
        q = q.replace(Regex("""(?i)^(dis[- ]moi|vanelle|s'il te plaît|svp)[, ]*"""), "")
        q = q.replace(Regex("""(?i)\?$"""), "").trim()
        val low = q.lowercase()
        // Désambiguïser superficie vs population
        if (Regex("""(?i)plus\s+grand(?:e)?\s+pays""").containsMatchIn(low) &&
            !low.contains("population") && !low.contains("habitant")
        ) {
            return "plus grand pays du monde par superficie"
        }
        if (Regex("""(?i)plus\s+peuplé""").containsMatchIn(low) ||
            (low.contains("plus grand pays") && low.contains("population"))
        ) {
            return "pays le plus peuplé du monde"
        }
        if (Regex("""(?i)capitale\s+(?:de|d')""").containsMatchIn(low)) {
            return q
        }
        return q.take(100)
    }

    /**
     * Raisonnement forcé mais **réponse finale seule à afficher**.
     * Format strict pour pouvoir élague le CoT visible (latence perçue).
     */
    fun buildStructuredPrompt(userMessage: String, hasExternalFacts: Boolean): String {
        val base = userMessage.trim()
        return buildString {
            append(base)
            append("\n\nRaisonne brièvement en interne, puis réponds UNIQUEMENT dans ce format :\n")
            append("BROUILLON: (2-4 puces max : faits")
            if (hasExternalFacts) append(" issus du contexte")
            append(" vs déductions ; si fragile, note-le)\n")
            append("RÉPONSE: (2-6 phrases claires, complètes, pour l'utilisateur — c'est la seule partie utile)\n")
            append("Règles : n'invente rien ; si tu ne sais pas, dis-le dans RÉPONSE ; pas de présentation.")
        }
    }

    /**
     * Extrait la partie parlée / affichée : priorise « RÉPONSE: », sinon texte nettoyé.
     * Coupe le chain-of-thought visible pour la latence et le confort vocal.
     */
    fun extractSpokenAnswer(raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return t
        // Bloc RÉPONSE: … (fin ou jusqu'à une autre section)
        Regex("""(?is)RÉPONSE\s*:\s*(.+)$""").find(t)?.groupValues?.getOrNull(1)?.let { body ->
            val clean = body.trim()
                .removePrefix("assistant").trim()
            if (clean.length >= 8) return clean
        }
        Regex("""(?is)(?:conclusion|réponse finale)\s*:\s*(.+)$""").find(t)?.groupValues?.getOrNull(1)?.let { body ->
            val clean = body.trim()
            if (clean.length >= 8) return clean
        }
        // Retire un préambule BROUILLON: … s'il est en tête
        var out = t
        if (out.contains("BROUILLON:", ignoreCase = true)) {
            out = out.substringAfter("RÉPONSE:", missingDelimiterValue = out)
                .substringAfter("Réponse:", missingDelimiterValue = out)
                .trim()
        }
        // Retire listes numérotées de méthode si le modèle a ignoré le format
        val lines = out.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val withoutSteps = lines.filterNot { line ->
            Regex("""^(?:BROUILLON|FAITS|DÉDUCTIONS)\s*:""").containsMatchIn(line) ||
                Regex("""^\d+\)\s*(?:Reformule|Liste|Sépare|Raisonne|Conclusion|Auto-check)""").containsMatchIn(line)
        }
        return withoutSteps.joinToString(" ").ifBlank { out }.trim()
    }


    /** Prompt court : humain, intention, langue du user, zero invention. */
    fun buildSimplePrompt(userMessage: String): String {
        val m = userMessage.trim()
        return m + "\n\nReponds comme un humain attentif : phrases completes et correctes, " +
            "dans la langue de la question. Comprends l'intention. " +
            "N'invente aucun fait. Si tu ne sais pas, dis-le simplement. Pas de presentation."
    }

    /** Reformulation apres faits web. */
    fun buildRagPrompt(question: String): String =
        "Question : ${question.trim()}\n\n" +
            "Utilise UNIQUEMENT les faits fournis dans le contexte. " +
            "Reponds dans la langue de la question, comme un humain clair et naturel. " +
            "Phrases completes. Ne change pas les chiffres ni les noms. " +
            "Si le contexte ne suffit pas, dis-le. Pas de presentation."

    fun tryDeterministicMath(t: String): String? {
        val s = t.lowercase()
            .replace('×', '*')
            .replace('÷', '/')
            .replace("plus", "+")
            .replace("moins", "-")
            .replace("fois", "*")
            .replace(',', '.')
        val m = Regex("""(\d+(?:\.\d+)?)\s*([\+\-\*/])\s*(\d+(?:\.\d+)?)""").find(s) ?: return null
        val a = m.groupValues[1].toDoubleOrNull() ?: return null
        val op = m.groupValues[2]
        val b = m.groupValues[3].toDoubleOrNull() ?: return null
        val r = when (op) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            "/" -> if (b == 0.0) return "Division par zero : impossible." else a / b
            else -> return null
        }
        val pretty = if (r == r.toLong().toDouble()) r.toLong().toString()
        else String.format("%.4f", r).trimEnd('0').trimEnd('.')
        return "Resultat : $pretty (calcul exact, pas une estimation)."
    }

    fun looksOverconfidentBluff(text: String): Boolean {
        val t = text.lowercase()
        if (t.length < 40) return false
        val bluff = listOf(
            "il est evident que", "tout le monde sait", "sans aucun doute",
            "c'est certain que", "absolument certain", "je peux garantir"
        )
        val hedge = listOf("peut-etre", "probablement", "il semble", "je ne suis pas", "hypothese", "si je comprends")
        val bluffHits = bluff.count { t.contains(it) }
        val hedgeHits = hedge.count { t.contains(it) }
        return bluffHits >= 1 && hedgeHits == 0 && !t.contains("je ne sais")
    }
}
