package com.vanelle.os

/**
 * Faits ultra-courants vérifiés — filet si le web est lent / indisponible.
 * Évite les hallucinations du 1B sur les questions de base.
 */
object QuickFacts {
    fun answer(q: String): String? {
        val t = q.lowercase()
            .replace("é", "e").replace("è", "e").replace("ê", "e")
            .replace("à", "a").replace("ù", "u").replace("ô", "o")

        // Plus grand pays (superficie)
        if ((t.contains("plus grand pays") || t.contains("plus grand etat") ||
                t.contains("plus grand pays du monde")) &&
            !t.contains("population") && !t.contains("peuple") && !t.contains("habitant")
        ) {
            return "La Russie est le plus grand pays du monde par superficie, avec environ 17,1 millions de km²."
        }
        // Plus peuplé
        if (t.contains("plus peuple") || (t.contains("plus grand pays") && (t.contains("population") || t.contains("habitant")))) {
            return "L'Inde est le pays le plus peuplé du monde (devant la Chine), avec plus d'1,4 milliard d'habitants."
        }
        // Capitales fréquentes
        if (t.contains("capitale") && t.contains("france")) return "La capitale de la France est Paris."
        if (t.contains("capitale") && (t.contains("usa") || t.contains("etats-unis") || t.contains("etats unis")))
            return "La capitale des États-Unis est Washington, D.C."
        if (t.contains("capitale") && t.contains("japon")) return "La capitale du Japon est Tokyo."

        return null
    }
}
