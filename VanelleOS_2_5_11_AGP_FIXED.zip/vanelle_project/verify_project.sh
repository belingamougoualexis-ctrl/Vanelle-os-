#!/usr/bin/env bash
set -euo pipefail

echo '[1/5] ZIP/source sanity'
test -f settings.gradle.kts
test -f build.gradle.kts
test -f app/build.gradle.kts
test -f app/src/main/AndroidManifest.xml

echo '[2/5] Manifest component references'
python3 - <<'PY'
import re, pathlib
root=pathlib.Path('app/src/main')
manifest=(root/'AndroidManifest.xml').read_text()
classes={name for p in (root/'java').rglob('*.kt') for name in re.findall(r'\b(?:class|object|interface)\s+(\w+)', p.read_text())}
for name in re.findall(r'android:name="(?:\.)?([A-Za-z0-9_]+)"', manifest):
    if name and name not in classes and name not in {'provider'}:
        raise SystemExit(f'Manifest component not found in Kotlin sources: {name}')
print('OK')
PY

echo '[3/5] No unsafe Kotlin non-null assertions'
if grep -Rni '!!' app/src/main/java --include='*.kt'; then
  echo 'Unsafe !! found'; exit 1
fi

echo '[4/5] No simulation markers in production source'
if grep -RniE 'fake|dummy|mock|simulated|simulator|placeholder|simulation' app/src/main/java --include='*.kt' | grep -vE '^.*(commentaire|comments|pas de simulation|sans simulation|simulation marker).*$'; then
  echo 'Potential simulation marker found'; exit 1
fi

echo '[5/5] Model integrity constants'
grep -Eq 'EXPECTED_MIN_BYTES = 1_929_903_264L|EXPECTED_MIN_BYTES = 1929903264L' app/src/main/java/com/vanelle/os/LlamaModelManager.kt
grep -q '9c9f56a391a3abbd5b89d0245bf6106081bcc3173119d4229235dd9d23253f94' app/src/main/java/com/vanelle/os/LlamaModelManager.kt
echo 'SOURCE AUDIT OK'
