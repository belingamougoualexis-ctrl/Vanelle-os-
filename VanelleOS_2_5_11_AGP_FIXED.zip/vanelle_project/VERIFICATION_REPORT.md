# VanelleOS 2.4.1 — Vérification finale

## Vérifications effectuées
- Archive extraite sans erreur.
- Structure Android présente (`settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts`).
- 80 fichiers Kotlin présents.
- Aucune variante `legacyUiTest`/`legacyUi` trouvée dans le code ou la configuration.
- Aucun APK/AAB embarqué dans le projet.
- Modèle GGUF externe à l'APK.
- Dépendance `io.github.ljcamargo:llamacpp-kotlin:0.4.0` présente.
- Configuration R8/ProGuard prévue pour les classes chargées par réflexion.
- Vérification de l'intégrité SHA-256 du modèle présente.
- Téléchargement reprenable et conservation du modèle après mise à jour de l'application.
- Correction appliquée au cas HTTP 416 lorsque le fichier partiel est déjà exactement complet.
- Recherche de marqueurs de simulation/legacy effectuée.

## Limite de validation de cet environnement
Le projet fourni ne contient pas `gradlew`/`gradle-wrapper.jar`, et cet environnement ne dispose pas d'une installation Gradle + Android SDK permettant d'exécuter honnêtement `assembleDebug`, `assembleRelease`, `lint` et les tests instrumentés.

La validation Android officielle doit donc être exécutée dans Android Studio/Gradle avec le SDK du projet. Android recommande l'exécution de lint via Gradle dans le projet Android.
