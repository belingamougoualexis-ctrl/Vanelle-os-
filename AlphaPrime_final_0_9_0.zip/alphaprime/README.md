Alpha Prime 0.9.0

# Alpha Prime — local-first release

Alpha Prime est une plateforme locale d'entraînement, d'expérimentation, d'évaluation et de gestion d'IA. Le cœur s'exécute sur la machine de l'utilisateur : SQLite, datasets versionnés, modèles, checkpoints, artefacts, logs, configurations et historiques restent dans le workspace local.

## Principes de vérité

L'application ne fabrique aucun résultat. Les états utilisés dans les réponses et l'interface sont :

- `REAL` : mesuré, exécuté ou écrit réellement sur la machine.
- `ESTIMATED` : prévision calculée avant une opération.
- `PROPOSED` : proposition qui attend une exécution/validation réelle.
- `SIMULATED (TEST)` : uniquement pour un scénario de test explicitement isolé.
- `UNAVAILABLE` : dépendance, matériel ou infrastructure réellement absente.
- `FAILED` : opération réellement tentée puis échouée.

Une estimation ne devient `REAL` qu'après mesure. Une proposition ne devient validée qu'après exécution. Aucun GPU, téléchargement, entraînement, métrique ou déploiement n'est simulé.

## Architecture locale

Le projet sépare les responsabilités suivantes : Frontend, Backend local, AI Orchestrator, AI Mission Engine, Local AI Council, Universal Data Engine, Dataset Registry, Model Engine, Model Registry, Local Model Manager, Compute Engine, Smart Compute Planner, Training Engine, Experiment Engine, Evaluation Engine, Auto Lab, Error Mining, Synthetic Data Lab, Red Team Engine, AI Scientist, Champion/Challenger, Model Genome, Continuous Training, Safety Gate, Deployment Engine, Cost Guardian, Disaster Recovery, Observability, Security, Artifact Storage et configuration SQLite/JSON.

Les providers sont conçus derrière des interfaces afin d'ajouter plus tard un GPU distant ou du cloud sans modifier le cœur local. Ces extensions ne sont pas requises pour le produit actuel.


## Sélection explicite : données, modèle et LLM

Le nouvel écran **Training** ne demande plus seulement un chemin de fichier : il fait choisir une **version de dataset déjà enregistrée** dans le projet, puis calcule la compatibilité des moteurs de modèle sur la machine. Vous pouvez choisir `Auto` ou un moteur précis réellement supporté, relier une **mission existante**, et tenter de continuer un **model version/checkpoint local** lorsqu'un checkpoint compatible existe réellement.

Le menu **LLM & Model Manager** est séparé du modèle entraîné : le LLM sert au pilotage du Council, tandis que le modèle entraîné appartient au Model Registry et au Training Engine.

Le système ne permet pas de sélectionner silencieusement une capacité inexistante : une combinaison non compatible apparaît `UNAVAILABLE`, avec une cause et une action corrective.

La chaîne LLM comprend désormais un moteur LoRA/QLoRA générique sur les modèles Transformers locaux compatibles; le modèle de base est sélectionnable depuis le registre local vérifié. Le moteur générique de fine-tuning LoRA/QLoRA est disponible; les architectures non compatibles sont refusées avec cause et solution.

## Entraînement distribué — 100% local

`LOCAL_DISTRIBUTED_PROVIDER` répartit réellement l'entraînement (utile pour de gros volumes de données) sur :

1. **D'autres cœurs CPU de cette machine** — activé automatiquement seulement si ≥2 cœurs réels sont détectés (même règle d'honnêteté que pour le multi-GPU : jamais simulé).
2. **D'autres machines de votre propre réseau local (LAN)** — vous lancez vous-même le service worker sur chacune :
   ```bash
   python3 -m ai_training_os.providers.local_distributed_worker --port 9500
   ```
   puis vous les référencez dans la configuration d'entraînement : `config["nodes"] = ["192.168.1.12:9500", ...]`. Chaque nœud est réellement vérifié (ping TCP) avant utilisation ; un nœud injoignable est rapporté comme tel, jamais fabriqué comme disponible.

Aucun accès Internet, aucun compte cloud, aucune clé API externe n'est utilisé. La capacité de calcul ne monte que si vous ajoutez de vraies machines à votre réseau — c'est ce qui permet à ce provider de tenir la charge même pour de très gros volumes de données, tout en restant strictement local.

## Interface 2026

Le dashboard utilise une identité business claire et premium : surfaces blanches, fond gris très léger, navy institutionnel, accents or, bleu opérationnel, logo aigle Alpha Prime, navigation par domaines, dashboard de supervision, cartes de ressources réelles, actions rapides, mode Simple/Expert et fonctionnement sans dépendance CDN externe. Le thème sombre reste disponible comme option, mais la présentation par défaut est claire. La couche visuelle reste connectée aux mêmes endpoints locaux : elle n’introduit aucune métrique, progression ou état fictif.

## Démarrage

Depuis le dossier du projet :

```bash
python3 run_server.py --workspace ./workspace --port 8787
```

Puis ouvrir :

```text
http://127.0.0.1:8787/
```

Le serveur HTTP écoute sur `127.0.0.1` par défaut. Il n'est pas destiné à être exposé directement sur Internet.

## Où sont les données ?

Dans le dossier passé à `--workspace` :

```text
workspace/
├── aitos.db
├── config.json
├── storage/                 # originaux et versions de datasets
│   ├── originals/
│   └── versions/
├── models/                  # paquets/modèles gérés par le Model Manager
├── llm_models/              # modèles LLM locaux importés ou sélectionnés
├── checkpoints/             # checkpoints de jobs d'entraînement
├── artifacts/               # artefacts produits par les opérations réelles
└── synthetic/               # datasets explicitement synthétiques
```

Aucun workspace de démonstration n'est inclus dans la distribution de production. Le dossier `fixtures/` contient uniquement des données de test clairement séparées.

## LLM local réel

Le `LocalLLMProvider` n'utilise pas de réponse de secours.

Il peut détecter et vérifier réellement :

1. un modèle Ollama déjà installé en local ;
2. un fichier `.gguf` avec `llama-cpp-python` ;
3. un dossier de modèle Transformers local contenant sa configuration et ses poids.

Dans l'interface, vous pouvez détecter, vérifier et sélectionner un modèle local. La sélection est persistée dans `workspace/llm_models/.selected_model.json`.

Sans LLM compatible, le Council reste dans l'état :

```text
LLM REQUIRED — Aucun modèle de langage local compatible n’est actuellement disponible.
```

Il n'y a alors aucune fausse conversation.

## Compute local

Le Compute Engine mesure réellement CPU, RAM, GPU/VRAM lorsqu'ils sont exposés par CUDA/MPS/nvidia-smi, accélérateurs, disque, espace temporaire et connectivité sortante.

`LOCAL_GPU_PROVIDER` et `LOCAL_MULTI_GPU_PROVIDER` ne s'activent que lorsque le matériel et les dépendances correspondants sont réellement disponibles. Sans GPU compatible, l'état est `UNAVAILABLE` et le système peut utiliser le CPU réel.

## Training / Evaluation / Recovery

Le parcours local actuellement intégré de bout en bout couvre notamment les modèles tabulaires CPU scikit-learn :

```text
Mission → Dataset versionné → Model Plan → Experiment → Training réel
→ Checkpoints → Evaluation réelle → Error Mining → Red Team réel
→ Safety Gate → Artifact → Model Genome
```

Le provider `sgd_incremental` possède une reprise réelle à partir du dernier checkpoint valide. Une interruption n'est pas transformée en succès : elle reste `PAUSED` côté job/experiment jusqu'à une reprise effectivement relancée.

Le Safety Gate bloque le déploiement si aucune revue `APPROVED` n'est présente. L'export d'un modèle et son déploiement sont deux opérations distinctes.

## Model Manager

Le gestionnaire local prend en charge l'import, le packaging en shards, manifest/checksum, validation, réparation contrôlée d'un shard corrompu, reprise de téléchargement HTTP avec `Range`, suivi réel et nettoyage.

Un téléchargement n'est jamais annoncé terminé avant la fin réelle et la vérification de checksum.

## Universal Data Engine

Les adaptateurs disponibles dépendent des bibliothèques installées. Le système annonce ses capacités réelles pour CSV, JSON, JSONL, TXT, Parquet, XLSX, PDF, images, audio et vidéo. Les pipelines préservent toujours l'original et enregistrent les transformations/versionnements.

Pour les très gros datasets, une limitation actuelle demeure : le parcours tabulaire intégré charge encore les lignes nécessaires en mémoire. Le Model Manager, lui, sait déjà travailler avec des fichiers shardés.

## Auto Lab / Synthetic / Red Team / Scientist

Auto Lab exécute une boucle réelle à partir d'un callback d'expérience réel et s'arrête sur objectif, temps, stockage, nombre d'expériences ou amélioration négligeable.

Synthetic Data Lab marque explicitement les lignes synthétiques et conserve leur origine, méthode et configuration.

Red Team exécute réellement ses attaques locales compatibles. AI Scientist analyse l'historique réellement présent dans SQLite ; ses hypothèses restent `PROPOSED` jusqu'à validation expérimentale.

Champion/Challenger compare des résultats factuels et ne remplace pas automatiquement le Champion.

## Sécurité

Le système vérifie les chemins, les hashes, les archives d'import/restauration, la présence des dépendances et la gestion des secrets par variables d'environnement. L'exécution arbitraire de code utilisateur reste `UNAVAILABLE` tant qu'un sandbox OS dédié n'est pas installé : le programme ne lance pas aveuglément du code non fiable.

## Sauvegarde / restauration

Dans l'interface `Recovery`, ou en Python :

```python
from ai_training_os import AITrainingOS

app = AITrainingOS("./workspace")
backup = app.disaster_recovery.backup("./backup.zip")
print(backup)
print(app.disaster_recovery.verify("./backup.zip"))
print(app.disaster_recovery.restore("./backup.zip", "./workspace_restored"))
```

Le restore refuse un workspace cible non vide et vérifie les hashes avant d'installer les fichiers.

Pour un projet uniquement :

```python
export = app.exporter.export(project_id, "./project_export.zip")
imported = app.exporter.import_project("./project_export.zip", "./new_workspace")
```

## Tests

Exécuter :

```bash
python3 run_tests.py
```

ou, avec pytest :

```bash
python3 -m pytest -q
```

Le test E2E réel peut être lancé sans polluer le dépôt :

```bash
python3 run_e2e.py
```

Le script E2E utilise un workspace temporaire et n'écrit aucun résultat de démonstration dans le projet source.

Une vérification JavaScript statique du dashboard peut être faite avec Node :

```bash
node --check /tmp/aitos_frontend.js
```

## Limites vérifiées de cette livraison

- Dans l'environnement de construction utilisé pour cette livraison, aucun GPU CUDA/MPS n'est présent et `torch` est CPU-only : les fonctions GPU sont donc `UNAVAILABLE` ici et ne sont pas simulées.
- Aucun backend LLM local compatible n'est installé dans cet environnement de construction (`Ollama`, `llama-cpp-python` et `transformers` non disponibles) : le Council génératif est donc `LLM REQUIRED` ici.
- Le parcours d'entraînement complet réellement intégré est centré sur les modèles tabulaires locaux compatibles scikit-learn ; les formats image/audio/vidéo/PDF disposent d'adaptateurs de données, mais leurs pipelines d'entraînement spécialisés ne sont pas prétendus universellement disponibles.
- L'exécution de code utilisateur non sandboxée est volontairement `UNAVAILABLE`.
- Cloud, remote GPU, multi-tenant et distributed computing restent des interfaces d'extension et ne sont pas nécessaires au fonctionnement local.

## Installation locale automatique (premier démarrage)

Au premier démarrage, l'interface affiche `Installation locale`. Après consentement, elle télécharge réellement dans le workspace :

- le runtime llama.cpp adapté au système détecté depuis les releases officielles `ggml-org/llama.cpp` ;
- `SmolLM2-360M-Instruct-Q4_K_M.gguf` pour le Council local ;
- `nomic-embed-text-v1.5.Q4_K_M.gguf` pour les embeddings locaux.

Chaque ressource est téléchargée en fichier `.part`, peut reprendre après interruption et est acceptée uniquement après vérification SHA-256. Les ressources déjà validées ne sont pas re-téléchargées. Une erreur reste `FAILED` et l'installation peut être reprise depuis l'interface.

Les modèles sont stockés dans `workspace/llm_models/` et le runtime dans `workspace/bootstrap/runtime/`. Les URLs et checksums déclarés sont versionnés dans `ai_training_os/startup_manager.py`.

## Résolution automatique GPU et serveurs

AlphaPrime inclut maintenant un `EnvironmentManager` qui distingue :

- GPU physiquement détecté ;
- pilote réellement utilisable ;
- runtime CUDA/ROCm/MPS ;
- PyTorch et son backend réel ;
- environnement d'entraînement effectivement prêt.

L'application ne considère plus `nvidia-smi` seul comme un backend PyTorch. Elle effectue une vérification réelle du framework et peut lancer un test de calcul GPU avant de déclarer `READY`.

Les routes locales ajoutées sont :

- `GET /api/environment/status` — scan + plan de résolution ;
- `GET /api/environment/verify` — test de calcul réel ;
- `POST /api/servers/register` — enregistre un serveur de calcul ;
- `GET /api/servers` — liste les serveurs ;
- `GET /api/server/inspect?server_id=...` — inspection SSH réelle et plan de préparation.

Pour les serveurs, AlphaPrime peut inspecter une machine distante via SSH et déterminer automatiquement son GPU NVIDIA, pilote visible, Python et PyTorch/CUDA. Si un GPU est visible mais que PyTorch CUDA n'est pas opérationnel, le serveur est marqué `NOT READY` et l'action requise est explicitement calculée au lieu de simuler une disponibilité.

Un agent léger `server_agent.py` est aussi fourni pour les infrastructures où l'administrateur préfère exposer un agent local plutôt que donner un accès SSH à AlphaPrime. Il expose `/health` et `/environment` et ne lance aucune installation silencieuse de pilote système.

Les pilotes GPU système restent soumis aux privilèges du système d'exploitation : AlphaPrime peut les détecter et guider/automatiser l'étape lorsque l'environnement l'autorise, mais ne prétend jamais les avoir installés si ce n'est pas vérifié.


## Premier lancement 0.9.0

Le serveur local démarre immédiatement puis prépare en arrière-plan le stack Python LLM/fine-tuning et les modèles locaux. Les téléchargements sont repris et vérifiés par SHA-256. Tant que la préparation n'est pas réellement terminée, l'interface affiche UNAVAILABLE/PENDING plutôt qu'un faux READY.
