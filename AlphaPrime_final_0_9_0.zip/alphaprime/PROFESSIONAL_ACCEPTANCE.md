# Alpha Prime 0.9.0 — Professional Acceptance

Cette version regroupe le socle local-first et les contrôles nécessaires à un vrai cycle AI engineering : Mission → Data → Model → Training → Evaluation → Safety → Delivery.

## Ajouts

- Dataset Studio avec versions immuables, nettoyage avec lineage et contrôles de fuite.
- LLM Health par rôle et configuration persistante.
- Auto-configuration/sélection locale du LLM lorsqu’un modèle réellement détecté est disponible.
- Dependency Manager pour transformers, peft, datasets, accelerate et safetensors.
- Hardware Manager avec détection CPU/RAM/GPU/CUDA et plan de préparation.
- Validation Gate en lecture + exécution explicite.
- Delivery Manager avec artefact enregistré, hash et téléchargement depuis le dashboard.
- Full System Test et règles truth-first.

## Règle d’acceptation

Aucune métrique, réponse LLM, disponibilité GPU, livraison ou réussite d’entraînement n’est fabriquée. Une capacité indisponible est affichée comme telle avec sa cause et sa solution.
