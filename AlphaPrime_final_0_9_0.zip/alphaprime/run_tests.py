"""
run_tests.py — Exécute réellement tous les tests de tests/*.py.

pytest n'est pas installé et aucun accès réseau sortant n'existe pour
l'installer (vérifié réellement, voir ai_training_os/compute.py). Ce
runner exécute donc le MÊME code de test via un harnais minimal
compatible (tests/_mini_pytest_compat contient l'API pytest.fixture /
pytest.raises utilisée). Aucun test n'est skippé ou inventé : chaque
test_*() est réellement exécuté et son résultat réel est rapporté.
"""
import sys
import os
import glob
import importlib
import importlib.util
import inspect
import tempfile
import pathlib
import shutil
import traceback
import subprocess
import json
import re

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, "_mini_pytest"))
sys.path.insert(0, ROOT)

import pytest  # noqa: E402  (résout vers _mini_pytest/pytest.py)


class _MonkeyPatch:
    """Minimal real stand-in for pytest's monkeypatch fixture: records every
    change so it can be undone after the test, exactly like the real one."""
    def __init__(self):
        self._undo = []

    def setattr(self, target, name, value=None, raising=True):
        if value is None and isinstance(name, str) and "." in name:
            # not used here, kept for API compatibility
            pass
        if not hasattr(target, name) and raising:
            raise AttributeError(name)
        had = hasattr(target, name)
        old = getattr(target, name, None)
        self._undo.append((target, name, had, old))
        setattr(target, name, value)

    def undo(self):
        for target, name, had, old in reversed(self._undo):
            if had:
                setattr(target, name, old)
            else:
                delattr(target, name)
        self._undo.clear()


def resolve_fixture(name, cache, tmp_root):
    if name == "tmp_path":
        if "tmp_path" not in cache:
            d = tempfile.mkdtemp(dir=tmp_root)
            cache["tmp_path"] = pathlib.Path(d)
        return cache["tmp_path"]
    if name == "monkeypatch":
        if "monkeypatch" not in cache:
            cache["monkeypatch"] = _MonkeyPatch()
        return cache["monkeypatch"]
    if name in cache:
        return cache[name]
    fn = pytest.get_fixture(name)
    if fn is None:
        raise RuntimeError(f"Fixture inconnue: {name}")
    params = inspect.signature(fn).parameters
    args = [resolve_fixture(p, cache, tmp_root) for p in params]
    value = fn(*args)
    cache[name] = value
    return value


def run_file(path, tmp_root):
    pytest._FIXTURES.clear()
    mod_name = os.path.splitext(os.path.basename(path))[0]
    spec = importlib.util.spec_from_file_location(mod_name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[mod_name] = mod
    spec.loader.exec_module(mod)

    results = []
    test_funcs = [
        (name, obj) for name, obj in vars(mod).items()
        if name.startswith("test_") and callable(obj)
    ]
    for name, func in test_funcs:
        cache = {}
        params = inspect.signature(func).parameters
        try:
            args = [resolve_fixture(p, cache, tmp_root) for p in params]
            func(*args)
            results.append((name, "PASS", None))
        except getattr(pytest, "Skipped", Exception) as e:
            results.append((name, "SKIP", str(e) or "Test explicitement ignoré."))
        except Exception as e:
            results.append((name, "FAIL", f"{type(e).__name__}: {e}\n{traceback.format_exc(limit=3)}"))
        finally:
            mp = cache.get("monkeypatch")
            if mp is not None:
                mp.undo()
    return results


def _child(path):
    tmp_root = tempfile.mkdtemp(prefix="aitos_one_test_")
    try:
        results = run_file(os.path.abspath(path), tmp_root)
        print("AITOS_RESULTS=" + json.dumps(results, ensure_ascii=False, default=str), flush=True)
        return 1 if any(status == "FAIL" for _, status, _ in results) else 0
    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--child", help="Exécute un seul fichier dans un processus isolé")
    parser.add_argument("--timeout", type=int, default=120)
    args = parser.parse_args()
    if args.child:
        return _child(args.child)

    test_files = sorted(glob.glob(os.path.join(ROOT, "tests", "test_*.py")))
    total_pass, total_fail = 0, 0
    all_failures = []
    for tf in test_files:
        print(f"\n=== {os.path.relpath(tf, ROOT)} ===", flush=True)
        try:
            cp = subprocess.run(
                [sys.executable, __file__, "--child", tf, "--timeout", str(args.timeout)],
                cwd=ROOT, text=True, capture_output=True, timeout=args.timeout,
                env=dict(os.environ),
            )
            child_output = cp.stdout + ("\n" + cp.stderr if cp.stderr else "")
            marker = re.search(r"AITOS_RESULTS=(.+)", child_output)
            if not marker:
                print("  [FAIL] child runner did not return structured results", flush=True)
                if child_output.strip(): print(child_output[-2500:], flush=True)
                total_fail += 1
                all_failures.append((tf, "<child-runner>", child_output[-4000:]))
                continue
            results = json.loads(marker.group(1))
            for name, status, err in results:
                suffix = f" — {err}" if status == "SKIP" and err else ""
                print(f"  [{status}] {name}{suffix}", flush=True)
                if status == "PASS": total_pass += 1
                elif status == "SKIP": pass
                else:
                    total_fail += 1
                    all_failures.append((tf, name, err))
            if cp.returncode not in (0, 1) and not results:
                total_fail += 1
                all_failures.append((tf, "<child-process>", child_output[-4000:]))
        except subprocess.TimeoutExpired as exc:
            print(f"  [FAIL] fichier dépassant le délai de {args.timeout}s", flush=True)
            total_fail += 1
            all_failures.append((tf, "<timeout>", f"Timeout après {args.timeout}s"))

    print(f"\n{'='*60}\nTOTAL: {total_pass} PASS, {total_fail} FAIL\n{'='*60}")
    if all_failures:
        print("\nDétail des échecs:")
        for tf, name, err in all_failures:
            print(f"\n--- {tf}::{name} ---\n{err}")
    return 1 if total_fail else 0


if __name__ == "__main__":
    sys.exit(main())
