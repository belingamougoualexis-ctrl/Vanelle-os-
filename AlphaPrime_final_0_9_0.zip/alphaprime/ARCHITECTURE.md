# Alpha Prime — architecture & structure (0.9.0)

## 1. Principe produit

Alpha Prime est un **AI Training OS local-first** : les données, les expériences, les checkpoints, les artefacts et l'exécution restent dans le workspace local par défaut. Le système expose en permanence un état de vérité (`REAL`, `ESTIMATED`, `PROPOSED`, `UNAVAILABLE`, `FAILED`, `SIMULATED (TEST)`) afin de ne pas présenter une capacité absente comme opérationnelle.

Le dashboard sépare explicitement deux objets souvent confondus :

- **LLM de pilotage** : modèle local utilisé par le Council / AI Scientist pour raisonner et produire des plans.
- **Modèle entraîné** : modèle réellement sélectionné pour l'expérience de training et enregistré dans le Model Registry.

## 2. Architecture en couches

```text
┌──────────────────────────────────────────────────────────────┐
│ UI / Command Center                                         │
│ Dashboard · Training · LLM & Model Manager · Safety views  │
└──────────────────────────────┬───────────────────────────────┘
                               │ HTTP localhost
┌──────────────────────────────▼───────────────────────────────┐
│ Local API                                                    │
│ Routing · validation · erreurs actionnables · assets        │
└──────────────────────────────┬───────────────────────────────┘
                               │
┌──────────────────────────────▼───────────────────────────────┐
│ AI Orchestrator                                              │
│ Mission → Data → Model Strategy → Training → Evaluation    │
│ → Error Mining → Red Team → Safety Gate → Artifact         │
└─────────────┬──────────────────────┬─────────────────────────┘
              │                      │
      ┌───────▼────────┐     ┌───────▼────────────┐
      │ Data plane     │     │ ML / Training plane │
      │ Data Engine    │     │ Model Engine        │
      │ Dataset Reg.   │     │ Training Engine     │
      │ Feature Engine │     │ Experiment Registry │
      └───────┬────────┘     │ Evaluation Engine   │
              │              └────────┬────────────┘
              └──────────────┬────────┘
                             │
                   ┌─────────▼─────────┐
                   │ Control / Safety  │
                   │ Council · Mission │
                   │ Red Team · Gate   │
                   │ Scientist · Cost  │
                   └─────────┬─────────┘
                             │
                   ┌─────────▼─────────┐
                   │ Local persistence │
                   │ SQLite · storage  │
                   │ models · ckpts    │
                   │ artifacts · logs  │
                   └───────────────────┘
```

## 3. Choix des données à entraîner

Le flux Training demande désormais une **version de dataset enregistrée** dans le projet actif. Une version précise est choisie avant le job.

La sélection ne copie pas une donnée inventée : la compatibilité est recalculée à partir du dataset versionné et des capacités réellement disponibles sur la machine.

## 4. Choix du modèle à entraîner

L'interface propose les moteurs réellement intégrés au `Model Engine`. Pour la classification, le bundle actuel comprend notamment :

- `logistic_regression`
- `random_forest`
- `sgd_incremental`
- `mlp_sklearn`
- `mlp_torch`
- `text_tfidf`
- `pdf_tfidf`
- `image_pixel_logreg`
- `audio_spectral_logreg`
- `video_frame_stats_logreg`

Le système peut aussi proposer la poursuite d'une version de modèle existante lorsqu'un checkpoint local compatible existe réellement.

**Important :** ce sélecteur concerne les modèles que le moteur de training actuel sait réellement exécuter. Il ne prétend pas encore fournir une fine-tuning LoRA/QLoRA générique de n'importe quel LLM Hugging Face. Cette capacité nécessite un moteur de fine-tuning LLM dédié.

## 5. LLM local

Le `LocalLLMProvider` détecte, dans l'ordre fonctionnel du bundle :

1. runtime llama.cpp local géré par l'application ;
2. Ollama local ;
3. `llama-cpp-python` + GGUF local ;
4. Transformers + répertoire de modèle local.

Aucun fallback textuel n'est utilisé lorsque le LLM n'est pas disponible. L'état passe à `LLM REQUIRED` avec **cause** et **solution**.

La sélection du modèle LLM est persistée dans `workspace/llm_models/.selected_model.json` après vérification.

## 6. Gestion des erreurs

Le backend retourne maintenant un contrat d'erreur commun :

```json
{
  "status": "FAILED",
  "error": "...",
  "message": "L'opération n'a pas pu être terminée.",
  "cause": "...",
  "solution": "..."
}
```

Pour les ressources absentes, le dashboard affiche également un toast d'action avec la cause et la solution. Les états `UNAVAILABLE` et `LLM REQUIRED` ne sont pas transformés en succès fictif.

## 7. Missions couvertes

Le cœur du bundle comprend les responsabilités suivantes :

Frontend, Local Backend, AI Orchestrator, AI Mission Engine, Local AI Council, Universal Data Engine, Dataset Registry, Model Engine, Model Registry, Local Model Manager, Compute Engine, Smart Compute Planner, Training Engine, Experiment Engine, Evaluation Engine, Auto Lab, Error Mining, Synthetic Data Lab, Red Team Engine, AI Scientist, Champion/Challenger, Model Genome, Continuous Training, Safety Gate, Deployment Engine, Cost Guardian, Disaster Recovery, Observability, Security, Artifact Storage et Local Configuration/SQLite.

Cela signifie que la **chaîne de responsabilités est bien présente architecturalement**. En revanche, la présence d'un module ne signifie pas que chaque modalité ou chaque type de modèle est déjà entraînable : l'interface marque ces limites au moment du choix et le moteur renvoie `UNAVAILABLE` lorsqu'une capacité réelle manque.

## 8. Identité visuelle

Palette business retenue :

- **Navy principal** `#0C3857` — confiance, infrastructure, navigation.
- **Gold** `#C8A861` — accent premium, état actif, marque.
- **Bleu opérationnel** `#2F6FE4` — actions et liens.
- **Canvas clair** `#F4F6F9` — environnement de travail.
- **Blanc** `#FFFFFF` — cartes et surfaces.
- **Encres** `#102A43` — lecture et données.

Le logo fourni est utilisé localement dans `frontend/assets/alpha-prime-eagle.jpg`.

## 9. Vérification de configuration

Une installation est considérée comme réellement prête pour les délibérations du Council uniquement si un backend LLM local compatible et un modèle valide sont détectés. Sinon l'application doit afficher `LLM REQUIRED`.

Sur l'environnement de build utilisé lors de cette préparation, les bibliothèques `transformers`, `peft`, `datasets`, `accelerate` et `llama_cpp` n'étaient pas installées, et PyTorch disponible était CPU-only. Il serait donc incorrect d'annoncer que le LLM local est déjà opérationnel sur cette machine de build.
