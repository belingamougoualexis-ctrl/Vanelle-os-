"""Reproducible local model delivery bundles."""
from __future__ import annotations
import json, os, zipfile
from pathlib import Path
from . import utils

class DeliveryManager:
    def __init__(self, workspace, conn=None, audit=None):
        self.workspace=Path(workspace); self.conn=conn; self.audit=audit
        self.root=self.workspace/"deliveries"; self.root.mkdir(parents=True,exist_ok=True)

    def package_model_version(self, model_version_id: str) -> dict:
        if self.conn is None:
            raise RuntimeError("Connexion SQLite requise")
        row=self.conn.execute(
            "SELECT mv.*,m.name AS model_name,m.architecture FROM model_versions mv JOIN models m ON mv.model_id=m.id WHERE mv.id=?",
            (model_version_id,),
        ).fetchone()
        if not row:
            raise ValueError("Version de modèle introuvable")
        mv=dict(row); src=mv.get("file_path")
        if not src or not os.path.isfile(src):
            raise RuntimeError("Artefact du modèle absent: aucune livraison réelle ne peut être produite.")
        out=self.root/f"{model_version_id}_delivery.zip"
        manifest={
            "status":"REAL",
            "model_version":mv,
            "source_sha256":utils.sha256_file(src),
            "created_at":utils.now_iso(),
        }
        with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
            z.write(src,Path(src).name)
            z.writestr("model_manifest.json",json.dumps(manifest,ensure_ascii=False,indent=2,default=str))
            z.writestr("MODEL_CARD.md",self._model_card(mv,manifest))
            z.writestr("README.md",self._readme(mv))
            z.writestr("SHA256SUMS.txt", f"{manifest['source_sha256']}  {Path(src).name}\n")
        result={
            "status":"REAL","path":str(out),"sha256":utils.sha256_file(out),
            "size_bytes":out.stat().st_size,"manifest":manifest,
        }
        if self.audit:
            self.audit.log("system","MODEL_DELIVERY_PACKAGED","model_version",model_version_id,result)
        return result

    @staticmethod
    def _model_card(mv,manifest):
        return f"# {mv['model_name']}\n\nArchitecture: {mv['architecture']}\nVersion: {mv['version_number']}\nStatus: {mv['status']}\n\nSource SHA-256: {manifest['source_sha256']}\n"

    @staticmethod
    def _readme(mv):
        return (
            f"# Alpha Prime delivery\n\nModel: {mv['model_name']} v{mv['version_number']}\n"
            "Use the exact configuration and dependencies recorded in model_manifest.json.\n"
        )
