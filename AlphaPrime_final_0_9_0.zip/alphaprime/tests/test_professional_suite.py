
import os, sys, tempfile, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_training_os.core import AITrainingOS

def test_dataset_studio_inspects_real_fixture(tmp_path):
    app=AITrainingOS(str(tmp_path))
    pid=app.create_project("studio")
    src=os.path.join(os.path.dirname(os.path.dirname(__file__)),"fixtures","sample_dataset.csv")
    ds=app.datasets.create_dataset(pid,"sample",src)
    dsv,_=app.datasets.import_version(ds,src)
    r=app.dataset_studio.inspect(dsv)
    assert r["status"]=="REAL"
    assert r["integrity"]["verified"] is True
    assert "quality" in r

def test_llm_health_is_honest_without_model(tmp_path):
    app=AITrainingOS(str(tmp_path))
    r=app.llm_health.verify_all_tasks()
    assert r["status"] in ("UNAVAILABLE","FAILED","REAL")
    if r["status"]=="UNAVAILABLE": assert r["cause"] and r["solution"]

def test_full_system_test_runs_real_components(tmp_path):
    app=AITrainingOS(str(tmp_path))
    r=app.health_suite.run(include_llm=False)
    assert r["truth_status"]=="REAL"
    assert any(x["name"]=="sqlite_integrity" and x["status"]=="PASSED" for x in r["checks"])

def test_delivery_manager_rejects_missing_artifact(tmp_path):
    app=AITrainingOS(str(tmp_path))
    pid=app.create_project("delivery")
    mid=app.models.create_model(pid,"m","logistic_regression")
    mv=app.models.create_version(mid,None,{"code_version":"test","dependencies":{}},{"model_type":"logistic_regression"},{"compute":{}},file_path=None)
    try: app.delivery.package_model_version(mv)
    except RuntimeError as e: assert "artefact" in str(e).lower() or "absent" in str(e).lower()
    else: raise AssertionError("Une livraison sans artefact réel ne doit pas être annoncée")

def test_dataset_studio_cleaning_creates_immutable_new_version(tmp_path):
    app=AITrainingOS(str(tmp_path))
    pid=app.create_project("studio-clean")
    src=os.path.join(os.path.dirname(os.path.dirname(__file__)),"fixtures","sample_dataset.csv")
    ds=app.datasets.create_dataset(pid,"sample",src)
    dsv,_=app.datasets.import_version(ds,src)
    out=app.dataset_studio.apply_cleaning(dsv)
    assert out["status"]=="REAL"
    assert out["new_dataset_version_id"]!=dsv
    assert app.datasets.get_version(dsv)["status"]=="VALIDATED"
    new=app.datasets.get_version(out["new_dataset_version_id"])
    assert new and new["id"]!=dsv and os.path.isfile(new["file_path"])
    prov=json.loads(new["provenance_json"])
    assert prov["parent_dataset_version_id"]==dsv


def test_hardware_status_is_measured(tmp_path):
    app=AITrainingOS(str(tmp_path))
    out=app.hardware.status()
    assert out["status"]=="REAL"
    assert out["scan"]["training_runtime"]["backend"] in ("CPU","CUDA","MPS","GPU_DRIVER_ONLY")


def test_delivery_download_registration(tmp_path):
    app=AITrainingOS(str(tmp_path))
    pid=app.create_project("delivery-api")
    src=os.path.join(os.path.dirname(os.path.dirname(__file__)),"fixtures","sample_dataset.csv")
    result=app.orchestrator.run_tabular_classification(pid,src,"DS","Model","logistic_regression",1,security_policy={"max_prediction_flip_rate":1.0})
    assert result["status"]=="REAL"
    delivery=app.delivery.package_model_version(result["model_version_id"])
    assert delivery["status"]=="REAL" and os.path.isfile(delivery["path"])
