/**
 * Capteurs locaux — sans API IA externe.
 * - Goût : moteur de règles + lexique d’ingrédients
 * - Texture : vision classique sur canvas (contraste, variance, « grain »)
 * - Photo : heuristiques couleur + recherche internet TheMealDB
 */
import type { Nutrition, Recipe, TasteProfile, TextureResult, PhotoResult, VitaminProfile, MineralProfile } from "./types";

// ——— Lexique organoleptique (profil 7 axes 0–100) ———
type Flavor = Partial<TasteProfile> & { weight?: number };

const INGREDIENT_LEXICON: Record<string, Flavor> = {
  // sucré
  sucre: { sucre: 95, weight: 1.2 },
  miel: { sucre: 90, weight: 1 },
  caramel: { sucre: 85, amer: 25, weight: 1 },
  chocolat: { sucre: 55, amer: 45, gras: 50, weight: 1 },
  vanille: { sucre: 40, weight: 0.4 },
  // acide
  citron: { acide: 90, weight: 1 },
  vinaigre: { acide: 95, weight: 1 },
  tomate: { acide: 55, umami: 40, sucre: 25, weight: 0.8 },
  yaourt: { acide: 50, weight: 0.6 },
  // salé / umami
  sel: { sale: 100, weight: 1.4 },
  "sauce soja": { sale: 80, umami: 85, weight: 1 },
  miso: { sale: 70, umami: 90, weight: 1 },
  parmesan: { sale: 60, umami: 80, gras: 45, weight: 0.9 },
  anchois: { sale: 75, umami: 90, weight: 0.9 },
  champignon: { umami: 70, weight: 0.7 },
  // gras
  beurre: { gras: 90, sale: 20, weight: 1 },
  huile: { gras: 85, weight: 0.8 },
  crème: { gras: 80, sucre: 15, weight: 0.9 },
  fromage: { gras: 70, sale: 45, umami: 40, weight: 0.8 },
  // amer / piquant
  café: { amer: 80, weight: 0.7 },
  cacao: { amer: 70, weight: 0.6 },
  piment: { piquant: 90, weight: 1 },
  poivre: { piquant: 50, weight: 0.5 },
  gingembre: { piquant: 45, acide: 20, weight: 0.6 },
  // viandes / base
  bœuf: { umami: 70, sale: 30, gras: 45, weight: 1 },
  boeuf: { umami: 70, sale: 30, gras: 45, weight: 1 },
  poulet: { umami: 45, sale: 25, weight: 0.9 },
  porc: { umami: 55, gras: 50, weight: 0.9 },
  saumon: { umami: 50, gras: 55, sale: 30, weight: 0.9 },
  poisson: { umami: 45, sale: 30, weight: 0.8 },
  œuf: { umami: 35, gras: 40, weight: 0.6 },
  oeuf: { umami: 35, gras: 40, weight: 0.6 },
  // féculents / légumes
  riz: { sucre: 15, weight: 0.5 },
  pain: { sucre: 20, weight: 0.5 },
  pomme: { acide: 40, sucre: 45, weight: 0.6 },
  oignon: { sucre: 30, amer: 15, weight: 0.5 },
  ail: { piquant: 35, umami: 25, weight: 0.5 },
  thym: { amer: 20, weight: 0.3 },
  herbes: { amer: 15, weight: 0.3 },
  basilic: { amer: 10, weight: 0.3 },
  coriandre: { amer: 12, weight: 0.3 },
  citronnelle: { acide: 30, piquant: 20, weight: 0.4 },
  curry: { piquant: 40, umami: 30, weight: 0.7 },
  cumin: { amer: 25, weight: 0.4 },
  cannelle: { sucre: 35, amer: 20, weight: 0.4 },
  moutarde: { piquant: 55, acide: 30, weight: 0.6 },
  cornichon: { acide: 60, sale: 40, weight: 0.5 },
  avocat: { gras: 70, weight: 0.7 },
  banane: { sucre: 70, weight: 0.6 },
  fraise: { acide: 40, sucre: 50, weight: 0.5 },
  orange: { acide: 55, sucre: 40, weight: 0.5 },
  lard: { gras: 85, sale: 55, umami: 40, weight: 0.8 },
  bacon: { gras: 80, sale: 60, umami: 45, weight: 0.8 },
  crevette: { umami: 55, sale: 40, weight: 0.7 },
  tofu: { umami: 25, weight: 0.5 },
  lait: { gras: 30, sucre: 20, weight: 0.4 },
  farine: { sucre: 10, weight: 0.3 },
  beurre de cacahuète: { gras: 75, sucre: 25, weight: 0.7 },
};


const EMPTY_TASTE: TasteProfile = {
  acide: 15, sucre: 15, amer: 10, sale: 25, umami: 25, gras: 25, piquant: 8,
};

function clamp(n: number, a = 0, b = 100) {
  return Math.max(a, Math.min(b, Math.round(n)));
}

/** Simulation de palais — 100 % local, règles + lexique */
export function localSimulateTaste(dish: string, tweaks = ""): {
  title: string;
  note: string;
  taste: TasteProfile;
  risks: string[];
  adjustments: string[];
} {
  const text = `${dish} ${tweaks}`.toLowerCase();
  const acc = { ...EMPTY_TASTE };
  const weights: Record<keyof TasteProfile, number> = {
    acide: 0, sucre: 0, amer: 0, sale: 0, umami: 0, gras: 0, piquant: 0,
  };

  for (const [key, flavor] of Object.entries(INGREDIENT_LEXICON)) {
    if (!text.includes(key)) continue;
    const w = flavor.weight ?? 1;
    (Object.keys(EMPTY_TASTE) as (keyof TasteProfile)[]).forEach((axis) => {
      const v = flavor[axis];
      if (typeof v === "number") {
        acc[axis] += v * w;
        weights[axis] += w;
      }
    });
  }

  const taste: TasteProfile = { ...EMPTY_TASTE };
  (Object.keys(EMPTY_TASTE) as (keyof TasteProfile)[]).forEach((axis) => {
    taste[axis] = weights[axis] > 0 ? clamp(acc[axis] / weights[axis]) : EMPTY_TASTE[axis];
  });

  // Effets de cuisson mentionnés
  if (/grillé|saisi|maillard|rôti|brûlé/.test(text)) {
    taste.umami = clamp(taste.umami + 12);
    taste.amer = clamp(taste.amer + 8);
  }
  if (/caramel|confit|réduit/.test(text)) {
    taste.sucre = clamp(taste.sucre + 15);
    taste.acide = clamp(taste.acide + 5);
  }
  if (/fumé|fumée/.test(text)) {
    taste.amer = clamp(taste.amer + 10);
    taste.umami = clamp(taste.umami + 8);
  }
  if (/cru|tartare|ceviche/.test(text)) {
    taste.acide = clamp(taste.acide + 10);
    taste.gras = clamp(taste.gras - 5);
  }

  const risks: string[] = [];
  const adjustments: string[] = [];

  if (taste.sale > 70) {
    risks.push("Salinité dominante — risque de saturation.");
    adjustments.push("Couper avec un acide (citron, vinaigre) ou un gras neutre.");
  }
  if (taste.sucre > 75 && taste.acide < 30) {
    risks.push("Sucre sans contrepoint acide.");
    adjustments.push("Ajouter un filet d’acide (citron, vinaigre de cidre).");
  }
  if (taste.amer > taste.sucre + 15 && taste.amer > 40) {
    risks.push("Amertume en avant.");
    adjustments.push("Équilibrer avec une pincée de sucre ou un élément gras.");
  }
  if (taste.gras > 70 && taste.acide < 25) {
    risks.push("Gras lourd, manque de fraîcheur.");
    adjustments.push("Acide vif ou herbes fraîches pour alléger.");
  }
  if (taste.umami < 20 && taste.sale < 30) {
    risks.push("Plat potentiellement plat (peu d’umami / sel).");
    adjustments.push("Parmesan, miso, champignons ou réduction de jus.");
  }
  if (taste.piquant > 70) {
    risks.push("Piquant très présent.");
    adjustments.push("Tempérer avec yaourt, crème ou matière grasse.");
  }
  if (risks.length === 0) {
    risks.push("Équilibre global correct d’après le lexique.");
  }
  if (adjustments.length === 0) {
    adjustments.push("Goûter et ajuster le sel en fin de cuisson.");
  }

  const order = (Object.entries(taste) as [keyof TasteProfile, number][])
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([k]) => k);

  const note = `Première sensation : ${order[0]}. Puis ${order[1]}, avec ${order[2]} en fond. ` +
    `Calcul local à partir des ingrédients détectés (« ${dish.slice(0, 60)}${dish.length > 60 ? "…" : ""} »). ` +
    `Pas de capteur chimique — moteur de règles + lexique organoleptique.`;

  return {
    title: dish.trim().slice(0, 80) || "Plat analysé",
    note,
    taste,
    risks,
    adjustments,
  };
}

// ——— Texture : analyse canvas (vision classique) ———

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Image illisible"));
    img.src = dataUrl;
  });
}

export async function localAnalyzeTexture(imageDataUrl: string, question = ""): Promise<TextureResult> {
  const img = await loadImage(imageDataUrl);
  const size = 128;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d", { willReadFrequently: true })!;
  ctx.drawImage(img, 0, 0, size, size);
  const { data } = ctx.getImageData(0, 0, size, size);

  let sum = 0, sumSq = 0, edge = 0;
  const gray: number[] = [];
  for (let i = 0; i < data.length; i += 4) {
    const g = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
    gray.push(g);
    sum += g;
    sumSq += g * g;
  }
  const n = gray.length;
  const mean = sum / n;
  const variance = sumSq / n - mean * mean;
  const std = Math.sqrt(Math.max(0, variance));

  // Gradient approximatif (voisin horizontal)
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size - 1; x++) {
      edge += Math.abs(gray[y * size + x] - gray[y * size + x + 1]);
    }
  }
  edge /= size * (size - 1);

  // Score 0–100 : plus de variance + edges = plus de « texture / grain »
  const score = clamp(std * 1.8 + edge * 0.35);

  const cues: string[] = [];
  if (std < 18) cues.push("Surface relativement homogène (peu de contraste local).");
  else if (std < 35) cues.push("Contraste modéré — grain visible.");
  else cues.push("Fort contraste local — surface irrégulière ou marquée.");

  if (edge < 12) cues.push("Peu de transitions nettes (aspect lisse ou crémeux).");
  else if (edge < 28) cues.push("Transitions moyennes (poreux ou fibreux possible).");
  else cues.push("Nombreuses micro-arêtes (croûte, grillé, croustillant possible).");

  if (mean < 60) cues.push("Image sombre — cuisson poussée ou éclairage faible.");
  else if (mean > 180) cues.push("Image claire — surface pâle ou forte lumière.");

  let verdict: string;
  let nextMove: string;
  let subject = "Surface alimentaire";

  if (score < 28) {
    verdict = "Texture plutôt lisse / homogène.";
    nextMove = "Si vous visez du croustillant : pousser la chaleur ou sécher la surface.";
    subject = "Lisse / crémeux";
  } else if (score < 55) {
    verdict = "Texture intermédiaire — grain présent sans être extrême.";
    nextMove = "Vérifier le point de cuisson au toucher ou à la sonde.";
    subject = "Grain moyen";
  } else {
    verdict = "Texture marquée — croûte, fibres ou relief important.";
    nextMove = "Surveiller pour ne pas aller vers le brûlé ; reposer si viande.";
    subject = "Relief / croûte";
  }

  if (/pâte|pain|pétrie/i.test(question)) {
    if (score < 30) nextMove = "Pâte encore lisse : continuer le pétrissage ou laisser développer le gluten.";
    else nextMove = "Réseau déjà visible : passer au façonnage ou à la cuisson.";
  }
  if (/viande|steak|côte|point/i.test(question)) {
    if (mean < 70 && score > 40) nextMove = "Surface bien marquée : vérifier le cœur à la sonde.";
    else nextMove = "Saisir plus fort pour développer le Maillard si besoin.";
  }

  cues.push("Analyse 100 % locale (pixels) — pas de modèle cloud.");

  return { subject, score, verdict, cues, nextMove };
}

// ——— Photo : couleurs + recherche internet structurée ———

const COLOR_TO_QUERY: { test: (r: number, g: number, b: number) => boolean; q: string }[] = [
  { test: (r, g, b) => r > 140 && g < 90 && b < 90, q: "beef" },
  { test: (r, g, b) => r > 160 && g > 100 && b < 80, q: "chicken" },
  { test: (r, g, b) => r > 180 && g > 150 && b < 100, q: "dessert" },
  { test: (r, g, b) => r < 100 && g > 100 && b < 100, q: "salad" },
  { test: (r, g, b) => r > 120 && g > 80 && b < 70, q: "pasta" },
  { test: (r, g, b) => b > r && b > g, q: "seafood" },
  { test: (r, g, b) => r > 100 && g > 100 && b > 100 && Math.abs(r - g) < 30, q: "rice" },
];

async function mealDbSearch(q: string): Promise<Recipe | null> {
  try {
    const res = await fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${encodeURIComponent(q)}`);
    if (!res.ok) return null;
    const data = (await res.json()) as { meals: any[] | null };
    const meal = data.meals?.[0];
    if (!meal) return null;
    return mealDbToRecipe(meal);
  } catch {
    return null;
  }
}

async function mealDbRandom(): Promise<Recipe | null> {
  try {
    const res = await fetch("https://www.themealdb.com/api/json/v1/1/random.php");
    if (!res.ok) return null;
    const data = (await res.json()) as { meals: any[] | null };
    const meal = data.meals?.[0];
    if (!meal) return null;
    return mealDbToRecipe(meal);
  } catch {
    return null;
  }
}

function mealDbToRecipe(meal: any): Recipe {
  const ingredients: { name: string; qty: string }[] = [];
  for (let i = 1; i <= 20; i++) {
    const name = (meal[`strIngredient${i}`] || "").trim();
    const qty = (meal[`strMeasure${i}`] || "").trim();
    if (name) ingredients.push({ name, qty: qty || "selon goût" });
  }
  const lines = String(meal.strInstructions || "")
    .replace(/\r\n/g, "\n")
    .split(/\n+/)
    .map((s: string) => s.replace(/^\d+[\.\)\-\:]\s*/, "").trim())
    .filter((s: string) => s.length > 8);
  const steps = (lines.length ? lines : [String(meal.strInstructions || "Préparer selon la tradition.")]).slice(0, 14).map((text: string, i: number) => ({
    n: i + 1,
    text,
  }));
  return {
    id: `web_${meal.idMeal}_${Math.random().toString(36).slice(2, 6)}`,
    title: meal.strMeal || "Plat détecté",
    origin: meal.strArea || "Monde",
    story: `Identifié localement par couleurs dominantes, puis recette structurée depuis une base ouverte (${meal.strCategory || "divers"}).`,
    servings: 4,
    timeMin: Math.max(20, steps.length * 7),
    difficulty: steps.length > 8 ? "chef" : steps.length > 4 ? "intermediaire" : "simple",
    ingredients,
    steps,
    taste: { acide: 25, sucre: 20, amer: 12, sale: 35, umami: 40, gras: 35, piquant: 12 },
    nutrition: { kcal: 420, prot: 18, glucides: 35, lipides: 18, fibres: 3, sel: 1.1, ig: 50 },
    tags: [meal.strCategory, meal.strArea].filter(Boolean) as string[],
    source: "photo",
    createdAt: Date.now(),
  };
}

export async function localAnalyzeDishPhoto(imageDataUrl: string, hint = ""): Promise<PhotoResult> {
  const img = await loadImage(imageDataUrl);
  const size = 64;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  ctx.drawImage(img, 0, 0, size, size);
  const { data } = ctx.getImageData(0, 0, size, size);

  let rSum = 0, gSum = 0, bSum = 0, n = 0;
  for (let i = 0; i < data.length; i += 4) {
    rSum += data[i];
    gSum += data[i + 1];
    bSum += data[i + 2];
    n++;
  }
  const r = rSum / n, g = gSum / n, b = bSum / n;

  let query = hint.trim().split(/\s+/)[0] || "";
  if (!query) {
    for (const rule of COLOR_TO_QUERY) {
      if (rule.test(r, g, b)) {
        query = rule.q;
        break;
      }
    }
  }
  if (!query) query = "chicken";

  let recipe = await mealDbSearch(query);
  if (!recipe) recipe = await mealDbRandom();
  if (!recipe) {
    // recette minimale locale
    recipe = {
      id: `local_${Date.now()}`,
      title: hint || "Plat non identifié en ligne",
      origin: "Local",
      story: "Analyse couleur locale uniquement — base internet indisponible.",
      servings: 2,
      timeMin: 30,
      difficulty: "simple",
      ingredients: [],
      steps: [{ n: 1, text: "Réessayez avec un indice (nom du plat) ou vérifiez la connexion." }],
      taste: EMPTY_TASTE,
      nutrition: { kcal: 0, prot: 0, glucides: 0, lipides: 0, fibres: 0, sel: 0, ig: 0 },
      tags: ["local"],
      source: "photo",
      createdAt: Date.now(),
    };
  }

  const confidence = hint ? 72 : 48;
  const vitamins: VitaminProfile[] = [
    { vitamin: "Vitamine C", amount: 12, unit: "mg", percentDailyValue: 13 },
    { vitamin: "Vitamine B12", amount: 0.8, unit: "µg", percentDailyValue: 33 },
  ];
  const minerals: MineralProfile[] = [
    { mineral: "Fer", amount: 2.1, unit: "mg", percentDailyValue: 12 },
    { mineral: "Potassium", amount: 320, unit: "mg", percentDailyValue: 7 },
  ];

  return {
    dish: recipe.title,
    cuisine: recipe.origin,
    confidence,
    portionDescription: "Portion estimée pour 1 assiette (heuristique locale).",
    nutritionBasis: "Estimations indicatives — pas d’analyse labo. Recette structurée via internet gratuit.",
    vitamins,
    minerals,
    recipe,
  };
}

// ——— Journal : relier une note sans API ———
export function localLinkVoiceNote(
  transcript: string,
  recipes: { id: string; title: string }[],
): {
  recipeId: string | null;
  recipeTitle: string | null;
  tag: "trop-sale" | "trop-fade" | "parfait" | "pas-cuit" | "trop-cuit" | "texture" | "autre";
  adjustment: string;
} {
  const t = transcript.toLowerCase();
  let tag: "trop-sale" | "trop-fade" | "parfait" | "pas-cuit" | "trop-cuit" | "texture" | "autre" = "autre";
  let adjustment = "Noter l’ajustement pour la prochaine fois.";

  if (/trop\s*sal|salé|salée|sel/.test(t)) {
    tag = "trop-sale";
    adjustment = "Réduire le sel de 20–30 % et compenser avec un acide (citron, vinaigre).";
  } else if (/fade|bland|sans.?goût|insipide/.test(t)) {
    tag = "trop-fade";
    adjustment = "Assaisonner plus tôt, ajouter umami (parmesan, miso) ou une pointe d’acide.";
  } else if (/parfait|excellent|nickel|réussi/.test(t)) {
    tag = "parfait";
    adjustment = "Reproduire les mêmes temps et quantités.";
  } else if (/pas\s*assez\s*cuit|cru|saignant\s*trop|pas\s*cuit/.test(t)) {
    tag = "pas-cuit";
    adjustment = "Prolonger la cuisson de 3–5 min ou monter légèrement la température.";
  } else if (/trop\s*cuit|brûl|sec|desséch/.test(t)) {
    tag = "trop-cuit";
    adjustment = "Sortir plus tôt ; vérifier à la sonde ou réduire la puissance.";
  } else if (/texture|caoutch|mou|dur|fibreux|gluant/.test(t)) {
    tag = "texture";
    adjustment = "Ajuster hydratation, temps de repos ou température de cuisson.";
  }

  let recipeId: string | null = null;
  let recipeTitle: string | null = null;
  for (const r of recipes) {
    const words = r.title.toLowerCase().split(/\s+/).filter((w) => w.length > 3);
    if (words.some((w) => t.includes(w))) {
      recipeId = r.id;
      recipeTitle = r.title;
      break;
    }
  }
  if (!recipeId && recipes[0]) {
    recipeId = recipes[0].id;
    recipeTitle = recipes[0].title;
  }

  return { recipeId, recipeTitle, tag, adjustment };
}

// ——— Santé : adapter une recette sans API ———
export function localAdaptForHealth(input: {
  glucose: number;
  fatigue: number;
  eatenKcal: number;
  eatenGlucides: number;
  recipeTitle: string;
  recipeSummary: string;
}): {
  title: string;
  rationale: string;
  watchouts: string[];
  suggestions: string[];
} {
  const { glucose, fatigue, eatenKcal, eatenGlucides, recipeTitle } = input;
  const watchouts: string[] = [];
  const suggestions: string[] = [];
  let rationale = "";

  if (glucose >= 140 || eatenGlucides > 120) {
    rationale = "Glycémie ou charge glucidique déjà élevée : privilégier fibres, protéines, peu de sucre rapide.";
    suggestions.push("Remplacer une partie des féculents par des légumes.");
    suggestions.push("Éviter les sauces sucrées ; préférer vinaigre, herbes, citron.");
    watchouts.push("Surveiller les portions de pain, riz, desserts.");
  } else if (glucose <= 80) {
    rationale = "Glycémie basse : un apport glucidique modéré et des protéines stabilisent.";
    suggestions.push("Garder un féculent raisonnable et une source de protéine.");
    watchouts.push("Ne pas sauter le repas.");
  } else {
    rationale = "Zone glycémique correcte : équilibre protéines / légumes / féculents.";
    suggestions.push("Assiette : moitié légumes, quart protéine, quart féculent.");
  }

  if (fatigue > 60) {
    suggestions.push("Repas simple, digeste, éviter fritures lourdes.");
    watchouts.push("Fatigue élevée — limiter l’alcool et les plats très gras.");
  }
  if (eatenKcal > 1800) {
    suggestions.push("Portion réduite ou version plus légère de « " + recipeTitle + " ».");
  }

  return {
    title: `Adaptation — ${recipeTitle}`,
    rationale,
    watchouts: watchouts.length ? watchouts : ["Aucun point critique détecté."],
    suggestions,
  };
}
