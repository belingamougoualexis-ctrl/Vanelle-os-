# Corriger « Build and Sign Release APK » (GitHub Actions)

## Pourquoi ça a échoué (15 s)

D’après le log (licences Google GDK) et le dépôt Prime :

1. **Pas de dossier `android/`** dans le repo tant que `npx cap add android` n’a pas été exécuté  
2. Le job affiche les **licences SDK** puis s’arrête souvent si :
   - le chemin Gradle est faux
   - les **secrets de signature** manquent (`SIGNING_KEY`, etc.)
   - `npm run build` ne produit pas `dist/`

Le texte long sur la privacy GDK n’est **pas** l’erreur : c’est la licence Android acceptée automatiquement.

## Correctif fourni

Fichier : `.github/workflows/android-release.yml`

Il fait dans l’ordre :
1. Node 20 + Java 17 + Android SDK  
2. `sdkmanager --licenses`  
3. `npm install` + Capacitor  
4. `npx cap add android` + `cap sync`  
5. `./gradlew assembleRelease`  
6. Signature **si** secrets présents  
7. Upload artifact `prime-release-apk`

## Secrets à ajouter (Settings → Secrets → Actions)

| Secret | Contenu |
|--------|---------|
| `SIGNING_KEY` | Fichier `.jks` encodé en base64 |
| `KEY_ALIAS` | Ex. `prime` |
| `KEY_STORE_PASSWORD` | Mot de passe keystore |
| `KEY_PASSWORD` | Mot de passe de la clé |

```bash
# Sur ta machine
keytool -genkey -v -keystore prime-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias prime
openssl base64 -A -in prime-release.jks > key.b64
# Coller le contenu de key.b64 dans SIGNING_KEY
```

Sans ces secrets, l’APK **release non signé** (ou debug) est quand même uploadé en artifact.

## Lancer le workflow

1. Pousse le dossier `.github/workflows/` sur GitHub  
2. Onglet **Actions** → **Build and Sign Release APK** → **Run workflow**  
3. Télécharge l’artifact `prime-release-apk`

## Si ça échoue encore

Ouvre le log et cherche la **première** ligne rouge `Error` / `FAILURE` (pas le texte de licence).

Cas fréquents :

| Message | Solution |
|---------|----------|
| `dist/ introuvable` | Vérifier que `npm run build` génère bien des fichiers statiques |
| `android/ missing` | Le step `cap add android` a échoué — regarder les logs npm |
| `validateSigningRelease` | Secrets absents ou mauvais alias |
| `SDK location not found` | Le step Setup Android SDK a échoué |

## Build local (recommandé pour tester)

```bash
npm install
npm install @capacitor/core @capacitor/cli @capacitor/android
npm run build
npx cap add android
npx cap sync android
cd android && ./gradlew assembleRelease
```

APK : `android/app/build/outputs/apk/release/`
