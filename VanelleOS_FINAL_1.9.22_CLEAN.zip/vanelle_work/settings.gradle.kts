pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Dépôt conservé en complément ; llamacpp-kotlin 0.4.0 est disponible sur Maven Central
        maven(url = "https://jitpack.io")
    }
}
rootProject.name = "VanelleOS"
include(":app")
