# VanelleOS 1.9.22 — correctif final IA locale

## Correctifs

- Correction de la résolution de `LlamaHelper` pour `llamacpp-kotlin 0.4.0`.
- Suppression de la détection erronée de `generate/complete/chat/ask`.
- Utilisation de `predict(...)` comme API de génération.
- Abonnement aux `LLMEvent` avant le lancement de la génération afin de ne pas perdre les premiers tokens.
- Gestion de `Ongoing`, `Done` et `Error`.
- Conservation du verrouillage d'inférence pour éviter deux générations natives simultanées.
- La réponse vocale démarre selon la disponibilité réelle de la génération.
- Le chargement mémoire démarre dès que le modèle est validé.
- Ajout d'un workflow GitHub Actions pour construire les variantes moderne 64 bits et legacy.
- Version de l'application : 1.9.22-real-llama / versionCode 33.

## Modèle

Le projet continue d'utiliser le GGUF Llama 3.2 1B Instruct Q4_K_M déjà prévu par VanelleOS. Le fichier est validé par taille, signature GGUF et SHA-256 avant chargement.

## Limite de validation locale

L'environnement de génération ne contient ni Gradle ni Android SDK. Le build Android complet ne peut donc pas être exécuté ici. Le workflow fourni effectue la compilation réelle sur GitHub Actions avec JDK 17 et Gradle 8.10.2.
