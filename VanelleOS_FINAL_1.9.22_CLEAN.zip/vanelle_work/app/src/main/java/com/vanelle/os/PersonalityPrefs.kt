package com.vanelle.os
import android.content.Context

object PersonalityPrefs {
    private fun p(c: Context) = c.getSharedPreferences("vanelle_prefs", 0)

    /** calme | energique | coach | pote */
    fun getPersonality(c: Context) = p(c).getString("personality", "pote") ?: "pote"
    fun setPersonality(c: Context, id: String) {
        if (id in listOf("calme", "energique", "coach", "pote"))
            p(c).edit().putString("personality", id).apply()
    }

    fun personalityLabel(id: String) = when (id) {
        "calme" -> "Calme & posée"
        "energique" -> "Énergique"
        "coach" -> "Coach motivante"
        else -> "Pote bienveillante"
    }

    /**
     * Style conversationnel Vanelle : naturel et chaleureux, avec la précision
     * d'un assistant expert, une structure claire quand elle est utile et des
     * réponses directes. On décrit des qualités de comportement, sans imiter
     * ni prétendre être un autre assistant.
     */
    fun systemTone(c: Context): String =
        "Tu es Vanelle, une assistante personnelle naturelle, chaleureuse, précise et utile. " +
        "Comporte-toi comme un mélange de qualités d'assistants modernes : compréhension fine du contexte, " +
        "raisonnement rigoureux, réponses naturelles, bonne structure et ton humain. " +
        "Ne prétends jamais être Claude, Gemini, ChatGPT ou un autre système. " +
        "Pour une conversation, réponds directement à l'intention de l'utilisateur. " +
        "Pour une salutation comme bonjour, salut, coucou ou bonsoir, réponds simplement et naturellement à la salutation : " +
        "ne définis jamais le mot de salutation et ne donne pas sa définition sauf si l'utilisateur demande explicitement sa définition. " +
        "N'invente jamais une action effectuée. Si une information est incertaine, dis-le clairement. " +
        "Réponds en français sauf demande contraire."

    fun isGuestMode(c: Context) = false // mode invité supprimé
    fun setGuestMode(c: Context, on: Boolean) { /* mode invité supprimé */ }

    fun preferOffline(c: Context) = p(c).getBoolean("prefer_offline", true)
    fun setPreferOffline(c: Context, on: Boolean) = p(c).edit().putBoolean("prefer_offline", on).apply()
}
